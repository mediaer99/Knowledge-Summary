/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/

#include <pthread.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/time.h>

#include "ax_venc_interface.h"
#include "ax_venc_api.h"
#include "ax_sys_log.h"
#include "ax_fifo.h"
#include "ax_venc_log.h"
#include "ax_utils.h"
#include "vc8000_driver.h"
#include "ax_venc_proc.h"
#include "ax_jenc_proc.h"
#include "ax_sys_api.h"
#include "ax_sys_api_internal.h"
#include "ax_frame.h"

#ifndef AX_VENC_PUBLIC
    #define AX_VENC_PUBLIC __attribute__ ((visibility ("default")))
#endif

AX_S32 g_fd_venc = -1;
AX_S32 g_fd_jenc = -1;
AX_S32 g_fd_devmem = -1;

static AX_S32 g_venc_chn_count = 0;
static pthread_mutex_t g_venc_chn_count_mutex_lock = PTHREAD_MUTEX_INITIALIZER;


AX_VENC_MOD_INSTANCE_S gModCtx = {
	.enModState = VENC_MOD_UNINIT,
	.isVencEncodeLoopExit = {[0 ... AX_VENC_LOOP_THREAD_NUM-1] = AX_FALSE},
	.isJencEncodeLoopExit = AX_FALSE,
	.enChnState = {[0 ... MAX_VENC_NUM-1] = VENC_CHN_STATE_DESTROYED},
	.stChnStateMutex = {[0 ... MAX_VENC_NUM-1] = PTHREAD_MUTEX_INITIALIZER},
	.bEncSelectCondInit = AX_FALSE,
	.stEncSelectMutex = PTHREAD_MUTEX_INITIALIZER,
	.stEncSelectCond = PTHREAD_COND_INITIALIZER,
	.stVencSelectGrp = {[0 ... MAX_VENC_GRP_NUM-1] = {
		.bEncSelectCondInit = AX_FALSE,
		.stEncSelectMutex = PTHREAD_MUTEX_INITIALIZER,
		.stEncSelectCond = PTHREAD_COND_INITIALIZER,}},
	.vencGrpId = {[0 ... MAX_VENC_NUM-1] = -1},
	.isVencEncodeLoopCreate = {[0 ... AX_VENC_LOOP_THREAD_NUM-1] = AX_FALSE},
	.isJencEncodeLoopCreate = AX_FALSE,
	.isVencEnterSleep = {[0 ... AX_VENC_LOOP_THREAD_NUM-1] = AX_FALSE},
	.isJencEnterSleep = AX_FALSE,
	.isVencWaitUnlock = AX_FALSE,
	.isJencWaitUnlock = AX_FALSE,
};

static const char * gVencChnState[] = {
	"CREATED",
	"STARTED",
	"STOPPED",
	"DESTROYING",
	"DESTROYED",
	"RESETED"
};

#define MAX_DROP_FRAME_NUM 65535
#define MIN_DROP_FRAME_NUM 0
#define MAX_REENCODE_FRAME_NUM 3
#define MIN_REENCODE_FRAME_NUM 0
#define MAX_DROP_FRAME_THR_BPS 167772160    // 160 * 1024 * 1024
#define MIN_DROP_FRAME_THR_BPS 65536		// 64 * 1024

/* only for the sync with ChnDestroy/GetStream/ReleaseStream */
static pthread_mutex_t gstDstryGetMutex[MAX_VENC_NUM] = {
	[0 ... MAX_VENC_NUM-1] = PTHREAD_MUTEX_INITIALIZER
};

/* only for the sync with ChnDestroy/SendFrame */
static pthread_mutex_t gstDstrySendMutex[MAX_VENC_NUM] = {
	[0 ... MAX_VENC_NUM-1] = PTHREAD_MUTEX_INITIALIZER
};

static pthread_mutex_t gJpegEncodeOnceMutex = PTHREAD_MUTEX_INITIALIZER;

#define VENC_CHN_RANGE_CHECK(VeChn)							\
	do {										\
		if (VeChn < 0 || VeChn >= MAX_VENC_NUM) {				\
			VLOG_ERROR("VENC: Invalid Channel ID(%d), RANGE IN[0, %d).\n",	\
				VeChn, MAX_VENC_NUM);						\
			return AX_ERR_VENC_INVALID_CHNID;					\
		}										\
	} while (0)

#define VENC_POINTER_CHECK(VeChn, ptr)							\
	do {										\
		if (NULL == ptr) {							\
			VLOG_ERROR("VencChn %d: NULL pointer.\n", VeChn);		\
			return AX_ERR_VENC_NULL_PTR;					\
		}									\
	} while (0)

#define VENC_CHN_EXIST_CHECK(VeChn, pChn)						\
	do {										\
		if (NULL == pChn) {							\
			VLOG_ERROR("VencChn %d: Channel %d not exist.\n",		\
				VeChn, VeChn);						\
			return AX_ERR_VENC_UNEXIST;					\
		}									\
	} while (0)

#define VENC_GRP_RANGE_CHECK(grpId)							\
	do {										\
		if (grpId < 0 || grpId >= MAX_VENC_GRP_NUM) {				\
			VLOG_ERROR("VENC: Invalid Grp ID(%d), RANGE IN[0, %d).\n",	\
				grpId, MAX_VENC_GRP_NUM);						\
			return AX_ERR_VENC_INVALID_GRPID;					\
		}										\
	} while (0)

#define VENC_CHN_COUNT_MUTEX_LOCK(lock) \
    do { \
        int res = pthread_mutex_lock(&lock); \
        if (0 != res) { \
            VLOG_ERROR("VENC_CHN_COUNT_MUTEX_LOCK failed\n"); \
        } \
    } while(0)

#define VENC_CHN_COUNT_MUTEX_UNLOCK(lock) \
    do { \
        int res = pthread_mutex_unlock(&lock); \
        if (0 != res) { \
            VLOG_ERROR("VENC_CHN_COUNT_MUTEX_UNLOCK failed\n"); \
        } \
    } while(0)

extern VENC_DUMP_DATA_S gVencDumpData;

AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM] = {[0 ... MAX_VENC_NUM-1] = NULL};
AX_JPEG_ENCODE_ONE_FRAME_INSTANCE_S gstJpegInst = {.pEncoder = NULL};

static AX_VOID VencUpdateRcParam(AX_S32 VeChn, const AX_VENC_RC_PARAM_S *pstChnRcParam);
static AX_VOID VencUpdateChnVariables(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pstChnAttr);
static AX_VOID VencTryWakeupInputQueueReader(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_VOID VencTryStartInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_VOID VencTryStopInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_VOID VencTryClearInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_VOID VencTryClearOutputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
AX_VOID VencTryWakeupOutputQueueReader(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pstChnAttr);
static AX_BOOL VencIsAnyChnStrmExist(AX_CHN_STREAM_STATUS_S *pstChnStrmState);
static AX_BOOL VencIsGrpChnStrmExist(VENC_GRP grpId, AX_CHN_STREAM_STATUS_S *pstChnStrmState, AX_U32 *pValidChnNum);
static AX_BOOL VencChnIsInGrp(VENC_GRP grpId, VENC_CHN VeChn);

static AX_S32 VencCreateInputKfifo(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_S32 VencDestroyInputKfifo(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_S32 VencSendFifoTimeout(VENC_CHN VeChn, FifoInst fifoObj, AX_S32 s32MilliSec);
static AX_S32 VencSetInputKfifoDepth(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_S32 VencSendFrameToDebugFifo(VENC_CHN VeChn, AX_BLK BlockID, AX_S32 Devfd);
static AX_S32 VencSendFrameChnAttrCheck(VENC_CHN VeChn,
			const AX_VIDEO_FRAME_INFO_S *pstFrame, const AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_S32 VencSendFrameCropAttrCheck(VENC_CHN VeChn,
			const AX_VIDEO_FRAME_INFO_S *pstFrame, const AX_VENC_CHN_INSTANCE_S *pChnInst);
static AX_S32 VencSpsVuiParamCheck(VENC_CHN VeChn, const AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam);
static AX_S32 VencRateJamStrategyParamCheck(VENC_CHN VeChn, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam);
static AX_S32 VencSuperFrameCfgCheck(VENC_CHN VeChn, const AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg);
static AX_S32 JpegEncodeOnceInit(AX_VOID);
static AX_S32 JpegEncodeOnceDeinit(AX_VOID);

static AX_S32 AX_VENC_NotifyEventCallBack(const AX_NOTIFY_EVENT_E event,AX_VOID * pdata)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;
	AX_U8 VeChn;
	AX_S32 i;

	VLOG_INFO("event:%d\n",event);

	switch(event)
	{
	case AX_NOTIFY_EVENT_SLEEP:
		AX_SYS_WakeLock(AX_ID_VENC);

		for(VeChn = 0; VeChn < MAX_VENC_NUM; VeChn++){
			pChnInst = gChnInst[VeChn];

			if(pChnInst == NULL)
				continue;

			if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType))
				continue;

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn])
				continue;

			pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);

			/*step1:stop receiving new data */
			VencTryStopInputQueue(VeChn,pChnInst);

			/*step2: try to clear the input queue
			*Pay special attention to the reset operation on the vb reference count
			*/
			VencTryClearInputQueue(VeChn,pChnInst);

			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		}

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			gModCtx.isVencEnterSleep[i] = AX_TRUE;
		}

		gModCtx.isVencWaitUnlock = AX_TRUE;
		pthread_mutex_lock(&gModCtx.stVencMutex);
		pthread_cond_signal(&gModCtx.stVencCond);
		pthread_mutex_unlock(&gModCtx.stVencMutex);
		break;
	case AX_NOTIFY_EVENT_WAKEUP:

		for(VeChn = 0; VeChn < MAX_VENC_NUM; VeChn++){
			pChnInst = gChnInst[VeChn];

			if(pChnInst == NULL)
				continue;

			if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType))
				continue;

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn])
				continue;

			/*Insert IDR frame*/
			AX_VENC_RequestIDR(VeChn,AX_TRUE);

			pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);

			/*start input queue for receiving new data */
			VencTryStartInputQueue(VeChn, gChnInst[VeChn]);

			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		}

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			gModCtx.isVencEnterSleep[i] = AX_FALSE;
		}

		pthread_mutex_lock(&gModCtx.stVencMutex);
		pthread_cond_signal(&gModCtx.stVencCond);
		pthread_mutex_unlock(&gModCtx.stVencMutex);
		break;
	default:
		return 0;
	}

	return 0;
}

static AX_S32 AX_JENC_NotifyEventCallBack(const AX_NOTIFY_EVENT_E event,AX_VOID * pdata)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;
	AX_U8 VeChn;

	VLOG_INFO("event:%d\n",event);

	switch(event)
	{
	case AX_NOTIFY_EVENT_SLEEP:
		AX_SYS_WakeLock(AX_ID_JENC);

		for(VeChn = 0; VeChn < MAX_VENC_NUM; VeChn++){
			pChnInst = gChnInst[VeChn];

			if(pChnInst == NULL)
				continue;

			if ((PT_JPEG != pChnInst->enType) && (PT_MJPEG != pChnInst->enType))
				continue;

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn])
				continue;

			pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);

			/*step1:stop receiving new data */
			VencTryStopInputQueue(VeChn,pChnInst);

			/*step2: try to clear the input queue
			*Pay special attention to the reset operation on the vb reference count
			*/
			VencTryClearInputQueue(VeChn,pChnInst);

			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		}

		gModCtx.isJencEnterSleep = AX_TRUE;
		gModCtx.isJencWaitUnlock = AX_TRUE;
		pthread_mutex_lock(&gModCtx.stJencMutex);
		pthread_cond_signal(&gModCtx.stJencCond);
		pthread_mutex_unlock(&gModCtx.stJencMutex);
		break;
	case AX_NOTIFY_EVENT_WAKEUP:

		for(VeChn = 0; VeChn < MAX_VENC_NUM; VeChn++){
			pChnInst = gChnInst[VeChn];

			if(pChnInst == NULL)
				continue;

			if ((PT_JPEG != pChnInst->enType) && (PT_MJPEG != pChnInst->enType))
				continue;

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn])
				continue;

			pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);

			/*start input queue for receiving new data */
			VencTryStartInputQueue(VeChn, gChnInst[VeChn]);

			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		}

		gModCtx.isJencEnterSleep = AX_FALSE;
		pthread_mutex_lock(&gModCtx.stJencMutex);
		pthread_cond_signal(&gModCtx.stJencCond);
		pthread_mutex_unlock(&gModCtx.stJencMutex);
		break;
	default:
		return 0;
	}

	return 0;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_Init(const AX_VENC_MOD_ATTR_S *pstModAttr)
{
	AX_S32 s32Ret = -1;
	pthread_attr_t thread_attr;
	struct sched_param schedparam = {0};
	AX_S32 i = 0;
	AX_BOOL loopCreate = AX_TRUE;
	VencDebugInit(SYS_LOG_ERROR, SYS_LOG_TARGET_SYSLOG, VENC_DUMP_NONE, VENC_DUMP_NONE_CHN);

	if (NULL == pstModAttr) {
		VLOG_ERROR("VENC Invalid module parameter.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (VENC_MOD_INITED == gModCtx.enModState) {
		VLOG_ERROR("VENC encoder device has already been inited.\n");
		return AX_SUCCESS;
	}

	if (pstModAttr->enVencType & VENC_JPEG_ENCODER) {
		g_fd_jenc = open(JENC_DEVICE_NAME, O_RDWR);
		if (g_fd_jenc == -1) {
			VLOG_ERROR("VENC open %s failed.\n",JENC_DEVICE_NAME);
			return AX_ERR_VENC_SYS_NOTREADY;
		}

		s32Ret = JpegEncodeOnceInit();
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VENC jpeg encode one frame init error. s32Ret = %d\n", s32Ret);
			close(g_fd_jenc);
			g_fd_jenc = -1;
			return AX_ERR_VENC_NOT_INIT;
		}
	}

	AX_VENC_ENCODER_TYPE_E enType = pstModAttr->enVencType;
	if (VENC_VIDEO_ENCODER != enType && VENC_JPEG_ENCODER != enType &&
		VENC_MULTI_ENCODER != enType) {
		VLOG_ERROR("VENC Unsupport payload type =%d.\n", enType);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	/* Set thread priority */
	s32Ret = pthread_attr_init(&thread_attr);
	if(s32Ret) {
		VLOG_ERROR("VENC pthread attr init failed!s32Ret=0x%x\n",s32Ret);
		return AX_ERR_VENC_SET_PRIORITY_FAIL;
	}

	s32Ret = pthread_attr_setinheritsched(&thread_attr, PTHREAD_EXPLICIT_SCHED);
	if(s32Ret) {
		pthread_attr_destroy(&thread_attr);
		VLOG_ERROR("VENC pthread attr setinheritsched failed!s32Ret=0x%x\n",s32Ret);
		return AX_ERR_VENC_SET_PRIORITY_FAIL;
	}

	s32Ret = pthread_attr_setschedpolicy(&thread_attr, SCHED_FIFO);
	if(s32Ret) {
		pthread_attr_destroy(&thread_attr);
		VLOG_ERROR("VENC pthread attr setschedpolicy failed!s32Ret=0x%x\n",s32Ret);
		return AX_ERR_VENC_SET_PRIORITY_FAIL;
	}

	schedparam.sched_priority = 99;
	s32Ret = pthread_attr_setschedparam(&thread_attr, &schedparam);
	if(s32Ret) {
		pthread_attr_destroy(&thread_attr);
		VLOG_ERROR("VENC pthread attr setschedparam failed!s32Ret=0x%x\n",s32Ret);
		return AX_ERR_VENC_SET_PRIORITY_FAIL;
	}

	gModCtx.enModState = VENC_MOD_INITING;

	/* venc init */
	if (enType & VENC_VIDEO_ENCODER) {

		g_fd_venc = open(VENC_DEVICE_NAME, O_RDWR);
		if (g_fd_venc == -1) {
 			pthread_attr_destroy(&thread_attr);
			VLOG_ERROR("VENC open %s failed.\n",VENC_DEVICE_NAME);
			return AX_ERR_VENC_SYS_NOTREADY;
		}

		/* selectpthread_cond_timedwait must use CLOCK_MONOTONIC*/
		if(gModCtx.bEncSelectCondInit == AX_FALSE)
		{
			pthread_condattr_init(&gModCtx.stEncSelectCondAttr);
			pthread_condattr_setclock(&gModCtx.stEncSelectCondAttr, CLOCK_MONOTONIC);
			pthread_cond_init(&gModCtx.stEncSelectCond, &gModCtx.stEncSelectCondAttr);
			gModCtx.bEncSelectCondInit = AX_TRUE;
		}

		for(i = 0; i < MAX_VENC_GRP_NUM; i++)
		{
			if(gModCtx.stVencSelectGrp[i].bEncSelectCondInit == AX_FALSE)
			{
				pthread_condattr_init(&gModCtx.stVencSelectGrp[i].stEncSelectCondAttr);
				pthread_condattr_setclock(&gModCtx.stVencSelectGrp[i].stEncSelectCondAttr, CLOCK_MONOTONIC);
				pthread_cond_init(&gModCtx.stVencSelectGrp[i].stEncSelectCond, &gModCtx.stVencSelectGrp[i].stEncSelectCondAttr);
				gModCtx.stVencSelectGrp[i].bEncSelectCondInit = AX_TRUE;
			}
		}

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			gModCtx.isVencEncodeLoopExit[i] = AX_FALSE;
			gModCtx.isVencEnterSleep[i] = AX_FALSE;
			pthread_mutex_init(&gModCtx.stVencMutex[i], NULL);
			pthread_condattr_init(&gModCtx.stVencCondAttr[i]);
			pthread_condattr_setclock(&gModCtx.stVencCondAttr[i], CLOCK_MONOTONIC);
			pthread_cond_init(&gModCtx.stVencCond[i], &gModCtx.stVencCondAttr[i]);

			gModCtx.encodeThreadIndex[i] = i;
			//create video encoder thread
			pthread_create(&gModCtx.vencTid[i], &thread_attr, VencEncodeLoop, (void *)&gModCtx.encodeThreadIndex[i]);
		}

		VencProcInit(VencProcCatCallback);

		g_venc_chn_count = 0;

		gModCtx.isVencWaitUnlock = AX_FALSE;
		AX_SYS_RegisterEventCb(AX_ID_VENC,AX_VENC_NotifyEventCallBack,NULL);
	}

	if (enType & VENC_JPEG_ENCODER) {


		gModCtx.isJencEncodeLoopExit = AX_FALSE;
		pthread_mutex_init(&gModCtx.stJencMutex, NULL);
		pthread_condattr_init(&gModCtx.stJencCondAttr);
		pthread_condattr_setclock(&gModCtx.stJencCondAttr, CLOCK_MONOTONIC);
		pthread_cond_init(&gModCtx.stJencCond, &gModCtx.stJencCondAttr);

		//create video encoder thread
		pthread_create(&gModCtx.jencTid, &thread_attr, JencEncodeLoop, (void *)&gModCtx);

		JencProcInit();

		gModCtx.isJencWaitUnlock = AX_FALSE;
		gModCtx.isJencEnterSleep = AX_FALSE;
		AX_SYS_RegisterEventCb(AX_ID_JENC,AX_JENC_NotifyEventCallBack,NULL);
	}

	g_fd_devmem = open("/dev/mem", O_RDWR | O_SYNC, S_IRUSR | S_IRUSR);

	pthread_attr_destroy(&thread_attr);

	gModCtx.enModState = VENC_MOD_INITED;
	gModCtx.enType = enType;

	//Wait for the JencEncodeLoop thread or VencEncodeLoop thread to enter the while loop
	if (enType & VENC_VIDEO_ENCODER) {
		while(1) {
			loopCreate = AX_TRUE;
			for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
				loopCreate &= gModCtx.isVencEncodeLoopCreate[i];
			}
			if (loopCreate == AX_TRUE) {
				break;
			}
			usleep(1);
		}
	}
	if (enType & VENC_JPEG_ENCODER) {
		while(1) {
			if (gModCtx.isJencEncodeLoopCreate == AX_TRUE) {
				break;
			}
			usleep(1);
		}
	}

	VLOG_INFO("ENC init success.\n");
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_Deinit()
{
	AX_S32 s32Ret = -1;
	AX_S32 i = 0;

	if (VENC_MOD_INITED != gModCtx.enModState) {
		VLOG_ERROR("VENC encoder device has already been Deinited.\n");
		return AX_SUCCESS;
	}

	if (gModCtx.enType & VENC_JPEG_ENCODER) {
		s32Ret = JpegEncodeOnceDeinit();
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VENC jpeg encode one frame Deinit error.\n");
			return AX_ERR_VENC_NOT_PERMIT;
		}
	}

	for (i = 0; i < MAX_VENC_NUM; i++) {
		if (NULL != gChnInst[i]) {
			VLOG_ERROR("VENC There is still channel(%d) alive.\n", i);
			return AX_ERR_VENC_NOT_PERMIT;
		}
	}

	if (gModCtx.enType & VENC_VIDEO_ENCODER) {

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			pthread_mutex_lock(&gModCtx.stVencMutex[i]);

			gModCtx.isVencEncodeLoopExit[i] = AX_TRUE;
			gModCtx.isVencEncodeLoopCreate[i] = AX_FALSE;
			pthread_cond_signal(&gModCtx.stVencCond[i]);

			pthread_mutex_unlock(&gModCtx.stVencMutex[i]);

			pthread_join(gModCtx.vencTid[i], NULL);
		}

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			pthread_mutex_destroy(&gModCtx.stVencMutex[i]);
			pthread_condattr_destroy(&gModCtx.stVencCondAttr[i]);
			pthread_cond_destroy(&gModCtx.stVencCond[i]);
		}

		VencProcDeinit();

		AX_SYS_UnregisterEventCb(AX_ID_VENC);

		if (g_fd_venc != -1){
			close(g_fd_venc);
			g_fd_venc = -1;
		}

	}

	if (gModCtx.enType & VENC_JPEG_ENCODER) {
		pthread_mutex_lock(&gModCtx.stJencMutex);
		gModCtx.isJencEncodeLoopExit = AX_TRUE;
		gModCtx.isJencEncodeLoopCreate = AX_FALSE;
		pthread_cond_signal(&gModCtx.stJencCond);
		pthread_mutex_unlock(&gModCtx.stJencMutex);

		pthread_join(gModCtx.jencTid, NULL);
		pthread_mutex_destroy(&gModCtx.stJencMutex);
		pthread_condattr_destroy(&gModCtx.stJencCondAttr);
		pthread_cond_destroy(&gModCtx.stJencCond);

		JencProcDeinit();

		AX_SYS_UnregisterEventCb(AX_ID_JENC);

		if (g_fd_jenc != -1){
			close(g_fd_jenc);
			g_fd_jenc = -1;
		}
	}

	if (g_fd_devmem != -1){
		close(g_fd_devmem);
		g_fd_devmem = -1;
	}

	for(int i = 0; i < MAX_VENC_GRP_NUM; i++) {
		if(gModCtx.stVencSelectGrp[i].u32ChanNum) {
			pthread_mutex_lock(&gModCtx.stVencSelectGrp[i].stEncSelectMutex);
			pthread_cond_signal(&gModCtx.stVencSelectGrp[i].stEncSelectCond);
			pthread_mutex_unlock(&gModCtx.stVencSelectGrp[i].stEncSelectMutex);
		}
	}

	pthread_mutex_lock(&gModCtx.stEncSelectMutex);
	gModCtx.enModState = VENC_MOD_UNINIT;
	pthread_cond_signal(&gModCtx.stEncSelectCond);
	pthread_mutex_unlock(&gModCtx.stEncSelectMutex);

	VLOG_INFO("VENC deinit success.\n");

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_CreateChn(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
	VLOG(SYS_LOG_ERROR, "VencChn %d hal. Build at %s %s.\n", VeChn, __DATE__, __TIME__);

	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstAttr);

	AX_S32 s32Ret = -1;
	ringbuffer_initparam_t stRbParam;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	if (VENC_MOD_INITED != gModCtx.enModState) {
		VLOG_ERROR("VencChn %d: Encoder device is not init.\n", VeChn);
		return AX_ERR_VENC_NOT_INIT;
	}

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED != gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: Channel %d exist.\n",
			VeChn, VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_EXIST;
	}
	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);

	s32Ret = VencChnAttrCheck(VeChn, pstAttr);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: chn attr check err.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	pChnInst = (AX_VENC_CHN_INSTANCE_S *)calloc(1, sizeof(AX_VENC_CHN_INSTANCE_S));
	if (NULL == pChnInst) {
		VLOG_ERROR("VencChn %d: calloc instance err.\n", VeChn);
		return AX_ERR_VENC_NOMEM;
	}

    pChnInst->ChnId = VeChn;
	pChnInst->devFd = -1;
	pChnInst->enType = pstAttr->stVencAttr.enType;

	memcpy(&pChnInst->stVencChnAttr, pstAttr, sizeof(AX_VENC_CHN_ATTR_S));

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
		pChnInst->pEncoder = &gVencEncoder;
	} else if ((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
		pChnInst->pEncoder = &gJencEncoder;
	} else {
		VLOG_ERROR("VencChn %d: create encoder handle error.\n", VeChn);
		goto err0;
	}

	s32Ret = VencCreateInputKfifo(VeChn, pChnInst);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: create input kfifo err.\n", VeChn);
		goto err0;
	}

	s32Ret = AX_Fifo_Create(VeChn, VENC_MAX_FIFO_CAPACITY, pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth, &pChnInst->inputQueue);
	if (FIFO_OK != s32Ret) {
		VLOG_ERROR("VencChn %d: create input ufifo err.\n", VeChn);
		goto err1;
	}

	s32Ret = AX_Fifo_Create(VeChn, VENC_MAX_FIFO_CAPACITY, pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth, &pChnInst->outputQueue);
	if (FIFO_OK != s32Ret) {
		VLOG_ERROR("VencChn %d: video encoder output queue create error.\n", VeChn);
		goto err2;
	}

	stRbParam.buffer_size = pstAttr->stVencAttr.u32BufSize;
	if (stRbParam.buffer_size <= 0)
	{
		stRbParam.buffer_size = 2 * (pstAttr->stVencAttr.u32MaxPicWidth) * (pstAttr->stVencAttr.u32MaxPicHeight);
	}
	stRbParam.buffer_size += MARGIN_PADDING_FOR_SMALL_RESOLUTION;

	if(((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) &&
	    (pstAttr->stVencAttr.u32BufSize == pstAttr->stVencAttr.u32PicWidthSrc * pstAttr->stVencAttr.u32PicHeightSrc * 3/8))
	{
		stRbParam.streamBuffMargin = pstAttr->stVencAttr.u32PicWidthSrc * pstAttr->stVencAttr.u32PicHeightSrc * 3/8
					+ MARGIN_PADDING_FOR_SMALL_RESOLUTION;
	}else{
		stRbParam.streamBuffMargin = pstAttr->stVencAttr.u32PicWidthSrc * pstAttr->stVencAttr.u32PicHeightSrc * 3/4
					+ MARGIN_PADDING_FOR_SMALL_RESOLUTION;
	}

	stRbParam.enCodecType = pstAttr->stVencAttr.enType;


	if(pstAttr->stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL) {
		pChnInst->pstRingBuf = NULL;
		VLOG_INFO("VencChn %d: output buffer uses pool memory.\n", VeChn);
	}else{
		pChnInst->pstRingBuf = ringbuffer_create(VeChn, &stRbParam);
		if (NULL == pChnInst->pstRingBuf) {
			VLOG_ERROR("VencChn %d: create ring buffer error.\n", VeChn);
			goto err3;
		}
	}

	s32Ret = pChnInst->pEncoder->pfnCreateChn(VeChn, pstAttr, pChnInst);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: encoder create channel error.\n", VeChn);
		goto err4;
	}

	VencUpdateChnVariables(VeChn, pChnInst);

	/* dump frame/stream data */
	if ((gVencDumpData.enDumpType > VENC_DUMP_NONE) && (gVencDumpData.enDumpType <= VENC_DUMP_ALL)) {
		s32Ret = VencDumpDataBegin(VeChn, pChnInst);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: Begin dump data error.\n", VeChn);
			goto err4;
		}
	}

	gChnInst[VeChn] = pChnInst;

	gChnInst[VeChn]->enStateMachine = VENC_STATE_MACHINE_NORMAL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	gModCtx.enChnState[VeChn] = VENC_CHN_STATE_CREATED;
	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);

	gModCtx.enChnCodecType[VeChn] = pstAttr->stVencAttr.enType;

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
		VENC_CHN_COUNT_MUTEX_LOCK(g_venc_chn_count_mutex_lock);
		gModCtx.VencChnLoopIndex[VeChn] = g_venc_chn_count % AX_VENC_LOOP_THREAD_NUM;
		g_venc_chn_count++;
		VENC_CHN_COUNT_MUTEX_UNLOCK(g_venc_chn_count_mutex_lock);
	}

	VLOG_INFO("VencChn %d: create encoder channel success.\n", VeChn);
	return AX_SUCCESS;

err4:
	if(pstAttr->stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
		ringbuffer_close(VeChn, pChnInst->pstRingBuf);
	}

err3:
	AX_Fifo_Destroy(VeChn, pChnInst->outputQueue);

err2:
	AX_Fifo_Destroy(VeChn, pChnInst->inputQueue);

err1:
	VencDestroyInputKfifo(VeChn, pChnInst);

err0:
	free(pChnInst);
	pChnInst = NULL;
    gChnInst[VeChn] = NULL;

	VLOG_ERROR("VencChn %d: create encoder channel failed.\n", VeChn);
	return AX_ERR_VENC_CREATE_CHAN_ERR;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_DestroyChn(VENC_CHN VeChn)
{
	VENC_CHN_RANGE_CHECK(VeChn);

	AX_S32 s32Ret = -1;
	AX_S32 s32RetLock = -1;
	VENC_GRP grpId = -1;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_STOPPED != gModCtx.enChnState[VeChn] &&
		VENC_CHN_STATE_CREATED != gModCtx.enChnState[VeChn]) {
			VLOG_ERROR("VencChn %d: Change Channel state from (%s) to (DESTROYING) is not allowd.\n",
				VeChn,
				gVencChnState[gModCtx.enChnState[VeChn]]);

		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	AX_VENC_CHN_INSTANCE_S *pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}
	gModCtx.enChnState[VeChn] = VENC_CHN_STATE_DESTROYING;

	VLOG_DEBUG("VencChn %d: try wakeup output queue +++.\n", VeChn);
	VencTryWakeupOutputQueueReader(VeChn, pChnInst);
	VLOG_DEBUG("VencChn %d: try wakeup output queue ---.\n", VeChn);

	VencTryWakeupInputQueueReader(VeChn, pChnInst);

	VLOG_DEBUG("VencChn %d: destroy get lock +++.\n", VeChn);

	pthread_mutex_lock(&gstDstryGetMutex[VeChn]);

	VLOG_DEBUG("VencChn %d: destroy get lock ---.\n", VeChn);

	pthread_mutex_lock(&gstDstrySendMutex[VeChn]);

	VLOG_DEBUG("VencChn %d: destroy send lock ---.\n", VeChn);

	s32Ret = pChnInst->pEncoder->pfnDestroyChn(pChnInst);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: destroy channel error(%d).\n", VeChn, s32Ret);
		s32RetLock = pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		if (s32RetLock)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);
		s32RetLock = pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		if (s32RetLock)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);
		s32RetLock = pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		if (s32RetLock)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);
		return s32Ret;
	}

	if(pChnInst->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
		ringbuffer_close(VeChn, pChnInst->pstRingBuf);
	}

	AX_Fifo_Destroy(VeChn, pChnInst->inputQueue);

	VencDestroyInputKfifo(VeChn, pChnInst);

	/*try to clear the output queue*/
	VencTryClearOutputQueue(VeChn, pChnInst);

	AX_Fifo_Destroy(VeChn, pChnInst->outputQueue);

	if (pChnInst->pstUserDataBufferQueue)
		DestroyUserDataBufferQueue(VeChn, pChnInst->pstUserDataBufferQueue);

	if ((gVencDumpData.enDumpType > VENC_DUMP_NONE) && (gVencDumpData.enDumpType <= VENC_DUMP_ALL))
		VencDumpDataEnd(VeChn, pChnInst);

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
		VENC_CHN_COUNT_MUTEX_LOCK(g_venc_chn_count_mutex_lock);
		g_venc_chn_count--;
		VENC_CHN_COUNT_MUTEX_UNLOCK(g_venc_chn_count_mutex_lock);
	}

	free(pChnInst);
	pChnInst = NULL;
	gChnInst[VeChn] = NULL;

	gModCtx.enChnState[VeChn] = VENC_CHN_STATE_DESTROYED;

	s32RetLock = pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
	if (s32RetLock)
		VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);
	s32RetLock = pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
	if (s32RetLock)
		VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);
	s32RetLock = pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	if (s32RetLock)
		VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32RetLock);

	VLOG_INFO("VencChn %d: Destroy channel success.\n", VeChn);

	/* destroy chan trigger grp signal when chan is in grp */
	grpId = gModCtx.vencGrpId[VeChn];
	if((MAX_VENC_GRP_NUM > grpId) && (grpId >= 0)) {
		pthread_mutex_lock(&gModCtx.stVencSelectGrp[grpId].stEncSelectMutex);
		pthread_cond_signal(&gModCtx.stVencSelectGrp[grpId].stEncSelectCond);
		pthread_mutex_unlock(&gModCtx.stVencSelectGrp[grpId].stEncSelectMutex);
	}

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SendFrame(VENC_CHN VeChn, const AX_VIDEO_FRAME_INFO_S *pstFrame , AX_S32 s32MilliSec)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstFrame);

	if (s32MilliSec < -1) {
		VLOG_ERROR("VencChn %d: sendFrame Invalid s32MilliSec value(%d).\n", VeChn, s32MilliSec);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;
	AX_VIDEO_FRAME_INFO_S stFrame;
	AX_S32 modId = -1;
	AX_U32 u32BlkId[3]={0};//must set 0 default
	AX_VOID *pDumpVirAddr;

	pthread_mutex_lock(&gstDstrySendMutex[VeChn]);

	if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: sendFrame stop recv frame. CurrState:%d\n", VeChn, gModCtx.enChnState[VeChn]);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}
	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		s32Ret = pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32Ret);
		return AX_ERR_VENC_UNEXIST;
	}

	stFrame = *pstFrame;

	//link mode not use this API
	if (AX_LINK_MODE == pChnInst->stVencChnAttr.stVencAttr.enLinkMode) {
		VLOG_ERROR("VencChn %d: sendFrame, link mode not support this API!\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	if (pChnInst->bSendFrmAbort) {
		VLOG_ERROR("VencChn %d: sendFrame, get abort signal, stop sending frame.\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	s32Ret = VencSendFrameChnAttrCheck(VeChn, pstFrame, pChnInst);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: sendFrame, Invalid input frame info.\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_MATCH;
	}

	s32Ret = VencSendFrameCropAttrCheck(VeChn, pstFrame, pChnInst);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: sendFrame, Invalid input frame info.\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ((VENC_DUMP_FRAME & gVencDumpData.enDumpType) && pChnInst->fDumpFrame) {

		if(stFrame.stVFrame.u64VirAddr[0]){
			fwrite((void *)((AX_U32)stFrame.stVFrame.u64VirAddr[0]),1,pChnInst->s32FrameSize,pChnInst->fDumpFrame);
		}else{
			pDumpVirAddr = AX_SYS_Mmap(stFrame.stVFrame.u64PhyAddr[0],pChnInst->s32FrameSize);
			if(pDumpVirAddr){

				fwrite(pDumpVirAddr,1,pChnInst->s32FrameSize,pChnInst->fDumpFrame);

				s32Ret = AX_SYS_Munmap(pDumpVirAddr,pChnInst->s32FrameSize);

				if(s32Ret){
					VLOG_WARNING("VencChn %d:AX_SYS_Munmap failed,s32Ret=0x%x\n",VeChn,s32Ret);
				}
			}else{
				VLOG_WARNING("VencChn %d: failed to dump frame data.\n", VeChn);
			}
		}
	}

	if (pChnInst->s32FrameIndex < 0) {
		pChnInst->s32FrameIndex = 0;
	}

	/*get BlkId from struct AX_VIDEO_FRAME_S*/
	for(int i = 0; i < 3; i++)
	{
		u32BlkId[i] = stFrame.stVFrame.u32BlkId[i];
	}

    if (0 == stFrame.stVFrame.u64PhyAddr[0]) {
        VLOG_ERROR("VencChn %d: sendFrame invalid phyAddr[0].\n", VeChn);
        pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	//TODO: use something like osal_memcpy instead of memcpy/alloc/free...
	for (int i = 0; i < 3; i++) {
		if (stFrame.stVFrame.u64PhyAddr[i]) {
			stFrame.stVFrame.u64PhyAddr[i] -= VENC_ADDR_OFFSET;
		}
	}

	pChnInst->stFrameInfo.inputFrameType = FRAME_NORMAL_TYPE;
	memcpy(&pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo, &stFrame, sizeof(AX_VIDEO_FRAME_INFO_S));
	VLOG_DEBUG("VencChn %d: sendFrame fifo push +++, u32FrameSize=%d phyAddr0=%llx, virAddr0=%llx \n",
				VeChn,
                pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u32FrameSize,
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[0],
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[0]);
	VLOG_DEBUG("VencChn %d: phyAddr1=%llx, virAddr1=%llx, phyAddr2=%llx, virAddr2=%llx, blkId=%ld, pts=%lld, seq=%lld, userdata %lld\n",
				VeChn,
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[1],
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[1],
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[2],
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[2],
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.u32PoolId,
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PTS,
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64SeqNum,
				pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64UserData);

	if (s32MilliSec > 0)
	{
		s32Ret = VencSendFifoTimeout(VeChn, pChnInst->inputQueue, s32MilliSec);
		if (AX_SUCCESS != s32Ret)
		{
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return s32Ret;
		}
	}

	if(u32BlkId[0] > 0) {
		if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
			modId = AX_ID_VENC;
		}else if((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
			modId = AX_ID_JENC;
		}

		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[0], modId);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrame, Pool IncreaseRefCnt block_0(0x%x) err(0x%x).\n", VeChn, u32BlkId[0], s32Ret);
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}
	if (u32BlkId[1] > 0)
	{
		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[1], modId);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrame, Pool IncreaseRefCnt block_1(0x%x) err(0x%x).\n", VeChn, u32BlkId[1], s32Ret);
			if (u32BlkId[0] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[0], modId);
			}
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}
	if (u32BlkId[2] > 0)
	{
		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[2], modId);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrame, Pool IncreaseRefCnt block_2(0x%x) err(0x%x).\n", VeChn, u32BlkId[2], s32Ret);
			if (u32BlkId[0] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[0], modId);
			}
			if (u32BlkId[1] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[1], modId);
			}

			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}
	s32Ret = AX_Fifo_Push(VeChn, pChnInst->inputQueue, pChnInst->stFrameInfo, s32MilliSec);
	if ((FIFO_FULL == s32Ret) && (AX_TRUE != pChnInst->bSendFrmAbort)) {
		VLOG_DEBUG("VencChn %d: sendFrame fifo push full...\n", VeChn);

		for(int i = 0; i < 3; i++)
		{
			if(u32BlkId[i] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], modId);
			}
		}

		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_QUEUE_FULL;
	} else if ((FIFO_FULL == s32Ret) && (AX_TRUE == pChnInst->bSendFrmAbort)) {
		VLOG_ERROR("VencChn %d: sendFrame, fifo push abort...\n", VeChn);

		for(int i = 0; i < 3; i++)
		{
			if(u32BlkId[i] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], modId);
			}
		}

		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_FLOW_END;
	}
	pChnInst->s32FrameIndex++;
	pChnInst->u64TotalRecvFrameNum++;

	VencSendFrameToDebugFifo(VeChn,stFrame.stVFrame.u32BlkId[0],pChnInst->devFd);

	pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SendFrameEx(VENC_CHN VeChn, const AX_USER_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstFrame);

	if (s32MilliSec < -1) {
		VLOG_ERROR("VencChn %d: Invalid s32MilliSec value(%d).\n", VeChn, s32MilliSec);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_S32 s32Ret = -1;
	AX_USER_FRAME_INFO_S stFrame = *pstFrame;
	AX_U32 u32BlkId[3]={0};//must set 0 default

	pthread_mutex_lock(&gstDstrySendMutex[VeChn]);

	if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn]) {
		VLOG_DEBUG("VencChn %d: stop recv frame. Current State:%d\n", VeChn, gModCtx.enChnState[VeChn]);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	AX_VENC_CHN_INSTANCE_S *pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		s32Ret = pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32Ret);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: sendFrameEx, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	if (AX_LINK_MODE == pChnInst->stVencChnAttr.stVencAttr.enLinkMode)
	{
		VLOG_ERROR("VencChn %d: sendFrameEx, link mode not support this API!\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	if (pChnInst->bSendFrmAbort)
	{
		VLOG_ERROR("VencChn %d: sendFrameEx, get abort signal, stop sending frame.\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	s32Ret = VencSendFrameChnAttrCheck(VeChn, &pstFrame->stUserFrame, pChnInst);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: sendFrameEx, Invalid input frame info.\n", VeChn);
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_NOT_MATCH;
	}

	if (pChnInst->s32FrameIndex < 0) {
		pChnInst->s32FrameIndex = 0;
	}

	/*get BlkId from struct AX_VIDEO_FRAME_S*/
	for(int i = 0; i < 3; i++)
	{
		u32BlkId[i] = stFrame.stUserFrame.stVFrame.u32BlkId[i];
	}

	if (0 == stFrame.stUserFrame.stVFrame.u64PhyAddr[0])
	{
        VLOG_ERROR("VencChn %d: sendFrameEx invalid phyAddr[0].\n", VeChn);
        pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	for (int i = 0; i < 3; i++)
	{
		if (stFrame.stUserFrame.stVFrame.u64PhyAddr[i])
		{
			stFrame.stUserFrame.stVFrame.u64PhyAddr[i] -= VENC_ADDR_OFFSET;
		}
	}
	if (stFrame.stUserRcInfo.u64QpMapPhyAddr)
	{
		stFrame.stUserRcInfo.u64QpMapPhyAddr -= VENC_ADDR_OFFSET;
	}

	pChnInst->stFrameInfo.inputFrameType = FRAME_USER_TYPE;
	memcpy(&pChnInst->stFrameInfo.inputUserFrameInfo.stUserFrameInfo, &stFrame, sizeof(AX_USER_FRAME_INFO_S));

	if (s32MilliSec > 0)
	{
		s32Ret = VencSendFifoTimeout(VeChn, pChnInst->inputQueue, s32MilliSec);
		if (AX_SUCCESS != s32Ret)
		{
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return s32Ret;
		}
	}

	if(u32BlkId[0] > 0) {
		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[0], AX_ID_VENC);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrameEx, Pool IncreaseRefCnt block_0(0x%x) err(0x%x).\n", VeChn, u32BlkId[0], s32Ret);
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	if(u32BlkId[1] > 0) {
		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[1], AX_ID_VENC);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrameEx, Pool IncreaseRefCnt block_1(0x%x) err(0x%x).\n", VeChn, u32BlkId[1], s32Ret);
			if (u32BlkId[0] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[0], AX_ID_VENC);
			}
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	if(u32BlkId[2] > 0) {
		s32Ret = AX_POOL_IncreaseRefCnt_Inter(u32BlkId[2], AX_ID_VENC);
		if (AX_SUCCESS != s32Ret) {
			VLOG_ERROR("VencChn %d: sendFrameEx, Pool IncreaseRefCnt block_2(0x%x) err(0x%x).\n", VeChn, u32BlkId[2], s32Ret);
			if (u32BlkId[0] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[0], AX_ID_VENC);
			}
			if (u32BlkId[1] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[1], AX_ID_VENC);
			}
			pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	s32Ret = AX_Fifo_Push(VeChn, pChnInst->inputQueue, pChnInst->stFrameInfo, s32MilliSec);
	if ((FIFO_FULL == s32Ret) && (AX_TRUE != pChnInst->bSendFrmAbort)) {
		VLOG_DEBUG("VencChn %d: sendFrameEx fifo push full...\n", VeChn);

		for(int i = 0; i < 3; i++)
		{
			if(u32BlkId[i] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], AX_ID_VENC);
			}
		}

		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_QUEUE_FULL;
	} else if ((FIFO_FULL == s32Ret) && (AX_TRUE == pChnInst->bSendFrmAbort)) {
		VLOG_ERROR("VencChn %d: sendFrameEx, fifo push abort...\n", VeChn);

		for(int i = 0; i < 3; i++)
		{
			if(u32BlkId[i] > 0) {
				AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], AX_ID_VENC);
			}
		}
		pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);
		return AX_ERR_VENC_FLOW_END;
	}
	pChnInst->s32FrameIndex++;
	pChnInst->u64TotalRecvFrameNum++;

	VencSendFrameToDebugFifo(VeChn,stFrame.stUserFrame.stVFrame.u32BlkId[0],pChnInst->devFd);

	pthread_mutex_unlock(&gstDstrySendMutex[VeChn]);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectChn(AX_CHN_STREAM_STATUS_S *pstChnStrmState, AX_S32 s32MilliSec)
{
	if (NULL == pstChnStrmState) {
		VLOG_ERROR("VENC: NULL pointer.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (s32MilliSec < -1) {
		VLOG_ERROR("VENC: Invalid s32MilliSec(%d).\n", s32MilliSec);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_BOOL bStrmExist = AX_FALSE;
	AX_S32	s32Ret = -1;
	struct timespec tv;

	if (-1 == s32MilliSec) {
		VLOG_DEBUG("VENC: SelectChn, cond wait+++.\n");
		pthread_mutex_lock(&gModCtx.stEncSelectMutex);
		while (1) {
			if (VENC_MOD_INITED != gModCtx.enModState) {
				pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
				return AX_ERR_VENC_NOT_INIT;
			}

			bStrmExist = VencIsAnyChnStrmExist(pstChnStrmState);
			if (bStrmExist)
				break;

			pthread_cond_wait(&gModCtx.stEncSelectCond, &gModCtx.stEncSelectMutex);
		}
		pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
		VLOG_DEBUG("VENC: SelectChn, cond wait---.\n");
	} else if (0 == s32MilliSec) {
		bStrmExist = VencIsAnyChnStrmExist(pstChnStrmState);
		if (!bStrmExist) {
			VLOG_DEBUG("VENC: selectChn, all channel output queue are empty...\n");
			return AX_ERR_VENC_QUEUE_EMPTY;
		}
	} else if (s32MilliSec > 0) {
		clock_gettime(CLOCK_MONOTONIC, &tv);
		tv.tv_sec += s32MilliSec / 1000;
		tv.tv_nsec += (s32MilliSec % 1000) * 1000 * 1000;
		if (tv.tv_nsec >= (1000*1000*1000)) {
			tv.tv_nsec -= (1000*1000*1000);
			tv.tv_sec += 1;
		}

		pthread_mutex_lock(&gModCtx.stEncSelectMutex);
		while (1) {
			if (VENC_MOD_INITED != gModCtx.enModState) {
				pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
				return AX_ERR_VENC_NOT_INIT;
			}

			bStrmExist = VencIsAnyChnStrmExist(pstChnStrmState);
			if (bStrmExist)
				break;

			s32Ret = pthread_cond_timedwait(&gModCtx.stEncSelectCond, &gModCtx.stEncSelectMutex, &tv);
			if (0 != s32Ret) { //not receive signal in s32MilliSec time, timeout.
				pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
				return AX_ERR_VENC_QUEUE_EMPTY;
			}
		}
		pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
	}

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectSetGrp(VENC_GRP grpId, AX_VENC_SELECT_GRP_PARAM_S *pstGrpInfo)
{
	VENC_GRP_RANGE_CHECK(grpId);

	if(NULL == pstGrpInfo) {
		VLOG_ERROR("VENC: NULL pointer.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if((MAX_VENC_NUM < pstGrpInfo->u32TotalChnNum) || (0 == pstGrpInfo->u32TotalChnNum)) {
		VLOG_ERROR("VENC: grp %d u32TotalChnNum %d err.\n", grpId, pstGrpInfo->u32TotalChnNum);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_U32 i = 0;
	AX_U32 j = 0;
	AX_U32 u32VencChan = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	/* if grp is created */
	if(pstVencSelectGrp->u32ChanNum) {
		VLOG_ERROR("VENC: grp %d chan num %d, already init\n", grpId, pstVencSelectGrp->u32ChanNum);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	for(i = 0; i < pstGrpInfo->u32TotalChnNum; i++) {
		u32VencChan = pstGrpInfo->u32ChnIndex[i];

		/* u32VencChan must valid */
		VENC_CHN_RANGE_CHECK(u32VencChan);

		/* check if same venc chan in grp */
		for(j = i + 1; j < pstGrpInfo->u32TotalChnNum; j++) {
			if(pstGrpInfo->u32ChnIndex[j] == u32VencChan) {
				VLOG_ERROR("VENC:same venc chan %d in grp\n", u32VencChan);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}

		/* check if venc chan already in grp */
		for(j = 0; j < MAX_VENC_GRP_NUM; j++) {
			if(VencChnIsInGrp(j, u32VencChan)) {
				VLOG_ERROR("VENC:venc chan %d already in grp %d\n", u32VencChan, j);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
	}

	pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
	/* 1.add chan map */
	for(i = 0; i < pstGrpInfo->u32TotalChnNum; i++) {
		u32VencChan = pstGrpInfo->u32ChnIndex[i];
		gModCtx.vencGrpId[u32VencChan] = grpId;
		pstVencSelectGrp->u32VencChan[i] = u32VencChan;
	}

	/* 2.set grp num */
	pstVencSelectGrp->u32ChanNum = pstGrpInfo->u32TotalChnNum;
	pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectClearGrp(VENC_GRP grpId)
{
	VENC_GRP_RANGE_CHECK(grpId);

	AX_U32 i = 0;
	AX_U32 u32VencChan = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
	/* 1.rm chan map */
	for(i = 0; i < pstVencSelectGrp->u32ChanNum; i++) {
		u32VencChan = pstVencSelectGrp->u32VencChan[i];
		gModCtx.vencGrpId[u32VencChan] = -1;
		/* the value of u32VencChan is not important, when u32ChanNum is zero */
		pstVencSelectGrp->u32VencChan[i] = 0;
	}

	/* 2.clear grp */
	pstVencSelectGrp->u32ChanNum = 0;
	pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectGrpAddChn(VENC_GRP grpId, VENC_CHN veChn)
{
	VENC_GRP_RANGE_CHECK(grpId);
	VENC_CHN_RANGE_CHECK(veChn);

	/* check if venc chan already in grp */
	for(int j = 0; j < MAX_VENC_GRP_NUM; j++) {
		if(VencChnIsInGrp(j, veChn)) {
			VLOG_ERROR("VENC:venc chan %d already in grp %d\n", veChn, j);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	AX_U32 idx = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
	idx = pstVencSelectGrp->u32ChanNum;
	if(MAX_VENC_NUM <= idx) {
		VLOG_ERROR("VENC: venc chn num overflow.\n");
		pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	pstVencSelectGrp->u32VencChan[idx] = veChn;
	pstVencSelectGrp->u32ChanNum++;
	gModCtx.vencGrpId[veChn] = grpId;
	pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectGrpDeleteChn(VENC_GRP grpId, VENC_CHN veChn)
{
	VENC_GRP_RANGE_CHECK(grpId);

	/* no matter if MAX_VENC_NUM <= veChn */
	if(AX_FALSE == VencChnIsInGrp(grpId, veChn)) {
		VLOG_ERROR("VENC:venc chan %d not in grp %d\n", veChn, grpId);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_U32 i = 0;
	AX_U32 j = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
	for(i = 0; i < pstVencSelectGrp->u32ChanNum; i++) {
		if(veChn == pstVencSelectGrp->u32VencChan[i]) {
			gModCtx.vencGrpId[veChn] = -1;
			for(j = i; j < pstVencSelectGrp->u32ChanNum - 1; j++)
				pstVencSelectGrp->u32VencChan[j] = pstVencSelectGrp->u32VencChan[j + 1];
			/* clear last chan id */
			pstVencSelectGrp->u32VencChan[pstVencSelectGrp->u32ChanNum - 1] = 0;
			pstVencSelectGrp->u32ChanNum--;
			break;
		}
	}
	pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectGrpQuery(VENC_GRP grpId, AX_VENC_SELECT_GRP_PARAM_S *pstGrpInfo)
{
	VENC_GRP_RANGE_CHECK(grpId);

	if(NULL == pstGrpInfo) {
		VLOG_ERROR("VENC: null ptr.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	AX_U32 i = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
	pstGrpInfo->u32TotalChnNum = pstVencSelectGrp->u32ChanNum;
	for(i = 0; i < pstVencSelectGrp->u32ChanNum; i++)
		pstGrpInfo->u32ChnIndex[i] = pstVencSelectGrp->u32VencChan[i];
	pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SelectGrp(VENC_GRP grpId, AX_CHN_STREAM_STATUS_S *pstChnStrmState, AX_S32 s32MilliSec)
{
	VENC_GRP_RANGE_CHECK(grpId);

	if (NULL == pstChnStrmState) {
		VLOG_ERROR("VENC: NULL pointer.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (s32MilliSec < -1) {
		VLOG_ERROR("VENC: Invalid s32MilliSec(%d).\n", s32MilliSec);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (VENC_MOD_INITED != gModCtx.enModState) {
		VLOG_ERROR("VENC: not init.\n");
		return AX_ERR_VENC_NOT_INIT;
	}

	AX_BOOL bStrmExist = AX_FALSE;
	AX_S32 s32Ret = -1;
	AX_U32 u32ValidChanNum = 0;
	struct timespec tv;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	if (-1 == s32MilliSec) {
		VLOG_DEBUG("VENC: SelectChn, cond wait+++.\n");
		pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
		while (1) {
			u32ValidChanNum = 0;
			bStrmExist = VencIsGrpChnStrmExist(grpId, pstChnStrmState, &u32ValidChanNum);
			if (bStrmExist)
				break;

			/* no valid venc chan in grp, grp not init or venc chan destroyed */
			if(0 == u32ValidChanNum) {
				VLOG_ERROR("VENC:no valid chan in grp %d\n", grpId);
				pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);
				return AX_ERR_VENC_QUEUE_EMPTY;
			}

			pthread_cond_wait(&pstVencSelectGrp->stEncSelectCond, &pstVencSelectGrp->stEncSelectMutex);
		}
		pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);
		VLOG_DEBUG("VENC: SelectChn, cond wait---.\n");
	} else if (0 == s32MilliSec) {
		bStrmExist = VencIsGrpChnStrmExist(grpId, pstChnStrmState, NULL);
		if (!bStrmExist) {
			VLOG_DEBUG("VENC: selectChn, all channel output queue are empty...\n");
			return AX_ERR_VENC_QUEUE_EMPTY;
		}
	} else if (s32MilliSec > 0) {
		clock_gettime(CLOCK_MONOTONIC, &tv);

		tv.tv_sec += s32MilliSec / 1000;
		tv.tv_nsec += (s32MilliSec % 1000) * 1000 * 1000;
		if (tv.tv_nsec >= (1000*1000*1000)) {
			tv.tv_nsec -= (1000*1000*1000);
			tv.tv_sec += 1;
		}

		pthread_mutex_lock(&pstVencSelectGrp->stEncSelectMutex);
		while (1) {
			u32ValidChanNum = 0;
			bStrmExist = VencIsGrpChnStrmExist(grpId, pstChnStrmState, &u32ValidChanNum);
			if (bStrmExist)
				break;

			/* no valid venc chan in grp, grp not init or venc chan destroyed */
			if(0 == u32ValidChanNum) {
				VLOG_ERROR("no valid chan in grp %d\n", grpId);
				pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);
				return AX_ERR_VENC_QUEUE_EMPTY;
			}

			s32Ret = pthread_cond_timedwait(&pstVencSelectGrp->stEncSelectCond, &pstVencSelectGrp->stEncSelectMutex, &tv);
			if (0 != s32Ret) { /* not receive signal in s32MilliSec time, timeout. */
				pthread_mutex_unlock(&pstVencSelectGrp->stEncSelectMutex);

				return AX_ERR_VENC_QUEUE_EMPTY;
			}
		}
		pthread_mutex_unlock(&gModCtx.stEncSelectMutex);
	}

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetStream(VENC_CHN VeChn, AX_VENC_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstStream);

	if (s32MilliSec < -1) {
		VLOG_ERROR("VencChn %d: getStream, Invalid s32MilliSec(%d).\n", VeChn, s32MilliSec);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	FifoRet fifoRet;
	AX_ENCODR_METADATA_INFO_S stPacketInfo;
	AX_VENC_CHN_INSTANCE_S *pChnInst;
	AX_S32 s32Ret = -1;
	AX_VOID* pVirAddrCached;

	pthread_mutex_lock(&gstDstryGetMutex[VeChn]);

	if (VENC_CHN_STATE_DESTROYING == gModCtx.enChnState[VeChn]) {
		//VLOG_DEBUG("VencChn %d: getStream, Channel is destroying...\n", VeChn);
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		//VLOG_DEBUG("VencChn %d: getStream, Channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		s32Ret = pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32Ret);
		return AX_ERR_VENC_UNEXIST;
	}

	if (pChnInst->bGetStrmAbort) {
		VLOG_ERROR("VencChn %d: getStream, got abort signal, stop getting stream.\n", VeChn);
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	fifoRet = AX_Fifo_Pop(VeChn, pChnInst->outputQueue, &stPacketInfo, s32MilliSec);
	if ((FIFO_EMPTY == fifoRet) && (AX_TRUE != pChnInst->bGetStrmAbort)) {
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_QUEUE_EMPTY;
	} else if ((FIFO_EMPTY == fifoRet) && (AX_TRUE == pChnInst->bGetStrmAbort)) {
		VLOG_DEBUG("VencChn %d: getStream, fifo pop abort...\n", VeChn);
		pChnInst->bGetStrmAbort = AX_FALSE;
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_FLOW_END;
	}

	if (stPacketInfo.outputStreamInfo.stPackage.u32Len <= 0) {
		VLOG_ERROR("VencChn %d: getStream, Invalid packet size(%u).\n",
			VeChn, stPacketInfo.outputStreamInfo.stPackage.u32Len);

		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	/* should recalculate phyaddr by adding VENC_ADDR_OFFSET */
	stPacketInfo.outputStreamInfo.stPackage.ulPhyAddr += VENC_ADDR_OFFSET;

	memcpy(&pstStream->stPack, &stPacketInfo.outputStreamInfo.stPackage, sizeof(AX_VENC_PACK_S));

	if ((VENC_DUMP_STREAM & gVencDumpData.enDumpType) && pChnInst->fDumpStream) {
		fwrite(pstStream->stPack.pu8Addr,
			1,
			pstStream->stPack.u32Len,
			pChnInst->fDumpStream);
	}

	//mmap ringbuffer to cached type,shall do unmap in ReleaseStream
	if(pChnInst->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
		pVirAddrCached = AX_SYS_MmapCache(pstStream->stPack.ulPhyAddr,pstStream->stPack.u32Len);
		if (NULL == pVirAddrCached){
			VLOG_WARNING("VencChn %d: AX_SYS_MmapCache(phyaddr:%llx,size:%d) failed,use ringbuffer non-cached virtual address.\n",
				VeChn, pstStream->stPack.ulPhyAddr, pstStream->stPack.u32Len);
		}else{
			pstStream->stPack.pu8Addr = pVirAddrCached;

			s32Ret = AX_SYS_MinvalidateCache(pstStream->stPack.ulPhyAddr,pstStream->stPack.pu8Addr,pstStream->stPack.u32Len);
			if (s32Ret){
				VLOG_ERROR("VencChn %d: AX_SYS_MinvalidateCache(phyaddr:%llx,viraddr:%p,size:%d) ret=0x%x.\n",
					VeChn, pstStream->stPack.ulPhyAddr, pstStream->stPack.pu8Addr,pstStream->stPack.u32Len,s32Ret);
			}
		}
	}

	pChnInst->u64TotalGetStrmNum++;
	pChnInst->u64LeftStreamBytes -= stPacketInfo.outputStreamInfo.stPackage.u32Len;

	pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);

	VLOG_DEBUG("VencChn %d: getStream, phyAddr=%llx, virAddr=%p, len=%u.\n",
			VeChn,
			pstStream->stPack.ulPhyAddr,
			pstStream->stPack.pu8Addr,
			pstStream->stPack.u32Len);

	return AX_SUCCESS;
}

//TODO: support release buffer in disorder
AX_VENC_PUBLIC AX_S32 AX_VENC_ReleaseStream(VENC_CHN VeChn, const AX_VENC_STREAM_S *pstStream)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstStream);

	AX_S32 s32Ret = -1;
	AX_S32 modId = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;
	AX_BLK u32BlkId;
	AX_S32 CacheType = 0;
	AX_U64 PhyAddr;

	pthread_mutex_lock(&gstDstryGetMutex[VeChn]);

	if (VENC_CHN_STATE_DESTROYING == gModCtx.enChnState[VeChn]) {
		VLOG_DEBUG("VencChn %d: releaseStream, Channel is destroying...\n", VeChn);
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_DEBUG("VencChn %d: releaseStream, Channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		s32Ret = pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", VeChn, s32Ret);
		return AX_ERR_VENC_UNEXIST;
	}

	if(pChnInst->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){

		u32BlkId = AX_POOL_PhysAddr2Handle(pstStream->stPack.ulPhyAddr);

		if(u32BlkId == AX_INVALID_BLOCKID){
			VLOG_ERROR("VencChn %d: releaseStream, AX_POOL_PhysAddr2Handle err.\n", VeChn);
			pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
			return AX_ERR_VENC_UNKNOWN;
		}

		if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
			modId = AX_ID_VENC;
		}else if((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
			modId = AX_ID_JENC;
		}

		s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,modId);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: releaseStream, AX_POOL_ReleaseBlock_Inter err(0x%x).\n", VeChn, s32Ret);
			pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
			return AX_ERR_VENC_UNKNOWN;
		}
	}else{

		//if virtual address is cached,shall do unmap
		s32Ret = AX_SYS_MemGetBlockInfoByVirt(pstStream->stPack.pu8Addr, &PhyAddr, &CacheType);
		if(CacheType == AX_MEM_CACHED){
			s32Ret = AX_SYS_Munmap(pstStream->stPack.pu8Addr,pstStream->stPack.u32Len);
			if (s32Ret){
				VLOG_ERROR("VencChn %d: AX_SYS_Munmap(viraddr:%p size:%d) faild,ret=0x%x.\n",
					VeChn, pstStream->stPack.pu8Addr, pstStream->stPack.u32Len, s32Ret);
			}
		}

		s32Ret = ringbuffer_read_finalize(VeChn, pChnInst->pstRingBuf, pstStream->stPack.u32Len);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: releaseStream, read finalize err(%d).\n", VeChn, s32Ret);
			pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);
			return AX_ERR_VENC_UNKNOWN;
		}
	}

	VLOG_DEBUG("VencChn %d: ReleaseStream, phyAddr=%llx, virAddr=%p, len=%u.\n",
			VeChn,
			pstStream->stPack.ulPhyAddr,
			pstStream->stPack.pu8Addr,
			pstStream->stPack.u32Len);

	pChnInst->u64TotalReleaseStrmNum++;

	pthread_mutex_unlock(&gstDstryGetMutex[VeChn]);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetStreamBufInfo(VENC_CHN VeChn, AX_VENC_STREAM_BUF_INFO_T * pstStreamBufInfo)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstStreamBufInfo);

    pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);

    if (NULL == gChnInst[VeChn]) {
        VLOG_ERROR("VencChn %d: Channel not exist.\n", VeChn);
        pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
        return AX_ERR_VENC_UNEXIST;
    }

    AX_VENC_CHN_INSTANCE_S *pChnInst = gChnInst[VeChn];

    if (pChnInst->pstRingBuf != NULL) {
        pstStreamBufInfo->u64PhyAddr = pChnInst->pstRingBuf->phyaddr_for_read;
        pstStreamBufInfo->pUserAddr = pChnInst->pstRingBuf->viraddr_for_read;

        AX_U32 bufferUsableSize = ringbuffer_usable_size(VeChn, pChnInst->pstRingBuf);
        pstStreamBufInfo->u32BufSize = bufferUsableSize;
    } else {
        VLOG_ERROR("VencChn %d: pChnInst->pstRingBuf == NULL\n", VeChn);
    }

    pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);

    return AX_SUCCESS;
}



AX_VENC_PUBLIC AX_S32 AX_VENC_StartRecvFrame(VENC_CHN VeChn, const AX_VENC_RECV_PIC_PARAM_S *pstRecvParam)
{
	AX_S32 i = 0;

	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRecvParam);

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_CREATED != gModCtx.enChnState[VeChn] &&
		VENC_CHN_STATE_STOPPED != gModCtx.enChnState[VeChn] &&
		VENC_CHN_STATE_RESETED != gModCtx.enChnState[VeChn]) {
			VLOG_ERROR("VencChn %d: Change Channel state from (%s) to (STARTED) is not allowd.\n",
				VeChn,
				gVencChnState[gModCtx.enChnState[VeChn]]);

		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	gModCtx.enChnState[VeChn] = VENC_CHN_STATE_STARTED;

	AX_VENC_CHN_INSTANCE_S *pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {

		for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
			pthread_mutex_lock(&gModCtx.stVencMutex[i]);
			pthread_cond_signal(&gModCtx.stVencCond[i]);
			pthread_mutex_unlock(&gModCtx.stVencMutex[i]);
		}

	} else if ((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
		pthread_mutex_lock(&gModCtx.stJencMutex);
		pthread_cond_signal(&gModCtx.stJencCond);
		pthread_mutex_unlock(&gModCtx.stJencMutex);
	}

	/*start input queue for receiving new data */
	VencTryStartInputQueue(VeChn, gChnInst[VeChn]);

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);

	VLOG_INFO("VencChn %d: start recv frame...\n", VeChn);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_StopRecvFrame(VENC_CHN VeChn)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[VeChn]) {
			VLOG_ERROR("VencChn %d: Change Channel state from (%s) to (STOPPED) is not allowed.\n",
				VeChn,
				gVencChnState[gModCtx.enChnState[VeChn]]);

		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	} else {
		pChnInst->s32FrameIndex = 0;
		pChnInst->u64FrameEncodeIndex = 0;
	}

	gModCtx.enChnState[VeChn] = VENC_CHN_STATE_STOPPED;

	/*step1:stop receiving new data */
	VencTryStopInputQueue(VeChn, pChnInst);

	/*step2: try to clear the input queue
	*Pay special attention to the reset operation on the vb reference count
	*/
	VencTryClearInputQueue(VeChn, pChnInst);

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);

	VLOG_INFO("VencChn %d: stop recv frame...\n", VeChn);
	return AX_SUCCESS;
}

#if 0
AX_S32 AX_VENC_SetOsdLayer(VENC_CHN VeChn, const AX_OSD_BMP_ATTR_S *pstOSDAttr)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstOSDAttr);
	VENC_CHN_EXIST_CHECK(VeChn, gChnInst[VeChn]);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pChnInst = gChnInst[VeChn];
	s32Ret = pChnInst->pEncoder->pfnSetOsdLayer(pChnInst, pstOSDAttr);
	if (AX_SUCCESS != s32Ret) {
		//
		return s32Ret;
	}

	return AX_SUCCESS;
}

AX_S32 AX_VENC_RefreshOsdLayer(VENC_CHN VeChn, AX_U32 u32OsdIndex, AX_U8* pBitmap)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pBitmap);
	VENC_CHN_EXIST_CHECK(VeChn, gChnInst[VeChn]);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pChnInst = gChnInst[VeChn];
	s32Ret = pChnInst->pEncoder->pfnRefreshOsdLayer(pChnInst, u32OsdIndex, pBitmap);
	if (AX_SUCCESS != s32Ret) {
		//
		return s32Ret;
	}

	return AX_SUCCESS;
}

AX_S32 AX_VENC_ResetOsd(VENC_CHN VeChn)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_CHN_EXIST_CHECK(VeChn, gChnInst[VeChn]);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pChnInst = gChnInst[VeChn];
	s32Ret = pChnInst->pEncoder->pfnResetOsd(pChnInst);
	if (AX_SUCCESS != s32Ret) {
		//
		return s32Ret;
	}

	return AX_SUCCESS;
}
#endif

AX_VENC_PUBLIC AX_S32 AX_VENC_SetRoiAttr(VENC_CHN VeChn, const AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRoiAttr);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: setRoiAttr, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}
	memcpy(&pChnInst->stVencRoiAttr[pstRoiAttr->u32Index], pstRoiAttr, sizeof(AX_VENC_ROI_ATTR_S));
	s32Ret = pChnInst->pEncoder->pfnSetRoiAttr(pChnInst, pstRoiAttr);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setRoiAttr, set roi attr err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetRoiAttr(VENC_CHN VeChn, AX_U32 u32Index, AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRoiAttr);

	if (u32Index < 0 || u32Index >= MAX_ROI_NUM) {
		VLOG_ERROR("VencChn %d: getRoiAttr, invalid roi index(%u).\n", VeChn, u32Index);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getRoiAttr, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	s32Ret = pChnInst->pEncoder->pfnGetRoiAttr(pChnInst, u32Index, pstRoiAttr);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getRoiAttr, get roi attr err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetRcParam(VENC_CHN VeChn, const AX_VENC_RC_PARAM_S *pstRcParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRcParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: setRcParam, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	s32Ret = pChnInst->pEncoder->pfnSetRcParam(pChnInst, pstRcParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setRcParam, set rc param err(%d)", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}
	VencUpdateRcParam(VeChn, pstRcParam);

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetRcParam(VENC_CHN VeChn, AX_VENC_RC_PARAM_S *pstRcParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRcParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getRcParam, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	s32Ret = pChnInst->pEncoder->pfnGetRcParam(pChnInst, pstRcParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getRcParam, get rc param err(%d)", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetChnAttr(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstChnAttr);

	AX_S32 s32Ret = -1;
	AX_U8 u8CurInFifoDepth = 0;
	AX_U8 u8CurOutFifoDepth = 0;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: setChnAttr, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: SetChnAttr, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if (pChnInst->stVencChnAttr.stVencAttr.enType == PT_H264 ||
		pChnInst->stVencChnAttr.stVencAttr.enType == PT_H265)
	{
		if (pstChnAttr->stVencAttr.enType == PT_JPEG || pstChnAttr->stVencAttr.enType == PT_MJPEG)
		{
			VLOG_ERROR("VencChn %d: channel encode type from type:%d to type:%d not supported.\n",
				VeChn,
				pChnInst->stVencChnAttr.stVencAttr.enType,
				pstChnAttr->stVencAttr.enType);
			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
			return AX_ERR_VENC_NOT_SUPPORT;
		}

		if (0 == memcmp(pstChnAttr, &pChnInst->stVencChnAttr, sizeof(AX_VENC_CHN_ATTR_S)))
		{
			VLOG_DEBUG("VencChn %d: channel attribute not change.\n", VeChn);
			pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
    		return AX_SUCCESS;
		}

		// update margin when resolution change
		if(pChnInst->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
			if (pChnInst->stVencChnAttr.stVencAttr.u32PicWidthSrc != pstChnAttr->stVencAttr.u32PicWidthSrc	||
				pChnInst->stVencChnAttr.stVencAttr.u32PicHeightSrc != pstChnAttr->stVencAttr.u32PicHeightSrc)
			{
				AX_U32 updateRingbufferMargin = (pstChnAttr->stVencAttr.u32PicWidthSrc * pstChnAttr->stVencAttr.u32PicHeightSrc * 3/4)
												+ MARGIN_PADDING_FOR_SMALL_RESOLUTION;
				pChnInst->pstRingBuf->stream_buffer_margin = updateRingbufferMargin;
				pChnInst->pstRingBuf->stream_buffer_margin_Init = updateRingbufferMargin;
			}
		}
	}

	if(pstChnAttr->stVencAttr.u8InFifoDepth > VENC_MAX_FIFO_CAPACITY){
		VLOG_ERROR("VencChn %d: input fifo depth(%d) shall not exceed the max fifo capacity(%d).\n",
			VeChn,
			pstChnAttr->stVencAttr.u8InFifoDepth,
			VENC_MAX_FIFO_CAPACITY);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if(pstChnAttr->stVencAttr.u8OutFifoDepth > VENC_MAX_FIFO_CAPACITY){
		VLOG_ERROR("VencChn %d: output fifo depth(%d) shall not exceed the max fifo capacity(%d).\n",
			VeChn,
			pstChnAttr->stVencAttr.u8OutFifoDepth,
			VENC_MAX_FIFO_CAPACITY);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	/*save current fifo depth*/
	u8CurInFifoDepth = pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth;
	u8CurOutFifoDepth = pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth;

	memcpy(&pChnInst->stVencChnAttr, pstChnAttr, sizeof(AX_VENC_CHN_ATTR_S));

	/*update input fifo depth if current depth is different from target depth*/
	if((pstChnAttr->stVencAttr.u8InFifoDepth != 0) && (pstChnAttr->stVencAttr.u8InFifoDepth != u8CurInFifoDepth)){
		VencSetInputKfifoDepth(VeChn, pChnInst);
		AX_Fifo_SetDepth(VeChn, pChnInst->inputQueue, pstChnAttr->stVencAttr.u8InFifoDepth);
	}else {
		/*restore input fifo depth*/
		pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth = u8CurInFifoDepth;
	}

	/*update output fifo depth if current depth is different from target depth*/
	if((pstChnAttr->stVencAttr.u8OutFifoDepth != 0) && (pstChnAttr->stVencAttr.u8OutFifoDepth != u8CurOutFifoDepth)){
		AX_Fifo_SetDepth(VeChn, pChnInst->outputQueue, pstChnAttr->stVencAttr.u8OutFifoDepth);
	}else {
		/*restore output fifo depth*/
		pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth = u8CurOutFifoDepth;
	}

	s32Ret = pChnInst->pEncoder->pfnSetChnAttr(pChnInst, pstChnAttr);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setChnAttr, set channel attr err(%x).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetChnAttr(VENC_CHN VeChn, AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstChnAttr);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getChnAttr, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	memcpy(pstChnAttr, &pChnInst->stVencChnAttr, sizeof(AX_VENC_CHN_ATTR_S));

	s32Ret = pChnInst->pEncoder->pfnGetChnAttr(pChnInst, pstChnAttr);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getChnAttr, get channel attr err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetSpsVuiParam(VENC_CHN VeChn, const AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstSpsVuiParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: setSpsVuiParam, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: setSpsVuiParam, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: setSpsVuiParam, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	if (AX_SUCCESS != VencSpsVuiParamCheck(VeChn, pstSpsVuiParam))
	{
		VLOG_ERROR("VencChn %d: Invalid Sps Vui Parameter.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	s32Ret = pChnInst->pEncoder->pfnSetSpsVuiParam(pChnInst, pstSpsVuiParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setSpsVuiParam, set sps vui param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetSpsVuiParam(VENC_CHN VeChn, AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstSpsVuiParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getSpsVuiParam, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: getSpsVuiParam, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: getSpsVuiParam, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	s32Ret = pChnInst->pEncoder->pfnGetSpsVuiParam(pChnInst, pstSpsVuiParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getSpsVuiParam, get sps vui param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetSuperFrameStrategy(VENC_CHN VeChn, const AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstSuperFrameCfg);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: setSuperFrameStrategy, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: setSuperFrameStrategy, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}


	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: setSuperFrameStrategy, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	if (AX_SUCCESS != VencSuperFrameCfgCheck(VeChn, pstSuperFrameCfg))
	{
		VLOG_ERROR("VencChn %d: Invalid super frame config.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	s32Ret = pChnInst->pEncoder->pfnSetSuperFrameCfg(pChnInst, pstSuperFrameCfg);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setSuperFrameCfg, set super frame config err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNKNOWN;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetRateJamStrategy(VENC_CHN VeChn, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRateJamParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: AX_VENC_SetRateJamStrategy, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: AX_VENC_SetRateJamStrategy, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if (PT_JPEG == pChnInst->enType) {
		VLOG_ERROR("VencChn %d: AX_VENC_SetRateJamStrategy, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	if (AX_SUCCESS != VencRateJamStrategyParamCheck(VeChn, pstRateJamParam))
	{
		VLOG_ERROR("VencChn %d: Invalid frame lost strategy Parameter.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	s32Ret = pChnInst->pEncoder->pfnSetRateJamStrategyParam(pChnInst, pstRateJamParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: AX_VENC_SetRateJamStrategy, set frame lost strategy param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetSuperFrameStrategy(VENC_CHN VeChn, AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstSuperFrameCfg);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getSuperFrameCfg, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: getSuperFrameCfg, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: getSuperFrameCfg, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	s32Ret = pChnInst->pEncoder->pfnGetSuperFrameCfg(pChnInst, pstSuperFrameCfg);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getSuperFrameCfg, get super frame config err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNKNOWN;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetRateJamStrategy(VENC_CHN VeChn, AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstRateJamParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: AX_VENC_GetRateJamStrategy, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: AX_VENC_GetRateJamStrategy, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if (PT_JPEG == pChnInst->enType) {
		VLOG_ERROR("VencChn %d: AX_VENC_GetRateJamStrategy, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	s32Ret = pChnInst->pEncoder->pfnGetRateJamStrategyParam(pChnInst, pstRateJamParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getRateJamStrategy, get frame lost stratety param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_InsertUserData(VENC_CHN VeChn, const AX_U8 *pu8Data, AX_U32 u32Len)
{
	VENC_CHN_RANGE_CHECK(VeChn);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: insertUserData, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	if ((PT_H264 != pChnInst->enType) && (PT_H265 != pChnInst->enType)) {
		VLOG_ERROR("VencChn %d: insert userdata, enType %d not support this API!\n", VeChn, pChnInst->enType);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	s32Ret = pChnInst->pEncoder->pfnInsertUserData(pChnInst, pu8Data, u32Len);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: insertUserData, insert user data err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_RequestIDR(VENC_CHN VeChn, AX_BOOL bInstant)
{
	VENC_CHN_RANGE_CHECK(VeChn);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: requestIDR, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	s32Ret = pChnInst->pEncoder->pfnRequestIDR(pChnInst, bInstant);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: requestIDR, request IDR err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}
    pChnInst->bRequestIDR = true;
    pChnInst->bInstant = bInstant;
    if (VENC_GOPMODE_ONELTR == pChnInst->stVencChnAttr.stGopAttr.enGopMode)
    {
        pChnInst->bInstant = false;
    }
	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_QueryStatus(VENC_CHN VeChn, AX_VENC_CHN_STATUS_S *pstStatus)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstStatus);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: queryStatus, channel is destroyed.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	s32Ret = pChnInst->pEncoder->pfnQueryStatus(pChnInst, pstStatus);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: queryStatus, get channel status err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetJpegParam(VENC_CHN VeChn, const AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstJpegParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

    if ((pstJpegParam->u32Qfactor > 99) || (pstJpegParam->u32Qfactor < 0)) {
        VLOG_ERROR("VencChn %d: pstJpegParam->u32Qfactor:%d over range[0,99].\n", VeChn, pstJpegParam->u32Qfactor);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYING <= gModCtx.enChnState[VeChn]) {
        VLOG_ERROR("VencChn %d: setJpegParam, channel is destroying.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: setJpegParam, chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}
	s32Ret = pChnInst->pEncoder->pfnSetJpegParam(pChnInst, pstJpegParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setJpegParam, set jpeg param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}

	VLOG_DEBUG("VencChn %d: SetJpegParam, Qfactor %d\n", VeChn, pstJpegParam->u32Qfactor);

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetJpegParam(VENC_CHN VeChn, AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstJpegParam);

	AX_S32 s32Ret = -1;
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	pthread_mutex_lock(&gModCtx.stChnStateMutex[VeChn]);
	if (VENC_CHN_STATE_DESTROYING <= gModCtx.enChnState[VeChn]) {
		VLOG_ERROR("VencChn %d: getJpegParam, channel is destroying.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}

	pChnInst = gChnInst[VeChn];
	if (pChnInst == NULL) {
		VLOG_ERROR("VencChn %d: chn instance is null.\n", VeChn);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return AX_ERR_VENC_UNEXIST;
	}
	s32Ret = pChnInst->pEncoder->pfnGetJpegParam(pChnInst, pstJpegParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: getJpegParam, get jpeg param err(%d).\n", VeChn, s32Ret);
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
		return s32Ret;
	}
	VLOG_DEBUG("VencChn %d: GetJpegParam, Qfactor %d\n", VeChn, pstJpegParam->u32Qfactor);

	pthread_mutex_unlock(&gModCtx.stChnStateMutex[VeChn]);
	return AX_SUCCESS;
}

static AX_S32 JpegEncodeOnceInit(AX_VOID)
{
	AX_S32 s32Ret = -1;

	gstJpegInst.pEncoder = &gJencEncoder;

	if (NULL != gstJpegInst.pEncoder) {
		s32Ret = gstJpegInst.pEncoder->pfnJpegEncodeOnceInit();
		if (0 != s32Ret) {
			VLOG_ERROR("Jpeg encode one frame init err.\n");
			return AX_ERR_VENC_NOT_INIT;
		}
	} else {
		s32Ret = AX_ERR_VENC_NULL_PTR;
	}

	return s32Ret;
}

static AX_S32 JpegEncodeOnceDeinit(AX_VOID)
{
	AX_S32 s32Ret = -1;

	if (NULL != gstJpegInst.pEncoder) {
		s32Ret = gstJpegInst.pEncoder->pfnJpegEncodeOnceDeinit();
		if (0 != s32Ret) {
			VLOG_ERROR("Jpeg encode one frame Deinit err.\n");
			return AX_ERR_VENC_NOT_PERMIT;
		}

		gstJpegInst.pEncoder = NULL;
	}

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_JpegEncodeOneFrame(AX_JPEG_ENCODE_ONCE_PARAMS *pstParam)
{
	AX_S32 s32Ret = -1;

	if (VENC_MOD_UNINIT == gModCtx.enModState) {
		VLOG_ERROR("Jpeg encode one frame: device is not init.\n");
		return AX_ERR_VENC_NOT_INIT;
	}

	pthread_mutex_lock(&gJpegEncodeOnceMutex);

	if (NULL != gstJpegInst.pEncoder) {
		s32Ret = gstJpegInst.pEncoder->pfnJpegEncodeOnce(pstParam);
		if (0 != s32Ret) {
			VLOG_ERROR("Jpeg encode one frame err(ret=%lx).\n", s32Ret);
			pthread_mutex_unlock(&gJpegEncodeOnceMutex);
			return s32Ret;
		}
	} else {
		s32Ret = AX_ERR_VENC_NULL_PTR;
	}

	pthread_mutex_unlock(&gJpegEncodeOnceMutex);

	return s32Ret;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_SetDebugFifoDepth(VENC_CHN VeChn, AX_VENC_ENCODER_TYPE_E enType, AX_U16 u16InFifoDepth, AX_U16 u16OutFifoDepth)
{
	AX_S32 fd_encoder = -1;
	AX_S32 s32Ret = -1;
	AX_U8 devName[20] = {0};
	VENC_IOC_PARAM_S stVencIocParam = {0};

	VENC_CHN_RANGE_CHECK(VeChn);

	if(u16InFifoDepth > VENC_MAX_DEBUG_FIFO_CAPACITY) {
		VLOG_ERROR("VencChn %d: invalid fifo depth =%d.over range[0,%d]\n", VeChn,u16InFifoDepth,VENC_MAX_DEBUG_FIFO_CAPACITY);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (VENC_VIDEO_ENCODER == enType) {
		sprintf((AX_CHAR *)devName,"%s", VENC_DEVICE_NAME);
	}else if(VENC_JPEG_ENCODER == enType) {
		sprintf((AX_CHAR *)devName,"%s", JENC_DEVICE_NAME);
	}else {
		VLOG_ERROR("VencChn %d: invalid encoder type =%d.\n", VeChn,enType);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	fd_encoder = open((AX_CHAR *)devName, O_RDWR);

	if (fd_encoder == -1) {
		VLOG_ERROR("VencChn %d: open %s failed,please insmod ax_venc.ko or ax_jenc.ko!\n", VeChn,devName);
		return AX_ERR_VENC_SYS_NOTREADY;
	}

	stVencIocParam.chnID = VeChn;
	stVencIocParam.fifoDepth = u16InFifoDepth;

	s32Ret = ioctl(fd_encoder, HANTRO_IOCH_IN_DEBUG_FIFO_DEPTH_SET, &stVencIocParam);
	if (0 != s32Ret) {
		close(fd_encoder);
		VLOG_ERROR("VencChn %d: set input debug fifo depth failed.\n", VeChn);
		return AX_ERR_VENC_UNKNOWN;
	}

	close(fd_encoder);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_GetInDebugFifoFrame(VENC_CHN VeChn, AX_VENC_ENCODER_TYPE_E enType, AX_VIDEO_FRAME_S *pstVFrame)
{
	AX_S32 fd_encoder = -1;
	AX_S32 s32Ret = -1;
	AX_U8 devName[20] = {0};
	VENC_FRAME_INFO_S stDebugFifoFrame;
	const AX_FRAME_DESCRIPTOR_S *pstFrameDesc = NULL;

	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstVFrame);

	if (VENC_VIDEO_ENCODER == enType) {
		sprintf((AX_CHAR *)devName,"%s", VENC_DEVICE_NAME);
	}else if(VENC_JPEG_ENCODER == enType) {
		sprintf((AX_CHAR *)devName,"%s", JENC_DEVICE_NAME);
	}else {
		VLOG_ERROR("VencChn %d: invalid encoder type =%d.\n", VeChn,enType);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	fd_encoder = open((AX_CHAR *)devName, O_RDWR);

	if (fd_encoder == -1) {
		VLOG_ERROR("VencChn %d: open %s failed,please insmod ax_venc.ko or ax_jenc.ko!\n",VeChn,devName);
		return AX_ERR_VENC_SYS_NOTREADY;
	}

	stDebugFifoFrame.chnID = VeChn;
	s32Ret = ioctl(fd_encoder, HANTRO_IOCH_IN_DEBUG_FIFO_POP, &stDebugFifoFrame);
	if (0 != s32Ret) {
		close(fd_encoder);
		VLOG_ERROR("VencChn %d: input debug fifo is empty.\n", VeChn);
		return AX_ERR_VENC_QUEUE_EMPTY;
	}

	pstFrameDesc = (AX_FRAME_DESCRIPTOR_S *)AX_POOL_GetMetaVirAddr(stDebugFifoFrame.blockID);

	if (!pstFrameDesc) {
		close(fd_encoder);
		VLOG_ERROR("VencChn %d, failed to get frame info from metadata\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(pstVFrame,&pstFrameDesc->stFrameInfo.stVFrame,sizeof(AX_VIDEO_FRAME_S));

	close(fd_encoder);

	return AX_SUCCESS;
}

AX_VENC_PUBLIC AX_S32 AX_VENC_ReleaseInDebugFifoFrame(VENC_CHN VeChn, AX_VENC_ENCODER_TYPE_E enType, const AX_VIDEO_FRAME_S *pstVFrame)
{
	AX_S32 s32Ret = -1,i;
	AX_BLK u32BlkId[3];
	AX_S32 modId = -1;

	VENC_CHN_RANGE_CHECK(VeChn);
	VENC_POINTER_CHECK(VeChn, pstVFrame);

	if (VENC_VIDEO_ENCODER == enType) {
		modId = AX_ID_VENC;
	}else if(VENC_JPEG_ENCODER == enType) {
		modId = AX_ID_JENC;
	}else {
		VLOG_ERROR("VencChn %d: invalid encoder type =%d.\n", VeChn,enType);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	for(i = 0;i < 3;i++) {

		u32BlkId[i] = pstVFrame->u32BlkId[i];

		if(u32BlkId[i] > 0) {
			s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], modId);
			if (0 != s32Ret) {
				VLOG_ERROR("VencChn %d: AX_POOL_DecreaseRefCnt_Inter err(0x%x).\n", VeChn,s32Ret);
				return AX_ERR_VENC_UNKNOWN;
			}
		}
	}

	return AX_SUCCESS;
}

static AX_S32 VencSendFrameToDebugFifo(VENC_CHN VeChn, AX_BLK BlockID, AX_S32 Devfd)
{
	AX_S32 s32Ret = -1;
	VENC_FRAME_INFO_S stDebugFifoFrame;

	VENC_CHN_RANGE_CHECK(VeChn);

	/*TODO*/
	if(BlockID == 0){
		VLOG_INFO("VencChn %d: does not support the case that blockID is 0.\n", VeChn);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	stDebugFifoFrame.chnID = VeChn;
	stDebugFifoFrame.blockID = BlockID;

	s32Ret = ioctl(Devfd, HANTRO_IOCH_IN_DEBUG_FIFO_PUSH, &stDebugFifoFrame);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: send frame to input debug fifo failed.\n", VeChn);
		return AX_ERR_VENC_UNKNOWN;
	}

	return AX_SUCCESS;
}

static AX_VOID VencUpdateRcParam(AX_S32 VeChn, const AX_VENC_RC_PARAM_S *pstChnRcParam)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = NULL;

	if (gChnInst[VeChn] != NULL)
		pChnInst = gChnInst[VeChn];

	AX_U32 enRcMode = pChnInst->stVencChnAttr.stRcAttr.enRcMode;
	AX_U32 dst_frameRate = pChnInst->dst_frameRate;
	AX_U32 src_frameRate = pChnInst->src_frameRate;

	switch (enRcMode) {
	case VENC_RC_MODE_H264CBR:
		if (pstChnRcParam->stH264Cbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264Cbr.fr32DstFrameRate;
		if (pstChnRcParam->stH264Cbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264Cbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264CVBR:
		if (pstChnRcParam->stH264CVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264CVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH264CVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264CVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264FIXQP:
		if (pstChnRcParam->stH264FixQp.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264FixQp.fr32DstFrameRate;
		if (pstChnRcParam->stH264FixQp.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264FixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264AVBR:
		if (pstChnRcParam->stH264AVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264AVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH264AVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264AVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264VBR:
		if (pstChnRcParam->stH264Vbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264Vbr.fr32DstFrameRate;
		if (pstChnRcParam->stH264Vbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264Vbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264QPMAP:
		if (pstChnRcParam->stH264QpMap.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264QpMap.fr32DstFrameRate;
		if (pstChnRcParam->stH264QpMap.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264QpMap.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264QVBR :
		if (pstChnRcParam->stH264QVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH264QVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH264QVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH264QVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265AVBR:
		if (pstChnRcParam->stH265AVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265AVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH265AVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265AVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265CBR:
		if (pstChnRcParam->stH265Cbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265Cbr.fr32DstFrameRate;
		if (pstChnRcParam->stH265Cbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265Cbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265CVBR:
		if (pstChnRcParam->stH265CVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265CVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH265CVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265CVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265FIXQP:
		if (pstChnRcParam->stH265FixQp.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265FixQp.fr32DstFrameRate;
		if (pstChnRcParam->stH265FixQp.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265FixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265QPMAP:
		if (pstChnRcParam->stH265QpMap.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265QpMap.fr32DstFrameRate;
		if (pstChnRcParam->stH265QpMap.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265QpMap.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265QVBR:
		if (pstChnRcParam->stH265QVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265QVbr.fr32DstFrameRate;
		if (pstChnRcParam->stH265QVbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265QVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265VBR:
		if (pstChnRcParam->stH265Vbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stH265Vbr.fr32DstFrameRate;
		if (pstChnRcParam->stH265Vbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stH265Vbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGCBR:
		if (pstChnRcParam->stMjpegCbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stMjpegCbr.fr32DstFrameRate;
		if (pstChnRcParam->stMjpegCbr.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stMjpegCbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGFIXQP:
		if (pstChnRcParam->stMjpegFixQp.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stMjpegFixQp.fr32DstFrameRate;
		if (pstChnRcParam->stMjpegFixQp.u32SrcFrameRate)
			src_frameRate = pstChnRcParam->stMjpegFixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGVBR:
		if (pstChnRcParam->stMjpegVbr.fr32DstFrameRate)
			dst_frameRate = pstChnRcParam->stMjpegVbr.fr32DstFrameRate;
		if (pstChnRcParam->stMjpegVbr.fr32DstFrameRate)
		src_frameRate = pstChnRcParam->stMjpegVbr.u32SrcFrameRate;
		break;
	default:
		break;
	}
	pChnInst->dst_frameRate = dst_frameRate;
	pChnInst->src_frameRate = src_frameRate;
	VLOG_INFO("VencChn %d: Update frame rate: srcFramerate %d, dstFramerate  %d\n",
						VeChn, src_frameRate, dst_frameRate);
}

static AX_VOID VencUpdateChnVariables(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pstChnAttr)
{
	AX_VENC_RC_ATTR_S pstRcAttr = pstChnAttr->stVencChnAttr.stRcAttr;
	AX_U32 enRcMode = pstChnAttr->stVencChnAttr.stRcAttr.enRcMode;
	AX_U32 dst_frameRate = 0;
	AX_U32 src_frameRate = 0;

	switch (enRcMode) {
	case VENC_RC_MODE_H264CBR:
		dst_frameRate = pstRcAttr.stH264Cbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264Cbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264CVBR:
		dst_frameRate = pstRcAttr.stH264CVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264CVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264FIXQP:
		dst_frameRate = pstRcAttr.stH264FixQp.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264FixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264AVBR:
		dst_frameRate = pstRcAttr.stH264AVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264AVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264VBR:
		dst_frameRate = pstRcAttr.stH264Vbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264Vbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264QPMAP:
		dst_frameRate = pstRcAttr.stH264QpMap.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264QpMap.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H264QVBR :
		dst_frameRate = pstRcAttr.stH264QVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH264QVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265AVBR:
		dst_frameRate = pstRcAttr.stH265AVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265AVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265CBR:
		dst_frameRate = pstRcAttr.stH265Cbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265Cbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265CVBR:
		dst_frameRate = pstRcAttr.stH265CVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265CVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265FIXQP:
		dst_frameRate = pstRcAttr.stH265FixQp.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265FixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265QPMAP:
		dst_frameRate = pstRcAttr.stH265QpMap.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265QpMap.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265QVBR:
		dst_frameRate = pstRcAttr.stH265QVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265QVbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_H265VBR:
		dst_frameRate = pstRcAttr.stH265Vbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stH265Vbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGCBR:
		dst_frameRate = pstRcAttr.stMjpegCbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stMjpegCbr.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGFIXQP:
		dst_frameRate = pstRcAttr.stMjpegFixQp.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stMjpegFixQp.u32SrcFrameRate;
		break;
	case VENC_RC_MODE_MJPEGVBR:
		dst_frameRate = pstRcAttr.stMjpegVbr.fr32DstFrameRate;
		src_frameRate = pstRcAttr.stMjpegVbr.u32SrcFrameRate;
		break;
	default:
		break;
	}
	pstChnAttr->dst_frameRate = dst_frameRate;
	pstChnAttr->src_frameRate = src_frameRate;
	VLOG_INFO("VencChn %d: Update frame rate: srcFramerate %d, dstFramerate  %d\n",
						VeChn, src_frameRate, dst_frameRate);
}

static AX_VOID VencTryWakeupInputQueueReader(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	pChnInst->bSendFrmAbort = AX_TRUE;
	AX_Fifo_WakeUp(VeChn, pChnInst->inputQueue, VENC_FIFO_PUSH);
	usleep(5 * 1000);
}

static AX_VOID VencTryStartInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;

	if(!pChnInst) {
		VLOG_ERROR("VencChn %d: null pointer error.\n", VeChn);
		return;
	}

	if (AX_NONLINK_MODE == pChnInst->stVencChnAttr.stVencAttr.enLinkMode) {
		pChnInst->bSendFrmAbort = AX_FALSE;
	}else {
		s32Ret = ioctl(pChnInst->devFd, HANTRO_IOCH_FIFO_START, &VeChn);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: start input queue failed in link mode,ret=%d.\n", VeChn,s32Ret);
			return;
		}
	}
	VLOG_INFO("VencChn %d: start input queue success.\n", VeChn);
}

static AX_VOID VencTryStopInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;

	if(!pChnInst) {
		VLOG_ERROR("VencChn %d: null pointer error.\n", VeChn);
		return;
	}

	if (AX_NONLINK_MODE == pChnInst->stVencChnAttr.stVencAttr.enLinkMode) {
		pChnInst->bSendFrmAbort = AX_TRUE;
		AX_Fifo_WakeUp(VeChn, pChnInst->inputQueue, VENC_FIFO_PUSH);
		usleep(5 * 1000);
	}else {
		s32Ret = ioctl(pChnInst->devFd, HANTRO_IOCH_FIFO_STOP, &VeChn);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: stop input queue failed in link mode,ret=%d.\n", VeChn,s32Ret);
			return;
		}
	}

	VLOG_INFO("VencChn %d: stop input queue success.\n", VeChn);
}

static AX_VOID VencTryClearInputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;
	AX_S32 modId = -1;
	AX_ENCODR_METADATA_INFO_S stFrameInfo = {0};
	VENC_FRAME_INFO_S stKfifoFrameInfo = {0};
	const AX_FRAME_DESCRIPTOR_S *pstFrameDesc = NULL;
	AX_U32 u32BlkId[3]={0};//must set 0 default

	if(!pChnInst) {
		VLOG_ERROR("VencChn %d: null pointer error.\n", VeChn);
		return;
	}

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
		modId = AX_ID_VENC;
	}else if((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
		modId = AX_ID_JENC;
	}

	while (1)
	{
		if (AX_NONLINK_MODE == pChnInst->stVencChnAttr.stVencAttr.enLinkMode) {
			s32Ret = AX_Fifo_Pop(VeChn, pChnInst->inputQueue, &stFrameInfo, 0);
			if (FIFO_EMPTY == s32Ret) {
				break;
			}
		}else {
			stKfifoFrameInfo.chnID = VeChn;
			s32Ret = ioctl(pChnInst->devFd, HANTRO_IOCH_FIFO_POP, &stKfifoFrameInfo);
			if (0 != s32Ret) {
				VLOG_INFO("VencChn %d: input fifo is empty,ret=%d.\n", VeChn,s32Ret);
				break;
			}

			pstFrameDesc = (AX_FRAME_DESCRIPTOR_S *)AX_POOL_GetMetaVirAddr(stKfifoFrameInfo.blockID);

			/*shall never fail*/
			if (!pstFrameDesc) {
				VLOG_ERROR("VencChn %d: failed to get frame info from metadata\n", VeChn);
				continue;
			}

			pChnInst->u64TotalRecvFrameNum++;
			stFrameInfo.inputFrameType = FRAME_NORMAL_TYPE;
			stFrameInfo.inputFrameInfo.stFrameInfo = pstFrameDesc->stFrameInfo;
		}

		/*get BlkId from struct AX_VIDEO_FRAME_S*/
		for(int i = 0; i < 3; i++)
		{
			if (stFrameInfo.inputFrameType == FRAME_NORMAL_TYPE) {
				u32BlkId[i] = stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u32BlkId[i];
			}else if (stFrameInfo.inputFrameType == FRAME_USER_TYPE) {
				u32BlkId[i] = stFrameInfo.inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u32BlkId[i];
			}

			if (u32BlkId[i] > 0)
			{
				s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], modId);
				if (0 != s32Ret){
					VLOG_ERROR("VencChn %d: AX_POOL_DecreaseRefCnt_Inter block_%d(0x%x) err(0x%x).\n", VeChn, i, u32BlkId[i], s32Ret);
				}else{
					VLOG_INFO("VencChn %d: AX_POOL_DecreaseRefCnt_Inter block_%d(0x%x) success.\n", VeChn, i, u32BlkId[i]);
				}
			}
		}
		pChnInst->u64TotalReleaseFrameNum++;
	}
}

AX_VOID VencTryWakeupOutputQueueReader(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;
	AX_S32 s32TimeWait = 0;
	s32TimeWait = pChnInst->stVencChnAttr.stVencAttr.s32StopWaitTime;

	if (s32TimeWait > -1) {

RETRY:
		if (s32TimeWait > 0) {
			s32Ret = AX_IsFifoEmpty(VeChn, pChnInst->outputQueue);
			if (FIFO_EMPTY != s32Ret) {
				usleep(1 * 1000);
				s32TimeWait--;
				goto RETRY;
			}
		}

		pChnInst->bGetStrmAbort = AX_TRUE;
		AX_Fifo_WakeUp(VeChn, pChnInst->outputQueue, VENC_FIFO_POP);
		usleep(5 * 1000);
	} else if (-1 == s32TimeWait) {
		while (1) {
			s32Ret = AX_IsFifoEmpty(VeChn, pChnInst->outputQueue);
			if (FIFO_EMPTY == s32Ret) {
				pChnInst->bGetStrmAbort = AX_TRUE;
				AX_Fifo_WakeUp(VeChn, pChnInst->outputQueue, VENC_FIFO_POP);
				usleep(5 * 1000);
				break;
			} else {
				usleep(5 * 1000);
				continue;
			}
		}
	}
}

static AX_VOID VencTryClearOutputQueue(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;
	AX_ENCODR_METADATA_INFO_S stFrameInfo = {0};
	AX_U32 u32BlkId;
	AX_S32 modId = -1;

	if(!pChnInst) {
		VLOG_ERROR("VencChn %d: null pointer error.\n", VeChn);
		return;
	}

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType)) {
		modId = AX_ID_VENC;
	}else if((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
		modId = AX_ID_JENC;
	}

	while (1)
	{
		s32Ret = AX_Fifo_Pop(VeChn, pChnInst->outputQueue, &stFrameInfo, 0);
		if (FIFO_EMPTY == s32Ret) {
			break;
		}

		if(pChnInst->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL) {

			/* should recalculate phyaddr by adding VENC_ADDR_OFFSET */
			stFrameInfo.outputStreamInfo.stPackage.ulPhyAddr += VENC_ADDR_OFFSET;

			u32BlkId = AX_POOL_PhysAddr2Handle(stFrameInfo.outputStreamInfo.stPackage.ulPhyAddr);

			s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,modId);
			if (0 != s32Ret) {
				VLOG_ERROR("VencChn %d: AX_POOL_ReleaseBlock_Inter err(0x%x).\n", VeChn, s32Ret);
			}else {
				VLOG_DEBUG("VencChn %d: AX_POOL_ReleaseBlock_Inter block(0x%x) success.\n", VeChn,u32BlkId);
			}
		}
	}
	pChnInst->u64LeftStreamBytes = 0;
	return;
}

static AX_BOOL VencIsAnyChnStrmExist(AX_CHN_STREAM_STATUS_S *pstChnStrmState)
{
	if (NULL == pstChnStrmState)
		return AX_FALSE;

	AX_U32 u32TotalChnNum = 0;
	AX_U32 u32Count = 0;

	for (int i = 0; i < MAX_VENC_NUM; i++) {

		pthread_mutex_lock(&gstDstryGetMutex[i]);

		if (VENC_CHN_STATE_DESTROYING == gModCtx.enChnState[i]) {
			VLOG_DEBUG("VencChn %d: selectChn, Channel is destroying...\n", i);
			pthread_mutex_unlock(&gstDstryGetMutex[i]);
			continue;
		}

		if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[i]) {
			VLOG_DEBUG("VencChn %d: selectChn, Channel is destroyed.\n", i);
			pthread_mutex_unlock(&gstDstryGetMutex[i]);
			continue;
		}

		u32Count = AX_Fifo_Count(i, gChnInst[i]->outputQueue);
		if (u32Count > 0) {
			pstChnStrmState->aenChnCodecType[i] = gChnInst[i]->enType;
			pstChnStrmState->au32ChnIndex[u32TotalChnNum] = i;
			u32TotalChnNum++;
		}

		pthread_mutex_unlock(&gstDstryGetMutex[i]);
	}

	pstChnStrmState->u32TotalChnNum = u32TotalChnNum;
	if (0 == u32TotalChnNum)
		return AX_FALSE;

	return AX_TRUE;
}

static AX_BOOL VencIsGrpChnStrmExist(VENC_GRP grpId, AX_CHN_STREAM_STATUS_S *pstChnStrmState, AX_U32 *pValidChnNum)
{
	if (NULL == pstChnStrmState) {
		VLOG_ERROR("VENC: null pointer.\n");
		return AX_FALSE;
	}

	if((MAX_VENC_GRP_NUM <= grpId) || (grpId < 0)) {
		VLOG_ERROR("VENC: invalid grpId.\n");
		return AX_FALSE;
	}

	AX_U32 u32TotalChnNum = 0;
	AX_U32 u32Count = 0;
	AX_U32 u32ValidChnNum = 0;
	AX_U32 u32VencChan = 0;
	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];

	for (int i = 0; i < pstVencSelectGrp->u32ChanNum; i++) {
		/* make sure u32VencChan < MAX_VENC_NUM */
		u32VencChan = pstVencSelectGrp->u32VencChan[i];
		pthread_mutex_lock(&gstDstryGetMutex[u32VencChan]);

		if (VENC_CHN_STATE_DESTROYING == gModCtx.enChnState[u32VencChan]) {
			VLOG_DEBUG("VencChn %d: selectChn, Channel is destroying...\n", u32VencChan);
			pthread_mutex_unlock(&gstDstryGetMutex[u32VencChan]);
			continue;
		}

		if (VENC_CHN_STATE_DESTROYED == gModCtx.enChnState[u32VencChan]) {
			VLOG_DEBUG("VencChn %d: selectChn, Channel is destroyed.\n", u32VencChan);
			pthread_mutex_unlock(&gstDstryGetMutex[u32VencChan]);
			continue;
		}

		/* recode valid venc chan num */
		u32ValidChnNum++;

		u32Count = AX_Fifo_Count(u32VencChan, gChnInst[u32VencChan]->outputQueue);
		if (u32Count > 0) {
			pstChnStrmState->aenChnCodecType[u32VencChan] = gChnInst[u32VencChan]->enType;
			pstChnStrmState->au32ChnIndex[u32TotalChnNum] = u32VencChan;
			u32TotalChnNum++;
		}

		pthread_mutex_unlock(&gstDstryGetMutex[u32VencChan]);
	}

	if(pValidChnNum)
		*pValidChnNum = u32ValidChnNum;

	pstChnStrmState->u32TotalChnNum = u32TotalChnNum;
	if (0 == u32TotalChnNum)
		return AX_FALSE;

	return AX_TRUE;
}

static AX_BOOL VencChnIsInGrp(VENC_GRP grpId, VENC_CHN VeChn)
{
	if((MAX_VENC_GRP_NUM <= grpId) || (grpId < 0)) {
		VLOG_ERROR("VENC: invalid grpId.\n");
		return AX_FALSE;
	}

	if((MAX_VENC_NUM <= VeChn) || (VeChn < 0)) {
		VLOG_ERROR("VENC: invalid enc chan.\n");
		return AX_FALSE;
	}

	AX_VENC_SELECT_GRP *pstVencSelectGrp = &gModCtx.stVencSelectGrp[grpId];
	for(int i = 0; i < pstVencSelectGrp->u32ChanNum; i++) {
		if(VeChn == pstVencSelectGrp->u32VencChan[i])
			return AX_TRUE;
	}

	return AX_FALSE;
}

static AX_S32 VencSendFrameCropAttrCheck(VENC_CHN VeChn, const AX_VIDEO_FRAME_INFO_S *pstFrame,
					const AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_U32 u32PicWidth, u32PicHeight;
	AX_S16 s16OffsetLeft, s16OffsetTop;
	AX_S16 s16OffsetRight, s16OffsetBottom;
	AX_S16 s16Temp = 0;

	u32PicWidth = pstFrame->stVFrame.u32Width;
	u32PicHeight = pstFrame->stVFrame.u32Height;

	s16OffsetLeft = pstFrame->stVFrame.s16OffsetLeft;
	s16OffsetTop = pstFrame->stVFrame.s16OffsetTop;
	s16OffsetRight = pstFrame->stVFrame.s16OffsetRight;
	s16OffsetBottom = pstFrame->stVFrame.s16OffsetBottom;

	if ( (PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType) ) {
		if ( (u32PicWidth < MIN_VENC_PIC_WIDTH) || (u32PicWidth > MAX_VENC_PIC_WIDTH) ) {
			VLOG_ERROR("VencChn %d Invalid pic width(%u), should range in [%u, %u].\n",
				VeChn,
				u32PicWidth,
				MIN_VENC_PIC_WIDTH,
				MAX_VENC_PIC_WIDTH);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		if ( (u32PicHeight < MIN_VENC_PIC_HEIGHT) || (u32PicHeight > MAX_VENC_PIC_HEIGHT) ) {
			VLOG_ERROR("VencChn %d Invalid pic height(%u), should range in [%u, %u].\n",
				VeChn,
				u32PicHeight,
				MIN_VENC_PIC_HEIGHT,
				MAX_VENC_PIC_HEIGHT);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	if ( (PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType) ) {
		if ( (u32PicWidth < MIN_JENC_PIC_WIDTH) || (u32PicWidth > MAX_JENC_PIC_WIDTH) ) {
			VLOG_ERROR("VencChn %d Invalid pic width(%u), should rang in [%u, %u].\n",
				VeChn,
				u32PicWidth,
				MIN_JENC_PIC_WIDTH,
				MAX_JENC_PIC_WIDTH);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		if ( (u32PicHeight < MIN_JENC_PIC_HEIGHT) || (u32PicHeight > MAX_JENC_PIC_HEIGHT) ) {
			VLOG_ERROR("VencChn %d Invalid pic height(%u), should range in [%u, %u].\n",
				VeChn,
				u32PicHeight,
				MIN_JENC_PIC_HEIGHT,
				MAX_JENC_PIC_HEIGHT);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	/* CropOffset must be even */
	if ((s16OffsetLeft & (1)) != 0 || (s16OffsetTop & (1)) != 0) {
		VLOG_ERROR("VencChn %d OffsetX=%d or OffsetY=%d must be even.\n",
			VeChn,
			s16OffsetLeft,
			s16OffsetTop);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ((s16OffsetLeft < 0) || (s16OffsetLeft > u32PicWidth)) {
		VLOG_ERROR("VencChn %d: Invalid s16OffsetLeft=%d, should range in [0, %u].\n",
			VeChn,
			s16OffsetLeft,
			u32PicWidth);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ( (s16OffsetRight < 0) || (s16OffsetRight > u32PicWidth) ) {
		VLOG_ERROR("VencChn %d: Invalid s16OffsetRight=%d, should range in [0, %u].\n",
			VeChn,
			s16OffsetRight,
			u32PicWidth);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ((s16OffsetTop < 0) || (s16OffsetTop > u32PicHeight)) {
		VLOG_ERROR("VencChn %d: Invalid s16OffsetTop=%d, should range in [0, %u].\n",
			VeChn,
			s16OffsetTop,
			u32PicHeight);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ( (s16OffsetBottom < 0) || (s16OffsetBottom > u32PicHeight) ) {
		VLOG_ERROR("VencChn %d: Invalid s16OffsetBottom=%d, should range in [0, %u].\n",
			VeChn,
			s16OffsetBottom,
			u32PicHeight);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	s16Temp = s16OffsetRight - s16OffsetLeft;
	if ((s16Temp < 0) || (s16Temp & 1) != 0) {
		VLOG_ERROR("VencChn %d: s16OffsetRight(%d) < s16OffsetLeft(%d), or crop width is not even.\n",
			VeChn,
			s16OffsetRight,
			s16OffsetLeft);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	s16Temp = s16OffsetBottom - s16OffsetTop;
	if ((s16Temp < 0) || (s16Temp & 1) != 0) {
		VLOG_ERROR("VencChn %d: s16OffsetBottom(%d) < s16OffsetTop(%d), or crop height is not even.\n",
			VeChn,
			s16OffsetBottom,
			s16OffsetTop);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

static AX_S32 VencSendFifoTimeout(VENC_CHN VeChn, FifoInst fifoObj, AX_S32 s32MilliSec)
{
    FifoRet fifoRet = FIFO_OK;
    fifoRet = AX_IsFifoFull(VeChn, fifoObj);
    struct timespec start_time = {0};
    struct timespec end_time = {0};
    AX_U64 consume_ms = 0;
    clock_gettime(CLOCK_MONOTONIC, &start_time);
    while (FIFO_FULL == fifoRet)
    {
        clock_gettime(CLOCK_MONOTONIC, &end_time);
        consume_ms =
            (1000 * (end_time.tv_sec - start_time.tv_sec)) + ((end_time.tv_nsec - start_time.tv_nsec) / 1000000);
        if (consume_ms >= s32MilliSec)
        {
            return AX_ERR_VENC_QUEUE_FULL;
        }
        usleep(1000);
        fifoRet = AX_IsFifoFull(VeChn, fifoObj);
    }
    return AX_SUCCESS;
}
static AX_S32 VencSendFrameChnAttrCheck(VENC_CHN VeChn, const AX_VIDEO_FRAME_INFO_S *pstFrame,
					const AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	if(NULL == pstFrame || NULL == pChnInst) {
		return AX_ERR_VENC_NULL_PTR;
	}

	if ( (PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType) ) {
		if (pstFrame->stVFrame.u32Width != pChnInst->stVencChnAttr.stVencAttr.u32PicWidthSrc) {
			VLOG_ERROR("VencChn %d Invalid pic width(%u),which is inconsistent with the pic width(%u) set by CreateChn.\n",
				VeChn,
				pstFrame->stVFrame.u32Width,
				pChnInst->stVencChnAttr.stVencAttr.u32PicWidthSrc);
			return AX_ERR_VENC_NOT_MATCH;
		}

		if (pstFrame->stVFrame.u32Height != pChnInst->stVencChnAttr.stVencAttr.u32PicHeightSrc) {
			VLOG_ERROR("VencChn %d Invalid pic height(%u),which is inconsistent with the pic height(%u) set by CreateChn.\n",
				VeChn,
				pstFrame->stVFrame.u32Height,
				pChnInst->stVencChnAttr.stVencAttr.u32PicHeightSrc);
			return AX_ERR_VENC_NOT_MATCH;
		}
	}

	if ((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType)) {
		if (pstFrame->stVFrame.u32Width > pChnInst->stVencChnAttr.stVencAttr.u32MaxPicWidth ||
			pstFrame->stVFrame.u32Width < MinJencWidth) {
			VLOG_ERROR("JencChn %d Invalid pic width(%u),which is over range[32, %d].\n",
				VeChn,
				pstFrame->stVFrame.u32Width,
				pChnInst->stVencChnAttr.stVencAttr.u32MaxPicWidth);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		if (pstFrame->stVFrame.u32Height > pChnInst->stVencChnAttr.stVencAttr.u32MaxPicHeight ||
			pstFrame->stVFrame.u32Height < MinJencHeight) {
			VLOG_ERROR("JencChn %d Invalid pic height(%u),which is over range[32, %d].\n",
				VeChn,
				pstFrame->stVFrame.u32Height,
				pChnInst->stVencChnAttr.stVencAttr.u32MaxPicHeight);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	return AX_SUCCESS;
}

// sps vui parameter check
static AX_S32 VencSpsVuiParamCheck(VENC_CHN VeChn, const AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam)
{
	if (pstSpsVuiParam->u32VideoSignalTypePresentFlag != 0 && pstSpsVuiParam->u32VideoSignalTypePresentFlag != 1)
	{
		VLOG_ERROR("VencChn %d: invalid vui u32VideoSignalTypePresentFlag=%d must be 0 or 1.\n", VeChn, pstSpsVuiParam->u32VideoSignalTypePresentFlag);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	if (pstSpsVuiParam->u32ColourDescriptionPresentFlag != 0 && pstSpsVuiParam->u32ColourDescriptionPresentFlag != 1)
	{
		VLOG_ERROR("VencChn %d: invalid vui u32ColourDescriptionPresentFlag=%d must be 0 or 1.\n", VeChn, pstSpsVuiParam->u32ColourDescriptionPresentFlag);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	if (pstSpsVuiParam->u32ColourPrimaries < 0 || pstSpsVuiParam->u32ColourPrimaries > 255)
	{
		VLOG_ERROR("VencChn %d: vui u32ColourPrimaries=%d, out of range[0, 255].\n", VeChn, pstSpsVuiParam->u32ColourPrimaries);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	if (pstSpsVuiParam->u32MatrixCoefficients < 0 || pstSpsVuiParam->u32MatrixCoefficients > 255)
	{
		VLOG_ERROR("VencChn %d: vui u32MatrixCoefficients=%d, out of range[0, 255].\n", VeChn, pstSpsVuiParam->u32MatrixCoefficients);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	if (pstSpsVuiParam->u32TransferCharacteristics < 0 || pstSpsVuiParam->u32TransferCharacteristics > 255)
	{
		VLOG_ERROR("VencChn %d: vui u32TransferCharacteristics=%d, out of range[0, 255].\n", VeChn, pstSpsVuiParam->u32TransferCharacteristics);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

static AX_S32 VencRateJamStrategyParamCheck(VENC_CHN VeChn, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	if (gChnInst[VeChn]->enType == PT_MJPEG)
	{
		if (pstRateJamParam->enDropFrmMode != DROPFRM_NORMAL)
		{
			VLOG_ERROR("VencChn %d: pstRateJamParam enDropFrmMode = %d is invalid.\n", VeChn, pstRateJamParam->enDropFrmMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}
	else
	{
		if (pstRateJamParam->enDropFrmMode < DROPFRM_NORMAL || pstRateJamParam->enDropFrmMode > DROPFRM_PSKIP)
		{
			VLOG_ERROR("VencChn %d: pstRateJamParam enDropFrmMode = %d is invalid.\n", VeChn, pstRateJamParam->enDropFrmMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	if (pstRateJamParam->u32MaxApplyCount < MIN_DROP_FRAME_NUM || pstRateJamParam->u32MaxApplyCount > MAX_DROP_FRAME_NUM)
	{
		VLOG_ERROR("VencChn %d: pstRateJamParam u32MaxApplyCount = %d is invalid.\n", VeChn, pstRateJamParam->u32MaxApplyCount);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstRateJamParam->u32DropFrmThrBps < MIN_DROP_FRAME_THR_BPS  || pstRateJamParam->u32DropFrmThrBps > MAX_DROP_FRAME_THR_BPS)
	{
		VLOG_ERROR("VencChn %d: pstRateJamParam u32DropFrmThrBps = %d is invalid.\n", VeChn, pstRateJamParam->u32DropFrmThrBps);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

static AX_S32 VencSuperFrameCfgCheck(VENC_CHN VeChn, const AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg)
{
	if (pstSuperFrameCfg->u32SuperIFrmBitsThr < 0)
	{
		VLOG_ERROR("VencChn %d: invalid super frame config: u32SuperIFrmBitsThr = %d must be > 0.\n", VeChn, pstSuperFrameCfg->u32SuperIFrmBitsThr);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstSuperFrameCfg->u32SuperPFrmBitsThr < 0)
	{
		VLOG_ERROR("VencChn %d: invalid super frame config: u32SuperPFrmBitsThr = %d must be > 0.\n", VeChn, pstSuperFrameCfg->u32SuperPFrmBitsThr);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstSuperFrameCfg->u32SuperBFrmBitsThr < 0)
	{
		VLOG_ERROR("VencChn %d: invalid super frame config: u32SuperBFrmBitsThr = %d must be > 0.\n", VeChn, pstSuperFrameCfg->u32SuperBFrmBitsThr);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstSuperFrameCfg->u32MaxReEncodeTimes < MIN_REENCODE_FRAME_NUM || pstSuperFrameCfg->u32MaxReEncodeTimes > MAX_REENCODE_FRAME_NUM)
	{
		VLOG_ERROR("VencChn %d: pstSuperFrameCfg u32MaxReEncodeTimes = %d is invalid.\n", VeChn, pstSuperFrameCfg->u32MaxReEncodeTimes);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

static AX_S32 VencCreateInputKfifo(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret = -1;
	AX_S32 encFd = -1;
	VENC_IOC_PARAM_S stVencIocParam = {0};

	if(NULL == pChnInst) {
		return AX_ERR_VENC_NULL_PTR;
	}

	if ((PT_H264 == pChnInst->enType) || (PT_H265 == pChnInst->enType))
		encFd = g_fd_venc;
	else if ((PT_JPEG == pChnInst->enType) || (PT_MJPEG == pChnInst->enType))
		encFd = g_fd_jenc;

	stVencIocParam.chnID = VeChn;

	/*get default fifo depth,AX620A:4 , AX620U:1*/
	s32Ret = ioctl(encFd, HANTRO_IOCH_INPUT_FIFO_DEPTH_GET, &stVencIocParam);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: get default input kfifo depth err.\n", VeChn);
		goto ERROR;
	}

	/*invalid param,use default output fifo depth*/
	if(pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth <=0) {
		pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth = VENC_DEFAULT_OUT_FIFO_DEPTH;
	}

	/*invalid param,use default input fifo depth*/
	if(pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth <=0) {
		pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth = stVencIocParam.fifoDepth;
	}else {

		/*valid param,update fifo depth*/
		stVencIocParam.chnID = VeChn;
		stVencIocParam.fifoDepth = pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth;

		s32Ret = ioctl(encFd, HANTRO_IOCH_INPUT_FIFO_DEPTH_SET, &stVencIocParam);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: set input kfifo depth err.\n", VeChn);
			goto ERROR;
		}
	}

	s32Ret = ioctl(encFd, HANTRO_IOCH_FIFO_CREATE, &VeChn);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: create input kfifo err.\n", VeChn);
		goto ERROR;
	}

	pChnInst->devFd = encFd;

	return 0;

ERROR:

	return -1;
}

static AX_S32 VencDestroyInputKfifo(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret;

	if(NULL == pChnInst) {
		return AX_ERR_VENC_NULL_PTR;
	}

	if (pChnInst->devFd >= 0) {
		s32Ret = ioctl(pChnInst->devFd, HANTRO_IOCH_FIFO_FREE, &VeChn);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: destroy input Kfifo error.\n", VeChn);
			return -1;
		}
	}

	return 0;
}

static AX_S32 VencSetInputKfifoDepth(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	AX_S32 s32Ret;
	VENC_IOC_PARAM_S stVencIocParam = {0};

	if(NULL == pChnInst) {
		return AX_ERR_VENC_NULL_PTR;
	}

	if (pChnInst->devFd >= 0) {

		stVencIocParam.chnID = VeChn;
		stVencIocParam.fifoDepth = pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth;

		s32Ret = ioctl(pChnInst->devFd, HANTRO_IOCH_INPUT_FIFO_DEPTH_SET, &stVencIocParam);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: set input kfifo depth err.\n", VeChn);
			return -1;
		}
	}

	return 0;
}
