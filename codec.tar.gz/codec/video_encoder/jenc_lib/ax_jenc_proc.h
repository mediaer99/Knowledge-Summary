#ifndef _AX_JENC_PROC_H_
#define _AX_JENC_PROC_H_

#include <pthread.h>
#include "ax_global_type.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define PROC_MSG_LEN            64*1024

typedef AX_S32 pJencProcCatCallback(char *msg, int msgMaxLen);

typedef struct __JencProcParams {
    AX_BOOL bExit;
    pthread_t threadId;
    pJencProcCatCallback *callback;
} JENC_PROC_PARAMS_S;

/* reserve for video encoder proc */

AX_S32 JencProcInit(AX_VOID);
AX_S32 JencProcDeinit(AX_VOID);



#ifdef __cplusplus
}
#endif

#endif