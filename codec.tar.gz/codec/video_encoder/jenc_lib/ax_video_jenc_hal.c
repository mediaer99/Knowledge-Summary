#include "ax_video_jenc_hal.h"
#include "ax_venc_interface.h"
#include "ax_fifo.h"
#include "ax_utils.h"
#include "ax_video_jenc.h"
#include <math.h>
#include <sys/prctl.h>
#include <sys/ioctl.h>
#include "vsi_string.h"
#include "base_type.h"

#include "jenc_api.h"
#include "enccommon.h"
#include "ax_video_jenc_utils.h"
#include "ax_video_jenc_init.h"

#include "ax_venc_log.h"
#include "vc8000_driver.h"
#include "ax_sys_api.h"
#include "ax_sys_api_internal.h"
#include "ax_frame.h"

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)
#define DEBUG_LOG(str, arg...)        \
	do { 	\
		printf("tid:%ld ax_video_jenc_hal.c %s %d "str"\n", gettid(), __func__, __LINE__, ##arg);	\
	} while(0)

#define DEBUG_ERR_LOG(str, arg...)        \
	do {		\
		printf("tid:%ld ax_video_jenc_hal.c %s %d Error! "str"\n", gettid(), __func__, __LINE__, ##arg);	\
	} while(0)


AX_JENC_HANDLE_S *gJencHandle[MAX_VENC_NUM] = {NULL};

/* reserved for jpeg encode one frame */
AX_JENC_HANDLE_S gstJencEncodeOnceHandle;

extern AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM];
extern AX_VENC_MOD_INSTANCE_S gModCtx;

extern AX_VOID VencTryWakeupOutputQueueReader(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);

static bool IsJencFifoFull(VENC_CHN VeChn, FifoInst fifoObj)
{
	FifoRet fifoRet;

	fifoRet = AX_IsFifoFull(VeChn, fifoObj);
	if (FIFO_FULL == fifoRet) {
		//VLOG_DEBUG("fifo is full.\n");
		return true;
	}

	return false;
}

static bool IsJencFifoEmpty(VENC_CHN VeChn, FifoInst fifoObj)
{
	FifoRet fifoRet;

	fifoRet = AX_IsFifoEmpty(VeChn, fifoObj);
	if (FIFO_EMPTY == fifoRet) {
		//VLOG_ERROR("fifo is empty.\n");
		return true;
	}

	return false;
}

static bool IsJencChnResReady(AX_S32 Vechn,AX_LINK_MODE_E enMode)
{
	bool bReady = false;
	VENC_FRAME_INFO_S stKfifoFrameInfo = {0};
	AX_S32 isEmpty = -1;

	if (NULL == gJencHandle[Vechn] || NULL == gChnInst[Vechn])
		return false;


	if (AX_NONLINK_MODE == enMode) {
	    bReady = IsJencFifoEmpty(Vechn, gChnInst[Vechn]->inputQueue);
	    if (bReady) {
		    //VLOG_DEBUG("JENC %d input fifo is empty.\n", Vechn);
		    return false;
	    }
	}else if (AX_LINK_MODE == enMode) {
	    stKfifoFrameInfo.chnID = Vechn;
	    isEmpty = ioctl(gChnInst[Vechn]->devFd, HANTRO_IOCH_FIFO_IS_EMPTY, &stKfifoFrameInfo);
	    if (isEmpty) {
		    //VLOG_DEBUG("JENC %d input fifo is empty.\n", Vechn);
		    return false;
	    }
	}

	bReady = IsJencFifoFull(Vechn, gChnInst[Vechn]->outputQueue);
	if (bReady) {
	    //VLOG_DEBUG("JENC %d output fifo is full.\n", Vechn);
	    return false;
	}

	return true;
}

static bool IsJencAllChnResNotReady()
{
	bool bReady = false;

	for (int i = 0; i < MAX_VENC_NUM; i++) {
		if ((PT_JPEG != gModCtx.enChnCodecType[i]) && (PT_MJPEG != gModCtx.enChnCodecType[i]))
			continue;

		if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[i])
			continue;

		if (NULL == gChnInst[i])
			continue;
		bReady = IsJencChnResReady(i, gChnInst[i]->stVencChnAttr.stVencAttr.enLinkMode);

		if(bReady)
			return false;
	}

	return true;
}

static bool IsJencAllChnStoped()
{
	for (int i = 0; i < MAX_VENC_NUM; i++) {

		pthread_mutex_lock(&gModCtx.stChnStateMutex[i]);
		if ((PT_JPEG != gModCtx.enChnCodecType[i]) && (PT_MJPEG != gModCtx.enChnCodecType[i])) {
			pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			continue;
		}
		if (VENC_CHN_STATE_STARTED == gModCtx.enChnState[i]) {
			pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			return false;
		}
		pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
	}

	return true;
}

static bool IsJencAllChnStopedV2()
{
	for (int i = 0; i < MAX_VENC_NUM; i++) {

		if (NULL == gChnInst[i]) {
			continue;
		}
		if ((PT_JPEG != gChnInst[i]->enType) && (PT_MJPEG != gChnInst[i]->enType)) {
			continue;
		}
		if (VENC_CHN_STATE_STARTED == gModCtx.enChnState[i]) {
			return false;
		}
	}

	return true;
}

static AX_S32 JencGetOutputBufferFromPool(AX_S32 chnID,AX_S32 s32BufSize,AX_BLK *pOutBlkId,AX_U64 *pPhyAddr,AX_VOID **ppVirAddr)
{
	AX_S32 s32Ret = 0;
	AX_BLK u32BlkId = 0;
	AX_U64 u64PhyAddr = 0;
	AX_VOID *pVirAddr = NULL;

	u32BlkId = AX_POOL_GetBlock_Inter(AX_INVALID_POOLID,s32BufSize,NULL,AX_ID_JENC);

	if(u32BlkId == AX_INVALID_BLOCKID){
		VLOG_INFO("JencChn %d: failed to get block for output buffer,request size=%d.\n\n",chnID,s32BufSize);
		return AX_ERR_VENC_NOMEM;
	}

	u64PhyAddr = AX_POOL_Handle2PhysAddr(u32BlkId);

	if(!u64PhyAddr){
		VLOG_ERROR("Jenc ChnId %d: Handle2PhysAddr for output buffer failed,blockid(0x%x).\n\n",chnID,u32BlkId);

		s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,AX_ID_JENC);
		if (s32Ret) {
			VLOG_ERROR("Jenc ChnId %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32BlkId, s32Ret);
		}
		return AX_ERR_VENC_NOMEM;
	}

	pVirAddr = AX_POOL_GetBlockVirAddr(u32BlkId);

	if(!pVirAddr){
		VLOG_ERROR("Jenc ChnId %d: GetBlockVirAddr for output buffer failed,blockid(0x%x).\n\n",chnID,u32BlkId);

		s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,AX_ID_JENC);
		if (s32Ret) {
			VLOG_ERROR("Jenc ChnId %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32BlkId, s32Ret);
		}
		return AX_ERR_VENC_NOMEM;
	}

	*pOutBlkId = u32BlkId;
	*pPhyAddr = u64PhyAddr;
	*ppVirAddr = pVirAddr;

	return AX_SUCCESS;
}

AX_VOID *JencEncodeLoop(void *pModeCtx)
{
	AX_S32 s32Ret = -1;
	FifoRet fifoRet = FIFO_OK;
	AX_S32 s32BufferSize = 0;
	VENC_GRP grpId = 0;
	AX_ENCODR_METADATA_INFO_S stFrameInfo;
	AX_ENCODR_METADATA_INFO_S stStreamInfo;
	VENC_FRAME_INFO_S stKfifoFrameInfo;
	const AX_FRAME_DESCRIPTOR_S *pstFrameDesc = NULL;
	bool bAllChnResNotReady = true;
	bool bIsFifoFull = false;
	AX_BLK u32BlkId[3]={0};//must set 0 by default
	AX_BLK u32OutBlkId = 0;
	AX_VENC_MOD_INSTANCE_S *pCtx = (AX_VENC_MOD_INSTANCE_S *)pModeCtx;
	AX_U32 waitFlg = 0;

    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set,SIGALRM);
    pthread_sigmask(SIG_SETMASK,&set,NULL);
	/* set encode thread name */
	prctl(PR_SET_NAME, "JencEncodeLoop");

	VLOG_ERROR("JENC loop enter +++.\n");
	while(VENC_MOD_INITED != pCtx->enModState) {
		usleep(1);
	}
	VLOG_ERROR("JENC loop enter ---.\n");

	while (VENC_MOD_INITED == pCtx->enModState) {

		for (int chnID = 0; chnID < MAX_VENC_NUM; chnID++) {
			waitFlg  = 0;
			pthread_mutex_lock(&gModCtx.stChnStateMutex[chnID]);
			while ((VENC_MOD_INITED == pCtx->enModState) && IsJencAllChnStopedV2()) {
				pthread_mutex_lock(&pCtx->stJencMutex);
				pCtx->isJencEncodeLoopCreate = AX_TRUE;
				VLOG_DEBUG("JencChn %d: Jenc loop thread wait +++.\n", chnID);
				pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
				pthread_cond_wait(&pCtx->stJencCond, &pCtx->stJencMutex);
				waitFlg = 1;
				VLOG_DEBUG("JencChn %d: Jenc loop thread wait ---.\n", chnID);
				pthread_mutex_unlock(&pCtx->stJencMutex);
				if (pCtx->isJencEncodeLoopExit || pCtx->isJencEnterSleep) {
					break;
				}
			}
			if (!waitFlg) pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);

			if ((VENC_MOD_INITED != pCtx->enModState) || pCtx->isJencEncodeLoopExit) {
				VLOG_INFO("Jenc encode loop thread exit...\n");
				return NULL;
			}

			if (pCtx->isJencEnterSleep == AX_TRUE) {
				if (pCtx->isJencWaitUnlock) {
					AX_SYS_WakeUnlock(AX_ID_JENC);
					pCtx->isJencWaitUnlock = AX_FALSE;
				}
				usleep(1000);
				continue;
			}

			/*
			Should call sleep(0) when there is not data to be processed
			in all channels to avoid excessive CPU loading.
			*/
			bAllChnResNotReady = IsJencAllChnResNotReady();
			if(bAllChnResNotReady){
				usleep(1000);
				continue;
			}

			if ((PT_JPEG != gModCtx.enChnCodecType[chnID]) && (PT_MJPEG != gModCtx.enChnCodecType[chnID])){
				continue;
			}

			pthread_mutex_lock(&pCtx->stChnStateMutex[chnID]);

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[chnID]) {
				pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
				continue;
			}

			if (!IsJencChnResReady(chnID,gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode)) {
				pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
				continue;
			}

			/* peek one frame from input queue */
			if (AX_LINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				stKfifoFrameInfo.chnID = chnID;
				s32Ret = ioctl(gChnInst[chnID]->devFd, HANTRO_IOCH_FIFO_PEEK, &stKfifoFrameInfo);
				if (0 != s32Ret) {
					VLOG_INFO("Jenc ChnId %d: ioctl peek fifo failed,ret=%d.\n", chnID,s32Ret);
					pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
					continue;
				}

				pstFrameDesc = (AX_FRAME_DESCRIPTOR_S *)AX_POOL_GetMetaVirAddr(stKfifoFrameInfo.blockID);

				/*shall never fail*/
				if (!pstFrameDesc) {
					VLOG_ERROR("Jenc ChnId %d: failed to get frame info from metadata\n", chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				if (0 == pstFrameDesc->stFrameInfo.stVFrame.u64PhyAddr[0]) {
					VLOG_DEBUG("Jenc ChnId %d: invalid phyAddr[0].\n", chnID);
					pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
					continue;
				}

				stFrameInfo.inputFrameInfo.stFrameInfo = pstFrameDesc->stFrameInfo;

				for (int j = 0; j < 3; j++) {
					if (stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[j]) {
						stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[j] -= VENC_ADDR_OFFSET;
					}
				}

				if (pstFrameDesc->stFrameInfo.stVFrame.u32Width != gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc ||
					pstFrameDesc->stFrameInfo.stVFrame.u32Height != gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc) {
					VLOG_DEBUG("Jenc ChnId %d: frame width/height is invalid,input.width=%d,input.height=%d,input.stride=%d,chn.width=%d,chn.height=%d.\n",
						chnID,
						pstFrameDesc->stFrameInfo.stVFrame.u32Width,
						pstFrameDesc->stFrameInfo.stVFrame.u32Height,
						pstFrameDesc->stFrameInfo.stVFrame.u32PicStride[0],
						gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc,
						gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc);
					goto DROP_FRAME;
				}


			} else if(AX_NONLINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				fifoRet = AX_Fifo_Peek(chnID, gChnInst[chnID]->inputQueue, &stFrameInfo, 0);
				if (FIFO_OK != fifoRet) {
					VLOG_INFO("Jenc ChnId %d: input fifo peek failed,ret=%d.\n", chnID,fifoRet);
					pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
					continue;
				}
			}

			// frame rate control: reduce frame mode
			if (gChnInst[chnID]->enType == PT_MJPEG)
			{
				s32Ret = VencIsFrameRateCtrlDrop(gChnInst[chnID]->src_frameRate, gChnInst[chnID]->dst_frameRate, gChnInst[chnID]->u64FrameEncodeIndex);
				if (s32Ret)
				{
					VLOG_DEBUG("Jenc ChnId %d: encode framerate control: drop index[%lld] frame\n",
                    	chnID, gChnInst[chnID]->u64FrameEncodeIndex);

					gChnInst[chnID]->u64FrameEncodeIndex++;
					goto DROP_FRAME;
				}
			}

ENLARGE_FRAME:

			/*shall check whether out fifo is full in enlarge frame mode*/
			if(gChnInst[chnID]->enStateMachine == VENC_STATE_MACHINE_ENLARGE){
				bIsFifoFull = IsJencFifoFull(chnID, gChnInst[chnID]->outputQueue);
				if(bIsFifoFull){
					VLOG_DEBUG("Jenc ChnId %d: enlarge frame mode but output fifo is full,try next time\n", chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}
			}

			if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
				s32BufferSize = (gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc * gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc * 3/2);

				AX_U64 u64OutBufPhyAddr = 0;
				AX_VOID *pOutBufVirAddr = NULL;

				s32Ret = JencGetOutputBufferFromPool(chnID,s32BufferSize,&u32OutBlkId,&u64OutBufPhyAddr,&pOutBufVirAddr);

				if(AX_SUCCESS != s32Ret){
					VLOG_WARNING("Jenc ChnId %d: failed to get output buffer from pool,try next time\n\n",chnID);
					gChnInst[chnID]->u64TotalBlkGetFailNum++;
					pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
					continue;
				}
				gJencHandle[chnID]->encIn.busOutBuf[0] = u64OutBufPhyAddr - VENC_ADDR_OFFSET;
				gJencHandle[chnID]->encIn.pOutBuf[0] = pOutBufVirAddr;
				gJencHandle[chnID]->encIn.outBufSize[0] = s32BufferSize;

				VLOG_DEBUG("Jenc ChnId %d: get output buffer success,blockid=0x%x.\n\n",chnID,u32OutBlkId);
			}else{
				s32BufferSize = ringbuffer_usable_size(chnID, gChnInst[chnID]->pstRingBuf);
				if (s32BufferSize < gChnInst[chnID]->pstRingBuf->stream_buffer_margin) {
					VLOG_WARNING("Jenc stream buffer margin is not enough.\n"
						"s32BufferSize:%d, stream_buffer_margin:%d\n",
						s32BufferSize, gChnInst[chnID]->pstRingBuf->stream_buffer_margin);
					pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
					continue;
				}

				gJencHandle[chnID]->encIn.busOutBuf[0] = gChnInst[chnID]->pstRingBuf->phyaddr_for_write;
				gJencHandle[chnID]->encIn.pOutBuf[0] = gChnInst[chnID]->pstRingBuf->viraddr_for_write;
				gJencHandle[chnID]->encIn.outBufSize[0] = s32BufferSize;
			}

			VLOG_DEBUG("ChnId:%d out: phyAddr=0x%lx, virAddr=%p, size=%u.\n",
						chnID, gJencHandle[chnID]->encIn.busOutBuf[0],
						gJencHandle[chnID]->encIn.pOutBuf[0],
						gJencHandle[chnID]->encIn.outBufSize[0]);

			// statistical realtime frame rate and bitrate
			if (gChnInst[chnID]->enType == PT_MJPEG)
			{
				if (gChnInst[chnID]->u64TotalEncodeNum == 0)
				{
					gettimeofday(&gChnInst[chnID]->timeGetFrmEncodeStart, NULL);
					gChnInst[chnID]->timeGetFrmEncodeStartForInstantBps = gChnInst[chnID]->timeGetFrmEncodeStart;
				}
				else
				{
					gChnInst[chnID]->pEncoder->pfnUpdateFpsBr(gChnInst[chnID]);
				}

				// rate jam strategy
				gChnInst[chnID]->u64EncodeFrmNumForInstantaneousBps++;
				if (gJencHandle[chnID]->stCmdl.stRateJamStrategyParam.bDropFrmEn)
				{
					s32Ret = JencRateJamProcess((JpegEncInst)gChnInst[chnID], gJencHandle[chnID], chnID);
					if (s32Ret != AX_SUCCESS)
					{
						/* release block used by output buffer */
						if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
							s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId,AX_ID_JENC);
							if (s32Ret) {
								VLOG_ERROR("Jenc ChnId %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
							}
						}
						goto DROP_FRAME;
					}
				}
			}

			s32Ret = JencProcess(chnID, gJencHandle[chnID], stFrameInfo, &stStreamInfo);
			if (AX_SUCCESS != s32Ret) {
				VLOG_ERROR("Jenc ChnId %d: encode error.s32Ret:0x%x\n", chnID, s32Ret);

				/* release block used by output buffer */
				if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
					s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId,AX_ID_JENC);
					if (s32Ret) {
						VLOG_ERROR("Jenc ChnId %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
					}
				}

				/* shall try to wakeup GetStream for block-mode */
				VencTryWakeupOutputQueueReader(chnID, gChnInst[chnID]);

				goto DROP_FRAME;
			}

			gChnInst[chnID]->u64TotalEncodeNum++;
			if (gChnInst[chnID]->enType == PT_MJPEG)
			{
				gChnInst[chnID]->u64PerSecondStrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
				gChnInst[chnID]->u64StatisticalEncodeFrm++;
				gChnInst[chnID]->u64FrameEncodeIndex++;
				gChnInst[chnID]->u64InstantaneousEncodeStrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
			}

			if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
				ringbuffer_write_finalize(chnID, gChnInst[chnID]->pstRingBuf, stStreamInfo.outputStreamInfo.stPackage.u32Len);
			}

			fifoRet = AX_Fifo_Push(chnID, gChnInst[chnID]->outputQueue, stStreamInfo, 0);
			if (FIFO_OK != fifoRet) {

				/* shall never happen because it has been checked before */
				VLOG_DEBUG("Jenc ChnId:%d: output fifo push failed\n", chnID);

				/* release block used by output buffer */
				if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
					s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId,AX_ID_JENC);
					if (s32Ret) {
						VLOG_ERROR("Jenc ChnId %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
					}
				}
				goto DROP_FRAME;
			}
			gChnInst[chnID]->u64LeftStreamBytes += stStreamInfo.outputStreamInfo.stPackage.u32Len;

			if (gChnInst[chnID]->enType == PT_MJPEG)
			{
				s32Ret = VencIsFrameRateCtrlEnlarge(gChnInst[chnID]->src_frameRate, gChnInst[chnID]->dst_frameRate, gChnInst[chnID]->u64FrameEncodeIndex);
				if (s32Ret) {
					VLOG_DEBUG("Jenc ChnId %d: encode framerate control: duplicate index[%lld] frame\n",
                    	chnID, gChnInst[chnID]->u64FrameEncodeIndex);

					/*state machine switch to enlarge frame mode*/
					gChnInst[chnID]->enStateMachine = VENC_STATE_MACHINE_ENLARGE;

					goto ENLARGE_FRAME;
				}
			}

			grpId = pCtx->vencGrpId[chnID];
			if ((MAX_VENC_GRP_NUM > grpId) && (grpId >= 0)) {
				pthread_mutex_lock(&pCtx->stVencSelectGrp[grpId].stEncSelectMutex);
				pthread_cond_signal(&pCtx->stVencSelectGrp[grpId].stEncSelectCond);
				pthread_mutex_unlock(&pCtx->stVencSelectGrp[grpId].stEncSelectMutex);
			} else {
				pthread_mutex_lock(&pCtx->stEncSelectMutex);
				pthread_cond_signal(&pCtx->stEncSelectCond);
				pthread_mutex_unlock(&pCtx->stEncSelectMutex);
			}
DROP_FRAME:

			/*state machine switch to normal state*/
			gChnInst[chnID]->enStateMachine = VENC_STATE_MACHINE_NORMAL;

			/* pop one frame from input queue */
			if (AX_LINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				s32Ret = ioctl(gChnInst[chnID]->devFd, HANTRO_IOCH_FIFO_POP, &stKfifoFrameInfo);
				if (0 != s32Ret) {
					VLOG_ERROR("Jenc ChnId %d: ioctl pop fifo failed,ret=%d.\n", chnID,s32Ret);
				}
				gChnInst[chnID]->u64TotalRecvFrameNum++;
			}else {
				fifoRet = AX_Fifo_Pop(chnID, gChnInst[chnID]->inputQueue, &stFrameInfo, 0);
				if (FIFO_OK != fifoRet) {
					VLOG_ERROR("Jenc ChnId %d: input fifo pop failed,ret=%d.\n", chnID,fifoRet);
				}
			}

			for(int i = 0; i < 3; i++)
			{
				u32BlkId[i] = stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u32BlkId[i];

				if(u32BlkId[i] > 0) {
					s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i],AX_ID_JENC);
					if (s32Ret) {
						VLOG_ERROR("Jenc ChnId %d: pool DecreaseRefCnt block_%d(0x%x) err. s32Ret:0x%x\n", chnID, i, u32BlkId[i], s32Ret);
					}
				}
			}
			gChnInst[chnID]->u64TotalReleaseFrameNum++;
			pthread_mutex_unlock(&pCtx->stChnStateMutex[chnID]);
		}
	}

	VLOG_DEBUG("Exit!\n");
	return NULL;
}


static AX_S32 JencCreateChn(AX_S32 VeChn, const AX_VENC_CHN_ATTR_S *pstAttr, AX_VOID *pCtx)
{
	AX_S32 s32Ret = -1;
	AX_JENC_HANDLE_S *pHandle;

	s32Ret = JencChnAttrCheck(VeChn, pstAttr);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC %d: channel attribute check fail.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	pHandle = (AX_JENC_HANDLE_S *)calloc(1, sizeof(AX_JENC_HANDLE_S));
	if (NULL == pHandle) {
		VLOG_ERROR("JENC %d: create handle error.\n", VeChn);
		return AX_ERR_VENC_CREATE_CHAN_ERR;
	}

	JencDefaultParameter(pHandle);
	pHandle->VeChn = VeChn;
	s32Ret = JencHandleGetChnAttr(VeChn, pstAttr, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC %d: init channel attribute error.\n", VeChn);
		s32Ret = AX_ERR_VENC_ILLEGAL_PARAM;
		goto ERR_FERR_HANDLE;
	}

	/* Encoder initialization */
	s32Ret = JencOpenEncoder(&pHandle->jenc_encoder, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC %d: open encoder error.\n");
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
		goto ERR_FERR_HANDLE;
	}

	s32Ret = JencAllocResNew(pHandle->jenc_encoder, pHandle, pstAttr);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC %d: alloc res error.\n", VeChn);
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
		goto ERR_FREE_RES;
	}

	// s32Ret = JencEncodeHeader(pHandle);
	// if (0 != s32Ret) {
	// 	VLOG_ERROR("JENC %d: encode header err.\n", VeChn);
	// 	return AX_ERR_VENC_CREATE_CHAN_ERR;
	// }

	pHandle->VeChn = VeChn;
    ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx = pHandle;
	gJencHandle[VeChn] = pHandle;

	return AX_SUCCESS;

ERR_FREE_RES:
    JencCloseEncoder(pHandle->jenc_encoder, pHandle);
	JencFreeRes(pHandle->jenc_encoder, pHandle);
ERR_FERR_HANDLE:
	free(pHandle);
	return s32Ret;
}

static AX_S32 JencDestroyChn(AX_VOID *pCtx)
{
	AX_S32 s32Ret;
	if (pCtx == NULL) {
		return AX_ERR_VENC_NULL_PTR;
	}

    AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
    VENC_CHN VencChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VencChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	JencEncodeEnd(pHandle);

	JencFreeRes(pHandle->jenc_encoder, pHandle);

	s32Ret = JencCloseEncoder(pHandle->jenc_encoder, pHandle);

	free(pHandle);

	pCtx = NULL;

	return s32Ret;
}

static AX_S32 JencSendFrame(AX_VOID *pCtx, const AX_VIDEO_FRAME_INFO_S *pstFrame , AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstFrame) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }


    return AX_SUCCESS;
}

static AX_S32 JencSendFrameEx(AX_VOID *pCtx, const AX_USER_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstFrame) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }


    return AX_SUCCESS;
}

static AX_S32 JencGetStream(AX_VOID *pCtx, AX_VENC_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstStream) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencReleaseStream(AX_VOID *pCtx, const AX_VENC_STREAM_S *pstStream)
{
	AX_S32 VeChn;

    if (NULL == pstStream) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencStartRecvFrame(AX_VOID *pCtx, const AX_VENC_RECV_PIC_PARAM_S *pstRecvParam)
{
	AX_S32 VeChn;

    if (NULL == pstRecvParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencStopRecvFrame(AX_VOID *pCtx)
{
	AX_S32 VeChn;

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

#if 0
static AX_S32 JencSetOsdLayer(AX_VOID *pCtx, const AX_OSD_BMP_ATTR_S *pstOSDAttr)
{
	AX_S32 VeChn;

    if (NULL == pstOSDAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencRefreshOsdLayer(AX_VOID *pCtx, AX_U32 u32OsdIndex, AX_U8* pBitmap)
{
	AX_S32 VeChn;

    if (NULL == pBitmap) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencResetOsd(AX_VOID *pCtx)
{
	AX_S32 VeChn;

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}
#endif

static AX_S32 JencSetRoiAttr(AX_VOID *pCtx, const AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
    AX_S32 VeChn;
    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencGetRoiAttr(AX_VOID *pCtx, AX_U32 u32Index, AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
    AX_S32 VeChn;
    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

static AX_S32 JencSetRcParam(AX_VOID *pCtx, const AX_VENC_RC_PARAM_S *pstRcParam)
{
	JpegEncRet s32Ret;
	JpegEncRateCtrl jencRateCtrl;
	AX_S32 VeChn;

	if (pCtx == NULL || pstRcParam == NULL) {
		VLOG_ERROR("pContex or pRcParam is null.\n");
		return AX_ERR_VENC_NULL_PTR;
	}
    AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (pHandle == NULL) {
		VLOG_ERROR("pHandle is null.\n");
		return AX_ERR_VENC_NULL_PTR;
	}
	if(pHandle->stCmdl.mjpeg != AX_TRUE) {
		VLOG_ERROR("Jpeg encode not support set rc param.\n");
		return AX_ERR_VENC_NOT_PERMIT;
	}

	VeChn = pHandle->VeChn;

	s32Ret = JencRcParamCheck(VeChn, pHandle->enRcMode, pstRcParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("JENC %d: JencSetRcParam, Invalid Rc Params.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	memset(&jencRateCtrl,0,sizeof(JpegEncRateCtrl));

	s32Ret = AXJpegEncGetRC(&pHandle->jenc_encoder, &jencRateCtrl);
	if (JPEGENC_OK != s32Ret) {
		VLOG_ERROR("JENC %d: JencSetRcParam, getRateCtrl failed.\n", VeChn);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	if(pHandle->stCmdl.mjpeg == AX_TRUE){
	    switch (pHandle->enRcMode){
	    case VENC_RC_MODE_MJPEGCBR:
            jencRateCtrl.bitPerSecond = pstRcParam->stMjpegCbr.u32BitRate * VENC_BITRATE_RATIO;
            jencRateCtrl.qpMin = pstRcParam->stMjpegCbr.u32MinQp;
            jencRateCtrl.qpMax = pstRcParam->stMjpegCbr.u32MaxQp;
            break;
	    case VENC_RC_MODE_MJPEGVBR:
            jencRateCtrl.bitPerSecond = pstRcParam->stMjpegVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
            jencRateCtrl.qpMin = pstRcParam->stMjpegVbr.u32MinQp;
            jencRateCtrl.qpMax = pstRcParam->stMjpegVbr.u32MaxQp;
            break;
	    case VENC_RC_MODE_MJPEGFIXQP:
            jencRateCtrl.FixedQp = pstRcParam->stMjpegFixQp.s32FixedQp;
            break;
	    default:
            VLOG_ERROR("JENC %d: JencSetRcParam, Invalid Rc mode(%d).\n", VeChn,pHandle->enRcMode);
            return AX_ERR_VENC_ILLEGAL_PARAM;
	    }

	}else{
		VLOG_ERROR("JENC %d: JencSetRcParam, is not MJPEG.\n", VeChn);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	s32Ret = AXJpegEncSetRC(&pHandle->jenc_encoder, &jencRateCtrl);
	if (JPEGENC_OK != s32Ret) {
		VLOG_ERROR("JENC %d: JencSetRcParam, setRateCtrl failed.\n", VeChn);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	memcpy(&pHandle->stRcParam, pstRcParam, sizeof(AX_VENC_RC_PARAM_S));

	if (pHandle->enRcMode == VENC_RC_MODE_MJPEGFIXQP)
	{
		VLOG_ERROR("JENC %d: JencSetRcParam:FixedQp=%d\n",
				VeChn,pstRcParam->stMjpegFixQp.s32FixedQp);
	}else{
	    VLOG_ERROR("JENC %d: JencSetRcParam: RcMode=%d,vbr=%d,qpRange=[%2d, %2d],bps=%9d\n",
				VeChn,
				pHandle->enRcMode,
				jencRateCtrl.vbr,
				jencRateCtrl.qpMin, jencRateCtrl.qpMax,
				jencRateCtrl.bitPerSecond);
	}

	return AX_SUCCESS;

}

static AX_S32 JencGetRcParam(AX_VOID *pCtx, AX_VENC_RC_PARAM_S *pstRcParam)
{
	/* JpegEncRet s32Ret; */
	/* JpegEncRateCtrl jencRateCtrl; */
	/* AX_S32 VeChn; */

	if (pCtx == NULL || pstRcParam == NULL) {
		return AX_ERR_VENC_NULL_PTR;
	}
    AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;

	memcpy(pstRcParam, &pHandle->stRcParam, sizeof(AX_VENC_RC_PARAM_S));

	return AX_SUCCESS;
}

static AX_S32 JencSetChnAttr(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr)
{
    AX_S32 VeChn;
    AX_S32 s32Ret = 0;

    if (NULL == pstChnAttr) {
		VLOG_ERROR("Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR("Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	s32Ret = JencChnAttrCheck(VeChn, pstChnAttr);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC %d: channel attribute check fail.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    s32Ret = JencHandleUpdateChnAttr(VeChn, pstChnAttr, pHandle);
    if (s32Ret) {
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    return AX_SUCCESS;
}

static AX_S32 JencGetChnAttr(AX_VOID *pCtx, AX_VENC_CHN_ATTR_S *pstChnAttr)
{
    AX_S32 VeChn;
    if (NULL == pstChnAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    return AX_SUCCESS;
}

static AX_S32 JencSetRateJamStrategyParam(AX_VOID *pCtx, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	AX_S32 VeChn;

	if (NULL == pstRateJamParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(&pHandle->stCmdl.stRateJamStrategyParam, pstRateJamParam, sizeof(AX_VENC_RATE_JAM_CFG_S));

	return AX_SUCCESS;
}

static AX_S32 JencGetRateJamStrategyParam(AX_VOID *pCtx, AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	AX_S32 VeChn;
	if (NULL == pstRateJamParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(pstRateJamParam, &pHandle->stCmdl.stRateJamStrategyParam, sizeof(AX_VENC_RATE_JAM_CFG_S));

	return AX_SUCCESS;
}

static AX_S32 JencInsertUserData(AX_VOID *pCtx, const AX_U8 *pu8Data, AX_U32 u32Len)
{
    AX_S32 VeChn;
    if (NULL == pu8Data) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

static AX_S32 JencRequestIDR(AX_VOID *pCtx, AX_BOOL bInstant)
{
	return AX_ERR_VENC_NOT_SUPPORT;
}

static AX_S32 JencQueryStatus(AX_VOID *pCtx, AX_VENC_CHN_STATUS_S *pstStatus)
{
	AX_S32 VeChn;
	AX_S32 s32Ret = 0;
	AX_S32 LeftFrames = 0;
	VENC_IOC_PARAM_S stJencIocParam = {0};

	if (NULL == pstStatus) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	AX_VENC_CHN_INSTANCE_S *JencInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;

	VeChn = JencInst->ChnId;

	if (AX_NONLINK_MODE == JencInst->stVencChnAttr.stVencAttr.enLinkMode) {
		LeftFrames = AX_Fifo_Count(VeChn, JencInst->inputQueue);
	}else if (AX_LINK_MODE == JencInst->stVencChnAttr.stVencAttr.enLinkMode) {
		stJencIocParam.chnID = VeChn;
		s32Ret = ioctl(JencInst->devFd, HANTRO_IOCH_FIFO_LEN, &stJencIocParam);
		if (s32Ret) {
			VLOG_ERROR("JencChn %d: get frames length in input fifo failed.\n", VeChn);
			return AX_ERR_VENC_UNKNOWN;
		}
		LeftFrames = stJencIocParam.fifoLength;
	}

	pstStatus->u32LeftPics = LeftFrames;
	pstStatus->u32LeftStreamBytes = JencInst->u64LeftStreamBytes;
	pstStatus->u32LeftStreamFrames = JencInst->u64TotalEncodeNum - JencInst->u64TotalGetStrmNum;
	pstStatus->u32CurPacks = 0;  // not support
	pstStatus->u32LeftRecvPics = 0;  // not support
	pstStatus->u32LeftEncPics = 0;  // not support

	VLOG_DEBUG("JencChn %d: LeftPics %d, LeftStreamBytes %d, LeftStreamFrames %d.\n",
				VeChn,
				pstStatus->u32LeftPics,
				pstStatus->u32LeftStreamBytes,
				pstStatus->u32LeftStreamFrames);

	return AX_SUCCESS;
}

static AX_VOID JencUpdateFpsBr(AX_VOID *pCtx)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;
	struct timeval timeGetFrmEncode;

	gettimeofday(&timeGetFrmEncode, NULL);

	AX_U32 timediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetFrmEncodeStart);
	if (timediff > 1000000) // 1000000us == 1s
	{
		pChnInst->F32RealTimeFrameRate = (AX_F32)(pChnInst->u64StatisticalEncodeFrm * 1000 * 1000) / timediff;
		pChnInst->u64RealTimeBitRate = pChnInst->u64PerSecondStrmSize * 8 * 1000 * 1000 / timediff;
		pChnInst->u64RealTimeBitRate >>= 10;

		pChnInst->u64PerSecondStrmSize = 0;
		pChnInst->u64StatisticalEncodeFrm = 0;

		pChnInst->timeGetFrmEncodeStart = timeGetFrmEncode;
	}

	// update for instantaneous bps
	if (pChnInst->enType == PT_MJPEG)
	{
		AX_U32 bpstimediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetFrmEncodeStartForInstantBps);
		if (pChnInst->u64EncodeFrmNumForInstantaneousBps > 5 || bpstimediff > 1000000) // update per 5 frames, we think it is instantanous data
		{
			pChnInst->u64InstantaneousBitRate = pChnInst->u64InstantaneousEncodeStrmSize * 8 * 1000 * 1000 / bpstimediff;
			pChnInst->u64InstantaneousEncodeStrmSize = 0;
			pChnInst->u64EncodeFrmNumForInstantaneousBps = 0;

			pChnInst->timeGetFrmEncodeStartForInstantBps = timeGetFrmEncode;
		}
	}
}


static AX_S32 JencSetJpegParam(AX_VOID *pCtx, const AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
    AX_S32 s32Ret = AX_SUCCESS;
    if (pCtx == NULL || pstJpegParam == NULL) {
        return AX_ERR_VENC_NULL_PTR;
    }

    AX_S32 VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

    AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	s32Ret = JencJpegParamCheck(VeChn, pstJpegParam);

	if (s32Ret == AX_SUCCESS) {
		s32Ret = AXJencSetUserQpTable(&pHandle->jenc_encoder, pstJpegParam->u32Qfactor,
									pstJpegParam->u8YQt, pstJpegParam->u8CbCrQt);
		if (s32Ret != JPEGENC_OK)
			s32Ret = AX_ERR_VENC_NULL_PTR;
		pHandle->u32Qfactor = pstJpegParam->u32Qfactor;
	}

	return s32Ret;
}

static AX_S32 JencGetJpegParam(AX_VOID *pCtx, AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
    AX_S32 s32Ret = AX_SUCCESS;
    if (pCtx == NULL || pstJpegParam == NULL) {
        return AX_ERR_VENC_NULL_PTR;
    }

    AX_S32 VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

    AX_JENC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	s32Ret = AXJencGetUserQpTable(&pHandle->jenc_encoder, &pstJpegParam->u32Qfactor,
									pstJpegParam->u8YQt, pstJpegParam->u8CbCrQt);
	if (s32Ret != JPEGENC_OK)
		s32Ret = AX_ERR_VENC_NULL_PTR;

	return s32Ret;

}

static AX_S32 JencEncodeOnceQualityParamCheck(const AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	AX_S32 i, j, k, length;

	i = j = k = length = 0;

	if (NULL == pstJpegParam) {
		VLOG_ERROR("Jenc: Invalid param null pointer.\n");
		return -1;
	}

	if ((pstJpegParam->u32Qfactor < 0) || (pstJpegParam->u32Qfactor > 99)) {
		VLOG_ERROR("Jenc : Invalid u32Qfactor(%d).\n", pstJpegParam->u32Qfactor);
		return -1;
	}

	length = sizeof(pstJpegParam->u8YQt) / sizeof(pstJpegParam->u8YQt[0]);

	for (i = 0; i < length; i++) {
		if(pstJpegParam->u8YQt[i] == 0)
			j++;
		if(pstJpegParam->u8CbCrQt[i] == 0)
			k++;
	}

	/* u8YQt table invalid */
	if ((j > 0) && (j < length)) {
		VLOG_ERROR("Jenc : Invalid u8YQt table.\n");
		return -1;
	}
	/* u8CbCrQt table invalid */
	if ((k > 0) && (k < length)) {
		VLOG_ERROR("Jenc : Invalid u8CbCrQt table.\n");
		return -1;
	}

	return 0;
}

static AX_S32 JpegEncodeOnceInit()
{
	AX_S32 s32Ret = -1;
	AX_JENC_HANDLE_S *pHandle = &gstJencEncodeOnceHandle;

	memset(pHandle, 0, sizeof(AX_JENC_HANDLE_S));

	JencDefaultParameter(pHandle);

	s32Ret = JencOpenEncoder(&pHandle->jenc_encoder, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("Jpeg Encode Once: open encoder error.\n");
		s32Ret = AX_ERR_VENC_NOT_INIT;
		goto ERR_OPEN_ENCODER;
	}

	s32Ret = JencEncodeOnceAllocRes(pHandle->jenc_encoder, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("Jpeg Encode Once: alloc res error.\n");
		s32Ret = AX_ERR_VENC_NOMEM;
		goto ERR_FREE_RES;
	}

	return AX_SUCCESS;

ERR_FREE_RES:
	JencCloseEncoder(pHandle->jenc_encoder, pHandle);

ERR_OPEN_ENCODER:
	return s32Ret;
}

static AX_S32 JpegEncodeOncePrepareFrameAddress(AX_JENC_HANDLE_S *pJencHandle, AX_JPEG_ENCODE_ONCE_PARAMS *pstJpegParam)
{
	JpegEncIn *pEncIn = &(pJencHandle->encIn);
	JpegEncInst encoder = pJencHandle->jenc_encoder;

	u64 lumaSize = 0;
	u64 chromaSize = 0;
	u64 u64FramePhyAddr[3] = {0};
	u64 u64FrameVirAddr[3] = {0};

	/* config frame buffer */
	AXJencGetLumaSize(encoder, &lumaSize);
	AXJencGetChromaSize(encoder, &chromaSize);

	for (int i = 0; i < 3; i++) {
		if (pstJpegParam->u64PhyAddr[i])
			u64FramePhyAddr[i] = pstJpegParam->u64PhyAddr[i] - VENC_ADDR_OFFSET;
		if (pstJpegParam->u64VirAddr[i])
			u64FrameVirAddr[i] = pstJpegParam->u64VirAddr[i];
	}

	VLOG_DEBUG("Get lumaSize:%d, chromaSize:%d \n", lumaSize, chromaSize);

	if (0 == u64FramePhyAddr[0]) {
		VLOG_ERROR("Frame physical address null \n");
		return -1;
	} else {
		pEncIn->busLum = u64FramePhyAddr[0];
		pEncIn->busCb = (0 == u64FramePhyAddr[1]) ? (pEncIn->busLum + lumaSize) : u64FramePhyAddr[1];
		pEncIn->busCr = (0 == u64FramePhyAddr[2]) ? (pEncIn->busCb + (chromaSize >> 1)) : u64FramePhyAddr[2];
	}

	if (0 == u64FrameVirAddr[0]) {
		pEncIn->pLum = 0;
		pEncIn->pCb = 0;
		pEncIn->pCr = 0;
	} else {
		pEncIn->pLum = ((u8 *)((u32)u64FrameVirAddr[0]));
		pEncIn->pCb = (0 == u64FrameVirAddr[1]) ? (pEncIn->pLum + lumaSize) : ((u8 *)((u32)u64FrameVirAddr[1]));
		pEncIn->pCr = (0 == u64FrameVirAddr[2]) ? (pEncIn->pCb + (chromaSize >>1 )) : ((u8 *)((u32)u64FrameVirAddr[2]));
	}

	if (pJencHandle->roimapMem.virtualAddress != NULL)
		pEncIn->busRoiMap = pJencHandle->roimapMem.busAddress;
	else
		pEncIn->busRoiMap = 0;

	VLOG_DEBUG("phy0 %lx, phy1 %lx, phy2 %lx \n", pEncIn->busLum, pEncIn->busCb, pEncIn->busCr);
	VLOG_DEBUG("vir0 %p, vir1 %p, vir2 %p \n", pEncIn->pLum, pEncIn->pCb, pEncIn->pCr);

	return 0;
}

static AX_BOOL JpegEncodeOnceUpdateJencConfig(AX_JENC_HANDLE_S *pJencHandle, AX_JPEG_ENCODE_ONCE_PARAMS *pstJpegParam)
{
	AX_JENC_HANDLE_S *pHandle = pJencHandle;
	JencCommandLine_s *pCmdl = &pHandle->stCmdl;
	JpegEncCfg *cfg = &pHandle->cfg;
	/* JpegEncFrameType imgFormat = JencImgFormat2FrameType(pstJpegParam->enImgFormat); */
	u64 lumaSize = 0;
	u64 chromaSize = 0;
	AX_U32 newStride = 0;
	/* AX_S32 newXOffset = 0; */
	/* AX_S32 newYOffset = 0; */
	/* AX_U32 newCodingWidth = 0; */
	/* AX_U32 newCodingHeight = 0; */

	cfg->inputWidth = pstJpegParam->u32Width;
	cfg->inputHeight = pstJpegParam->u32Height;
	cfg->codingWidth = pstJpegParam->u32Width;
	cfg->codingHeight = pstJpegParam->u32Height;
	cfg->frameType = pstJpegParam->enImgFormat;
	cfg->xDensity = 1;
	cfg->yDensity = 1;

	/* set crop */
	cfg->xOffset = pstJpegParam->s16OffsetLeft;
	cfg->yOffset = pstJpegParam->s16OffsetTop;
	AX_S16 cropW = pstJpegParam->s16OffsetRight - pstJpegParam->s16OffsetLeft + 1;
	AX_S16 cropH =  pstJpegParam->s16OffsetBottom - pstJpegParam->s16OffsetTop + 1;

	/* Note: if offsetLeft/offsetRight/OffsetTop/OffsetBottom are zero, just encode full pic default */
	if ((cropW >= MIN_JENC_PIC_WIDTH) && (cropW <= cfg->inputWidth))
		cfg->codingWidth = cropW;

	if ((cropH >= MIN_JENC_PIC_HEIGHT) && (cropH <= cfg->inputHeight))
		cfg->codingHeight = cropH;

	/* update stride[0] */
	newStride = pstJpegParam->u32PicStride[0];
	if(!newStride) {
		if (pstJpegParam->enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
			newStride = pstJpegParam->u32Width;
		else if (pstJpegParam->enImgFormat <= AX_YUV422_INTERLEAVED_UYVY)
			newStride = pstJpegParam->u32Width * 2;
	}

	if(cfg->picStride[0] != newStride) {
		VLOG_DEBUG("Jenc image stride[0] update from %d to %d\n", cfg->picStride[0], newStride);
		cfg->picStride[0] = newStride;
	}

	/* update stride[1] */
	newStride = pstJpegParam->u32PicStride[1];
	if(!newStride) {
		if (pstJpegParam->enImgFormat == AX_YUV420_PLANAR)
			newStride = cfg->picStride[0] / 2;
		else if (pstJpegParam->enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
			newStride = cfg->picStride[0];
	}

	if(cfg->picStride[1] != newStride) {
		VLOG_DEBUG("Jenc image stride[1] update from %d to %d\n", cfg->picStride[1], newStride);
		cfg->picStride[1] = newStride;
	}

	/* update stride[2] */
	newStride = pstJpegParam->u32PicStride[2];
	if(!newStride) {
		if (pstJpegParam->enImgFormat == AX_YUV420_PLANAR){
			newStride = cfg->picStride[0] / 2;
		}
	}

	if(cfg->picStride[2] != newStride) {
		VLOG_DEBUG("Jenc image stride[2] update from %d to %d\n", cfg->picStride[2], newStride);
		cfg->picStride[2] = newStride;
	}

	pJencHandle->u32PicStride[0] = cfg->picStride[0];
	pJencHandle->u32PicStride[1] = cfg->picStride[1];
	pJencHandle->u32PicStride[2] = cfg->picStride[2];

	switch(cfg->frameType)
	{
	case JPEGENC_YUV420_PLANAR:
	case JPEGENC_YVU420_PLANAR:
		lumaSize = cfg->picStride[0] * cfg->inputHeight;
		chromaSize = cfg->picStride[1] * cfg->inputHeight;
		break;
	case JPEGENC_YUV420_SEMIPLANAR:
	case JPEGENC_YUV420_SEMIPLANAR_VU:
		lumaSize = cfg->picStride[0] * cfg->inputHeight;
		chromaSize = cfg->picStride[1] * cfg->inputHeight / 2;
		break;
	default:
		VLOG_ERROR("Jpeg invalid frame format(%d).\n", cfg->frameType);
		return false;
	}

	AXJencSetLumaSize(pJencHandle->jenc_encoder, lumaSize);
	AXJencSetChromaSize(pJencHandle->jenc_encoder, chromaSize);

	return true;
}

static AX_S32 JpegEncodeOnceParamCheck(AX_JPEG_ENCODE_ONCE_PARAMS *pstJpegParam)
{
	if (NULL == pstJpegParam) {
		VLOG_ERROR("Jpeg Encode Once: Invalid pstJpegParam.\n");
		return -1;
	}

	AX_U64 u64InPhyAddr[3];
	AX_U64 u64OutPhyAddr;
	AX_S32 s32StrmLen;
	AX_S32 s32Ret = -1;
	AX_S16 s16OffsetLeft, s16OffsetTop;
	AX_S16 s16OffsetRight, s16OffsetBottom;
	AX_U32 u32PicStride[3];
	AX_S16 s16CropW = -1;
	AX_S16 s16CropH = -1;

	/* frame info */
	AX_S32 width = pstJpegParam->u32Width;
	AX_S32 height = pstJpegParam->u32Height;
	AX_IMG_FORMAT_E	enImgFormat = pstJpegParam->enImgFormat;

	s16OffsetLeft = pstJpegParam->s16OffsetLeft;
	s16OffsetTop = pstJpegParam->s16OffsetTop;
	s16OffsetRight = pstJpegParam->s16OffsetRight;
	s16OffsetBottom = pstJpegParam->s16OffsetBottom;

	for (int i = 0; i < 3; i++) {
		u64InPhyAddr[i] = pstJpegParam->u64PhyAddr[i];
		u32PicStride[i] = pstJpegParam->u32PicStride[i];
	}

	if (0 == u64InPhyAddr[0]) {
		VLOG_ERROR("Jpeg Encode Once: Invalid frame buffer, u64PhyAddr[0]=0.\n");
		return -1;
	}

	if (width < MIN_JENC_PIC_WIDTH || width > MAX_JENC_PIC_WIDTH) {
		VLOG_ERROR("Jpeg Encode Once: width %d out of range[%d, %d].\n",
				width, MIN_JENC_PIC_WIDTH, MAX_JENC_PIC_WIDTH);
		return -1;
	}

	if (height < MIN_JENC_PIC_HEIGHT || height > MAX_JENC_PIC_HEIGHT) {
		VLOG_ERROR("Jpeg Encode Once: height %d out of range[%d, %d].\n",
				height, MIN_JENC_PIC_HEIGHT, MAX_JENC_PIC_HEIGHT);
		return -1;
	}

	/* offsetLeft and offsetTop must be even */
	if ((s16OffsetLeft & 1) != 0 || (s16OffsetTop & 1) != 0) {
		VLOG_ERROR("Jpeg Encode Once: OffsetX=%d or OffsetY=%d must be even.\n",
			s16OffsetLeft,
			s16OffsetTop);
		return -1;
	}
	/* offsetLeft rang in [0, w) */
	if ((s16OffsetLeft < 0) || (s16OffsetLeft > (width-1) )) {
		VLOG_ERROR("Jpeg Encode Once: Invalid s16OffsetLeft=%d, should range in [0, %u).\n",
			s16OffsetLeft,
			width);
		return -1;
	}
	/* offsetRight rang in [0, w) */
	if ( (s16OffsetRight < 0) || (s16OffsetRight > (width-1) ) ) {
		VLOG_ERROR("Jpeg Encode Once: Invalid s16OffsetRight=%d, should range in [0, %u).\n",
			s16OffsetRight,
			width);
		return -1;
	}
	/* offsetTop rang in [0, h) */
	if ((s16OffsetTop < 0) || (s16OffsetTop > (height-1) )) {
		VLOG_ERROR("Jpeg Encode Once: Invalid s16OffsetTop=%d, should range in [0, %u).\n",
			s16OffsetTop,
			height);
		return -1;
	}
	/* offsetBottom rang in [0, h) */
	if ( (s16OffsetBottom < 0) || (s16OffsetBottom > (height-1) ) ) {
		VLOG_ERROR("Jpeg Encode Once: Invalid s16OffsetBottom=%d, should range in [0, %u).\n",
			s16OffsetBottom,
			height);
		return -1;
	}

	/*  when offsetLeft/offsetRight/offsetTop/OffsetBottom are zero, just encode full picture. so don't return error
	 */
	if ( !((0==s16OffsetLeft) && (0==s16OffsetRight) && (0==s16OffsetTop) && (0==s16OffsetBottom)) ) {
		if ((s16OffsetRight <= s16OffsetLeft) || (s16OffsetBottom <= s16OffsetTop)) {
			VLOG_ERROR("Jpeg Encode Once: s16OffsetRight(%d) <= s16OffsetLeft(%d) or s16OffsetBottom(%d) <= s16OffsetTop(%d).\n",
				s16OffsetRight,
				s16OffsetLeft,
				s16OffsetBottom,
				s16OffsetTop);
			return -1;
		}

		s16CropW = s16OffsetRight - s16OffsetLeft + 1;
		if ((s16CropW & 1) != 0) {
			VLOG_ERROR("Jpeg Encode Once: crop width(%d) must be even, width(%d), s16OffsetRight(%d), s16OffsetLeft(%d).\n",
				s16CropW,
				width,
				s16OffsetRight,
				s16OffsetLeft);
			return -1;
		}
		if (s16CropW < MIN_JENC_PIC_WIDTH || s16CropW > width) {
			VLOG_ERROR("Jpeg Encode Once: crop width(%d) out of range[%d, %d].\n",
				s16CropW,
				MIN_JENC_PIC_WIDTH,
				width);
			return -1;
		}

		s16CropH = s16OffsetBottom - s16OffsetTop + 1;
		if ((s16CropH & 1) != 0) {
			VLOG_ERROR("Jpeg Encode Once: crop Height(%d) must be even, height(%d), s16OffsetTop(%d), s16OffsetBottom(%d).\n",
				s16CropH,
				height,
				s16OffsetTop,
				s16OffsetBottom);
			return -1;
		}
		if (s16CropH < MIN_JENC_PIC_HEIGHT || s16CropH > height) {
			VLOG_ERROR("Jpeg Encode Once: crop height(%d) out of range[%d, %d].\n",
				s16CropH,
				MIN_JENC_PIC_HEIGHT,
				height);
			return -1;
		}
	}

	if (u32PicStride[0] && (u32PicStride[0] < width)) {
		VLOG_ERROR("Jpeg Encode Once: strid0(%d) less than width(%d).\n",
			u32PicStride[0], width);
		return -1;
	}
	/* frame format and stride check */
	switch (enImgFormat)
	{
	case AX_YUV420_PLANAR:
		if ( (0 < u32PicStride[1]) && ( u32PicStride[1] < (width/2) ) ) {
			VLOG_ERROR("Jpeg Encode Once: strid1(%d) less than width/2(%d).\n",
				u32PicStride[1], width/2);
			return -1;
		}
		if ( (0 < u32PicStride[2]) && ( u32PicStride[2] < (width/2) ) ) {
			VLOG_ERROR("Jpeg Encode Once: strid2(%d) less than width/2(%d).\n",
				u32PicStride[2], width/2);
			return -1;
		}
		break;
	case AX_YUV420_SEMIPLANAR:
	case AX_YUV420_SEMIPLANAR_VU:
		if ( (0 < u32PicStride[1]) && ( u32PicStride[1] < width ) ) {
			VLOG_ERROR("Jpeg Encode Once: strid1(%d) less than width(%d).\n",
				u32PicStride[1], width);
			return -1;
		}
		break;
	default:
		VLOG_ERROR("Jpeg Encode Once: Invalid image format(%d).\n", enImgFormat);
		return -1;
	}

	/* stream info */
	u64OutPhyAddr = pstJpegParam->ulPhyAddr;
	s32StrmLen = pstJpegParam->u32Len;

	if (0 == u64OutPhyAddr) {
		VLOG_ERROR("Jpeg Encode Once: Invalid stream buffer, u64PhyAddr[0]=0.\n");
		return -1;
	}

	if (s32StrmLen <= 0) {
		VLOG_ERROR("Jpeg Encode Once: Invalid stream buffer size(%d).\n", s32StrmLen);
		return -1;
	}

	/* qFactor and qpTable params check */
	s32Ret = JencEncodeOnceQualityParamCheck(&pstJpegParam->stJpegParam);
	if (s32Ret) {
		VLOG_ERROR("Jpeg Encode Once: Invalid qFactor or qpTable params.\n");
		return -1;
	}

	return 0;
}

static AX_S32 JpegEncodeOnce(AX_JPEG_ENCODE_ONCE_PARAMS *pstJpegParam)
{
	AX_JENC_HANDLE_S *pHandle = &gstJencEncodeOnceHandle;
	JpegEncIn *pEncIn = &(pHandle->encIn);
	JpegEncInst encoder = pHandle->jenc_encoder;
	JpegEncOut encOut;
	JpegEncRet ret;
	int s32Ret = -1;
	u64 phyAddr = 0;
	i32 cacheType = 0;
	i32 picBytes = 0;
	i32 slice = 0;

	i32 picCnt = 0;
	/* u32 total_bits = 0; */
	/* Jenc_ma_s ma; */

	pEncIn->frameHeader = 1;
	pEncIn->filter = NULL;
	pEncIn->axiFEEnable = 0;
	pEncIn->fbdcInfo.enableFBDC = false;

	if (NULL == pstJpegParam) {
		VLOG_ERROR("Jpeg invalid pstJpegParam, null pointer.\n");
		return AX_ERR_VENC_NULL_PTR;
	}

	s32Ret = JpegEncodeOnceParamCheck(pstJpegParam);
	if (s32Ret) {
		VLOG_ERROR("JpegEncodeOnceParamCheck error, ret=%d.\n", s32Ret);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	JpegEncodeOnceUpdateJencConfig(pHandle, pstJpegParam);

	JpegEncodeOncePrepareFrameAddress(pHandle, pstJpegParam);

	s32Ret = AXJencSetUserQpTable(&pHandle->jenc_encoder, pstJpegParam->stJpegParam.u32Qfactor,
					pstJpegParam->stJpegParam.u8YQt, pstJpegParam->stJpegParam.u8CbCrQt);
	if (s32Ret != JPEGENC_OK) {
		VLOG_ERROR("AXJencSetUserQpTable error, ret=%d.\n", ret);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	pHandle->frameCntTotal++;

	ret = AXJencSetPictureSize(encoder, &pHandle->cfg);
	if(ret != JPEGENC_OK) {
		VLOG_ERROR("JencSetPictureSize ret:%d \n", ret);
		return AX_ERR_VENC_NOT_MATCH;
	}

	/* set output buffer */
	pEncIn->busOutBuf[0] = pstJpegParam->ulPhyAddr - VENC_ADDR_OFFSET;
	pEncIn->pOutBuf[0] = pstJpegParam->pu8Addr;
	pEncIn->outBufSize[0] = pstJpegParam->u32Len;

	ret = AXJencEncode(encoder, pEncIn, &encOut);
	switch (ret) {
	case JPEGENC_RESTART_INTERVAL:
		picBytes += encOut.jfifSize;
		slice++;    /* Encode next slice */
		VLOG_ERROR("Jpeg encode fail. ret= %d.\n", ret);
		return AX_ERR_VENC_NOT_PERMIT;
	case JPEGENC_FRAME_READY:
		s32Ret = AX_SYS_MemGetBlockInfoByVirt(pstJpegParam->pu8Addr, &phyAddr, &cacheType);
		if (cacheType == AX_MEM_CACHED) {
			s32Ret = AX_SYS_MinvalidateCache(phyAddr, pstJpegParam->pu8Addr, encOut.jfifSize);
			if (s32Ret) {
				VLOG_ERROR("AX_SYS_MinvalidateCache(phyaddr:%#llx,viraddr:%#llx,size:%d) ret=0x%x.\n",
					pstJpegParam->ulPhyAddr, pstJpegParam->u64VirAddr, pstJpegParam->u32Len);
			}
		}

		pstJpegParam->ulPhyAddr = pEncIn->busOutBuf[0] + VENC_ADDR_OFFSET;
		pstJpegParam->pu8Addr = (unsigned char *)pEncIn->pOutBuf[0];
		pstJpegParam->u32Len = encOut.jfifSize;
		VLOG_DEBUG("JENC : encoded:  phyAddr=%lx, vir_addr=%p, packetSize=%d.\n",
			pstJpegParam->ulPhyAddr, pstJpegParam->pu8Addr, pstJpegParam->u32Len);

		picCnt++;

		VLOG_DEBUG("=== Encoded %i bits=%d HWCycles=%d Time(us %d HW +SW) \n",
			picCnt, encOut.jfifSize, JencGetPerformance(encoder), uJencTimeDiff(pHandle->timeFrameEnd,
			pHandle->timeFrameStart));

		picBytes = 0;
		slice = 0;
		break;
	case JPEGENC_OUTPUT_BUFFER_OVERFLOW:
		picBytes = 0;
		slice = 0;
		VLOG_ERROR("Jpeg encode fail, buffer overflow, ret= %d.\n", ret);
		return AX_ERR_VENC_NOT_SUPPORT;
	default:
		VLOG_ERROR("Jpeg encode fail, unknow error, ret= %d.\n", ret);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	return AX_SUCCESS;
}

static AX_S32 JpegEncodeOnceDeinit()
{
	AX_S32 s32Ret;

	AX_JENC_HANDLE_S *pHandle = &gstJencEncodeOnceHandle;

	JencEncodeOnceFreeRes(pHandle->jenc_encoder, pHandle);

	s32Ret = JencCloseEncoder(pHandle->jenc_encoder, pHandle);


	return s32Ret;
}

AX_VENC_ENCODER_S gJencEncoder = {
	.enType = PT_JPEG,
	.pfnCreateChn = JencCreateChn,
	.pfnDestroyChn = JencDestroyChn,

	.pfnSendFrame = JencSendFrame,
	.pfnSendFrameEx = JencSendFrameEx,

	.pfnGetStream = JencGetStream,
	.pfnReleaseStream = JencReleaseStream,

	.pfnStartRecvFrame = JencStartRecvFrame,
	.pfnStopRecvFrame = JencStopRecvFrame,

#if 0
	.pfnSetOsdLayer = JencSetOsdLayer,
	.pfnRefreshOsdLayer = JencRefreshOsdLayer,
	.pfnResetOsd = JencResetOsd,
#endif

	.pfnSetRoiAttr = JencSetRoiAttr,
	.pfnGetRoiAttr = JencGetRoiAttr,

	.pfnSetRcParam = JencSetRcParam,
	.pfnGetRcParam = JencGetRcParam,

	.pfnSetChnAttr = JencSetChnAttr,
	.pfnGetChnAttr = JencGetChnAttr,

	.pfnInsertUserData = JencInsertUserData,
	.pfnRequestIDR = JencRequestIDR,
	.pfnQueryStatus = JencQueryStatus,

	.pfnUpdateFpsBr = JencUpdateFpsBr,  // update realtime frame rate and bit rate

	.pfnSetRateJamStrategyParam = JencSetRateJamStrategyParam,
	.pfnGetRateJamStrategyParam = JencGetRateJamStrategyParam,

	.pfnSetJpegParam = JencSetJpegParam,
	.pfnGetJpegParam = JencGetJpegParam,

	.pfnJpegEncodeOnceInit = JpegEncodeOnceInit,
	.pfnJpegEncodeOnceDeinit = JpegEncodeOnceDeinit,
	.pfnJpegEncodeOnce = JpegEncodeOnce
};
