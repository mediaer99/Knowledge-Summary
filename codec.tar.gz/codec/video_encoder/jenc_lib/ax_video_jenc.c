
#include "ax_video_jenc.h"
#include "jenc_hevcencapi.h"
#include "ax_venc_log.h"
#include "jenc_ewl.h"
#include "ax_utils.h"

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)

#define DEBUG_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_jenc.c %s %d "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_jenc.c %s %d Error! "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define PTRACE(...)  /* no trace */
// #define PTRACE(str, arg...) do{printf("    tid:%ld ewl.c %s %d "str"\n", gettid(), __func__, __LINE__, ##arg);}while(0)



// static inputLineBufferCfg inputMbLineBuf;

#ifndef QP_FRACTIONAL_BITS
#ifndef CTBRC_STRENGTH
#define QP_FRACTIONAL_BITS  0
#else
#define QP_FRACTIONAL_BITS  8
#endif
#endif

extern u32 JencEncAsicGetAsicHWid(u32 client_type, void *ctx);

#if 0
AX_S32 JencEncodeHeader(AX_JENC_HANDLE_S *tb)
{
    JpegEncIn *pEncIn = &(tb->encIn);
    JpegEncOut encOut;

    SetupOutputBuffer(tb, pEncIn);

    tb->validencodedframenumber = 0;
    tb->ma.pos = tb->ma.count = 0;
    tb->ma.frameRateNumer = tb->outputRateNumer;
    tb->ma.frameRateDenom = tb->outputRateDenom;
    if (tb->outputRateDenom)
        tb->ma.length = MAX(LEAST_MONITOR_FRAME, MIN(tb->monitorFrames, MOVING_AVERAGE_FRAMES));
    else
        tb->ma.length = MOVING_AVERAGE_FRAMES;

    InitPicConfig(pEncIn, tb);

    // if (tb->sendAUD)
    //     pEncIn->sendAUD = 1;

    /* Video, sequence and picture parameter sets */
    // for (int p = 0; p < 1; p++) {
    //     if (VCEncStrmStart(tb->jenc_encoder, pEncIn, &encOut)) {
    //         printf("hevc_set_parameter() fails\n");
    //     }

    //     VCEncStrmBufs bufs;
    //     getStreamBufs (&bufs, tb, HANTRO_FALSE);

    //     JencWriteStrmBufs(tb->out, &bufs, 0, encOut.streamSize, 0);

    //     tb->total_bits += encOut.streamSize * 8;
    //     tb->streamSize += encOut.streamSize;
    // }

    // tb->nextCodingType = VCENC_INTRA_FRAME;
    // VCEncGetRateCtrl(tb->jenc_encoder, &tb->rc);

    return 0;
}
#endif

AX_S32 JencEncodeEnd(AX_JENC_HANDLE_S *pJencHandle)
{
    //JpegEncIn *pEncIn = &(pJencHandle->encIn);
    //JpegEncOut encOut;
    //int ret;

    //SetupOutputBuffer(pJencHandle, pEncIn);

    // ret = VCEncStrmEnd(tb->jenc_encoder, pEncIn, &encOut);
    // if (ret == VCENC_OK)
    // {
    //     VCEncStrmBufs bufs;
    //     getStreamBufs (&bufs, tb, HANTRO_FALSE);

    //     JencWriteStrmBufs(tb->out, &bufs, 0, encOut.streamSize, 0);
    //     tb->streamSize += encOut.streamSize;
    // }

    // printf("Total of %d frames processed, %d frames encoded, %lu bytes, maxSliceBytes=%d\n",
                //  tb->frameCntTotal, tb->picture_enc_cnt - (tb->frame_delay-1), (long unsigned int)tb->streamSize, tb->maxSliceSize);
    return 0;
}

// Helper function to calculate time diffs.
unsigned int uJencTimeDiff(struct timeval end, struct timeval start)
{
   return (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec);
}

static AX_S32 PrepareFrameAddress(AX_JENC_HANDLE_S *pJencHandle, AX_VIDEO_FRAME_INFO_S stFrameInfo)
{
    JpegEncIn *pEncIn = &(pJencHandle->encIn);
    JpegEncInst encoder = pJencHandle->jenc_encoder;

    u64 lumaSize = 0;
    u64 chromaSize = 0;

    //config frame buffer
    AXJencGetLumaSize(encoder, &lumaSize);
    AXJencGetChromaSize(encoder, &chromaSize);

    VLOG_DEBUG("Get lumaSize:%d, chromaSize:%d \n", lumaSize, chromaSize);

    if (!stFrameInfo.stVFrame.u64PhyAddr[0]) {
        VLOG_ERROR("Frame physical address null \n");
        return AX_ERR_VENC_ILLEGAL_PARAM;
    } else {
        pEncIn->busLum = stFrameInfo.stVFrame.u64PhyAddr[0];
    }

    if (!stFrameInfo.stVFrame.u64PhyAddr[1]) {
        pEncIn->busCb = pEncIn->busLum + lumaSize;
    } else {
        pEncIn->busCb = stFrameInfo.stVFrame.u64PhyAddr[1];
    }

    if (!stFrameInfo.stVFrame.u64PhyAddr[2]) {
        pEncIn->busCr = pEncIn->busCb + chromaSize/2;
    } else {
        pEncIn->busCr = stFrameInfo.stVFrame.u64PhyAddr[2];
    }

    // FBDC_ENABLE
    if(stFrameInfo.stVFrame.enCompressMode == AX_COMPRESS_MODE_TILE) {
        pEncIn->fbdcInfo.enableFBDC = true;
        pEncIn->fbdcInfo.width = stFrameInfo.stVFrame.u32Width;
        if ((stFrameInfo.stVFrame.s16OffsetRight > 0) && (stFrameInfo.stVFrame.s16OffsetBottom > 0)) {
            pEncIn->fbdcInfo.width = stFrameInfo.stVFrame.s16OffsetRight - stFrameInfo.stVFrame.s16OffsetLeft;
        }
        pEncIn->fbdcInfo.cropX = stFrameInfo.stVFrame.s16OffsetLeft;
        pEncIn->fbdcInfo.cropY = stFrameInfo.stVFrame.s16OffsetTop;
        pEncIn->busLum = stFrameInfo.stVFrame.u64PhyAddr[0];
        pEncIn->busCb = stFrameInfo.stVFrame.u64PhyAddr[1];
        VLOG_DEBUG("config fbdcinfo locked by PID %d,yadd=%llx,uvaddr=%llx,w=%d\n",
            getpid(), pEncIn->busLum, pEncIn->busCb , pEncIn->fbdcInfo.width);
    } else {
        pEncIn->fbdcInfo.enableFBDC = false;
    }

    /* Virtual addresses of input picture, used by software encoder */

    pEncIn->pLum = (u8 *)((u32)stFrameInfo.stVFrame.u64VirAddr[0]);

    if (!pEncIn->pLum) {
        pEncIn->pCb = 0;
        pEncIn->pCr = 0;
    } else {
        if (!stFrameInfo.stVFrame.u64VirAddr[1]) {
            pEncIn->pCb = pEncIn->pLum + lumaSize;
        } else {
            pEncIn->pCb = (u8 *)((u32)stFrameInfo.stVFrame.u64VirAddr[1]);
        }
        if (!stFrameInfo.stVFrame.u64PhyAddr[2]) {
            pEncIn->pCr = pEncIn->pCb + chromaSize/2;
        } else {
            pEncIn->pCr = (u8 *)((u32)stFrameInfo.stVFrame.u64VirAddr[2]);
        }
    }

    if (pJencHandle->roimapMem.virtualAddress != NULL) {
        pEncIn->busRoiMap = pJencHandle->roimapMem.busAddress;
    } else {
        pEncIn->busRoiMap = 0;
    }
    VLOG_DEBUG("phy0 %lx, phy1 %lx, phy2 %lx \n", pEncIn->busLum, pEncIn->busCb, pEncIn->busCr);
    VLOG_DEBUG("vir0 %p, vir1 %p, vir2 %p \n", pEncIn->pLum, pEncIn->pCb, pEncIn->pCr);

    return 0;
}


static AX_BOOL UpdateJencConfig(AX_JENC_HANDLE_S *pJencHandle, AX_VIDEO_FRAME_INFO_S stFrameInfo)
{
    AX_JENC_HANDLE_S *pHandle = pJencHandle;
    AX_VIDEO_FRAME_S stFrame = stFrameInfo.stVFrame;
    JencCommandLine_s *pCmdl = &pHandle->stCmdl;
    JpegEncCfg *cfg = &pHandle->cfg;
    AX_BOOL isUpdata = AX_FALSE;
    JpegEncFrameType imgFormat = JencImgFormat2FrameType(stFrame.enImgFormat);
    u64 lumaSize = 0;
    u64 chromaSize = 0;
    AX_U32 newStride = 0;
    AX_S32 newXOffset = 0;
    AX_S32 newYOffset = 0;
    AX_U32 newCodingWidth = 0;
    AX_U32 newCodingHeight = 0;

    if (cfg->frameType != imgFormat) {
        VLOG_DEBUG("Jenc image format update to %d\n", stFrame.enImgFormat);
        cfg->frameType = imgFormat;
        isUpdata = AX_TRUE;
    }

    if (cfg->inputWidth != stFrame.u32Width) {
        cfg->inputWidth = stFrame.u32Width;
        VLOG_DEBUG("Jenc image width update to %d\n", cfg->inputWidth);
        isUpdata = AX_TRUE;
    }
    if (cfg->inputHeight != stFrame.u32Height) {
        cfg->inputHeight = stFrame.u32Height;
        VLOG_DEBUG("Jenc image height update to %d\n", cfg->inputHeight);
        isUpdata = AX_TRUE;
    }

    if(pCmdl->dynamicCropEnable){ //use crop parameters in frame info
        newXOffset = stFrame.s16OffsetLeft;
        newYOffset = stFrame.s16OffsetTop;
        newCodingWidth = stFrame.s16OffsetRight - stFrame.s16OffsetLeft;
        newCodingHeight = stFrame.s16OffsetBottom - stFrame.s16OffsetTop;
    }else{ //use crop parameters in channel attribute
        newXOffset = pCmdl->horOffsetSrc;
        newYOffset = pCmdl->verOffsetSrc;
        newCodingWidth = pCmdl->output_width;
        newCodingHeight = pCmdl->output_height;
    }

    if(cfg->xOffset != newXOffset)
    {
        VLOG_DEBUG("Jenc image crop xOffset update from %d to %d\n",cfg->xOffset,newXOffset);
        cfg->xOffset = newXOffset;
        isUpdata = AX_TRUE;
    }

    if(cfg->yOffset != newYOffset)
    {
        VLOG_DEBUG("Jenc image crop yOffset update from %d to %d\n",cfg->yOffset,newYOffset);
        cfg->yOffset = newYOffset;
        isUpdata = AX_TRUE;
    }

    if(!newCodingWidth)
        newCodingWidth = stFrame.u32Width;

    if(cfg->codingWidth != newCodingWidth)
    {
        VLOG_DEBUG("Jenc image crop codingWidth update from %d to %d\n",cfg->codingWidth,newCodingWidth);
        cfg->codingWidth = newCodingWidth;
        isUpdata = AX_TRUE;
    }

    if(!newCodingHeight)
        newCodingHeight = stFrame.u32Height;

    if(cfg->codingHeight != newCodingHeight)
    {
        VLOG_DEBUG("Jenc image crop codingHeight update from %d to %d\n",cfg->codingHeight,newCodingHeight);
        cfg->codingHeight = newCodingHeight;
        isUpdata = AX_TRUE;
    }

    if(cfg->rotation == JPEGENC_ROTATE_90R || cfg->rotation == JPEGENC_ROTATE_90L){
        cfg->xOffset = newYOffset;
        cfg->yOffset = newXOffset;
        cfg->codingWidth = newCodingHeight;
        cfg->codingHeight = newCodingWidth;
        cfg->xDensity = pCmdl->ydensity;
        cfg->yDensity = pCmdl->xdensity;
        VLOG_DEBUG("Jenc image rotation is %d\n",cfg->rotation);
    }

    /* update stride[0] */
    newStride = stFrame.u32PicStride[0];
    if(!newStride)
    {
        if (stFrame.enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
            newStride = stFrame.u32Width;
        else if (stFrame.enImgFormat <= AX_YUV422_INTERLEAVED_UYVY)
            newStride = stFrame.u32Width * 2;
    }

    if(cfg->picStride[0] != newStride)
    {
        VLOG_DEBUG("Jenc image stride[0] update from %d to %d\n",cfg->picStride[0],newStride);
        cfg->picStride[0] = newStride;
        isUpdata = AX_TRUE;
    }

    /* update stride[1] */
    newStride = stFrame.u32PicStride[1];
    if(!newStride)
    {
        if (stFrame.enImgFormat == AX_YUV420_PLANAR)
            newStride = cfg->picStride[0] / 2;
        else if (stFrame.enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
            newStride = cfg->picStride[0];
    }

    if(cfg->picStride[1] != newStride)
    {
        VLOG_DEBUG("Jenc image stride[1] update from %d to %d\n",cfg->picStride[1],newStride);
        cfg->picStride[1] = newStride;
        isUpdata = AX_TRUE;
    }

    /* update stride[2] */
    newStride = stFrame.u32PicStride[2];
    if(!newStride)
    {
        if (stFrame.enImgFormat == AX_YUV420_PLANAR){
            newStride = cfg->picStride[0] / 2;
        }
    }

    if(cfg->picStride[2] != newStride)
    {
        VLOG_DEBUG("Jenc image stride[2] update from %d to %d\n",cfg->picStride[2],newStride);
        cfg->picStride[2] = newStride;
        isUpdata = AX_TRUE;
    }

    pJencHandle->u32PicStride[0] = cfg->picStride[0];
    pJencHandle->u32PicStride[1] = cfg->picStride[1];
    pJencHandle->u32PicStride[2] = cfg->picStride[2];

    if (isUpdata) {
        switch(cfg->frameType)
        {
        case JPEGENC_YUV420_PLANAR:
        case JPEGENC_YVU420_PLANAR:
            lumaSize = cfg->picStride[0] * cfg->inputHeight;
            chromaSize = cfg->picStride[1] * cfg->inputHeight;
            break;
        case JPEGENC_YUV420_SEMIPLANAR:
        case JPEGENC_YUV420_SEMIPLANAR_VU:
            lumaSize = cfg->picStride[0] * cfg->inputHeight;
            chromaSize = cfg->picStride[1] * cfg->inputHeight / 2;
            break;
         default:
            break;
        }
        AXJencSetLumaSize(pJencHandle->jenc_encoder, lumaSize);
        AXJencSetChromaSize(pJencHandle->jenc_encoder, chromaSize);
    }

    return isUpdata;
}

AX_S32 JencRateJamProcess(JpegEncInst JencInst, AX_JENC_HANDLE_S *pHandle, AX_S32 VeChn)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)JencInst;
	if (pChnInst->u64InstantaneousBitRate > pHandle->stCmdl.stRateJamStrategyParam.u32DropFrmThrBps)
	{
		if (DROPFRM_NORMAL == pHandle->stCmdl.stRateJamStrategyParam.enDropFrmMode)
		{
			while (1)
			{
				if (pHandle->stCmdl.stRateJamStrategyParam.u32MaxApplyCount == 0)
				{
					return -1;
				}
				if (pHandle->stCmdl.dropFrameCnt < pHandle->stCmdl.stRateJamStrategyParam.u32MaxApplyCount)
				{
					VLOG_DEBUG("VencChn %d: instant bitrate: %llu exceed the threshold, discard it...\n",
						  VeChn,
						  pChnInst->u64InstantaneousBitRate);

					pHandle->stCmdl.dropFrameCnt++;
					return -1;
				}

				pHandle->stCmdl.dropFrameCnt = 0;
				break;
			}
		}
	}
	else
	{
		pHandle->stCmdl.dropFrameCnt = 0;
	}

	return AX_SUCCESS;
}


AX_S32 JencProcess(int ChnId, AX_JENC_HANDLE_S *pJencHandle, AX_ENCODR_METADATA_INFO_S in, AX_ENCODR_METADATA_INFO_S *out)
{
    AX_JENC_HANDLE_S *pHandle = pJencHandle;
    JpegEncIn *pEncIn = &(pJencHandle->encIn);
    JencCommandLine_s *pCmdl = &pJencHandle->stCmdl;
    JpegEncInst encoder = pJencHandle->jenc_encoder;
    JpegEncOut encOut;
    VCEncRet ret;
    /* i32 encRet = NOK; */

    i32 picBytes = 0;
    i32 slice = 0;

    /* u32 mjpeg_length = 0; */
    /* u32 mjpeg_movi_idx = 0; */
    /* IDX_CHUNK * idx = NULL; */
    i32 picCnt = 0;
    /* u32 total_bits = 0; */
    /* long numbersquareoferror = 0; */
    /* float sumsquareoferror = 0; */
    /* int encodeFail = 0; */
    /* float averagesquareoferror = 0; */
    /* Jenc_ma_s ma; */
    /* i32 maxerrorovertarget = 0; */
    /* i32 maxerrorundertarget = 0; */
    bool is_update = 0;

    /* int filter_ret = 0; */

    pEncIn->frameHeader = 1;
    pEncIn->filter = NULL;
    //for VC8000EJ test bench, disable axiFE by default
    pEncIn->axiFEEnable = 0;

    is_update = UpdateJencConfig(pHandle, in.inputFrameInfo.stFrameInfo);
    VLOG_DEBUG("Jenc config update status: %d \n", is_update);

    PrepareFrameAddress(pJencHandle, in.inputFrameInfo.stFrameInfo);

    pHandle->frameCntTotal++;

    /*if mjpeg is enabled, assemble mjpeg container header*/
    if (pCmdl->mjpeg == AX_TRUE) {
#if 0 // MJPEG AVIHeader is not used. AX620SW-4174
        ma.pos = ma.count = 0;
        ma.frameRateNumer = pCmdl->frameRateNum;
        ma.frameRateDenom = pCmdl->frameRateDenom;

        ma.length = MOVING_AVERAGE_FRAMES;
        pJencHandle->outbufMem[0].virtualAddress = pJencHandle->encIn.pOutBuf[0];

        mjpeg_length = MjpegEncodeAVIHeader(pJencHandle->outbufMem[0].virtualAddress,
            pJencHandle->cfg.codingWidth, pJencHandle->cfg.codingHeight,
            pCmdl->frameRateNum, pCmdl->frameRateDenom, pCmdl->lastPic - pCmdl->firstPic + 1);

        mjpeg_movi_idx = mjpeg_length + 4;
        u32 * output_buf = pJencHandle->outbufMem[0].virtualAddress;
        MjpegAVIchunkheader((u8 **)&output_buf, "LIST", "movi", 0);

        mjpeg_length += 12;
        idx = malloc((pCmdl->lastPic - pCmdl->firstPic + 1) * sizeof(IDX_CHUNK));
#endif
    }

    ret = AXJencSetPictureSize(encoder, &pHandle->cfg);
    /* Handle error situation */
    if(ret != (VCEncRet)JPEGENC_OK) {
        VLOG_ERROR("JencSetPictureSize ret:%d \n", ret);
#if 0
        if (pCmdl->mjpeg == AX_TRUE) {
            free(idx);
        }
#endif
        return ret;
    }

    gettimeofday(&pHandle->timeFrameStart, NULL);
    ret = AXJencEncode(encoder, pEncIn, &encOut);

    gettimeofday(&pHandle->timeFrameEnd, NULL);

    switch (ret) {
    case JPEGENC_RESTART_INTERVAL:
        picBytes += encOut.jfifSize;
        slice++;    /* Encode next slice */
        break;
    case JPEGENC_FRAME_READY:
        if (pCmdl->inputLineBufMode)
            VCEncUpdateInitSegNum(&pJencHandle->inputMbLineBuf);

        gettimeofday(&pHandle->timeFrameEnd, NULL);

        // out->outputStreamInfo.enCodingType = pEncIn->codingType;
        out->outputStreamInfo.stPackage.enType = pCmdl->mjpeg == AX_TRUE? PT_MJPEG : PT_JPEG;
        out->outputStreamInfo.stPackage.ulPhyAddr = pEncIn->busOutBuf[0];
        out->outputStreamInfo.stPackage.pu8Addr = (unsigned char *)pEncIn->pOutBuf[0];
        out->outputStreamInfo.stPackage.u32Len = encOut.jfifSize;
        out->outputStreamInfo.stPackage.u64PTS = in.inputFrameInfo.stFrameInfo.stVFrame.u64PTS;
        out->outputStreamInfo.stPackage.u64SeqNum = in.inputFrameInfo.stFrameInfo.stVFrame.u64SeqNum;
        out->outputStreamInfo.stPackage.u64UserData = in.inputFrameInfo.stFrameInfo.stVFrame.u64UserData;
        VLOG_DEBUG("JENC chnId:%d: encoded: encode type %d, phyAddr=%lx, vir_addr=%p, packetSize=%d.\n",
            ChnId, out->outputStreamInfo.stPackage.enCodingType, out->outputStreamInfo.stPackage.ulPhyAddr,
            out->outputStreamInfo.stPackage.pu8Addr, out->outputStreamInfo.stPackage.u32Len);
        VLOG_DEBUG("JENC chnId:%d: encoded: pts=%lld, seq=%lld, userdata=%lld.\n",
            ChnId, out->outputStreamInfo.stPackage.u64PTS, out->outputStreamInfo.stPackage.u64SeqNum,
            out->outputStreamInfo.stPackage.u64UserData);
        picCnt++;

        if (pCmdl->mjpeg == AX_TRUE) {
#if 0
            picBytes += encOut.jfifSize;
            mjpeg_length += picBytes;

            if (mjpeg_length % 4 != 0) {
                memset(pJencHandle->outbufMem[0].virtualAddress, 0, 4 - (mjpeg_length % 4));
                mjpeg_length = (mjpeg_length + 3) & (~3);
                picBytes = (picBytes + 3) & (~3);
            }

            idx[picCnt-1].length = picBytes;

            /*rate control statistic log*/
            total_bits += picBytes * 8;
            JencMaAddFrame(&ma, picBytes*8);

// printf("=== Encoded %i Qp=%d bits=%d TotalBits=%d averagebitrate=%lld HWCycles=%d Time(us %d HW +SW) \n",
//         picCnt, (JencGetQpHdr(encoder) >> QP_FRACTIONAL_BITS), picBytes*8, total_bits,
//         ((unsigned long long)total_bits * cmdl.frameRateNum) / ((picCnt+1) * cmdl.frameRateDenom),
//         JencGetPerformance(encoder), uJencTimeDiff(timeFrameEnd, timeFrameStart));

            if((pCmdl->bitPerSecond != 0) && ((picCnt+1) >= ma.length)) {
                numbersquareoferror++;
                if(maxerrorovertarget<(JencMa(&ma)- pCmdl->bitPerSecond))
                    maxerrorovertarget=(JencMa(&ma)- pCmdl->bitPerSecond);
                if(maxerrorundertarget<(pCmdl->bitPerSecond-JencMa(&ma)))
                    maxerrorundertarget=(pCmdl->bitPerSecond-JencMa(&ma));

                sumsquareoferror += ((float)(ABS(JencMa(&ma)- (i32)pCmdl->bitPerSecond))*100/pCmdl->bitPerSecond);

                averagesquareoferror=(sumsquareoferror/numbersquareoferror);

                VLOG_DEBUG("++++RateControl(movingBitrate=%d MaxOvertarget=%d%% MaxUndertarget=%d%% AveDeviationPerframe=%f%%) \n",
                    JencMa(&ma), maxerrorovertarget*100/pCmdl->bitPerSecond,
                    maxerrorundertarget*100/pCmdl->bitPerSecond, averagesquareoferror);
            }
#endif
        } else {
            VLOG_DEBUG("=== Encoded %i bits=%d HWCycles=%d Time(us %d HW +SW) \n",
                picCnt, encOut.jfifSize, JencGetPerformance(encoder), uJencTimeDiff(pHandle->timeFrameEnd, pHandle->timeFrameStart));
        }

        picBytes = 0;
        slice = 0;

        ret = AX_SUCCESS;
        break;
    case JPEGENC_OUTPUT_BUFFER_OVERFLOW:
        /* For debugging
        if(writeOutput)
            JencWriteStrm(fout, pJencHandle->outbufMem.virtualAddress,
                    pJencHandle->outbufMem.size, 0);*/
        /* Rewind the file back this picture's bytes
        fseek(fout, -picBytes, SEEK_CUR);*/
        picBytes = 0;
        slice = 0;
        break;
    default:
        VLOG_ERROR("FAILED. Error code: %i\n", ret);

        /* encodeFail = (int)ret; */
        /* For debugging */
        // if(writeOutput)
        //     JencWriteStrmBufs(fout, pJencHandle->outbufMem, 0,
        //                 encOut.jfifSize, encOut.invalidBytesInBuf0Tail, 0);
        break;
    }
#if 0
    if (pCmdl->mjpeg == AX_TRUE) {
        free(idx);
    }
#endif

    return ret;
}

int JencCloseEncoder(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    VCEncRet ret;
    /* const void *ewl_inst = JencGetEwl(JencInst); */

    // if (EWL_DEVMEM_VAILD(tb->scaledPictureMem))
    //     JencEWLFreeLinear(ewl_inst, &tb->scaledPictureMem);

    if ((ret = JencRelease(JencInst)) != VCENC_OK) {
        VLOG_ERROR("JencRelease() failed. ret:%d \n", ret);
    }

    return ret;
}


int JencAllocRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    JencCommandLine_s *cmdl = &pJencHandle->stCmdl;
    i32 sliceRows = 0;
    u64 pictureSize;
    u32 streamBufTotalSize;
    u32 headerSize = JPEGENC_STREAM_MIN_BUF0_SIZE;
    i32 i, ret;
    u64 lumaSize;
    u64 chromaSize;
    u64 dec400LumaTblSize;
    u64 dec400ChrTblSize;
    u32 dec400TblSize;
    u32 input_alignment = 0;
    i32 mcuh = 8;
    i32 strmBufNum = 2;
    i32 bufSizes[2] = {0, 0};
    i32 dec400VersionId = 0;

    const void* ewl_inst = JencGetEwl(JencInst);

    input_alignment = (cmdl->exp_of_input_alignment == 0) ? 0 : (1 << cmdl->exp_of_input_alignment);
    mcuh = (cmdl->codingMode == 1) ? 8 : 16;
    strmBufNum = cmdl->streamBufChain ? 2 : 1;

    /* Set slice size and output buffer size
        * For output buffer size, 1 byte/pixel is enough for most images.
        * Some extra is needed for testing purposes (noise input) */

    if(cmdl->partialCoding == 0) {
        sliceRows = cmdl->lumHeightSrc;
    } else {
        sliceRows = cmdl->restartInterval * mcuh;
    }

    streamBufTotalSize = cmdl->output_width * sliceRows * 2;
    if(cmdl->thumbnail)
        headerSize += pJencHandle->thumbDataLength;

    JencDec400GetVersionId(ewl_inst, &dec400VersionId);

    JencGetAlignedPicSizebyFormat(cmdl->frameType, cmdl->lumWidthSrc, sliceRows,
                                input_alignment, &lumaSize, &chromaSize, &pictureSize);

    if(dec400VersionId == 1) {
        JencGetDec400CompTablebyFormat(cmdl->frameType, cmdl->lumWidthSrc, cmdl->lumHeightSrc,
                                input_alignment, &dec400LumaTblSize, &dec400ChrTblSize,
                                &cmdl->dec400FrameTableSize, dec400VersionId);
    } else {
        JencGetDec400CompTablebyFormat(cmdl->frameType, cmdl->lumWidthSrc, cmdl->lumHeightSrc,
                                    input_alignment, &dec400LumaTblSize, &dec400ChrTblSize,
                                    NULL,dec400VersionId);
    }

    JencSetLumaSize(JencInst, lumaSize, dec400LumaTblSize);//((jpegInstance_s *)enc)->lumaSize = lumaSize;
    JencSetChromaSize(JencInst, chromaSize, dec400ChrTblSize);//((jpegInstance_s *)enc)->chromaSize = chromaSize;

    pJencHandle->pictureMem.virtualAddress = NULL;
        /* Here we use the EWL instance directly from the encoder
        * because it is the easiest way to allocate the linear memories */
    pJencHandle->pictureMem.mem_type = EWL_MEM_TYPE_DPB;
#ifdef FBDC_ENABLE
    pictureSize = cmdl->UVheaderSize + cmdl->UVpayloadSize + cmdl->YheaderSize + cmdl->YpayloadSize;
    VLOG_DEBUG("JPEG input memory size is %lld \n", pictureSize);
#endif

    ret = JencEWLMallocLinear(ewl_inst, pictureSize, 0, &pJencHandle->pictureMem);
    if (ret != EWL_OK) {
        VLOG_ERROR("Failed to allocate input picture!");
        pJencHandle->pictureMem.virtualAddress = NULL;
        return 1;
    }
    pJencHandle->dec400CompTblMem.virtualAddress = NULL;
    dec400TblSize = dec400LumaTblSize + dec400ChrTblSize;
    if (dec400TblSize > 0) {
        pJencHandle->dec400CompTblMem.mem_type = EWL_MEM_TYPE_DPB;
        ret = JencEWLMallocLinear(ewl_inst, dec400TblSize, 16, &pJencHandle->dec400CompTblMem);
        if (ret != EWL_OK) {
            VLOG_ERROR("Failed to allocate dec400 compress table!\n");
            pJencHandle->dec400CompTblMem.virtualAddress = NULL;
            return 1;
        }
    }

    if (strmBufNum == 1) {
        bufSizes[0] = (cmdl->streamMultiSegmentMode != 0 ? streamBufTotalSize/128 : streamBufTotalSize);
    } else {
        /* set small stream buffer0 to test two stream buffers */
        bufSizes[0] = streamBufTotalSize / 100;
        bufSizes[1] = streamBufTotalSize - bufSizes[0];
    }
    bufSizes[0] += headerSize;
    memset(pJencHandle->outbufMem, 0, sizeof(pJencHandle->outbufMem));
    for (i = 0; i < strmBufNum; i ++) {
        u32 size = bufSizes[i];

        /* For FPGA testing, smaller size maybe specified. */
        /* Max output buffer size is less than 256MB */
        //comment out outbufSize hard limitation for 16K*16K testing
        //size = size < (1024*1024*64) ? size : (1024*1024*64);

        pJencHandle->outbufMem[i].mem_type = EWL_MEM_TYPE_SLICE;
        ret = JencEWLMallocLinear(ewl_inst, size, 0, &pJencHandle->outbufMem[i]);
        if (ret != EWL_OK) {
            VLOG_ERROR("Failed to allocate output buffer!\n");
            pJencHandle->outbufMem[i].virtualAddress = NULL;
            return 1;
        }
    }
    //RoiMap assume cmdl->width/height % 16 == 0
    if(pJencHandle->cfg.enableRoimap) {
        ret = JencReadRoimap(pJencHandle, ewl_inst);
        if (ret) {
            VLOG_ERROR("ReadRoimap fail, return:%d", ret);
        }
    }

    /*Overlay input buffer*/
    for(i = 0; i < 8; i++) {
        u32 block_size = 0;
        u32 dec400TableSize = 0;
        if ((cmdl->overlayEnables >> i) & 1) {
            switch (cmdl->olFormat[i]) {
            case 0: //ARGB
                if(cmdl->olSuperTile[i] == 0)
                    block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                else
                    block_size = cmdl->olYStride[i]*((cmdl->olHeight[i] + 63) / 64);
                break;
            case 1: //NV12
                block_size = cmdl->olYStride[i]*cmdl->olHeight[i] +
                                cmdl->olUVStride[i]*cmdl->olHeight[i]/2;
                break;
            case 2: //Bitmap
                block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                break;
            default: //3
                block_size = 0;
                break;
            }

            pJencHandle->overlayMem[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
            ret = JencEWLMallocLinear(ewl_inst, block_size, 0, &pJencHandle->overlayMem[i]);
            if(ret != EWL_OK) {
                pJencHandle->overlayMem[i].virtualAddress = NULL;
                return 1;
            }

            memset(pJencHandle->overlayMem[i].virtualAddress, 0, block_size);

            /* Dec400 buffer */
            if (pJencHandle->cfg.osdDec400TableFile && i == 0) {
                JencGetOsdDec400SizeJpeg(cmdl, dec400VersionId, i, &dec400TableSize);
            }

            if (dec400TableSize) {
                ret = JencEWLMallocLinear(ewl_inst, dec400TableSize, 0, &pJencHandle->osdDec400CompTblMem);
                if(ret != EWL_OK) {
                    pJencHandle->osdDec400CompTblMem.virtualAddress = NULL;
                    return 1;
                }

                memset(pJencHandle->osdDec400CompTblMem.virtualAddress, 0, dec400TableSize);
                pJencHandle->cfg.osdDec400TableSize = dec400TableSize;
            } else if(i == 0) {
                pJencHandle->osdDec400CompTblMem.virtualAddress = NULL;
            }
        } else {
            pJencHandle->overlayMem[i].virtualAddress = NULL;
        }
    }

    VLOG_DEBUG("Input %dx%d + %dx%d encoding at %dx%d + %dx%d ",
            cmdl->lumWidthSrcThumb, cmdl->lumHeightSrcThumb,
            cmdl->lumWidthSrc, cmdl->lumHeightSrc,
            cmdl->widthThumb, cmdl->heightThumb,
            cmdl->output_width, cmdl->output_height);

    if(cmdl->partialCoding != 0)
        VLOG_DEBUG("in slices of %dx%d", cmdl->output_width, sliceRows);

    VLOG_DEBUG("Input buffer size: %u bytes", pJencHandle->pictureMem.size);
    VLOG_DEBUG("Input buffer bus address: %p", (void *)pJencHandle->pictureMem.busAddress);
    VLOG_DEBUG("Input buffer user address: %10p", pJencHandle->pictureMem.virtualAddress);
    for (i = 0; i < strmBufNum; i ++) {
        VLOG_DEBUG("Output buffer%d size: %u bytes", i, pJencHandle->outbufMem[i].size);
        VLOG_DEBUG("Output buffer%d bus address: %p", i, (void *)pJencHandle->outbufMem[i].busAddress);
        VLOG_DEBUG("Output buffer%d user address: %10p\n", i, pJencHandle->outbufMem[i].virtualAddress);
    }

    return 0;
}

int JencAllocResNew(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    JencCommandLine_s *cmdl = &pJencHandle->stCmdl;
    i32 sliceRows = 0;
    u32 streamBufTotalSize;
    u32 headerSize = JPEGENC_STREAM_MIN_BUF0_SIZE;
    i32 i, ret;
    i32 mcuh = 8;
    i32 strmBufNum = 2;
    i32 bufSizes[2] = {0, 0};

    const void* ewl_inst = JencGetEwl(JencInst);

    mcuh = (cmdl->codingMode == 1) ? 8 : 16;
    strmBufNum = cmdl->streamBufChain ? 2 : 1;

    /* Set slice size and output buffer size
        * For output buffer size, 1 byte/pixel is enough for most images.
        * Some extra is needed for testing purposes (noise input) */

// To do: make sure is slice encode support?
    if(cmdl->partialCoding == 0) {
        sliceRows = cmdl->lumHeightSrc;
    } else {
        sliceRows = cmdl->restartInterval * mcuh;
    }

    streamBufTotalSize = cmdl->output_width * sliceRows * 2;
    if(cmdl->thumbnail)
        headerSize += pJencHandle->thumbDataLength;

// To do: review buf size cal process
    if (strmBufNum == 1) {
        bufSizes[0] = (cmdl->streamMultiSegmentMode != 0 ? streamBufTotalSize/128 : streamBufTotalSize);
    } else {
        /* set small stream buffer0 to test two stream buffers */
        bufSizes[0] = streamBufTotalSize / 100;
        bufSizes[1] = streamBufTotalSize - bufSizes[0];
    }
    bufSizes[0] += headerSize;
    memset(pJencHandle->outbufMem, 0, sizeof(pJencHandle->outbufMem));
    if (PT_MJPEG == pstAttr->stVencAttr.enType)
    {
#if 0 // outbufMem replaced by output ringbuffer
        for (i = 0; i < strmBufNum; i ++) {
            u32 size = bufSizes[i];

// To do: replace by VB pool
            pJencHandle->outbufMem[i].mem_type = EWL_MEM_TYPE_SLICE;
            ret = JencEWLMallocLinear(ewl_inst, size, 0, &pJencHandle->outbufMem[i]);
            if (ret != EWL_OK) {
                VLOG_ERROR("Failed to allocate output buffer!\n");
                pJencHandle->outbufMem[i].virtualAddress = NULL;
                return 1;
            }
        }
#endif
    }
    //RoiMap assume cmdl->width/height % 16 == 0
    if(pJencHandle->cfg.enableRoimap) {
        ret = JencReadRoimap(pJencHandle, ewl_inst);
        if (ret) {
            VLOG_ERROR("ReadRoimap fail, return:%d", ret);
        }
    }

// To do: make sure if useful?
    /*Overlay input buffer*/
    for(i = 0; i < 8; i++) {
        u32 block_size = 0;
        if((cmdl->overlayEnables >> i) & 1)
        {
            switch(cmdl->olFormat[i])
            {
            case 0: //ARGB
                if(cmdl->olSuperTile[i] == 0)
                    block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                else
                    block_size = cmdl->olYStride[i]*((cmdl->olHeight[i] + 63) / 64);
                break;
            case 1: //NV12
                block_size = cmdl->olYStride[i]*cmdl->olHeight[i] +
                                cmdl->olUVStride[i]*cmdl->olHeight[i]/2;
                break;
            case 2: //Bitmap
                block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                break;
            default: //3
                block_size = 0;
                break;
            }

            pJencHandle->overlayMem[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
            ret = JencEWLMallocLinear(ewl_inst, block_size, 0, &pJencHandle->overlayMem[i]);
            if(ret != EWL_OK) {
                pJencHandle->overlayMem[i].virtualAddress = NULL;
                return 1;
            }

            memset(pJencHandle->overlayMem[i].virtualAddress, 0, block_size);
        } else {
            pJencHandle->overlayMem[i].virtualAddress = NULL;
        }
    }

    VLOG_DEBUG("Input %dx%d + %dx%d encoding at %dx%d + %dx%d ",
            cmdl->lumWidthSrcThumb, cmdl->lumHeightSrcThumb,
            cmdl->lumWidthSrc, cmdl->lumHeightSrc,
            cmdl->widthThumb, cmdl->heightThumb,
            cmdl->output_width, cmdl->output_height);

    if(cmdl->partialCoding != 0)
        VLOG_DEBUG("in slices of %dx%d", cmdl->output_width, sliceRows);

    return 0;
}


void JencFreeRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    i32 i;
    const void* ewl_inst = JencGetEwl(JencInst);

    if(EWL_DEVMEM_VAILD(pJencHandle->pictureMem)) {
        JencEWLFreeLinear(ewl_inst, &pJencHandle->pictureMem);
    }
#if 0 // outbufMem replaced by output ringbuffer
    for (i = 0; i < MAX_STRM_BUF_NUM; i ++) {
        if(pJencHandle->outbufMem[i].virtualAddress != NULL)
            JencEWLFreeLinear(ewl_inst, &pJencHandle->outbufMem[i]);
    }
#endif
    if(EWL_DEVMEM_VAILD(pJencHandle->dec400CompTblMem)) {
        JencEWLFreeLinear(ewl_inst, &pJencHandle->dec400CompTblMem);
    }

    if(pJencHandle->thumbData != NULL)
        free(pJencHandle->thumbData);

#ifndef TB_DEFINED_COMMENT
    if(pJencHandle->cfg.pCom != NULL)
        free((void *)pJencHandle->cfg.pCom);
#endif

    for(i = 0; i < MAX_OVERLAY_NUM; i++) {
        if(pJencHandle->overlayMem[i].virtualAddress != NULL)
            JencEWLFreeLinear(ewl_inst, &pJencHandle->overlayMem[i]);
    }

    if (pJencHandle->osdDec400CompTblMem.virtualAddress != NULL)
        JencEWLFreeLinear(ewl_inst, &pJencHandle->osdDec400CompTblMem);

    if(pJencHandle->roimapMem.virtualAddress != NULL)
        JencEWLFreeLinear(ewl_inst, &pJencHandle->roimapMem);
}

int JencEncodeOnceAllocRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    JencCommandLine_s *cmdl = &pJencHandle->stCmdl;
    i32 sliceRows = 0;
    u32 streamBufTotalSize;
    u32 headerSize = JPEGENC_STREAM_MIN_BUF0_SIZE;
    /* i32 i, ret; */
    i32 mcuh = 8;
    i32 strmBufNum = 2;
    i32 bufSizes[2] = {0, 0};

    /* const void* ewl_inst = JencGetEwl(JencInst); */

    mcuh = (cmdl->codingMode == 1) ? 8 : 16;
    strmBufNum = cmdl->streamBufChain ? 2 : 1;

    /* Set slice size and output buffer size
     * For output buffer size, 1 byte/pixel is enough for most images.
     * Some extra is needed for testing purposes (noise input)
     */

    /* To do: make sure is slice encode support? */
    if(cmdl->partialCoding == 0) {
        sliceRows = cmdl->lumHeightSrc;
    } else {
        sliceRows = cmdl->restartInterval * mcuh;
    }

    streamBufTotalSize = cmdl->output_width * sliceRows * 2;
    if(cmdl->thumbnail)
        headerSize += pJencHandle->thumbDataLength;

    /* To do: review buf size cal process */
    if (strmBufNum == 1) {
        bufSizes[0] = (cmdl->streamMultiSegmentMode != 0 ? streamBufTotalSize/128 : streamBufTotalSize);
    } else {
        /* set small stream buffer0 to test two stream buffers */
        bufSizes[0] = streamBufTotalSize / 100;
        bufSizes[1] = streamBufTotalSize - bufSizes[0];
    }
    bufSizes[0] += headerSize;
    memset(pJencHandle->outbufMem, 0, sizeof(pJencHandle->outbufMem));

#if 0
    //RoiMap assume cmdl->width/height % 16 == 0
    if(pJencHandle->cfg.enableRoimap) {
        ret = JencReadRoimap(pJencHandle, ewl_inst);
        if (ret) {
            VLOG_ERROR("ReadRoimap fail, return:%d", ret);
        }
    }
#endif

    VLOG_DEBUG("Input %dx%d + %dx%d encoding at %dx%d + %dx%d ",
            cmdl->lumWidthSrcThumb, cmdl->lumHeightSrcThumb,
            cmdl->lumWidthSrc, cmdl->lumHeightSrc,
            cmdl->widthThumb, cmdl->heightThumb,
            cmdl->output_width, cmdl->output_height);

    if(cmdl->partialCoding != 0)
        VLOG_DEBUG("in slices of %dx%d", cmdl->output_width, sliceRows);

    return 0;
}


void JencEncodeOnceFreeRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    /* i32 i; */
    const void* ewl_inst = JencGetEwl(JencInst);


    if(pJencHandle->thumbData != NULL)
        free(pJencHandle->thumbData);

#ifndef TB_DEFINED_COMMENT
    if(pJencHandle->cfg.pCom != NULL)
        free((void *)pJencHandle->cfg.pCom);
#endif

    if(pJencHandle->roimapMem.virtualAddress != NULL)
        JencEWLFreeLinear(ewl_inst, &pJencHandle->roimapMem);
}

/*------------------------------------------------------------------------------
        Function name     : osd_overlap
        Description         : check osd input overlap
        Return type         : i32
        Argument                : cml
        Argument                : i - osd channel to check
------------------------------------------------------------------------------*/
static i32 JpegOsdOverlap(AX_JENC_HANDLE_S *pJencHandle, u8 id)
{
    JencCommandLine_s * cml = &pJencHandle->stCmdl;
    int i, tmpx, tmpy;
    int blockW = 64;
    int blockH = 16;
    for (i = 0; i < MAX_OVERLAY_NUM; i++) {
        if (!((cml->overlayEnables >> i) & 1) || i == id) continue;
        u32 xoffsetId = cml->olXoffset[id];
        u32 yoffsetId = cml->olYoffset[id];
        u32 cropWidthId = cml->olCropWidth[id];
        u32 cropHeightId = cml->olCropHeight[id];


        u32 xoffset = cml->olXoffset[i];
        u32 yoffset = cml->olYoffset[i];
        u32 cropWidth = cml->olCropWidth[i];
        u32 cropHeight = cml->olCropHeight[i];

        if (!((xoffsetId + cropWidthId) <= xoffset || (yoffsetId + cropHeightId) <= yoffset ||
            xoffsetId >= (xoffset + cropWidth) || yoffsetId >= (yoffset + cropHeight))) {
            return -1;
        }

        /* Check not share CTB: avoid loop all ctb */
        if ((xoffsetId + cropWidthId) <= xoffset && (yoffsetId + cropHeightId) <= yoffset) {
            tmpx = ((xoffsetId + cropWidthId - 1) / blockW) * blockW;
            tmpy = ((yoffsetId + cropHeightId - 1) / blockH) * blockH;

            if (tmpx + blockW > xoffset && tmpy + blockH > yoffset) {
                return -1;
            }
        } else if ((xoffsetId + cropWidthId) <= xoffset && yoffsetId >= (yoffset + cropHeight)) {
            tmpx = ((xoffsetId + cropWidthId - 1) / blockW) * blockW;
            tmpy = ((yoffset + cropHeight - 1) / blockH) * blockH;
            if (tmpx + blockW > xoffset && tmpy + blockH > yoffsetId) {
                return -1;
            }
        } else if (xoffsetId >= (xoffset + cropWidth) && (yoffsetId + cropHeightId) <= yoffset) {
            tmpx = ((xoffset + cropWidth - 1) / blockW) * blockW;
            tmpy = ((yoffsetId + cropHeightId - 1) / blockH) * blockH;
            if (tmpx + blockW > xoffsetId && tmpy + blockH > yoffset) {
                return -1;
            }
        } else if (xoffsetId >= (xoffset + cropWidth) && yoffsetId >= (yoffset + cropHeight)) {
            tmpx = ((xoffset + cropWidth - 1) / blockW) * blockW;
            tmpy = ((yoffset + cropHeight - 1) / blockH) * blockH;
            if (tmpx + blockW > xoffsetId && tmpy + blockH > yoffsetId) {
                return -1;
            }
        } else if ((xoffsetId + cropWidthId) <= xoffset) {
            tmpx = ((xoffsetId + cropWidthId - 1) / blockW) * blockW;
            if (tmpx + blockW > xoffset)
                return -1;
        } else if ((yoffsetId + cropHeightId) <= yoffset) {
            tmpy = ((yoffsetId + cropHeightId - 1) / blockH) * blockH;
            if (tmpy + blockH > yoffset)
                return -1;
        } else if (xoffsetId >= (xoffset + cropWidth)) {
            tmpx = ((xoffset + cropWidth - 1) / blockW) * blockW;
            if (tmpx + blockW > xoffsetId)
                return -1;
        } else if (yoffsetId >= (yoffset + cropHeight)) {
            tmpy = ((yoffset + cropHeight - 1) / blockH) * blockH;
            if (tmpy + blockH > yoffsetId)
                return -1;
        }
    }

    return 0;
}

static i32 JpegOverlapCheck(AX_JENC_HANDLE_S *pJencHandle, u32 id)
{
    JencCommandLine_s *tb = &pJencHandle->stCmdl;
    u32 i = id;

    if(tb->olWidth[i] == 0 || tb->olHeight[i] == 0
    || tb->olCropWidth == 0 || tb->olCropHeight == 0) {
        VLOG_ERROR("Invalid overlay region %d size \n", i);
        return -1;
    }

    u64 widthMax = (tb->rotation == 1 || tb->rotation == 2)?
        (tb->output_height - tb->verOffsetSrc) : (tb->output_width - tb->horOffsetSrc);
    u64 heightMax = (tb->rotation == 1 || tb->rotation == 2)?
        (tb->output_width - tb->horOffsetSrc) : (tb->output_height - tb->verOffsetSrc);

    if (tb->olCropWidth[i] + tb->olXoffset[i] > widthMax ||
    tb->olCropHeight[i] + tb->olYoffset[i] > heightMax) {
        VLOG_ERROR("Invalid overlay region %d offset\n", i);
        return -1;
    }

    if (tb->olCropXoffset[i] + tb->olCropWidth[i] > tb->olWidth[i] ||
    tb->olCropYoffset[i] + tb->olCropHeight[i] > tb->olHeight[i]) {
        VLOG_ERROR("Invalid overlay region %d cropping offset\n", i);
        return -1;
    }

    if (tb->olFormat[i] == 2 && (tb->olCropWidth[i] % 8 != 0)) {
        VLOG_ERROR("Invalid overlay region %d cropping width for bitmap \n", i);
        return -1;
    }

    if (JpegOsdOverlap(pJencHandle, i)) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR overlay area overlapping \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 && tb->olFormat[i] != 0) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR Super tile only support ARGB8888 format \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 && i != 0) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR Super tile only support for channel 1 \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 && tb->partialCoding != 0) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR OSD Super tile does not support partialCoding    \n");
        return -1;
    }

    if ((tb->olSuperTile[i] == 0 && tb->olScaleWidth[i] != tb->olCropWidth[i]) ||
    (tb->olSuperTile[i] == 0 && tb->olScaleHeight[i] != tb->olCropHeight[i]) ||
    (tb->olScaleWidth[i] != tb->olCropWidth[i] && i != 0) ||
    (tb->olScaleHeight[i]!= tb->olCropHeight[i] && i != 0)) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR Up scale only work for special usage \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 &&
    (tb->olCropXoffset[i] % 64 != 0 || tb->olCropYoffset[i] % 64 != 0)) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR super tile cropping offset must be 64 aligned \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 &&
    (tb->olScaleWidth[i] < tb->olCropWidth[i] ||
    tb->olScaleHeight[i] < tb->olCropHeight[i])) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR osd only support upscaling but no downscaling \n");
        return -1;
    }

    if (tb->olSuperTile[i] != 0 &&
    ((tb->olScaleWidth[i] & 1) ||
    tb->olScaleWidth[i] > (tb->olCropWidth[i]*2) ||
    (tb->olScaleHeight[i] & 1) ||
    tb->olScaleHeight[i] > (tb->olCropHeight[i] * 2))) {
        VLOG_ERROR("VCEncSetCodingCtrl: ERROR osd upscaling width or height \n");
        return -1;
    }

    return 0;
}

static void JencStreamSegmentReady(void *cb_data)
{
    /* u8 *streamBase; */
    JencSegmentCtl_s *ctl = (JencSegmentCtl_s*)cb_data;

    if (ctl->streamMultiSegEn) {
        /* streamBase = ctl->streamBase + (ctl->streamRDCounter % ctl->segmentAmount) * ctl->segmentSize; */

        VLOG_DEBUG("receive segment irq %d,length=%d\n",ctl->streamRDCounter,ctl->segmentSize);
        // if(writeOutput)
        //     JencWriteStrm(ctl->outStreamFile, (u32 *)streamBase, ctl->segmentSize, 0);

        ctl->streamRDCounter++;
    }
}

int JencOpenEncoder(JpegEncInst *pJencInst, AX_JENC_HANDLE_S *pJencHandle)
{
    JpegEncRet ret;
    JpegEncCfg cfg;

    // JpegEncInst encoder = *pJencInst;
    JencCommandLine_s *pCmdl = &pJencHandle->stCmdl;
    u32 i;

    memset(&cfg, 0, sizeof(JpegEncCfg));
    /* Encoder initialization */
    if (pCmdl->output_width == INVALID_DEFAULT)
        pCmdl->output_width = pCmdl->lumWidthSrc;

    if (pCmdl->output_width == INVALID_DEFAULT)
        pCmdl->output_width = pCmdl->lumHeightSrc;

    /* VENC_CHN VeChn = pJencHandle->VeChn; */
    /* overlay controls */
    for(i = 0; i< MAX_OVERLAY_NUM; i++) {
        if((pCmdl->overlayEnables >> i) & 1) {
            if(pCmdl->olYStride[i] == 0) {
                switch(pCmdl->olFormat[i]) {
                case 0: //ARGB
                    if(pCmdl->olSuperTile[i] == 0)
                        pCmdl->olYStride[i] = pCmdl->olWidth[i]*4;
                    else
                        pCmdl->olYStride[i] = ((pCmdl->olWidth[i]+63) / 64) * 64 * 64 * 4;
                    break;
                case 1: //NV12
                    pCmdl->olYStride[i] = pCmdl->olWidth[i];
                    break;
                case 2: //Bitmap
                    pCmdl->olYStride[i] = pCmdl->olWidth[i] / 8;
                    break;
                default:
                    break;
                }
            }

            if(pCmdl->olUVStride[i] == 0)
                pCmdl->olUVStride[i] = pCmdl->olYStride[i];

            if(pCmdl->olCropHeight[i] == 0)
                pCmdl->olCropHeight[i] = pCmdl->olHeight[i];

            if(pCmdl->olCropWidth[i] == 0)
                pCmdl->olCropWidth[i] = pCmdl->olWidth[i];

            if(pCmdl->olScaleWidth[i] == 0)
                pCmdl->olScaleWidth[i] = pCmdl->olCropWidth[i];

            if(pCmdl->olScaleHeight[i] == 0)
                pCmdl->olScaleHeight[i] = pCmdl->olCropHeight[i];

            if (JpegOverlapCheck(pJencHandle, i)) {
                VLOG_ERROR("JpegOverlapCheck Failed! \n");
                return -1;
            }
        }
    }

    /* lossless mode */
    if (pCmdl->predictMode!=0) {
        cfg.losslessEn = 1;
        cfg.predictMode = pCmdl->predictMode;
        cfg.ptransValue = pCmdl->ptransValue;
    } else {
        cfg.losslessEn = 0;
    }

    cfg.ChnId = pJencHandle->VeChn;
    cfg.rotation = (JpegEncPictureRotation)pCmdl->rotation;
    /* Currently Not sure why having this limitation, will delete after regression verified
       This may cause some JPEG cases fail md5 comparasion */
    cfg.inputWidth = (pCmdl->lumWidthSrc + 15) & (~15);   /* API limitation */
    if (cfg.inputWidth != (u32)pCmdl->lumWidthSrc) {
        VLOG_ERROR("Warning: Input width must be multiple of 16! \n"
            "cfg.inputWidth:%d, pCmdl->lumWidthSrc:%d \n",
            cfg.inputWidth, pCmdl->lumWidthSrc);
    }

    cfg.inputWidth = pCmdl->lumWidthSrc;
    cfg.inputHeight = pCmdl->lumHeightSrc;
    for (i = 0; i < 3; i++){
        cfg.picStride[i] = pCmdl->picStride[i];
    }

    if(cfg.rotation && cfg.rotation != JPEGENC_ROTATE_180) {
        /* full */
        cfg.xOffset = pCmdl->verOffsetSrc;
        cfg.yOffset = pCmdl->horOffsetSrc;

        cfg.codingWidth = pCmdl->output_height;
        cfg.codingHeight = pCmdl->output_width;
        cfg.xDensity = pCmdl->ydensity;
        cfg.yDensity = pCmdl->xdensity;
    } else {
        /* full */
        cfg.xOffset = pCmdl->horOffsetSrc;
        cfg.yOffset = pCmdl->verOffsetSrc;

        cfg.codingWidth = pCmdl->output_width;
        cfg.codingHeight = pCmdl->output_height;
        cfg.xDensity = pCmdl->xdensity;
        cfg.yDensity = pCmdl->ydensity;
    }
    cfg.mirror = pCmdl->mirror;
    cfg.restartInterval = pCmdl->restartInterval;
    cfg.codingType = (JpegEncCodingType)pCmdl->partialCoding;
    cfg.frameType = (JpegEncFrameType)pCmdl->frameType;
    cfg.unitsType = (JpegEncAppUnitsType)pCmdl->unitsType;
    cfg.markerType = (JpegEncTableMarkerType)pCmdl->markerType;
    cfg.colorConversion.type = (JpegEncColorConversionType)pCmdl->colorConversion;
    if (cfg.colorConversion.type == JPEGENC_RGBTOYUV_USER_DEFINED) {
        /* User defined RGB to YCbCr conversion coefficients, scaled by 16-bits */
        cfg.colorConversion.coeffA = 20000;
        cfg.colorConversion.coeffB = 44000;
        cfg.colorConversion.coeffC = 5000;
        cfg.colorConversion.coeffE = 35000;
        cfg.colorConversion.coeffF = 38000;
        cfg.colorConversion.coeffG = 35000;
        cfg.colorConversion.coeffH = 38000;
        cfg.colorConversion.LumaOffset = 0;
    }

    // writeOutput = pCmdl->writeOut;
    cfg.codingMode = (JpegEncCodingMode)pCmdl->codingMode;

    /* low latency */
    cfg.inputLineBufEn = (pCmdl->inputLineBufMode>0) ? 1 : 0;
    cfg.inputLineBufLoopBackEn = (pCmdl->inputLineBufMode==1||pCmdl->inputLineBufMode==2) ? 1 : 0;
    cfg.inputLineBufDepth = pCmdl->inputLineBufDepth;
    cfg.amountPerLoopBack = pCmdl->amountPerLoopBack;
    cfg.inputLineBufHwModeEn = (pCmdl->inputLineBufMode==2||pCmdl->inputLineBufMode==4) ? 1 : 0;
    cfg.inputLineBufCbFunc = VCEncInputLineBufDone;
    cfg.inputLineBufCbData = &pJencHandle->inputMbLineBuf;
    cfg.hashType = pCmdl->hashtype;

    /*stream multi-segment*/
    cfg.streamMultiSegmentMode = pCmdl->streamMultiSegmentMode;
    cfg.streamMultiSegmentAmount = pCmdl->streamMultiSegmentAmount;
    cfg.streamMultiSegCbFunc = &JencStreamSegmentReady;
    cfg.streamMultiSegCbData = &pJencHandle->streamSegCtl;

    /* constant chroma control */
    cfg.constChromaEn = pCmdl->constChromaEn;
    cfg.constCb = pCmdl->constCb;
    cfg.constCr = pCmdl->constCr;

    /* jpeg rc*/
    cfg.targetBitPerSecond = pCmdl->bitPerSecond;
    cfg.frameRateNum = 1;
    cfg.frameRateDenom = 1;

    /* default qFactor */
    cfg.qFactor = 90;

    //framerate valid only when RC enabled
    if (pCmdl->bitPerSecond) {
        cfg.frameRateNum = pCmdl->frameRateNum;
        cfg.frameRateDenom = pCmdl->frameRateDenom;
    }
    cfg.qpmin = pCmdl->qpmin;
    cfg.qpmax = pCmdl->qpmax;
    cfg.fixedQP = pCmdl->fixedQP;
    cfg.rcMode   = pCmdl->rcMode;
    cfg.picQpDeltaMax = pCmdl->picQpDeltaMax;
    cfg.picQpDeltaMin = pCmdl->picQpDeltaMin;

    /*stride*/
    cfg.exp_of_input_alignment = pCmdl->exp_of_input_alignment;

    /* overlay control */
    for(i = 0; i < MAX_OVERLAY_NUM; i++) {
        cfg.olEnable[i] = (pCmdl->overlayEnables >> i) & 1;
        cfg.olFormat[i] = pCmdl->olFormat[i];
        cfg.olAlpha[i] = pCmdl->olAlpha[i];
        cfg.olWidth[i] = pCmdl->olWidth[i];
        cfg.olCropWidth[i] = pCmdl->olCropWidth[i];
        cfg.olHeight[i] = pCmdl->olHeight[i];
        cfg.olCropHeight[i] = pCmdl->olCropHeight[i];
        cfg.olXoffset[i] = pCmdl->olXoffset[i];
        cfg.olCropXoffset[i] = pCmdl->olCropXoffset[i];
        cfg.olYoffset[i] = pCmdl->olYoffset[i];
        cfg.olCropYoffset[i] = pCmdl->olCropYoffset[i];
        cfg.olYStride[i] = pCmdl->olYStride[i];
        cfg.olUVStride[i] = pCmdl->olUVStride[i];
        cfg.olSuperTile[i] = pCmdl->olSuperTile[i];
        cfg.olScaleWidth[i] = pCmdl->olScaleWidth[i];
        cfg.olScaleHeight[i] = pCmdl->olScaleHeight[i];
    }

    /* SRAM power down mode disable  */
    cfg.sramPowerdownDisable = pCmdl->sramPowerdownDisable;

    if(pCmdl->thumbnail < 0 || pCmdl->thumbnail > 3) {
        VLOG_ERROR("Not valid thumbnail format!\n");
        return -1;
    }

    if ((pCmdl->thumbnail != 0) && pCmdl->inputThumb) {
        FILE *fThumb;
        size_t size;
        fThumb = fopen(pCmdl->inputThumb, "rb");
        if (fThumb == NULL) {
            VLOG_ERROR("Unable to open Thumbnail file: %s\n", pCmdl->inputThumb);
            return -1;
        }

        switch(pCmdl->thumbnail) {
        case 1:
            fseek(fThumb,0,SEEK_END);
            pJencHandle->thumbDataLength = ftell(fThumb);
            fseek(fThumb,0,SEEK_SET);
            break;
        case 2:
            pJencHandle->thumbDataLength = 3*256 + pCmdl->widthThumb * pCmdl->heightThumb;
            break;
        case 3:
            pJencHandle->thumbDataLength = pCmdl->widthThumb * pCmdl->heightThumb * 3;
            break;
        default:
            assert(0);
        }

        pJencHandle->thumbData = (u8*)malloc(pJencHandle->thumbDataLength);
        size = fread(pJencHandle->thumbData, 1, pJencHandle->thumbDataLength, fThumb);
        if(pJencHandle->thumbDataLength != size) {
            VLOG_ERROR("read Thumbnail file err: %d %d\n", size, pJencHandle->thumbDataLength);
        }
        fclose(fThumb);
    }

    cfg.AXIAlignment = pCmdl->AXIAlignment;
    cfg.burstMaxLength = pCmdl->burstMaxLength;

    cfg.mmuEnable = pCmdl->mmuEnable;


    //JencParamPrintLog(pCmdl, cfg);

    if ((ret = AXJencInit(&cfg, pJencInst, NULL)) != JPEGENC_OK) {
        VLOG_ERROR("JencInit() failed. ret:%d \n", ret);
        return (int)ret;
    }

    if(pJencHandle->thumbData != NULL) {
        JpegEncThumb jpegThumb;
        jpegThumb.format = pCmdl->thumbnail == 1 ? JPEGENC_THUMB_JPEG : pCmdl->thumbnail == 3 ?
                            JPEGENC_THUMB_RGB24 : JPEGENC_THUMB_PALETTE_RGB8;
        jpegThumb.width = pCmdl->widthThumb;
        jpegThumb.height = pCmdl->heightThumb;
        jpegThumb.data = pJencHandle->thumbData;
        jpegThumb.dataLength = pJencHandle->thumbDataLength;

        ret = JencSetThumbnail(*pJencInst, &jpegThumb );
        if(ret != JPEGENC_OK ) {
            VLOG_ERROR("Failed to set thumbnail. Error code: %8i\n", ret);
            return -1;
        }
    }

    pJencHandle->u32Qfactor = cfg.qFactor;
    memcpy(&pJencHandle->cfg, &cfg, sizeof(JpegEncCfg));

    return 0;
}

int JencHandleUpdateChnAttr(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr, AX_JENC_HANDLE_S *pJencHandle)
{
    if (pJencHandle == NULL) {
        VLOG_ERROR("jencHandle is null\n");
        return -1;
    }

    if (pstAttr == NULL) {
        VLOG_ERROR("pstAttr is null\n");
        return -1;
    }

    JencCommandLine_s *pCmdl = &pJencHandle->stCmdl;

    if (pCmdl == NULL) {
        VLOG_ERROR("pCmdl is null\n");
        return -1;
    }

    /*width height of input frame*/
    if (pstAttr->stVencAttr.u32PicWidthSrc) {
        pCmdl->lumWidthSrc = pstAttr->stVencAttr.u32PicWidthSrc;
    }

    if (pstAttr->stVencAttr.u32PicHeightSrc) {
        pCmdl->lumHeightSrc = pstAttr->stVencAttr.u32PicHeightSrc;
    }

    if ( (0 != pstAttr->stVencAttr.u32CropWidth) &&
         (0 != pstAttr->stVencAttr.u32CropHeight) ) {
        /* cropping offset */
        pCmdl->horOffsetSrc = pstAttr->stVencAttr.u32CropOffsetX;
        pCmdl->verOffsetSrc = pstAttr->stVencAttr.u32CropOffsetY;
        /*widht height of encoded picture*/
        pCmdl->output_width = pstAttr->stVencAttr.u32CropWidth;
        pCmdl->output_height = pstAttr->stVencAttr.u32CropHeight;
        pCmdl->dynamicCropEnable = AX_FALSE;
    } else {
        /* cropping offset */
        pCmdl->horOffsetSrc = 0;
        pCmdl->verOffsetSrc = 0;
        /*widht height of encoded picture*/
        pCmdl->output_width = pstAttr->stVencAttr.u32PicWidthSrc;
        pCmdl->output_height = pstAttr->stVencAttr.u32PicHeightSrc;
        pCmdl->dynamicCropEnable = AX_TRUE;
    }

    VLOG_DEBUG("Chn %d Update ChnAttr: WxH %dx%d, Crop area: %d:%d:%d:%d\n",
                        ChnId,
                        pCmdl->lumWidthSrc,
                        pCmdl->lumHeightSrc,
                        pCmdl->horOffsetSrc,
                        pCmdl->verOffsetSrc,
                        pCmdl->output_width,
                        pCmdl->output_height);

    return 0;
}


int JencHandleGetChnAttr(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr, AX_JENC_HANDLE_S *pJencHandle)
{
    JencCommandLine_s *pCmdl = &pJencHandle->stCmdl;
    // AX_S32 s32Ret = -1;
    pJencHandle->VeChn = ChnId;

    if (pstAttr->stVencAttr.enType == PT_MJPEG) {
        pCmdl->mjpeg = AX_TRUE;

        switch (pstAttr->stRcAttr.enRcMode) {
        case VENC_RC_MODE_MJPEGCBR:
            pCmdl->srcFrameRate = pstAttr->stRcAttr.stMjpegCbr.u32SrcFrameRate;
            pCmdl->frameRateNum = pstAttr->stRcAttr.stMjpegCbr.fr32DstFrameRate;
            pCmdl->bitPerSecond = pstAttr->stRcAttr.stMjpegCbr.u32BitRate * VENC_BITRATE_RATIO;
            pCmdl->qpmin = pstAttr->stRcAttr.stMjpegCbr.u32MinQp;
            pCmdl->qpmax = pstAttr->stRcAttr.stMjpegCbr.u32MaxQp;
            pCmdl->rcMode = JPEGENC_CBR;
            pJencHandle->enRcMode = VENC_RC_MODE_MJPEGCBR;

            memcpy(&pJencHandle->stRcParam.stMjpegCbr, &pstAttr->stRcAttr.stMjpegCbr, sizeof(AX_VENC_MJPEG_CBR_S));
            break;
        case VENC_RC_MODE_MJPEGVBR:
            pCmdl->srcFrameRate = pstAttr->stRcAttr.stMjpegVbr.u32SrcFrameRate;
            pCmdl->frameRateNum = pstAttr->stRcAttr.stMjpegVbr.fr32DstFrameRate;
            pCmdl->bitPerSecond = pstAttr->stRcAttr.stMjpegVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
            pCmdl->qpmin = pstAttr->stRcAttr.stMjpegVbr.u32MinQp;
            pCmdl->qpmax = pstAttr->stRcAttr.stMjpegVbr.u32MaxQp;
            pCmdl->rcMode = JPEGENC_VBR;
            pJencHandle->enRcMode = VENC_RC_MODE_MJPEGVBR;

            memcpy(&pJencHandle->stRcParam.stMjpegVbr, &pstAttr->stRcAttr.stMjpegVbr, sizeof(AX_VENC_MJPEG_VBR_S));
            break;
        case VENC_RC_MODE_MJPEGFIXQP:
            pCmdl->srcFrameRate = pstAttr->stRcAttr.stMjpegFixQp.u32SrcFrameRate;
            pCmdl->frameRateNum = pstAttr->stRcAttr.stMjpegFixQp.fr32DstFrameRate;
            pCmdl->fixedQP = pstAttr->stRcAttr.stMjpegFixQp.s32FixedQp;
            pCmdl->rcMode = JPEGENC_FIXQP;
            pJencHandle->enRcMode = VENC_RC_MODE_MJPEGFIXQP;

            memcpy(&pJencHandle->stRcParam.stMjpegFixQp, &pstAttr->stRcAttr.stMjpegFixQp, sizeof(AX_VENC_MJPEG_FIXQP_S));
            break;
        default:
            VLOG_ERROR("Unsupport  pstAttr->stRcAttr.enRcMode:%d \n", pstAttr->stRcAttr.enRcMode);
            break;
        }
    } else {
        pCmdl->rcMode = JPEGENC_SINGLEFRAME;
        pCmdl->qLevel = 10;
    }

    pJencHandle->s32GetFrameMode = pstAttr->stVencAttr.enLinkMode;

    /*width height of input frame*/
    pCmdl->lumWidthSrc = pstAttr->stVencAttr.u32PicWidthSrc;
    pCmdl->lumHeightSrc = pstAttr->stVencAttr.u32PicHeightSrc;

    if ( (0 != pstAttr->stVencAttr.u32CropWidth) &&
         (0 != pstAttr->stVencAttr.u32CropHeight) ) {
        /* cropping offset */
        pCmdl->horOffsetSrc = pstAttr->stVencAttr.u32CropOffsetX;
        pCmdl->verOffsetSrc = pstAttr->stVencAttr.u32CropOffsetY;
        /*widht height of encoded picture*/
        pCmdl->output_width = pstAttr->stVencAttr.u32CropWidth;
        pCmdl->output_height = pstAttr->stVencAttr.u32CropHeight;
        pCmdl->dynamicCropEnable = AX_FALSE;
    } else {
        /* cropping offset */
        pCmdl->horOffsetSrc = 0;
        pCmdl->verOffsetSrc = 0;
        /*widht height of encoded picture*/
        pCmdl->output_width = pstAttr->stVencAttr.u32PicWidthSrc;
        pCmdl->output_height = pstAttr->stVencAttr.u32PicHeightSrc;
        pCmdl->dynamicCropEnable = AX_TRUE;
    }

    pJencHandle->streamBufSize = 10*1024*1024;//pstAttr->stVencAttr.u32BufSize;
    pJencHandle->streamBufNum = 1;//pHandle->streamBufChain ? 2 : 1;

    /* Video range config */
    // pHandle->videoRange = pstAttr->stVencAttr.u32VideoRange;

    // pJencHandle->encIn.dec400Enable = 0;

    // pHandle->yuvFile = fopen("/mnt/352x288_yuv420p_30frm.yuv", "rb");

    pJencHandle->hwid = JencEncAsicGetAsicHWid(JENC_EWL_CLIENT_TYPE_JPEG_ENC, NULL);

    return AX_SUCCESS;
}


int JencChnAttrCheck(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    AX_S32 chn_width_max = pstAttr->stVencAttr.u32MaxPicWidth;
	AX_S32 chn_height_max = pstAttr->stVencAttr.u32MaxPicHeight;
	AX_S32 chn_width = pstAttr->stVencAttr.u32PicWidthSrc;
    AX_S32 chn_height = pstAttr->stVencAttr.u32PicHeightSrc;
    AX_U32 crop_width = pstAttr->stVencAttr.u32CropWidth;
    AX_U32 crop_height = pstAttr->stVencAttr.u32CropHeight;
    AX_U32 crop_offset_x = pstAttr->stVencAttr.u32CropOffsetX;
    AX_U32 crop_offset_y = pstAttr->stVencAttr.u32CropOffsetY;
    AX_U32 dst_frameRate = 0;
    AX_U32 src_frameRate = 0;

    if ((PT_JPEG != pstAttr->stVencAttr.enType) && (PT_MJPEG != pstAttr->stVencAttr.enType)) {
        VLOG_ERROR("JencChn %d: .enType:%d\n", ChnId,  pstAttr->stVencAttr.enType);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	if (chn_width_max > MaxJencWidth || chn_width_max < MinJencWidth) {
        VLOG_ERROR("JencChn %d: Set channel width %d over range[32, 32768].\n", ChnId, chn_width_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
	}

    if (chn_height_max > MaxJencHeight || chn_height_max < MinJencHeight) {
        VLOG_ERROR("JencChn %d: Set channel height %d over range[32, 32768].\n", ChnId, chn_height_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	if (chn_width > MaxJencWidth || chn_width < MinJencWidth) {
        VLOG_ERROR("JencChn %d: Set channel max width %d over range[32, 32768].\n", ChnId, chn_width);
        return AX_ERR_VENC_ILLEGAL_PARAM;
	}

    if (chn_height > MaxJencHeight || chn_height < MinJencHeight) {
        VLOG_ERROR("JencChn %d: Set channel max height %d over range[32, 32768].\n", ChnId, chn_height);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_width > chn_width_max && chn_width_max != 0) {
        VLOG_ERROR("JencChn %d: u32PicWidthSrc(%d) > u32MaxPicWidth(%d) not support.\n",
            ChnId, chn_width, chn_width_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_height > chn_height_max && chn_height_max != 0) {
        VLOG_ERROR("JencChn %d: u32PicHeightSrc(%d) > u32MaxPicHeight(%d) not support.\n",
            ChnId, chn_height, chn_height_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (crop_width > chn_width) {
        VLOG_ERROR("JencChn %d: u32CropWidth(%d) > u32PicWidthSrc(%d) not support.\n",
            ChnId, crop_width, chn_width);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_width & 1) != 0) {
        VLOG_ERROR("JencChn %d: u32CropWidth(%d) must be even.\n",
            ChnId, crop_width);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (crop_height > chn_height) {
        VLOG_ERROR("JencChn %d: u32CropHeight(%d) > u32PicHeightSrc(%d) not support.\n",
            ChnId, crop_height, chn_height);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_height & 1) != 0) {
        VLOG_ERROR("JencChn %d: u32CropHeight(%d) must be even.\n",
            ChnId, crop_height);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_offset_x & 1) != 0) {
        VLOG_ERROR("JencChn %d: u32CropOffsetX(%d) must be even.\n",
            ChnId, crop_offset_x);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_offset_y & 1) != 0) {
        VLOG_ERROR("JencChn %d: u32CropOffsetY(%d) must be even.\n",
            ChnId, crop_offset_y);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_width + crop_offset_x) > chn_width) {
        VLOG_ERROR("JencChn %d: u32CropWidth(%d) + u32CropOffsetX(%d) > u32PicWidthSrc(%d) not support.\n",
            ChnId, crop_width, crop_offset_x, chn_width);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((crop_height + crop_offset_y) > chn_height) {
        VLOG_ERROR("JencChn %d: u32CropHeight(%d) + u32CropOffsetY(%d) > u32PicHeightSrc(%d) not support.\n",
            ChnId, crop_height, crop_offset_y, chn_height);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (pstAttr->stVencAttr.enType == PT_JPEG) {

    } else {
        switch (pstAttr->stRcAttr.enRcMode) {
        case VENC_RC_MODE_MJPEGCBR:
            dst_frameRate = pstAttr->stRcAttr.stMjpegCbr.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegCbr.u32SrcFrameRate;
            break;
        case VENC_RC_MODE_MJPEGFIXQP:
            dst_frameRate = pstAttr->stRcAttr.stMjpegFixQp.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegFixQp.u32SrcFrameRate;
            break;
        case VENC_RC_MODE_MJPEGVBR:
            dst_frameRate = pstAttr->stRcAttr.stMjpegVbr.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegVbr.u32SrcFrameRate;
            break;
        default:
            break;
        }
        if (dst_frameRate > src_frameRate) {
            VLOG_ERROR("JencChn %d: Target frame rate more than Source frame rate: srcFrmRate=%d, TargetFrmRate=%d.\n",
                  ChnId, src_frameRate, dst_frameRate);
            return AX_ERR_VENC_ILLEGAL_PARAM;
        }
    }

    return AX_SUCCESS;
}

int JencJpegParamCheck(AX_S32 ChnId, const AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	AX_S32 i = 0, j = 0, k = 0, length = 0;
	if (NULL == pstJpegParam) {
		VLOG_ERROR("JencChn %d: Invalid param null pointer.\n", ChnId);
		return AX_ERR_VENC_NULL_PTR;
	}

	if((pstJpegParam->u32Qfactor < 0) || (pstJpegParam->u32Qfactor > 99)) {
		VLOG_ERROR("JencChn %d: Invalid u32Qfactor.\n", ChnId);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	length = sizeof(pstJpegParam->u8YQt)/sizeof(pstJpegParam->u8YQt[0]);

	for(i = 0;i < length;i++) {
		if(pstJpegParam->u8YQt[i] == 0) {
			j++;
		}
		if(pstJpegParam->u8CbCrQt[i] == 0) {
			k++;
		}
	}
	//u8YQt table invalid
	if((j > 0) && (j < length)) {
		VLOG_ERROR("JencChn %d: Invalid u8YQt table.\n", ChnId);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	//u8CbCrQt table invalid
	if((k > 0) && (k < length)) {
		VLOG_ERROR("JencChn %d: Invalid u8CbCrQt table.\n", ChnId);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

int JencRcParamCheck(AX_S32 ChnId, AX_VENC_RC_MODE_E enRcMode, const AX_VENC_RC_PARAM_S *pstRcParam)
{
    if (NULL == pstRcParam) {
		VLOG_ERROR("Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

	switch (enRcMode) {
	case VENC_RC_MODE_MJPEGCBR:
		//Qfactor check
		if ((pstRcParam->stMjpegCbr.u32MinQp < VENC_MIN_QP) ||
			(pstRcParam->stMjpegCbr.u32MinQp > VENC_MAX_QP) ||
			(pstRcParam->stMjpegCbr.u32MaxQp < VENC_MIN_QP) ||
			(pstRcParam->stMjpegCbr.u32MaxQp > VENC_MAX_QP) ||
			(pstRcParam->stMjpegCbr.u32MaxQp < pstRcParam->stMjpegCbr.u32MinQp))
		{
			VLOG_ERROR("JencChn %d: JencRcParamCheck, invalid qp range: MinQp=%u,MaxQp=%u.\n",
					ChnId,
					pstRcParam->stMjpegCbr.u32MinQp,
					pstRcParam->stMjpegCbr.u32MaxQp);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		//BitRate check
		if (pstRcParam->stMjpegCbr.u32BitRate < VENC_MIN_BITRATE ||
			pstRcParam->stMjpegCbr.u32BitRate > VENC_MAX_BITRATE)
		{
			VLOG_ERROR("JencChn %d: JencRcParamCheck, invalid input bitrate=%d(kbps),MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
				ChnId, pstRcParam->stMjpegCbr.u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		break;

	case VENC_RC_MODE_MJPEGVBR:
		//Qfactor check
		if ((pstRcParam->stMjpegVbr.u32MinQp < VENC_MIN_QP) ||
			(pstRcParam->stMjpegVbr.u32MinQp > VENC_MAX_QP) ||
			(pstRcParam->stMjpegVbr.u32MaxQp < VENC_MIN_QP) ||
			(pstRcParam->stMjpegVbr.u32MaxQp > VENC_MAX_QP) ||
			(pstRcParam->stMjpegVbr.u32MaxQp < pstRcParam->stMjpegVbr.u32MinQp))
		{
			VLOG_ERROR("JencChn %d: JencRcParamCheck, invalid qp range: MinQp=%u,MaxQp=%u.\n",
					ChnId,
					pstRcParam->stMjpegVbr.u32MinQp,
					pstRcParam->stMjpegVbr.u32MaxQp);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		//BitRate check
		if (pstRcParam->stMjpegVbr.u32MaxBitRate < VENC_MIN_BITRATE ||
			pstRcParam->stMjpegVbr.u32MaxBitRate > VENC_MAX_BITRATE)
		{
			VLOG_ERROR("JencChn %d: JencRcParamCheck, invalid input bitrate=%d(kbps),MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					ChnId, pstRcParam->stMjpegVbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;

	case VENC_RC_MODE_MJPEGFIXQP:
		//FixedQp check
		if (pstRcParam->stMjpegFixQp.s32FixedQp < -1 ||
			pstRcParam->stMjpegFixQp.s32FixedQp > 51)
		{
			VLOG_ERROR("JencChn %d: JencRcParamCheck, invalid FixedQp=%d.\n",
					ChnId, pstRcParam->stMjpegFixQp.s32FixedQp);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;

	default:
		VLOG_ERROR("JencChn %d: JencRcParamCheck, Invalid Rc mode(%d).\n",
                ChnId, enRcMode);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}
