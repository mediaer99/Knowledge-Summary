

#ifndef _AX_VIDEO_JENC_INIT_H_
#define _AX_VIDEO_JENC_INIT_H_

#include "base_type.h"
#include "ax_video_jenc.h"
#include "ax_venc_log.h"

#ifdef __cplusplus
extern "C" {
#endif
void JencDefaultParameter(AX_JENC_HANDLE_S *pJencHandle);

// int ENCMallocLinear(int size, unsigned int *busAddr, unsigned int **virAddr);
// int ENCFreeLinear(int size, unsigned int busAddr, unsigned int *virAddr);

#ifdef __cplusplus
}
#endif
#endif
