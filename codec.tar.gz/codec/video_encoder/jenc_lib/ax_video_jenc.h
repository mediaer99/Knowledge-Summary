
#ifndef _AX_VIDEO_JENC_H_
#define _AX_VIDEO_JENC_H_

#include "osal.h"
#include "base_type.h"

#include "ax_video_jenc_utils.h"
#include "jenc_api.h"
#include "mjpegencapi.h"

#include "ax_fifo.h"


#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------------
    3. Module defines
------------------------------------------------------------------------------*/

#define INVALID_DEFAULT (-255)
#define MAX_BPS_ADJUST 20
#define MAX_STREAMS 16
#define MAX_SCENE_CHANGE 20
#define MAX_CUTREE_DEPTH 64
#define MAX_DELAY_NUM (MAX_CORE_NUM+MAX_CUTREE_DEPTH)

/* The 2 defines below should be reconsidered. */
#ifndef LEAST_MONITOR_FRAME
#define LEAST_MONITOR_FRAME       3
#endif
#ifndef ENCH2_SLICE_READY_INTERRUPT
#define ENCH2_SLICE_READY_INTERRUPT                      1
#endif

#ifndef MAX_PATH
#define MAX_PATH   256
#endif


int JencOpenEncoder(JpegEncInst *pJencInst, AX_JENC_HANDLE_S *pJencHandle);

int JencCloseEncoder(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle);
int JencAllocRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle);
int JencAllocResNew(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle, const AX_VENC_CHN_ATTR_S *pstAttr);
void JencFreeRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle);


i32 JencProcess(int ChnId, AX_JENC_HANDLE_S *pJencHandle, AX_ENCODR_METADATA_INFO_S in, AX_ENCODR_METADATA_INFO_S *out);

int JencEncodeEnd(AX_JENC_HANDLE_S *pJencHandle);
// int JencEncodeHeader(AX_JENC_HANDLE_S *tb);
int JencHandleUpdateChnAttr(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr, AX_JENC_HANDLE_S *pJencHandle);

int JencHandleGetChnAttr(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr, AX_JENC_HANDLE_S *pJencHandle);

int JencChnAttrCheck(AX_S32 ChnId, const AX_VENC_CHN_ATTR_S *pstAttr);
int JencJpegParamCheck(AX_S32 ChnId, const AX_VENC_JPEG_PARAM_S *pstJpegParam);
int JencRcParamCheck(AX_S32 ChnId, AX_VENC_RC_MODE_E enRcMode, const AX_VENC_RC_PARAM_S *pstRcParam);

AX_S32 JencRateJamProcess(JpegEncInst JencInst, AX_JENC_HANDLE_S *pHandle, AX_S32 VeChn);

void JencEncodeOnceFreeRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle);

int JencEncodeOnceAllocRes(JpegEncInst JencInst, AX_JENC_HANDLE_S *pJencHandle);

unsigned int uJencTimeDiff(struct timeval end, struct timeval start);

#ifdef __cplusplus
}
#endif

#endif
