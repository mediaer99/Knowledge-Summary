#include <math.h>
#include "osal.h"

#include "vsi_string.h"
#include "base_type.h"
#include "error.h"
#include "jenc_api.h"
#include "jenc_ewl.h"
#include "ax_video_jenc.h"
#include "ax_venc_log.h"
#include "enccommon.h"
#include "ax_video_jenc_utils.h"

#ifdef __linux
#include <sys/syscall.h>
#endif
#define gettid() syscall(__NR_gettid)
#define DEBUG_LOG(str, arg...)        \
    do{   \
        printf("  tid:%ld JpegEncApi.c %s %d "str"\n", gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)       \
    do{ \
        printf("  tid:%ld JpegEncApi.c %s %d Error! "str"\n", gettid(), __func__, __LINE__, ##arg);  \
    }while(0)

extern u32 JencGetAlignedByteStride(int width, i32 input_format, u32 *luma_stride, u32 *chroma_stride,u32 input_alignment);

/*------------------------------------------------------------------------------

    JencWriteStrm
        Write encoded stream to file

    Params:
        fout    - file to write
        strbuf  - data to be written
        size    - amount of data to write
        endian  - data endianess, big or little

------------------------------------------------------------------------------*/
void JencWriteStrm(FILE *fout, u32 *strmbuf, u32 size, u32 endian)
{

#ifdef NO_OUTPUT_WRITE
  return;
#endif
	VLOG_ERROR("-------------\n");

  if (!fout || !strmbuf || !size) return;

	VLOG_ERROR("-------------\n");
  /* Swap the stream endianess before writing to file if needed */
  if (endian == 1)
  {
    u32 i = 0, words = (size + 3) / 4;

    while (words)
    {
      u32 val = strmbuf[i];
      u32 tmp = 0;

      tmp |= (val & 0xFF) << 24;
      tmp |= (val & 0xFF00) << 8;
      tmp |= (val & 0xFF0000) >> 8;
      tmp |= (val & 0xFF000000) >> 24;
      strmbuf[i] = tmp;
      words--;
      i++;
    }

  }
	VLOG_ERROR("-------------\n");
  //printf("Write out stream size %d \n", size);
  /* Write the stream to file */
  fwrite(strmbuf, 1, size, fout);
	VLOG_ERROR("-------------\n");
}
#if 0
/*------------------------------------------------------------------------------

    JencWriteStrmBufs
        Write encoded stream to file

    Params:
        fout - file to write
        bufs - stream buffers
        offset - stream buffer offset
        size - amount of data to write
        endian - data endianess, big or little

------------------------------------------------------------------------------*/
void JencWriteStrmBufs (FILE *fout, VCEncStrmBufs *bufs, u32 offset, u32 size, u32 endian)
{
  u8 *buf0 = bufs->buf[0];
  u32 buf0Len = bufs->bufLen[0];

  if (!buf0)
  	return;

  JencWriteStrm(fout, (u32 *)(buf0 + offset), size, endian);

  return;

  #if 0
  if (offset < buf0Len)
  {
  VLOG_ERROR("-------------\n");
    u32 size0 = MIN(size, buf0Len-offset);
    JencWriteStrm(fout, (u32 *)(buf0 + offset), size0, endian);
    if ((size0 < size) && buf1)
      JencWriteStrm(fout, (u32 *)buf1, size-size0, endian);
  }
  else if (buf1)
  {
  VLOG_ERROR("-------------\n");
    JencWriteStrm(fout, (u32 *)(buf1 + offset - buf0Len), size, endian);
  }
#endif
  VLOG_ERROR("-------------\n");
}

static float getPixelWidthInByte(VCEncPictureType type)
{
  switch (type)
  {
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
      return 1.25;
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
      return 2;
    case VCENC_YUV420_PLANAR_10BIT_I010:
    case VCENC_YUV420_PLANAR_10BIT_P010:
      return 2;
    case VCENC_YUV420_PLANAR:
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444:
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
    case VCENC_YUV420_SEMIPLANAR_101010:
      return 1;
    default:
      return 1;
  }
}
#endif

/*------------------------------------------------------------------------------
    Function name : JpegEncGetAlignedStride
    Description   : Returns the stride in byte by given aligment and format.
    Return type   : u32
------------------------------------------------------------------------------*/
u32 JpegEncGetAlignedStride(int width, i32 input_format, u32 *luma_stride, u32 *chroma_stride,u32 input_alignment)
{
    return JencGetAlignedByteStride(width, input_format, luma_stride, chroma_stride, input_alignment);
}


void JencGetAlignedPicSizebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size)
{
    u32 luma_stride=0, chroma_stride = 0;
    u64 lumaSize = 0, chromaSize = 0, pictureSize = 0;

    JpegEncGetAlignedStride(width,type,&luma_stride,&chroma_stride,alignment);
    switch(type)
    {
    case JPEGENC_YUV420_PLANAR:
    case JPEGENC_YVU420_PLANAR:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)chroma_stride * height/2*2;
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)chroma_stride * height/2;
        break;
    case JPEGENC_YUV422_INTERLEAVED_YUYV:
    case JPEGENC_YUV422_INTERLEAVED_UYVY:
    case JPEGENC_RGB565:
    case JPEGENC_BGR565:
    case JPEGENC_RGB555:
    case JPEGENC_BGR555:
    case JPEGENC_RGB444:
    case JPEGENC_BGR444:
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
        lumaSize = (u64)luma_stride * height;
        chromaSize = 0;
        break;
    case JPEGENC_YUV420_I010:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)chroma_stride * height/2*2;
        break;
    case JPEGENC_YUV420_MS_P010:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)chroma_stride * height/2;
        break;
    case JPEGENC_YUV420_8BIT_DAHUA_HEVC:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)lumaSize/2;
        break;
    case JPEGENC_YUV420_8BIT_DAHUA_H264:
        lumaSize = (u64)luma_stride * height * 2* 12/ 8;
        chromaSize = 0;
        break;
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        lumaSize = (u64)luma_stride * ((height+3)/4);
        chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
        break;
    case JPEGENC_YUV422_888:
        lumaSize = (u64)luma_stride * height;
        chromaSize = (u64)chroma_stride * height;
        break;
    case JPEGENC_YUV420_8BIT_TILE_8_8:
        lumaSize = (u64)luma_stride * ((height+7)/8);
        chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
        break;
    case JPEGENC_YUV420_10BIT_TILE_8_8:
        lumaSize = (u64)luma_stride * ((height+7)/8);
        chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
        break;
    case JPEGENC_YUV420_FBC:
        lumaSize = luma_stride *((height +1)/2);
        chromaSize = chroma_stride * (((height/2)+1)/2);
        break;
    default:
        printf("not support this format\n");
        chromaSize = lumaSize = 0;
        break;
    }

    pictureSize = lumaSize + chromaSize;
    if (luma_Size != NULL)
        *luma_Size = lumaSize;
    if (chroma_Size != NULL)
        *chroma_Size = chromaSize;
    if (picture_Size != NULL)
        *picture_Size = pictureSize;
}

void JencGetDec400CompTablebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size, i32 dec400VersionId)
{
    u32 luma_stride=0, chroma_stride = 0;
    u64 lumaSize = 0, chromaSize = 0, pictureSize = 0;
    u64 chromaPaddingSize = 0;
    if (alignment == 0)
        alignment = 256;
    JpegEncGetAlignedStride(width,type,&luma_stride,&chroma_stride,alignment);

    u32 tileSize = 256;
    if(1 == dec400VersionId || 3 == dec400VersionId)
    {
        tileSize = 128;
    }
    else if(2 == dec400VersionId)
    {
        tileSize = 64;
    }

    switch(type)
    {
    case JPEGENC_YUV420_PLANAR:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize * 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize * 2, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        //OYB M1 planner format: padding cb cr respectively
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8*2;
        }
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8;
        break;
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = 0;
        break;
    case JPEGENC_YUV420_I010:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize * 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize * 2, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8*2;
        }
        break;
    case JPEGENC_YUV420_MS_P010:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8;
        break;
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize / 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize / 4, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*4 * ((height+3)/4),8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*4 * (((height/2)+3)/4),8*16)/ 8;
        }
        break;
    default:
        printf("not support this format\n");
        chromaSize = lumaSize = 0;
        break;
    }

    pictureSize = lumaSize + chromaSize;
    pictureSize += chromaPaddingSize;

    if (luma_Size != NULL)
        *luma_Size = lumaSize;
    if (chroma_Size != NULL)
        *chroma_Size = chromaSize;
    if (picture_Size != NULL)
        *picture_Size = pictureSize;
}

#if 0
static i32 getSmartOpt (char *line, char *opt, i32 *val)
{
  char *p = strstr(line, opt);
  if (!p)
    return NOK;

  p = strchr(line, '=');
  if (!p)
    return NOK;

  p ++;
  while (*p == ' ') p ++;
  if (*p == '\0')
    return NOK;

  sscanf(p, "%d", val);
  return OK;
}
#endif

#if 0
/*------------------------------------------------------------------------------
  file_read
------------------------------------------------------------------------------*/
static i32 file_read(FILE *file, u8 *data, u64 seek, size_t size)
{
  if ((file == NULL) || (data == NULL)) return NOK;

  fseeko(file, seek, SEEK_SET);
  if (fread(data, sizeof(u8), size, file) < size)
  {
    if (!feof(file))
    {
      Error(2, ERR, SYSERR);
    }
    return NOK;
  }

  return OK;
}
#endif

/*------------------------------------------------------------------------------
    Add new frame bits for moving average bitrate calculation
------------------------------------------------------------------------------*/
void JencMaAddFrame(Jenc_ma_s *ma, i32 frameSizeBits)
{
    ma->frame[ma->pos++] = frameSizeBits;

    if (ma->pos == ma->length)
        ma->pos = 0;

    if (ma->count < ma->length)
        ma->count++;
}

/*------------------------------------------------------------------------------
    Calculate average bitrate of moving window
------------------------------------------------------------------------------*/
i32 JencMa(Jenc_ma_s *ma)
{
    i32 i;
    unsigned long long sum = 0;     /* Using 64-bits to avoid overflow */

    for (i = 0; i < ma->count; i++)
        sum += ma->frame[i];

    if (!ma->frameRateDenom)
        return 0;

    sum = sum / ma->count;

    return sum * (ma->frameRateNumer+ma->frameRateDenom-1) / ma->frameRateDenom;
}

int JencReadRoimap(AX_JENC_HANDLE_S *pJencHandle, const void* ewl_inst)
{
    FILE *fpROI;
    char buf[30];
    i32 RoiRectNum = 0;
    u32 RoiRectLeft[30];
    u32 RoiRectTop[30];
    u32 RoiRectWidth[30];
    u32 RoiRectHeight[30];
    /* u32 RoiRegionCal = 0; */
    /* u32 RoiRegionCalWidth = 0; */
    u32 RoiSize = 0;
    u32 ImageWidthMB = 0;
    u32 ImageHeightMB = 0;
    /* u8 NumsBit = 0; */
    /* u8 BitSet = 0; */
    /* u32 byte_start[30]; */
    /* u32 byte_offest[30]; */
    u8 *roimap_virtualAddr = NULL;
    u8 RoiRegion_SetVal[8] = {0};
    u32 bitNum = 0;
    u8 roiValTmp = 0;
    /* u32 sliceRows = 0; */
    u32 sliceRowsMb = 0;
    /* u32 mcuh = 0; */
    u32 RoiSizePerSlice = 0;
    u32 MbNumPerSlice = 0;
    JencCommandLine_s * cmdl = &pJencHandle->stCmdl;

    // static const u8 set_val[9] = {0x00, 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};
    fpROI = fopen(cmdl->roimapFile, "r");
    if (fpROI == NULL)
    {
        printf("jpeg_map.roi: Error, Can Not Open File %s\n", cmdl->roimapFile);
        return -1;
    }
    while(fgets(buf, 30, fpROI)!=NULL)
    {
        if(buf[0] == 'r')
        {
            sscanf(buf,"roi=(%d,%d,%d,%d)",
                &RoiRectLeft[RoiRectNum],&RoiRectTop[RoiRectNum],
                &RoiRectWidth[RoiRectNum],&RoiRectHeight[RoiRectNum]);

            if (RoiRectLeft[RoiRectNum] + RoiRectWidth[RoiRectNum] > cmdl->output_width
                || RoiRectTop[RoiRectNum] + RoiRectHeight[RoiRectNum] > cmdl->output_height)
            {
                printf("jpeg_map.roi: Error, The Roi Region Coordinate Input Is Out Of Picture Range!\n");
                fclose(fpROI);
                return -1;
            }
            if(cmdl->codingMode == JPEGENC_420_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/16;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/16;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+15)/16;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+15)/16;
            }
            else if(cmdl->codingMode == JPEGENC_422_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/16;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/8;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+15)/16;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+7)/8;
            }
            else if(cmdl->codingMode == JPEGENC_MONO_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/8;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/8;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+7)/8;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+7)/8;
            }
            RoiRectNum++;
        }
    }
    fclose(fpROI);

    if(cmdl->codingMode == JPEGENC_420_MODE)
    {
        ImageWidthMB = (cmdl->output_width + 15) / 16;
        ImageHeightMB = (cmdl->output_height + 15) / 16;
    }
    else if(cmdl->codingMode == JPEGENC_422_MODE)
    {
        ImageWidthMB = (cmdl->output_width + 15) / 16;
        ImageHeightMB = (cmdl->output_height + 7) / 8;
    }
    else if(cmdl->codingMode == JPEGENC_MONO_MODE)
    {
        ImageWidthMB = (cmdl->output_width + 7) / 8;
        ImageHeightMB = (cmdl->output_height + 7) / 8;
    }
    if(cmdl->partialCoding == 0)
    {
        RoiSize = (ImageWidthMB*ImageHeightMB+7)/8;
        sliceRowsMb = ImageHeightMB;
    }
    else
    {
        if(cmdl->codingMode == JPEGENC_420_MODE)
        {
            sliceRowsMb = cmdl->restartInterval;
        }
        else
        {
            sliceRowsMb = cmdl->restartInterval*2;
        }
        RoiSizePerSlice = (sliceRowsMb*ImageWidthMB+7)/8;
        RoiSize = RoiSizePerSlice*((ImageHeightMB+sliceRowsMb-1)/sliceRowsMb);
    }

    pJencHandle->roimapMem.mem_type = EWL_MEM_TYPE_VPU_WORKING;
    if(JencEWLMallocLinear(ewl_inst, RoiSize, 0, &pJencHandle->roimapMem) != EWL_OK)
    {
        fprintf(stderr, "Failed to allocate RoiMap Memory!\n");
        pJencHandle->roimapMem.virtualAddress = NULL;
        return 1;
    }
    memset(pJencHandle->roimapMem.virtualAddress, 0, RoiSize);
    // ROI bitmap need 1
    roimap_virtualAddr = (u8 *)pJencHandle->roimapMem.virtualAddress;

    for(int roinum = 0; roinum < RoiRectNum; roinum++)
    {
        roimap_virtualAddr = (u8 *)pJencHandle->roimapMem.virtualAddress;
        for(int rows = 0; rows < ImageHeightMB; rows++)
        {
            for(int cals = 0; cals < ImageWidthMB; cals++)
            {
                if((rows >= RoiRectTop[roinum] && rows < (RoiRectTop[roinum] + RoiRectHeight[roinum]))
                     && cals >= RoiRectLeft[roinum] && cals < (RoiRectLeft[roinum] + RoiRectWidth[roinum]))//ROI
                {
                     RoiRegion_SetVal[bitNum] = 1;
                }
                else
                {
                    RoiRegion_SetVal[bitNum] = 0;
                }
                bitNum++;
                if(bitNum == 8 || (rows == ImageHeightMB-1 && cals == ImageWidthMB-1) || (MbNumPerSlice == sliceRowsMb*ImageWidthMB-1))
                {
                    roiValTmp = RoiRegion_SetVal[0]*128+RoiRegion_SetVal[1]*64+RoiRegion_SetVal[2]*32+
                    RoiRegion_SetVal[3]*16+RoiRegion_SetVal[4]*8+RoiRegion_SetVal[5]*4+RoiRegion_SetVal[6]*2+
                    RoiRegion_SetVal[7]*1;
                    *roimap_virtualAddr = *roimap_virtualAddr | roiValTmp;
                    roimap_virtualAddr++;
                    roiValTmp = 0;
                    bitNum = 0;
                    memset(RoiRegion_SetVal, 0, sizeof(RoiRegion_SetVal));
                }
                MbNumPerSlice++;
                if(MbNumPerSlice == sliceRowsMb*ImageWidthMB || (rows == ImageHeightMB-1 && cals == ImageWidthMB-1))
                {
                    MbNumPerSlice=0;
                }
            }
        }
    }
    return 0;
}

void JencGetOsdDec400SizeJpeg(JencCommandLine_s *cmdl, u8 dec400VersionId, u8 idx, u32 *dec400TableSize)
{
    /* i32 ret = 0; */
    u32 luma_stride=cmdl->olYStride[idx];
    u32 height = (cmdl->olHeight[idx] + 63)/64;
    u32 pictureSize = 0;

    ASSERT(cmdl->olFormat[idx] == 0 && cmdl->olSuperTile[idx]);

    u32 tileSize = 256;
    if(1 == dec400VersionId || 3 == dec400VersionId)
    {
        tileSize = 128;
    }
    else if(2 == dec400VersionId)
    {
        tileSize = 64;
    }

    /* Since SuperTile format will always be 64x64 aligned, no need to take care tile align */
    pictureSize = STRIDE(luma_stride * height/tileSize*4,8)/ 8;

    *dec400TableSize = pictureSize;
}


void JencParamPrintLog(JencCommandLine_s *pCmdl, JpegEncCfg cfg)
{
#ifdef JENC_DEBUG_TRACE
    JencCommandLine_s *cml = pCmdl;

    fprintf(stdout, "Init config: %dx%d @ x%dy%d => %dx%d   \n",
            cfg.inputWidth, cfg.inputHeight, cfg.xOffset, cfg.yOffset,
            cfg.codingWidth, cfg.codingHeight);

    fprintf(stdout,
            "\n\t**********************************************************\n");
    fprintf(stdout, "\n\t-JPEG: ENCODER CONFIGURATION\n");
    if (cml->qLevel == USER_DEFINED_QTABLE) {
        i32 i;
        fprintf(stdout, "\t-JPEG: qTableLuma :");
        for (i = 0; i < 64; i++) {
            if (i % 16 == 0)
                fprintf(stdout, "\n \t");
            fprintf(stdout, " %d", cfg.qTableLuma[i]);
        }

        fprintf(stdout, "\n");
        fprintf(stdout, "\t-JPEG: qTableChroma :");
        for (i = 0; i < 64; i++) {
            if (i % 16 == 0)
                fprintf(stdout, "\n \t");
            fprintf(stdout, " %d", cfg.qTableChroma[i]);
        }

        fprintf(stdout, "\n");
    }
    else
        fprintf(stdout, "\t-JPEG: qp \t\t:%d\n", cfg.qLevel);

    fprintf(stdout, "\t-JPEG: inX \t\t:%d\n", cfg.inputWidth);
    fprintf(stdout, "\t-JPEG: inY \t\t:%d\n", cfg.inputHeight);
    fprintf(stdout, "\t-JPEG: outX \t\t:%d\n", cfg.codingWidth);
    fprintf(stdout, "\t-JPEG: outY \t\t:%d\n", cfg.codingHeight);
    fprintf(stdout, "\t-JPEG: rst \t\t:%d\n", cfg.restartInterval);
    fprintf(stdout, "\t-JPEG: xOff \t\t:%d\n", cfg.xOffset);
    fprintf(stdout, "\t-JPEG: yOff \t\t:%d\n", cfg.yOffset);
    fprintf(stdout, "\t-JPEG: frameType \t:%d\n", cfg.frameType);
    fprintf(stdout, "\t-JPEG: colorConversionType :%d\n", cfg.colorConversion.type);
    fprintf(stdout, "\t-JPEG: colorConversionA    :%d\n", cfg.colorConversion.coeffA);
    fprintf(stdout, "\t-JPEG: colorConversionB    :%d\n", cfg.colorConversion.coeffB);
    fprintf(stdout, "\t-JPEG: colorConversionC    :%d\n", cfg.colorConversion.coeffC);
    fprintf(stdout, "\t-JPEG: colorConversionE    :%d\n", cfg.colorConversion.coeffE);
    fprintf(stdout, "\t-JPEG: colorConversionF    :%d\n", cfg.colorConversion.coeffF);
    fprintf(stdout, "\t-JPEG: rotation \t:%d\n", cfg.rotation);
    fprintf(stdout, "\t-JPEG: codingType \t:%d\n", cfg.codingType);
    fprintf(stdout, "\t-JPEG: codingMode \t:%d\n", cfg.codingMode);
    fprintf(stdout, "\t-JPEG: markerType \t:%d\n", cfg.markerType);
    fprintf(stdout, "\t-JPEG: units \t\t:%d\n", cfg.unitsType);
    fprintf(stdout, "\t-JPEG: xDen \t\t:%d\n", cfg.xDensity);
    fprintf(stdout, "\t-JPEG: yDen \t\t:%d\n", cfg.yDensity);


    fprintf(stdout, "\t-JPEG: thumbnail format\t:%d\n", cml->thumbnail);
    fprintf(stdout, "\t-JPEG: Xthumbnail\t:%d\n", cml->widthThumb);
    fprintf(stdout, "\t-JPEG: Ythumbnail\t:%d\n", cml->heightThumb);

    fprintf(stdout, "\t-JPEG: First picture\t:%d\n", cml->firstPic);
    fprintf(stdout, "\t-JPEG: Last picture\t\t:%d\n", cml->lastPic);
    fprintf(stdout, "\t-JPEG: inputLineBufEn \t\t:%d\n", cfg.inputLineBufEn);
    fprintf(stdout, "\t-JPEG: inputLineBufLoopBackEn \t:%d\n", cfg.inputLineBufLoopBackEn);
    fprintf(stdout, "\t-JPEG: inputLineBufHwModeEn \t:%d\n", cfg.inputLineBufHwModeEn);
    fprintf(stdout, "\t-JPEG: inputLineBufDepth \t:%d\n", cfg.inputLineBufDepth);
    fprintf(stdout, "\t-JPEG: amountPerLoopBack \t:%d\n", cfg.amountPerLoopBack);

    fprintf(stdout, "\t-JPEG: streamMultiSegmentMode \t:%d\n", cfg.streamMultiSegmentMode);
    fprintf(stdout, "\t-JPEG: streamMultiSegmentAmount \t:%d\n", cfg.streamMultiSegmentAmount);

    fprintf(stdout, "\t-JPEG: constChromaEn \t:%d\n", cfg.constChromaEn);
    fprintf(stdout, "\t-JPEG: constCb \t:%d\n", cfg.constCb);
    fprintf(stdout, "\t-JPEG: constCr \t:%d\n", cfg.constCr);

#ifdef TB_DEFINED_COMMENT
    fprintf(stdout, "\n\tNOTE! Using comment values defined in testbench!\n");
#else
    fprintf(stdout, "\t-JPEG: comlen \t\t:%d\n", cfg.comLength);
    fprintf(stdout, "\t-JPEG: COM \t\t:%s\n", cfg.pCom);
#endif
    fprintf(stdout,
            "\n\t**********************************************************\n\n");
#endif

}


i32 JencImgFormat2FrameType(AX_IMG_FORMAT_E enFormat)
{
    i32 FrameType;
    switch(enFormat) {
    case AX_YUV420_PLANAR:
        FrameType = JPEGENC_YUV420_PLANAR;
        break;
    case AX_YUV420_SEMIPLANAR:
        FrameType = JPEGENC_YUV420_SEMIPLANAR;
        break;
    case AX_YUV420_SEMIPLANAR_VU:
        FrameType = JPEGENC_YUV420_SEMIPLANAR_VU;
        break;
    case AX_YUV422_INTERLEAVED_YUYV:
        FrameType = JPEGENC_YUV422_INTERLEAVED_YUYV;
        break;
    case AX_YUV422_INTERLEAVED_UYVY:
        FrameType = JPEGENC_YUV422_INTERLEAVED_UYVY;
        break;
    default:
        FrameType = -1;
        break;
    }
#if 0
    AX_YUV444_PACKED = 0x05,          /* YUV YUV YUV ...          */
    /* RGB Format */
    AX_FORMAT_RGB565 = 0x40,
    AX_FORMAT_RGB888 = 0x41,        /**<  RGB888 24bpp */

    AX_FORMAT_KRGB444 = 0x42,       /**<  RGB444 16bpp */
    AX_FORMAT_KRGB555 = 0x43,       /**<  RGB555 16bpp */
    AX_FORMAT_KRGB888 = 0x44,       /**<  RGB888 32bpp */

    AX_FORMAT_ARGB4444 = 0x45,      /**< ARGB4444 */
    AX_FORMAT_ARGB1555 = 0x46,      /**< ARGB1555 */
    AX_FORMAT_ARGB8888 = 0x47,      /**< ARGB8888 */
    AX_FORMAT_ARGB8565 = 0x48,      /**< ARGB8565 */

    AX_FORMAT_BGR888,               /**< BGR888 24bpp */

        JPEGENC_RGB565,                                      /* 16-bit RGB 16bpp         */
        JPEGENC_BGR565,                                      /* 16-bit RGB 16bpp         */
        JPEGENC_RGB555,                                      /* 15-bit RGB 16bpp         */
        JPEGENC_BGR555,                                      /* 15-bit RGB 16bpp         */
        JPEGENC_RGB444,                                      /* 12-bit RGB 16bpp         */
        JPEGENC_BGR444,                                      /* 12-bit RGB 16bpp         */
        JPEGENC_RGB888,                                      /* 24-bit RGB 32bpp         */
        JPEGENC_BGR888,                                      /* 24-bit RGB 32bpp         */
        JPEGENC_RGB101010,                                   /* 30-bit RGB 32bpp         */
        JPEGENC_BGR101010,                                   /* 30-bit RGB 32bpp         */
        JPEGENC_YUV420_I010 = 15,                            /* 10-bit YUV 24bpp         */
        JPEGENC_YUV420_MS_P010 = 16,                         /* 10-bit YUVSP 24bpp       */
        JPEGENC_YUV420_8BIT_DAHUA_HEVC = 19,                 /* 8-bit DAHUA_HEVC         */
        JPEGENC_YUV420_8BIT_DAHUA_H264 = 20,                 /* 8-bit DAHUA_H264         */
        JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4 = 21,        /* YYYY... UVUVUV...        */
        JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4 = 22,     /* YYYY... VUVUVU...        */
        JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4 = 23,      /* YYYY... UVUV... */
        JPEGENC_YUV422_888 = 25,                             /* YYYY... UVUVUV...        */
        JPEGENC_YUV420_8BIT_TILE_8_8 = 35,                   /* 8-bit 8x8 tile              */
        JPEGENC_YUV420_10BIT_TILE_8_8 = 36,                  /* 10-bit 8x8 tile              */
        JPEGENC_YVU420_PLANAR = 37,                          /* 10-bit 8x8 tile              */
        JPEGENC_YUV420_FBC = 38                              /* 8-bit 64x2 tile          */
#endif
    return FrameType;
}

