#include <fcntl.h>

#include "ax_jenc_proc.h"
#include "ax_venc_interface.h"
#include "ax_venc_log.h"
#include "vc8000_driver.h"
#include "ax_video_jenc.h"
#include "ax_video_jenc_hal.h"
#include <sys/time.h>
#include <signal.h>
#include <time.h>
#include <sys/ioctl.h>

extern AX_JENC_HANDLE_S *gJencHandle[MAX_VENC_NUM];
extern AX_VENC_MOD_INSTANCE_S gModCtx;
extern AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM];
extern AX_S32 g_fd_jenc;

static timer_t jenc_timer_id = 0;
static AX_S32 JencProcCatCallback(char *msg, int msgMaxLen);
static void JencProcUpdate();

static JENC_PROC_PARAMS_S gJencProcParams = {
	.bExit = AX_FALSE,
	.callback = JencProcCatCallback,
};

static AX_VOID *JencListenerThread(AX_VOID *args)
{
	AX_S32 s32Ret = -1;
	char procMsg[PROC_MSG_LEN];
	JENC_PROC_PARAMS_S *pArgs = (JENC_PROC_PARAMS_S *)args;

	if (NULL == pArgs || NULL == pArgs->callback) {
		VLOG_ERROR("JENC proc invalid args.\n");
		return NULL;
	}

	while (!pArgs->bExit) {
		s32Ret = ioctl(g_fd_jenc, HANTRO_IOCH_VENC_PROC_TRIGGER);
		if (0 != s32Ret)
		{
			VLOG_ERROR("JENC proc trigger fail, retry...\n");
			usleep(5000);
			continue;
		}

		if (NULL != pArgs->callback) {
			s32Ret = pArgs->callback(procMsg, PROC_MSG_LEN);
            if (0 != s32Ret) {
                VLOG_ERROR("JENC proc pArgs->callback fail, s32Ret:0x%x retry...\n", s32Ret);
            }
        }

		s32Ret = ioctl(g_fd_jenc, HANTRO_IOCH_VENC_PROC_UPDATE, &procMsg);
		if (0 != s32Ret) {
			VLOG_ERROR("JENC proc update message fail, s32Ret:0x%x retry...\n", s32Ret);
		}
	}

	return NULL;
}

//proc info update
void JencProcUpdate(union sigval v)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst;
	AX_S32 s32Ret;

	for (int i = 0; i < MAX_VENC_NUM; i++) {
		if (PT_MJPEG != gModCtx.enChnCodecType[i])
			continue;

		s32Ret = pthread_mutex_lock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret) {
			VLOG_ERROR("VENC %d: proc lock err(%d).\n", i, s32Ret);
			continue;
		}
		pChnInst = gChnInst[i];

		if (NULL == pChnInst || (NULL == gJencHandle[i])) {
			s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			if (s32Ret)
				VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);

			continue;
		}

		pChnInst->pEncoder->pfnUpdateFpsBr(pChnInst);

		s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);
	}
	return;
}

AX_S32 JencProcInit(AX_VOID)
{
	AX_S32 s32Ret;
	struct sigevent evp;
	struct itimerspec ts;

	/* init timer */
	memset(&evp, 0, sizeof (evp));
	evp.sigev_value.sival_ptr = &jenc_timer_id;
	evp.sigev_notify = SIGEV_THREAD;
	evp.sigev_notify_function = JencProcUpdate;
	evp.sigev_value.sival_int = 3;

	s32Ret = timer_create(CLOCK_REALTIME, &evp, &jenc_timer_id);
	if (s32Ret) {
		VLOG_ERROR("JENC proc timer_create error\n");
		jenc_timer_id = 0;
		return AX_ERR_VENC_UNKNOWN;
	}

	ts.it_interval.tv_sec = 3;
	ts.it_interval.tv_nsec = 0;
	ts.it_value.tv_sec = 3;
	ts.it_value.tv_nsec = 0;

	s32Ret = timer_settime(jenc_timer_id, TIMER_ABSTIME, &ts, NULL);
	if (s32Ret) {
		VLOG_ERROR("JENC proc timer_settime error\n");
		return AX_ERR_VENC_UNKNOWN;
	}

	gJencProcParams.bExit = AX_FALSE;
	gJencProcParams.callback = JencProcCatCallback;

	s32Ret = pthread_create(&gJencProcParams.threadId, NULL, JencListenerThread, &gJencProcParams);
	if (0 != s32Ret) {
		VLOG_ERROR("JENC proc thread create error.!\n");
		goto ERROR;
	}

	VLOG_ERROR("JENC proc init success.\n");
	return AX_SUCCESS;

ERROR:

	return AX_ERR_VENC_SYS_NOTREADY;
}

AX_S32 JencProcDeinit(AX_VOID)
{
	AX_S32 s32Ret;

	gJencProcParams.bExit = AX_TRUE;

	s32Ret = ioctl(g_fd_jenc, HANTRO_IOCH_VENC_PROC_WAKEUP);
	if (s32Ret) {
		VLOG_ERROR("JENC proc wakeup error.\n");
		return AX_ERR_VENC_UNKNOWN;
	}

	pthread_join(gJencProcParams.threadId, NULL);
	gJencProcParams.callback = NULL;

	if (jenc_timer_id) {
		s32Ret = timer_delete(jenc_timer_id);
		if ( s32Ret) {
			VLOG_ERROR("JENC proc timer_delete error\n");
			return AX_ERR_VENC_UNKNOWN;
		}
	}

	VLOG_ERROR("JENC proc deinit success.\n");
	return AX_SUCCESS;
}

static char *GetImageFormat(VENC_CHN VeChn, AX_IMG_FORMAT_E enImgFmt)
{
    switch (enImgFmt)
    {
    case AX_YUV420_PLANAR:
        return "YUV420P";
    case AX_YUV420_SEMIPLANAR:
        return "NV12";
    case AX_YUV420_SEMIPLANAR_VU:
        return "NV21";
    case AX_YUV422_INTERLEAVED_YUYV:
        return "YUYV422";
    case AX_YUV422_INTERLEAVED_UYVY:
        return "UYVY422";
    default:
        VLOG_ERROR("JENC %d: Unknow Image format.\n", VeChn);
        break;
    }
    return "N/A";
}

//add more proc info later
static AX_S32 JencProcCatCallback(char *msg, int msgMaxLen)
{
	AX_S32 s32Ret;

	memset(msg, 0, msgMaxLen);

	snprintf(msg + strlen(msg),
		msgMaxLen - strlen(msg),
		"-------- MODULE PARAM ------------------------\n"
		"%-12s%-12s\n", "MaxChnSize", "MaxRoiSize");

	snprintf(msg + strlen(msg),
		msgMaxLen - strlen(msg),
		"%-12u%-12u\n\n",
		MAX_VENC_NUM,
		MAX_ROI_NUM);

	AX_VENC_CHN_INSTANCE_S *pChnInst;
	for (int i = 0; i < MAX_VENC_NUM; i++) {
		if (PT_JPEG != gModCtx.enChnCodecType[i] && PT_MJPEG != gModCtx.enChnCodecType[i])
			continue;

		s32Ret = pthread_mutex_lock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret) {
			VLOG_ERROR("JENC %d: proc lock err(%d).\n", i, s32Ret);
			continue;
		}
		pChnInst = gChnInst[i];

		if ((NULL == pChnInst) || (NULL == gJencHandle[i])) {
			s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			if (s32Ret) {
				VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);
            }
			continue;
		}

		/* Channel attribute */
		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"-------- JENC CHN ATTR  ------------------------\n"
			"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
			"ID", "Type", "wSrc", "hSrc", "Strd0", "Strd1", "PixFmt", "Qfactor", "IsLink", "MultiSlice", "InFifoDepth", "OutFifoDepth", "StrmBufSize(kb)");

		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"%-8d%-13s%-13d%-13d%-13d%-13d%-13s%-13d%-13s%-13d%-13d%-13d%-13d\n",
			i,
			pChnInst->stVencChnAttr.stVencAttr.enType == PT_JPEG ? "jpeg" : "mjpeg",
			pChnInst->stVencChnAttr.stVencAttr.u32PicWidthSrc,
			pChnInst->stVencChnAttr.stVencAttr.u32PicHeightSrc,
			gJencHandle[i]->u32PicStride[0],
			gJencHandle[i]->u32PicStride[1],
			GetImageFormat(i, pChnInst->stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.enImgFormat),
			gJencHandle[i]->u32Qfactor,
			pChnInst->stVencChnAttr.stVencAttr.enLinkMode == AX_LINK_MODE ? "true" : "false",
			pChnInst->stVencChnAttr.stVencAttr.u32MbLinesPerSlice,
			pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth,
			pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth,
			pChnInst->stVencChnAttr.stVencAttr.u32BufSize/1000);

		/* RC attribute */
		if (PT_MJPEG == pChnInst->stVencChnAttr.stVencAttr.enType) {
			if (VENC_RC_MODE_MJPEGCBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- JENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "StatTime", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"CBR",
					gJencHandle[i]->stRcParam.stMjpegCbr.u32StatTime,
					gJencHandle[i]->stRcParam.stMjpegCbr.u32SrcFrameRate,
					gJencHandle[i]->stRcParam.stMjpegCbr.fr32DstFrameRate,
					gJencHandle[i]->stRcParam.stMjpegCbr.u32BitRate,
					gJencHandle[i]->stRcParam.stMjpegCbr.u32MinQp,
					gJencHandle[i]->stRcParam.stMjpegCbr.u32MaxQp);
			} else if (VENC_RC_MODE_MJPEGVBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- JENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "StatTime", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"VBR",
					gJencHandle[i]->stRcParam.stMjpegVbr.u32StatTime,
					gJencHandle[i]->stRcParam.stMjpegVbr.u32SrcFrameRate,
					gJencHandle[i]->stRcParam.stMjpegVbr.fr32DstFrameRate,
					gJencHandle[i]->stRcParam.stMjpegVbr.u32MaxBitRate,
					gJencHandle[i]->stRcParam.stMjpegVbr.u32MinQp,
					gJencHandle[i]->stRcParam.stMjpegVbr.u32MaxQp);
			} else if (VENC_RC_MODE_MJPEGFIXQP == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- JENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "SrcFr", "DstFr", "FixedQp");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d\n",
					i,
					"FixQP",
					gJencHandle[i]->stRcParam.stMjpegFixQp.u32SrcFrameRate,
					gJencHandle[i]->stRcParam.stMjpegFixQp.fr32DstFrameRate,
					gJencHandle[i]->stRcParam.stMjpegFixQp.s32FixedQp);
			}
		}

		/* encode statistic */
		snprintf(msg + strlen(msg),
			msgMaxLen - strlen(msg),
			"-------- JENC STATUS  ------------------------\n"
			"%-8s%-8s%-13s%-13s%-13s%-13s%-13s%-16s%-13s%-13s\n", "ID", "State", "FrmRecvNum", "FrmRlsNum", "FrmEncNum", "StrmGetNum", "StrmRlsNum", "BlkGetFailNum", "RealFr(fps)", "RealBr(kbps)");

		if (pChnInst->enType == PT_MJPEG)
		{
			snprintf(msg + strlen(msg),
				msgMaxLen - strlen(msg),
				"%-8d%-8d%-13llu%-13llu%-13llu%-13llu%-13llu%-16llu%-13.2f%-13llu\n\n",
				i,
				gModCtx.enChnState[i],
				pChnInst->u64TotalRecvFrameNum,
				pChnInst->u64TotalReleaseFrameNum,
				pChnInst->u64TotalEncodeNum,
				pChnInst->u64TotalGetStrmNum,
				pChnInst->u64TotalReleaseStrmNum,
				pChnInst->u64TotalBlkGetFailNum,
				pChnInst->F32RealTimeFrameRate,
				pChnInst->u64RealTimeBitRate);
		}
		else if (pChnInst->enType == PT_JPEG)
		{

			snprintf(msg + strlen(msg),
				msgMaxLen - strlen(msg),
				"%-8d%-8d%-13llu%-13llu%-13llu%-13llu%-13llu%-16llu%-13s%-13s\n\n",
				i,
				gModCtx.enChnState[i],
				pChnInst->u64TotalRecvFrameNum,
				pChnInst->u64TotalReleaseFrameNum,
				pChnInst->u64TotalEncodeNum,
				pChnInst->u64TotalGetStrmNum,
				pChnInst->u64TotalReleaseStrmNum,
				pChnInst->u64TotalBlkGetFailNum,
				"N/A",
				"N/A");
		}

		s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret)
			VLOG_ERROR("JENC %d: proc unlock err(%d).\n", i, s32Ret);
	}

	return 0;
}