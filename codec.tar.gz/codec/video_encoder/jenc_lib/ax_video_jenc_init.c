#include <math.h>
#include <linux/ioctl.h>
#include "vsi_string.h"
#include "enccfg.h"
#include "ax_video_jenc_init.h"

void JencDefaultParameter(AX_JENC_HANDLE_S *pJencHandle)
{
    JencCommandLine_s *cml = &pJencHandle->stCmdl;
    memset(cml, 0, sizeof(JencCommandLine_s));
    // strcpy(cml->input, "input.yuv");
    // strcpy(cml->inputThumb, "thumbnail.jpg");
    // strcpy(cml->com, "com.txt");
    // strcpy(cml->output, "stream.jpg");
    // strcpy(cml->qTablePath, "");
    cml->useVcmd = -1;
    cml->roimapFile = NULL;
    cml->nonRoiFilter = NULL;
    cml->nonRoiLevel = 10;
    cml->firstPic = 0;
    cml->lastPic = 0;
    cml->lumWidthSrc = INVALID_DEFAULT;
    cml->lumHeightSrc = INVALID_DEFAULT;
    cml->output_width = INVALID_DEFAULT;
    cml->output_height = INVALID_DEFAULT;
    cml->horOffsetSrc = 0;
    cml->verOffsetSrc = 0;
    cml->qLevel = 1;
    cml->restartInterval = 0;
    cml->thumbnail = 0;
    cml->widthThumb = 32;
    cml->heightThumb = 32;
    cml->frameType = 0;
    cml->colorConversion = 0;
    cml->rotation = 0;
    cml->partialCoding = 0;
    cml->codingMode = 0;
    cml->markerType = 0;
    cml->unitsType = 0;
    cml->xdensity = 1;
    cml->ydensity = 1;
    // cml->writeOut = 1;
    cml->comLength = 0;
    cml->inputLineBufMode = 0;
    cml->inputLineBufDepth = 1;
    cml->amountPerLoopBack = 0;
    cml->hashtype = 0;
    cml->mirror = 0;
    cml->formatCustomizedType = -1;
    cml->constChromaEn = 0;
    cml->constCb = 0x80;
    cml->constCr = 0x80;
    cml->predictMode = 0;
    cml->ptransValue = 0;
    cml->bitPerSecond =0;
    cml->mjpeg = 0;
    cml->frameRateNum = 30;
    cml->frameRateDenom = 1;
    cml->rcMode        = 1;
    cml->picQpDeltaMin = -2;
    cml->picQpDeltaMax = 3;
    cml->qpmin = 0;
    cml->qpmax = 51;
    cml->fixedQP = -1;
    cml->exp_of_input_alignment = 4;
    cml->streamBufChain = 0;
    cml->streamMultiSegmentMode = 0;
    cml->streamMultiSegmentAmount = 4;
    // strcpy(cml->dec400CompTableinput, "dec400CompTableinput.bin");
    cml->AXIAlignment = 0;
    cml->mmuEnable = 0;
    /*Overlay*/
    cml->overlayEnables = 0;
    // strcpy(cml->osdDec400CompTableInput, "osdDec400CompTableinput.bin");

    for(int i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        // strcpy(cml->olInput[i], "olInput.yuv");
        cml->olFormat[i] = 0;
        cml->olAlpha[i] = 0;
        cml->olWidth[i] = 0;
        cml->olHeight[i] = 0;
        cml->olXoffset[i] = 0;
        cml->olYoffset[i] = 0;
        cml->olYStride[i] = 0;
        cml->olUVStride[i] = 0;
        cml->olSuperTile[i] = 0;
        cml->olScaleWidth[i] = 0;
        cml->olScaleHeight[i] = 0;
    }

    cml->sramPowerdownDisable = 0;
    cml->burstMaxLength = ENCH2_DEFAULT_BURST_LENGTH;
    for(int i = 0; i < 3; i++) {
        cml->picStride[i] = 0;
    }

    // rate jam strategy
    cml->dropFrameCnt = 0;
    cml->stRateJamStrategyParam.bDropFrmEn = AX_FALSE;
    cml->stRateJamStrategyParam.enDropFrmMode = DROPFRM_NORMAL;
    cml->stRateJamStrategyParam.u32MaxApplyCount = 3;
    cml->stRateJamStrategyParam.u32DropFrmThrBps = 128 * 1024; //  128K
}
