
#ifndef _AX_VIDEO_JENC_UTILS_H_
#define _AX_VIDEO_JENC_UTILS_H_

#include "base_type.h"
#include "ax_global_type.h"
#include "jenc_api.h"
#include "jenc_ewl.h"
#include "encinputlinebuffer.h"
#include "ax_comm_venc.h"


#ifdef __cplusplus
extern "C" {
#endif

#define JENC_DEBUG_TRACE
#define MOVING_AVERAGE_FRAMES    120
#define USER_DEFINED_QTABLE 9

typedef struct {
    i32 frame[MOVING_AVERAGE_FRAMES];
    i32 length;
    i32 count;
    i32 pos;
    i32 frameRateNumer;
    i32 frameRateDenom;
} Jenc_ma_s;


typedef struct
{
    char *input;
    char *output;
    char *inputThumb;
    char *roimapFile;
    char *nonRoiFilter;
    i32 firstPic;
    i32 lastPic;
    #ifdef FBDC_ENABLE
    i32 UVheaderSize;
    i32 UVpayloadSize;
    i32 YheaderSize;
    i32 YpayloadSize;
    i32 CropX;
    i32 CropY;
    #endif
    i32 output_width;
    i32 output_height;
    i32 lumWidthSrc;
    i32 lumHeightSrc;

    i32 horOffsetSrc;
    i32 verOffsetSrc;
    i32 restartInterval;
    i32 frameType;
    i32 colorConversion;
    i32 rotation;
    i32 partialCoding;
    i32 codingMode;
    i32 markerType;
    i32 qLevel;
    i32 nonRoiLevel;
    char *qTablePath;
    i32 unitsType;
    i32 xdensity;
    i32 ydensity;
    i32 thumbnail;
    i32 widthThumb;
    i32 heightThumb;
    i32 lumWidthSrcThumb;
    i32 lumHeightSrcThumb;
    i32 horOffsetSrcThumb;
    i32 verOffsetSrcThumb;
    // i32 writeOut;
    i32 comLength;
    char *com;

    /* low latency */
    i32 inputLineBufMode;
    i32 inputLineBufDepth;
    u32 amountPerLoopBack;

    u32 hashtype;
    i32 mirror;
    i32 formatCustomizedType;
    /* constant chroma control */
    i32 constChromaEn;
    u32 constCb;
    u32 constCr;
    i32 losslessEnable;
    i32 predictMode;
    i32 ptransValue;
    u32 bitPerSecond;
    AX_BOOL mjpeg;
    AX_U32 srcFrameRate;
    u32 frameRateNum;
    u32 frameRateDenom;
    JpegEncRcMode rcMode;
    i32 picQpDeltaMin;
    i32 picQpDeltaMax;
    u32 qpmin;
    u32 qpmax;
    i32 fixedQP;

    /*stride*/
    u32 exp_of_input_alignment;
    u32 streamBufChain;
    u32 streamMultiSegmentMode;
    u32 streamMultiSegmentAmount;
    char *dec400CompTableinput;
    u64 dec400FrameTableSize;

    u32 AXIAlignment;

    /* mmu */
    u32 mmuEnable;

    /*Overlay*/
    u32 overlayEnables;
    char *olInput[MAX_OVERLAY_NUM];
    u32 olFormat[MAX_OVERLAY_NUM];
    u32 olAlpha[MAX_OVERLAY_NUM];
    u32 olWidth[MAX_OVERLAY_NUM];
    u32 olCropWidth[MAX_OVERLAY_NUM];
    u32 olHeight[MAX_OVERLAY_NUM];
    u32 olCropHeight[MAX_OVERLAY_NUM];
    u32 olXoffset[MAX_OVERLAY_NUM];
    u32 olCropXoffset[MAX_OVERLAY_NUM];
    u32 olYoffset[MAX_OVERLAY_NUM];
    u32 olCropYoffset[MAX_OVERLAY_NUM];
    u32 olYStride[MAX_OVERLAY_NUM];
    u32 olUVStride[MAX_OVERLAY_NUM];

    u32 olSuperTile[MAX_OVERLAY_NUM];
    u32 olScaleWidth[MAX_OVERLAY_NUM];
    u32 olScaleHeight[MAX_OVERLAY_NUM];
    char *osdDec400CompTableInput;

    /* SRAM power down mode disable */
    u32 sramPowerdownDisable;

    i32 useVcmd;
    i32 useMMU;
    i32 useDec400;
    i32 useL2Cache;

    /*AXI max burst length */
    u32 burstMaxLength;

    u32 picStride[3];
    bool dynamicCropEnable;

    // rate jam strategy
    u32 dropFrameCnt;
    AX_VENC_RATE_JAM_CFG_S stRateJamStrategyParam;
}JencCommandLine_s;



typedef struct {
    u32 streamRDCounter;
    u32 streamMultiSegEn;
    u8 *streamBase;
    u32 segmentSize;
    u32 segmentAmount;
    FILE *outStreamFile;
} JencSegmentCtl_s;


typedef struct axJENC_HANDLE_S
{
    JencCommandLine_s stCmdl;

    JpegEncCfg cfg;

    AX_LINK_MODE_E s32GetFrameMode;

    u32 u32PicStride[3];
    u32 thumbDataLength;

    u8 *thumbData; /* thumbnail data buffer */

    JENC_EWLLinearMem_t pictureMem;
    JENC_EWLLinearMem_t dec400CompTblMem;

    JENC_EWLLinearMem_t outbufMem[MAX_STRM_BUF_NUM];
    JENC_EWLLinearMem_t overlayMem[MAX_OVERLAY_NUM];
    JENC_EWLLinearMem_t osdDec400CompTblMem;

    JENC_EWLLinearMem_t roimapMem;

    inputLineBufferCfg inputMbLineBuf;

    JencSegmentCtl_s streamSegCtl;

    u32 hwid;  /* HW ID */
    AX_S32 VeChn;

    JpegEncInst jenc_encoder;

    JpegEncIn encIn;
    JpegEncOut encOut;

    AX_VENC_RC_MODE_E enRcMode;
    AX_VENC_RC_PARAM_S stRcParam;

    //encode header
    Jenc_ma_s ma;

    u64 frameCntTotal;
    u64 streamBufSize;
    u32 streamBufNum;

    struct timeval timeFrameStart;
    struct timeval timeFrameEnd;
    AX_U32 u32Qfactor;                      /* RW; Range:[1,99]; Qfactor value */
} AX_JENC_HANDLE_S;

void JencWriteStrm(FILE *fout, u32 *strmbuf, u32 size, u32 endian);

void JencGetAlignedPicSizebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size);

void JencMaAddFrame(Jenc_ma_s *ma, i32 frameSizeBits);
i32 JencMa(Jenc_ma_s *ma);

void JencGetDec400CompTablebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size, i32 dec400VersionId);

int JencReadRoimap(AX_JENC_HANDLE_S *pJencHandle, const void* ewl_inst);
void JencGetOsdDec400SizeJpeg(JencCommandLine_s *cmdl, u8 dec400VersionId, u8 idx, u32 *dec400TableSize);
void JencParamPrintLog(JencCommandLine_s *pCmdl, JpegEncCfg cfg);
i32 JencImgFormat2FrameType(AX_IMG_FORMAT_E enFormat);


#ifdef __cplusplus
}
#endif
#endif
