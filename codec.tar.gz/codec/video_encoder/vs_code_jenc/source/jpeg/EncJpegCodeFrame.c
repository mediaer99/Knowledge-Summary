/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Hantro Products Oy.                             --
--                                                                            --
--                   (C) COPYRIGHT 2006 HANTRO PRODUCTS OY                    --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract  :    JPEG Code Frame control
--
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    1. Include headers
------------------------------------------------------------------------------*/
#include "enccommon.h"
#include "jenc_ewl.h"

#include "EncJpegCodeFrame.h"
#include "encdec400.h"
#include "ax_sys_api.h"

#ifdef __linux
#include <sys/syscall.h>
#endif
#define gettid() syscall(__NR_gettid)
#define DEBUG_LOG(str, arg...)        \
    do{   \
        printf("  tid:%ld EncJpegCodeFrame.c %s %d "str"\n", gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)       \
    do{ \
        printf("  tid:%ld EncJpegCodeFrame.c %s %d Jenc_Error! "str"\n", gettid(), __func__, __LINE__, ##arg);  \
    }while(0)

/*------------------------------------------------------------------------------
    2. External compiler flags
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
    3. Module defines
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    4. Local function prototypes
------------------------------------------------------------------------------*/
static void NextHeader(stream_s * stream, jpegData_s * jpeg);
static void EndRi(stream_s * stream, jpegData_s * jpeg);
static void jpegSetNewFrame(jpegInstance_s * inst);

/*------------------------------------------------------------------------------

    EncJpegCodeFrame

------------------------------------------------------------------------------*/
jpegEncodeFrame_e EncJpegCodeFrameRun(jpegInstance_s * inst)
{
    jpegEncodeFrame_e ret;
    u32 vcmd_en;
    u64 phyAddr = 0;
    i32 cacheType = 0;
    u32 cacheDataLen = 0;
    i32 s32Ret = 0;

    vcmd_en = JencEWLGetVCMDSupport();

    /* set output stream start point in case of whole encoding mode
     * and no rst used */
    if(inst->stream.byteCnt == 0) {
        inst->jpeg.streamStartAddress = inst->stream.stream;
    }
    /* set new frame encoding parameters */
    jpegSetNewFrame(inst);

    /* jpeg header info wb to ddr */
    s32Ret = AX_SYS_MemGetBlockInfoByVirt((void *)inst->jpeg.streamStartAddress, &phyAddr, &cacheType);
    if (cacheType == AX_MEM_CACHED) {
        cacheDataLen = (inst->stream.byteCnt + 0xf) & (~0xf);
        if (cacheDataLen > inst->stream.size) {
            cacheDataLen = inst->stream.size;
        }
        s32Ret = AX_SYS_MflushCache(phyAddr, (void *)inst->jpeg.streamStartAddress, cacheDataLen);
        if (s32Ret) {
            DEBUG_ERR_LOG("AX_SYS_MinvalidateCache fail %d.\n", s32Ret);
        }
        //DEBUG_LOG("[%s] write back header, %p size %d %d\n", __func__, inst->jpeg.streamStartAddress, cacheDataLen, (int)(inst->stream.stream-inst->jpeg.streamStartAddress));
    }

    if (vcmd_en==0) {
    /* start hw encoding */
        JencEncAsicFrameStart(inst->asic.ewl, &inst->asic.regs, 0);
    } else {
        // DEBUG_LOG("inst->jpeg.width:%d, inst->jpeg.height:%d", inst->jpeg.width, inst->jpeg.height);
        //priority = 0, will be set in command line.
        JencEncSetReseveInfo(inst->asic.ewl, inst->jpeg.width, inst->jpeg.height, 0, 0, 0, JENC_EWL_CLIENT_TYPE_JPEG_ENC);

        JencEncReseveCmdbuf(inst->asic.ewl, &inst->asic.regs);

        if (inst->asic.regs.picWidth == 0) {
            DEBUG_ERR_LOG("inst->asic.regs.picWidth == 0");
            return JPEGENCODE_INVALID_ARGUMENT;
        }

        if (inst->asic.regs.picHeight == 0) {
            DEBUG_ERR_LOG("inst->asic.regs.picHeight == 0");
            return JPEGENCODE_INVALID_ARGUMENT;
        }

        inst->asic.regs.vcmdBufSize = 0;
        //JencEncMakeCmdbufData(&inst->asic, &inst->asic.regs,(void *)&inst->dec400_data);
        if(JencEncMakeCmdbufData(&inst->asic, &inst->asic.regs,(void *)&inst->dec400_data, (void *)&inst->dec400OsdData)==JPEGENC_INVALID_ARGUMENT)
        {
            return JPEGENCODE_INVALID_ARGUMENT;
        }
        inst->asic.regs.totalCmdbufSize = inst->asic.regs.vcmdBufSize;
        JencEncCopyDataToCmdbuf(inst->asic.ewl, &inst->asic.regs);

        JencEncLinkRunCmdbuf(inst->asic.ewl,&inst->asic.regs);
    }
    return JPEGENCODE_OK;
}

jpegEncodeFrame_e EncJpegCodeFrameWait(jpegInstance_s * inst)
{
    jpegEncodeFrame_e ret;
    asicData_s *asic = &inst->asic;
    u32 status = ASIC_STATUS_ERROR;
    u32 vcmd_en;

    vcmd_en = JencEWLGetVCMDSupport();

    do {
        /* Encode one frame */
        i32 ewl_ret;

#ifndef JPEG_SIMULATION
        /* Wait for IRQ */
        if(vcmd_en==0)
        {
            ewl_ret = JencEWLWaitHwRdy(asic->ewl, NULL, NULL, &status);
        }
        else
        {
            ewl_ret = JencEncWaitCmdbuf(asic->ewl, asic->regs.cmdbufid, &status);
        }
#else
        return JPEGENCODE_OK;
#endif
        if(ewl_ret != EWL_OK)
        {
            status = ASIC_STATUS_ERROR;

            if(ewl_ret == EWL_ERROR)
            {
                /* IRQ error => Stop and release HW */
                ret = JPEGENCODE_SYSTEM_ERROR;
            }
            else    /*if(ewl_ret == EWL_HW_WAIT_TIMEOUT) */
            {
                /* IRQ Timeout => Stop and release HW */
                ret = JPEGENCODE_TIMEOUT;
            }

            JencEncAsicStop(asic->ewl);
            /* Release HW so that it can be used by other codecs */
            if(vcmd_en==0)
            {
                if (inst->dec400Enable != 0)
                  Jenc_VCEncDisableDec400(&inst->dec400_data);

                if(inst->axiFEEnable != 0)
                  JencAxiFeDisable(asic->ewl);

                JencEWLReleaseHw(asic->ewl);
            }
            else
            {
                JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
            }

        }
        else
        {

            status = Jenc_EncAsicCheckStatus_V2(asic, status);

            if(status != ASIC_STATUS_LINE_BUFFER_DONE && status != ASIC_STATUS_SEGMENT_READY)
            {
              if(inst->dec400Enable != 0)
                Jenc_VCEncDisableDec400(&inst->dec400_data);

              if(inst->axiFEEnable != 0)
                JencAxiFeDisable(asic->ewl);
            }

            switch (status)
            {
            case ASIC_STATUS_ERROR:
                if(vcmd_en==0)
                {
                    JencEWLReleaseHw(asic->ewl);
                }
                else
                {
                    JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
                }
                ret = JPEGENCODE_HW_ERROR;
                break;
            case ASIC_STATUS_BUFF_FULL:
                if(vcmd_en==0)
                {
                    JencEWLReleaseHw(asic->ewl);
                }
                else
                {
                    JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
                }
                ret = JPEGENCODE_OK;
                inst->stream.overflow = ENCHW_YES;
                break;
            case ASIC_STATUS_HW_RESET:
                if(vcmd_en==0)
                {
                    JencEWLReleaseHw(asic->ewl);
                }
                else
                {
                    JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
                }
                ret = JPEGENCODE_HW_RESET;
                break;
            case ASIC_STATUS_HW_TIMEOUT:
                if(vcmd_en==0)
                {
                    JencEWLReleaseHw(asic->ewl);
                }
                else
                {
                    JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
                }
                ret = JPEGENCODE_TIMEOUT;
                break;
            case ASIC_STATUS_FRAME_READY:
                inst->stream.byteCnt -= (asic->regs.firstFreeBit/8);    /* last not full 64-bit counted in HW data */
                inst->stream.byteCnt += asic->regs.outputStrmSize[0];
                ret = JPEGENCODE_OK;
                if(vcmd_en==0)
                {
                    JencEWLReleaseHw(asic->ewl);
                }
                else
                {
                    JencEWLReleaseCmdbuf(asic->ewl,asic->regs.cmdbufid);
                }
                break;
            case ASIC_STATUS_LINE_BUFFER_DONE:
                ret = JPEGENCODE_OK;
                /* SW handshaking: Software will clear the line buffer interrupt and then update the
                           *   line buffer write pointer, when the next line buffer is ready. The encoder will
                           *   continue to run when detected the write pointer is updated.  */
                if (!inst->inputLineBuf.inputLineBufHwModeEn)
                {
                    if (inst->inputLineBuf.cbFunc)
                        inst->inputLineBuf.cbFunc(inst->inputLineBuf.cbData);
                }
                break;
            case ASIC_STATUS_SEGMENT_READY:
                ret = JPEGENCODE_OK;

                while(inst->streamMultiSegment.streamMultiSegmentMode != 0 &&
                      inst->streamMultiSegment.rdCnt < Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STRM_SEGMENT_WR_PTR))
                {
                  if (inst->streamMultiSegment.cbFunc)
                    inst->streamMultiSegment.cbFunc(inst->streamMultiSegment.cbData);
                  /*note: must make sure the data of one segment is read by app then rd counter can increase*/
                  inst->streamMultiSegment.rdCnt++;
                }
                Jenc_EncAsicWriteRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STRM_SEGMENT_RD_PTR,inst->streamMultiSegment.rdCnt);
                break;
            default:
                /* should never get here */
                ASSERT(0);
                ret = JPEGENCODE_HW_ERROR;
            }
        }
    }while (status == ASIC_STATUS_LINE_BUFFER_DONE || status == ASIC_STATUS_SEGMENT_READY);

    /* Handle EOI */
    if(ret == JPEGENCODE_OK)
    {
        /* update mcu count */
        if(inst->jpeg.codingType == ENC_PARTIAL_FRAME)
        {
            if (inst->jpeg.losslessEn)
            {
                u32  rstMbs = (inst->jpeg.width + 15) / 16 * inst->jpeg.rstMbRows;

                if((inst->jpeg.mbNum + rstMbs) <
                   ((u32) inst->jpeg.mbPerFrame))
                {
                    inst->jpeg.mbNum += rstMbs;
                    inst->jpeg.row += inst->jpeg.sliceRows;
                }
                else
                {
                    inst->jpeg.mbNum += (inst->jpeg.mbPerFrame - inst->jpeg.mbNum);
                }
            }
            else
            {
                u32  rstMbs = (inst->jpeg.width + 15) / 16 * inst->jpeg.rstMbRows;

                if((inst->jpeg.mbNum + rstMbs) <
                   ((u32) inst->jpeg.mbPerFrame))
                {
                    inst->jpeg.mbNum += rstMbs;
                    inst->jpeg.row += inst->jpeg.sliceRows;
                }
                else
                {
                    inst->jpeg.mbNum += (inst->jpeg.mbPerFrame - inst->jpeg.mbNum);
                }
            }
        }
        else
        {
            inst->jpeg.mbNum += inst->jpeg.mbPerFrame;
        }

        EndRi(&inst->stream, &inst->jpeg);
    }

    return ret;
}

/*------------------------------------------------------------------------------

    Write the header data (frame header or restart marker) to the stream.

------------------------------------------------------------------------------*/
void NextHeader(stream_s * stream, jpegData_s * jpeg)
{
    if(jpeg->mbNum == 0)
    {
        (void) EncJpegHdr(stream, jpeg);
    }
}

/*------------------------------------------------------------------------------

    Write the end of current coding unit (RI / FRAME) into stream.

------------------------------------------------------------------------------*/
void EndRi(stream_s * stream, jpegData_s * jpeg)
{
    /* not needed anymore, ASIC generates EOI marker */
}

/*------------------------------------------------------------------------------

    Set encoding parameters at the beginning of a new frame.

------------------------------------------------------------------------------*/
void jpegSetNewFrame(jpegInstance_s * inst)
{
    regValues_s *regs = &inst->asic.regs;
    u8 offsetTo8BytesAlignment = 0;
    ptr_t strmBaseTmp = regs->outputStrmBase[0];

    /* Write next header if needed */
    NextHeader(&inst->stream, &inst->jpeg);

    offsetTo8BytesAlignment = (u8)((regs->outputStrmBase[0] + inst->stream.byteCnt) & 0x07);

    /* calculate output start point for hw */
    regs->outputStrmSize[0] -= (inst->stream.byteCnt - offsetTo8BytesAlignment);
    inst->invalidBytesInBuf0Tail = regs->outputStrmSize[0] & 0x07;
    regs->outputStrmSize[0] &= (~0x07);    /* 8 multiple size */

    /* 64-bit aligned stream base address */
    regs->outputStrmBase[0] = ((regs->outputStrmBase[0] + inst->stream.byteCnt) & (~0x07));
    /* bit offset in the last 64-bit word */
    regs->firstFreeBit = (offsetTo8BytesAlignment) * 8;
    regs->jpegHeaderLength = (u32)(regs->outputStrmBase[0] - strmBaseTmp);
    Jenc_hash(&inst->jpeg.hashctx, inst->jpeg.streamStartAddress, (inst->stream.byteCnt - offsetTo8BytesAlignment));
    regs->hashtype = inst->jpeg.hashctx.hash_type;
    Jenc_hash_getstate(&inst->jpeg.hashctx, &regs->hashval, &regs->hashoffset);

    /* header remainder is byte aligned, max 7 bytes = 56 bits */
    if(regs->firstFreeBit != 0)
    {
        /* 64-bit aligned stream pointer */
        u8 *pTmp = (u8 *) ((size_t) (inst->stream.stream) & (~0x07));
        u32 val;

        /* Clear remaining bits */
        for (val = 6; val >= regs->firstFreeBit/8; val--)
            pTmp[val] = 0;

        val = pTmp[0] << 24;
        val |= pTmp[1] << 16;
        val |= pTmp[2] << 8;
        val |= pTmp[3];

        regs->strmStartMSB = val;  /* 32 bits to MSB */

        if(regs->firstFreeBit > 32)
        {
            val = pTmp[4] << 24;
            val |= pTmp[5] << 16;
            val |= pTmp[6] << 8;

            regs->strmStartLSB = val;
        }
        else
            regs->strmStartLSB = 0;
    }
    else
    {
        regs->strmStartMSB = regs->strmStartLSB = 0;
    }

    /* low latency: configure related register.*/
    regs->lineBufferEn = inst->inputLineBuf.inputLineBufEn;
    regs->lineBufferHwHandShake = inst->inputLineBuf.inputLineBufHwModeEn;
    regs->lineBufferLoopBackEn = inst->inputLineBuf.inputLineBufLoopBackEn;
    regs->lineBufferDepth = inst->inputLineBuf.inputLineBufDepth;
    regs->amountPerLoopBack = inst->inputLineBuf.amountPerLoopBack;
    regs->initSegNum = inst->inputLineBuf.initSegNum;
    regs->mbWrPtr = inst->inputLineBuf.wrCnt;
    regs->mbRdPtr = 0;
    regs->lineBufferInterruptEn = ENCH2_INPUT_BUFFER_INTERRUPT &
                                  regs->lineBufferEn &
                                  (regs->lineBufferHwHandShake == 0) &
                                  (regs->lineBufferDepth > 0);
}
