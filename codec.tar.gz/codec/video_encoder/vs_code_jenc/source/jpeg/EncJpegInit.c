/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Hantro Products Oy.                             --
--                                                                            --
--                   (C) COPYRIGHT 2006 HANTRO PRODUCTS OY                    --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract  :
--
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------

    Table of contents

    1. Include headers
    2. External compiler flags
    3. Module defines
    4. Local function prototypes
    5. Functions

------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    1. Include headers
------------------------------------------------------------------------------*/
#include "EncJpegInit.h"

#include "EncJpegCommon.h"
#include "jenc_ewl.h"

/*------------------------------------------------------------------------------
    2. External compiler flags
--------------------------------------------------------------------------------*/
#ifdef __linux
#include <sys/syscall.h>
#endif
#define gettid() syscall(__NR_gettid)
/*--------------------------------------------------------------------------------
    3. Module defines
------------------------------------------------------------------------------*/

#define DEBUG_LOG(str, arg...)        \
    do{   \
        printf(" tid:%ld EncJpegInit.c %s %d "str"\n", gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)       \
    do{ \
        printf(" tid:%ld EncJpegInit.c %s %d Jenc_Error! "str"\n", gettid(), __func__, __LINE__, ##arg);  \
    }while(0)

/*------------------------------------------------------------------------------
    4. Local function prototypes
------------------------------------------------------------------------------*/
static void SetQTable(u8 *dst, const u8 *src);
static void AXSetQTable(u8 *dst, const u8 *src, const u32 afactor);
/* JPEG QUANT table order */

/*------------------------------------------------------------------------------

    JpegInit

------------------------------------------------------------------------------*/
JpegEncRet JpegInit(const JpegEncCfg * pEncCfg, jpegInstance_s ** instAddr, void *ctx)
{
    jpegInstance_s *inst = NULL;
    const void *ewl = NULL;

    JpegEncRet ret = JPEGENC_OK;
    JENC_EWLInitParam_t param;

    ASSERT(pEncCfg);
    ASSERT(instAddr);

    *instAddr = NULL;

    /* Init EWL */
    param.context = ctx;
    param.clientType = JENC_EWL_CLIENT_TYPE_JPEG_ENC;
    param.slice_idx = pEncCfg->slice_idx;
	param.mmuEnable = pEncCfg->mmuEnable;

    if((ewl = JencEWLInit(&param)) == NULL) {
        DEBUG_ERR_LOG("JencEWLInit failed!");
        return JPEGENC_EWL_ERROR;
    }

    /* Encoder instance */
    inst = (jpegInstance_s *) JencEWLcalloc(1, sizeof(jpegInstance_s));

    if(inst == NULL) {
        ret = JPEGENC_MEMORY_ERROR;
        DEBUG_ERR_LOG("JencEWLcalloc failed!");
        goto err;
    }

    /* Default values */
    EncJpegInit(&inst->jpeg);

    inst->jpeg.codingMode = pEncCfg->codingMode;

    /* lossless mode */
    inst->jpeg.losslessEn = pEncCfg->losslessEn;
    if (inst->jpeg.losslessEn) {
        inst->jpeg.predictMode = pEncCfg->predictMode;
        inst->jpeg.ptransValue = pEncCfg->ptransValue;
        ASSERT(inst->jpeg.predictMode>0);
        ASSERT(inst->jpeg.predictMode<8);
    } else {
        inst->jpeg.predictMode = 0;
        inst->jpeg.ptransValue = 0;
    }

    /* Set parameters depending on user config */
    /* Choose quantization tables */
    inst->jpeg.qTable.pQlumi = QuantLuminance[pEncCfg->qLevel];
    inst->jpeg.qTable.pQchromi = QuantChrominance[pEncCfg->qLevel];

    /* If user specified quantization tables, use them */
    if (pEncCfg->qTableLuma) {
        SetQTable(inst->jpeg.qTableLuma, pEncCfg->qTableLuma);
        inst->jpeg.qTable.pQlumi = inst->jpeg.qTableLuma;
    }

    if (pEncCfg->qTableChroma) {
        SetQTable(inst->jpeg.qTableChroma, pEncCfg->qTableChroma);
        inst->jpeg.qTable.pQchromi = inst->jpeg.qTableChroma;
    }

    /* Comment header data */
    if(pEncCfg->comLength > 0 && pEncCfg->pCom != NULL) {
        inst->jpeg.com.comLen = pEncCfg->comLength;
        inst->jpeg.com.pComment = pEncCfg->pCom;
        inst->jpeg.com.comEnable = 1;
    }

    /* Units type */
    if(pEncCfg->unitsType == JPEGENC_NO_UNITS) {
        inst->jpeg.appn.units = ENC_NO_UNITS;
        inst->jpeg.appn.Xdensity = 1;
        inst->jpeg.appn.Ydensity = 1;
    } else {
        inst->jpeg.appn.units = pEncCfg->unitsType;
        inst->jpeg.appn.Xdensity = pEncCfg->xDensity;
        inst->jpeg.appn.Ydensity = pEncCfg->yDensity;
    }

    /* Marker type */
    if(pEncCfg->markerType == JPEGENC_SINGLE_MARKER) {
        inst->jpeg.markerType = ENC_SINGLE_MARKER;
    } else {
        inst->jpeg.markerType = pEncCfg->markerType;
    }

#if 0
    /* Rotation type */
    if(pEncCfg->rotation == JPEGENC_ROTATE_90R)
    {
        inst->jpeg.rotation = ROTATE_90R;
    }
    else if(pEncCfg->rotation == JPEGENC_ROTATE_90L)
    {
        inst->jpeg.rotation = ROTATE_90L;
    }
    else
    {
        inst->jpeg.rotation = ROTATE_0;
    }
#endif

    /* Copy quantization tables to ASIC internal memories */
    JencEncAsicSetQuantTable(&inst->asic, inst->jpeg.qTable.pQlumi,
                         inst->jpeg.qTable.pQchromi);

    if(pEncCfg->enableRoimap) {
        for(int i = 0; i < 64; i++) {
            inst->jpeg.qTableLumaNonRoi[i] =
                (pEncCfg->filter[i] == 0) ? 255 :
                    (MIN(255, inst->jpeg.qTable.pQlumi[i]*255/pEncCfg->filter[i]));

            inst->jpeg.qTableChromaNonRoi[i] =
                (pEncCfg->filter[i+64] == 0) ? 255 :
                    (MIN(255, inst->jpeg.qTable.pQchromi[i]*255/pEncCfg->filter[i+64]));
        }

        JencEncAsicSetNonRoiQuantTable(
            &inst->asic, inst->jpeg.qTableLumaNonRoi,
            inst->jpeg.qTableChromaNonRoi, pEncCfg->filter);
    }

    /* Initialize ASIC */
    inst->asic.ewl = ewl;
    (void) JencEncAsicControllerInit(&inst->asic, ctx, param.clientType);

    *instAddr = inst;

    return ret;

err:
    DEBUG_ERR_LOG(" ret:%d", ret);
    if(inst != NULL)
        JencEWLfree(inst);
    if(ewl != NULL)
        (void) JencEWLRelease(ewl);

    return ret;
}

JpegEncRet AXJpegInit(const JpegEncCfg * pEncCfg, jpegInstance_s ** instAddr, void *ctx)
{
    jpegInstance_s *inst = NULL;
    const void *ewl = NULL;

    JpegEncRet ret = JPEGENC_OK;
    JENC_EWLInitParam_t param;

    ASSERT(pEncCfg);
    ASSERT(instAddr);

    *instAddr = NULL;

    i32 VeChn = pEncCfg->ChnId;
    /* Init EWL */
    param.context = ctx;
    param.clientType = JENC_EWL_CLIENT_TYPE_JPEG_ENC;
    param.slice_idx = pEncCfg->slice_idx;
	param.mmuEnable = pEncCfg->mmuEnable;

    if((ewl = JencEWLInit(&param)) == NULL) {
        DEBUG_ERR_LOG("JencEWLInit failed!");
        return JPEGENC_EWL_ERROR;
    }

    /* Encoder instance */
    inst = (jpegInstance_s *) JencEWLcalloc(1, sizeof(jpegInstance_s));

    if(inst == NULL) {
        ret = JPEGENC_MEMORY_ERROR;
        DEBUG_ERR_LOG("JencEWLcalloc failed!");
        goto err;
    }

    /* Default values */
    EncJpegInit(&inst->jpeg);

    inst->jpeg.codingMode = pEncCfg->codingMode;

    /* lossless mode */
    inst->jpeg.losslessEn = pEncCfg->losslessEn;
    if (inst->jpeg.losslessEn) {
        inst->jpeg.predictMode = pEncCfg->predictMode;
        inst->jpeg.ptransValue = pEncCfg->ptransValue;
        ASSERT(inst->jpeg.predictMode>0);
        ASSERT(inst->jpeg.predictMode<8);
    } else {
        inst->jpeg.predictMode = 0;
        inst->jpeg.ptransValue = 0;
    }

    /* Set parameters depending on user config */
    /* Choose quantization tables */

    inst->jpeg.qFactor = pEncCfg->qFactor;
    AXSetQTable(inst->jpeg.qTableLumaActive, inst->jpeg.qTableLuma,pEncCfg->qFactor);
    inst->jpeg.qTable.pQlumi = inst->jpeg.qTableLumaActive;
    AXSetQTable(inst->jpeg.qTableChromaActive, inst->jpeg.qTableChroma,pEncCfg->qFactor);
    inst->jpeg.qTable.pQchromi = inst->jpeg.qTableChromaActive;

    /* Comment header data */
    if(pEncCfg->comLength > 0 && pEncCfg->pCom != NULL) {
        inst->jpeg.com.comLen = pEncCfg->comLength;
        inst->jpeg.com.pComment = pEncCfg->pCom;
        inst->jpeg.com.comEnable = 1;
    }

    /* Units type */
    if(pEncCfg->unitsType == JPEGENC_NO_UNITS) {
        inst->jpeg.appn.units = ENC_NO_UNITS;
        inst->jpeg.appn.Xdensity = 1;
        inst->jpeg.appn.Ydensity = 1;
    } else {
        inst->jpeg.appn.units = pEncCfg->unitsType;
        inst->jpeg.appn.Xdensity = pEncCfg->xDensity;
        inst->jpeg.appn.Ydensity = pEncCfg->yDensity;
    }

    /* Marker type */
    if(pEncCfg->markerType == JPEGENC_SINGLE_MARKER) {
        inst->jpeg.markerType = ENC_SINGLE_MARKER;
    } else {
        inst->jpeg.markerType = pEncCfg->markerType;
    }

#if 0
    /* Rotation type */
    if(pEncCfg->rotation == JPEGENC_ROTATE_90R)
    {
        inst->jpeg.rotation = ROTATE_90R;
    }
    else if(pEncCfg->rotation == JPEGENC_ROTATE_90L)
    {
        inst->jpeg.rotation = ROTATE_90L;
    }
    else
    {
        inst->jpeg.rotation = ROTATE_0;
    }
#endif

    /* Copy quantization tables to ASIC internal memories */
    JencEncAsicSetQuantTable(&inst->asic, inst->jpeg.qTable.pQlumi,
                         inst->jpeg.qTable.pQchromi);

    /* to do */
    if(pEncCfg->enableRoimap) {
        for(int i = 0; i < 64; i++) {
            inst->jpeg.qTableLumaNonRoi[i] =
                (pEncCfg->filter[i] == 0) ? 255 :
                    (MIN(255, inst->jpeg.qTable.pQlumi[i]*255/pEncCfg->filter[i]));

            inst->jpeg.qTableChromaNonRoi[i] =
                (pEncCfg->filter[i+64] == 0) ? 255 :
                    (MIN(255, inst->jpeg.qTable.pQchromi[i]*255/pEncCfg->filter[i+64]));
        }

        JencEncAsicSetNonRoiQuantTable(
            &inst->asic, inst->jpeg.qTableLumaNonRoi,
            inst->jpeg.qTableChromaNonRoi, pEncCfg->filter);
    }

    /* Initialize ASIC */
    inst->asic.ewl = ewl;
    (void) JencEncAsicControllerInit(&inst->asic, ctx, param.clientType);

    *instAddr = inst;

    return ret;

err:
    DEBUG_ERR_LOG(" ret:%d", ret);
    if(inst != NULL)
        JencEWLfree(inst);
    if(ewl != NULL)
        (void) JencEWLRelease(ewl);

    return ret;
}


/*------------------------------------------------------------------------------

    JpegShutdown

    Function frees the encoder instance.

    Input   instance_s *    Pointer to the encoder instance to be freed.
                            After this the pointer is no longer valid.

------------------------------------------------------------------------------*/
void JpegShutdown(jpegInstance_s * data)
{
    const void *ewl;

    ASSERT(data);

    ewl = data->asic.ewl;
    if(JencEWLGetVCMDSupport())
      JencEWLfree(data->asic.regs.vcmdBuf);
    Jenc_EncAsicMemFree_V2(&data->asic);

    JencEWLfree(data);

    (void) JencEWLRelease(ewl);
}

/*------------------------------------------------------------------------------
    SetQTable
------------------------------------------------------------------------------*/
static void SetQTable(u8 *dst, const u8 *src)
{
    i32 i;
    if (dst == NULL) {
        DEBUG_ERR_LOG("dst == NULL");
        return;
    }

    if (src == NULL) {
        DEBUG_ERR_LOG("src == NULL");
        return;
    }

    for (i = 0; i < 64; i++) {
        u8 qp = src[i];
        // DEBUG_LOG(" qp:%d, i:%d", qp, i);
        /* Round qp to value that can be handled by ASIC */
        if (qp > 128)
            qp = qp/8*8;
        else if (qp > 64)
            qp = qp/4*4;
        else if (qp > 32)
            qp = qp/2*2;

        dst[i] = qp;
    }
}

static void AXSetQTable(u8 *dst, const u8 *src, const u32 qfactor)
{
    i32 i;
    int factor = qfactor;

    if (qfactor < 1) factor = 1;
    if (qfactor > 99) factor = 99;
    if (qfactor < 50)
        factor = 5000 / factor;
    else
        factor = 200 - factor*2;

    for (i = 0; i < 64; i++)
    {
        i32 qp = (src[i]*factor + 50)/100;

        /* Limit the quantizers to 1 <= qp <= 255 */
        if (qp < 1)
            qp = 1;
        else if (qp > 255)
            qp = 255;

        /* Round qp to value that can be handled by ASIC */
        if (qp > 128)
            qp = qp/8*8;
        else if (qp > 64)
            qp = qp/4*4;
        else if (qp > 32)
            qp = qp/2*2;

        dst[i] = qp;
    }
}

void AXSetUserQpTable(jpegInstance_s *inst, const u32 qfactor, const u8* qTableLuma, const u8* qTableChroma)
{
    if(inst == NULL || qTableLuma == NULL || qTableChroma == NULL)
    {
        printf("[%s %d] ERROR null argument.",__FUNCTION__,__LINE__);
        return;
    }

    int i = 0, zero_count = 0, length = 0;

    if (qfactor != 0)
        inst->jpeg.qFactor = qfactor;

    if (qTableLuma != NULL) {

        zero_count = 0;
        length = 64;
        for(i = 0;i < length;i++) {
            if(qTableLuma[i] == 0)
                zero_count++;
        }

        /*
        *Note:
        *If all values are non-zero,then update luma table,
        *otherwise use standard quantification table.
        */
        if(zero_count == 0) {
            //update user Luma table
            memcpy(inst->jpeg.qTableLuma, qTableLuma, sizeof(inst->jpeg.qTableLuma));
        }

    }
    if (qTableChroma != NULL) {

        zero_count = 0;
        length = 64;
        for(i = 0;i < length;i++) {
            if(qTableChroma[i] == 0)
                zero_count++;
        }

        /*
        *Note:
        *If all values are non-zero,then update chroma table,
        *otherwise use standard quantification table.
        */
        if(zero_count == 0) {
            //update user Chroma table
            memcpy(inst->jpeg.qTableChroma, qTableChroma, sizeof(inst->jpeg.qTableChroma));
        }
    }

    //Calculate the active quantification table
    AXSetQTable(inst->jpeg.qTableLumaActive, inst->jpeg.qTableLuma, inst->jpeg.qFactor);
    inst->jpeg.qTable.pQlumi = inst->jpeg.qTableLumaActive;
    //Calculate the active quantification table
    AXSetQTable(inst->jpeg.qTableChromaActive, inst->jpeg.qTableChroma, inst->jpeg.qFactor);
    inst->jpeg.qTable.pQchromi = inst->jpeg.qTableChromaActive;

    /* Copy quantization tables to ASIC internal memories */
    JencEncAsicSetQuantTable(&inst->asic, inst->jpeg.qTable.pQlumi,
                         inst->jpeg.qTable.pQchromi);
    return;
}

void AXGetUserQpTable(jpegInstance_s *inst, u32 *qfactor,u8 *qTableLuma, u8 *qTableChroma)
{
    if(inst == NULL || qfactor == NULL || qTableLuma == NULL || qTableChroma == NULL)
    {
        printf("[%s %d] ERROR null argument.",__FUNCTION__,__LINE__);
        return;
    }

    *qfactor = inst->jpeg.qFactor;
    memcpy(qTableLuma,inst->jpeg.qTableLuma,sizeof(inst->jpeg.qTableLuma));
    memcpy(qTableChroma,inst->jpeg.qTableChroma,sizeof(inst->jpeg.qTableChroma));
    return;
}


