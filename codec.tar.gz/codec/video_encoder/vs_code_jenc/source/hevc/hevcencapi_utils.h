/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------
--
-- Abstract : Hevc API utils Messages.
--
------------------------------------------------------------------------------*/
#ifndef API_UTILS_H
#define API_UTILS_H

#include "instance.h"

#define VCENC_SW_BUILD ((VCENC_BUILD_MAJOR * 1000000) + \
  (VCENC_BUILD_MINOR * 1000) + VCENC_BUILD_REVISION)

#define PRM_SET_BUFF_SIZE 1024    /* Parameter sets max buffer size */
#define RPS_SET_BUFF_SIZE 140     /* rps sets max buffer size */
#define VCENC_MAX_BITRATE             (800000*1000)    /* Level 6.2 high tier limit */

/* HW ID check. Jenc_VCEncInit() will fail if HW doesn't match. */

#define VCENC_MIN_ENC_WIDTH       64 //132     /* 144 - 12 pixels overfill */
#define VCENC_MAX_ENC_WIDTH       8192
#define VCENC_MIN_ENC_HEIGHT      64 //96
#define VCENC_MAX_ENC_HEIGHT      8192
#define VCENC_MAX_ENC_HEIGHT_EXT  8640
#define VCENC_HEVC_MAX_LEVEL      VCENC_HEVC_LEVEL_6
#define VCENC_H264_MAX_LEVEL      VCENC_H264_LEVEL_6_2

#define VCENC_DEFAULT_QP          26

#define VCENC_MAX_PP_INPUT_WIDTH      8192

#define VCENC_MAX_USER_DATA_SIZE      2048

#define VCENC_AV1_MAX_ENC_WIDTH       4096
#define VCENC_AV1_MAX_ENC_AREA        (4096 * 2304)

#define VCENC_VP9_MAX_ENC_WIDTH       4096
#define VCENC_VP9_MAX_ENC_HEIGHT      8384
#define VCENC_VP9_MAX_ENC_AREA        (4096 * 2176)

#define VCENC_BUS_ADDRESS_VALID(bus_address)  (((bus_address) != 0) /*&& \
                                              ((bus_address & 0x0F) == 0)*/)

#define VCENC_BUS_CH_ADDRESS_VALID(bus_address)  (((bus_address) != 0) /*&& \
                                              ((bus_address & 0x07) == 0)*/)

#define FIX_POINT_LAMBDA

#define LARGE_QPFACTOR_FOR_BIGQP


/* Tracing macro */
#ifdef HEVCENC_TRACE
#define APITRACE(str) Jenc_VCEncTrace(str)
#define APITRACEERR(str) Jenc_VCEncTrace(str)
#define APITRACEPARAM_X(str, val) \
  { char tmpstr[255]; sprintf(tmpstr, "  %s: %p", str, (void *)val); Jenc_VCEncTrace(tmpstr); }
#define APITRACEPARAM(str, val) \
  { char tmpstr[255]; sprintf(tmpstr, "  %s: %d", str, (int)val); Jenc_VCEncTrace(tmpstr); }
#else
#define APITRACE(str)
#define APITRACEERR(str) { printf(str); printf("\n"); }
#define APITRACEPARAM_X(str, val)
#define APITRACEPARAM(str, val)
#endif

#define APIPRINT(v, ...) { if(v)printf(__VA_ARGS__); }

#define HEVC_LEVEL_NUM 13
#define H264_LEVEL_NUM 20
#define AV1_LEVEL_NUM  24
#define VP9_LEVEL_NUM  14
#define AV1_VALID_MAX_LEVEL  15
#define VP9_VALID_MAX_LEVEL  10

/*------------------------------------------------------------------------------
       Encoder API utils function prototypes
  ------------------------------------------------------------------------------*/
void Jenc_VCEncShutdown(VCEncInst inst);
void Jenc_GenNextPicConfig(VCEncIn *pEncIn, const u8 *gopCfgOffset, i32 codecH264, i32 i32LastPicPoc);
u64 Jenc_CalNextPic(VCEncGopConfig *cfg, int picture_cnt);
void Jenc_StrmEncodeTraceEncInPara(VCEncIn *pEncIn, struct vcenc_instance *vcenc_instance);
VCEncRet Jenc_StrmEncodeCheckPara(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, 
                      VCEncOut *pEncOut, asicData_s *asic, u32 client_type);
void Jenc_StrmEncodeGlobalmvConfig(asicData_s *asic, struct sw_picture *pic, VCEncIn *pEncIn, 
                      struct vcenc_instance *vcenc_instance);
void Jenc_StrmEncodeOverlayConfig(asicData_s *asic, VCEncIn *pEncIn, struct vcenc_instance *vcenc_instance);
void Jenc_StrmEncodePrefixSei(struct vcenc_instance *vcenc_instance, struct Jenc_sps *s, 
                      VCEncOut *pEncOut, struct sw_picture *pic, VCEncIn *pEncIn);
void Jenc_StrmEncodeSuffixSei(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, VCEncOut *pEncOut);
void Jenc_StrmEncodeGradualDecoderRefresh(struct vcenc_instance *vcenc_instance, asicData_s *asic, 
            VCEncIn *pEncIn, VCEncPictureCodingType *codingType, JENC_EWLHwConfig_t cfg);
void Jenc_StrmEncodeRegionOfInterest(struct vcenc_instance *vcenc_instance, asicData_s *asic);
VCEncRet Jenc_EncGetSSIM (struct vcenc_instance *inst, VCEncOut *pEncOut);
VCEncRet Jenc_EncGetPSNR (struct vcenc_instance *inst, VCEncOut *pEncOut);
VCEncRet Jenc_TemporalMvpGenConfig(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, struct container *c,
                                struct sw_picture *pic, VCEncPictureCodingType codingType);
VCEncRet Jenc_GenralRefPicMarking(struct vcenc_instance *vcenc_instance, struct container *c, struct rps *r);

void Jenc_VCEncAddNaluSize(VCEncOut *pEncOut, u32 naluSizeBytes);

VCEncRet Jenc_VCEncCodecPrepareEncode(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, 
                                            VCEncOut *pEncOut, VCEncPictureCodingType codingType, 
                                            struct sw_picture *pic, struct container *c, u32* segcounts);

VCEncRet Jenc_VCEncCodecPostEncodeUpdate(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, VCEncOut *pEncOut, 
                   VCEncPictureCodingType codingType, struct sw_picture *pic);

void Jenc_EndOfSequence(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, VCEncOut *pEncOut);

#endif
