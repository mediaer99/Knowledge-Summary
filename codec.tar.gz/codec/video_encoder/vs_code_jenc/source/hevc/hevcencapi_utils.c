/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2019 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : VC Encoder API utils
--
------------------------------------------------------------------------------*/
#include <math.h>

#include "jenc_hevcencapi.h"
#include "hevcencapi_utils.h"
#include "encasiccontroller.h"
#include "sw_put_bits.h"

#ifdef INTERNAL_TEST
#include "sw_test_id.h"
#endif

#ifdef TEST_DATA
#include "enctrace.h"
#endif

#ifdef TRACE_REGS
#include "enctrace.h"
#endif

#ifdef VIDEOSTAB_ENABLED
#include "vidstabcommon.h"
#endif

#ifdef SUPPORT_VP9
#include "vp9encapi.h"
#endif

#ifdef SUPPORT_AV1
#include "av1encapi.h"
#endif


#ifdef TEMPORAL_MVP_SUPPORT
/* Use register in future. And only need 1 set for both P2 and P1 */
extern u32 globalTMVPenable;
extern u32 globalCOLLfromL0;
extern u32 globalCOLLrefIdx;
extern ptr_t mvInfoBase;
extern ptr_t rplMvInfoBaseL0;
extern ptr_t rplMvInfoBaseL1;
extern u32 rplL0DeltaPocL0;
extern u32 rplL0DeltaPocL1;
extern u32 rplL1DeltaPocL0;
extern u32 rplL1DeltaPocL1;
extern u32 previousPoc;


extern u32 globalTMVPenablePass1;
extern u32 globalCOLLfromL0Pass1;
extern u32 globalCOLLrefIdxPass1;
extern ptr_t mvInfoBasePass1;
extern ptr_t rplMvInfoBaseL0Pass1;
extern ptr_t rplMvInfoBaseL1Pass1;
extern u32 rplL0DeltaPocL0Pass1;
extern u32 rplL0DeltaPocL1Pass1;
extern u32 rplL1DeltaPocL0Pass1;
extern u32 rplL1DeltaPocL1Pass1;
extern u32 previousPocPass1;

//For av1 order hint
extern u32 orderHint[8];
extern u32 savedOrderHint[2][8];

extern u32 orderHintPass1[8];
extern u32 savedOrderHintPass1[2][8];
#endif


/*------------------------------------------------------------------------------

    Jenc_VCEncShutdown

    Function frees the encoder instance.

    Input   inst    Pointer to the encoder instance to be freed.
                            After this the pointer is no longer valid.

------------------------------------------------------------------------------*/
void Jenc_VCEncShutdown(VCEncInst inst)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) inst;
  const void *ewl;

  ASSERT(inst);

  ewl = pEncInst->asic.ewl;

  if(pEncInst->asic.regs.vcmdBuf)
    JencEWLfree(pEncInst->asic.regs.vcmdBuf);

  Jenc_EncAsicMemFree_V2(&pEncInst->asic);

  JencEWLfree(pEncInst);

  (void) JencEWLRelease(ewl);
}

/*------------------------------------------------------------------------------
  next_picture calculates next input picture depending input and output
  frame rates.
------------------------------------------------------------------------------*/
u64 Jenc_CalNextPic(VCEncGopConfig *cfg, int picture_cnt)
{
  u64 numer, denom;

  numer = (u64)cfg->inputRateNumer * (u64)cfg->outputRateDenom;
  denom = (u64)cfg->inputRateDenom * (u64)cfg->outputRateNumer;

  return numer * (picture_cnt / (1 << cfg->interlacedFrame)) / denom;
}

/*------------------------------------------------------------------------------
Function name : Jenc_GenNextPicConfig
Description   : generate the pic reference configure befor one picture encoded
Return type   : void
Argument      : VCEncIn *pEncIn
Argument      : u8 *gopCfgOffset
Argument      : i32 codecH264
Argument      : i32 i32LastPicPoc
------------------------------------------------------------------------------*/
void Jenc_GenNextPicConfig(VCEncIn *pEncIn, const u8 *gopCfgOffset, i32 codecH264, i32 i32LastPicPoc)
{
    i32 i, j, k, i32Poc, i32LTRIdx, numRefPics, numRefPics_org=0;
    u8 u8CfgStart, u8IsLTR_ref, u8IsUpdated;
    i32 i32MaxpicOrderCntLsb = 1 << 16;

    ASSERT(pEncIn != NULL);
    ASSERT(gopCfgOffset != NULL);

    u8CfgStart = gopCfgOffset[pEncIn->gopSize];
    memcpy(&pEncIn->gopCurrPicConfig, &(pEncIn->gopConfig.pGopPicCfg[u8CfgStart + pEncIn->gopPicIdx]), sizeof(VCEncGopPicConfig));

    pEncIn->i8SpecialRpsIdx = -1;
    pEncIn->i8SpecialRpsIdx_next = -1;
    memset(pEncIn->bLTR_used_by_cur, 0, sizeof(u32)*VCENC_MAX_LT_REF_FRAMES);
    if (0 == pEncIn->gopConfig.special_size)
        return;

    /* update ltr */
    i32 i32RefIdx;
    for (i32RefIdx = 0; i32RefIdx < pEncIn->gopConfig.ltrcnt; i32RefIdx++)
    {
        if (HANTRO_TRUE == pEncIn->bLTR_need_update[i32RefIdx])
            pEncIn->long_term_ref_pic[i32RefIdx] = i32LastPicPoc;
    }

    memset(pEncIn->bLTR_need_update, 0, sizeof(u32)*pEncIn->gopConfig.ltrcnt);
    if (0 != pEncIn->bIsIDR)
    {
        i32Poc = 0;
        pEncIn->gopCurrPicConfig.temporalId = 0;
        for (i = 0; i < pEncIn->gopConfig.ltrcnt; i++)
            pEncIn->long_term_ref_pic[i]  = INVALITED_POC;
    }
    else
        i32Poc = pEncIn->poc;
    /* check the current picture encoded as LTR*/
    pEncIn->u8IdxEncodedAsLTR = 0;
    for (j = 0; j < pEncIn->gopConfig.special_size; j++)
    {
        if (pEncIn->bIsPeriodUsingLTR == HANTRO_FALSE)
            break;

        if ((pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval <= 0) || (pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Ltr == 0))
            continue;

        i32Poc = i32Poc - pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Offset;

        if (i32Poc < 0)
        {
            i32Poc += i32MaxpicOrderCntLsb;
            if (i32Poc > (i32MaxpicOrderCntLsb >> 1))
                i32Poc = -1;
        }

        if ((i32Poc >= 0)&& (i32Poc % pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval == 0))
        {
            /* more than one LTR at the same frame position */
            if (0 != pEncIn->u8IdxEncodedAsLTR)
            {
                // reuse the same POC LTR
                pEncIn->bLTR_need_update[pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Ltr - 1] = HANTRO_TRUE;
                continue;
            }

            pEncIn->gopCurrPicConfig.codingType = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == FRAME_TYPE_RESERVED) ? pEncIn->gopCurrPicConfig.codingType : pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType;
            pEncIn->gopCurrPicConfig.nonReference = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].nonReference == FRAME_TYPE_RESERVED) ? pEncIn->gopCurrPicConfig.nonReference : pEncIn->gopConfig.pGopPicSpecialCfg[j].nonReference;
            pEncIn->gopCurrPicConfig.numRefPics = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED) ? pEncIn->gopCurrPicConfig.numRefPics : pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics;
            pEncIn->gopCurrPicConfig.QpFactor = (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor == QPFACTOR_RESERVED) ? pEncIn->gopCurrPicConfig.QpFactor : pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor;
            pEncIn->gopCurrPicConfig.QpOffset = (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset == QPOFFSET_RESERVED) ? pEncIn->gopCurrPicConfig.QpOffset : pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset;
            pEncIn->gopCurrPicConfig.temporalId = (pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId == TEMPORALID_RESERVED) ? pEncIn->gopCurrPicConfig.temporalId : pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId;

            if (((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics != NUMREFPICS_RESERVED))
            {
                for (k = 0; k < (i32)pEncIn->gopCurrPicConfig.numRefPics; k++)
                {
                    pEncIn->gopCurrPicConfig.refPics[k].ref_pic     = pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].ref_pic;
                    pEncIn->gopCurrPicConfig.refPics[k].used_by_cur = pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].used_by_cur;
                }
            }

            pEncIn->u8IdxEncodedAsLTR = pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Ltr;
            pEncIn->bLTR_need_update[pEncIn->u8IdxEncodedAsLTR - 1] = HANTRO_TRUE;
        }
    }

    if (0 != pEncIn->bIsIDR)
        return;

    u8IsUpdated = 0;
    for (j = 0; j < pEncIn->gopConfig.special_size; j++)
    {
        if (pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval <= 0)
            continue;

        /* no changed */
        if (((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == FRAME_TYPE_RESERVED) && ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED)
            && (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor == QPFACTOR_RESERVED) && (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset == QPOFFSET_RESERVED)
            && (pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId == TEMPORALID_RESERVED))
            continue;

        /* only consider LTR ref config */
        if (((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED))
        {
            /* reserved for later */
            pEncIn->i8SpecialRpsIdx = -1;
            u8IsUpdated                 = 1;
            continue;
        }

        if ((pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == VCENC_INTRA_FRAME)&&(pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == 0))
            numRefPics = 1;
        else
            numRefPics = pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics;

        numRefPics_org = pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics;
        for (k = 0; k < numRefPics; k++)
        {
            u8IsLTR_ref = IS_LONG_TERM_REF_DELTAPOC(pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].ref_pic);
            if ((u8IsLTR_ref == HANTRO_FALSE) && (0 == pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change))
                continue;
            i32LTRIdx = (u8IsLTR_ref == HANTRO_TRUE)?LONG_TERM_REF_DELTAPOC2ID(pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].ref_pic):0;

            if ((pEncIn->long_term_ref_pic[i32LTRIdx] == INVALITED_POC)&&(u8IsLTR_ref != HANTRO_FALSE) && (0 == pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change))
                continue;

            if (pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change != 0)
                i32Poc = pEncIn->poc - pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Offset;
            else
                i32Poc = pEncIn->poc - pEncIn->long_term_ref_pic[i32LTRIdx] - pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Offset;

            if (i32Poc < 0)
            {
                i32Poc += i32MaxpicOrderCntLsb;
                if (i32Poc > (i32MaxpicOrderCntLsb >> 1))
                   i32Poc = -1;
            }

            if ((i32Poc >= 0) && (i32Poc % pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval == 0))
            {
                pEncIn->gopCurrPicConfig.codingType = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == FRAME_TYPE_RESERVED) ? pEncIn->gopCurrPicConfig.codingType : pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType;
                pEncIn->gopCurrPicConfig.nonReference = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].nonReference == FRAME_TYPE_RESERVED) ? pEncIn->gopCurrPicConfig.nonReference : pEncIn->gopConfig.pGopPicSpecialCfg[j].nonReference;
                pEncIn->gopCurrPicConfig.numRefPics = ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED) ? pEncIn->gopCurrPicConfig.numRefPics : pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics;
                pEncIn->gopCurrPicConfig.QpFactor = (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor == QPFACTOR_RESERVED) ? pEncIn->gopCurrPicConfig.QpFactor : pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor;
                pEncIn->gopCurrPicConfig.QpOffset = (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset == QPOFFSET_RESERVED) ? pEncIn->gopCurrPicConfig.QpOffset : pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset;
                pEncIn->gopCurrPicConfig.temporalId = (pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId == TEMPORALID_RESERVED) ? pEncIn->gopCurrPicConfig.temporalId : pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId;

                if ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics != NUMREFPICS_RESERVED)
                {
                    for (i = 0; i < (i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics; i++)
                    {
                        pEncIn->gopCurrPicConfig.refPics[i].ref_pic = pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[i].ref_pic;
                        pEncIn->gopCurrPicConfig.refPics[i].used_by_cur = pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[i].used_by_cur;
                    }
                }

                pEncIn->i8SpecialRpsIdx = j;

                u8IsUpdated = 1;
            }

            if (0 != u8IsUpdated)
                break;
        }

        if(0 != u8IsUpdated)
            break;
    }

    if (codecH264)
    {
        u8IsUpdated = 0;
        for (j = 0; j < pEncIn->gopConfig.special_size; j++)
        {
            if (pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval <= 0)
                continue;

            /* no changed */
            if (((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == FRAME_TYPE_RESERVED) && ((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED)
                && (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpFactor == QPFACTOR_RESERVED) && (pEncIn->gopConfig.pGopPicSpecialCfg[j].QpOffset == QPOFFSET_RESERVED)
                && (pEncIn->gopConfig.pGopPicSpecialCfg[j].temporalId == TEMPORALID_RESERVED))
                continue;

            /* only consider LTR ref config */
            if (((i32)pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == NUMREFPICS_RESERVED))
            {
                /* reserved for later */
                pEncIn->i8SpecialRpsIdx_next = -1;
                u8IsUpdated = 1;
                continue;
            }

            if ((pEncIn->gopConfig.pGopPicSpecialCfg[j].codingType == VCENC_INTRA_FRAME) && (pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics == 0))
                numRefPics = 1;
            else
                numRefPics = pEncIn->gopConfig.pGopPicSpecialCfg[j].numRefPics;
            for (k = 0; k < numRefPics; k++)
            {
                u8IsLTR_ref = IS_LONG_TERM_REF_DELTAPOC(pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].ref_pic);
                if ((u8IsLTR_ref == HANTRO_FALSE) && (0 == pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change))
                    continue;
                i32LTRIdx = (u8IsLTR_ref == HANTRO_TRUE) ? LONG_TERM_REF_DELTAPOC2ID(pEncIn->gopConfig.pGopPicSpecialCfg[j].refPics[k].ref_pic) : 0;

                if ((pEncIn->long_term_ref_pic[i32LTRIdx] == INVALITED_POC) && (u8IsLTR_ref != HANTRO_FALSE) && (0 == pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change))
                    continue;

                if (pEncIn->gopConfig.pGopPicSpecialCfg[j].i32short_change != 0)
                    i32Poc = pEncIn->poc + pEncIn->gopConfig.delta_poc_to_next - pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Offset;
                else
                    i32Poc = pEncIn->poc + pEncIn->gopConfig.delta_poc_to_next - pEncIn->long_term_ref_pic[i32LTRIdx] - pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Offset;

                if (i32Poc < 0)
                {
                    i32Poc += i32MaxpicOrderCntLsb;
                    if (i32Poc >(i32MaxpicOrderCntLsb >> 1))
                        i32Poc = -1;
                }

                if ((i32Poc >= 0) && (i32Poc % pEncIn->gopConfig.pGopPicSpecialCfg[j].i32Interval == 0))
                {
                    pEncIn->i8SpecialRpsIdx_next = j;
                    u8IsUpdated = 1;
                }

                if (0 != u8IsUpdated)
                    break;
            }

            if (0 != u8IsUpdated)
                break;
        }
    }

    if (pEncIn->gopCurrPicConfig.codingType == VCENC_INTRA_FRAME)
        pEncIn->gopCurrPicConfig.numRefPics = numRefPics_org;


    j = 0;
    for (k = 0; k < (i32)pEncIn->gopCurrPicConfig.numRefPics; k++)
    {
        if (0 != pEncIn->gopCurrPicConfig.refPics[k].used_by_cur)
            j++;

        u8IsLTR_ref = IS_LONG_TERM_REF_DELTAPOC(pEncIn->gopCurrPicConfig.refPics[k].ref_pic);
        if (u8IsLTR_ref == HANTRO_FALSE)
            continue;
        i32LTRIdx = LONG_TERM_REF_DELTAPOC2ID(pEncIn->gopCurrPicConfig.refPics[k].ref_pic);

        pEncIn->bLTR_used_by_cur[i32LTRIdx] = pEncIn->gopCurrPicConfig.refPics[k].used_by_cur? HANTRO_TRUE:HANTRO_FALSE;
    }

    if (j > 1)
        pEncIn->gopCurrPicConfig.codingType = VCENC_BIDIR_PREDICTED_FRAME;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeTraceEncInPara
    Description   : Trace EncIn parameters
    Return type   : void
    Argument      : pEncIn - input parameters provided by user
                    vcenc_instance - encoder instance
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeTraceEncInPara(VCEncIn *pEncIn, struct vcenc_instance *vcenc_instance)
{
  APITRACE("Jenc_VCEncStrmEncode#");
  if (pEncIn != NULL)
  {
    APITRACEPARAM_X("busLuma", pEncIn->busLuma);
    APITRACEPARAM_X("busChromaU", pEncIn->busChromaU);
    APITRACEPARAM_X("busChromaV", pEncIn->busChromaV);
    APITRACEPARAM("timeIncrement", pEncIn->timeIncrement);
    APITRACEPARAM_X("pOutBuf", pEncIn->pOutBuf[0]);
    APITRACEPARAM_X("busOutBuf", pEncIn->busOutBuf[0]);
    APITRACEPARAM("outBufSize", pEncIn->outBufSize[0]);
    if (vcenc_instance->asic.regs.asicCfg.streamBufferChain)
    {
      APITRACEPARAM_X("pOutBuf1", pEncIn->pOutBuf[1]);
      APITRACEPARAM_X("busOutBuf1", pEncIn->busOutBuf[1]);
      APITRACEPARAM("outBufSize1", pEncIn->outBufSize[1]);
    }
    APITRACEPARAM("codingType", pEncIn->codingType);
    APITRACEPARAM("poc", pEncIn->poc);
    APITRACEPARAM("gopSize", pEncIn->gopSize);
    APITRACEPARAM("gopPicIdx", pEncIn->gopPicIdx);
    APITRACEPARAM_X("roiMapDeltaQpAddr", pEncIn->roiMapDeltaQpAddr);
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeCheckPara
    Description   : check illegal condition and return a status
    Return type   : VCEncRet
    Argument      : vcenc_instance - encoder instance
                    pEncIn - input parameters provided by user
                    pEncOut - place where output info is returned
                    asic - asic data
------------------------------------------------------------------------------*/
VCEncRet Jenc_StrmEncodeCheckPara(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, VCEncOut *pEncOut, asicData_s *asic, u32 client_type)
{
  /* Check for illegal inputs. */
  if ((vcenc_instance == NULL) || (pEncIn == NULL) || (pEncOut == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance. */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }
   /* Check status, INIT and ERROR not allowed. */
  if ((vcenc_instance->encStatus != VCENCSTAT_START_STREAM) &&
      (vcenc_instance->encStatus != VCENCSTAT_START_FRAME))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid status");
    return VCENC_INVALID_STATUS;
  }

  /* Check for invalid input values. */
  if ((pEncIn->gopSize > 1) &&
       (HW_ID_MAJOR_NUMBER(JencEncAsicGetAsicHWid(client_type, vcenc_instance->ctx)) <= 1))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid gopSize");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pEncIn->codingType > VCENC_NOTCODED_FRAME)
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid coding type");
    return VCENC_INVALID_ARGUMENT;
  }

   /* Check output stream buffers. */
  if ((pEncIn->busOutBuf[0] == 0) || (pEncIn->pOutBuf[0] == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid output stream buffer");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((vcenc_instance->streamMultiSegment.streamMultiSegmentMode == 0) && (pEncIn->outBufSize[0] < VCENC_STREAM_MIN_BUF0_SIZE))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Too small output stream buffer");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pEncIn->busOutBuf[1] || pEncIn->pOutBuf[1] || pEncIn->outBufSize[1])
  {
    if (!asic->regs.asicCfg.streamBufferChain)
    {
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR Two stream buffer not supported");
      return VCENC_INVALID_ARGUMENT;
    }
    else if ((pEncIn->busOutBuf[1] == 0) || (pEncIn->pOutBuf[1] == NULL))
    {
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid output stream buffer1");
      return VCENC_INVALID_ARGUMENT;
    }
    else if (vcenc_instance->streamMultiSegment.streamMultiSegmentMode != 0)
    {
      APITRACEERR("Jenc_VCEncStrmEncode:two output buffer not support multi-segment");
      return VCENC_INVALID_ARGUMENT;
    }
    else if (IS_VP9(vcenc_instance->codecFormat))
    {
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR Two stream buffer not supported by VP9");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (vcenc_instance->streamMultiSegment.streamMultiSegmentMode != 0 && vcenc_instance->parallelCoreNum > 1)
  {
    APITRACEERR("Jenc_VCEncStrmEncode: multi-segment not support multi-core");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Check GDR. */
  if ((vcenc_instance->gdrEnabled) && (pEncIn->codingType == VCENC_BIDIR_PREDICTED_FRAME))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR gdr not support B frame");
    return VCENC_INVALID_ARGUMENT;
  }
   /* Check limitation for H.264 baseline profile. */
  if (IS_H264(vcenc_instance->codecFormat) && vcenc_instance->profile == 66 && pEncIn->codingType == VCENC_BIDIR_PREDICTED_FRAME)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid frame type for baseline profile");
    return VCENC_INVALID_ARGUMENT;
  }

  switch (vcenc_instance->preProcess.inputFormat)
  {
    case VCENC_YUV420_PLANAR:
    case VCENC_YVU420_PLANAR:
    case VCENC_YUV420_PLANAR_10BIT_I010:
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC:
      if (!VCENC_BUS_CH_ADDRESS_VALID(pEncIn->busChromaV))
      {
        APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid input busChromaV");
        return VCENC_INVALID_ARGUMENT;
      }
    /* Fall through. */
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
    case VCENC_YUV420_PLANAR_10BIT_P010:
    case VCENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case VCENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case VCENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
    case VCENC_YUV420_SEMIPLANAR_101010:
    case VCENC_YUV420_8BIT_TILE_64_4:
    case VCENC_YUV420_UV_8BIT_TILE_64_4:
    case VCENC_YUV420_10BIT_TILE_32_4:
    case VCENC_YUV420_10BIT_TILE_48_4:
    case VCENC_YUV420_VU_10BIT_TILE_48_4:
    case VCENC_YUV420_8BIT_TILE_128_2:
    case VCENC_YUV420_UV_8BIT_TILE_128_2:
    case VCENC_YUV420_10BIT_TILE_96_2:
    case VCENC_YUV420_VU_10BIT_TILE_96_2:
    case VCENC_YUV420_8BIT_TILE_8_8:
    case VCENC_YUV420_10BIT_TILE_8_8:
    case VCENC_YUV420_FBC:
      if (!VCENC_BUS_ADDRESS_VALID(pEncIn->busChromaU))
      {
        APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid input busChromaU");
        return VCENC_INVALID_ARGUMENT;
      }
    /* Fall through. */
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444:
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_H264:
      if (!VCENC_BUS_ADDRESS_VALID(pEncIn->busLuma))
      {
        APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid input busLuma");
        return VCENC_INVALID_ARGUMENT;
      }
      break;
    default:
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid input format");
      return VCENC_INVALID_ARGUMENT;
  }

  if (vcenc_instance->preProcess.videoStab)
  {
    if (!VCENC_BUS_ADDRESS_VALID(pEncIn->busLumaStab))
    {
      APITRACE("Jenc_VCEncStrmEncodeExt: ERROR Invalid input busLumaStab");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  /* Stride feature only support YUV420SP and YUV422. */
  if ((vcenc_instance->input_alignment > 1) &&
      ((vcenc_instance->preProcess.inputFormat == VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR)||
       (vcenc_instance->preProcess.inputFormat == VCENC_YUV420_10BIT_PACKED_Y0L2)||
       (vcenc_instance->preProcess.inputFormat == VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC)||
       (vcenc_instance->preProcess.inputFormat == VCENC_YUV420_PLANAR_8BIT_DAHUA_H264)))
    {
      APITRACEERR("Jenc_VCEncStrmEncode: WARNING alignment doesn't support input format");
    }
  return VCENC_OK;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeGlobalmvConfig
    Description   : configure global MV parameter
    Return type   : void
    Argument      : asic - asic data
                    pic - picture
                    pEncIn - input parameters provided by user
                    vcenc_instance - encoder instance
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeGlobalmvConfig(asicData_s *asic, struct sw_picture *pic, VCEncIn *pEncIn, struct vcenc_instance *vcenc_instance )
{
#ifdef GLOBAL_MV_ON_SEARCH_RANGE
    int inLoopDSRatio = (vcenc_instance->pass == 2)? 2 : 1;
    //int inLoopDSRatio = (vcenc_instance->extDSRatio)? (vcenc_instance->extDSRatio + 1) : (vcenc_instance->inLoopDSRatio + 1);
    asic->regs.gmv[0][0] = asic->regs.gmv[0][1] =
    asic->regs.gmv[1][0] = asic->regs.gmv[1][1] = 0;
    if (pic->sliceInst->type != I_SLICE)
    {
      asic->regs.gmv[0][0] = (i16)(pEncIn->gmv[0][0]*inLoopDSRatio);
      asic->regs.gmv[0][1] = (i16)(pEncIn->gmv[0][1]*inLoopDSRatio);
    }
    if (pic->sliceInst->type == B_SLICE)
    {
      asic->regs.gmv[1][0] = (i16)(pEncIn->gmv[1][0]*inLoopDSRatio);
      asic->regs.gmv[1][1] = (i16)(pEncIn->gmv[1][1]*inLoopDSRatio);
    }
    if (vcenc_instance->pass == 2)
    {
      printf("    gmv[0]=(%d,%d), gmv[1]=(%d,%d)\n",
          asic->regs.gmv[0][0], asic->regs.gmv[0][1],
          asic->regs.gmv[1][0], asic->regs.gmv[1][1]);
    }
#else
    asic->regs.gmv[0][0] = asic->regs.gmv[0][1] =
    asic->regs.gmv[1][0] = asic->regs.gmv[1][1] = 0;
    if (pic->sliceInst->type != I_SLICE)
    {
      asic->regs.gmv[0][0] = pEncIn->gmv[0][0];
      asic->regs.gmv[0][1] = pEncIn->gmv[0][1];
    }
    if (pic->sliceInst->type == B_SLICE)
    {
      asic->regs.gmv[1][0] = pEncIn->gmv[1][0];
      asic->regs.gmv[1][1] = pEncIn->gmv[1][1];
    }
#endif

  /* Check GMV */
  if (asic->regs.asicCfg.gmvSupport)
  {
    i16 maxX, maxY;
    Jenc_getGMVRange (&maxX, &maxY, 0, IS_H264(vcenc_instance->codecFormat), pic->sliceInst->type == B_SLICE);

    if ((asic->regs.gmv[0][0] > maxX) || (asic->regs.gmv[0][0] < -maxX) ||
        (asic->regs.gmv[0][1] > maxY) || (asic->regs.gmv[0][1] < -maxY) ||
        (asic->regs.gmv[1][0] > maxX) || (asic->regs.gmv[1][0] < -maxX) ||
        (asic->regs.gmv[1][1] > maxY) || (asic->regs.gmv[1][1] < -maxY))
    {
      asic->regs.gmv[0][0] = CLIP3(-maxX,maxX,asic->regs.gmv[0][0]);
      asic->regs.gmv[0][1] = CLIP3(-maxY,maxY,asic->regs.gmv[0][1]);
      asic->regs.gmv[1][0] = CLIP3(-maxX,maxX,asic->regs.gmv[1][0]);
      asic->regs.gmv[1][1] = CLIP3(-maxY,maxY,asic->regs.gmv[1][1]);
      APITRACEERR("Jenc_VCEncStrmEncode: Global MV out of valid range");
      APIPRINT(1, "Jenc_VCEncStrmEncode: Clip Global MV to valid range: (%d, %d) for list0 and (%d, %d) for list1.\n",
        asic->regs.gmv[0][0],asic->regs.gmv[0][1],asic->regs.gmv[1][0],asic->regs.gmv[1][1]);
    }

    if (asic->regs.gmv[0][0] || asic->regs.gmv[0][1] || asic->regs.gmv[1][0] || asic->regs.gmv[1][1])
    {
      if ((pic->Jenc_sps->width < 320) || ((pic->Jenc_sps->width * pic->Jenc_sps->height) < (320 * 256)))
      {
        asic->regs.gmv[0][0] = asic->regs.gmv[0][1] = asic->regs.gmv[1][0] = asic->regs.gmv[1][1] = 0;
        APITRACEERR("Jenc_VCEncStrmEncode: Video size is too small to support Global MV, reset Global MV zero");
      }
    }
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeOverlayConfig
    Description   : configure OSD and mosaic parameter
    Return type   : void
    Argument      : asic - asic data
                    pEncIn - input parameters provided by user
                    vcenc_instance - encoder instance
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeOverlayConfig(asicData_s *asic, VCEncIn *pEncIn, struct vcenc_instance *vcenc_instance)
{
  int i;

  /* overlay regs */
  for (i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    //Offsets and cropping are handled in software prp, so we don't need to adjust them here
    asic->regs.overlayYAddr[i] = pEncIn->overlayInputYAddr[i];
    asic->regs.overlayUAddr[i] = pEncIn->overlayInputUAddr[i];
    asic->regs.overlayVAddr[i] = pEncIn->overlayInputVAddr[i];
    asic->regs.overlayEnable[i] = (vcenc_instance->pass == 1)?0 : pEncIn->overlayEnable[i];
    asic->regs.overlayFormat[i] = vcenc_instance->preProcess.overlayFormat[i];
    asic->regs.overlayAlpha[i] = vcenc_instance->preProcess.overlayAlpha[i];
    asic->regs.overlayXoffset[i] = vcenc_instance->preProcess.overlayXoffset[i];
    asic->regs.overlayYoffset[i] = vcenc_instance->preProcess.overlayYoffset[i];
    asic->regs.overlayWidth[i] = vcenc_instance->preProcess.overlayWidth[i];
    asic->regs.overlayHeight[i] = vcenc_instance->preProcess.overlayHeight[i];
    asic->regs.overlayYStride[i] = vcenc_instance->preProcess.overlayYStride[i];
    asic->regs.overlayUVStride[i] = vcenc_instance->preProcess.overlayUVStride[i];
    asic->regs.overlayBitmapY[i] = vcenc_instance->preProcess.overlayBitmapY[i];
    asic->regs.overlayBitmapU[i] = vcenc_instance->preProcess.overlayBitmapU[i];
    asic->regs.overlayBitmapV[i] = vcenc_instance->preProcess.overlayBitmapV[i];
  }
  if(vcenc_instance->preProcess.overlaySuperTile[0])
  {
    //To use 20 bit reg support 4k, times 64 in Cmodel
    asic->regs.overlayYStride[0] = vcenc_instance->preProcess.overlayYStride[0] / 64;
    asic->regs.overlayUVStride[0] = vcenc_instance->preProcess.overlayUVStride[0] / 64;
  }
  asic->regs.overlaySuperTile = vcenc_instance->preProcess.overlaySuperTile[0];
  asic->regs.overlayScaleWidth = vcenc_instance->preProcess.overlayScaleWidth[0];
  asic->regs.overlayScaleHeight = vcenc_instance->preProcess.overlayScaleHeight[0];
  asic->regs.overlayScaleStepW = (u16)((double)(vcenc_instance->preProcess.overlayCropWidth[0] << 16)
                          / vcenc_instance->preProcess.overlayScaleWidth[0]);
  asic->regs.overlayScaleStepH = (u16)((double)(vcenc_instance->preProcess.overlayCropHeight[0] << 16)
                          / vcenc_instance->preProcess.overlayScaleHeight[0]);

  /* Mosaic region(reuse OSD registers) */
  for (i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    /* Reuse OSD registers */
    if (vcenc_instance->preProcess.mosEnable[i])
    {
      asic->regs.overlayEnable[i] = (vcenc_instance->pass != 1);
      asic->regs.overlayFormat[i] = 3;
      asic->regs.overlayXoffset[i] = vcenc_instance->preProcess.mosXoffset[i];
      asic->regs.overlayYoffset[i] = vcenc_instance->preProcess.mosYoffset[i];
      asic->regs.overlayWidth[i] = vcenc_instance->preProcess.mosWidth[i];
      asic->regs.overlayHeight[i] = vcenc_instance->preProcess.mosHeight[i];
    }
  }

  /* Rest mosaic region */
  for (i = MAX_OVERLAY_NUM; i < MAX_MOSAIC_NUM; i++)
  {
    asic->regs.mosaicEnable[i - MAX_OVERLAY_NUM] = vcenc_instance->preProcess.mosEnable[i];
    asic->regs.mosaicXoffset[i - MAX_OVERLAY_NUM] = vcenc_instance->preProcess.mosXoffset[i];
    asic->regs.mosaicYoffset[i - MAX_OVERLAY_NUM] = vcenc_instance->preProcess.mosYoffset[i];
    asic->regs.mosaicWidth[i - MAX_OVERLAY_NUM] = vcenc_instance->preProcess.mosWidth[i];
    asic->regs.mosaicHeight[i - MAX_OVERLAY_NUM] = vcenc_instance->preProcess.mosHeight[i];
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodePrefixSei
    Description   : PREFIX sei message
    Return type   : void
    Argument      : vcenc_instance - encoder instance
                    s - Jenc_sps
                    pEncOut - place where output info is returned
                    pic - picture
                    pEncIn - input parameters provided by user
------------------------------------------------------------------------------*/
void Jenc_StrmEncodePrefixSei(struct vcenc_instance *vcenc_instance, struct Jenc_sps *s, VCEncOut *pEncOut, struct sw_picture *pic, VCEncIn *pEncIn)
{
  i32 tmp;
  if (IS_HEVC(vcenc_instance->codecFormat))
  {
    sei_s *sei = &vcenc_instance->rateControl.sei;

    if (sei->enabled == ENCHW_YES || sei->userDataEnabled == ENCHW_YES || sei->insertRecoveryPointMessage == ENCHW_YES
        || pEncIn->externalSEICount > 0)
    {
      if (sei->activated_sps == 0)
      {
        tmp = vcenc_instance->stream.byteCnt;
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, sei->byteStream);
        Jenc_HevcActiveParameterSetsSei(&vcenc_instance->stream, sei, &s->vui);
        Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

        sei->nalUnitSize = vcenc_instance->stream.byteCnt;
        printf(" activated_sps sei size=%d\n", vcenc_instance->stream.byteCnt);
        //pEncOut->streamSize+=vcenc_instance->stream.byteCnt;
        Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
        sei->activated_sps = 1;
      }
      if (sei->enabled == ENCHW_YES)
      {
        if ((pic->sliceInst->type == I_SLICE) && (sei->hrd == ENCHW_YES))
        {
          tmp = vcenc_instance->stream.byteCnt;
          Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, sei->byteStream);
          Jenc_HevcBufferingSei(&vcenc_instance->stream, sei, &s->vui);
          Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

          sei->nalUnitSize = vcenc_instance->stream.byteCnt;
          printf("BufferingSei sei size=%d\n", vcenc_instance->stream.byteCnt);
          //pEncOut->streamSize+=vcenc_instance->stream.byteCnt;
          Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
        }
        tmp = vcenc_instance->stream.byteCnt;
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, sei->byteStream);
        Jenc_HevcPicTimingSei(&vcenc_instance->stream, sei, &s->vui);
        Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

        sei->nalUnitSize = vcenc_instance->stream.byteCnt;
        printf("PicTiming sei size=%d\n", vcenc_instance->stream.byteCnt);
        //pEncOut->streamSize+=vcenc_instance->stream.byteCnt;
        Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
      }
      if (sei->userDataEnabled == ENCHW_YES)
      {
        tmp = vcenc_instance->stream.byteCnt;
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, sei->byteStream);
        Jenc_HevcUserDataUnregSei(&vcenc_instance->stream, sei);
        Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

        sei->nalUnitSize = vcenc_instance->stream.byteCnt;
        printf("UserDataUnreg sei size=%d\n", vcenc_instance->stream.byteCnt);
        //pEncOut->streamSize+=vcenc_instance->stream.byteCnt;
        Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
      }
      if (sei->insertRecoveryPointMessage == ENCHW_YES)
      {
        tmp = vcenc_instance->stream.byteCnt;
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, sei->byteStream);
        Jenc_HevcRecoveryPointSei(&vcenc_instance->stream, sei);
        Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

        sei->nalUnitSize = vcenc_instance->stream.byteCnt;
        printf("RecoveryPoint sei size=%d\n", vcenc_instance->stream.byteCnt);
        //pEncOut->streamSize+=vcenc_instance->stream.byteCnt;
        Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
      }
      if (pEncIn->externalSEICount > 0 && pEncIn->pExternalSEI != NULL)
      {
        for (int k = 0; k < pEncIn->externalSEICount; k++)
        {
          /* Skip only explicit SUFFIX_SEI_NUT */
          if (pEncIn->pExternalSEI[k].nalType == SUFFIX_SEI_NUT)
            continue;
          tmp = vcenc_instance->stream.byteCnt;
          Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, ENCHW_YES);

          u8 type = pEncIn->pExternalSEI[k].payloadType;
          u8 *content = pEncIn->pExternalSEI[k].pPayloadData;
          u32 size = pEncIn->pExternalSEI[k].payloadDataSize;
          Jenc_HevcExternalSei(&vcenc_instance->stream, type, content, size);

          Jenc_rbsp_trailing_bits(&vcenc_instance->stream);
          printf("External sei %d, size=%d\n", k, vcenc_instance->stream.byteCnt - tmp);
          Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
        }
      }
    }
  }
  else if (IS_H264(vcenc_instance->codecFormat))
  {
    sei_s *sei = &vcenc_instance->rateControl.sei;
    if(sei->enabled == ENCHW_YES || sei->userDataEnabled == ENCHW_YES || sei->insertRecoveryPointMessage == ENCHW_YES
       || pEncIn->externalSEICount > 0)
    {
      tmp = vcenc_instance->stream.byteCnt;
      Jenc_H264NalUnitHdr(&vcenc_instance->stream, 0, H264_SEI, sei->byteStream);
      if(sei->enabled == ENCHW_YES)
      {
          if((pic->sliceInst->type == I_SLICE) && (sei->hrd == ENCHW_YES))
          {
          	Jenc_H264BufferingSei(&vcenc_instance->stream, sei);
          }
          Jenc_H264PicTimingSei(&vcenc_instance->stream, sei);
      }
      if(sei->userDataEnabled == ENCHW_YES)
      {
      	Jenc_H264UserDataUnregSei(&vcenc_instance->stream, sei);
      }
      if (sei->insertRecoveryPointMessage == ENCHW_YES)
      {
      	Jenc_H264RecoveryPointSei(&vcenc_instance->stream, sei);
      }
      if (pEncIn->externalSEICount > 0 && pEncIn->pExternalSEI != NULL)
      {
        for (int k = 0; k < pEncIn->externalSEICount; k++)
        {
          u8 type = pEncIn->pExternalSEI[k].payloadType;
          u8 *content = pEncIn->pExternalSEI[k].pPayloadData;
          u32 size = pEncIn->pExternalSEI[k].payloadDataSize;
          Jenc_H264ExternalSei(&vcenc_instance->stream, type, content, size);
        }
      }
      Jenc_rbsp_trailing_bits(&vcenc_instance->stream);
      sei->nalUnitSize = vcenc_instance->stream.byteCnt;
      //printf("sei total size=%d\n", vcenc_instance->stream.byteCnt);
      Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
    }
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeSuffixSei
    Description   : SUFFIX SEI message
    Return type   : void
    Argument      : vcenc_instance - encoder instance
                    pEncIn - input parameters provided by user
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeSuffixSei(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, VCEncOut *pEncOut)
{
  if (IS_HEVC(vcenc_instance->codecFormat))
  {
    u32 tmp;
    sei_s *sei = &vcenc_instance->rateControl.sei;
    if (pEncIn->externalSEICount > 0 && pEncIn->pExternalSEI != NULL)
    {
      for (int k = 0; k < pEncIn->externalSEICount; k++)
      {
        if (pEncIn->pExternalSEI[k].nalType != SUFFIX_SEI_NUT)
          continue;
        u8 type = pEncIn->pExternalSEI[k].payloadType;
        u8 *content = pEncIn->pExternalSEI[k].pPayloadData;
        u32 size = pEncIn->pExternalSEI[k].payloadDataSize;
        if (!(type == 3 || type == 4 || type == 5 || type == 17 || type == 22 || type == 132 || type == 146))
        {
          printf("Payload type %d not allowed at SUFFIX_SEI_NUT\n", type);
          ASSERT(0);
        }
        tmp = vcenc_instance->stream.byteCnt;
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, SUFFIX_SEI_NUT, ENCHW_YES);
        Jenc_HevcExternalSei(&vcenc_instance->stream, type, content, size);
        Jenc_rbsp_trailing_bits(&vcenc_instance->stream);
        sei->nalUnitSize = vcenc_instance->stream.byteCnt;
        printf("External sei %d, size=%d\n", k, vcenc_instance->stream.byteCnt - tmp);
        Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
      }
    }
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeGradualDecoderRefresh
    Description   : configure GDR parameters
    Return type   : void
    Argument      : vcenc_instance - encoder instance
                    asic - asic data
                    pEncIn - input parameters provided by user
                    codingType - picture coding type
                    cfg - ewl HW config
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeGradualDecoderRefresh(struct vcenc_instance *vcenc_instance, asicData_s *asic, VCEncIn *pEncIn, VCEncPictureCodingType *codingType, JENC_EWLHwConfig_t cfg)
{
  i32 top_pos, bottom_pos;
  if ((vcenc_instance->gdrEnabled == 1) && (vcenc_instance->encStatus == VCENCSTAT_START_FRAME) && (vcenc_instance->gdrFirstIntraFrame == 0))
  {
    asic->regs.intraAreaTop = asic->regs.intraAreaLeft = asic->regs.intraAreaBottom =
                                asic->regs.intraAreaRight = INVALID_POS;
    asic->regs.roi1Top = asic->regs.roi1Left = asic->regs.roi1Bottom =
                           asic->regs.roi1Right = INVALID_POS;
    //asic->regs.roi1DeltaQp = 0;
    asic->regs.roi1Qp = -1;
    if (pEncIn->codingType == VCENC_INTRA_FRAME)
    {
      //vcenc_instance->gdrStart++ ;
      *codingType = VCENC_PREDICTED_FRAME;
    }
    if (vcenc_instance->gdrStart)
    {
      if (vcenc_instance->gdrCount == 0)
        vcenc_instance->rateControl.sei.insertRecoveryPointMessage = ENCHW_YES;
      else
        vcenc_instance->rateControl.sei.insertRecoveryPointMessage = ENCHW_NO;
      top_pos = (vcenc_instance->gdrCount / (1 + vcenc_instance->interlaced)) * vcenc_instance->gdrAverageMBRows;
      bottom_pos = 0;
      if (vcenc_instance->gdrMBLeft)
      {
        /* We need overlay rows between two GDR frame to make sure inter prediction vertical search range is
           within gdr intra area */
        u8 overlap_rows = 1;
        if ((vcenc_instance->gdrCount / (1 + (i32)vcenc_instance->interlaced)) < vcenc_instance->gdrMBLeft)
        {
          top_pos += (vcenc_instance->gdrCount / (1 + (i32)vcenc_instance->interlaced));
          /* Vertical search range is from 8-64. So for HEVC, 1 more ctb always fit.
             But for h264, we need search_range/16 more mbs */
          if(IS_H264(vcenc_instance->codecFormat))
          {
            overlap_rows = MAX((cfg.meVertSearchRangeH264 + 15)/16, 1);
          }
          bottom_pos += overlap_rows;
        }
        else
        {
          top_pos += vcenc_instance->gdrMBLeft;
        }
      }
      bottom_pos += top_pos + vcenc_instance->gdrAverageMBRows;
      if (bottom_pos > ((i32)vcenc_instance->ctbPerCol - 1))
      {
        bottom_pos = vcenc_instance->ctbPerCol - 1;
      }

      asic->regs.intraAreaTop = top_pos;
      asic->regs.intraAreaLeft = 0;
      asic->regs.intraAreaBottom = bottom_pos;
      asic->regs.intraAreaRight = vcenc_instance->ctbPerRow - 1;

      //to make video quality in intra area is close to inter area.
      asic->regs.roi1Top = top_pos;
      asic->regs.roi1Left = 0;
      asic->regs.roi1Bottom = bottom_pos;
      asic->regs.roi1Right = vcenc_instance->ctbPerRow - 1;

      /*
          roi1DeltaQp from user setting, or if user not provide roi1DeltaQp, use default roi1DeltaQp=3
      */
      if(!asic->regs.roi1DeltaQp)
        asic->regs.roi1DeltaQp = 3;

      asic->regs.rcRoiEnable = 0x01;

    }
    asic->regs.roiUpdate   = 1;    /* ROI has changed from previous frame. */
  }

}

/*------------------------------------------------------------------------------

    Function name : Jenc_StrmEncodeRegionOfInterest
    Description   : configure ROI parameters
    Return type   : void
    Argument      : vcenc_instance - encoder instance
                    asic - asic data
------------------------------------------------------------------------------*/
void Jenc_StrmEncodeRegionOfInterest(struct vcenc_instance *vcenc_instance, asicData_s *asic)
{
  asic->regs.offsetSliceQp = 0;
  if (asic->regs.qp >= 35)
  {
  	asic->regs.offsetSliceQp = 35 - asic->regs.qp;
  }
  if (asic->regs.qp <= 15)
  {
  	asic->regs.offsetSliceQp = 15 - asic->regs.qp;
  }

  if ((vcenc_instance->asic.regs.rcRoiEnable&0x0c) == 0)
  {
    if (vcenc_instance->asic.regs.rcRoiEnable &0x3)
    {
      if (asic->regs.asicCfg.roiAbsQpSupport)
      {
        i32 minDelta = (i32)asic->regs.qp - 51;

        asic->regs.roi1DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi1DeltaQp);
        asic->regs.roi2DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi2DeltaQp);

        if (asic->regs.roi1Qp >= 0)
          asic->regs.roi1Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi1Qp);

        if (asic->regs.roi2Qp >= 0)
          asic->regs.roi2Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi2Qp);

        if (asic->regs.asicCfg.ROI8Support)
        {
          asic->regs.roi3DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi3DeltaQp);
          asic->regs.roi4DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi4DeltaQp);
          asic->regs.roi5DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi5DeltaQp);
          asic->regs.roi6DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi6DeltaQp);
          asic->regs.roi7DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi7DeltaQp);
          asic->regs.roi8DeltaQp = CLIP3(minDelta, (i32)asic->regs.qp, asic->regs.roi8DeltaQp);

          if (asic->regs.roi3Qp >= 0)
            asic->regs.roi3Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi3Qp);

          if (asic->regs.roi4Qp >= 0)
             asic->regs.roi4Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi4Qp);

          if (asic->regs.roi5Qp >= 0)
            asic->regs.roi5Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi5Qp);

          if (asic->regs.roi6Qp >= 0)
            asic->regs.roi6Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi6Qp);

          if (asic->regs.roi7Qp >= 0)
            asic->regs.roi7Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi7Qp);

          if (asic->regs.roi8Qp >= 0)
             asic->regs.roi8Qp = CLIP3((i32)asic->regs.qpMin, (i32)asic->regs.qpMax, asic->regs.roi8Qp);
        }
      }
      else
      {
        asic->regs.roi1DeltaQp = CLIP3(0 ,15 - asic->regs.offsetSliceQp,asic->regs.roi1DeltaQp);
        asic->regs.roi2DeltaQp = CLIP3(0 ,15 - asic->regs.offsetSliceQp,asic->regs.roi2DeltaQp);
      }

      if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi1DeltaQp)
      {
        asic->regs.roi1DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
      }

      if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi2DeltaQp)
      {
        asic->regs.roi2DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
      }

      if (asic->regs.asicCfg.ROI8Support)
      {
        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi3DeltaQp)
        {
          asic->regs.roi3DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }

        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi4DeltaQp)
        {
          asic->regs.roi4DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }

        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi5DeltaQp)
        {
          asic->regs.roi5DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }

        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi6DeltaQp)
        {
          asic->regs.roi6DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }

        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi7DeltaQp)
        {
          asic->regs.roi7DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }

        if (((i32)asic->regs.qp - (i32)asic->regs.qpMin) < asic->regs.roi8DeltaQp)
        {
          asic->regs.roi8DeltaQp = (i32)asic->regs.qp - (i32)asic->regs.qpMin;
        }
      }
    }
  }
}

/*------------------------------------------------------------------------------

    Function name : Jenc_EncGetSSIM
    Description   : Calculate SSIM
    Return type   : VCEncRet
    Argument      : vcenc_instance - encoder instance
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_EncGetSSIM (struct vcenc_instance *inst, VCEncOut *pEncOut)
{
  if ((inst == NULL) || (pEncOut == NULL))
    return VCENC_ERROR;

  pEncOut->ssim[0] = pEncOut->ssim[1] = pEncOut->ssim[2] = 0.0;

  asicData_s *asic = &inst->asic;
  if ((!asic->regs.asicCfg.ssimSupport) || (!asic->regs.ssim))
    return VCENC_ERROR;

  const i32 shift_y  = (inst->Jenc_sps->bit_depth_luma_minus8==0)   ? SSIM_FIX_POINT_FOR_8BIT : SSIM_FIX_POINT_FOR_10BIT;
  const i32 shift_uv = (inst->Jenc_sps->bit_depth_chroma_minus8==0) ? SSIM_FIX_POINT_FOR_8BIT : SSIM_FIX_POINT_FOR_10BIT;
  i64 ssim_numerator_y = (i32)Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_Y_NUMERATOR_MSB);
  i64 ssim_numerator_u = (i32)Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_U_NUMERATOR_MSB);
  i64 ssim_numerator_v = (i32)Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_V_NUMERATOR_MSB);
  u32 ssim_denominator_y  = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_Y_DENOMINATOR);
  u32 ssim_denominator_uv = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_UV_DENOMINATOR);

  ssim_numerator_y = ssim_numerator_y << 32;
  ssim_numerator_u = ssim_numerator_u << 32;
  ssim_numerator_v = ssim_numerator_v << 32;
  ssim_numerator_y |= Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_Y_NUMERATOR_LSB);
  ssim_numerator_u |= Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_U_NUMERATOR_LSB);
  ssim_numerator_v |= Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSIM_V_NUMERATOR_LSB);

  if (ssim_denominator_y)
    pEncOut->ssim[0] = ssim_numerator_y * 1.0 / (1 << shift_y)  / ssim_denominator_y;

  if (ssim_denominator_uv)
  {
    pEncOut->ssim[1] = ssim_numerator_u * 1.0 / (1 << shift_uv) / ssim_denominator_uv;
    pEncOut->ssim[2] = ssim_numerator_v * 1.0 / (1 << shift_uv) / ssim_denominator_uv;
  }

#if 0
  double ssim = pEncOut->ssim[0] * 0.8 + 0.1 * (pEncOut->ssim[1] + pEncOut->ssim[2]);
  printf("    SSIM %.4f SSIM Y %.4f U %.4f V %.4f\n", ssim, pEncOut->ssim[0], pEncOut->ssim[1], pEncOut->ssim[2]);
#endif
  return VCENC_OK;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_EncGetPSNR
    Description   : operations about PSNR under several conditions
    Return type   : VCEncRet
    Argument      : vcenc_instance - encoder instance
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_EncGetPSNR (struct vcenc_instance *inst, VCEncOut *pEncOut)
{
  if ((inst == NULL) || (pEncOut == NULL))
      return VCENC_ERROR;

  asicData_s *asic = &inst->asic;

  /* calculate PSNR_Y,
  HW calculate SSE, SW calculate log10f
  In HW, 8 bottom lines in every 64 height unit is skipped to save line buffer
  SW log10f operation will waste too much CPU cycles,
  we suggest not use it, comment it out by default*/
  asic->regs.SSEDivide256 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SSE_DIV_256);
  {
    //pEncOut->psnr_y = (asic->regs.SSEDivide256 == 0)? 999999.0 :
    //                  10.0 * log10f((float)((256 << asic->regs.outputBitWidthLuma) - 1) * ((256 << asic->regs.outputBitWidthLuma) - 1) * asic->regs.picWidth * (asic->regs.picHeight - ((asic->regs.picHeight>>6)<<3))/ (float)(asic->regs.SSEDivide256 * ((256 << asic->regs.outputBitWidthLuma) << asic->regs.outputBitWidthLuma)));
  }

  /*PSNR for DJI*/
  asic->regs.lumSSEDivide256 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_LUM_SSE_DIV_256);
  asic->regs.cbSSEDivide64 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CB_SSE_DIV_64);
  asic->regs.crSSEDivide64 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CR_SSE_DIV_64);

#ifdef DJI
  pEncOut->psnr_y_predeb = (asic->regs.lumSSEDivide256 == 0)? 999999.0 :
                    10.0 * log10f((float)((256 << asic->regs.outputBitWidthLuma) - 1) * ((256 << asic->regs.outputBitWidthLuma) - 1) * asic->regs.picWidth * asic->regs.picHeight / (float)(asic->regs.lumSSEDivide256 * ((256 << asic->regs.outputBitWidthLuma) << asic->regs.outputBitWidthLuma)));
  pEncOut->psnr_cb_predeb = (asic->regs.cbSSEDivide64 == 0)? 999999.0 :
                    10.0 * log10f((float)((256 << asic->regs.outputBitWidthChroma) - 1) * ((256 << asic->regs.outputBitWidthChroma) - 1) * (asic->regs.picWidth/2) * (asic->regs.picHeight/2) / (float)(asic->regs.cbSSEDivide64 * ((64 << asic->regs.outputBitWidthChroma) << asic->regs.outputBitWidthChroma)));
  pEncOut->psnr_cr_predeb = (asic->regs.crSSEDivide64 == 0)? 999999.0 :
                    10.0 * log10f((float)((256 << asic->regs.outputBitWidthChroma) - 1) * ((256 << asic->regs.outputBitWidthChroma) - 1) * (asic->regs.picWidth/2) * (asic->regs.picHeight/2) / (float)(asic->regs.crSSEDivide64 * ((64 << asic->regs.outputBitWidthChroma) << asic->regs.outputBitWidthChroma)));
#endif

  inst->rateControl.hierarchial_sse[inst->rateControl.hierarchial_bit_allocation_GOP_size-1][inst->rateControl.gopPoc] = asic->regs.SSEDivide256;

  /*calculate accurate PSNR*/
  if (asic->regs.asicCfg.psnrSupport && asic->regs.psnr)
  {
    pEncOut->psnr[0] = pEncOut->psnr[1] = pEncOut->psnr[2] = 0.0;

    long long lum_sse, cb_sse, cr_sse;
    lum_sse = ((u32)asic->regs.lumSSEDivide256) \
              << 8 << inst->Jenc_sps->bit_depth_luma_minus8 << inst->Jenc_sps->bit_depth_luma_minus8;
    cb_sse = ((u32)asic->regs.cbSSEDivide64) \
              << 6 << inst->Jenc_sps->bit_depth_chroma_minus8 << inst->Jenc_sps->bit_depth_chroma_minus8;
    cr_sse = ((u32)asic->regs.crSSEDivide64) \
              << 6 << inst->Jenc_sps->bit_depth_chroma_minus8 << inst->Jenc_sps->bit_depth_chroma_minus8;

    float lum_mse, cb_mse, cr_mse;
    lum_mse = (float)lum_sse/(float)(inst->width * inst->height);
    cb_mse = ((float)cb_sse/(float)(inst->width * inst->height))*4;
    cr_mse = ((float)cr_sse/(float)(inst->width * inst->height))*4;

    int lum_max_value, cbcr_max_value;
    lum_max_value = (1 << inst->Jenc_sps->bit_depth_luma_minus8 << 8) - 1;
    cbcr_max_value = (1 << inst->Jenc_sps->bit_depth_chroma_minus8 << 8) - 1;

    if (lum_mse == 0.0)
      pEncOut->psnr[0] = 999999.0;
    else
      pEncOut->psnr[0] = 10.0 * log10f(lum_max_value * lum_max_value / lum_mse);

    if (cb_mse == 0.0)
      pEncOut->psnr[1] = 999999.0;
    else
      pEncOut->psnr[1] = 10.0 * log10f(cbcr_max_value * cbcr_max_value / cb_mse);

    if (cr_mse == 0.0)
      pEncOut->psnr[2] = 999999.0;
    else
      pEncOut->psnr[2] = 10.0 * log10f(cbcr_max_value * cbcr_max_value / cr_mse);
  }

  return VCENC_OK;
}

VCEncRet Jenc_GenralRefPicMarking(struct vcenc_instance *vcenc_instance, struct container *c, struct rps *r)
{
  VCEncRet ret = VCENC_OK;
#ifdef TEMPORAL_MVP_SUPPORT
  u32 savePrePoc = -1;
  if (IS_VP9(vcenc_instance->codecFormat))
    savePrePoc = (vcenc_instance->pass == 1)?previousPocPass1 : previousPoc;

  if (Jenc_ref_pic_marking(c, r, savePrePoc))
    ret = VCENC_ERROR;
#else
  if (Jenc_ref_pic_marking(c, r, -1))
    ret = VCENC_ERROR;
#endif
  return ret;
}


VCEncRet Jenc_TemporalMvpGenConfig(struct vcenc_instance *vcenc_instance, VCEncIn *pEncIn, struct container *c,
                                struct sw_picture *pic, VCEncPictureCodingType codingType)
{
  i32 i;
#ifdef TEMPORAL_MVP_SUPPORT
  if (vcenc_instance->pass != 1)
  {
    mvInfoBase = (ptr_t)pic->mvInfoBase;
    globalTMVPenable = !IS_H264(vcenc_instance->codecFormat);
    /* For VP9, tmvp is only enabled when last encoded frame is showable */
    if (IS_VP9(vcenc_instance->codecFormat) && !vcenc_instance->vp9_inst.lastFrameShowed)
    {
      globalTMVPenable = 0;
    }
    vcenc_instance->vp9_inst.lastFrameShowed = vcenc_instance->vp9_inst.show_frame;

    /* For AV1, enable controled by allow_ref_frame_mvs */
    if(IS_AV1(vcenc_instance->codecFormat))
      globalTMVPenable = vcenc_instance->av1_inst.allow_ref_frame_mvs;

    /* For P frame, use L0 as TMVP ref,
       For B frame, use L1 as TMVP ref (from H264) */
    globalCOLLfromL0 = (codingType == VCENC_PREDICTED_FRAME);
    /* Use closest ref */
    globalCOLLrefIdx = 0;

    if (pic->sliceInst->type != I_SLICE)
    {
      pic->deltaPocL0 = pic->rpl[0][0]->poc - pic->poc;
      if (IS_VP9(vcenc_instance->codecFormat))
      {
        struct sw_picture *previousPic = Jenc_get_picture(c, previousPoc);
        if(previousPic == NULL) {
          return VCENC_ERROR;
        }
        rplMvInfoBaseL0 = previousPic->mvInfoBase;
      }
      else
        rplMvInfoBaseL0 = pic->rpl[0][0]->mvInfoBase;
      rplL0DeltaPocL0 = pic->rpl[0][0]->deltaPocL0;
      rplL0DeltaPocL1 = pic->rpl[0][0]->deltaPocL1;
    }

    if (pic->sliceInst->type == B_SLICE)
    {
      pic->deltaPocL1 = pic->rpl[1][0]->poc - pic->poc;
      rplMvInfoBaseL1 = pic->rpl[1][0]->mvInfoBase;
      rplL1DeltaPocL0 = pic->rpl[1][0]->deltaPocL0;
      rplL1DeltaPocL1 = pic->rpl[1][0]->deltaPocL1;
    }

    /* We need to store order hint for av1 */
    if (IS_AV1(vcenc_instance->codecFormat))
    {
      for (i = 0; i < SW_REF_FRAMES; i++)
      {
        if (pic->sliceInst->type == I_SLICE)
          pic->av1OrderHint[i] = 0;
        else
        {
          pic->av1OrderHint[i] = pic->rpl[0][0]->poc;
          if (pic->sliceInst->type == B_SLICE && i > GOLDEN_FRAME)
            pic->av1OrderHint[i] = pic->rpl[1][0]->poc;
        }

        orderHint[i] = pic->av1OrderHint[i];
        if (pic->sliceInst->type != I_SLICE)
          savedOrderHint[0][i] = pic->rpl[0][0]->av1OrderHint[i];
        if (pic->sliceInst->type == B_SLICE)
          savedOrderHint[1][i] = pic->rpl[1][0]->av1OrderHint[i];
      }
    }
  }
  else
  {
    mvInfoBasePass1 = (ptr_t)pic->mvInfoBase;
    globalTMVPenablePass1 = !IS_H264(vcenc_instance->codecFormat);
    if (IS_VP9(vcenc_instance->codecFormat) && !vcenc_instance->vp9_inst.lastFrameShowed)
    {
      globalTMVPenablePass1 = 0;
    }
    vcenc_instance->vp9_inst.lastFrameShowed = vcenc_instance->vp9_inst.show_frame;
    if(IS_AV1(vcenc_instance->codecFormat))
      globalTMVPenable = vcenc_instance->av1_inst.allow_ref_frame_mvs;

    globalCOLLfromL0Pass1 = (codingType == VCENC_PREDICTED_FRAME);
    globalCOLLrefIdxPass1 = 0;

    if (pic->sliceInst->type != I_SLICE)
    {
      pic->deltaPocL0 = pic->rpl[0][0]->poc - pic->poc;
      if (IS_VP9(vcenc_instance->codecFormat))
      {
        struct sw_picture *previousPic = Jenc_get_picture(c, previousPocPass1);
        if(previousPic == NULL) {
          return VCENC_ERROR;
        }
        rplMvInfoBaseL0Pass1 = previousPic->mvInfoBase;
      }
      else
        rplMvInfoBaseL0Pass1 = pic->rpl[0][0]->mvInfoBase;
      rplL0DeltaPocL0Pass1 = pic->rpl[0][0]->deltaPocL0;
      rplL0DeltaPocL1Pass1 = pic->rpl[0][0]->deltaPocL1;
    }

    if (pic->sliceInst->type == B_SLICE)
    {
      pic->deltaPocL1 = pic->rpl[1][0]->poc - pic->poc;
      rplMvInfoBaseL1Pass1 = pic->rpl[1][0]->mvInfoBase;
      rplL1DeltaPocL0Pass1 = pic->rpl[1][0]->deltaPocL0;
      rplL1DeltaPocL1Pass1 = pic->rpl[1][0]->deltaPocL1;
    }

    if (IS_AV1(vcenc_instance->codecFormat))
    {
      for (i = 0; i < SW_REF_FRAMES; i++)
      {
        if (pic->sliceInst->type == I_SLICE)
          pic->av1OrderHint[i] = 0;
        else
        {
          pic->av1OrderHint[i] = pic->rpl[0][0]->poc;
          if (pic->sliceInst->type == B_SLICE && i > GOLDEN_FRAME)
            pic->av1OrderHint[i] = pic->rpl[1][0]->poc;
        }

        orderHintPass1[i] = pic->av1OrderHint[i];
        if (pic->sliceInst->type != I_SLICE)
          savedOrderHintPass1[0][i] = pic->rpl[0][0]->av1OrderHint[i];
        if (pic->sliceInst->type == B_SLICE)
          savedOrderHintPass1[1][i] = pic->rpl[1][0]->av1OrderHint[i];
      }
    }
  }
#endif

  return VCENC_OK;
}


/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncAddNaluSize
    Description   : Adds the size of a NAL unit into NAL size output buffer.

    Return type   : void
    Argument      : pEncOut - encoder output structure
    Argument      : naluSizeBytes - size of the NALU in bytes
------------------------------------------------------------------------------*/
void Jenc_VCEncAddNaluSize(VCEncOut *pEncOut, u32 naluSizeBytes)
{
  if (pEncOut->pNaluSizeBuf != NULL)
  {
    pEncOut->pNaluSizeBuf[pEncOut->numNalus++] = naluSizeBytes;
    pEncOut->pNaluSizeBuf[pEncOut->numNalus] = 0;
  }
}


/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncCodecPrepareEncode
    Description   : prepare encode for av1/vp9.
    Return type   : VCEncRet
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncCodecPrepareEncode(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn,
                                            VCEncOut *pEncOut, VCEncPictureCodingType codingType,
                                            struct sw_picture *pic, struct container *c, u32* segcounts)
{

#ifdef SUPPORT_VP9
  if(IS_VP9(vcenc_instance->codecFormat))
    return VCEncCodecPrepareEncodeVP9(vcenc_instance, pEncIn, pEncOut, codingType, pic, c, segcounts);
#endif

#ifdef SUPPORT_AV1
  if(IS_AV1(vcenc_instance->codecFormat))
    return VCEncCodecPrepareEncodeAV1(vcenc_instance, pEncIn, pEncOut, codingType, pic, c);
#endif

  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncCodecPostEncodeUpdate
    Description   : post encode update for av1/vp9.
    Return type   : VCEncRet
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncCodecPostEncodeUpdate(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, VCEncOut *pEncOut,
                   VCEncPictureCodingType codingType, struct sw_picture *pic)
{
#ifdef SUPPORT_VP9
  if(IS_VP9(vcenc_instance->codecFormat))
    return VCEncCodecPostEncodeUpdateVP9 (vcenc_instance, pEncIn, pEncOut, codingType, pic);
#endif

#ifdef SUPPORT_AV1
  if(IS_AV1(vcenc_instance->codecFormat))
    return VCEncCodecPostEncodeUpdateAV1 (vcenc_instance, pEncIn, pEncOut, codingType);
#endif

  return VCENC_OK;
}

/* Write end-of-stream code */
void Jenc_EndOfSequence(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, VCEncOut *pEncOut)
{
  if (IS_H264(vcenc_instance->codecFormat))
    Jenc_H264EndOfSequence(&vcenc_instance->stream, vcenc_instance->asic.regs.streamMode);
  else if(IS_HEVC(vcenc_instance->codecFormat))
    Jenc_HEVCEndOfSequence(&vcenc_instance->stream, vcenc_instance->asic.regs.streamMode);
#ifdef SUPPORT_AV1
  else if(IS_AV1(vcenc_instance->codecFormat))
    AV1EndOfSequence(vcenc_instance, pEncIn, pEncOut, &vcenc_instance->stream.byteCnt);
#endif
#ifdef SUPPORT_VP9
  else if(IS_VP9(vcenc_instance->codecFormat))
    VP9EndOfSequence(vcenc_instance, pEncIn, pEncOut, &vcenc_instance->stream.byteCnt);
#endif
}

