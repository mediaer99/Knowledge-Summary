/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2019 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : VC Encoder API
--
------------------------------------------------------------------------------*/

/**
 * \addtogroup api_video
 *
 * @{
 */

/*------------------------------------------------------------------------------
       Version Information
------------------------------------------------------------------------------*/
#include <math.h> /* for pow */
#include "vsi_string.h"
#include "osal.h"

#include "vc8000e_version.h"

#include "jenc_hevcencapi.h"
#include "hevcencapi_utils.h"

#include "base_type.h"
#include "error.h"
#include "instance.h"
#include "sw_parameter_set.h"
#include "rate_control_picture.h"
#include "sw_slice.h"
#include "tools.h"
#include "enccommon.h"
#include "hevcApiVersion.h"
#include "enccfg.h"
#include "hevcenccache.h"
#include "encdec400.h"
#include "axife.h"
#include "apbfilter.h"
#include "jenc_ewl.h"
#include "sw_put_bits.h"

#ifdef SUPPORT_VP9
#include "vp9encapi.h"
#endif

#ifdef SUPPORT_AV1
#include "av1encapi.h"
#endif

#ifdef INTERNAL_TEST
#include "sw_test_id.h"
#endif

#ifdef TEST_DATA
#include "enctrace.h"
#endif

#ifdef TRACE_REGS
#include "enctrace.h"
#endif

#ifdef VIDEOSTAB_ENABLED
#include "vidstabcommon.h"
#endif


typedef enum
{
  RCROIMODE_RC_ROIMAP_ROIAREA_DIABLE = 0,
  RCROIMODE_ROIAREA_ENABLE = 1,
  RCROIMODE_ROIMAP_ENABLE = 2,
  RCROIMODE_ROIMAP_ROIAREA_ENABLE = 3,
  RCROIMODE_RC_ENABLE = 4,
  RCROIMODE_RC_ROIAREA_ENABLE=5,
  RCROIMODE_RC_ROIMAP_ENABLE=6,
  RCROIMODE_RC_ROIMAP_ROIAREA_ENABLE=7

} RCROIMODEENABLE;

const u64 Jenc_VCEncMaxSBPSHevc[ HEVC_LEVEL_NUM ] =
{
  552960, 3686400, 7372800, 16588800, 33177600, 66846720, 133693440, 267386880,
  534773760, 1069547520, 1069547520, 2139095040, 4278190080
};
const u64 Jenc_VCEncMaxSBPSH264[ H264_LEVEL_NUM ] =
{
  1485*256, 1485*256, 3000*256, 6000*256, 11880*256, 11880*256, 19800*256, 20250*256
  , 40500*256, 108000*256, 216000*256, 245760*256, 245760*256
  , 522240*256, 589824*256, 983040*256, 2073600*256
  , 4177920*256, 8355840*256, 16711680ULL*256
};
const u64 Jenc_VCEncMaxSBPSAV1[ AV1_LEVEL_NUM ] =
{
  5529600, 10454400, 0, 0, 24969600, 39938400, 0, 0, 77856768, 155713536, 0, 0,
  273715200, 547430400, 1094860800, 1176502272, 1176502272, 2189721600, 4379443200, 4706009088,
  0, 0, 0, 0
};
const u64 Jenc_VCEncMaxSBPSVP9[ VP9_LEVEL_NUM ] =
{
  829440, 2764800, 4608000, 9216000, 20736000, 36864000, 83558400, 160432128, 311951360, 588251136,
  1176502272, 1176502272, 2353004544, 4706009088
};

const u32 Jenc_VCEncMaxPicSizeHevc[ HEVC_LEVEL_NUM ] =
{
  36864, 122880, 245760, 552960, 983040, 2228224, 2228224, 8912896,
  8912896, 8912896, 35651584, 35651584, 35651584
};
const u32 Jenc_VCEncMaxFSH264[ H264_LEVEL_NUM ] =
{
  99*256, 99*256, 396*256, 396*256, 396*256, 396*256, 792*256, 1620*256
  , 1620*256, 3600*256, 5120*256, 8192*256, 8192*256
  , 8704*256, 22080*256, 36864*256, 36864*256
  , 139264*256, 139264*256, 139264*256
};
const u32 Jenc_VCEncMaxPicSizeAV1[ AV1_LEVEL_NUM ] =
{
  147456, 278784, 0, 0, 665856, 1065024, 0, 0, 2359296, 2359296, 0, 0,
  8912896, 8912896, 8912896, 8912896, 35651584, 35651584, 35651584, 35651584,
  0, 0, 0, 0
};
const u32 Jenc_VCEncMaxPicSizeVP9[ VP9_LEVEL_NUM ] =
{
  36864, 73728, 122880, 245760, 552960, 983040, 2228224, 2228224, 8912896, 8912896, 8912896, 35651584, 35651584, 35651584
};

const u32 Jenc_VCEncMaxCPBSHevc[ HEVC_LEVEL_NUM ] =
{
  350000, 1500000, 3000000, 6000000, 10000000, 12000000, 20000000,
  25000000, 40000000, 60000000, 60000000, 120000000, 240000000
};
const u32 Jenc_VCEncMaxCPBSH264[ H264_LEVEL_NUM ] =
{
  175000, 350000, 500000, 1000000, 2000000, 2000000, 4000000, 4000000
  , 10000000, 14000000, 20000000, 25000000, 62500000
  , 62500000, 135000000, 240000000, 240000000
  , 240000000, 480000000, 800000000
};
const u32 Jenc_VCEncMaxCPBSHighTierHevc[ HEVC_LEVEL_NUM ] =
{
  350000, 1500000, 3000000, 6000000, 10000000, 30000000, 50000000,
  100000000, 160000000, 240000000, 240000000, 480000000, 800000000
};
const u32 Jenc_VCEncMaxCPBSAV1[ AV1_LEVEL_NUM ] =
{
  1500000, 3000000, 0, 0, 6000000, 10000000, 0, 0, 12000000, 20000000, 0, 0,
  30000000, 40000000, 60000000, 60000000, 60000000, 100000000, 160000000, 160000000, 0, 0, 0, 0
};
const u32 Jenc_VCEncMaxCPBSHighTierAV1[ AV1_LEVEL_NUM ] =
{
  0, 0, 0, 0, 0, 0, 0, 0, 30000000, 50000000, 0, 0,
  100000000, 160000000, 240000000, 240000000, 240000000, 480000000, 800000000, 800000000, 0, 0, 0, 0
};
const u32 Jenc_VCEncMaxCPBSVP9[ VP9_LEVEL_NUM ] =
{
  400000, 1000000, 1500000, 2800000, 6000000, 10000000, 16000000, 18000000, 36000000, 46000000, 0, 0, 0, 0
};

const u32 Jenc_VCEncMaxBRH264[ H264_LEVEL_NUM ] =
{
  64000, 128000, 192000, 384000, 768000, 2000000, 4000000, 4000000
  , 10000000, 14000000, 20000000, 20000000, 50000000
  , 50000000, 135000000, 240000000, 240000000
  , 240000000, 480000000, 800000000
};
const u32 Jenc_VCEncMaxBRVP9[ VP9_LEVEL_NUM ] =
{
  200000, 800000, 1800000, 3600000, 7200000, 12000000, 18000000, 30000000, 60000000, 120000000, 180000000, 180000000, 240000000, 480000000
};

static const u32 VCEncIntraPenalty[52] =
{
  24, 24, 24, 26, 27, 30, 32, 35, 39, 43, 48, 53, 58, 64, 71, 78,
  85, 93, 102, 111, 121, 131, 142, 154, 167, 180, 195, 211, 229,
  248, 271, 296, 326, 361, 404, 457, 523, 607, 714, 852, 1034,
  1272, 1588, 2008, 2568, 3318, 4323, 5672, 7486, 9928, 13216,
  17648
};//max*3=16bit

static const u32 lambdaSadDepth0Tbl[] =
{
  0x00000100, 0x0000011f, 0x00000143, 0x0000016a, 0x00000196, 0x000001c8,
  0x00000200, 0x0000023f, 0x00000285, 0x000002d4, 0x0000032d, 0x00000390,
  0x00000400, 0x0000047d, 0x0000050a, 0x000005a8, 0x00000659, 0x00000721,
  0x00000800, 0x000008fb, 0x00000a14, 0x00000b50, 0x00000cb3, 0x00000e41,
  0x00001000, 0x000011f6, 0x00001429, 0x000016a1, 0x00001966, 0x00001c82,
  0x00002000, 0x000023eb, 0x00002851, 0x00002d41, 0x000032cc, 0x00003904,
  0x00004000, 0x000047d6, 0x000050a3, 0x00005a82, 0x00006598, 0x00007209,
  0x00008000, 0x00008fad, 0x0000a145, 0x0000b505, 0x0000cb30, 0x0000e412,
  0x00010000, 0x00011f5a, 0x0001428a, 0x00016a0a
};

static const u32 lambdaSseDepth0Tbl[] =
{
  0x00000040, 0x00000051, 0x00000066, 0x00000080, 0x000000a1, 0x000000cb,
  0x00000100, 0x00000143, 0x00000196, 0x00000200, 0x00000285, 0x0000032d,
  0x00000400, 0x0000050a, 0x00000659, 0x00000800, 0x00000a14, 0x00000cb3,
  0x00001000, 0x00001429, 0x00001966, 0x00002000, 0x00002851, 0x000032cc,
  0x00004000, 0x000050a3, 0x00006598, 0x00008000, 0x0000a145, 0x0000cb30,
  0x00010000, 0x0001428a, 0x00019660, 0x00020000, 0x00028514, 0x00032cc0,
  0x00040000, 0x00050a29, 0x00065980, 0x00080000, 0x000a1451, 0x000cb2ff,
  0x00100000, 0x001428a3, 0x001965ff, 0x00200000, 0x00285146, 0x0032cbfd,
  0x00400000, 0x0050a28c, 0x006597fb, 0x00800000
};

static const u32 lambdaSadDepth1Tbl[] =
{
  0x0000016a, 0x00000196, 0x000001c8, 0x00000200, 0x0000023f, 0x00000285,
  0x000002d4, 0x0000032d, 0x00000390, 0x00000400, 0x0000047d, 0x0000050a,
  0x000005a8, 0x00000659, 0x00000721, 0x00000800, 0x000008fb, 0x00000a14,
  0x00000b50, 0x00000cb3, 0x00000e41, 0x00001000, 0x000011f6, 0x00001429,
  0x000016a1, 0x00001a6f, 0x00001ecb, 0x000023c7, 0x0000297a, 0x00002ffd,
  0x0000376d, 0x00003feb, 0x0000499c, 0x000054aa, 0x00006145, 0x00006fa2,
  0x00008000, 0x00008fad, 0x0000a145, 0x0000b505, 0x0000cb30, 0x0000e412,
  0x00010000, 0x00011f5a, 0x0001428a, 0x00016a0a, 0x00019660, 0x0001c824,
  0x00020000, 0x00023eb3, 0x00028514, 0x0002d414
};

static const u32 lambdaSseDepth1Tbl[] =
{
  0x00000080, 0x000000a1, 0x000000cb, 0x00000100, 0x00000143, 0x00000196,
  0x00000200, 0x00000285, 0x0000032d, 0x00000400, 0x0000050a, 0x00000659,
  0x00000800, 0x00000a14, 0x00000cb3, 0x00001000, 0x00001429, 0x00001966,
  0x00002000, 0x00002851, 0x000032cc, 0x00004000, 0x000050a3, 0x00006598,
  0x00008000, 0x0000aeb6, 0x0000ed0d, 0x00014000, 0x0001ae0e, 0x00023fb3,
  0x00030000, 0x0003fd60, 0x00054a95, 0x00070000, 0x00093d4b, 0x000c2b8a,
  0x00100000, 0x001428a3, 0x001965ff, 0x00200000, 0x00285146, 0x0032cbfd,
  0x00400000, 0x0050a28c, 0x006597fb, 0x00800000, 0x00a14518, 0x00cb2ff5,
  0x01000000, 0x01428a30, 0x01965fea, 0x02000000
};

static const float sqrtPow2QpDiv3[] = {
  /* for computing lambda_sad
   * for(int qp = 0; qp <= 63; qp++)
   *   sqrtPow2QpDiv3[i] = sqrt(pow(2.0, (qp-12)/3.0));
   */
  0.250000000, 0.280615512, 0.314980262, 0.353553391, 0.396850263, 0.445449359,
  0.500000000, 0.561231024, 0.629960525, 0.707106781, 0.793700526, 0.890898718,
  1.000000000, 1.122462048, 1.259921050, 1.414213562, 1.587401052, 1.781797436,
  2.000000000, 2.244924097, 2.519842100, 2.828427125, 3.174802104, 3.563594873,
  4.000000000, 4.489848193, 5.039684200, 5.656854249, 6.349604208, 7.127189745,
  8.000000000, 8.979696386, 10.079368399, 11.313708499, 12.699208416, 14.254379490,
  16.000000000, 17.959392773, 20.158736798, 22.627416998, 25.398416831, 28.508758980,
  32.000000000, 35.918785546, 40.317473597, 45.254833996, 50.796833663, 57.017517961,
  64.000000000, 71.837571092, 80.634947193, 90.509667992, 101.593667326, 114.035035922,
  128.000000000, 143.675142184, 161.269894387, 181.019335984, 203.187334652, 228.070071844,
  256.000000000, 287.350284367, 322.539788773, 362.038671968
};
static const float sqrtQpDiv6[] = {
  /* for computing lambda_sad
   * for(int qp = 0; qp <= 63; qp++)
   *   sqrtQpDiv6[i] = sqrt(CLIP3(2.0, 4.0, (qp-12) / 6.0));
   */
  1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562,
  1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562,
  1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.414213562, 1.471960144, 1.527525232, 1.581138830, 1.632993162, 1.683250823,
  1.732050808, 1.779513042, 1.825741858, 1.870828693, 1.914854216, 1.957890021, 2.000000000, 2.000000000, 2.000000000, 2.000000000,
  2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000,
  2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000, 2.000000000,
  2.000000000, 2.000000000, 2.000000000, 2.000000000
};

bool Jenc_multipass_enabled = HANTRO_FALSE;

#ifdef CDEF_BLOCK_STRENGTH_ENABLE
// [pass][luma/chroma][QP][strength]
u32 cdef_stats[2][2][64];

// [pass][luma_strength][chroma_strength]
u32 cdef_union[2][64][64];

// [pass][index]
//u8 cdef_y_strenth[2][8];
//u8 cdef_uv_strenth[2][8];
#endif

#define SLICE_TYPE_P            0
#define SLICE_TYPE_B            1
#define SLICE_TYPE_I            2
#define SLICE_TYPE_SP           3
#define SLICE_TYPE_SI           4

/*------------------------------------------------------------------------------
    4. Local function prototypes
------------------------------------------------------------------------------*/
static i32 out_of_memory(struct vcenc_buffer *n, u32 size);
static i32 get_buffer(struct buffer *, struct vcenc_buffer *, i32 size, i32 reset);
static i32 init_buffer(struct vcenc_buffer *, struct vcenc_instance *);
static i32 set_parameter(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn, struct Jenc_vps *v, struct Jenc_sps *s, struct Jenc_pps *p);
static bool_e VCEncCheckCfg(const VCEncConfig *pEncCfg, void *ctx);
static bool_e SetParameter(struct vcenc_instance *inst, const VCEncConfig   *pEncCfg);
static i32 vcenc_set_ref_pic_set(struct vcenc_instance *vcenc_instance);
static i32 vcenc_ref_pic_sets(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn);
static i32 VCEncGetAllowedWidth(i32 width, VCEncPictureType inputType);
static void IntraLamdaQpFixPoint(int qp, u32 *lamda_sad, enum slice_type type, int poc, u32 qpFactorSad, bool depth0);
static void InterLamdaQpFixPoint(int qp, unsigned int *lamda_sse, unsigned int *lamda_sad, enum slice_type type, u32 qpFactorSad, u32 qpFactorSse, bool depth0, u32 asicId);
static void IntraLamdaQp(int qp, u32 *lamda_sad, enum slice_type type, int poc, float dQPFactor, bool depth0);
static void InterLamdaQp(int qp, unsigned int *lamda_sse, unsigned int *lamda_sad, enum slice_type type, float dQPFactor, bool depth0, u32 asicId);
static void FillIntraFactor(regValues_s *regs);
static void LamdaTableQp(regValues_s *regs, int qp, enum slice_type type, int poc, double dQPFactor, bool depth0, u32 ctbRc);
static void VCEncSetQuantParameters(struct vcenc_instance *vcenc_instance,
                                         struct sw_picture *pic, const VCEncIn *pEncIn,
                                          double qp_factor, bool is_depth0);
static void VCEncSetNewFrame(VCEncInst inst);

/* DeNoise Filter */
static void VCEncHEVCDnfInit(struct vcenc_instance *vcenc_instance);
static void VCEncHEVCDnfSetParameters(struct vcenc_instance *vcenc_instance, const VCEncCodingCtrl *pCodeParams);
static void VCEncHEVCDnfGetParameters(struct vcenc_instance *vcenc_instance, VCEncCodingCtrl *pCodeParams);
static void VCEncHEVCDnfPrepare(struct vcenc_instance *vcenc_instance);
static void VCEncHEVCDnfUpdate(struct vcenc_instance *vcenc_instance);

/* RPS in slice header*/
static void VCEncGenSliceHeaderRps(struct vcenc_instance *vcenc_instance, VCEncPictureCodingType codingType, VCEncGopPicConfig *cfg);
static void VCEncGenPicRefConfig(struct container *c, VCEncGopPicConfig *cfg, struct sw_picture *pCurPic, i32 curPicPoc);

/* Parameter set send handler */
static void VCEncParameterSetHandle(struct vcenc_instance *vcenc_instance, VCEncInst inst, const VCEncIn *pEncIn, VCEncOut *pEncOut,struct container *c);

static void VCEncAddFillerNALU(VCEncInst inst, i32 cnt, true_e byteStream);
static VCEncLevel getLevel(VCEncVideoCodecFormat codecFormat, i32 levelIdx);
static VCEncLevel getLevelHevc(i32 levelIdx);
static VCEncLevel getLevelH264(i32 levelIdx);
static i32 getLevelIdx(VCEncVideoCodecFormat codecFormat, VCEncLevel levelIdx);
static i32 getlevelIdxHevc(VCEncLevel level);
static i32 getlevelIdxH264(VCEncLevel level);
static u64 getMaxSBPS( VCEncVideoCodecFormat codecFormat , i32 levelIdx );
static u32 getMaxPicSize( VCEncVideoCodecFormat codecFormat , i32 levelIdx );
static u32 getMaxCPBS( VCEncVideoCodecFormat codecFormat , i32 levelIdx, i32 profile,  i32 tier );
static u32 getMaxBR( VCEncVideoCodecFormat codecFormat , i32 levelIdx, i32 profile, i32 tier );

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncGetApiVersion
    Description   : Return the API version info

    Return type   : VCEncApiVersion
    Argument      : void
------------------------------------------------------------------------------*/
VCEncApiVersion Jenc_VCEncGetApiVersion(void)
{
  VCEncApiVersion ver;

  ver.major = VCENC_MAJOR_VERSION;
  ver.minor = VCENC_MINOR_VERSION;
  ver.clnum = VCENC_BUILD_CLNUM;

  APITRACE("Jenc_VCEncGetApiVersion# OK");
  return ver;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetBuild
    Description   : Return the SW and HW build information

    Return type   : VCEncBuild
    Argument      : void
------------------------------------------------------------------------------*/
VCEncBuild Jenc_VCEncGetBuild(u32 client_type)
{
  VCEncBuild ver;

  ver.swBuild = VCENC_SW_BUILD;
  ver.hwBuild = JencEncAsicGetAsicHWid(client_type, NULL);

  APITRACE("Jenc_VCEncGetBuild# OK");

  return (ver);
}

static inline JENC_CLIENT_TYPE VCEncGetClientType(VCEncVideoCodecFormat codecFormat)
{
  u32 clientType = JENC_EWL_CLIENT_TYPE_JPEG_ENC;
  if (IS_H264(codecFormat))
    clientType = JENC_EWL_CLIENT_TYPE_H264_ENC;
  else if (IS_AV1(codecFormat))
    clientType = JENC_EWL_CLIENT_TYPE_AV1_ENC;
  else if (IS_VP9(codecFormat))
    clientType = JENC_EWL_CLIENT_TYPE_VP9_ENC;
  else if (IS_HEVC(codecFormat))
    clientType = JENC_EWL_CLIENT_TYPE_HEVC_ENC;
  else{
    ASSERT(0 && "Unsupported codecFormat");
  }
  return clientType;
}

static void inline VideoTuneConfig(const VCEncConfig *config, struct vcenc_instance *vcenc_inst)
{
  if (!config || !vcenc_inst) return;
  regValues_s *regs = &vcenc_inst->asic.regs;

  vcenc_inst->cuTreeCtl.aqStrength = 1.0;
  vcenc_inst->cuTreeCtl.aq_mode = 0;
  vcenc_inst->psyFactor = 0.0;
  switch (config->tune)
  {
    case VCENC_TUNE_SSIM:
      vcenc_inst->cuTreeCtl.aq_mode = 2;
      break;
    case VCENC_TUNE_VISUAL:
    case VCENC_TUNE_SHARP_VISUAL:
      vcenc_inst->cuTreeCtl.aq_mode = 2;
    //   vcenc_inst->rateControl.rcVisualTuning = 1;

      /* PSY factor */
      if (regs->asicCfg.encPsyTuneSupport)
        vcenc_inst->psyFactor = 0.75;

      /* encoder mode decision tools tuning */
      if (regs->asicCfg.encVisualTuneSupport)
      {
      #ifdef H264_LA_INTRA_MODE_NON_4x4
        regs->H264Intramode4x4Disable = (config->pass == 1);
      #endif
      #ifdef H264_LA_INTRA_MODE_NON_8x8
        regs->H264Intramode8x8Disable = (config->pass == 1);
      #endif
      #ifdef LA_REFERENCE_USE_INPUT
        regs->RefFrameUsingInputFrameEnable = (config->pass == 1);
      #endif
      #ifdef ME_COARSE_MVCOST_QP
        regs->MeQpForLambda = ME_COARSE_MVCOST_QP;
      #endif
      #ifdef RDOQ_LAMBDA_ADJ
        vcenc_inst->bRdoqLambdaAdjust = 1;
      #endif
      #ifdef DISABLE_BI_IN_LDB
        regs->BiPredInLdbDisable = 1;
      #endif
      #ifdef BILINEAR_DOWNSAMPLE
        regs->InLoopDSBilinearEnable = (config->pass == 1);
      #endif
      #ifdef LA_HEVC_SIMPLE_RDO
        if ((config->pass == 1) && !IS_H264(config->codecFormat))
          regs->HevcSimpleRdoAssign = config->inLoopDSRatio ? 1 : 2;
      #endif
      #ifdef LA_INTRA_BY_SATD
        regs->PredModeBySatdEnable = (config->pass == 1);
      #endif
      }
      break;
    default:
      break;
  }

  regs->psyFactor = (u32)(vcenc_inst->psyFactor*(1<<PSY_FACTOR_SCALE_BITS) + 0.5);
}

/*------------------------------------------------------------------------------
  Jenc_VCEncInit initializes the encoder and creates new encoder instance.
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncInit(const VCEncConfig *config, VCEncInst *instAddr, void* ctx)
{
  /* Check for illegal inputs */
  if (config == NULL || instAddr == NULL)
  {
    APITRACEERR("Jenc_VCEncInit: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  struct instance *instance;
  const void *ewl = NULL;
  JENC_EWLInitParam_t param;
  struct vcenc_instance *vcenc_inst = NULL;
  struct container *c;
  u32 client_type;
  asicMemAlloc_s allocCfg;
  i32 parallelCoreNum = config->parallelCoreNum;
  u32 hw_id;

  regValues_s *regs;
  preProcess_s *pPP;
  struct Jenc_vps *v;
  struct Jenc_sps *s;
  struct Jenc_pps *p;
  VCEncRet ret;
  int i;
  APITRACE("Jenc_VCEncInit#");

  APITRACEPARAM("streamType", config->streamType);
  APITRACEPARAM("profile", config->profile);
  APITRACEPARAM("level", config->level);
  APITRACEPARAM("width", config->width);
  APITRACEPARAM("height", config->height);
  APITRACEPARAM("frameRateNum", config->frameRateNum);
  APITRACEPARAM("frameRateDenom", config->frameRateDenom);
  APITRACEPARAM("refFrameAmount", config->refFrameAmount);
  APITRACEPARAM("strongIntraSmoothing", config->strongIntraSmoothing);
  APITRACEPARAM("compressor", config->compressor);
  APITRACEPARAM("interlacedFrame", config->interlacedFrame);
  APITRACEPARAM("bitDepthLuma", config->bitDepthLuma);
  APITRACEPARAM("bitDepthChroma", config->bitDepthChroma);
  APITRACEPARAM("outputCuInfo", config->enableOutputCuInfo);
  APITRACEPARAM("SSIM", config->enableSsim);
  APITRACEPARAM("PSNR", config->enablePsnr);
  APITRACEPARAM("ctbRcMode", config->ctbRcMode);

  /* check that right shift on negative numbers is performed signed */
  /*lint -save -e* following check causes multiple lint messages */
#if (((-1) >> 1) != (-1))
#error Right bit-shifting (>>) does not preserve the sign
#endif
  /*lint -restore */

  if (parallelCoreNum > 1 && config->width * config->height < 256*256) {
    APITRACE("Jenc_VCEncInit: Use single core for small resolution");
    parallelCoreNum = 1;
  }

  /* Init EWL */
  param.context = ctx;
  param.clientType = VCEncGetClientType(config->codecFormat);
  param.mmuEnable = config->mmuEnable;
  param.slice_idx = config->slice_idx;
  if ((ewl = JencEWLInit(&param)) == NULL)
  {
    APITRACEERR("Jenc_VCEncInit: EWL Initialization failed");
    return VCENC_EWL_ERROR;
  }

  *instAddr = NULL;
  if (!(instance = (struct instance *)JencEWLcalloc(1, sizeof(struct instance))))
  {
    ret = VCENC_MEMORY_ERROR;
    goto error;
  }

  instance->instance = (struct vcenc_instance *)instance;
  *instAddr = (VCEncInst)instance;
  ASSERT(instance == (struct instance *)&instance->vcenc_instance);
  vcenc_inst = (struct vcenc_instance *)instance;

  vcenc_inst->asic.regs.bVCMDAvailable = JencEWLGetVCMDSupport() ? true : false;
  vcenc_inst->asic.regs.bVCMDEnable = JencEWLGetVCMDMode(ewl) ? true : false;
  if(vcenc_inst->asic.regs.bVCMDAvailable)
  {
    if (!(vcenc_inst->asic.regs.vcmdBuf = (u32 *)JencEWLcalloc(1, VCMDBUFFER_SIZE)))
    {
      ret = VCENC_MEMORY_ERROR;
      goto error;
    }
  }

  vcenc_inst->ctx = ctx;
  vcenc_inst->slice_idx = config->slice_idx;

  if (!(c = Jenc_get_container(vcenc_inst)))
  {
    ret = VCENC_MEMORY_ERROR;
    goto error;
  }

  /* Check for correct HW */
  client_type = VCEncGetClientType(config->codecFormat);
  hw_id = HW_ID_PRODUCT(JencEncAsicGetAsicHWid(client_type, ctx));
  if ((hw_id != HW_ID_PRODUCT_H2) \
    && (hw_id != HW_ID_PRODUCT_VC8000E))
  {
    if (instance != NULL)
      JencEWLfree(instance);
    if (ewl != NULL)
      (void) JencEWLRelease(ewl);
    APITRACEERR("Jenc_VCEncInit: ERROR codecFormat NOT support by HW");
    return VCENC_ERROR;
  }

  /* Check that configuration is valid */
  if (VCEncCheckCfg(config, ctx) == ENCHW_NOK)
  {
    if (instance != NULL)
      JencEWLfree(instance);
    if (ewl != NULL)
      (void) JencEWLRelease(ewl);
    APITRACEERR("Jenc_VCEncInit: ERROR Invalid configuration");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Create parameter sets */
  v = (struct Jenc_vps *)Jenc_create_parameter_set(VPS_NUT);
  s = (struct Jenc_sps *)Jenc_create_parameter_set(SPS_NUT);
  p = (struct Jenc_pps *)Jenc_create_parameter_set(PPS_NUT);

  /* Replace old parameter set with new ones */
  Jenc_remove_parameter_set(c, VPS_NUT, 0);
  Jenc_remove_parameter_set(c, SPS_NUT, 0);
  Jenc_remove_parameter_set(c, PPS_NUT, 0);

  Jenc_queue_put(&c->parameter_set, (struct node *)v);
  Jenc_queue_put(&c->parameter_set, (struct node *)s);
  Jenc_queue_put(&c->parameter_set, (struct node *)p);
  vcenc_inst->Jenc_sps = s;
  vcenc_inst->Jenc_vps = v;
  vcenc_inst->interlaced = config->interlacedFrame;
  vcenc_inst->insertNewPPS = 0;
  vcenc_inst->maxPPSId = 0;

  #ifdef RECON_REF_1KB_BURST_RW
  /*
   1KB_BURST_RW feature enabled, aligment is fixed not changable
   User must set the config correct, API internal not trick to change it
  */
  ASSERT( (config->exp_of_input_alignment == 10) && (config->exp_of_ref_alignment == 10) &&
                  (config->exp_of_ref_ch_alignment==10) && (config->compressor ==2));
  #endif

  /* Initialize ASIC */

  vcenc_inst->asic.ewl = ewl;
  (void) JencEncAsicControllerInit(&vcenc_inst->asic, ctx,param.clientType);
  JENC_EWLHwConfig_t asic_cfg;
  asic_cfg = JencEncAsicGetAsicConfig(param.clientType, ctx);

  u32 lookaheadDepth = config->lookaheadDepth;
  u32 pass = config->pass;
  if(lookaheadDepth > 0 && (asic_cfg.cuInforVersion < 1)) {
    // lookahead needs bFrame support & cuInfo version 1
    lookaheadDepth = 0;
    pass = 0;
  }

  vcenc_inst->ori_width = vcenc_inst->width = config->width;
  vcenc_inst->ori_height = vcenc_inst->height = config->height / (vcenc_inst->interlaced + 1);


  vcenc_inst->input_alignment = 1<<config->exp_of_input_alignment;
  vcenc_inst->ref_alignment = 1<<config->exp_of_ref_alignment;
  vcenc_inst->ref_ch_alignment = 1<<config->exp_of_ref_ch_alignment;
  vcenc_inst->aqInfoAlignment = 1<<config->exp_of_aqinfo_alignment;

  /* debug options */
  vcenc_inst->dumpRegister = config->dumpRegister;
  vcenc_inst->dumpCuInfo = config->dumpCuInfo;
  vcenc_inst->dumpCtbBits = config->dumpCtbBits;
  vcenc_inst->rasterscan = config->rasterscan;

  vcenc_inst->writeReconToDDR = config->writeReconToDDR;

  /* Allocate internal SW/HW shared memories */
  memset(&allocCfg, 0, sizeof (asicMemAlloc_s));
  allocCfg.width = config->width;
  allocCfg.height = config->height / (vcenc_inst->interlaced + 1);
  allocCfg.encodingType = (IS_H264(config->codecFormat)? ASIC_H264 : (IS_HEVC(config->codecFormat)? ASIC_HEVC: IS_VP9(config->codecFormat)?ASIC_VP9:ASIC_AV1));
  allocCfg.numRefBuffsLum = allocCfg.numRefBuffsChr = config->refFrameAmount + parallelCoreNum - 1;
  allocCfg.compressor = config->compressor;
  allocCfg.outputCuInfo = config->enableOutputCuInfo;
  allocCfg.outputCtbBits = config->enableOutputCtbBits && pass != 1;
  allocCfg.bitDepthLuma = config->bitDepthLuma;
  allocCfg.bitDepthChroma = config->bitDepthChroma;
  allocCfg.input_alignment = vcenc_inst->input_alignment;
  allocCfg.ref_alignment = vcenc_inst->ref_alignment;
  allocCfg.ref_ch_alignment = vcenc_inst->ref_ch_alignment;
  allocCfg.aqInfoAlignment = vcenc_inst->aqInfoAlignment;
  allocCfg.exteralReconAlloc = config->exteralReconAlloc;
  allocCfg.maxTemporalLayers = config->maxTLayers;
  allocCfg.ctbRcMode = config->ctbRcMode;
  /* IM + MAX_GOP_SIZE for pass1 */
  i32 hwCutreeBufCnt = CUTREE_BUFFER_CNT(lookaheadDepth, config->gopSize) +
                       (config->gopSize > MAX_ADAPTIVE_GOP_SIZE ? MAX_GOP_SIZE : MAX_ADAPTIVE_GOP_SIZE);
  allocCfg.numCuInfoBuf = (pass == 1 && asic_cfg.bMultiPassSupport ? hwCutreeBufCnt : 3) + parallelCoreNum - 1;
  /* not exceeding lookahead input buffer count. */
  allocCfg.numCuInfoBuf = vcenc_inst->numCuInfoBuf = MIN(allocCfg.numCuInfoBuf,LOOKAHEAD_BUFFER_CNT_WITH_REORDER(lookaheadDepth, config->gopSize));
  allocCfg.numCtbBitsBuf = parallelCoreNum;
  allocCfg.pass = pass;
  vcenc_inst->cuInfoBufIdx = 0;
  vcenc_inst->asic.regs.P010RefEnable = config->P010RefEnable;
  if (config->P010RefEnable) {
    if(config->bitDepthLuma > 8)
      allocCfg.bitDepthLuma = 16;
    if(config->bitDepthChroma > 8 && (config->compressor & 2) == 0)
      allocCfg.bitDepthChroma = 16;
  }

  vcenc_inst->compressor = config->compressor; //save these value
  vcenc_inst->maxTLayers = config->maxTLayers;
  vcenc_inst->ctbRcMode = config->ctbRcMode;
  vcenc_inst->outputCuInfo = config->enableOutputCuInfo;
  vcenc_inst->outputCtbBits = config->enableOutputCtbBits && pass != 1;
  vcenc_inst->numCtbBitsBuf = allocCfg.numCtbBitsBuf;

  // TODO,internal memory size alloc according to codedChromaIdc
  allocCfg.codedChromaIdc = (vcenc_inst->asic.regs.asicCfg.MonoChromeSupport == EWL_HW_CONFIG_NOT_SUPPORTED) ? VCENC_CHROMA_IDC_420 : config->codedChromaIdc;
#ifdef TEMPORAL_MVP_SUPPORT
  allocCfg.tmvpEnable = 1;
#else
  allocCfg.tmvpEnable = 0;
#endif
  allocCfg.is_malloc = 1;
  if (Jenc_EncAsicMemAlloc_V2(&vcenc_inst->asic, &allocCfg) != ENCHW_OK)
  {
    ret = VCENC_EWL_MEMORY_ERROR;
    goto error;
  }

  /* Set parameters depending on user config */
  if (SetParameter(vcenc_inst, config) != ENCHW_OK)
  {
    ret = VCENC_INVALID_ARGUMENT;
    goto error;
  }

  /* tuning video quality configuration */
  VideoTuneConfig(config, vcenc_inst);

  vcenc_inst->rateControl.codingType = ASIC_HEVC;
  vcenc_inst->rateControl.monitorFrames = MAX(LEAST_MONITOR_FRAME, config->frameRateNum / config->frameRateDenom);
  vcenc_inst->rateControl.picRc = ENCHW_NO;
  vcenc_inst->rateControl.picSkip = ENCHW_NO;
  vcenc_inst->rateControl.qpHdr = -1<<QP_FRACTIONAL_BITS;
  vcenc_inst->rateControl.ctbRcQpDeltaReverse = 0;
  vcenc_inst->rateControl.qpMin = vcenc_inst->rateControl.qpMinI = vcenc_inst->rateControl.qpMinPB = 0<<QP_FRACTIONAL_BITS;
  vcenc_inst->rateControl.qpMax = vcenc_inst->rateControl.qpMaxI = vcenc_inst->rateControl.qpMaxPB = 51<<QP_FRACTIONAL_BITS;
  vcenc_inst->rateControl.hrd = ENCHW_NO;
  vcenc_inst->rateControl.virtualBuffer.bitRate = 1000000;
  vcenc_inst->rateControl.virtualBuffer.bufferSize = 0;
  vcenc_inst->rateControl.bitrateWindow = 150;
  vcenc_inst->rateControl.vbr = ENCHW_NO;
  vcenc_inst->rateControl.crf = -1;
  vcenc_inst->rateControl.pbOffset = 6.0 * 0.378512;
  vcenc_inst->rateControl.ipOffset = 6.0 * 0.485427;

  vcenc_inst->rateControl.intraQpDelta = INTRA_QPDELTA_DEFAULT << QP_FRACTIONAL_BITS;
  vcenc_inst->rateControl.fixedIntraQp = 0 << QP_FRACTIONAL_BITS;
  vcenc_inst->rateControl.tolMovingBitRate = 2000;
  vcenc_inst->rateControl.tolCtbRcInter = 0.0;
  vcenc_inst->rateControl.tolCtbRcIntra = -1.0;
  vcenc_inst->rateControl.longTermQpDelta = 0;
  vcenc_inst->rateControl.f_tolMovingBitRate = 2000.0;
  vcenc_inst->rateControl.smooth_psnr_in_gop = 0;

  vcenc_inst->rateControl.maxPicSizeI = MIN( (((i64)Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum))*(1 + 20)),I32_MAX);
  vcenc_inst->rateControl.maxPicSizeP = MIN( (((i64)Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum))*(1 + 20)),I32_MAX);
  vcenc_inst->rateControl.maxPicSizeB = MIN( (((i64)Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum))*(1 + 20)),I32_MAX);

  vcenc_inst->rateControl.minPicSizeI = Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum)/(1+20) ;
  vcenc_inst->rateControl.minPicSizeP = Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum)/(1+20) ;
  vcenc_inst->rateControl.minPicSizeB = Jenc_rcCalculate(vcenc_inst->rateControl.virtualBuffer.bitRate, vcenc_inst->rateControl.outRateDenom, vcenc_inst->rateControl.outRateNum)/(1+20) ;
  vcenc_inst->blockRCSize = 0;
  vcenc_inst->rateControl.rcQpDeltaRange = 10;
  vcenc_inst->rateControl.rcBaseMBComplexity = 15;
  vcenc_inst->rateControl.picQpDeltaMin = -2;
  vcenc_inst->rateControl.picQpDeltaMax = 3;
  for (i = 0; i < 3; i ++)
  {
    vcenc_inst->rateControl.ctbRateCtrl.models[i].ctbMemPreAddr        = vcenc_inst->asic.ctbRcMem[i].busAddress;
    vcenc_inst->rateControl.ctbRateCtrl.models[i].ctbMemPreVirtualAddr = vcenc_inst->asic.ctbRcMem[i].virtualAddress;
  }
  vcenc_inst->rateControl.ctbRateCtrl.ctbMemCurAddr        = vcenc_inst->asic.ctbRcMem[3].busAddress;
  vcenc_inst->rateControl.ctbRateCtrl.ctbMemCurVirtualAddr = vcenc_inst->asic.ctbRcMem[3].virtualAddress;

  // ctbRc for rate purpose
  if (IS_CTBRC_FOR_BITRATE(allocCfg.ctbRcMode))
  {
    i32 rowQpStep = 4;    //IS_H264(vcenc_inst->codecFormat)  ? 4 : 16;
    vcenc_inst->rateControl.ctbRateCtrl.qpStep =
        ((rowQpStep << CTB_RC_QP_STEP_FIXP) + vcenc_inst->rateControl.ctbCols/2) / vcenc_inst->rateControl.ctbCols;
  }
  vcenc_inst->rateControl.pass = vcenc_inst->pass = pass;
  Jenc_multipass_enabled = (pass > 0);

  if (JencVCEncInitRc(&vcenc_inst->rateControl, 1) != ENCHW_OK)
  {
    ret = VCENC_INVALID_ARGUMENT;
    goto error;
  }

  vcenc_inst->rateControl.sei.enabled = ENCHW_NO;
  vcenc_inst->Jenc_sps->vui.vuiVideoFullRange = ENCHW_NO;
  vcenc_inst->disableDeblocking = 0;
  vcenc_inst->tc_Offset = 0;
  vcenc_inst->beta_Offset = 0;
  vcenc_inst->enableSao = 1;
  vcenc_inst->enableScalingList = 0;
  vcenc_inst->sarWidth = 0;
  vcenc_inst->sarHeight = 0;

  vcenc_inst->max_cu_size = 64;   /* Max coding unit size in pixels */
  vcenc_inst->min_cu_size = 8;   /* Min coding unit size in pixels */
  vcenc_inst->max_tr_size = 16;   /* Max transform size in pixels */ /*Default max 16, assume no TU32 support*/
  vcenc_inst->min_tr_size = 4;   /* Min transform size in pixels */

  VCEncHEVCDnfInit(vcenc_inst);

  vcenc_inst->tr_depth_intra = 2;   /* Max transform hierarchy depth */
  vcenc_inst->tr_depth_inter = (vcenc_inst->max_cu_size == 64) ? 4 : 3;   /* Max transform hierarchy depth */
  vcenc_inst->codecFormat = config->codecFormat;
  if(IS_H264(vcenc_inst->codecFormat) ) {
    vcenc_inst->max_cu_size = 16;   /* Max coding unit size in pixels */
    vcenc_inst->min_cu_size = 8;   /* Min coding unit size in pixels */
    vcenc_inst->max_tr_size = 16;   /* Max transform size in pixels */
    vcenc_inst->min_tr_size = 4;   /* Min transform size in pixels */
    vcenc_inst->tr_depth_intra = 1;   /* Max transform hierarchy depth */
    vcenc_inst->tr_depth_inter = 2;   /* Max transform hierarchy depth */
  }

  vcenc_inst->fieldOrder = 0;
  vcenc_inst->chromaQpOffset = 0;
  vcenc_inst->rateControl.sei.insertRecoveryPointMessage = 0;
  vcenc_inst->rateControl.sei.recoveryFrameCnt = 0;
  vcenc_inst->min_qp_size = vcenc_inst->max_cu_size;

  /* low latency */
  vcenc_inst->inputLineBuf.inputLineBufDepth = 1;

  /* smart */
  vcenc_inst->smartModeEnable = 0;
  vcenc_inst->smartH264LumDcTh = 5;
  vcenc_inst->smartH264CbDcTh = 1;
  vcenc_inst->smartH264CrDcTh = 1;
  vcenc_inst->smartHevcLumDcTh[0] = 2;
  vcenc_inst->smartHevcLumDcTh[1] = 2;
  vcenc_inst->smartHevcLumDcTh[2] = 2;
  vcenc_inst->smartHevcChrDcTh[0] = 2;
  vcenc_inst->smartHevcChrDcTh[1] = 2;
  vcenc_inst->smartHevcChrDcTh[2] = 2;
  vcenc_inst->smartHevcLumAcNumTh[0] = 12;
  vcenc_inst->smartHevcLumAcNumTh[1] = 51;
  vcenc_inst->smartHevcLumAcNumTh[2] = 204;
  vcenc_inst->smartHevcChrAcNumTh[0] = 3;
  vcenc_inst->smartHevcChrAcNumTh[1] = 12;
  vcenc_inst->smartHevcChrAcNumTh[2] = 51;
  vcenc_inst->smartH264Qp = 30;
  vcenc_inst->smartHevcLumQp = 30;
  vcenc_inst->smartHevcChrQp = 30;
  vcenc_inst->smartMeanTh[0] = 5;
  vcenc_inst->smartMeanTh[1] = 5;
  vcenc_inst->smartMeanTh[2] = 5;
  vcenc_inst->smartMeanTh[3] = 5;
  vcenc_inst->smartPixNumCntTh = 0;

  vcenc_inst->verbose = config->verbose;

  vcenc_inst->tiles_enabled_flag = 0;
  vcenc_inst->num_tile_columns = 1;
  vcenc_inst->num_tile_rows = 1;
  vcenc_inst->loop_filter_across_tiles_enabled_flag =1;

  regs = &vcenc_inst->asic.regs;

  regs->CyclesDdrPollingCheck = 0;
  regs->cabac_init_flag = 0;
  regs->entropy_coding_mode_flag = 1;
  regs->cirStart = 0;
  regs->cirInterval = 0;
  regs->intraAreaTop = regs->intraAreaLeft =
                         regs->intraAreaBottom = regs->intraAreaRight = INVALID_POS;

  regs->ipcm1AreaTop = regs->ipcm1AreaLeft =
                         regs->ipcm1AreaBottom = regs->ipcm1AreaRight = INVALID_POS;
  regs->ipcm2AreaTop = regs->ipcm2AreaLeft =
                         regs->ipcm2AreaBottom = regs->ipcm2AreaRight = INVALID_POS;
  regs->ipcm3AreaTop = regs->ipcm3AreaLeft =
                         regs->ipcm3AreaBottom = regs->ipcm3AreaRight = INVALID_POS;
  regs->ipcm4AreaTop = regs->ipcm4AreaLeft =
                         regs->ipcm4AreaBottom = regs->ipcm4AreaRight = INVALID_POS;
  regs->ipcm5AreaTop = regs->ipcm5AreaLeft =
                         regs->ipcm5AreaBottom = regs->ipcm5AreaRight = INVALID_POS;
  regs->ipcm6AreaTop = regs->ipcm6AreaLeft =
                         regs->ipcm6AreaBottom = regs->ipcm6AreaRight = INVALID_POS;
  regs->ipcm7AreaTop = regs->ipcm7AreaLeft =
                         regs->ipcm7AreaBottom = regs->ipcm7AreaRight = INVALID_POS;
  regs->ipcm8AreaTop = regs->ipcm8AreaLeft =
                         regs->ipcm8AreaBottom = regs->ipcm8AreaRight = INVALID_POS;

  regs->roi1Top = regs->roi1Left =
                    regs->roi1Bottom = regs->roi1Right = INVALID_POS;
  vcenc_inst->roi1Enable = 0;

  regs->roi2Top = regs->roi2Left =
                    regs->roi2Bottom = regs->roi2Right = INVALID_POS;
  vcenc_inst->roi2Enable = 0;

  regs->roi3Top = regs->roi3Left =
                    regs->roi3Bottom = regs->roi3Right = INVALID_POS;
  vcenc_inst->roi3Enable = 0;

  regs->roi4Top = regs->roi4Left =
                    regs->roi4Bottom = regs->roi4Right = INVALID_POS;
  vcenc_inst->roi4Enable = 0;

  regs->roi5Top = regs->roi5Left =
                    regs->roi5Bottom = regs->roi5Right = INVALID_POS;
  vcenc_inst->roi5Enable = 0;

  regs->roi6Top = regs->roi6Left =
                    regs->roi6Bottom = regs->roi6Right = INVALID_POS;
  vcenc_inst->roi6Enable = 0;

  regs->roi7Top = regs->roi7Left =
                    regs->roi7Bottom = regs->roi7Right = INVALID_POS;
  vcenc_inst->roi7Enable = 0;


  regs->roi8Top = regs->roi8Left =
                    regs->roi8Bottom = regs->roi8Right = INVALID_POS;
  vcenc_inst->roi8Enable = 0;

  regs->roi1DeltaQp = 0;
  regs->roi2DeltaQp = 0;
  regs->roi3DeltaQp = 0;
  regs->roi4DeltaQp = 0;
  regs->roi5DeltaQp = 0;
  regs->roi6DeltaQp = 0;
  regs->roi7DeltaQp = 0;
  regs->roi8DeltaQp = 0;
  regs->roi1Qp = -1;
  regs->roi2Qp = -1;
  regs->roi3Qp = -1;
  regs->roi4Qp = -1;
  regs->roi5Qp = -1;
  regs->roi6Qp = -1;
  regs->roi7Qp = -1;
  regs->roi8Qp = -1;

  /* currently HW SSIM calculation is not supported for AV1 */
  regs->ssim = config->enableSsim;
  if (regs->ssim)
  {
    if (!regs->asicCfg.ssimSupport)
    {
      APITRACEERR("Jenc_VCEncInit: WARNING SSIM calculation not supported by HW, force it disable");
      regs->ssim = 0;
    }
    else if (IS_AV1(config->codecFormat))
    {
      APITRACEERR("Jenc_VCEncInit: WARNING SSIM calculation not supported for AV1, force it disable");
      regs->ssim = 0;
    }
  }

  /*configure enablePsnr*/
  regs->psnr = config->enablePsnr;
  if (regs->psnr)
  {
    if (!regs->asicCfg.psnrSupport)
    {
      APITRACEERR("Jenc_VCEncInit: WARNING PSNR calculation not supported by HW, force it disable");
      regs->psnr = 0;
    }
    else if (IS_AV1(config->codecFormat))
    {
      APITRACEERR("Jenc_VCEncInit: WARNING PSNR calculation not supported for AV1, force it disable");
      regs->psnr = 0;
    }
  }

  regs->totalCmdbufSize = 0;

  /* External line buffer settings */
  regs->sram_linecnt_lum_fwd = config->extSramLumHeightFwd;
  regs->sram_linecnt_lum_bwd = config->extSramLumHeightBwd;
  regs->sram_linecnt_chr_fwd = config->extSramChrHeightFwd;
  regs->sram_linecnt_chr_bwd = config->extSramChrHeightBwd;

  /*AXI max burst length */
  if (0 == config->burstMaxLength)
    regs->AXI_burst_max_length = ENCH2_DEFAULT_BURST_LENGTH; //default
  else
    regs->AXI_burst_max_length = config->burstMaxLength;

  /* AXI alignment */
  regs->AXI_burst_align_wr_common = (config->AXIAlignment >> 28) & 0xf;
  regs->AXI_burst_align_wr_stream = (config->AXIAlignment >> 24) & 0xf;
  regs->AXI_burst_align_wr_chroma_ref = (config->AXIAlignment >> 20) & 0xf;
  regs->AXI_burst_align_wr_luma_ref = (config->AXIAlignment >> 16) & 0xf;
  regs->AXI_burst_align_rd_common = (config->AXIAlignment >> 12) & 0xf;
  regs->AXI_burst_align_rd_prp = (config->AXIAlignment >> 8) & 0xf;
  regs->AXI_burst_align_rd_ch_ref_prefetch = (config->AXIAlignment >> 4) & 0xf;
  regs->AXI_burst_align_rd_lu_ref_prefetch = (config->AXIAlignment) & 0xf;

  /* Check AXI alignment */
  if(asic_cfg.AXIAlignFuse == 0 && config->AXIAlignment !=0)
  {
    APITRACEERR("Jenc_VCEncInit: Jenc_Error, configured AXI is not supported by hardware");
    return VCENC_INVALID_ARGUMENT;
  }
  else
  {
    if((((asic_cfg.AXIAlignFuse >> 28) & 0xf) < regs->AXI_burst_align_wr_common) ||
       (((asic_cfg.AXIAlignFuse >> 24) & 0xf) < regs->AXI_burst_align_wr_stream) ||
       (((asic_cfg.AXIAlignFuse >> 20) & 0xf) < regs->AXI_burst_align_wr_chroma_ref) ||
       (((asic_cfg.AXIAlignFuse >> 16) & 0xf) < regs->AXI_burst_align_wr_luma_ref) ||
       (((asic_cfg.AXIAlignFuse >> 12) & 0xf) < regs->AXI_burst_align_rd_common) ||
       (((asic_cfg.AXIAlignFuse >> 8)  & 0xf) < regs->AXI_burst_align_rd_prp) ||
       (((asic_cfg.AXIAlignFuse >> 4)  & 0xf) < regs->AXI_burst_align_rd_ch_ref_prefetch) ||
       ((asic_cfg.AXIAlignFuse         & 0xf) < regs->AXI_burst_align_rd_lu_ref_prefetch))
    {
      APITRACEERR("Jenc_VCEncInit: Jenc_Error, configured AXI is not supported by hardware");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  vcenc_inst->pcm_enabled_flag = 0;
  vcenc_inst->pcm_loop_filter_disabled_flag = 0;

  vcenc_inst->roiMapEnable = 0;
  vcenc_inst->RoimapCuCtrl_index_enable = 0;
  vcenc_inst->RoimapCuCtrl_enable       = 0;
  vcenc_inst->roiMapDeltaQpEnable       = 0;
  vcenc_inst->roiMapDeltaQpBinEnable    = 0;
  vcenc_inst->RoimapCuCtrl_ver = 0;
  vcenc_inst->RoiQpDelta_ver = 0;
  vcenc_inst->ctbRCEnable = 0;
  regs->rcRoiEnable = 0x00;
  regs->diffCuQpDeltaDepth = 0;
  /* Status == INIT   Initialization succesful */
  vcenc_inst->encStatus = VCENCSTAT_INIT;
  vcenc_inst->created_pic_num = 0;

  pPP = &(vcenc_inst->preProcess);
  pPP->constChromaEn = 0;
  pPP->constCb = pPP->constCr = 0x80 << (config->bitDepthChroma-8);
  /* HDR10 */
  vcenc_inst->Hdr10Display.hdr10_display_enable = 0;
  vcenc_inst->Hdr10Display.hdr10_dx0 = 0;
  vcenc_inst->Hdr10Display.hdr10_dy0 = 0;
  vcenc_inst->Hdr10Display.hdr10_dx1 = 0;
  vcenc_inst->Hdr10Display.hdr10_dy1 = 0;
  vcenc_inst->Hdr10Display.hdr10_dx2 = 0;
  vcenc_inst->Hdr10Display.hdr10_dy2 = 0;
  vcenc_inst->Hdr10Display.hdr10_wx = 0;
  vcenc_inst->Hdr10Display.hdr10_wy = 0;
  vcenc_inst->Hdr10Display.hdr10_maxluma = 0;
  vcenc_inst->Hdr10Display.hdr10_minluma = 0;

  vcenc_inst->vuiColorDescription.vuiColorDescripPresentFlag     = 0;
  vcenc_inst->vuiColorDescription.vuiColorPrimaries              = 9;
  vcenc_inst->vuiColorDescription.vuiTransferCharacteristics     = 0;
  vcenc_inst->vuiColorDescription.vuiMatrixCoefficients          = 9;

  vcenc_inst->sarHeight                                          = 0;
  vcenc_inst->sarWidth                                           = 0;

  vcenc_inst->vuiVideoFormat                = 5;
  vcenc_inst->vuiVideoSignalTypePresentFlag = 0;

  vcenc_inst->Hdr10LightLevel.hdr10_lightlevel_enable = 0;
  vcenc_inst->Hdr10LightLevel.hdr10_maxlight = 0;
  vcenc_inst->Hdr10LightLevel.hdr10_avglight = 0;

  vcenc_inst->RpsInSliceHeader = 0;

  /* Multi-core */
  vcenc_inst->parallelCoreNum = parallelCoreNum;
  vcenc_inst->reservedCore =0;

  /* RDOQ. enable RDOQ by default if HW supported */
  if ((vcenc_inst->pass != 1) && (config->tune != VCENC_TUNE_SHARP_VISUAL))
  {
    regs->bRDOQEnable = (IS_H264(config->codecFormat) && regs->asicCfg.RDOQSupportH264)  ||
                        (IS_AV1(config->codecFormat)  && regs->asicCfg.RDOQSupportAV1)   ||
                        (IS_HEVC(config->codecFormat) && regs->asicCfg.RDOQSupportHEVC)  ||
                        (IS_VP9(config->codecFormat)  && regs->asicCfg.RDOQSupportVP9);
  }

  /* Multi-pass */
  vcenc_inst->lookaheadDepth = lookaheadDepth;
  vcenc_inst->bSkipCabacEnable = 0;
  vcenc_inst->bMotionScoreEnable = 0;
  vcenc_inst->extDSRatio = config->extDSRatio;
  vcenc_inst->ctx = ctx;
  vcenc_inst->slice_idx = config->slice_idx;

  vcenc_inst->bInputfileList = config->fileListExist;

  if (vcenc_inst->pass == 1)
  {
    vcenc_inst->inLoopDSRatio = config->inLoopDSRatio;
    ret = Jenc_cuTreeInit(&vcenc_inst->cuTreeCtl, vcenc_inst, config);
    if (ret != VCENC_OK)
    {
      APITRACE("Jenc_VCEncInit: Jenc_cuTreeInit failed");
      goto error;
    }

    /* skip CABAC engine for better througput in first pass */
    vcenc_inst->bSkipCabacEnable = regs->asicCfg.bMultiPassSupport;
    /* enable motion score computing for agop decision in first pass */
    vcenc_inst->bMotionScoreEnable = regs->asicCfg.bMultiPassSupport;
  }
  else if (vcenc_inst->pass == 2)
  {
    VCEncConfig new_cfg;
    u32 inLoopDsRatio;

    memcpy(&new_cfg, config, sizeof(VCEncConfig));

    /*config pass 1 encoder cfg*/
    new_cfg.pass = 1;
    new_cfg.lookaheadDepth = lookaheadDepth;
    new_cfg.enableOutputCuInfo = 1;

    /*pass-1 cutree downscaler config */
    inLoopDsRatio = config->inLoopDSRatio + 1;
    if(config->tune == VCENC_TUNE_SHARP_VISUAL)
    {
      inLoopDsRatio = 1;
      APITRACE("Jenc_VCEncInit: For --tune=sharpness_visual, set inLoopDSRatio to 0 forcibly");
    }
    if(regs->asicCfg.inLoopDSRatio == 0)
      inLoopDsRatio = 1;

    if(vcenc_inst->extDSRatio)
      inLoopDsRatio = vcenc_inst->extDSRatio + 1;

    new_cfg.inLoopDSRatio = inLoopDsRatio - 1;
    new_cfg.width /= inLoopDsRatio;
    new_cfg.height /= inLoopDsRatio;
    new_cfg.width = ( new_cfg.width >> 1)<< 1;
    new_cfg.height = ( new_cfg.height >> 1)<< 1;

    new_cfg.exteralReconAlloc = 0;//this should alloc internarlly when in the first pass.

    ret = Jenc_VCEncInit(&new_cfg, &vcenc_inst->lookahead.priv_inst, ctx);
    if (ret != VCENC_OK)
    {
      vcenc_inst->lookahead.priv_inst = NULL;
      APITRACE("Jenc_VCEncInit: LookaheadInit failed");
      goto error;
    }
  }

  /* AV1 or VP9 specific params init */
#ifdef SUPPORT_AV1
  if(IS_AV1(config->codecFormat))
    VCEncInitAV1(config, vcenc_inst);
#endif

#ifdef SUPPORT_VP9
  if(IS_VP9(config->codecFormat))
    VCEncInitVP9(config, vcenc_inst);
#endif

  vcenc_inst->asic.regs.bInitUpdate = 1;
  vcenc_inst->inst = vcenc_inst;
  APITRACE("Jenc_VCEncInit: OK");
  return VCENC_OK;

error:

  APITRACEERR("Jenc_VCEncInit: ERROR Initialization failed");

  //release all resource(instance/ewl/memory/ewl_mem) if vcenc_inst created but error happen
  if(vcenc_inst != NULL)
  {
      vcenc_inst->inst = vcenc_inst;
      Jenc_VCEncRelease(vcenc_inst);
      vcenc_inst = NULL;
      return ret;
  }
  //release ewl resource if vcenc_inst not created yet
  if (instance != NULL)
    JencEWLfree(instance);
  if (ewl != NULL)
    (void) JencEWLRelease(ewl);

  return ret;

}

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncRelease
    Description   : Releases encoder instance and all associated resource

    Return type   : VCEncRet
    Argument      : inst - the instance to be released
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncRelease(VCEncInst inst)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) inst;
  struct container *c;
  VCEncRet ret = VCENC_OK;

  APITRACE("Jenc_VCEncRelease#");

  /* Check for illegal inputs */
  if (pEncInst == NULL)
  {
    APITRACEERR("Jenc_VCEncRelease: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (pEncInst->inst != inst)
  {
    APITRACEERR("Jenc_VCEncRelease: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  if(pEncInst->pass == 2 && pEncInst->lookahead.priv_inst)
  {
    struct vcenc_instance *pEncInst_priv = (struct vcenc_instance *) pEncInst->lookahead.priv_inst;

    /* Terminate lookahead thread first, put correct status */
    ret = Jenc_TerminateLookaheadThread(&pEncInst->lookahead, pEncInst->encStatus == VCENCSTAT_ERROR);

    ret = Jenc_TerminateCuTreeThread(&pEncInst_priv->cuTreeCtl, pEncInst->encStatus == VCENCSTAT_ERROR);

    DestroyThread(&pEncInst->lookahead, &(pEncInst_priv->cuTreeCtl));

    if(pEncInst_priv->lookahead.internal_mem.mem.virtualAddress)
      JencEWLFreeLinear(pEncInst_priv->asic.ewl,  &(pEncInst_priv->lookahead.internal_mem.mem));


    /* Release pass 1 instance */
    if ((c = Jenc_get_container(pEncInst_priv)))
    {
      Jenc_sw_free_pictures(c);  /* Call this before Jenc_free_parameter_sets() */
      Jenc_free_parameter_sets(c);
      Jenc_VCEncShutdown((struct instance *)pEncInst_priv);
    }
    else
      ret = VCENC_ERROR;

    pEncInst_priv = NULL;

    if ((c = Jenc_get_container(pEncInst)))
    {
      Jenc_sw_free_pictures(c);  /* Call this before Jenc_free_parameter_sets() */
      Jenc_free_parameter_sets(c);
      Jenc_VCEncShutdown((struct instance *)pEncInst);
    }
    else
      ret = VCENC_ERROR;
  }else if(pEncInst->pass != 1)
  {
    if ((c = Jenc_get_container(pEncInst)))
    {
      Jenc_sw_free_pictures(c);  /* Call this before Jenc_free_parameter_sets() */
      Jenc_free_parameter_sets(c);
      Jenc_VCEncShutdown((struct instance *)pEncInst);
    }
    else
      ret = VCENC_ERROR;
  }

  JencEwlReleaseCoreWait(NULL);
  pEncInst = NULL;

  if(ret >= VCENC_OK)
  {
    APITRACE("Jenc_VCEncRelease: OK");
  }
  else
  {
    APITRACE("Jenc_VCEncRelease: NOK");
  }

  return ret;
}

/*------------------------------------------------------------------------------

    Jenc_VCEncGetPerformance

    Function frees the encoder instance.

    Input   inst    Pointer to the encoder instance to be freed.
                            After this the pointer is no longer valid.

------------------------------------------------------------------------------*/
u32 Jenc_VCEncGetPerformance(VCEncInst inst)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) inst;
  const void *ewl;
  u32 performanceData;
  ASSERT(inst);
  APITRACE("Jenc_VCEncGetPerformance#");
  /* Check for illegal inputs */
  if (pEncInst == NULL)
  {
    APITRACEERR("Jenc_VCEncGetPerformance: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (pEncInst->inst != inst)
  {
    APITRACEERR("Jenc_VCEncGetPerformance: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  ewl = pEncInst->asic.ewl;
  performanceData = JencEncAsicGetPerformance(ewl);
  APITRACE("Jenc_VCEncGetPerformance:OK");
  return performanceData;
}

/*------------------------------------------------------------------------------
  Jenc_get_container
------------------------------------------------------------------------------*/
struct container *Jenc_get_container(struct vcenc_instance *vcenc_instance)
{
  struct instance *instance = (struct instance *)vcenc_instance;

  if (!instance || (instance->instance != vcenc_instance)) return NULL;

  return &instance->container;
}


/*------------------------------------------------------------------------------
  Jenc_VCEncSetCodingCtrl
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncSetCodingCtrl(VCEncInst instAddr, const VCEncCodingCtrl *pCodeParams)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) instAddr;
  /* Check for illegal inputs */
  if ((pEncInst == NULL) || (pCodeParams == NULL))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  regValues_s *regs = &pEncInst->asic.regs;
  u32 i;
  u32 client_type;
  JENC_EWLHwConfig_t cfg;
  bool  bAdvanceHW;
  APITRACE("Jenc_VCEncSetCodingCtrl#");
  APITRACEPARAM("sliceSize", pCodeParams->sliceSize);
  APITRACEPARAM("seiMessages", pCodeParams->seiMessages);
  APITRACEPARAM("vuiVideoFullRange", pCodeParams->vuiVideoFullRange);
  APITRACEPARAM("disableDeblockingFilter", pCodeParams->disableDeblockingFilter);
  APITRACEPARAM("tc_Offset", pCodeParams->tc_Offset);
  APITRACEPARAM("beta_Offset", pCodeParams->beta_Offset);
  APITRACEPARAM("enableDeblockOverride", pCodeParams->enableDeblockOverride);
  APITRACEPARAM("deblockOverride", pCodeParams->deblockOverride);
  APITRACEPARAM("enableSao", pCodeParams->enableSao);
  APITRACEPARAM("enableScalingList", pCodeParams->enableScalingList);
  APITRACEPARAM("sampleAspectRatioWidth", pCodeParams->sampleAspectRatioWidth);
  APITRACEPARAM("sampleAspectRatioHeight", pCodeParams->sampleAspectRatioHeight);
  APITRACEPARAM("enableCabac", pCodeParams->enableCabac);
  APITRACEPARAM("cabacInitFlag", pCodeParams->cabacInitFlag);
  APITRACEPARAM("cirStart", pCodeParams->cirStart);
  APITRACEPARAM("cirInterval", pCodeParams->cirInterval);
  APITRACEPARAM("intraArea.enable", pCodeParams->intraArea.enable);
  APITRACEPARAM("intraArea.top", pCodeParams->intraArea.top);
  APITRACEPARAM("intraArea.bottom", pCodeParams->intraArea.bottom);
  APITRACEPARAM("intraArea.left", pCodeParams->intraArea.left);
  APITRACEPARAM("intraArea.right", pCodeParams->intraArea.right);
  APITRACEPARAM("ipcm1Area.enable", pCodeParams->ipcm1Area.enable);
  APITRACEPARAM("ipcm1Area.top", pCodeParams->ipcm1Area.top);
  APITRACEPARAM("ipcm1Area.bottom", pCodeParams->ipcm1Area.bottom);
  APITRACEPARAM("ipcm1Area.left", pCodeParams->ipcm1Area.left);
  APITRACEPARAM("ipcm1Area.right", pCodeParams->ipcm1Area.right);
  APITRACEPARAM("ipcm2Area.enable", pCodeParams->ipcm2Area.enable);
  APITRACEPARAM("ipcm2Area.top", pCodeParams->ipcm2Area.top);
  APITRACEPARAM("ipcm2Area.bottom", pCodeParams->ipcm2Area.bottom);
  APITRACEPARAM("ipcm2Area.left", pCodeParams->ipcm2Area.left);
  APITRACEPARAM("ipcm2Area.right", pCodeParams->ipcm2Area.right);
  APITRACEPARAM("ipcm3Area.enable", pCodeParams->ipcm3Area.enable);
  APITRACEPARAM("ipcm3Area.top", pCodeParams->ipcm3Area.top);
  APITRACEPARAM("ipcm3Area.bottom", pCodeParams->ipcm3Area.bottom);
  APITRACEPARAM("ipcm3Area.left", pCodeParams->ipcm3Area.left);
  APITRACEPARAM("ipcm3Area.right", pCodeParams->ipcm3Area.right);
  APITRACEPARAM("ipcm4Area.enable", pCodeParams->ipcm4Area.enable);
  APITRACEPARAM("ipcm4Area.top", pCodeParams->ipcm4Area.top);
  APITRACEPARAM("ipcm4Area.bottom", pCodeParams->ipcm4Area.bottom);
  APITRACEPARAM("ipcm4Area.left", pCodeParams->ipcm4Area.left);
  APITRACEPARAM("ipcm4Area.right", pCodeParams->ipcm4Area.right);
  APITRACEPARAM("ipcm5Area.enable", pCodeParams->ipcm5Area.enable);
  APITRACEPARAM("ipcm5Area.top", pCodeParams->ipcm5Area.top);
  APITRACEPARAM("ipcm5Area.bottom", pCodeParams->ipcm5Area.bottom);
  APITRACEPARAM("ipcm5Area.left", pCodeParams->ipcm5Area.left);
  APITRACEPARAM("ipcm5Area.right", pCodeParams->ipcm5Area.right);
  APITRACEPARAM("ipcm6Area.enable", pCodeParams->ipcm6Area.enable);
  APITRACEPARAM("ipcm6Area.top", pCodeParams->ipcm6Area.top);
  APITRACEPARAM("ipcm6Area.bottom", pCodeParams->ipcm6Area.bottom);
  APITRACEPARAM("ipcm6Area.left", pCodeParams->ipcm6Area.left);
  APITRACEPARAM("ipcm6Area.right", pCodeParams->ipcm6Area.right);
  APITRACEPARAM("ipcm7Area.enable", pCodeParams->ipcm7Area.enable);
  APITRACEPARAM("ipcm7Area.top", pCodeParams->ipcm7Area.top);
  APITRACEPARAM("ipcm7Area.bottom", pCodeParams->ipcm7Area.bottom);
  APITRACEPARAM("ipcm7Area.left", pCodeParams->ipcm7Area.left);
  APITRACEPARAM("ipcm7Area.right", pCodeParams->ipcm7Area.right);
  APITRACEPARAM("ipcm8Area.enable", pCodeParams->ipcm8Area.enable);
  APITRACEPARAM("ipcm8Area.top", pCodeParams->ipcm8Area.top);
  APITRACEPARAM("ipcm8Area.bottom", pCodeParams->ipcm8Area.bottom);
  APITRACEPARAM("ipcm8Area.left", pCodeParams->ipcm8Area.left);
  APITRACEPARAM("ipcm8Area.right", pCodeParams->ipcm8Area.right);
  APITRACEPARAM("roi1Area.enable", pCodeParams->roi1Area.enable);
  APITRACEPARAM("roi1Area.top", pCodeParams->roi1Area.top);
  APITRACEPARAM("roi1Area.bottom", pCodeParams->roi1Area.bottom);
  APITRACEPARAM("roi1Area.left", pCodeParams->roi1Area.left);
  APITRACEPARAM("roi1Area.right", pCodeParams->roi1Area.right);
  APITRACEPARAM("roi2Area.enable", pCodeParams->roi2Area.enable);
  APITRACEPARAM("roi2Area.top", pCodeParams->roi2Area.top);
  APITRACEPARAM("roi2Area.bottom", pCodeParams->roi2Area.bottom);
  APITRACEPARAM("roi2Area.left", pCodeParams->roi2Area.left);
  APITRACEPARAM("roi2Area.right", pCodeParams->roi2Area.right);
  APITRACEPARAM("roi3Area.enable", pCodeParams->roi3Area.enable);
  APITRACEPARAM("roi3Area.top", pCodeParams->roi3Area.top);
  APITRACEPARAM("roi3Area.bottom", pCodeParams->roi3Area.bottom);
  APITRACEPARAM("roi3Area.left", pCodeParams->roi3Area.left);
  APITRACEPARAM("roi3Area.right", pCodeParams->roi3Area.right);
  APITRACEPARAM("roi4Area.enable", pCodeParams->roi4Area.enable);
  APITRACEPARAM("roi4Area.top", pCodeParams->roi4Area.top);
  APITRACEPARAM("roi4Area.bottom", pCodeParams->roi4Area.bottom);
  APITRACEPARAM("roi4Area.left", pCodeParams->roi4Area.left);
  APITRACEPARAM("roi4Area.right", pCodeParams->roi4Area.right);
  APITRACEPARAM("roi5Area.enable", pCodeParams->roi5Area.enable);
  APITRACEPARAM("roi5Area.top", pCodeParams->roi5Area.top);
  APITRACEPARAM("roi5Area.bottom", pCodeParams->roi5Area.bottom);
  APITRACEPARAM("roi5Area.left", pCodeParams->roi5Area.left);
  APITRACEPARAM("roi5Area.right", pCodeParams->roi5Area.right);
  APITRACEPARAM("roi6Area.enable", pCodeParams->roi6Area.enable);
  APITRACEPARAM("roi6Area.top", pCodeParams->roi6Area.top);
  APITRACEPARAM("roi6Area.bottom", pCodeParams->roi6Area.bottom);
  APITRACEPARAM("roi6Area.left", pCodeParams->roi6Area.left);
  APITRACEPARAM("roi6Area.right", pCodeParams->roi6Area.right);
  APITRACEPARAM("roi7Area.enable", pCodeParams->roi7Area.enable);
  APITRACEPARAM("roi7Area.top", pCodeParams->roi7Area.top);
  APITRACEPARAM("roi7Area.bottom", pCodeParams->roi7Area.bottom);
  APITRACEPARAM("roi7Area.left", pCodeParams->roi7Area.left);
  APITRACEPARAM("roi7Area.right", pCodeParams->roi7Area.right);
  APITRACEPARAM("roi8Area.enable", pCodeParams->roi8Area.enable);
  APITRACEPARAM("roi8Area.top", pCodeParams->roi8Area.top);
  APITRACEPARAM("roi8Area.bottom", pCodeParams->roi8Area.bottom);
  APITRACEPARAM("roi8Area.left", pCodeParams->roi8Area.left);
  APITRACEPARAM("roi8Area.right", pCodeParams->roi8Area.right);
  APITRACEPARAM("roi1DeltaQp", pCodeParams->roi1DeltaQp);
  APITRACEPARAM("roi2DeltaQp", pCodeParams->roi2DeltaQp);
  APITRACEPARAM("roi3DeltaQp", pCodeParams->roi3DeltaQp);
  APITRACEPARAM("roi4DeltaQp", pCodeParams->roi4DeltaQp);
  APITRACEPARAM("roi5DeltaQp", pCodeParams->roi5DeltaQp);
  APITRACEPARAM("roi6DeltaQp", pCodeParams->roi6DeltaQp);
  APITRACEPARAM("roi7DeltaQp", pCodeParams->roi7DeltaQp);
  APITRACEPARAM("roi8DeltaQp", pCodeParams->roi8DeltaQp);
  APITRACEPARAM("roi1Qp", pCodeParams->roi1Qp);
  APITRACEPARAM("roi2Qp", pCodeParams->roi2Qp);
  APITRACEPARAM("roi3Qp", pCodeParams->roi3Qp);
  APITRACEPARAM("roi4Qp", pCodeParams->roi4Qp);
  APITRACEPARAM("roi5Qp", pCodeParams->roi5Qp);
  APITRACEPARAM("roi6Qp", pCodeParams->roi6Qp);
  APITRACEPARAM("roi7Qp", pCodeParams->roi7Qp);
  APITRACEPARAM("roi8Qp", pCodeParams->roi8Qp);
  APITRACEPARAM("chroma_qp_offset", pCodeParams->chroma_qp_offset);
  APITRACEPARAM("fieldOrder", pCodeParams->fieldOrder);
  APITRACEPARAM("gdrDuration", pCodeParams->gdrDuration);
  APITRACEPARAM("roiMapDeltaQpEnable", pCodeParams->roiMapDeltaQpEnable);
  APITRACEPARAM("roiMapDeltaQpBlockUnit", pCodeParams->roiMapDeltaQpBlockUnit);
  APITRACEPARAM("RoimapCuCtrl_index_enable", pCodeParams->RoimapCuCtrl_index_enable);
  APITRACEPARAM("RoimapCuCtrl_enable", pCodeParams->RoimapCuCtrl_enable);
  APITRACEPARAM("roiMapDeltaQpBinEnable", pCodeParams->roiMapDeltaQpBinEnable);
  APITRACEPARAM("RoimapCuCtrl_ver", pCodeParams->RoimapCuCtrl_ver);
  APITRACEPARAM("RoiQpDelta_ver", pCodeParams->RoiQpDelta_ver);
  APITRACEPARAM("pcm_enabled_flag", pCodeParams->pcm_enabled_flag);
  APITRACEPARAM("pcm_loop_filter_disabled_flag", pCodeParams->pcm_loop_filter_disabled_flag);
  APITRACEPARAM("ipcmMapEnable", pCodeParams->ipcmMapEnable);
  APITRACEPARAM("tiles_enabled_flag", pCodeParams->tiles_enabled_flag);
  APITRACEPARAM("num_tile_columns", pCodeParams->num_tile_columns);
  APITRACEPARAM("num_tile_rows", pCodeParams->num_tile_rows);
  APITRACEPARAM("loop_filter_across_tiles_enabled_flag", pCodeParams->loop_filter_across_tiles_enabled_flag);
  APITRACEPARAM("skipMapEnable", pCodeParams->skipMapEnable);
  APITRACEPARAM("enableRdoQuant", pCodeParams->enableRdoQuant);
  APITRACEPARAM("rdoqMapEnable", pCodeParams->rdoqMapEnable);
  APITRACEPARAM("aq_mode", pCodeParams->aq_mode);
  APITRACEPARAM("aq_strength", pCodeParams->aq_strength);
  APITRACEPARAM("psyFactor", pCodeParams->psyFactor);

  /* Check for existing instance */
  if (pEncInst->inst != pEncInst)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }
  cfg = regs->asicCfg;

  client_type = VCEncGetClientType(pEncInst->codecFormat);

  i32 core_id = -1;

   cfg = JencEncAsicGetAsicConfig(client_type,pEncInst->ctx);
   if (client_type == JENC_EWL_CLIENT_TYPE_H264_ENC && cfg.h264Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (client_type == JENC_EWL_CLIENT_TYPE_HEVC_ENC && cfg.hevcEnabled == EWL_HW_CONFIG_NOT_SUPPORTED)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (client_type == JENC_EWL_CLIENT_TYPE_AV1_ENC && cfg.av1Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (client_type == JENC_EWL_CLIENT_TYPE_VP9_ENC && cfg.vp9Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (cfg.deNoiseEnabled == EWL_HW_CONFIG_NOT_SUPPORTED &&
       pCodeParams->noiseReductionEnable == 1)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (pCodeParams->streamMultiSegmentMode != 0 && cfg.streamMultiSegment == EWL_HW_CONFIG_NOT_SUPPORTED)
   {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR unsupported argument by HW");
      return VCENC_INVALID_ARGUMENT;
   }

   if (pCodeParams->noiseReductionEnable == 1)
     pEncInst->featureToSupport.deNoiseEnabled = 1;
   else
     pEncInst->featureToSupport.deNoiseEnabled = 0;

  if(cfg.tu32Enable)
  {
    pEncInst->max_tr_size = 32;
    pEncInst->tr_depth_inter = (cfg.tu32Enable && cfg.dynamicMaxTuSize && pEncInst->rdoLevel == 0 ? 3 : 2);
  }

  if ((HW_ID_MAJOR_NUMBER(regs->asicHwId) < 2 /* H2V1 */)&&(pCodeParams->roiMapDeltaQpEnable == 1))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR ROI MAP not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pEncInst->asic.regs.asicCfg.roiMapVersion < 3) && pCodeParams->RoimapCuCtrl_index_enable )
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR ROI MAP cu ctrl index not supported");
    return VCENC_INVALID_ARGUMENT;
  }
  if ((pEncInst->asic.regs.asicCfg.roiMapVersion < 3) && pCodeParams->RoimapCuCtrl_enable )
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR ROI MAP cu ctrl not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  bAdvanceHW = (pEncInst->asic.regs.asicCfg.roiMapVersion == 2) && ((HW_ID_MAJOR_NUMBER(regs->asicHwId) >= 0x82) ||
                                            ((HW_ID_MAJOR_NUMBER(regs->asicHwId) == 0x60) && (HW_ID_MINOR_NUMBER(regs->asicHwId)>=0x10)));

  if ((pEncInst->asic.regs.asicCfg.roiMapVersion < 3) && pCodeParams->roiMapDeltaQpBinEnable )
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR ROI MAP DeltaQp format 1 ~3 not supported");
    return VCENC_INVALID_ARGUMENT;
  }
  if(pCodeParams->RoimapCuCtrl_enable && ((pCodeParams->RoimapCuCtrl_ver < 3)
                                           || (pCodeParams->RoimapCuCtrl_ver > 7)
                                           || IS_AV1(pEncInst->codecFormat)))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid RoiCuCtrlVer");
    return VCENC_INVALID_ARGUMENT;
  }
  if((pCodeParams->RoimapCuCtrl_enable == 0) && pCodeParams->RoimapCuCtrl_ver != 0)
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid RoimapCuCtrl_ver");
      return VCENC_INVALID_ARGUMENT;
  }

  true_e qpMapInvalid                  = pCodeParams->roiMapDeltaQpEnable && (pCodeParams->RoiQpDelta_ver == 0);
  true_e ipamMapInvalid                = pCodeParams->ipcmMapEnable && (pCodeParams->RoiQpDelta_ver != 1);
  true_e skipMapInvalid                = pCodeParams->skipMapEnable && (pCodeParams->RoiQpDelta_ver < 2);
  true_e rdoqMapInvalid                = pCodeParams->rdoqMapEnable && (pCodeParams->RoiQpDelta_ver != 4);
  true_e roiMapVersion3QpDeltaNotValid = (pEncInst->asic.regs.asicCfg.roiMapVersion == 3) && (qpMapInvalid || ipamMapInvalid || skipMapInvalid || (pCodeParams->RoiQpDelta_ver > 3));
  true_e roiMapVersion4QpDeltaNotValid = (pEncInst->asic.regs.asicCfg.roiMapVersion == 4) && (qpMapInvalid || ipamMapInvalid || skipMapInvalid || rdoqMapInvalid);
  if ( roiMapVersion3QpDeltaNotValid || roiMapVersion4QpDeltaNotValid ||
       ((pEncInst->asic.regs.asicCfg.roiMapVersion < 3) && (pCodeParams->RoiQpDelta_ver > 2)) ||
       (pCodeParams->RoiQpDelta_ver > 4))
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid RoiQpDelta_ver");
      return VCENC_INVALID_ARGUMENT;
  }
  if ( bAdvanceHW && (pCodeParams->ipcmMapEnable || pCodeParams->skipMapEnable) &&  (pCodeParams->RoiQpDelta_ver == 0))
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid RoiQpDelta_ver when advance HW");
      return VCENC_INVALID_ARGUMENT;
  }

  if ((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roiMapEnable != (pCodeParams->roiMapDeltaQpEnable ||
                                                                                    pCodeParams->RoimapCuCtrl_enable ||
                                                                                    pCodeParams->roiMapDeltaQpBinEnable)))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi Map Enable");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Check for invalid values */
  if (pCodeParams->sliceSize > (u32)pEncInst->ctbPerCol)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid sliceSize");
    return VCENC_INVALID_ARGUMENT;
  }
  if ((IS_AV1(pEncInst->codecFormat) || IS_VP9(pEncInst->codecFormat)) &&(pCodeParams->sliceSize != 0))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid sliceSize for AV1 or VP9, it should be 0");
    return VCENC_INVALID_ARGUMENT;
  }
  if ((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->gdrEnabled != (pCodeParams->gdrDuration > 0)))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config gdrDuration");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->cirStart > (u32)pEncInst->ctbPerFrame ||
      pCodeParams->cirInterval > (u32)pEncInst->ctbPerFrame)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid CIR value");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->intraArea.enable)
  {
    if (!(pCodeParams->intraArea.top <= pCodeParams->intraArea.bottom &&
          pCodeParams->intraArea.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->intraArea.left <= pCodeParams->intraArea.right &&
          pCodeParams->intraArea.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid intraArea");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  true_e ipcmAreaSupport = pCodeParams->ipcm1Area.enable || pCodeParams->ipcm2Area.enable || pCodeParams->ipcm3Area.enable || pCodeParams->ipcm4Area.enable ||
                           pCodeParams->ipcm5Area.enable || pCodeParams->ipcm6Area.enable || pCodeParams->ipcm7Area.enable || pCodeParams->ipcm8Area.enable;
  if ((IS_AV1(pEncInst->codecFormat) || IS_VP9(pEncInst->codecFormat)) && ( ipcmAreaSupport || pCodeParams->ipcmMapEnable)) {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR IPCM not supported for AV1 or VP9");
      return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->ipcm1Area.enable)
  {
    if (!(pCodeParams->ipcm1Area.top <= pCodeParams->ipcm1Area.bottom &&
          pCodeParams->ipcm1Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm1Area.left <= pCodeParams->ipcm1Area.right &&
          pCodeParams->ipcm1Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm1Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }
  if (pCodeParams->ipcm2Area.enable)
  {
    if (!(pCodeParams->ipcm2Area.top <= pCodeParams->ipcm2Area.bottom &&
          pCodeParams->ipcm2Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm2Area.left <= pCodeParams->ipcm2Area.right &&
          pCodeParams->ipcm2Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm2Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((regs->asicCfg.IPCM8Support == 0 ) && (pCodeParams->ipcm3Area.enable || pCodeParams->ipcm4Area.enable || pCodeParams->ipcm5Area.enable
                                         || pCodeParams->ipcm6Area.enable || pCodeParams->ipcm7Area.enable || pCodeParams->ipcm8Area.enable))
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcmArea");
      return VCENC_INVALID_ARGUMENT;
  }

  if (pCodeParams->ipcm3Area.enable)
  {
    if (!(pCodeParams->ipcm3Area.top <= pCodeParams->ipcm3Area.bottom &&
          pCodeParams->ipcm3Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm3Area.left <= pCodeParams->ipcm3Area.right &&
          pCodeParams->ipcm3Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm3Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->ipcm4Area.enable)
  {
    if (!(pCodeParams->ipcm4Area.top <= pCodeParams->ipcm4Area.bottom &&
          pCodeParams->ipcm4Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm4Area.left <= pCodeParams->ipcm4Area.right &&
          pCodeParams->ipcm4Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm4Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->ipcm5Area.enable)
  {
    if (!(pCodeParams->ipcm5Area.top <= pCodeParams->ipcm5Area.bottom &&
          pCodeParams->ipcm5Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm5Area.left <= pCodeParams->ipcm5Area.right &&
          pCodeParams->ipcm5Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm5Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->ipcm6Area.enable)
  {
    if (!(pCodeParams->ipcm6Area.top <= pCodeParams->ipcm6Area.bottom &&
          pCodeParams->ipcm6Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm6Area.left <= pCodeParams->ipcm6Area.right &&
          pCodeParams->ipcm6Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm6Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->ipcm7Area.enable)
  {
    if (!(pCodeParams->ipcm7Area.top <= pCodeParams->ipcm7Area.bottom &&
          pCodeParams->ipcm7Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm7Area.left <= pCodeParams->ipcm7Area.right &&
          pCodeParams->ipcm7Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm7Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->ipcm8Area.enable)
  {
    if (!(pCodeParams->ipcm8Area.top <= pCodeParams->ipcm8Area.bottom &&
          pCodeParams->ipcm8Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->ipcm8Area.left <= pCodeParams->ipcm8Area.right &&
          pCodeParams->ipcm8Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ipcm8Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi1Enable != pCodeParams->roi1Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi1Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi1Area.enable)
  {
    if (!(pCodeParams->roi1Area.top <= pCodeParams->roi1Area.bottom &&
          pCodeParams->roi1Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi1Area.left <= pCodeParams->roi1Area.right &&
          pCodeParams->roi1Area.right < (u32)pEncInst->ctbPerRow) || (pCodeParams->gdrDuration > 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi1Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi2Enable != pCodeParams->roi2Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi2Area");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pCodeParams->roi2Area.enable)
  {
    if (!(pCodeParams->roi2Area.top <= pCodeParams->roi2Area.bottom &&
          pCodeParams->roi2Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi2Area.left <= pCodeParams->roi2Area.right &&
          pCodeParams->roi2Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi2Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((regs->asicCfg.ROI8Support == 0 ) && (pCodeParams->roi3Area.enable || pCodeParams->roi4Area.enable || pCodeParams->roi5Area.enable
                                         || pCodeParams->roi6Area.enable || pCodeParams->roi7Area.enable || pCodeParams->roi8Area.enable))
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roiArea");
      return VCENC_INVALID_ARGUMENT;
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi3Enable != pCodeParams->roi3Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi3Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi3Area.enable)
  {
    if (!(pCodeParams->roi3Area.top <= pCodeParams->roi3Area.bottom &&
          pCodeParams->roi3Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi3Area.left <= pCodeParams->roi3Area.right &&
          pCodeParams->roi3Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi3Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi4Enable != pCodeParams->roi4Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi4Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi4Area.enable)
  {
    if (!(pCodeParams->roi4Area.top <= pCodeParams->roi4Area.bottom &&
          pCodeParams->roi4Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi4Area.left <= pCodeParams->roi4Area.right &&
          pCodeParams->roi4Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi4Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi5Enable != pCodeParams->roi5Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi5Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi5Area.enable)
  {
    if (!(pCodeParams->roi5Area.top <= pCodeParams->roi5Area.bottom &&
          pCodeParams->roi5Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi5Area.left <= pCodeParams->roi5Area.right &&
          pCodeParams->roi5Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi5Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi6Enable != pCodeParams->roi6Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi6Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi6Area.enable)
  {
    if (!(pCodeParams->roi6Area.top <= pCodeParams->roi6Area.bottom &&
          pCodeParams->roi6Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi6Area.left <= pCodeParams->roi6Area.right &&
          pCodeParams->roi6Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi6Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi7Enable != pCodeParams->roi7Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi7Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi7Area.enable)
  {
    if (!(pCodeParams->roi7Area.top <= pCodeParams->roi7Area.bottom &&
          pCodeParams->roi7Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi7Area.left <= pCodeParams->roi7Area.right &&
          pCodeParams->roi7Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi7Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((pEncInst->encStatus >= VCENCSTAT_START_STREAM)&&(pEncInst->roi8Enable != pCodeParams->roi8Area.enable))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config roi8Area");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->roi8Area.enable)
  {
    if (!(pCodeParams->roi8Area.top <= pCodeParams->roi8Area.bottom &&
          pCodeParams->roi8Area.bottom < (u32)pEncInst->ctbPerCol &&
          pCodeParams->roi8Area.left <= pCodeParams->roi8Area.right &&
          pCodeParams->roi8Area.right < (u32)pEncInst->ctbPerRow))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roi8Area");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if((((!bAdvanceHW) && (regs->asicCfg.roiMapVersion != 1 && regs->asicCfg.roiMapVersion != 3))||
      (bAdvanceHW && pCodeParams->RoiQpDelta_ver != 1)) && pCodeParams->ipcmMapEnable)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR IPCM MAP not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pCodeParams->skipMapEnable)
  {
    if (IS_AV1(pEncInst->codecFormat) || IS_VP9(pEncInst->codecFormat))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR SKIP MAP not supported for AV1/VP9");
      return VCENC_INVALID_ARGUMENT;
    }
    else if (((!bAdvanceHW) && (regs->asicCfg.roiMapVersion != 2 && regs->asicCfg.roiMapVersion != 3) && regs->asicCfg.roiMapVersion != 4) || (bAdvanceHW && pCodeParams->RoiQpDelta_ver != 2))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR SKIP MAP not supported by HW");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if (pCodeParams->rdoqMapEnable)
  {
    if ( (regs->asicCfg.roiMapVersion != 4) && (pCodeParams->RoiQpDelta_ver != 4))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR RDOQ MAP not supported by HW");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if(pCodeParams->aq_mode > 3)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl ERROR: INVALID aq_mode, should be within [0, 3]");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pCodeParams->aq_strength > 3.0) || (pCodeParams->aq_strength < 0.0))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl ERROR: INVALID aq_strength, should be within [0.0, 3.0]");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pCodeParams->psyFactor > 4.0) || (pCodeParams->psyFactor < 0.0))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl ERROR: INVALID psyFactor, should be within [0.0, 4.0]");
    return VCENC_INVALID_ARGUMENT;
  }
  else if ((pCodeParams->psyFactor > 0.0) && !regs->asicCfg.encPsyTuneSupport)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl ERROR: psy is not supported by HW");
    return VCENC_INVALID_ARGUMENT;
  }

  if (regs->asicCfg.roiAbsQpSupport)
  {
    if (pCodeParams->roi1DeltaQp < -51 ||
        pCodeParams->roi1DeltaQp > 51 ||
        pCodeParams->roi2DeltaQp < -51 ||
        pCodeParams->roi2DeltaQp > 51 ||
        pCodeParams->roi3DeltaQp < -51 ||
        pCodeParams->roi3DeltaQp > 51 ||
        pCodeParams->roi4DeltaQp < -51 ||
        pCodeParams->roi4DeltaQp > 51 ||
        pCodeParams->roi5DeltaQp < -51 ||
        pCodeParams->roi5DeltaQp > 51 ||
        pCodeParams->roi6DeltaQp < -51 ||
        pCodeParams->roi6DeltaQp > 51 ||
        pCodeParams->roi7DeltaQp < -51 ||
        pCodeParams->roi7DeltaQp > 51 ||
        pCodeParams->roi8DeltaQp < -51 ||
        pCodeParams->roi8DeltaQp > 51 ||
        pCodeParams->roi1Qp > 51 ||
        pCodeParams->roi2Qp > 51 ||
        pCodeParams->roi3Qp > 51 ||
        pCodeParams->roi4Qp > 51 ||
        pCodeParams->roi5Qp > 51 ||
        pCodeParams->roi6Qp > 51 ||
        pCodeParams->roi7Qp > 51 ||
        pCodeParams->roi8Qp > 51)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ROI delta QP");
      return VCENC_INVALID_ARGUMENT;
    }
  }
  else
  {
    if (pCodeParams->roi1DeltaQp < -30 ||
        pCodeParams->roi1DeltaQp > 0 ||
        pCodeParams->roi2DeltaQp < -30 ||
        pCodeParams->roi2DeltaQp > 0 /*||
       pCodeParams->adaptiveRoi < -51 ||
       pCodeParams->adaptiveRoi > 0*/)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid ROI delta QP");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  /* low latency : Input Line buffer check */
  if(pCodeParams->inputLineBufEn)
  {
     /* check zero depth */
     /* 6.0 does not check for amoutPerLoopBack */
     bool loopBackFalse = (pCodeParams->amountPerLoopBack == 0) && (HW_ID_MAJOR_NUMBER(regs->asicHwId) == 0x62);
     if ((pCodeParams->inputLineBufDepth == 0 || loopBackFalse) &&
         (pCodeParams->inputLineBufLoopBackEn || pCodeParams->inputLineBufHwModeEn))
     {
          APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid input buffer depth");
          return VCENC_INVALID_ARGUMENT;
     }

     /*prp sbi just support loop back mode*/
     if (regs->asicCfg.prpSbiSupport && pCodeParams->inputLineBufLoopBackEn == 0)
       return VCENC_INVALID_ARGUMENT;
  }

  if(pCodeParams->streamMultiSegmentMode > 2 ||
    ((pCodeParams->streamMultiSegmentMode >0) &&  (pCodeParams->streamMultiSegmentAmount <= 1 || pCodeParams->streamMultiSegmentAmount > 16)))
  {
     APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid stream multi-segment config");
     return VCENC_INVALID_ARGUMENT;
  }

  if(pCodeParams->streamMultiSegmentMode != 0 && pCodeParams->sliceSize != 0)
  {
     APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR multi-segment not support slice encoding");
     return VCENC_INVALID_ARGUMENT;
  }

  // if ((pCodeParams->Hdr10Display.hdr10_display_enable == ENCHW_YES) || (pCodeParams->vuiColor.vui_color_enable == ENCHW_YES) || (pCodeParams->Hdr10LightLevel.hdr10_lightlevel_enable == ENCHW_YES))
  if ((pCodeParams->Hdr10Display.hdr10_display_enable == ENCHW_YES) || (pCodeParams->Hdr10LightLevel.hdr10_lightlevel_enable == ENCHW_YES))
  {
	  // parameters check
	  if (!IS_HEVC(pEncInst->codecFormat) )
	  {
		  APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid Encoder Type, It should be HEVC!\n");
		  return VCENC_INVALID_ARGUMENT;
	  }

	  if (pEncInst->profile != VCENC_HEVC_MAIN_10_PROFILE)
	  {
		  APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid profile, It should be HEVC_MAIN_10_PROFILE!\n");
		  return VCENC_INVALID_ARGUMENT;
	  }

    /*
	  if (pCodeParams->Hdr10Color.hdr10_color_enable == ENCHW_YES)
	  {
		  if ((pCodeParams->Hdr10Color.hdr10_matrix != 9) || (pCodeParams->Hdr10Color.hdr10_primary != 9))
		  {
			  APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid HDR10 colour transfer VUI parameter\n");
			  return VCENC_INVALID_ARGUMENT;
		  }
	  }
    */
  }

  /* Programable ME vertical search range */
  if (pCodeParams->meVertSearchRange)
  {
    u8 permitVertRange[3] = {0, };
    u8 bPermit = 0;
    if(!regs->asicCfg.meVertRangeProgramable)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: Programable ME vertical search range not supported");
      return VCENC_INVALID_ARGUMENT;
    }

    if (IS_H264(pEncInst->codecFormat))
    {
      permitVertRange[0] = 24;
      permitVertRange[1] = 48;
      permitVertRange[2] = regs->asicCfg.meVertSearchRangeH264 * 8;
    }
    else
    {
      permitVertRange[0] = 40;
      permitVertRange[1] = 64;
      permitVertRange[2] = regs->asicCfg.meVertSearchRangeHEVC * 8;
    }

    /* check if the range is permissible */
    for (i32 i = 0; i < 3; i ++)
    {
      if (permitVertRange[i] && pCodeParams->meVertSearchRange == permitVertRange[i])
      {
        bPermit = 1;
        break;
      }
    }

    if (!bPermit)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: Invalid ME vertical search range. Should be 24|48|64 for H264; 40|64 for others.");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  if(pCodeParams->smartModeEnable && !pEncInst->asic.regs.asicCfg.backgroundDetSupport)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: Smart Mode not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pCodeParams->enableSao > 1 || pCodeParams->enableSao > 1 || pCodeParams->roiMapDeltaQpEnable > 1 ||
      pCodeParams->disableDeblockingFilter > 1 || pCodeParams->RoimapCuCtrl_enable > 1 || pCodeParams->roiMapDeltaQpBinEnable > 1 ||
      pCodeParams->seiMessages > 1 || pCodeParams->vuiVideoFullRange > 1)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid enable/disable");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pCodeParams->sampleAspectRatioWidth > 65535 ||
      pCodeParams->sampleAspectRatioHeight > 65535)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid sampleAspectRatio");
    return VCENC_INVALID_ARGUMENT;
  }

  regs->meAssignedVertRange = pCodeParams->meVertSearchRange >> 3;

  pEncInst->Hdr10Display.hdr10_display_enable = pCodeParams->Hdr10Display.hdr10_display_enable;
  pEncInst->Hdr10Display.hdr10_dx0 = pCodeParams->Hdr10Display.hdr10_dx0;
  pEncInst->Hdr10Display.hdr10_dy0 = pCodeParams->Hdr10Display.hdr10_dy0;
  pEncInst->Hdr10Display.hdr10_dx1 = pCodeParams->Hdr10Display.hdr10_dx1;
  pEncInst->Hdr10Display.hdr10_dy1 = pCodeParams->Hdr10Display.hdr10_dy1;
  pEncInst->Hdr10Display.hdr10_dx2 = pCodeParams->Hdr10Display.hdr10_dx2;
  pEncInst->Hdr10Display.hdr10_dy2 = pCodeParams->Hdr10Display.hdr10_dy2;
  pEncInst->Hdr10Display.hdr10_wx  = pCodeParams->Hdr10Display.hdr10_wx;
  pEncInst->Hdr10Display.hdr10_wy  = pCodeParams->Hdr10Display.hdr10_wy;
  pEncInst->Hdr10Display.hdr10_maxluma = pCodeParams->Hdr10Display.hdr10_maxluma;
  pEncInst->Hdr10Display.hdr10_minluma = pCodeParams->Hdr10Display.hdr10_minluma;

  pEncInst->vuiColorDescription.vuiColorDescripPresentFlag  = pCodeParams->vuiColorDescription.vuiColorDescripPresentFlag;
  pEncInst->vuiColorDescription.vuiColorPrimaries           = pCodeParams->vuiColorDescription.vuiColorPrimaries;
  pEncInst->vuiColorDescription.vuiMatrixCoefficients       = pCodeParams->vuiColorDescription.vuiMatrixCoefficients;
  pEncInst->vuiColorDescription.vuiTransferCharacteristics  = pCodeParams->vuiColorDescription.vuiTransferCharacteristics;

  pEncInst->Hdr10LightLevel.hdr10_lightlevel_enable = pCodeParams->Hdr10LightLevel.hdr10_lightlevel_enable;
  pEncInst->Hdr10LightLevel.hdr10_maxlight = pCodeParams->Hdr10LightLevel.hdr10_maxlight;
  pEncInst->Hdr10LightLevel.hdr10_avglight = pCodeParams->Hdr10LightLevel.hdr10_avglight;

  pEncInst->vuiVideoSignalTypePresentFlag  = pCodeParams->vuiVideoSignalTypePresentFlag;
  pEncInst->vuiVideoFormat                 = pCodeParams->vuiVideoFormat;

  pEncInst->sarWidth                       = pCodeParams->sampleAspectRatioWidth;
  pEncInst->sarHeight                      = pCodeParams->sampleAspectRatioHeight;
  pEncInst->vuiVideoFullRange              = pCodeParams->vuiVideoFullRange;

  pEncInst->RpsInSliceHeader = IS_H264(pEncInst->codecFormat)  ? 0: pCodeParams->RpsInSliceHeader;

  /* Check status, only slice size, CIR & ROI allowed to change after start */
  if (pEncInst->encStatus != VCENCSTAT_INIT)
  {
    goto set_slice_size;
  }

  if(IS_H264(pEncInst->codecFormat) ) {
    pEncInst->max_cu_size = 16;   /* Max coding unit size in pixels */
    pEncInst->min_cu_size = 8;   /* Min coding unit size in pixels */
    pEncInst->max_tr_size = 16;   /* Max transform size in pixels */
    pEncInst->min_tr_size = 4;   /* Min transform size in pixels */
    pEncInst->tr_depth_intra = 1;   /* Max transform hierarchy depth */
    pEncInst->tr_depth_inter = 2;   /* Max transform hierarchy depth */
    pEncInst->layerInRefIdc = pCodeParams->layerInRefIdcEnable;
  }

  if (pCodeParams->cabacInitFlag > 1)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid cabacInitIdc");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pCodeParams->enableCabac > 2)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid enableCabac");
    return VCENC_INVALID_ARGUMENT;
  }

  /* check limitation for H.264 baseline profile */
  if (IS_H264(pEncInst->codecFormat)  && pEncInst->profile == 66 && pCodeParams->enableCabac > 0)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid entropy coding mode for baseline profile");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((IS_H264(pEncInst->codecFormat)  && pCodeParams->roiMapDeltaQpBlockUnit >= 3) ||
      (IS_AV1(pEncInst->codecFormat)  && pCodeParams->roiMapDeltaQpBlockUnit >= 1) ) //AV1 qpDelta in CTU level
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid roiMapDeltaQpBlockUnit");
    return VCENC_INVALID_ARGUMENT;
  }

  if((IS_AV1(pEncInst->codecFormat) || IS_VP9(pEncInst->codecFormat))  && pCodeParams->tiles_enabled_flag)
  {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid, AV1 and VP9 tiles not up yet, disable it");
  }

  regs->bRDOQEnable = pCodeParams->enableRdoQuant;
  regs->rdoqMapEnable = pCodeParams->rdoqMapEnable ? 1:0;
  if (regs->bRDOQEnable || regs->rdoqMapEnable)
  {
    i32 rdoqSupport = (IS_H264(pEncInst->codecFormat) && regs->asicCfg.RDOQSupportH264)  ||
                      (IS_AV1(pEncInst->codecFormat)  && regs->asicCfg.RDOQSupportAV1)   ||
                      (IS_HEVC(pEncInst->codecFormat) && regs->asicCfg.RDOQSupportHEVC)  ||
                      (IS_VP9(pEncInst->codecFormat) && regs->asicCfg.RDOQSupportVP9);
    if (pEncInst->pass == 1)
    {
      regs->bRDOQEnable   = 0;
      regs->rdoqMapEnable = 0;
      regs->skipMapEnable = 0;
      APITRACEERR("Jenc_VCEncSetCodingCtrl: RDO Quant is not supported by PASS1 encoding and forced to be disabled");
    }
    if (( regs->bRDOQEnable || regs->rdoqMapEnable ) && (rdoqSupport == 0))
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: RDO Quant is not supported by this HW version");
      return VCENC_INVALID_ARGUMENT;
    }
    /* RDO Quant is not supported when cavlc is enabled for H264 encoder */
    if (IS_H264(pEncInst->codecFormat) && (pCodeParams->enableCabac == 0))
    {
      if (regs->rdoqMapEnable)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: WARNING. RDO Quant map is not supported by H264 CAVLC and forced to be disabled");
        regs->rdoqMapEnable = 0;
      }
      if (regs->bRDOQEnable)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: WARNING. RDO Quant is not supported by H264 CAVLC and forced to be disabled");
        regs->bRDOQEnable = 0;
      }
    }
  }

  regs->dynamicRdoEnable = pCodeParams->enableDynamicRdo;
  if (regs->dynamicRdoEnable)
  {
    if (regs->asicCfg.dynamicRdoSupport == 0)
    {
      regs->dynamicRdoEnable = 0;
      APITRACEERR("Jenc_VCEncSetCodingCtrl: Dynamic RDO is not supported by HW and forced to be disabled");
    }
  }
  if (regs->dynamicRdoEnable)
  {
    regs->dynamicRdoCu16Bias = pCodeParams->dynamicRdoCu16Bias;
    regs->dynamicRdoCu16Factor = pCodeParams->dynamicRdoCu16Factor;
    regs->dynamicRdoCu32Bias = pCodeParams->dynamicRdoCu32Bias;
    regs->dynamicRdoCu32Factor = pCodeParams->dynamicRdoCu32Factor;
  }
  pEncInst->chromaQpOffset = pCodeParams->chroma_qp_offset;
  pEncInst->fieldOrder = pCodeParams->fieldOrder ? 1 : 0;
  pEncInst->disableDeblocking = pCodeParams->disableDeblockingFilter;
  pEncInst->enableDeblockOverride = pCodeParams->enableDeblockOverride;
  if (pEncInst->enableDeblockOverride)
  {
    regs->slice_deblocking_filter_override_flag = pCodeParams->deblockOverride;
  }
  else
  {
    regs->slice_deblocking_filter_override_flag = 0;
  }
  if(IS_H264(pEncInst->codecFormat) ) {
    /* always enable deblocking override for H.264 */
    pEncInst->enableDeblockOverride = 1;
    regs->slice_deblocking_filter_override_flag = 1;
  }
  pEncInst->tc_Offset = pCodeParams->tc_Offset;
  pEncInst->beta_Offset = pCodeParams->beta_Offset;
  pEncInst->enableSao = pCodeParams->enableSao;

  VCEncHEVCDnfSetParameters(pEncInst, pCodeParams);

  regs->cabac_init_flag = pCodeParams->cabacInitFlag;
  regs->entropy_coding_mode_flag = (pCodeParams->enableCabac ? 1 : 0);

  /* SEI messages are written in the beginning of each frame */
  if (pCodeParams->seiMessages)
    pEncInst->rateControl.sei.enabled = ENCHW_YES;
  else
    pEncInst->rateControl.sei.enabled = ENCHW_NO;

  /* SRAM power down mode */
  regs->sramPowerdownDisable = pCodeParams->sramPowerdownDisable;

set_slice_size:

  if(pCodeParams->sliceSize)
  {
    /* Multi-slice mode is not supported by VCMD, so need to disable (bypass) VCMD */
    JencEWLSetVCMDMode(pEncInst->asic.ewl, 0);
    regs->bVCMDEnable = JencEWLGetVCMDMode(pEncInst->asic.ewl) ? true : false;
  }
  regs->sliceSize = pCodeParams->sliceSize;
  regs->sliceNum = (regs->sliceSize == 0) ?  1 : ((pEncInst->ctbPerCol + (regs->sliceSize - 1)) / regs->sliceSize);
  if((IS_AV1(pEncInst->codecFormat) || IS_VP9(pEncInst->codecFormat)) && regs->sliceNum > 1)
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: WARNING No multi slice support in AV1 or VP9");
    regs->sliceSize = 0;
    regs->sliceNum = 1;
  }

  //Limit MAX_SLICE_NUM
  if(regs->sliceNum > MAX_SLICE_NUM)
  {
    do
    {
      regs->sliceSize++;
      regs->sliceNum = (regs->sliceSize == 0) ?  1 : ((pEncInst->ctbPerCol + (regs->sliceSize - 1)) / regs->sliceSize);
    }while(regs->sliceNum > MAX_SLICE_NUM);
  }

  pEncInst->enableScalingList = pCodeParams->enableScalingList;

  if (pCodeParams->roiMapDeltaQpEnable || pCodeParams->roiMapDeltaQpBinEnable || pCodeParams->RoimapCuCtrl_enable )
  {
    pEncInst->min_qp_size = MIN((1 << (6 - pCodeParams->roiMapDeltaQpBlockUnit)), pEncInst->max_cu_size);
  }
  else
    pEncInst->min_qp_size = pEncInst->max_cu_size;


  /* Set CIR, intra forcing and ROI parameters */
  regs->cirStart = pCodeParams->cirStart;
  regs->cirInterval = pCodeParams->cirInterval;

  if (pCodeParams->intraArea.enable)
  {
    regs->intraAreaTop = pCodeParams->intraArea.top;
    regs->intraAreaLeft = pCodeParams->intraArea.left;
    regs->intraAreaBottom = pCodeParams->intraArea.bottom;
    regs->intraAreaRight = pCodeParams->intraArea.right;
  }
  else
  {
    regs->intraAreaTop = regs->intraAreaLeft = regs->intraAreaBottom =
                           regs->intraAreaRight = INVALID_POS;
  }

  pEncInst->pcm_enabled_flag = pCodeParams->pcm_enabled_flag || (pCodeParams->RoimapCuCtrl_ver > 3);
  regs->ipcmFilterDisable = pEncInst->pcm_loop_filter_disabled_flag = pCodeParams->pcm_loop_filter_disabled_flag;

  if (pCodeParams->ipcm1Area.enable)
  {
    regs->ipcm1AreaTop = pCodeParams->ipcm1Area.top;
    regs->ipcm1AreaLeft = pCodeParams->ipcm1Area.left;
    regs->ipcm1AreaBottom = pCodeParams->ipcm1Area.bottom;
    regs->ipcm1AreaRight = pCodeParams->ipcm1Area.right;
  }
  else
  {
    regs->ipcm1AreaTop = regs->ipcm1AreaLeft = regs->ipcm1AreaBottom =
                         regs->ipcm1AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm2Area.enable)
  {
    regs->ipcm2AreaTop = pCodeParams->ipcm2Area.top;
    regs->ipcm2AreaLeft = pCodeParams->ipcm2Area.left;
    regs->ipcm2AreaBottom = pCodeParams->ipcm2Area.bottom;
    regs->ipcm2AreaRight = pCodeParams->ipcm2Area.right;
  }
  else
  {
      regs->ipcm2AreaTop = regs->ipcm2AreaLeft = regs->ipcm2AreaBottom =
                           regs->ipcm2AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm3Area.enable)
  {
    regs->ipcm3AreaTop    = pCodeParams->ipcm3Area.top;
    regs->ipcm3AreaLeft   = pCodeParams->ipcm3Area.left;
    regs->ipcm3AreaBottom = pCodeParams->ipcm3Area.bottom;
    regs->ipcm3AreaRight  = pCodeParams->ipcm3Area.right;
  }
  else
  {
    regs->ipcm3AreaTop    = regs->ipcm3AreaLeft =
    regs->ipcm3AreaBottom = regs->ipcm3AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm4Area.enable)
  {
    regs->ipcm4AreaTop    = pCodeParams->ipcm4Area.top;
    regs->ipcm4AreaLeft   = pCodeParams->ipcm4Area.left;
    regs->ipcm4AreaBottom = pCodeParams->ipcm4Area.bottom;
    regs->ipcm4AreaRight  = pCodeParams->ipcm4Area.right;
  }
  else
  {
    regs->ipcm4AreaTop = regs->ipcm4AreaLeft = regs->ipcm4AreaBottom =
                         regs->ipcm4AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm5Area.enable)
  {
    regs->ipcm5AreaTop    = pCodeParams->ipcm5Area.top;
    regs->ipcm5AreaLeft   = pCodeParams->ipcm5Area.left;
    regs->ipcm5AreaBottom = pCodeParams->ipcm5Area.bottom;
    regs->ipcm5AreaRight  = pCodeParams->ipcm5Area.right;
  }
  else
  {
    regs->ipcm5AreaTop = regs->ipcm5AreaLeft = regs->ipcm5AreaBottom =
                         regs->ipcm5AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm6Area.enable)
  {
    regs->ipcm6AreaTop    = pCodeParams->ipcm6Area.top;
    regs->ipcm6AreaLeft   = pCodeParams->ipcm6Area.left;
    regs->ipcm6AreaBottom = pCodeParams->ipcm6Area.bottom;
    regs->ipcm6AreaRight  = pCodeParams->ipcm6Area.right;
  }
  else
  {
    regs->ipcm6AreaTop = regs->ipcm6AreaLeft = regs->ipcm6AreaBottom =
                         regs->ipcm6AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm7Area.enable)
  {
    regs->ipcm7AreaTop    = pCodeParams->ipcm7Area.top;
    regs->ipcm7AreaLeft   = pCodeParams->ipcm7Area.left;
    regs->ipcm7AreaBottom = pCodeParams->ipcm7Area.bottom;
    regs->ipcm7AreaRight  = pCodeParams->ipcm7Area.right;
  }
  else
  {
    regs->ipcm7AreaTop = regs->ipcm7AreaLeft = regs->ipcm7AreaBottom =
                         regs->ipcm7AreaRight = INVALID_POS;
  }

  if (pCodeParams->ipcm8Area.enable)
  {
    regs->ipcm8AreaTop    = pCodeParams->ipcm8Area.top;
    regs->ipcm8AreaLeft   = pCodeParams->ipcm8Area.left;
    regs->ipcm8AreaBottom = pCodeParams->ipcm8Area.bottom;
    regs->ipcm8AreaRight  = pCodeParams->ipcm8Area.right;
  }
  else
  {
    regs->ipcm8AreaTop = regs->ipcm8AreaLeft = regs->ipcm8AreaBottom =
                         regs->ipcm8AreaRight = INVALID_POS;
  }

  regs->ipcmMapEnable = pCodeParams->ipcmMapEnable;

  if (pCodeParams->roi1Area.enable && pEncInst->pass != 1)
  {
    regs->roi1Top = pCodeParams->roi1Area.top;
    regs->roi1Left = pCodeParams->roi1Area.left;
    regs->roi1Bottom = pCodeParams->roi1Area.bottom;
    regs->roi1Right = pCodeParams->roi1Area.right;
    pEncInst->roi1Enable = 1;
  }
  else
  {
    regs->roi1Top = regs->roi1Left = regs->roi1Bottom =
                                       regs->roi1Right = INVALID_POS;
    pEncInst->roi1Enable = 0;
  }
  if (pCodeParams->roi2Area.enable && pEncInst->pass != 1)
  {
    regs->roi2Top = pCodeParams->roi2Area.top;
    regs->roi2Left = pCodeParams->roi2Area.left;
    regs->roi2Bottom = pCodeParams->roi2Area.bottom;
    regs->roi2Right = pCodeParams->roi2Area.right;
    pEncInst->roi2Enable = 1;
  }
  else
  {
    regs->roi2Top = regs->roi2Left = regs->roi2Bottom =
                                       regs->roi2Right = INVALID_POS;
    pEncInst->roi2Enable = 0;
  }
  if (pCodeParams->roi3Area.enable && pEncInst->pass != 1)
  {
    regs->roi3Top = pCodeParams->roi3Area.top;
    regs->roi3Left = pCodeParams->roi3Area.left;
    regs->roi3Bottom = pCodeParams->roi3Area.bottom;
    regs->roi3Right = pCodeParams->roi3Area.right;
    pEncInst->roi3Enable = 1;
  }
  else
  {
    regs->roi3Top = regs->roi3Left = regs->roi3Bottom =
                                       regs->roi3Right = INVALID_POS;
    pEncInst->roi3Enable = 0;
  }
  if (pCodeParams->roi4Area.enable && pEncInst->pass != 1)
  {
    regs->roi4Top = pCodeParams->roi4Area.top;
    regs->roi4Left = pCodeParams->roi4Area.left;
    regs->roi4Bottom = pCodeParams->roi4Area.bottom;
    regs->roi4Right = pCodeParams->roi4Area.right;
    pEncInst->roi4Enable = 1;
  }
  else
  {
    regs->roi4Top = regs->roi4Left = regs->roi4Bottom =
                                       regs->roi4Right = INVALID_POS;
    pEncInst->roi4Enable = 0;
  }
  if (pCodeParams->roi5Area.enable && pEncInst->pass != 1)
  {
    regs->roi5Top = pCodeParams->roi5Area.top;
    regs->roi5Left = pCodeParams->roi5Area.left;
    regs->roi5Bottom = pCodeParams->roi5Area.bottom;
    regs->roi5Right = pCodeParams->roi5Area.right;
    pEncInst->roi5Enable = 1;
  }
  else
  {
    regs->roi5Top = regs->roi5Left = regs->roi5Bottom =
                                       regs->roi5Right = INVALID_POS;
    pEncInst->roi5Enable = 0;
  }
  if (pCodeParams->roi6Area.enable && pEncInst->pass != 1)
  {
    regs->roi6Top = pCodeParams->roi6Area.top;
    regs->roi6Left = pCodeParams->roi6Area.left;
    regs->roi6Bottom = pCodeParams->roi6Area.bottom;
    regs->roi6Right = pCodeParams->roi6Area.right;
    pEncInst->roi6Enable = 1;
  }
  else
  {
    regs->roi6Top = regs->roi6Left = regs->roi6Bottom =
                                       regs->roi6Right = INVALID_POS;
    pEncInst->roi6Enable = 0;
  }
  if (pCodeParams->roi7Area.enable && pEncInst->pass != 1)
  {
    regs->roi7Top = pCodeParams->roi7Area.top;
    regs->roi7Left = pCodeParams->roi7Area.left;
    regs->roi7Bottom = pCodeParams->roi7Area.bottom;
    regs->roi7Right = pCodeParams->roi7Area.right;
    pEncInst->roi7Enable = 1;
  }
  else
  {
    regs->roi7Top = regs->roi7Left = regs->roi7Bottom =
                                       regs->roi7Right = INVALID_POS;
    pEncInst->roi7Enable = 0;
  }
  if (pCodeParams->roi8Area.enable && pEncInst->pass != 1)
  {
    regs->roi8Top = pCodeParams->roi8Area.top;
    regs->roi8Left = pCodeParams->roi8Area.left;
    regs->roi8Bottom = pCodeParams->roi8Area.bottom;
    regs->roi8Right = pCodeParams->roi8Area.right;
    pEncInst->roi8Enable = 1;
  }
  else
  {
    regs->roi8Top = regs->roi8Left = regs->roi8Bottom =
                                       regs->roi8Right = INVALID_POS;
    pEncInst->roi8Enable = 0;
  }

  regs->roi1DeltaQp = -pCodeParams->roi1DeltaQp;
  regs->roi2DeltaQp = -pCodeParams->roi2DeltaQp;
  regs->roi1Qp = pCodeParams->roi1Qp;
  regs->roi2Qp = pCodeParams->roi2Qp;
  regs->roi3DeltaQp = -pCodeParams->roi3DeltaQp;
  regs->roi4DeltaQp = -pCodeParams->roi4DeltaQp;
  regs->roi5DeltaQp = -pCodeParams->roi5DeltaQp;
  regs->roi6DeltaQp = -pCodeParams->roi6DeltaQp;
  regs->roi7DeltaQp = -pCodeParams->roi7DeltaQp;
  regs->roi8DeltaQp = -pCodeParams->roi8DeltaQp;
  regs->roi3Qp = pCodeParams->roi3Qp;
  regs->roi4Qp = pCodeParams->roi4Qp;
  regs->roi5Qp = pCodeParams->roi5Qp;
  regs->roi6Qp = pCodeParams->roi6Qp;
  regs->roi7Qp = pCodeParams->roi7Qp;
  regs->roi8Qp = pCodeParams->roi8Qp;

  regs->roiUpdate   = 1;    /* ROI has changed from previous frame. */

  pEncInst->roiMapEnable = 0;
  pEncInst->roiMapDeltaQpEnable           = pCodeParams->roiMapDeltaQpEnable;
  if(pEncInst->asic.regs.asicCfg.roiMapVersion >= 3)
  {
      pEncInst->RoimapCuCtrl_index_enable = pCodeParams->RoimapCuCtrl_index_enable;
      pEncInst->RoimapCuCtrl_enable       = pCodeParams->RoimapCuCtrl_enable;

      pEncInst->RoimapCuCtrl_ver          = pCodeParams->RoimapCuCtrl_ver;
      pEncInst->RoiQpDelta_ver            = pCodeParams->RoiQpDelta_ver;
      pEncInst->roiMapDeltaQpBinEnable    = pCodeParams->roiMapDeltaQpBinEnable;
  }
  if(bAdvanceHW)
    pEncInst->RoiQpDelta_ver              = pCodeParams->RoiQpDelta_ver;
#ifndef CTBRC_STRENGTH
  if ((pCodeParams->roiMapDeltaQpEnable == 1) || pCodeParams->roiMapDeltaQpBinEnable)
  {
    pEncInst->roiMapEnable = 1;
    regs->rcRoiEnable = RCROIMODE_ROIMAP_ENABLE;
  }
  else if (pCodeParams->roi1Area.enable || pCodeParams->roi2Area.enable)
    regs->rcRoiEnable = RCROIMODE_ROIAREA_ENABLE;
  else
    regs->rcRoiEnable = RCROIMODE_RC_ROIMAP_ROIAREA_DIABLE;
#else
    /* rdoqSkipOnlyMapEnableFlag just for 2pass when only rdoq or skip , no Qp */
    true_e rdoqSkipOnlyMapEnableFlag = (pEncInst->pass != 0) && (pCodeParams->skipMapEnable || pCodeParams->rdoqMapEnable) && (pEncInst->asic.regs.asicCfg.roiMapVersion == 4) && (pEncInst->RoiQpDelta_ver == 4);
    /*rcRoiEnable : bit2: rc control bit, bit1: roi map control bit, bit 0: roi area control bit*/
    if(((pCodeParams->roiMapDeltaQpEnable == 1) || rdoqSkipOnlyMapEnableFlag || pCodeParams->roiMapDeltaQpBinEnable || pCodeParams->RoimapCuCtrl_enable) &&( pCodeParams->roi1Area.enable ==0 && pCodeParams->roi2Area.enable ==0 && pCodeParams->roi3Area.enable ==0&& pCodeParams->roi4Area.enable ==0
                                                 && pCodeParams->roi5Area.enable ==0&& pCodeParams->roi6Area.enable ==0&& pCodeParams->roi7Area.enable ==0&& pCodeParams->roi8Area.enable ==0))
    {
      pEncInst->roiMapEnable = 1;
      regs->rcRoiEnable = 0x02;
    }
    else if((pCodeParams->roiMapDeltaQpEnable == 0) && (pCodeParams->roiMapDeltaQpBinEnable == 0)&& (pCodeParams->RoimapCuCtrl_enable == 0) && ( pCodeParams->roi1Area.enable !=0 || pCodeParams->roi2Area.enable !=0 || pCodeParams->roi3Area.enable !=0 || pCodeParams->roi4Area.enable !=0
                                                       || pCodeParams->roi5Area.enable !=0 || pCodeParams->roi6Area.enable !=0 || pCodeParams->roi7Area.enable !=0 || pCodeParams->roi8Area.enable !=0))
    {
      regs->rcRoiEnable = 0x01;
    }
    else if(((pCodeParams->roiMapDeltaQpEnable != 0) || rdoqSkipOnlyMapEnableFlag || pCodeParams->roiMapDeltaQpBinEnable || (pCodeParams->RoimapCuCtrl_enable != 0)) && ( pCodeParams->roi1Area.enable !=0 || pCodeParams->roi2Area.enable !=0 || pCodeParams->roi3Area.enable !=0 || pCodeParams->roi4Area.enable !=0
                                                       || pCodeParams->roi5Area.enable !=0 || pCodeParams->roi6Area.enable !=0 || pCodeParams->roi7Area.enable !=0 || pCodeParams->roi8Area.enable !=0))
    {
      pEncInst->roiMapEnable = 1;
      regs->rcRoiEnable = 0x03;
    }
    else
      regs->rcRoiEnable = 0x00;
#endif

  if (pEncInst->pass == 1)
    regs->rcRoiEnable = 0x00;

  /* SKIP map */
  if (pEncInst->pass != 1)
    regs->skipMapEnable = pCodeParams->skipMapEnable ? 1 : 0;

  pEncInst->rateControl.sei.insertRecoveryPointMessage = ENCHW_NO;
  pEncInst->rateControl.sei.recoveryFrameCnt = pCodeParams->gdrDuration;
  if (pEncInst->encStatus < VCENCSTAT_START_FRAME)
  {
    pEncInst->gdrFirstIntraFrame = (1 + pEncInst->interlaced);
  }
  pEncInst->gdrEnabled = (pCodeParams->gdrDuration > 0);
  bool gdrInit = pEncInst->gdrEnabled && (pEncInst->gdrDuration != (i32)pCodeParams->gdrDuration);
  pEncInst->gdrDuration = pCodeParams->gdrDuration;

  if (gdrInit )
  {
    pEncInst->gdrStart = 0;
    pEncInst->gdrCount = 0;

    pEncInst->gdrAverageMBRows = (pEncInst->ctbPerCol - 1) / pEncInst->gdrDuration;
    pEncInst->gdrMBLeft = pEncInst->ctbPerCol - 1 - pEncInst->gdrAverageMBRows * pEncInst->gdrDuration;

    if (pEncInst->gdrAverageMBRows == 0)
    {
      pEncInst->rateControl.sei.recoveryFrameCnt = pEncInst->gdrMBLeft;
      pEncInst->gdrDuration = pEncInst->gdrMBLeft;
    }
  }

  /* low latency */
  pEncInst->inputLineBuf.inputLineBufEn = pCodeParams->inputLineBufEn;
  pEncInst->inputLineBuf.inputLineBufLoopBackEn = pCodeParams->inputLineBufLoopBackEn;
  pEncInst->inputLineBuf.inputLineBufDepth = pCodeParams->inputLineBufDepth;
  pEncInst->inputLineBuf.amountPerLoopBack = (regs->asicCfg.prpSbiSupport ? pCodeParams->amountPerLoopBack : 2);
  pEncInst->inputLineBuf.inputLineBufHwModeEn = pCodeParams->inputLineBufHwModeEn;
  pEncInst->inputLineBuf.cbFunc = pCodeParams->inputLineBufCbFunc;
  pEncInst->inputLineBuf.cbData = pCodeParams->inputLineBufCbData;
  pEncInst->inputLineBuf.sbi_id_0 = pCodeParams->sbi_id_0;
  pEncInst->inputLineBuf.sbi_id_1 = pCodeParams->sbi_id_1;
  pEncInst->inputLineBuf.sbi_id_2 = pCodeParams->sbi_id_2;

  /*stream multi-segment*/
  pEncInst->streamMultiSegment.streamMultiSegmentMode = pCodeParams->streamMultiSegmentMode;
  pEncInst->streamMultiSegment.streamMultiSegmentAmount = pCodeParams->streamMultiSegmentAmount;
  pEncInst->streamMultiSegment.cbFunc = pCodeParams->streamMultiSegCbFunc;
  pEncInst->streamMultiSegment.cbData = pCodeParams->streamMultiSegCbData;

  /* smart */
  pEncInst->smartModeEnable = pCodeParams->smartModeEnable;
  pEncInst->smartH264LumDcTh = pCodeParams->smartH264LumDcTh;
  pEncInst->smartH264CbDcTh = pCodeParams->smartH264CbDcTh;
  pEncInst->smartH264CrDcTh = pCodeParams->smartH264CrDcTh;
  for(i = 0; i < 3; i++) {
    pEncInst->smartHevcLumDcTh[i] = pCodeParams->smartHevcLumDcTh[i];
    pEncInst->smartHevcChrDcTh[i] = pCodeParams->smartHevcChrDcTh[i];
    pEncInst->smartHevcLumAcNumTh[i] = pCodeParams->smartHevcLumAcNumTh[i];
    pEncInst->smartHevcChrAcNumTh[i] = pCodeParams->smartHevcChrAcNumTh[i];
  }
  pEncInst->smartH264Qp = pCodeParams->smartH264Qp;
  pEncInst->smartHevcLumQp = pCodeParams->smartHevcLumQp;
  pEncInst->smartHevcChrQp = pCodeParams->smartHevcChrQp;
  for(i = 0; i < 4; i++)
    pEncInst->smartMeanTh[i] = pCodeParams->smartMeanTh[i];
  pEncInst->smartPixNumCntTh = pCodeParams->smartPixNumCntTh;

  /* tile*/
  pEncInst->tiles_enabled_flag = pCodeParams->tiles_enabled_flag && ((IS_HEVC(pEncInst->codecFormat) || IS_H264(pEncInst->codecFormat)));
  pEncInst->num_tile_columns = pCodeParams->num_tile_columns;
  pEncInst->num_tile_rows = pCodeParams->num_tile_rows;
  pEncInst->loop_filter_across_tiles_enabled_flag = pCodeParams->loop_filter_across_tiles_enabled_flag;

  /* psy factor */
  pEncInst->psyFactor = pCodeParams->psyFactor;
  regs->psyFactor = (u32)(pEncInst->psyFactor*(1<<PSY_FACTOR_SCALE_BITS) + 0.5);

  /* multipass */
  pEncInst->cuTreeCtl.inQpDeltaBlkSize = 64 >> pCodeParams->roiMapDeltaQpBlockUnit;
  pEncInst->cuTreeCtl.aq_mode = pCodeParams->aq_mode;
  pEncInst->cuTreeCtl.aqStrength = pCodeParams->aq_strength;

  if(pEncInst->pass==2) {
	  if(!((pEncInst->asic.regs.asicCfg.roiMapVersion == 4) && (pEncInst->RoiQpDelta_ver == 4)))
      pEncInst->RoiQpDelta_ver            = 1;
    VCEncCodingCtrl newCodeParams;
    memcpy(&newCodeParams, pCodeParams, sizeof(VCEncCodingCtrl));
    newCodeParams.chroma_qp_offset = 0;
    newCodeParams.RoimapCuCtrl_enable = HANTRO_FALSE;
    newCodeParams.RoimapCuCtrl_index_enable = HANTRO_FALSE;
    if(pEncInst->asic.regs.asicCfg.roiMapVersion == 3)
      newCodeParams.RoiQpDelta_ver            = 1;
    VCEncRet ret = Jenc_VCEncSetCodingCtrl(pEncInst->lookahead.priv_inst, &newCodeParams);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncSetCodingCtrl: LookaheadSetCodingCtrl failed");
      return ret;
    }
  }

  pEncInst->asic.regs.bCodingCtrlUpdate = 1;
  APITRACE("Jenc_VCEncSetCodingCtrl: OK");
  return VCENC_OK;
}

/*-----------------------------------------------------------------------------
check reference lists modification
-------------------------------------------------------------------------------*/
i32 Jenc_check_ref_lists_modification(const VCEncIn *pEncIn)
{
  int i;
  bool lowdelayB = HANTRO_FALSE;
  VCEncGopConfig *gopCfg = (VCEncGopConfig *)(&(pEncIn->gopConfig));

  for (i = 0; i < gopCfg->size; i ++)
  {
    VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[i]);
    if (cfg->codingType == VCENC_BIDIR_PREDICTED_FRAME)
    {
      u32 iRefPic;
      lowdelayB = HANTRO_TRUE;
      for (iRefPic = 0; iRefPic < cfg->numRefPics; iRefPic ++)
      {
        if (cfg->refPics[iRefPic].used_by_cur && cfg->refPics[iRefPic].ref_pic > 0)
          lowdelayB = HANTRO_FALSE;
      }
      if (lowdelayB)
        break;
    }
  }
  return (lowdelayB || pEncIn->bIsPeriodUpdateLTR || pEncIn->flexRefsEnable) ? 1 : 0;
}


/*------------------------------------------------------------------------------
  set_parameter
------------------------------------------------------------------------------*/
i32 set_parameter(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn,
                  struct Jenc_vps *v, struct Jenc_sps *s, struct Jenc_pps *p)
{
  struct container *c;
  struct vcenc_buffer source;
  i32 tmp;
  i32 i;

  if (!(c = Jenc_get_container(vcenc_instance))) goto out;
  if (!v || !s || !p) goto out;

  /* Initialize stream buffers */
  if (init_buffer(&source, vcenc_instance)) goto out;
  if (get_buffer(&v->ps.b, &source, PRM_SET_BUFF_SIZE, HANTRO_TRUE)) goto out;
#ifdef TEST_DATA
  Jenc_Enc_open_stream_trace(&v->ps.b);
#endif

  if (get_buffer(&s->ps.b, &source, PRM_SET_BUFF_SIZE, HANTRO_TRUE)) goto out;
#ifdef TEST_DATA
  Jenc_Enc_open_stream_trace(&s->ps.b);
#endif

  if (get_buffer(&p->ps.b, &source, PRM_SET_BUFF_SIZE, HANTRO_TRUE)) goto out;
#ifdef TEST_DATA
  Jenc_Enc_open_stream_trace(&p->ps.b);
#endif


  /* Coding unit sizes */
  if (Jenc_vs_log2i(vcenc_instance->min_cu_size, &tmp)) goto out;
  if (Jenc_checkRange(tmp, 3, 3)) goto out;
  s->log2_min_cb_size = tmp;

  if (Jenc_vs_log2i(vcenc_instance->max_cu_size, &tmp)) goto out;
  i32 log2_ctu_size = (IS_H264(vcenc_instance->codecFormat)  ? 4 : 6);
  if (Jenc_checkRange(tmp, log2_ctu_size, log2_ctu_size)) goto out;
  s->log2_diff_cb_size = tmp - s->log2_min_cb_size;
  p->log2_ctb_size = s->log2_min_cb_size + s->log2_diff_cb_size;
  p->ctb_size = 1 << p->log2_ctb_size;
  ASSERT(p->ctb_size == vcenc_instance->max_cu_size);

  /* Transform size */
  if (Jenc_vs_log2i(vcenc_instance->min_tr_size, &tmp)) goto out;
  if (Jenc_checkRange(tmp, 2, 2)) goto out;
  s->log2_min_tr_size = tmp;

  if (Jenc_vs_log2i(vcenc_instance->max_tr_size, &tmp)) goto out;
  if (Jenc_checkRange(tmp, s->log2_min_tr_size, MIN(p->log2_ctb_size, 5)))
    goto out;
  s->log2_diff_tr_size = tmp - s->log2_min_tr_size;
  p->log2_max_tr_size = s->log2_min_tr_size + s->log2_diff_tr_size;
  ASSERT(1 << p->log2_max_tr_size == vcenc_instance->max_tr_size);

  /* Max transform hierarchy depth intra/inter */
  tmp = p->log2_ctb_size - s->log2_min_tr_size;
  if (Jenc_checkRange(vcenc_instance->tr_depth_intra, 0, tmp)) goto out;
  s->max_tr_hierarchy_depth_intra = vcenc_instance->tr_depth_intra;

  if (Jenc_checkRange(vcenc_instance->tr_depth_inter, 0, tmp)) goto out;
  s->max_tr_hierarchy_depth_inter = vcenc_instance->tr_depth_inter;

  s->scaling_list_enable_flag = vcenc_instance->enableScalingList;

  /* Parameter set id */
  if (Jenc_checkRange(vcenc_instance->vps_id, 0, 15)) goto out;
  v->ps.id = vcenc_instance->vps_id;

  if (Jenc_checkRange(vcenc_instance->sps_id, 0, 15)) goto out;
  s->ps.id = vcenc_instance->sps_id;
  s->vps_id = v->ps.id;

  if (Jenc_checkRange(vcenc_instance->pps_id, 0, 63)) goto out;
  p->ps.id = vcenc_instance->pps_id;
  p->sps_id = s->ps.id;

  /* TODO image cropping parameters */
  if (!(vcenc_instance->width > 0)) goto out;
  if (!(vcenc_instance->height > 0)) goto out;
  s->width = vcenc_instance->width;
  s->height = vcenc_instance->height;

  /* strong_intra_smoothing_enabled_flag */
  //if (Jenc_checkRange(s->strong_intra_smoothing_enabled_flag, 0, 1)) goto out;
  s->strong_intra_smoothing_enabled_flag = vcenc_instance->strong_intra_smoothing_enabled_flag;
  ASSERT((s->strong_intra_smoothing_enabled_flag == 0) || (s->strong_intra_smoothing_enabled_flag == 1));

  /* Default quantization parameter */
  if (Jenc_checkRange(vcenc_instance->rateControl.qpHdr >> QP_FRACTIONAL_BITS, 0, 51)) goto out;
  p->init_qp = vcenc_instance->rateControl.qpHdr >> QP_FRACTIONAL_BITS;

  /* Picture level rate control TODO... */
  if (Jenc_checkRange(vcenc_instance->rateControl.picRc, 0, 1)) goto out;

  p->cu_qp_delta_enabled_flag = ((vcenc_instance->asic.regs.rcRoiEnable != 0) || vcenc_instance->gdrDuration != 0) ? 1 : 0;
#ifdef INTERNAL_TEST
  p->cu_qp_delta_enabled_flag = (vcenc_instance->testId == TID_ROI) ? 1 : p->cu_qp_delta_enabled_flag;
#endif

  if (p->cu_qp_delta_enabled_flag == 0 && vcenc_instance->rateControl.ctbRc)
  {
    p->cu_qp_delta_enabled_flag = 1;
  }

  if(vcenc_instance->asic.regs.RefFrameUsingInputFrameEnable) {
    vcenc_instance->disableDeblocking = 1;
    vcenc_instance->enableSao = 0;
  }

  if (Jenc_vs_log2i(vcenc_instance->min_qp_size, &tmp)) goto out;
#if 1
  /* Get the qp size from command line. */
  p->diff_cu_qp_delta_depth = p->log2_ctb_size - tmp;
#else
  /* Make qp size the same as ctu now. FIXME: when qp size is different. */
  p->diff_cu_qp_delta_depth = 0;
#endif

  if (Jenc_checkRange(tmp, s->log2_min_cb_size, p->log2_ctb_size)) goto out;

  //tile
  p->tiles_enabled_flag = vcenc_instance->tiles_enabled_flag;
  p->num_tile_columns = vcenc_instance->num_tile_columns;
  p->num_tile_rows = vcenc_instance->num_tile_rows;
  p->loop_filter_across_tiles_enabled_flag = vcenc_instance->loop_filter_across_tiles_enabled_flag;

  /* Init the rest. TODO: tiles are not supported yet. How to get
   * slice/tiles from test_bench.c ? */
  if (Jenc_init_parameter_set(s, p)) goto out;
  p->deblocking_filter_disabled_flag = vcenc_instance->disableDeblocking;
  p->tc_offset = vcenc_instance->tc_Offset * 2;
  p->beta_offset = vcenc_instance->beta_Offset * 2;
  p->deblocking_filter_override_enabled_flag = vcenc_instance->enableDeblockOverride;


  p->cb_qp_offset = vcenc_instance->chromaQpOffset;
  p->cr_qp_offset = vcenc_instance->chromaQpOffset;

  s->sao_enabled_flag = vcenc_instance->enableSao;

  s->frameCropLeftOffset = vcenc_instance->preProcess.frameCropLeftOffset;
  s->frameCropRightOffset = vcenc_instance->preProcess.frameCropRightOffset;
  s->frameCropTopOffset = vcenc_instance->preProcess.frameCropTopOffset;
  s->frameCropBottomOffset = vcenc_instance->preProcess.frameCropBottomOffset;

  v->streamMode = vcenc_instance->asic.regs.streamMode;
  s->streamMode = vcenc_instance->asic.regs.streamMode;
  p->streamMode = vcenc_instance->asic.regs.streamMode;

  v->general_level_idc = vcenc_instance->level;
  s->general_level_idc = vcenc_instance->level;

  v->general_profile_idc = vcenc_instance->profile;
  s->general_profile_idc = vcenc_instance->profile;

  s->chroma_format_idc = vcenc_instance->asic.regs.codedChromaIdc;

  v->general_tier_flag = vcenc_instance->tier;
  s->general_tier_flag = vcenc_instance->tier;

  s->pcm_enabled_flag = vcenc_instance->pcm_enabled_flag;
  s->pcm_sample_bit_depth_luma_minus1 = vcenc_instance->Jenc_sps->bit_depth_luma_minus8+7;
  s->pcm_sample_bit_depth_chroma_minus1 = vcenc_instance->Jenc_sps->bit_depth_chroma_minus8+7;
  s->pcm_loop_filter_disabled_flag = vcenc_instance->pcm_loop_filter_disabled_flag;

  /* Set H264 Jenc_sps*/
  if (IS_H264(vcenc_instance->codecFormat))
  {
    /* Internal images, next macroblock boundary */
    i32 width = 16 * ((s->width + 15) / 16);
    i32 height = 16 * ((s->height + 15) / 16);
    i32 mbPerFrame = (width/16) * (height/16);
    if (vcenc_instance->interlaced)
    {
      s->frameMbsOnly = ENCHW_NO;
      /* Map unit 32-pixels high for fields */
      height = 32 * ((s->height + 31) / 32);
    }
    s->picWidthInMbsMinus1 = width / 16 - 1;
    s->picHeightInMapUnitsMinus1 = height / (16*(1+vcenc_instance->interlaced)) - 1;

    /* Set cropping parameters if required */
    if( s->width%16 || s->height%16 ||
        (vcenc_instance->interlaced && s->height%32))
    {
      s->frameCropping = ENCHW_YES;
    }
    else
    {
      s->frameCropping = ENCHW_NO;
    }

    /* Level 1b is indicated with levelIdc == 11 (later) and constraintSet3 */
    if(vcenc_instance->level == VCENC_H264_LEVEL_1_b)
    {
      s->constraintSet3 = ENCHW_YES;
    }

    /* Level 1b is indicated with levelIdc == 11 (constraintSet3) */
    if(vcenc_instance->level == VCENC_H264_LEVEL_1_b)
    {
        s->general_level_idc = 11;
    }

    /* Interlaced => main profile */
    if (vcenc_instance->interlaced >= 1 && s->general_profile_idc == 66)
      s->general_profile_idc = 77;

    p->transform8x8Mode = (s->general_profile_idc >= 100 ? ENCHW_YES : ENCHW_NO);
    p->entropy_coding_mode_flag = vcenc_instance->asic.regs.entropy_coding_mode_flag;

    /* always CABAC => main profile */
    if (s->general_profile_idc == 66) {
      ASSERT(p->entropy_coding_mode_flag == 0);
    }

    /*  always 8x8 transform enabled => high profile */
    ASSERT(p->transform8x8Mode == ENCHW_NO || s->general_profile_idc >= 100);

    /* set numRefFrame*/
    s->numRefFrames = s->max_dec_pic_buffering[0] - 1;
    vcenc_instance->frameNum = 0;
    vcenc_instance->idrPicId = 0;
    vcenc_instance->h264_mmo_nops = 0;
  }

  vcenc_instance->asic.regs.outputBitWidthLuma = s->bit_depth_luma_minus8;
  vcenc_instance->asic.regs.outputBitWidthChroma = s->bit_depth_chroma_minus8;

  p->lists_modification_present_flag = Jenc_check_ref_lists_modification(pEncIn);
  if(pEncIn->gopConfig.ltrcnt > 0)
    s->long_term_ref_pics_present_flag = 1;

#ifdef SUPPORT_AV1
  if (IS_AV1(vcenc_instance->codecFormat))
  {
    AV1SetParameter(vcenc_instance, s, p, v);
  }
#endif

#ifdef SUPPORT_VP9
  /*TODO: VP9 read profile from user*/
  if(IS_VP9(vcenc_instance->codecFormat))
  {
    VP9SetParameter(vcenc_instance, v, s);
  }
#endif

  return VCENC_OK;

out:
  /*
    The memory instances are allocated in Jenc_VCEncInit()
    should be released in Jenc_VCEncRelease()
    */
  //Jenc_free_parameter_set((struct ps *)v);
  //Jenc_free_parameter_set((struct ps *)s);
  //Jenc_free_parameter_set((struct ps *)p);

  return VCENC_ERROR;
}


VCEncRet Jenc_VCEncGetCodingCtrl(VCEncInst inst,
                                VCEncCodingCtrl *pCodeParams)
{
  struct vcenc_instance  *pEncInst = (struct vcenc_instance *) inst;
  /* Check for illegal inputs */
  if ((pEncInst == NULL) || (pCodeParams == NULL))
  {
    APITRACEERR("Jenc_VCEncGetCodingCtrl: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  regValues_s *regs = &pEncInst->asic.regs;
  i32 i;
  APITRACE("Jenc_VCEncGetCodingCtrl#");

  /* Check for existing instance */
  if (pEncInst->inst != pEncInst)
  {
    APITRACEERR("Jenc_VCEncGetCodingCtrl: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  pCodeParams->seiMessages =
    (pEncInst->rateControl.sei.enabled == ENCHW_YES) ? 1 : 0;

  pCodeParams->disableDeblockingFilter = pEncInst->disableDeblocking;
  pCodeParams->fieldOrder = pEncInst->fieldOrder;

  pCodeParams->sramPowerdownDisable = regs->sramPowerdownDisable;

  pCodeParams->tc_Offset = pEncInst->tc_Offset;
  pCodeParams->beta_Offset = pEncInst->beta_Offset;
  pCodeParams->enableSao = pEncInst->enableSao;
  pCodeParams->enableScalingList = pEncInst->enableScalingList;
  pCodeParams->vuiVideoFullRange =
    (pEncInst->Jenc_sps->vui.vuiVideoFullRange == ENCHW_YES) ? 1 : 0;
  pCodeParams->sampleAspectRatioWidth = pEncInst->sarWidth;
  pCodeParams->sampleAspectRatioHeight = pEncInst->sarHeight;
  pCodeParams->sliceSize = regs->sliceSize;

  pCodeParams->cabacInitFlag = regs->cabac_init_flag;
  pCodeParams->enableCabac = regs->entropy_coding_mode_flag;

  pCodeParams->cirStart = regs->cirStart;
  pCodeParams->cirInterval = regs->cirInterval;
  pCodeParams->intraArea.top    = regs->intraAreaTop;
  pCodeParams->intraArea.left   = regs->intraAreaLeft;
  pCodeParams->intraArea.bottom = regs->intraAreaBottom;
  pCodeParams->intraArea.right  = regs->intraAreaRight;
  if ((pCodeParams->intraArea.top <= pCodeParams->intraArea.bottom &&
       pCodeParams->intraArea.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->intraArea.left <= pCodeParams->intraArea.right &&
       pCodeParams->intraArea.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->intraArea.enable = 1;
  }
  else
  {
    pCodeParams->intraArea.enable = 0;
  }

  pCodeParams->ipcm1Area.top    = regs->ipcm1AreaTop;
  pCodeParams->ipcm1Area.left   = regs->ipcm1AreaLeft;
  pCodeParams->ipcm1Area.bottom = regs->ipcm1AreaBottom;
  pCodeParams->ipcm1Area.right  = regs->ipcm1AreaRight;
  if ((pCodeParams->ipcm1Area.top <= pCodeParams->ipcm1Area.bottom &&
       pCodeParams->ipcm1Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm1Area.left <= pCodeParams->ipcm1Area.right &&
       pCodeParams->ipcm1Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm1Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm1Area.enable = 0;
  }

  pCodeParams->ipcm2Area.top    = regs->ipcm2AreaTop;
  pCodeParams->ipcm2Area.left   = regs->ipcm2AreaLeft;
  pCodeParams->ipcm2Area.bottom = regs->ipcm2AreaBottom;
  pCodeParams->ipcm2Area.right  = regs->ipcm2AreaRight;
  if ((pCodeParams->ipcm2Area.top <= pCodeParams->ipcm2Area.bottom &&
       pCodeParams->ipcm2Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm2Area.left <= pCodeParams->ipcm2Area.right &&
       pCodeParams->ipcm2Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm2Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm2Area.enable = 0;
  }

  pCodeParams->ipcm3Area.top    = regs->ipcm3AreaTop;
  pCodeParams->ipcm3Area.left   = regs->ipcm3AreaLeft;
  pCodeParams->ipcm3Area.bottom = regs->ipcm3AreaBottom;
  pCodeParams->ipcm3Area.right  = regs->ipcm3AreaRight;
  if ((pCodeParams->ipcm3Area.top <= pCodeParams->ipcm3Area.bottom &&
       pCodeParams->ipcm3Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm3Area.left <= pCodeParams->ipcm3Area.right &&
       pCodeParams->ipcm3Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm3Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm3Area.enable = 0;
  }

  pCodeParams->ipcm4Area.top    = regs->ipcm4AreaTop;
  pCodeParams->ipcm4Area.left   = regs->ipcm4AreaLeft;
  pCodeParams->ipcm4Area.bottom = regs->ipcm4AreaBottom;
  pCodeParams->ipcm4Area.right  = regs->ipcm4AreaRight;
  if ((pCodeParams->ipcm4Area.top <= pCodeParams->ipcm4Area.bottom &&
       pCodeParams->ipcm4Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm4Area.left <= pCodeParams->ipcm4Area.right &&
       pCodeParams->ipcm4Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm4Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm4Area.enable = 0;
  }

  pCodeParams->ipcm5Area.top    = regs->ipcm5AreaTop;
  pCodeParams->ipcm5Area.left   = regs->ipcm5AreaLeft;
  pCodeParams->ipcm5Area.bottom = regs->ipcm5AreaBottom;
  pCodeParams->ipcm5Area.right  = regs->ipcm5AreaRight;
  if ((pCodeParams->ipcm5Area.top <= pCodeParams->ipcm5Area.bottom &&
       pCodeParams->ipcm5Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm5Area.left <= pCodeParams->ipcm5Area.right &&
       pCodeParams->ipcm5Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm5Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm5Area.enable = 0;
  }

  pCodeParams->ipcm6Area.top    = regs->ipcm6AreaTop;
  pCodeParams->ipcm6Area.left   = regs->ipcm6AreaLeft;
  pCodeParams->ipcm6Area.bottom = regs->ipcm6AreaBottom;
  pCodeParams->ipcm6Area.right  = regs->ipcm6AreaRight;
  if ((pCodeParams->ipcm6Area.top <= pCodeParams->ipcm6Area.bottom &&
       pCodeParams->ipcm6Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm6Area.left <= pCodeParams->ipcm6Area.right &&
       pCodeParams->ipcm6Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm6Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm6Area.enable = 0;
  }

  pCodeParams->ipcm7Area.top    = regs->ipcm7AreaTop;
  pCodeParams->ipcm7Area.left   = regs->ipcm7AreaLeft;
  pCodeParams->ipcm7Area.bottom = regs->ipcm7AreaBottom;
  pCodeParams->ipcm7Area.right  = regs->ipcm7AreaRight;
  if ((pCodeParams->ipcm7Area.top <= pCodeParams->ipcm7Area.bottom &&
       pCodeParams->ipcm7Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm7Area.left <= pCodeParams->ipcm7Area.right &&
       pCodeParams->ipcm7Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm7Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm7Area.enable = 0;
  }

  pCodeParams->ipcm8Area.top    = regs->ipcm8AreaTop;
  pCodeParams->ipcm8Area.left   = regs->ipcm8AreaLeft;
  pCodeParams->ipcm8Area.bottom = regs->ipcm8AreaBottom;
  pCodeParams->ipcm8Area.right  = regs->ipcm8AreaRight;
  if ((pCodeParams->ipcm8Area.top <= pCodeParams->ipcm8Area.bottom &&
       pCodeParams->ipcm8Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->ipcm8Area.left <= pCodeParams->ipcm8Area.right &&
       pCodeParams->ipcm8Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->ipcm8Area.enable = 1;
  }
  else
  {
    pCodeParams->ipcm8Area.enable = 0;
  }

  pCodeParams->roi1Area.top    = regs->roi1Top;
  pCodeParams->roi1Area.left   = regs->roi1Left;
  pCodeParams->roi1Area.bottom = regs->roi1Bottom;
  pCodeParams->roi1Area.right  = regs->roi1Right;
  if (pCodeParams->roi1Area.top <= pCodeParams->roi1Area.bottom &&
      pCodeParams->roi1Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi1Area.left <= pCodeParams->roi1Area.right &&
      pCodeParams->roi1Area.right < (u32)pEncInst->ctbPerRow)
  {
    pCodeParams->roi1Area.enable = 1;
  }
  else
  {
    pCodeParams->roi1Area.enable = 0;
  }

  pCodeParams->roi2Area.top    = regs->roi2Top;
  pCodeParams->roi2Area.left   = regs->roi2Left;
  pCodeParams->roi2Area.bottom = regs->roi2Bottom;
  pCodeParams->roi2Area.right  = regs->roi2Right;
  if ((pCodeParams->roi2Area.top <= pCodeParams->roi2Area.bottom &&
       pCodeParams->roi2Area.bottom < (u32)pEncInst->ctbPerCol &&
       pCodeParams->roi2Area.left <= pCodeParams->roi2Area.right &&
       pCodeParams->roi2Area.right < (u32)pEncInst->ctbPerRow))
  {
    pCodeParams->roi2Area.enable = 1;
  }
  else
  {
    pCodeParams->roi2Area.enable = 0;
  }

  pCodeParams->roi1DeltaQp = -regs->roi1DeltaQp;
  pCodeParams->roi2DeltaQp = -regs->roi2DeltaQp;
  pCodeParams->roi1Qp = regs->roi1Qp;
  pCodeParams->roi2Qp = regs->roi2Qp;

  pCodeParams->roi3Area.top = regs->roi3Top;
  pCodeParams->roi3Area.left = regs->roi3Left;
  pCodeParams->roi3Area.bottom = regs->roi3Bottom;
  pCodeParams->roi3Area.right = regs->roi3Right;
  if ((pCodeParams->roi3Area.top <= pCodeParams->roi3Area.bottom &&
      pCodeParams->roi3Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi3Area.left <= pCodeParams->roi3Area.right &&
      pCodeParams->roi3Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi3Area.enable = 1;
  }
  else
  {
      pCodeParams->roi3Area.enable = 0;
  }

  pCodeParams->roi4Area.top = regs->roi4Top;
  pCodeParams->roi4Area.left = regs->roi4Left;
  pCodeParams->roi4Area.bottom = regs->roi4Bottom;
  pCodeParams->roi4Area.right = regs->roi4Right;
  if ((pCodeParams->roi4Area.top <= pCodeParams->roi4Area.bottom &&
      pCodeParams->roi4Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi4Area.left <= pCodeParams->roi4Area.right &&
      pCodeParams->roi4Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi4Area.enable = 1;
  }
  else
  {
      pCodeParams->roi4Area.enable = 0;
  }

  pCodeParams->roi5Area.top = regs->roi5Top;
  pCodeParams->roi5Area.left = regs->roi5Left;
  pCodeParams->roi5Area.bottom = regs->roi5Bottom;
  pCodeParams->roi5Area.right = regs->roi5Right;
  if ((pCodeParams->roi5Area.top <= pCodeParams->roi5Area.bottom &&
      pCodeParams->roi5Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi5Area.left <= pCodeParams->roi5Area.right &&
      pCodeParams->roi5Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi5Area.enable = 1;
  }
  else
  {
      pCodeParams->roi5Area.enable = 0;
  }

  pCodeParams->roi6Area.top = regs->roi6Top;
  pCodeParams->roi6Area.left = regs->roi6Left;
  pCodeParams->roi6Area.bottom = regs->roi6Bottom;
  pCodeParams->roi6Area.right = regs->roi6Right;
  if ((pCodeParams->roi6Area.top <= pCodeParams->roi6Area.bottom &&
      pCodeParams->roi6Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi6Area.left <= pCodeParams->roi6Area.right &&
      pCodeParams->roi6Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi6Area.enable = 1;
  }
  else
  {
      pCodeParams->roi6Area.enable = 0;
  }

  pCodeParams->roi7Area.top = regs->roi7Top;
  pCodeParams->roi7Area.left = regs->roi7Left;
  pCodeParams->roi7Area.bottom = regs->roi7Bottom;
  pCodeParams->roi7Area.right = regs->roi7Right;
  if ((pCodeParams->roi7Area.top <= pCodeParams->roi7Area.bottom &&
      pCodeParams->roi7Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi7Area.left <= pCodeParams->roi7Area.right &&
      pCodeParams->roi7Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi7Area.enable = 1;
  }
  else
  {
      pCodeParams->roi7Area.enable = 0;
  }

  pCodeParams->roi8Area.top = regs->roi8Top;
  pCodeParams->roi8Area.left = regs->roi8Left;
  pCodeParams->roi8Area.bottom = regs->roi8Bottom;
  pCodeParams->roi8Area.right = regs->roi8Right;
  if ((pCodeParams->roi8Area.top <= pCodeParams->roi8Area.bottom &&
      pCodeParams->roi8Area.bottom < (u32)pEncInst->ctbPerCol &&
      pCodeParams->roi8Area.left <= pCodeParams->roi8Area.right &&
      pCodeParams->roi8Area.right < (u32)pEncInst->ctbPerRow))
  {
      pCodeParams->roi8Area.enable = 1;
  }
  else
  {
      pCodeParams->roi8Area.enable = 0;
  }

  pCodeParams->roi3DeltaQp = -regs->roi3DeltaQp;
  pCodeParams->roi4DeltaQp = -regs->roi4DeltaQp;
  pCodeParams->roi5DeltaQp = -regs->roi5DeltaQp;
  pCodeParams->roi6DeltaQp = -regs->roi6DeltaQp;
  pCodeParams->roi7DeltaQp = -regs->roi7DeltaQp;
  pCodeParams->roi8DeltaQp = -regs->roi8DeltaQp;
  pCodeParams->roi3Qp = regs->roi3Qp;
  pCodeParams->roi4Qp = regs->roi4Qp;
  pCodeParams->roi5Qp = regs->roi5Qp;
  pCodeParams->roi6Qp = regs->roi6Qp;
  pCodeParams->roi7Qp = regs->roi7Qp;
  pCodeParams->roi8Qp = regs->roi8Qp;

  pCodeParams->pcm_enabled_flag = pEncInst->pcm_enabled_flag;
  pCodeParams->pcm_loop_filter_disabled_flag = pEncInst->pcm_loop_filter_disabled_flag;


  pCodeParams->enableDeblockOverride = pEncInst->enableDeblockOverride;

  pCodeParams->deblockOverride = regs->slice_deblocking_filter_override_flag;

  pCodeParams->chroma_qp_offset = pEncInst->chromaQpOffset;

  pCodeParams->roiMapDeltaQpEnable       = pEncInst->roiMapDeltaQpEnable;
  pCodeParams->roiMapDeltaQpBlockUnit    = regs->diffCuQpDeltaDepth;
  pCodeParams->ipcmMapEnable             = regs->ipcmMapEnable;
  pCodeParams->RoimapCuCtrl_index_enable = pEncInst->RoimapCuCtrl_index_enable;
  pCodeParams->RoimapCuCtrl_enable       = pEncInst->RoimapCuCtrl_enable;
  pCodeParams->roiMapDeltaQpBinEnable    = pEncInst->roiMapDeltaQpBinEnable;
  pCodeParams->RoimapCuCtrl_ver          = pEncInst->RoimapCuCtrl_ver;
  pCodeParams->RoiQpDelta_ver            = pEncInst->RoiQpDelta_ver;

  /* SKIP map */
  pCodeParams->skipMapEnable = regs->skipMapEnable;

  /* RDOQ map */
  pCodeParams->rdoqMapEnable = regs->rdoqMapEnable;

  pCodeParams->gdrDuration = pEncInst->gdrEnabled ? pEncInst->gdrDuration : 0;

  VCEncHEVCDnfGetParameters(pEncInst, pCodeParams);

  /* low latency */
  pCodeParams->inputLineBufEn = pEncInst->inputLineBuf.inputLineBufEn;
  pCodeParams->inputLineBufLoopBackEn = pEncInst->inputLineBuf.inputLineBufLoopBackEn;
  pCodeParams->inputLineBufDepth = pEncInst->inputLineBuf.inputLineBufDepth;
  pCodeParams->amountPerLoopBack = pEncInst->inputLineBuf.amountPerLoopBack;
  pCodeParams->inputLineBufHwModeEn = pEncInst->inputLineBuf.inputLineBufHwModeEn;
  pCodeParams->inputLineBufCbFunc = pEncInst->inputLineBuf.cbFunc;
  pCodeParams->inputLineBufCbData = pEncInst->inputLineBuf.cbData;

  /*stream multi-segment*/
  pCodeParams->streamMultiSegmentMode = pEncInst->streamMultiSegment.streamMultiSegmentMode;
  pCodeParams->streamMultiSegmentAmount = pEncInst->streamMultiSegment.streamMultiSegmentAmount;
  pCodeParams->streamMultiSegCbFunc = pEncInst->streamMultiSegment.cbFunc;
  pCodeParams->streamMultiSegCbData = pEncInst->streamMultiSegment.cbData;

  /* smart */
  pCodeParams->smartModeEnable = pEncInst->smartModeEnable;
  pCodeParams->smartH264LumDcTh = pEncInst->smartH264LumDcTh;
  pCodeParams->smartH264CbDcTh = pEncInst->smartH264CbDcTh;
  pCodeParams->smartH264CrDcTh = pEncInst->smartH264CrDcTh;
  for(i = 0; i < 3; i++) {
    pCodeParams->smartHevcLumDcTh[i] = pEncInst->smartHevcLumDcTh[i];
    pCodeParams->smartHevcChrDcTh[i] = pEncInst->smartHevcChrDcTh[i];
    pCodeParams->smartHevcLumAcNumTh[i] = pEncInst->smartHevcLumAcNumTh[i];
    pCodeParams->smartHevcChrAcNumTh[i] = pEncInst->smartHevcChrAcNumTh[i];
  }
  pCodeParams->smartH264Qp = pEncInst->smartH264Qp;
  pCodeParams->smartHevcLumQp = pEncInst->smartHevcLumQp;
  pCodeParams->smartHevcChrQp = pEncInst->smartHevcChrQp;
  for(i = 0; i < 4; i++)
    pCodeParams->smartMeanTh[i] = pEncInst->smartMeanTh[i];
  pCodeParams->smartPixNumCntTh = pEncInst->smartPixNumCntTh;

  pCodeParams->tiles_enabled_flag = pEncInst->tiles_enabled_flag;
  pCodeParams->num_tile_columns = pEncInst->num_tile_columns;
  pCodeParams->num_tile_rows = pEncInst->num_tile_rows;
  pCodeParams->loop_filter_across_tiles_enabled_flag = pEncInst->loop_filter_across_tiles_enabled_flag;

  pCodeParams->Hdr10Display.hdr10_display_enable = pEncInst->Hdr10Display.hdr10_display_enable;
  pCodeParams->Hdr10Display.hdr10_dx0 = pEncInst->Hdr10Display.hdr10_dx0;
  pCodeParams->Hdr10Display.hdr10_dy0 = pEncInst->Hdr10Display.hdr10_dy0;
  pCodeParams->Hdr10Display.hdr10_dx1 = pEncInst->Hdr10Display.hdr10_dx1;
  pCodeParams->Hdr10Display.hdr10_dy1 = pEncInst->Hdr10Display.hdr10_dy1;
  pCodeParams->Hdr10Display.hdr10_dx2 = pEncInst->Hdr10Display.hdr10_dx2;
  pCodeParams->Hdr10Display.hdr10_dy2 = pEncInst->Hdr10Display.hdr10_dy2;
  pCodeParams->Hdr10Display.hdr10_wx  = pEncInst->Hdr10Display.hdr10_wx;
  pCodeParams->Hdr10Display.hdr10_wy  = pEncInst->Hdr10Display.hdr10_wy;
  pCodeParams->Hdr10Display.hdr10_maxluma = pEncInst->Hdr10Display.hdr10_maxluma;
  pCodeParams->Hdr10Display.hdr10_minluma = pEncInst->Hdr10Display.hdr10_minluma;
  pCodeParams->vuiColorDescription.vuiColorDescripPresentFlag   = pEncInst->vuiColorDescription.vuiColorDescripPresentFlag;
  pCodeParams->vuiColorDescription.vuiMatrixCoefficients        = pEncInst->vuiColorDescription.vuiMatrixCoefficients;
  pCodeParams->vuiColorDescription.vuiColorPrimaries            = pEncInst->vuiColorDescription.vuiColorPrimaries;
  pCodeParams->vuiColorDescription.vuiTransferCharacteristics   = pEncInst->vuiColorDescription.vuiTransferCharacteristics;


  pCodeParams->Hdr10LightLevel.hdr10_lightlevel_enable=pEncInst->Hdr10LightLevel.hdr10_lightlevel_enable;
  pCodeParams->Hdr10LightLevel.hdr10_maxlight=pEncInst->Hdr10LightLevel.hdr10_maxlight;
  pCodeParams->Hdr10LightLevel.hdr10_avglight=pEncInst->Hdr10LightLevel.hdr10_avglight;

  pCodeParams->vuiVideoSignalTypePresentFlag = pEncInst->vuiVideoSignalTypePresentFlag;
  pCodeParams->vuiVideoFormat                = pEncInst->vuiVideoFormat;

  pCodeParams->RpsInSliceHeader = pEncInst->RpsInSliceHeader;

  pCodeParams->enableRdoQuant = regs->bRDOQEnable;

  pCodeParams->enableDynamicRdo = regs->dynamicRdoEnable;
  pCodeParams->dynamicRdoCu16Bias = regs->dynamicRdoCu16Bias;
  pCodeParams->dynamicRdoCu16Factor = regs->dynamicRdoCu16Factor;
  pCodeParams->dynamicRdoCu32Bias = regs->dynamicRdoCu32Bias;
  pCodeParams->dynamicRdoCu32Factor = regs->dynamicRdoCu32Factor;
  /* Assigned ME vertical search range */
  pCodeParams->meVertSearchRange = regs->meAssignedVertRange << 3;

  /* some subjective quality params: aq_mode and psyFactor */
  pCodeParams->aq_mode = pEncInst->cuTreeCtl.aq_mode;
  pCodeParams->aq_strength = pEncInst->cuTreeCtl.aqStrength;
  pCodeParams->psyFactor = pEncInst->psyFactor;

  APITRACE("Jenc_VCEncGetCodingCtrl: OK");
  return VCENC_OK;
}

/* recalculate level based on RC parameters */
static VCEncLevel rc_recalculate_level(struct vcenc_instance *inst, u32 cpbSize, u32 bps)
{
    i32 i = 0, j = 0, levelIdx = inst->levelIdx;
    i32 maxLevel = 0;
    switch( inst->codecFormat )
    {
      case VCENC_VIDEO_CODEC_HEVC:
        maxLevel = HEVC_LEVEL_NUM - 1;
      break;
      case VCENC_VIDEO_CODEC_H264:
        maxLevel = H264_LEVEL_NUM - 1;
        break;

      case VCENC_VIDEO_CODEC_AV1:
        maxLevel = AV1_VALID_MAX_LEVEL - 1;
        break;

      case VCENC_VIDEO_CODEC_VP9:
        maxLevel = VP9_VALID_MAX_LEVEL - 1;
        break;

      default:
        break;
    }

    if (cpbSize > getMaxCPBS(inst->codecFormat, maxLevel, inst->profile, inst->tier))
    {
      APITRACEERR("rc_recalculate_level: WARNING Invalid cpbSize.");
      i = j = maxLevel;
    }
    if (bps > getMaxBR(inst->codecFormat, maxLevel, inst->profile, inst->tier))
    {
      APITRACEERR("rc_recalculate_level: WARNING Invalid bitsPerSecond.");
      i = j = maxLevel;
    }
    for(i = 0; i < maxLevel; i++)
    {
      if (cpbSize <= getMaxCPBS(inst->codecFormat, i, inst->profile, inst->tier))
        break;
    }
    for(j = 0; j < maxLevel; j++)
    {
      if (bps <= getMaxBR(inst->codecFormat, j, inst->profile, inst->tier))
        break;
    }

    levelIdx = MAX(levelIdx,MAX(i, j));
    return (getLevel(inst->codecFormat, levelIdx));
}
/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncSetRateCtrl
    Description   : Sets rate control parameters

    Return type   : VCEncRet
    Argument      : inst - the instance in use
                    pRateCtrl - user provided parameters
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncSetRateCtrl(VCEncInst inst, const VCEncRateCtrl *pRateCtrl)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (pRateCtrl == NULL))
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  vcencRateControl_s *rc;
  u32 i, tmp;
  i32 prevBitrate;
  regValues_s *regs = &vcenc_instance->asic.regs;
  i32 bitrateWindow;
  i32 rate_control_mode_change = 0;
  i32 frame_rate_change = 0;

  APITRACE("Jenc_VCEncSetRateCtrl#");
  APITRACEPARAM("pictureRc", pRateCtrl->pictureRc);
  APITRACEPARAM("pictureSkip", pRateCtrl->pictureSkip);
  APITRACEPARAM("qpHdr", pRateCtrl->qpHdr);
  APITRACEPARAM("qpMinPB", pRateCtrl->qpMinPB);
  APITRACEPARAM("qpMaxPB", pRateCtrl->qpMaxPB);
  APITRACEPARAM("qpMinI", pRateCtrl->qpMinI);
  APITRACEPARAM("qpMaxI", pRateCtrl->qpMaxI);
  APITRACEPARAM("bitPerSecond", pRateCtrl->bitPerSecond);
  APITRACEPARAM("hrd", pRateCtrl->hrd);
  APITRACEPARAM("hrdCpbSize", pRateCtrl->hrdCpbSize);
  APITRACEPARAM("bitrateWindow", pRateCtrl->bitrateWindow);
  APITRACEPARAM("intraQpDelta", pRateCtrl->intraQpDelta);
  APITRACEPARAM("fixedIntraQp", pRateCtrl->fixedIntraQp);
  APITRACEPARAM("bitVarRangeI", pRateCtrl->bitVarRangeI);
  APITRACEPARAM("bitVarRangeP", pRateCtrl->bitVarRangeP);
  APITRACEPARAM("bitVarRangeB", pRateCtrl->bitVarRangeB);
  APITRACEPARAM("staticSceneIbitPercent", pRateCtrl->u32StaticSceneIbitPercent);
  APITRACEPARAM("ctbRc", pRateCtrl->ctbRc);
  APITRACEPARAM("blockRCSize", pRateCtrl->blockRCSize);
  APITRACEPARAM("rcQpDeltaRange", pRateCtrl->rcQpDeltaRange);
  APITRACEPARAM("rcBaseMBComplexity", pRateCtrl->rcBaseMBComplexity);
  APITRACEPARAM("picQpDeltaMin", pRateCtrl->picQpDeltaMin);
  APITRACEPARAM("picQpDeltaMax", pRateCtrl->picQpDeltaMax);
  APITRACEPARAM("vbr", pRateCtrl->vbr);
  APITRACEPARAM("ctbRcQpDeltaReverse", pRateCtrl->ctbRcQpDeltaReverse);

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  rc = &vcenc_instance->rateControl;
  if (pRateCtrl->ctbRcQpDeltaReverse > 1)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR ctbRcQpDeltaReverse out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  rc->ctbRcQpDeltaReverse = pRateCtrl->ctbRcQpDeltaReverse;


  /* after stream was started with HRD ON,
   * it is not allowed to change RC params */
  if (vcenc_instance->encStatus == VCENCSTAT_START_FRAME && rc->hrd == ENCHW_YES)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Stream started with HRD ON. Not allowed to change any parameters");
    return VCENC_INVALID_STATUS;
  }

  if ((vcenc_instance->encStatus >= VCENCSTAT_START_STREAM)&&(vcenc_instance->ctbRCEnable != pRateCtrl->ctbRc))
  {
    APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid encoding status to config ctbRc");
    return VCENC_INVALID_ARGUMENT;
  }
  if ((HW_ID_MAJOR_NUMBER(regs->asicHwId) < 2 /* H2V1 */) && pRateCtrl->ctbRc)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR CTB RC not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Check for invalid input values */
  if (pRateCtrl->pictureRc > 1 ||
      pRateCtrl->pictureSkip > 1 || pRateCtrl->hrd > 1)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid enable/disable value");
    return VCENC_INVALID_ARGUMENT;
  }

  /* rate control mode has been changed. Only consider change between cbr and vbr. Constrain couple (hrd=1,vbr=0),(hrd=0,vbr=1)*/
  if(rc->hrd != (true_e)pRateCtrl->hrd || rc->vbr != (true_e)pRateCtrl->vbr)
  {
	rate_control_mode_change = 1;
  }

  if (pRateCtrl->qpHdr > 51 ||
      pRateCtrl->qpMinPB > 51 ||
      pRateCtrl->qpMaxPB > 51 ||
      pRateCtrl->qpMaxPB < pRateCtrl->qpMinPB ||
      pRateCtrl->qpMinI > 51 ||
      pRateCtrl->qpMaxI > 51 ||
      pRateCtrl->qpMaxI < pRateCtrl->qpMinI)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid QP");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((u32)(pRateCtrl->intraQpDelta + 51) > 102)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR intraQpDelta out of range");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pRateCtrl->fixedIntraQp > 51)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR fixedIntraQp out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pRateCtrl->bitrateWindow < 1 || pRateCtrl->bitrateWindow > 300)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid GOP length");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pRateCtrl->monitorFrames < LEAST_MONITOR_FRAME || pRateCtrl->monitorFrames > 120)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid monitorFrames");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pRateCtrl->blockRCSize > 2 || pRateCtrl->ctbRc > 3 ||
     (IS_AV1(vcenc_instance->codecFormat) && pRateCtrl->blockRCSize > 0)) //AV1 qpDelta in CTU level
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid blockRCSize");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Frame rate may change. */
  if(pRateCtrl->frameRateDenom == 0 || pRateCtrl->frameRateNum == 0)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid frameRateDenom, frameRateNum");
    return VCENC_INVALID_ARGUMENT;
  }

  if(rc->outRateNum != (i32)pRateCtrl->frameRateNum || rc->outRateDenom != (i32)pRateCtrl->frameRateDenom)
  {
    /*Though only when ((rc->outRateNum/rc->outRateDenom) != (i32)(pRateCtrl->frameRateNum/pRateCtrl->frameRateDenom)) the frame rate is changed,
    we consider all the situation as frame rate is changed, and Jenc_sps will change.*/
    frame_rate_change = 1;
    rc->outRateNum = pRateCtrl->frameRateNum;
    rc->outRateDenom = pRateCtrl->frameRateDenom;
  }

  /* Bitrate affects only when rate control is enabled */
  if ((pRateCtrl->pictureRc ||
       pRateCtrl->pictureSkip || pRateCtrl->hrd) &&
      (((pRateCtrl->bitPerSecond < 10000) &&(rc->outRateNum>rc->outRateDenom)) ||
      ((((pRateCtrl->bitPerSecond *rc->outRateDenom)/ rc->outRateNum)< 10000) && (rc->outRateNum<rc->outRateDenom)) ||
       pRateCtrl->bitPerSecond > VCENC_MAX_BITRATE))
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR Invalid bitPerSecond");
    return VCENC_INVALID_ARGUMENT;
  }

  /* HRD and VBR are conflict */
  if (pRateCtrl->hrd && pRateCtrl->vbr)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR HRD and VBR can not be enabled at the same time");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pRateCtrl->picQpDeltaMin > -1) || (pRateCtrl->picQpDeltaMin < -10) ||
      (pRateCtrl->picQpDeltaMax <  1) || (pRateCtrl->picQpDeltaMax >  10))
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR picQpRange out of range. Min:Max should be in [-1,-10]:[1,10]");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pRateCtrl->ctbRcRowQpStep < 0)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR ctbRowQpStep out of range");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pRateCtrl->ctbRc >= 2 && pRateCtrl->crf >= 0)
  {
    APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR crf is set with ctbRc>=2");
    return VCENC_INVALID_ARGUMENT;
  }

  {
    u32 cpbSize = pRateCtrl->hrdCpbSize;
    u32 bps = pRateCtrl->bitPerSecond;
    u32 level = vcenc_instance->levelIdx;
    u32 cpbMaxRate = pRateCtrl->cpbMaxRate;

    /* Limit maximum bitrate based on resolution and frame rate */
    /* Saturates really high settings */
    /* bits per unpacked frame */
    tmp = (vcenc_instance->Jenc_sps->bit_depth_chroma_minus8/2 + vcenc_instance->Jenc_sps->bit_depth_luma_minus8 + 12)
            * vcenc_instance->ctbPerFrame * vcenc_instance->max_cu_size * vcenc_instance->max_cu_size;
    rc->i32MaxPicSize = tmp;
    /* bits per second */
    tmp = MIN((((i64)Jenc_rcCalculate(tmp, rc->outRateNum, rc->outRateDenom))* 5 / 3),I32_MAX);
    if (bps > (u32)tmp)
      bps = (u32)tmp;

    if(vcenc_instance->bAutoLevel) {
        vcenc_instance->level = rc_recalculate_level(vcenc_instance, cpbSize, bps);
        level = vcenc_instance->levelIdx = getLevelIdx(vcenc_instance->codecFormat, vcenc_instance->level);
        if(vcenc_instance->level == -1)
        {
          return VCENC_INVALID_ARGUMENT;
        }
    }
    /* if HRD is ON we have to obay all its limits */
    if (pRateCtrl->hrd != 0)
    {
      if (cpbSize == 0)
        cpbSize = getMaxCPBS(vcenc_instance->codecFormat, level, vcenc_instance->profile, vcenc_instance->tier);
      else if (cpbSize == (u32)(-1))
        cpbSize = bps;
      if(cpbSize > 0x7FFFFFFF)
        cpbSize = 0x7FFFFFFF;

      if (cpbMaxRate == 0)
        cpbMaxRate = bps;

      /* Limit minimum CPB size based on average bits per frame */
      tmp = Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum);
      cpbSize = MAX(cpbSize, tmp);

      /* cpbSize must be rounded so it is exactly the size written in stream */
      i = 0;
      tmp = cpbSize;
      while (4095 < (tmp >> (4 + i++)));

      cpbSize = (tmp >> (4 + i)) << (4 + i);

      if (cpbSize > getMaxCPBS(vcenc_instance->codecFormat, level, vcenc_instance->profile, vcenc_instance->tier))
      {
        APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR. HRD is ON. hrdCpbSize higher than maximum allowed for stream level");
        return VCENC_INVALID_ARGUMENT;
      }

      if (bps > getMaxBR(vcenc_instance->codecFormat, level, vcenc_instance->profile, vcenc_instance->tier))
      {
        APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR. HRD is ON. bitPerSecond higher than maximum allowed for stream level");
        return VCENC_INVALID_ARGUMENT;
      }
    }

    if (cpbMaxRate || cpbSize)
    {
      /* if cpbMaxRate or cpbSize is set, cpbMaxRate can't < bps */
      cpbMaxRate = MAX(bps, cpbMaxRate);

      /* if cpbMaxRate is not 0, cpbSize mustn't be 0 and is set to default 2*bps*/
      if (cpbSize == 0) cpbSize = 2*bps;
    }

    rc->virtualBuffer.bufferSize = cpbSize;
    rc->virtualBuffer.maxBitRate = cpbMaxRate;
    // rc->virtualBuffer.bufferRate = cpbMaxRate * rc->outRateDenom / rc->outRateNum;

    /* Set the parameters to rate control */
    if (pRateCtrl->pictureRc != 0)
      rc->picRc = ENCHW_YES;
    else
      rc->picRc = ENCHW_NO;

    /* CTB_RC */
    vcenc_instance->rateControl.rcQpDeltaRange = pRateCtrl->rcQpDeltaRange;
    vcenc_instance->rateControl.rcBaseMBComplexity = pRateCtrl->rcBaseMBComplexity;
    vcenc_instance->rateControl.picQpDeltaMin = pRateCtrl->picQpDeltaMin;
    vcenc_instance->rateControl.picQpDeltaMax = pRateCtrl->picQpDeltaMax;
    if (pRateCtrl->ctbRc)
    {
      u32 maxCtbRcQpDelta = (regs->asicCfg.ctbRcVersion > 1) ? 51 : 15;
      rc->ctbRc = pRateCtrl->ctbRc;

      /* look-ahead always use fixed-QP */
      if (vcenc_instance->pass == 1)
        rc->ctbRc = 0;

      /* If CTB QP adjustment for Rate Control not supported, just disable it, not return error. */
      if (IS_CTBRC_FOR_BITRATE(rc->ctbRc) && (regs->asicCfg.ctbRcVersion == 0))
      {
        CLR_CTBRC_FOR_BITRATE(rc->ctbRc);
        APITRACEERR("Jenc_VCEncSetRateCtrl: ERROR CTB QP adjustment for Rate Control not supported, Disabled it");
      }

      if (vcenc_instance->rateControl.rcQpDeltaRange > maxCtbRcQpDelta)
      {
        vcenc_instance->rateControl.rcQpDeltaRange = maxCtbRcQpDelta;
        APITRACEERR("Jenc_VCEncSetRateCtrl: rcQpDeltaRange too big, Clipped it into valid range");
      }

      vcenc_instance->ctbRCEnable = rc->ctbRc;
      if (IS_CTBRC_FOR_BITRATE(rc->ctbRc)) rc->picRc = ENCHW_YES;
      vcenc_instance->blockRCSize = pRateCtrl->blockRCSize;
      if(vcenc_instance->min_qp_size > (64 >> vcenc_instance->blockRCSize))
         vcenc_instance->min_qp_size = (64 >> vcenc_instance->blockRCSize);
    }
    else
    {
      rc->ctbRc = 0;
      vcenc_instance->ctbRCEnable = 0;
    }

    if (pRateCtrl->pictureSkip != 0)
      rc->picSkip = ENCHW_YES;
    else
      rc->picSkip = ENCHW_NO;

    if (pRateCtrl->hrd != 0)
    {
      rc->hrd = ENCHW_YES;
      rc->picRc = ENCHW_YES;
    }
    else
      rc->hrd = ENCHW_NO;

    rc->vbr = pRateCtrl->vbr ? ENCHW_YES : ENCHW_NO;
    rc->qpHdr = pRateCtrl->qpHdr << QP_FRACTIONAL_BITS;
    rc->qpMinPB = pRateCtrl->qpMinPB << QP_FRACTIONAL_BITS;
    rc->qpMaxPB = pRateCtrl->qpMaxPB << QP_FRACTIONAL_BITS;
    rc->qpMinI = pRateCtrl->qpMinI << QP_FRACTIONAL_BITS;
    rc->qpMaxI = pRateCtrl->qpMaxI << QP_FRACTIONAL_BITS;
    prevBitrate = rc->virtualBuffer.bitRate;
    rc->virtualBuffer.bitRate = bps;
    bitrateWindow = rc->bitrateWindow;
    rc->bitrateWindow = pRateCtrl->bitrateWindow;
    rc->maxPicSizeI = MIN(((((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) / 100)* (100 + pRateCtrl->bitVarRangeI)),rc->i32MaxPicSize);
    rc->maxPicSizeP = MIN(((((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) / 100)* (100 + pRateCtrl->bitVarRangeP)),rc->i32MaxPicSize);
    rc->maxPicSizeB = MIN(((((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) / 100)* (100 + pRateCtrl->bitVarRangeB)),rc->i32MaxPicSize);

    rc->minPicSizeI = (i32)(((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) * 100/ (100 + pRateCtrl->bitVarRangeI));
    rc->minPicSizeP = (i32)(((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) * 100/ (100 + pRateCtrl->bitVarRangeP));
    rc->minPicSizeB = (i32)(((i64)Jenc_rcCalculate(bps, rc->outRateDenom, rc->outRateNum)) * 100/ (100 + pRateCtrl->bitVarRangeB));

    rc->tolMovingBitRate = pRateCtrl->tolMovingBitRate;
    rc->f_tolMovingBitRate = (float)rc->tolMovingBitRate;
    rc->monitorFrames = pRateCtrl->monitorFrames;
    rc->u32StaticSceneIbitPercent = pRateCtrl->u32StaticSceneIbitPercent;
    rc->tolCtbRcInter = pRateCtrl->tolCtbRcInter;
    rc->tolCtbRcIntra = pRateCtrl->tolCtbRcIntra;
    rc->ctbRateCtrl.qpStep = ((pRateCtrl->ctbRcRowQpStep << CTB_RC_QP_STEP_FIXP) + rc->ctbCols/2) / rc->ctbCols;
  }

  rc->intraQpDelta = pRateCtrl->intraQpDelta << QP_FRACTIONAL_BITS;
  rc->fixedIntraQp = pRateCtrl->fixedIntraQp << QP_FRACTIONAL_BITS;
  rc->frameQpDelta = 0 << QP_FRACTIONAL_BITS ;
  rc->smooth_psnr_in_gop = pRateCtrl->smoothPsnrInGOP;
  rc->longTermQpDelta = pRateCtrl->longTermQpDelta << QP_FRACTIONAL_BITS;

  /*CRF parameters: pb and ip offset is set to default value
    Todo: set it available to user*/
  rc->crf = pRateCtrl->crf;
  //rc->pbOffset = 6.0 * LOG2(1.3f);
  //rc->ipOffset = 6.0 * LOG2(1.4f);
  rc->pbOffset = 6.0 * 0.378512;
  rc->ipOffset = 6.0 * 0.485427;

  /* New parameters checked already so ignore return value.
  * Reset RC bit counters when changing bitrate. */
  (void)JencVCEncInitRc(rc, (vcenc_instance->encStatus == VCENCSTAT_INIT) ||
                    (rc->virtualBuffer.bitRate != prevBitrate)||
                    (bitrateWindow != rc->bitrateWindow) || rate_control_mode_change || frame_rate_change);

  if (vcenc_instance->encStatus <= VCENCSTAT_START_STREAM && vcenc_instance->bInputfileList) {
      memcpy(&vcenc_instance->rateControl_ori, pRateCtrl, sizeof(*pRateCtrl));
   }

  if(vcenc_instance->pass==2) {
    VCEncRet ret = Jenc_VCEncSetRateCtrl(vcenc_instance->lookahead.priv_inst, pRateCtrl);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncSetRateCtrl: LookaheadSetRateCtrl failed");
      return ret;
    }
  }

  vcenc_instance->asic.regs.bRateCtrlUpdate = 1;
  APITRACE("Jenc_VCEncSetRateCtrl: OK");
  return VCENC_OK;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncGetRateCtrl
    Description   : Return current rate control parameters

    Return type   : VCEncRet
    Argument      : inst - the instance in use
                    pRateCtrl - place where parameters are returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncGetRateCtrl(VCEncInst inst, VCEncRateCtrl *pRateCtrl)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  vcencRateControl_s *rc;

  APITRACE("Jenc_VCEncGetRateCtrl#");

  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (pRateCtrl == NULL))
  {
    APITRACEERR("Jenc_VCEncGetRateCtrl: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncGetRateCtrl: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  /* Get the values */
  rc = &vcenc_instance->rateControl;

  pRateCtrl->pictureRc = rc->picRc == ENCHW_NO ? 0 : 1;
  /* CTB RC */
  pRateCtrl->ctbRc = rc->ctbRc;
  pRateCtrl->pictureSkip = rc->picSkip == ENCHW_NO ? 0 : 1;
  pRateCtrl->qpHdr = rc->qpHdr >> QP_FRACTIONAL_BITS;
  pRateCtrl->qpMinPB = rc->qpMinPB >> QP_FRACTIONAL_BITS;
  pRateCtrl->qpMaxPB = rc->qpMaxPB >> QP_FRACTIONAL_BITS;
  pRateCtrl->qpMinI = rc->qpMinI >> QP_FRACTIONAL_BITS;
  pRateCtrl->qpMaxI = rc->qpMaxI >> QP_FRACTIONAL_BITS;
  pRateCtrl->bitPerSecond = rc->virtualBuffer.bitRate;
  pRateCtrl->cpbMaxRate = rc->virtualBuffer.maxBitRate;
  if (rc->virtualBuffer.bitPerPic)
  {
    pRateCtrl->bitVarRangeI = (i32)(((i64)rc->maxPicSizeI) * 100/ rc->virtualBuffer.bitPerPic - 100);
    pRateCtrl->bitVarRangeP = (i32)(((i64)rc->maxPicSizeP) * 100/ rc->virtualBuffer.bitPerPic - 100);
    pRateCtrl->bitVarRangeB = (i32)(((i64)rc->maxPicSizeB) * 100/ rc->virtualBuffer.bitPerPic - 100);
  }
  else
  {
    pRateCtrl->bitVarRangeI = 10000;
    pRateCtrl->bitVarRangeP = 10000;
    pRateCtrl->bitVarRangeB = 10000;
  }
  pRateCtrl->hrd = rc->hrd == ENCHW_NO ? 0 : 1;
  pRateCtrl->bitrateWindow = rc->bitrateWindow;
  pRateCtrl->targetPicSize = rc->targetPicSize;

  pRateCtrl->hrdCpbSize = (u32) rc->virtualBuffer.bufferSize;
  pRateCtrl->intraQpDelta = rc->intraQpDelta >> QP_FRACTIONAL_BITS;
  pRateCtrl->fixedIntraQp = rc->fixedIntraQp >> QP_FRACTIONAL_BITS;
  pRateCtrl->monitorFrames = rc->monitorFrames;
  pRateCtrl->u32StaticSceneIbitPercent = rc->u32StaticSceneIbitPercent;
  pRateCtrl->tolMovingBitRate = rc->tolMovingBitRate;
  pRateCtrl->tolCtbRcInter = rc->tolCtbRcInter;
  pRateCtrl->tolCtbRcIntra = rc->tolCtbRcIntra;
  pRateCtrl->ctbRcRowQpStep = rc->ctbRateCtrl.qpStep ?
    ((rc->ctbRateCtrl.qpStep*rc->ctbCols + (1<<(CTB_RC_QP_STEP_FIXP-1))) >> CTB_RC_QP_STEP_FIXP) : 0;
  pRateCtrl->longTermQpDelta = rc->longTermQpDelta >> QP_FRACTIONAL_BITS;

  pRateCtrl->blockRCSize = vcenc_instance->blockRCSize ;
  pRateCtrl->rcQpDeltaRange = vcenc_instance->rateControl.rcQpDeltaRange;
  pRateCtrl->rcBaseMBComplexity= vcenc_instance->rateControl.rcBaseMBComplexity;
  pRateCtrl->picQpDeltaMin = vcenc_instance->rateControl.picQpDeltaMin;
  pRateCtrl->picQpDeltaMax = vcenc_instance->rateControl.picQpDeltaMax;
  pRateCtrl->vbr = rc->vbr == ENCHW_NO ? 0 : 1;
  pRateCtrl->ctbRcQpDeltaReverse = rc->ctbRcQpDeltaReverse;
  pRateCtrl->crf = rc->crf;

  APITRACE("Jenc_VCEncGetRateCtrl: OK");
  return VCENC_OK;
}


/*------------------------------------------------------------------------------
    Function name   : Jenc_VSCheckSize
    Description     :
    Return type     : i32
    Argument        : u32 inputWidth
    Argument        : u32 inputHeight
    Argument        : u32 stabilizedWidth
    Argument        : u32 stabilizedHeight
------------------------------------------------------------------------------*/
i32 Jenc_VSCheckSize(u32 inputWidth, u32 inputHeight, u32 stabilizedWidth,
                      u32 stabilizedHeight)
{
    /* Input picture minimum dimensions */
    if((inputWidth < 104) || (inputHeight < 104))
        return 1;

    /* Stabilized picture minimum  values */
    if((stabilizedWidth < 96) || (stabilizedHeight < 96))
        return 1;

    /* Stabilized dimensions multiple of 4 */
    if(((stabilizedWidth & 3) != 0) || ((stabilizedHeight & 3) != 0))
        return 1;

    /* Edge >= 4 pixels, not checked because stabilization can be
     * used without cropping for scene change detection
    if((inputWidth < (stabilizedWidth + 8)) ||
       (inputHeight < (stabilizedHeight + 8)))
        return 1; */

    return 0;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_osd_overlap
    Description     : check osd input overlap
    Return type     : VCEncRet
    Argument        : pPreProcCfg - user provided parameters
    Argument        : i - osd channel to check
------------------------------------------------------------------------------*/
VCEncRet Jenc_osd_overlap(const VCEncPreProcessingCfg *pPreProcCfg, u8 id, VCEncVideoCodecFormat format)
{
  int i,tmpx, tmpy;
  int blockW = 64;
  int blockH = (format == VCENC_VIDEO_CODEC_H264)?16:64;
  VCEncOverlayArea area0 = pPreProcCfg->overlayArea[id];
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    if(!pPreProcCfg->overlayArea[i].enable || i == id) continue;

    VCEncOverlayArea area1 = pPreProcCfg->overlayArea[i];

    if(!((area0.xoffset+area0.cropWidth) <= area1.xoffset || (area0.yoffset + area0.cropHeight) <= area1.yoffset ||
       area0.xoffset >= (area1.xoffset + area1.cropWidth) || area0.yoffset >= (area1.yoffset + area1.cropHeight)))
    {
      return VCENC_ERROR;
    }

    /* Check not share CTB: avoid loop all ctb */
    if((area0.xoffset+area0.cropWidth) <= area1.xoffset && (area0.yoffset+area0.cropHeight) <= area1.yoffset)
    {
      tmpx = ((area0.xoffset+area0.cropWidth -1)/blockW) * blockW;
      tmpy = ((area0.yoffset+area0.cropHeight -1)/blockH) * blockH;

      if(tmpx + blockW  > area1.xoffset && tmpy + blockH  > area1.yoffset)
      {
        return VCENC_ERROR;
      }
    }
    else if((area0.xoffset+area0.cropWidth) <= area1.xoffset && area0.yoffset >= (area1.yoffset + area1.cropHeight))
    {
      tmpx = ((area0.xoffset+area0.cropWidth -1)/blockW) * blockW;
      tmpy = ((area1.yoffset + area1.cropHeight - 1)/blockH) * blockH;
      if(tmpx + blockW  > area1.xoffset && tmpy + blockH > area0.yoffset)
      {
        return VCENC_ERROR;
      }
    }
    else if(area0.xoffset >= (area1.xoffset + area1.cropWidth) && (area0.yoffset+area0.cropHeight) <= area1.yoffset)
    {
      tmpx = ((area1.xoffset+area1.cropWidth -1)/blockW) * blockW;
      tmpy = ((area0.yoffset + area0.cropHeight -1)/blockH) * blockH;
      if(tmpx + blockW > area0.xoffset && tmpy + blockH > area1.yoffset)
      {
        return VCENC_ERROR;
      }
    }
    else if(area0.xoffset >= (area1.xoffset + area1.cropWidth) && area0.yoffset >= (area1.yoffset + area1.cropHeight))
    {
      tmpx = ((area1.xoffset+area1.cropWidth - 1)/blockW) * blockW;
      tmpy = ((area1.yoffset + area1.cropHeight - 1)/blockH) * blockH;
      if(tmpx + blockW > area0.xoffset && tmpy + blockH > area0.yoffset)
      {
        return VCENC_ERROR;
      }
    }
    else if((area0.xoffset+area0.cropWidth) <= area1.xoffset)
    {
      tmpx = ((area0.xoffset+area0.cropWidth - 1)/blockW) * blockW;
      if(tmpx + blockW > area1.xoffset)
        return VCENC_ERROR;
    }
    else if((area0.yoffset+area0.cropHeight) <= area1.yoffset)
    {
      tmpy = ((area0.yoffset+area0.cropHeight - 1)/blockH) * blockH;
      if(tmpy + blockH > area1.yoffset)
        return VCENC_ERROR;
    }
    else if(area0.xoffset >= (area1.xoffset + area1.cropWidth))
    {
      tmpx = ((area1.xoffset+area1.cropWidth - 1)/blockW) * blockW;
      if(tmpx + blockW > area0.xoffset)
        return VCENC_ERROR;
    }
    else if(area0.yoffset >= (area1.yoffset + area1.cropHeight))
    {
      tmpy = ((area1.yoffset+area1.cropHeight - 1)/blockH) * blockH;
      if(tmpy + blockH > area0.yoffset)
        return VCENC_ERROR;
    }
  }

  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncSetPreProcessing
    Description     : Sets the preprocessing parameters
    Return type     : VCEncRet
    Argument        : inst - encoder instance in use
    Argument        : pPreProcCfg - user provided parameters
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncSetPreProcessing(VCEncInst inst, const VCEncPreProcessingCfg *pPreProcCfg)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s pp_tmp;
  asicData_s *asic = &vcenc_instance->asic;
  u32 client_type;

  APITRACE("Jenc_VCEncSetPreProcessing#");
  APITRACEPARAM("origWidth", pPreProcCfg->origWidth);
  APITRACEPARAM("origHeight", pPreProcCfg->origHeight);
  APITRACEPARAM("xOffset", pPreProcCfg->xOffset);
  APITRACEPARAM("yOffset", pPreProcCfg->yOffset);
  APITRACEPARAM("inputType", pPreProcCfg->inputType);
  APITRACEPARAM("rotation", pPreProcCfg->rotation);
  APITRACEPARAM("mirror", pPreProcCfg->mirror);
  APITRACEPARAM("colorConversion.type", pPreProcCfg->colorConversion.type);
  APITRACEPARAM("colorConversion.coeffA", pPreProcCfg->colorConversion.coeffA);
  APITRACEPARAM("colorConversion.coeffB", pPreProcCfg->colorConversion.coeffB);
  APITRACEPARAM("colorConversion.coeffC", pPreProcCfg->colorConversion.coeffC);
  APITRACEPARAM("colorConversion.coeffE", pPreProcCfg->colorConversion.coeffE);
  APITRACEPARAM("colorConversion.coeffF", pPreProcCfg->colorConversion.coeffF);
  APITRACEPARAM("scaledWidth", pPreProcCfg->scaledWidth);
  APITRACEPARAM("scaledHeight", pPreProcCfg->scaledHeight);
  APITRACEPARAM("scaledOutput", pPreProcCfg->scaledOutput);
  APITRACEPARAM_X("virtualAddressScaledBuff", pPreProcCfg->virtualAddressScaledBuff);
  APITRACEPARAM("busAddressScaledBuff", pPreProcCfg->busAddressScaledBuff);
  APITRACEPARAM("sizeScaledBuff", pPreProcCfg->sizeScaledBuff);
  APITRACEPARAM("constChromaEn", pPreProcCfg->constChromaEn);
  APITRACEPARAM("constCb", pPreProcCfg->constCb);
  APITRACEPARAM("constCr", pPreProcCfg->constCr);

  /* Check for illegal inputs */
  if ((inst == NULL) || (pPreProcCfg == NULL))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  /* check HW limitations */
  u32 i = 0;
  i32 core_id = -1;

  client_type = VCEncGetClientType(vcenc_instance->codecFormat);
  JENC_EWLHwConfig_t cfg = JencEncAsicGetAsicConfig(client_type,vcenc_instance->ctx);

  if (client_type == JENC_EWL_CLIENT_TYPE_H264_ENC && cfg.h264Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_HEVC_ENC && cfg.hevcEnabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_AV1_ENC && cfg.av1Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_VP9_ENC && cfg.vp9Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (cfg.rgbEnabled == EWL_HW_CONFIG_NOT_SUPPORTED &&
    pPreProcCfg->inputType >= VCENC_RGB565 &&
    pPreProcCfg->inputType <= VCENC_BGR101010)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR RGB input core not supported");
    return VCENC_INVALID_ARGUMENT;
  }
  if (cfg.scalingEnabled == EWL_HW_CONFIG_NOT_SUPPORTED &&
    pPreProcCfg->scaledOutput != 0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: WARNING Scaling core not supported, disabling output");
    return VCENC_INVALID_ARGUMENT;
  }
  if (cfg.cscExtendSupport == EWL_HW_CONFIG_NOT_SUPPORTED &&
    (pPreProcCfg->colorConversion.type >= VCENC_RGBTOYUV_BT601_FULL_RANGE) &&
    (pPreProcCfg->colorConversion.type <=VCENC_RGBTOYUV_BT709_FULL_RANGE))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: WARNING color conversion extend not supported, set to BT601_l.mat");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((cfg.NVFormatOnlySupport == EWL_HW_CONFIG_ENABLED) && ((pPreProcCfg->inputType < 1) || (pPreProcCfg->inputType > 2)))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR input format only support NV12 or NV21 by HW");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((cfg.NonRotationSupport == EWL_HW_CONFIG_ENABLED) && (pPreProcCfg->rotation != 0))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR rotation not supported by HW");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->colorConversion.type == VCENC_RGBTOYUV_USER_DEFINED) &&
    (cfg.cscExtendSupport == EWL_HW_CONFIG_NOT_SUPPORTED) &&
    ((pPreProcCfg->colorConversion.coeffG != pPreProcCfg->colorConversion.coeffE) ||
     (pPreProcCfg->colorConversion.coeffH != pPreProcCfg->colorConversion.coeffF) ||
     (pPreProcCfg->colorConversion.LumaOffset != 0)))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR color conversion extend not supported, invalid coefficient");
    return VCENC_INVALID_ARGUMENT;
  }

  if (cfg.scaled420Support == EWL_HW_CONFIG_NOT_SUPPORTED && pPreProcCfg->scaledOutput != 0 &&
    pPreProcCfg->scaledOutputFormat == 1)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Scaling to 420SP core not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  if (cfg.inLoopDSRatio == EWL_HW_CONFIG_ENABLED && vcenc_instance->pass == 1 &&
    pPreProcCfg->inputType >= VCENC_YUV420_10BIT_PACKED_Y0L2 &&
    pPreProcCfg->inputType < VCENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4 &&
    pPreProcCfg->inputType > VCENC_YUV420_PLANAR_10BIT_P010_TILE_4_4 &&
    pPreProcCfg->inputType <= VCENC_YUV420_VU_10BIT_TILE_96_2)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR in-loop down-scaler not supported by this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if (cfg.scaled420Support == EWL_HW_CONFIG_ENABLED && pPreProcCfg->scaledOutput != 0 &&
    (!((((double)vcenc_instance->width / pPreProcCfg->scaledWidth) >= 1) && (((double)vcenc_instance->width / pPreProcCfg->scaledWidth) <= 32) &&
     (((double)vcenc_instance->height / pPreProcCfg->scaledHeight) >= 1) && (((double)vcenc_instance->height / pPreProcCfg->scaledHeight) <= 32)))
    )
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Scaling ratio not supported");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->inputType >= VCENC_RGB565 && pPreProcCfg->inputType <= VCENC_BGR101010)
    vcenc_instance->featureToSupport.rgbEnabled = 1;
  else
    vcenc_instance->featureToSupport.rgbEnabled = 0;

  if (pPreProcCfg->scaledOutput != 0)
    vcenc_instance->featureToSupport.scalingEnabled = 1;
  else
    vcenc_instance->featureToSupport.scalingEnabled = 0;

  if (vcenc_instance->pass != 1)
  {
    /* HW limit: width/height should be 8-pixel aligned for AV1 or VP9+rotation */
    if (IS_AV1(vcenc_instance->codecFormat) &&
        ((vcenc_instance->preProcess.lumWidth & 7) || (vcenc_instance->preProcess.lumHeight & 7)))
    {
      APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR support only 8-pixel aligned width/height for AV1");
      return VCENC_INVALID_ARGUMENT;
    }
    else if(IS_VP9(vcenc_instance->codecFormat))
    {
      true_e picWidthInvalidInVp9  = ((pPreProcCfg->rotation != VCENC_ROTATE_0) || (pPreProcCfg->mirror != VCENC_MIRROR_NO)) && ( 0 != (vcenc_instance->preProcess.lumWidth & 7));
      true_e picHeightInvalidInVp9 = (pPreProcCfg->rotation != VCENC_ROTATE_0)  && ( 0 != (vcenc_instance->preProcess.lumHeight & 7));
      if( picWidthInvalidInVp9 || picHeightInvalidInVp9 )
      {
        APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR support only 8-pixel aligned width/height for VP9 when mirror or rotation");
        return VCENC_INVALID_ARGUMENT;
      }
    }
  }

  if (pPreProcCfg->origWidth > VCENC_MAX_PP_INPUT_WIDTH)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Input image width is too big");
    return VCENC_INVALID_ARGUMENT;
  }
#if 1
  /* Scaled image width limits, multiple of 4 (YUYV) and smaller than input */
  if ((pPreProcCfg->scaledWidth > (u32)vcenc_instance->width) ||
      ((pPreProcCfg->scaledWidth & 0x1) != 0) ||
      (pPreProcCfg->scaledWidth > DOWN_SCALING_MAX_WIDTH))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: Invalid scaledWidth");
    return VCENC_INVALID_ARGUMENT;
  }

  if (((i32)pPreProcCfg->scaledHeight > vcenc_instance->height) ||
      (pPreProcCfg->scaledHeight & 0x1) != 0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: Invalid scaledHeight");
    return VCENC_INVALID_ARGUMENT;
  }
#endif
  if (pPreProcCfg->inputType >= VCENC_FORMAT_MAX)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid YUV type");
    return VCENC_INVALID_ARGUMENT;
  }
  if ((pPreProcCfg->inputType == VCENC_YUV420_PLANAR_10BIT_I010
  ||pPreProcCfg->inputType == VCENC_YUV420_PLANAR_10BIT_P010
  ||pPreProcCfg->inputType == VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR
  ||pPreProcCfg->inputType == VCENC_YUV420_10BIT_PACKED_Y0L2
  ||pPreProcCfg->inputType == VCENC_YUV420_PLANAR_10BIT_P010_TILE_4_4
  ||pPreProcCfg->inputType == VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC
  ||pPreProcCfg->inputType == VCENC_YUV420_PLANAR_8BIT_DAHUA_H264)&&(HW_ID_MAJOR_NUMBER(asic->regs.asicHwId)<4))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid YUV type, HW not support I010 format.");
    return VCENC_INVALID_ARGUMENT;
  }

  if(pPreProcCfg->inputType == VCENC_YUV420_FBC && (asic->regs.asicHwId < 0x80006010 || asic->regs.asicHwId >= 0x80006100))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid YUV type, HW not support FBC format.");
    return VCENC_INVALID_ARGUMENT;
  }

  if(pPreProcCfg->inputType == VCENC_YUV420_FBC && pPreProcCfg->rotation > VCENC_ROTATE_0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid rotation, FBC format does not support rotate.");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->inputType == VCENC_YUV420_FBC && pPreProcCfg->mirror == VCENC_MIRROR_YES)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid mirror, FBC format does not support rotate.");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->rotation > VCENC_ROTATE_180R)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid rotation");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->mirror > VCENC_MIRROR_YES)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid mirror");
    return VCENC_INVALID_ARGUMENT;
  }

  if ( (vcenc_instance->inputLineBuf.inputLineBufEn) && ((pPreProcCfg->rotation!=0) || (pPreProcCfg->mirror!=0)
                                                     || (pPreProcCfg->videoStabilization!=0)) )
  {
    APITRACE("Jenc_VCEncSetPreProcessing: ERROR Cannot do rotation, stabilization, and mirror in low latency mode");
    return VCENC_INVALID_ARGUMENT;
  }

#if 0
  if (((pPreProcCfg->xOffset & 1) != 0) || ((pPreProcCfg->yOffset & 1) != 0))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset");
    return VCENC_INVALID_ARGUMENT;
  }
#endif

  if (pPreProcCfg->inputType == VCENC_YUV420_SEMIPLANAR_101010 && (pPreProcCfg->xOffset % 6) != 0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType == VCENC_YUV420_8BIT_TILE_64_4 || pPreProcCfg->inputType == VCENC_YUV420_UV_8BIT_TILE_64_4)&& (((pPreProcCfg->xOffset % 64) != 0) || ((pPreProcCfg->yOffset % 4) != 0)))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->inputType == VCENC_YUV420_10BIT_TILE_32_4 && (((pPreProcCfg->xOffset % 32) != 0) || ((pPreProcCfg->yOffset % 4) != 0)))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType == VCENC_YUV420_10BIT_TILE_48_4 || pPreProcCfg->inputType == VCENC_YUV420_VU_10BIT_TILE_48_4)&& (((pPreProcCfg->xOffset % 48) != 0) || ((pPreProcCfg->yOffset % 4) != 0)))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType == VCENC_YUV420_8BIT_TILE_128_2 || pPreProcCfg->inputType == VCENC_YUV420_UV_8BIT_TILE_128_2)&& ((pPreProcCfg->xOffset % 128) != 0))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType == VCENC_YUV420_10BIT_TILE_96_2 || pPreProcCfg->inputType == VCENC_YUV420_VU_10BIT_TILE_96_2)&& ((pPreProcCfg->xOffset % 96) != 0))
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid offset for this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType >= VCENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4 &&
       pPreProcCfg->inputType <= VCENC_YUV420_VU_10BIT_TILE_96_2)
      && pPreProcCfg->rotation!=0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: rotation not supported by this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if (((pPreProcCfg->inputType == VCENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4)||
      (pPreProcCfg->inputType == VCENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4)||
      (pPreProcCfg->inputType == VCENC_YUV420_PLANAR_10BIT_P010_TILE_4_4))&&
      ((pPreProcCfg->origWidth & 0x3)!=0 || (pPreProcCfg->origHeight & 0x3)!=0))
  {
      APITRACEERR("Jenc_VCEncSetPreProcessing: the source size not supported by the 4x4 tile format");
      return VCENC_INVALID_ARGUMENT;
  }

  if ((pPreProcCfg->inputType > VCENC_BGR101010)
      && pPreProcCfg->videoStabilization!=0)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: stabilization not supported by this format");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pPreProcCfg->constChromaEn)
  {
    u32 maxCh = (1 << (8 + vcenc_instance->Jenc_sps->bit_depth_chroma_minus8)) - 1;
    if ((pPreProcCfg->constCb > maxCh) || (pPreProcCfg->constCr > maxCh))
    {
      APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid constant chroma pixel value");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  // if ((IS_HEVC(vcenc_instance->codecFormat)) &&((vcenc_instance->vuiColor.vui_color_enable == ENCHW_YES) || (vcenc_instance->Hdr10Display.hdr10_display_enable == ENCHW_YES) || (vcenc_instance->Hdr10LightLevel.hdr10_lightlevel_enable == ENCHW_YES)))
  if ((IS_HEVC(vcenc_instance->codecFormat)) &&((vcenc_instance->Hdr10Display.hdr10_display_enable == ENCHW_YES) || (vcenc_instance->Hdr10LightLevel.hdr10_lightlevel_enable == ENCHW_YES)))
  {
	  if ((pPreProcCfg->inputType >= VCENC_RGB565) && (pPreProcCfg->inputType <= VCENC_BGR101010))
	  {
		  if (pPreProcCfg->colorConversion.type != VCENC_RGBTOYUV_BT2020)
		  {
			  APITRACEERR("Jenc_VCEncSetPreProcessing: Invalid color conversion in HDR10\n");
			  return VCENC_INVALID_ARGUMENT;
		  }
	  }

	  if ((vcenc_instance->Jenc_sps->bit_depth_luma_minus8 != 2) || (vcenc_instance->Jenc_sps->bit_depth_chroma_minus8 != 2))
	  {
		  APITRACEERR("Jenc_VCEncSetPreProcessing: Invalid bit depth for main10 profile in HDR10\n");
		  return VCENC_INVALID_ARGUMENT;
	  }
  }

  /*Overlay Area check*/
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    if(pPreProcCfg->overlayArea[i].enable && !cfg.OSDSupport)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: OSD not supported\n");
      return VCENC_INVALID_ARGUMENT;
    }
    if(pPreProcCfg->overlayArea[i].enable && vcenc_instance->pass != 1)
    {
      if(
       pPreProcCfg->overlayArea[i].xoffset + pPreProcCfg->overlayArea[i].cropWidth > vcenc_instance->width ||
       pPreProcCfg->overlayArea[i].yoffset + pPreProcCfg->overlayArea[i].cropHeight > vcenc_instance->height)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid overlay area\n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].cropWidth == 0 || pPreProcCfg->overlayArea[i].cropHeight == 0)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid overlay size\n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].cropXoffset + pPreProcCfg->overlayArea[i].cropWidth > pPreProcCfg->overlayArea[i].width ||
        pPreProcCfg->overlayArea[i].cropYoffset + pPreProcCfg->overlayArea[i].cropHeight > pPreProcCfg->overlayArea[i].height)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid overlay cropping size\n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].format == 2 && (pPreProcCfg->overlayArea[i].cropWidth % 8 != 0))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid overlay cropping width for bitmap \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(Jenc_osd_overlap(pPreProcCfg, i, vcenc_instance->codecFormat))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR overlay area overlapping \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 && pPreProcCfg->overlayArea[i].format != 0)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Super tile only support ARGB8888 format \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 && i != 0)
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Super tile only support for channel 1 \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if((pPreProcCfg->overlayArea[i].superTile == 0 && pPreProcCfg->overlayArea[i].scaleWidth != pPreProcCfg->overlayArea[i].cropWidth) ||
          (pPreProcCfg->overlayArea[i].superTile == 0 && pPreProcCfg->overlayArea[i].scaleHeight != pPreProcCfg->overlayArea[i].cropHeight) ||
          (pPreProcCfg->overlayArea[i].scaleWidth  != pPreProcCfg->overlayArea[i].cropWidth && i != 0) ||
          (pPreProcCfg->overlayArea[i].scaleHeight != pPreProcCfg->overlayArea[i].cropHeight && i != 0))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Up scale only work for special usage \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 &&
         (pPreProcCfg->overlayArea[i].cropXoffset % 64 != 0  || pPreProcCfg->overlayArea[i].cropYoffset % 64 != 0))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR super tile cropping offset must be 64 aligned \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 &&
         (pPreProcCfg->overlayArea[i].scaleWidth < pPreProcCfg->overlayArea[i].cropWidth ||
          pPreProcCfg->overlayArea[i].scaleHeight < pPreProcCfg->overlayArea[i].cropHeight))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR osd only support upscaling but no downscaling \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 &&
         ((pPreProcCfg->overlayArea[i].scaleWidth & 1) ||
         pPreProcCfg->overlayArea[i].scaleWidth > (pPreProcCfg->overlayArea[i].cropWidth*2) ||
         (pPreProcCfg->overlayArea[i].scaleHeight & 1) ||
         pPreProcCfg->overlayArea[i].scaleHeight > (pPreProcCfg->overlayArea[i].cropHeight * 2)))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR osd upscaling width or height constraint \n");
        return VCENC_INVALID_ARGUMENT;
      }

      if(pPreProcCfg->overlayArea[i].superTile != 0 &&
        (pPreProcCfg->overlayArea[i].scaleWidth > vcenc_instance->width ||
         pPreProcCfg->overlayArea[i].scaleHeight > vcenc_instance->height))
      {
        APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR osd upscaling size has to be less than background size \n");
        return VCENC_INVALID_ARGUMENT;
      }
    }
  }

  /* Mosaic checker */
  for(i = 0; i < MAX_MOSAIC_NUM; i++)
  {
    if(!pPreProcCfg->mosEnable[i]) continue;

    int mbSize = IS_H264(vcenc_instance->codecFormat)? 16 : 64;
    if(pPreProcCfg->mosEnable[i] && !cfg.MosaicSupport)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: Mosaic not supported\n");
      return VCENC_INVALID_ARGUMENT;
    }
    u32 alignedPicWidth =  STRIDE(vcenc_instance->width, mbSize);
    u32 alignedPicHeight = STRIDE(vcenc_instance->height, mbSize);
    if(pPreProcCfg->mosXoffset[i] + pPreProcCfg->mosWidth[i] >  alignedPicWidth ||
       pPreProcCfg->mosYoffset[i] + pPreProcCfg->mosHeight[i] > alignedPicHeight)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR Invalid mosaic area\n");
      return VCENC_INVALID_ARGUMENT;
    }

    if(pPreProcCfg->mosXoffset[i] % mbSize || pPreProcCfg->mosYoffset[i] % mbSize ||
       pPreProcCfg->mosWidth[i] % mbSize || pPreProcCfg->mosHeight[i] % mbSize)
    {
      APITRACEERR("Jenc_VCEncSetCodingCtrl: ERROR mosaic region should be ctb/mb alligned \n");
      return VCENC_INVALID_ARGUMENT;
    }
  }

  pp_tmp = vcenc_instance->preProcess;

  if (pPreProcCfg->videoStabilization == 0)
  {
    pp_tmp.horOffsetSrc = pPreProcCfg->xOffset;
    pp_tmp.verOffsetSrc = pPreProcCfg->yOffset;
  }
  else
  {
    pp_tmp.horOffsetSrc = 0;
    pp_tmp.verOffsetSrc = 0;
  }

  pp_tmp.subsample_x = (vcenc_instance->asic.regs.codedChromaIdc == VCENC_CHROMA_IDC_420) ? 1 : 0;
  pp_tmp.subsample_y = (vcenc_instance->asic.regs.codedChromaIdc == VCENC_CHROMA_IDC_420) ? 1 : 0;

  /* Encoded frame resolution as set in Init() */
  //pp_tmp = pEncInst->preProcess;    //here is a bug? if enabling this line.

  cfg = JencEncAsicGetAsicConfig(client_type, vcenc_instance->ctx);

  pp_tmp.lumWidthSrc  = pPreProcCfg->origWidth;
  pp_tmp.lumHeightSrc = pPreProcCfg->origHeight;
  pp_tmp.rotation     = pPreProcCfg->rotation;
  pp_tmp.mirror       = pPreProcCfg->mirror;
  pp_tmp.inputFormat  = pPreProcCfg->inputType;
  pp_tmp.videoStab    = (pPreProcCfg->videoStabilization != 0) ? 1 : 0;
  pp_tmp.scaledWidth  = pPreProcCfg->scaledWidth;
  pp_tmp.scaledHeight = pPreProcCfg->scaledHeight;
  asic->scaledImage.busAddress = pPreProcCfg->busAddressScaledBuff;
  asic->scaledImage.virtualAddress = pPreProcCfg->virtualAddressScaledBuff;
  asic->scaledImage.size = pPreProcCfg->sizeScaledBuff;
  asic->regs.scaledLumBase = asic->scaledImage.busAddress;
  pp_tmp.input_alignment = pPreProcCfg->input_alignment;
  /* external DS takes precedence over inLoopDS, allowing user to switch if both are supported */
  pp_tmp.inLoopDSRatio = ((vcenc_instance->pass == 1 && !vcenc_instance->extDSRatio)? vcenc_instance->inLoopDSRatio : 0);

  pp_tmp.scaledOutputFormat = pPreProcCfg->scaledOutputFormat;
  pp_tmp.scaledOutput = (pPreProcCfg->scaledOutput) ? 1 : 0;
  if (pPreProcCfg->scaledWidth * pPreProcCfg->scaledHeight == 0 || vcenc_instance->pass == 1)
    pp_tmp.scaledOutput = 0;
  /* Check for invalid values */
  if (JencPreProcessCheck(&pp_tmp) != ENCHW_OK)
  {
    APITRACEERR("Jenc_VCEncSetPreProcessing: ERROR Invalid cropping values");
    return VCENC_INVALID_ARGUMENT;
  }
#if 1
  pp_tmp.frameCropping = ENCHW_NO;
  pp_tmp.frameCropLeftOffset = 0;
  pp_tmp.frameCropRightOffset = 0;
  pp_tmp.frameCropTopOffset = 0;
  pp_tmp.frameCropBottomOffset = 0;
  /* Set cropping parameters if required */
  u32 alignment = (IS_H264(vcenc_instance->codecFormat) ? 16 : 8);
  if (vcenc_instance->preProcess.lumWidth % alignment || vcenc_instance->preProcess.lumHeight % alignment)
  {
    u32 fillRight = (vcenc_instance->preProcess.lumWidth + alignment-1) / alignment * alignment -
                    vcenc_instance->preProcess.lumWidth;
    u32 fillBottom = (vcenc_instance->preProcess.lumHeight + alignment-1) / alignment * alignment -
                     vcenc_instance->preProcess.lumHeight;


    pp_tmp.frameCropping = ENCHW_YES;

    if (pPreProcCfg->rotation == VCENC_ROTATE_0)     /* No rotation */
    {
      if (pp_tmp.mirror)
        pp_tmp.frameCropLeftOffset = fillRight >> pp_tmp.subsample_x;
      else
        pp_tmp.frameCropRightOffset = fillRight >> pp_tmp.subsample_x;

      pp_tmp.frameCropBottomOffset = fillBottom >> pp_tmp.subsample_y;
    }
    else if (pPreProcCfg->rotation == VCENC_ROTATE_90R)        /* Rotate right */
    {

      pp_tmp.frameCropLeftOffset = fillRight >> pp_tmp.subsample_x;

      if (pp_tmp.mirror)
        pp_tmp.frameCropTopOffset = fillBottom >> pp_tmp.subsample_y;
      else
        pp_tmp.frameCropBottomOffset = fillBottom >> pp_tmp.subsample_y;
    }
    else if (pPreProcCfg->rotation == VCENC_ROTATE_90L)        /* Rotate left */
    {
      pp_tmp.frameCropRightOffset = fillRight >> pp_tmp.subsample_x;

      if (pp_tmp.mirror)
        pp_tmp.frameCropBottomOffset = fillBottom >> pp_tmp.subsample_y;
      else
        pp_tmp.frameCropTopOffset = fillBottom >> pp_tmp.subsample_y;
    }
    else if (pPreProcCfg->rotation == VCENC_ROTATE_180R)        /* Rotate 180 degree left */
    {
      if (pp_tmp.mirror)
        pp_tmp.frameCropRightOffset = fillRight >> pp_tmp.subsample_x;
      else
        pp_tmp.frameCropLeftOffset = fillRight >> pp_tmp.subsample_x;

      pp_tmp.frameCropTopOffset = fillBottom >> pp_tmp.subsample_y;
    }
  }
#endif

  if (pp_tmp.videoStab != 0)
  {
    u32 width = pp_tmp.lumWidth;
    u32 height = pp_tmp.lumHeight;
    u32 heightSrc = pp_tmp.lumHeightSrc;

    if (pp_tmp.rotation)
    {
      u32 tmp;

      tmp = width;
      width = height;
      height = tmp;
    }

    if (Jenc_VSCheckSize(pp_tmp.lumWidthSrc, heightSrc, width, height) != 0)
    {
      APITRACE("Jenc_VCEncSetPreProcessing: ERROR Invalid size for stabilization");
      return VCENC_INVALID_ARGUMENT;
    }

#ifdef VIDEOSTAB_ENABLED
    VSAlgInit(&vcenc_instance->vsSwData, pp_tmp.lumWidthSrc, heightSrc, width, height);

    VSAlgGetResult(&vcenc_instance->vsSwData, &pp_tmp.horOffsetSrc, &pp_tmp.verOffsetSrc);
#endif
  }

  pp_tmp.colorConversionType = pPreProcCfg->colorConversion.type;
  pp_tmp.colorConversionCoeffA = pPreProcCfg->colorConversion.coeffA;
  pp_tmp.colorConversionCoeffB = pPreProcCfg->colorConversion.coeffB;
  pp_tmp.colorConversionCoeffC = pPreProcCfg->colorConversion.coeffC;
  pp_tmp.colorConversionCoeffE = pPreProcCfg->colorConversion.coeffE;
  pp_tmp.colorConversionCoeffF = pPreProcCfg->colorConversion.coeffF;
  pp_tmp.colorConversionCoeffG = pPreProcCfg->colorConversion.coeffG;
  pp_tmp.colorConversionCoeffH = pPreProcCfg->colorConversion.coeffH;
  pp_tmp.colorConversionLumaOffset = pPreProcCfg->colorConversion.LumaOffset;
  JencSetColorConversion(&pp_tmp, &vcenc_instance->asic);

  /* constant chroma control */
  pp_tmp.constChromaEn = pPreProcCfg->constChromaEn;
  pp_tmp.constCb = pPreProcCfg->constCb;
  pp_tmp.constCr = pPreProcCfg->constCr;

  /* overlay control*/
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    pp_tmp.overlayEnable[i] = pPreProcCfg->overlayArea[i].enable;
    pp_tmp.overlayAlpha[i] = pPreProcCfg->overlayArea[i].alpha;
    pp_tmp.overlayFormat[i] = pPreProcCfg->overlayArea[i].format;
    pp_tmp.overlayHeight[i] = pPreProcCfg->overlayArea[i].height;
    pp_tmp.overlayCropHeight[i] = pPreProcCfg->overlayArea[i].cropHeight;
    pp_tmp.overlayScaleHeight[i] = pPreProcCfg->overlayArea[i].scaleHeight;
    pp_tmp.overlayWidth[i] = pPreProcCfg->overlayArea[i].width;
    pp_tmp.overlayCropWidth[i] = pPreProcCfg->overlayArea[i].cropWidth;
    pp_tmp.overlayScaleWidth[i] = pPreProcCfg->overlayArea[i].scaleWidth;
    pp_tmp.overlayXoffset[i] = pPreProcCfg->overlayArea[i].xoffset;
    pp_tmp.overlayCropXoffset[i] = pPreProcCfg->overlayArea[i].cropXoffset;
    pp_tmp.overlayYoffset[i] = pPreProcCfg->overlayArea[i].yoffset;
    pp_tmp.overlayCropYoffset[i] = pPreProcCfg->overlayArea[i].cropYoffset;
    pp_tmp.overlayYStride[i] = pPreProcCfg->overlayArea[i].Ystride;
    pp_tmp.overlayUVStride[i] = pPreProcCfg->overlayArea[i].UVstride;
    pp_tmp.overlayBitmapY[i] = pPreProcCfg->overlayArea[i].bitmapY;
    pp_tmp.overlayBitmapU[i] = pPreProcCfg->overlayArea[i].bitmapU;
    pp_tmp.overlayBitmapV[i] = pPreProcCfg->overlayArea[i].bitmapV;
    //HEVC handles PRP per frame, no need to do slice
    pp_tmp.overlaySliceHeight[i] = pPreProcCfg->overlayArea[i].cropHeight;
    pp_tmp.overlayVerOffset[i] = pPreProcCfg->overlayArea[i].cropYoffset;
    pp_tmp.overlaySuperTile[i] = pPreProcCfg->overlayArea[i].superTile;
  }

  /* Mosaic control */
  for(i = 0; i < MAX_MOSAIC_NUM; i++)
  {
    pp_tmp.mosEnable[i] = pPreProcCfg->mosEnable[i];
    pp_tmp.mosXoffset[i] = pPreProcCfg->mosXoffset[i];
    pp_tmp.mosYoffset[i] = pPreProcCfg->mosYoffset[i];
    pp_tmp.mosWidth[i] = pPreProcCfg->mosWidth[i];
    pp_tmp.mosHeight[i] = pPreProcCfg->mosHeight[i];
  }

  pp_tmp.codecFormat = vcenc_instance->codecFormat;

  vcenc_instance->preProcess = pp_tmp;
  if(vcenc_instance->pass==2) {
    VCEncPreProcessingCfg new_cfg;
    u32 ds_ratio = 1;

    memcpy(&new_cfg, pPreProcCfg, sizeof(VCEncPreProcessingCfg));

    /*pass-1 cutree downscaler*/
    if(vcenc_instance->extDSRatio) {
      ds_ratio = vcenc_instance->extDSRatio + 1;
      new_cfg.origWidth  /= ds_ratio;
      new_cfg.origHeight /= ds_ratio;
      new_cfg.origWidth  = (new_cfg.origWidth  >> 1) << 1;
      new_cfg.origHeight = (new_cfg.origHeight >> 1) << 1;
      new_cfg.xOffset /= ds_ratio;
      new_cfg.yOffset /= ds_ratio;
    }

    VCEncRet ret = Jenc_VCEncSetPreProcessing(vcenc_instance->lookahead.priv_inst, &new_cfg);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncSetPreProcessing: LookaheadSetPreProcessing failed");
      return ret;
    }
  }

  vcenc_instance->asic.regs.bPreprocessUpdate = 1;
  APITRACE("Jenc_VCEncSetPreProcessing: OK");

  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncGetPreProcessing
    Description     : Returns current preprocessing parameters
    Return type     : VCEncRet
    Argument        : inst - encoder instance
    Argument        : pPreProcCfg - place where the parameters are returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncGetPreProcessing(VCEncInst inst,
                                   VCEncPreProcessingCfg *pPreProcCfg)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s *pPP;
  asicData_s *asic = &vcenc_instance->asic;
  i32 i;
  APITRACE("Jenc_VCEncGetPreProcessing#");
  /* Check for illegal inputs */
  if ((inst == NULL) || (pPreProcCfg == NULL))
  {
    APITRACEERR("Jenc_VCEncGetPreProcessing: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncGetPreProcessing: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  pPP = &vcenc_instance->preProcess;

  pPreProcCfg->origHeight = pPP->lumHeightSrc;
  pPreProcCfg->origWidth = pPP->lumWidthSrc;
  pPreProcCfg->xOffset = pPP->horOffsetSrc;
  pPreProcCfg->yOffset = pPP->verOffsetSrc;

  pPreProcCfg->rotation = (VCEncPictureRotation) pPP->rotation;
  pPreProcCfg->mirror = (VCEncPictureMirror) pPP->mirror;
  pPreProcCfg->inputType = (VCEncPictureType) pPP->inputFormat;

  pPreProcCfg->busAddressScaledBuff = asic->scaledImage.busAddress;
  pPreProcCfg->virtualAddressScaledBuff = asic->scaledImage.virtualAddress;
  pPreProcCfg->sizeScaledBuff = asic->scaledImage.size;

  pPreProcCfg->scaledOutput       = pPP->scaledOutput;
  pPreProcCfg->scaledWidth       = pPP->scaledWidth;
  pPreProcCfg->scaledHeight       = pPP->scaledHeight;
  pPreProcCfg->input_alignment = pPP->input_alignment;
  pPreProcCfg->inLoopDSRatio = pPP->inLoopDSRatio;
  pPreProcCfg->videoStabilization = pPP->videoStab;
  pPreProcCfg->scaledOutputFormat = pPP->scaledOutputFormat;

  pPreProcCfg->colorConversion.type =
    (VCEncColorConversionType) pPP->colorConversionType;
  pPreProcCfg->colorConversion.coeffA = pPP->colorConversionCoeffA;
  pPreProcCfg->colorConversion.coeffB = pPP->colorConversionCoeffB;
  pPreProcCfg->colorConversion.coeffC = pPP->colorConversionCoeffC;
  pPreProcCfg->colorConversion.coeffE = pPP->colorConversionCoeffE;
  pPreProcCfg->colorConversion.coeffF = pPP->colorConversionCoeffF;
  pPreProcCfg->colorConversion.coeffG = pPP->colorConversionCoeffG;
  pPreProcCfg->colorConversion.coeffH = pPP->colorConversionCoeffH;
  pPreProcCfg->colorConversion.LumaOffset = pPP->colorConversionLumaOffset;

  /* constant chroma control */
  pPreProcCfg->constChromaEn = pPP->constChromaEn;
  pPreProcCfg->constCb = pPP->constCb;
  pPreProcCfg->constCr = pPP->constCr;

  /* OSD related parameters */
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    pPreProcCfg->overlayArea[i].xoffset = pPP->overlayXoffset[i];
    pPreProcCfg->overlayArea[i].cropXoffset = pPP->overlayCropXoffset[i];
    pPreProcCfg->overlayArea[i].yoffset = pPP->overlayYoffset[i];
    pPreProcCfg->overlayArea[i].cropYoffset = pPP->overlayCropYoffset[i];
    pPreProcCfg->overlayArea[i].width = pPP->overlayWidth[i];
    pPreProcCfg->overlayArea[i].scaleWidth = pPP->overlayScaleWidth[i];
    pPreProcCfg->overlayArea[i].cropWidth = pPP->overlayCropWidth[i];
    pPreProcCfg->overlayArea[i].height = pPP->overlayHeight[i];
    pPreProcCfg->overlayArea[i].cropHeight = pPP->overlayCropHeight[i];
    pPreProcCfg->overlayArea[i].format = pPP->overlayFormat[i];
    pPreProcCfg->overlayArea[i].superTile = pPP->overlaySuperTile[i];
    pPreProcCfg->overlayArea[i].alpha = pPP->overlayAlpha[i];
    pPreProcCfg->overlayArea[i].enable = pPP->overlayEnable[i];
    pPreProcCfg->overlayArea[i].Ystride = pPP->overlayYStride[i];
    pPreProcCfg->overlayArea[i].UVstride = pPP->overlayUVStride[i];
    pPreProcCfg->overlayArea[i].bitmapY = pPP->overlayBitmapY[i];
    pPreProcCfg->overlayArea[i].bitmapU = pPP->overlayBitmapU[i];
    pPreProcCfg->overlayArea[i].bitmapV = pPP->overlayBitmapV[i];
    pPreProcCfg->overlayArea[i].superTile = pPP->overlaySuperTile[i];
    pPreProcCfg->overlayArea[i].scaleWidth = pPP->overlayScaleWidth[i];
    pPreProcCfg->overlayArea[i].scaleHeight = pPP->overlayScaleHeight[i];
  }

  /* Get mosaic region paramters */
  for(i = 0; i < MAX_MOSAIC_NUM; i++)
  {
    pPreProcCfg->mosEnable[i] = pPP->mosEnable[i];
    pPreProcCfg->mosXoffset[i] = pPP->mosXoffset[i];
    pPreProcCfg->mosYoffset[i] = pPP->mosYoffset[i];
    pPreProcCfg->mosWidth[i] = pPP->mosWidth[i];
    pPreProcCfg->mosHeight[i] = pPP->mosHeight[i];
  }

  APITRACE("Jenc_VCEncGetPreProcessing: OK");
  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncCreateNewPPS
    Description     : create new PPS
    Return type     : VCEncRet
    Argument        : inst - encoder instance in use
    Argument        : pPPSCfg - user provided parameters
    Argument        : newPPSId - new PPS id for user
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncCreateNewPPS(VCEncInst inst, const VCEncPPSCfg *pPPSCfg, i32* newPPSId)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s pp_tmp;
  asicData_s *asic = &vcenc_instance->asic;
  struct Jenc_pps * p;
  struct Jenc_pps * p0;
  i32 ppsId;

  struct container *c;


  APITRACE("Jenc_VCEncCreateNewPPS#");
  APITRACEPARAM("chroma_qp_offset", pPPSCfg->chroma_qp_offset);
  APITRACEPARAM("tc_Offset", pPPSCfg->tc_Offset);
  APITRACEPARAM("beta_Offset", pPPSCfg->beta_Offset);

  /* Check for illegal inputs */
  if ((inst == NULL) || (pPPSCfg == NULL))
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }


  if (pPPSCfg->chroma_qp_offset > 12 ||
      pPPSCfg->chroma_qp_offset < -12)
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR chroma_qp_offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pPPSCfg->tc_Offset > 6 || pPPSCfg->tc_Offset < -6)
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR tc_Offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pPPSCfg->beta_Offset > 6 || pPPSCfg->beta_Offset < -6)
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR beta_Offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  c = Jenc_get_container(vcenc_instance);

  p0 = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, 0);
  /*get ppsId*/
  ppsId = 0;
  while(1)
  {
    p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, ppsId);
    if(p == NULL)
    {
      break;
    }
    ppsId++;
  }
  *newPPSId = ppsId;

  if(ppsId > 63)
  {
    APITRACEERR("Jenc_VCEncCreateNewPPS: ERROR PPS id is greater than 63");
    return VCENC_INVALID_ARGUMENT;
  }
  p = (struct Jenc_pps *)Jenc_create_parameter_set(PPS_NUT);
  {
    struct ps pstemp = p->ps;
    *p = *p0;
    p->ps = pstemp;
  }
  p->cb_qp_offset = p->cr_qp_offset = pPPSCfg->chroma_qp_offset;

  p->tc_offset = pPPSCfg->tc_Offset*2;

  p->beta_offset = pPPSCfg->beta_Offset*2;

  p->ps.id = ppsId;

  Jenc_queue_put(&c->parameter_set, (struct node *)p);

  vcenc_instance->insertNewPPS = 1;
  vcenc_instance->insertNewPPSId = ppsId;

  vcenc_instance->maxPPSId++;

  /*create new PPS with ppsId*/
  APITRACE("Jenc_VCEncCreateNewPPS: OK");

  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncModifyOldPPS
    Description     : modify old PPS
    Return type     : VCEncRet
    Argument        : inst - encoder instance in use
    Argument        : pPPSCfg - user provided parameters
    Argument        : newPPSId - old PPS id provided by user
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncModifyOldPPS(VCEncInst inst, const VCEncPPSCfg *pPPSCfg, i32 ppsId)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s pp_tmp;
  asicData_s *asic = &vcenc_instance->asic;
  struct Jenc_pps * p;
  struct container *c;

  APITRACE("Jenc_VCEncModifyOldPPS#");
  APITRACEPARAM("chroma_qp_offset", pPPSCfg->chroma_qp_offset);
  APITRACEPARAM("tc_Offset", pPPSCfg->tc_Offset);
  APITRACEPARAM("beta_Offset", pPPSCfg->beta_Offset);

  /* Check for illegal inputs */
  if ((inst == NULL) || (pPPSCfg == NULL))
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }


  if (pPPSCfg->chroma_qp_offset > 12 ||
      pPPSCfg->chroma_qp_offset < -12)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR chroma_qp_offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pPPSCfg->tc_Offset > 6 || pPPSCfg->tc_Offset < -6)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR tc_Offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }
  if (pPPSCfg->beta_Offset > 6 || pPPSCfg->beta_Offset < -6)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR beta_Offset out of range");
    return VCENC_INVALID_ARGUMENT;
  }

  if(vcenc_instance->maxPPSId < ppsId || ppsId < 0)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }

  c = Jenc_get_container(vcenc_instance);

  p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, ppsId);

  if(p == NULL)
  {
    APITRACEERR("Jenc_VCEncModifyOldPPS: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }


  p->cb_qp_offset = p->cr_qp_offset = pPPSCfg->chroma_qp_offset;

  p->tc_offset = pPPSCfg->tc_Offset*2;

  p->beta_offset = pPPSCfg->beta_Offset*2;


  vcenc_instance->insertNewPPS = 1;
  vcenc_instance->insertNewPPSId = ppsId;


  /*create new PPS with ppsId*/
  APITRACE("Jenc_VCEncModifyOldPPS: OK");

  return VCENC_OK;
}


/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncGetPPSData
    Description     : get PPS parameters for user
    Return type     : VCEncRet
    Argument        : inst - encoder instance
    Argument        : pPPSCfg - place where the parameters are returned
    Argument        : ppsId - PPS id provided by user
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncGetPPSData(VCEncInst inst,  VCEncPPSCfg *pPPSCfg, i32 ppsId)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s *pPP;
  struct Jenc_pps * p;
  struct Jenc_pps * p0;
  struct container *c;

  APITRACE("Jenc_VCEncGetPPSData#");
  /* Check for illegal inputs */
  if ((inst == NULL) || (pPPSCfg == NULL))
  {
    APITRACEERR("Jenc_VCEncGetPPSData: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncGetPPSData: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  if(vcenc_instance->maxPPSId < ppsId || ppsId < 0)
  {
    APITRACEERR("Jenc_VCEncGetPPSData: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }

  c = Jenc_get_container(vcenc_instance);

  p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, ppsId);

  if(p == NULL)
  {
    APITRACEERR("Jenc_VCEncGetPPSData: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }

  pPPSCfg->chroma_qp_offset = p->cb_qp_offset;

  pPPSCfg->tc_Offset = p->tc_offset/2;

  pPPSCfg->beta_Offset = p->beta_offset/2;


  APITRACE("Jenc_VCEncGetPPSData: OK");
  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncActiveAnotherPPS
    Description     : active another PPS
    Return type     : VCEncRet
    Argument        : inst - encoder instance in use
    Argument        : ppsId - PPS id provided by user
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncActiveAnotherPPS(VCEncInst inst, i32 ppsId)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s pp_tmp;
  asicData_s *asic = &vcenc_instance->asic;
  struct Jenc_pps * p;

  struct container *c;


  APITRACE("Jenc_VCEncActiveAnotherPPS#");
  APITRACEPARAM("ppsId", ppsId);

  /* Check for illegal inputs */
  if (inst == NULL)
  {
    APITRACEERR("Jenc_VCEncActiveAnotherPPS: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncActiveAnotherPPS: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  if(vcenc_instance->maxPPSId < ppsId || ppsId < 0)
  {
    APITRACEERR("Jenc_VCEncActiveAnotherPPS: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }

  c = Jenc_get_container(vcenc_instance);

  p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, ppsId);

  if(p == NULL)
  {
    APITRACEERR("Jenc_VCEncActiveAnotherPPS: ERROR Invalid ppsId");
    return VCENC_INVALID_ARGUMENT;
  }

  vcenc_instance->pps_id = ppsId;

  /*create new PPS with ppsId*/
  APITRACE("Jenc_VCEncActiveAnotherPPS: OK");

  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name   : Jenc_VCEncGetActivePPSId
    Description     : get PPS parameters for user
    Return type     : VCEncRet
    Argument        : inst - encoder instance
    Argument        : pPPSCfg - place where the parameters are returned
    Argument        : ppsId - PPS id provided by user
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncGetActivePPSId(VCEncInst inst,  i32* ppsId)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  preProcess_s *pPP;
  struct Jenc_pps * p;
  struct container *c;

  APITRACE("Jenc_VCEncGetPPSData#");
  /* Check for illegal inputs */
  if ((inst == NULL) || (ppsId == NULL))
  {
    APITRACEERR("Jenc_VCEncGetActivePPSId: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncGetActivePPSId: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  *ppsId = vcenc_instance->pps_id;

  APITRACE("Jenc_VCEncGetActivePPSId: OK");
  return VCENC_OK;
}

/**
 * Enables or disables writing user data to the encoded stream. The user data will be written in
 * the stream as a Supplemental Enhancement Information (SEI) message connected to all the
 * following encoded frames. The SEI message payload type is marked as "user_data_unregistered".
 *
 * \param [in] inst The instance that defines the encoder in use.
 * \param [in] pUserData Pointer to a buffer containing the user data. The encoder stores a
 *             pointer to this buffer and reads data from the buffer during encoding of the
 *             following frames. Because the encoder reads data straight from this buffer,
 *             it must not be freed before disabling the user data writing.
 * \param [in] userDataSize  Size of the data in the pUserData buffer in bytes. If a zero value
 *             is given, the user data writing is disabled. Invalid value disables user data
 *             writing. Valid value range: 0 or [16, 2048]
 * \return VCENC_OK setup sucessfully, the user data SEI will be inserted when call
 *             Jenc_VCEncStrmEncode() or the user data has been disabled;
 * \return VCENC_NULL_ARGUMENT pUserData is invalid;
 * \return VCENC_INSTANCE_ERROR inst is invalid;
 */
VCEncRet Jenc_VCEncSetSeiUserData(VCEncInst inst, const u8 *pUserData,
                                 u32 userDataSize)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;

  APITRACE("Jenc_VCEncSetSeiUserData#");
  APITRACEPARAM("userDataSize", userDataSize);

  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (userDataSize != 0 && pUserData == NULL))
  {
    APITRACEERR("Jenc_VCEncSetSeiUserData: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncSetSeiUserData: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  /* Disable user data */
  if ((userDataSize < 16) || (userDataSize > VCENC_MAX_USER_DATA_SIZE))
  {
    vcenc_instance->rateControl.sei.userDataEnabled = ENCHW_NO;
    vcenc_instance->rateControl.sei.pUserData = NULL;
    vcenc_instance->rateControl.sei.userDataSize = 0;
  }
  else
  {
    vcenc_instance->rateControl.sei.userDataEnabled = ENCHW_YES;
    vcenc_instance->rateControl.sei.pUserData = pUserData;
    vcenc_instance->rateControl.sei.userDataSize = userDataSize;
  }

  APITRACE("Jenc_VCEncSetSeiUserData: OK");
  return VCENC_OK;

}


#define MAX_TLAYER 7

i32 Jenc_calculate_gop_reorder_frames(struct Jenc_sps *Jenc_sps, VCEncGopPicConfig *pcfg, int gopSize)
{
  for(int i=0; i<gopSize; i++)
  {
    int highestDecodingNumberWithLowerPOC = 0;
    for(int j=0; j<gopSize; j++)
    {
      if(pcfg[j].poc <= pcfg[i].poc)
      {
        highestDecodingNumberWithLowerPOC = j;
      }
    }
    int numReorder = 0;
    for(int j=0; j<highestDecodingNumberWithLowerPOC; j++)
    {
      if(pcfg[j].temporalId <= pcfg[i].temporalId &&
          pcfg[j].poc > pcfg[i].poc)
      {
        numReorder++;
      }
    }
    if(numReorder > Jenc_sps->max_num_reorder_pics[pcfg[i].temporalId])
    {
      Jenc_sps->max_num_reorder_pics[pcfg[i].temporalId] = numReorder;
    }
  }
  return OK;
}

/*------------------------------------------------------------------------------
  Jenc_vcenc_calculate_num_reorder_frames
------------------------------------------------------------------------------*/
i32 Jenc_vcenc_calculate_num_reorder_frames(struct vcenc_instance *inst, const VCEncIn *pEncIn)
{
  const VCEncGopConfig *gopCfg = &pEncIn->gopConfig;
  int i,ret;
  int numReorder = 0;

  for(int i=0; i < inst->Jenc_sps->max_num_sub_layers; i++)
  {
    inst->Jenc_sps->max_num_reorder_pics[i] = 0;
  }
  /* calculate per-gop num reordering frames */
  for (i = 1; i <= MAX_GOP_SIZE; i++) {
    if (gopCfg->gopCfgOffset[i] == 0 && i > 1)
      continue;
    Jenc_calculate_gop_reorder_frames(inst->Jenc_sps, gopCfg->pGopPicCfg + gopCfg->gopCfgOffset[i], i);
  }
  /* update max_num_reorder_pics & max_dec_pic_buffering to full layer param */
  for(int i=1; i < inst->Jenc_sps->max_num_sub_layers; i++)
  {
    inst->Jenc_sps->max_num_reorder_pics[0] = MAX(inst->Jenc_sps->max_num_reorder_pics[0], inst->Jenc_sps->max_num_reorder_pics[i]);
    if(inst->Jenc_sps->max_dec_pic_buffering[0] < inst->Jenc_vps->max_num_reorder_pics[i] + 1)
      inst->Jenc_sps->max_dec_pic_buffering[0] = inst->Jenc_vps->max_num_reorder_pics[i] + 1;
  }
  for(int i = 0; i < inst->Jenc_sps->max_num_sub_layers; i++)
  {
    inst->Jenc_vps->max_dec_pic_buffering[i] = inst->Jenc_sps->max_dec_pic_buffering[i] =inst->Jenc_sps->max_dec_pic_buffering[0];
    inst->Jenc_vps->max_num_reorder_pics[i] = inst->Jenc_sps->max_num_reorder_pics[i] = inst->Jenc_sps->max_num_reorder_pics[0];
  }

  return OK;
}

/*------------------------------------------------------------------------------
  parameter_set

  RPS:
  poc[n*2  ] = delta_poc
  poc[n*2+1] = used_by_curr_pic
  poc[n*2  ] = 0, termination
  For example:
  { 0, 0},    No reference pictures
  {-1, 1},    Only one previous pictures
  {-1, 1, -2, 1},   Two previous pictures
  {-1, 1, -2, 0},   Two previous ictures, 2'nd not used
  {-1, 1, -2, 1, 1, 1}, Two previous and one future picture
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncStrmStart
    Description   : Starts a new stream
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncStrmStart(VCEncInst inst, const VCEncIn *pEncIn, VCEncOut *pEncOut)
{

  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  struct container *c;
  struct Jenc_vps *v;
  struct Jenc_sps *s;
  struct Jenc_pps *p;
  i32 i, ret = VCENC_ERROR;
  u32 client_type;

  APITRACE("Jenc_VCEncStrmStart#");
  APITRACEPARAM_X("busLuma", pEncIn->busLuma);
  APITRACEPARAM_X("busChromaU", pEncIn->busChromaU);
  APITRACEPARAM_X("busChromaV", pEncIn->busChromaV);
  APITRACEPARAM("timeIncrement", pEncIn->timeIncrement);
  APITRACEPARAM_X("pOutBuf", pEncIn->pOutBuf[0]);
  APITRACEPARAM_X("busOutBuf", pEncIn->busOutBuf[0]);
  APITRACEPARAM("outBufSize", pEncIn->outBufSize[0]);
  APITRACEPARAM("codingType", pEncIn->codingType);
  APITRACEPARAM("poc", pEncIn->poc);
  APITRACEPARAM("gopSize", pEncIn->gopSize);
  APITRACEPARAM("gopPicIdx", pEncIn->gopPicIdx);
  APITRACEPARAM_X("roiMapDeltaQpAddr", pEncIn->roiMapDeltaQpAddr);

  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (pEncIn == NULL) || (pEncOut == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }


  /* Check status */
  if ((vcenc_instance->encStatus != VCENCSTAT_INIT) &&
      (vcenc_instance->encStatus != VCENCSTAT_START_FRAME))
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Invalid status");
    return VCENC_INVALID_STATUS;
  }

  /* Check output stream buffers */
  if (pEncIn->pOutBuf[0] == NULL)
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Invalid output stream buffer");
    return VCENC_INVALID_ARGUMENT;
  }

  if (vcenc_instance->streamMultiSegment.streamMultiSegmentMode == 0 && (pEncIn->outBufSize[0] < VCENC_STREAM_MIN_BUF0_SIZE))
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Too small output stream buffer");
    return VCENC_INVALID_ARGUMENT;
  }

  /* Check idr_interval and gdrDuration */
  if (pEncIn->gopConfig.idr_interval < pEncIn->gopConfig.gdrDuration
      || (pEncIn->gopConfig.idr_interval==1 && pEncIn->gopConfig.gdrDuration>0))
  {
      APITRACEERR("Jenc_VCEncStrmStart: ERROR intraPicRate and gdrDuration");
      return VCENC_INVALID_ARGUMENT;
  }

  /* Check for invalid input values */
  client_type = VCEncGetClientType(vcenc_instance->codecFormat);
  if ((HW_ID_MAJOR_NUMBER(JencEncAsicGetAsicHWid(client_type, vcenc_instance->ctx)) <= 1) && (pEncIn->gopConfig.size > 1))
  {
    APITRACEERR("Jenc_VCEncStrmStart: ERROR Invalid input. gopConfig");
    return VCENC_INVALID_ARGUMENT;
  }
  if (!(c = Jenc_get_container(vcenc_instance))) return VCENC_ERROR;

  vcenc_instance->vps_id = 0;
  vcenc_instance->sps_id = 0;
  vcenc_instance->pps_id = 0;

  if(vcenc_instance->pass == 1) {
    vcenc_instance->lookahead.internal_mem.mem.mem_type = EWL_MEM_TYPE_VPU_WORKING;
    ret = JencEWLMallocLinear(vcenc_instance->asic.ewl, pEncIn->outBufSize[0],0, &(vcenc_instance->lookahead.internal_mem.mem));
    if(ret != EWL_OK)
        return  VCENC_ERROR;
    vcenc_instance->stream.stream = (u8*)vcenc_instance->lookahead.internal_mem.mem.virtualAddress;
    vcenc_instance->lookahead.internal_mem.pOutBuf = vcenc_instance->lookahead.internal_mem.mem.virtualAddress;
    vcenc_instance->stream.stream_bus = vcenc_instance->lookahead.internal_mem.busOutBuf = vcenc_instance->lookahead.internal_mem.mem.busAddress;
    vcenc_instance->stream.size = vcenc_instance->lookahead.internal_mem.outBufSize = vcenc_instance->lookahead.internal_mem.mem.size;
  } else {
    vcenc_instance->stream.stream = (u8 *)pEncIn->pOutBuf[0];
    vcenc_instance->stream.stream_bus = pEncIn->busOutBuf[0];
    vcenc_instance->stream.size = pEncIn->outBufSize[0];
	vcenc_instance->stream.av1pre_size = pEncIn->Av1PreBufferSize;
	vcenc_instance->stream.stream_av1pre_bus = pEncIn->busAv1PrecarryOutBuf;
  }

  pEncOut->pNaluSizeBuf = (u32 *)vcenc_instance->asic.sizeTbl[0].virtualAddress;

  Jenc_hash_init(&vcenc_instance->hashctx, pEncIn->hashType);

  vcenc_instance->temp_size = 1024 * 10;
  vcenc_instance->temp_buffer = vcenc_instance->stream.stream + vcenc_instance->stream.size - vcenc_instance->temp_size;

  pEncOut->streamSize = 0;
  pEncOut->sliceHeaderSize = 0;
  pEncOut->numNalus = 0;
  pEncOut->maxSliceStreamSize = 0;

  /* set RPS */
  if (vcenc_ref_pic_sets(vcenc_instance, pEncIn))
  {
    Jenc_Error(2, ERR, "vcenc_ref_pic_sets() fails");
    return NOK;
  }

  v = (struct Jenc_vps *)Jenc_get_parameter_set(c, VPS_NUT, 0);
  s = (struct Jenc_sps *)Jenc_get_parameter_set(c, SPS_NUT, 0);
  p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, 0);

  /* Initialize parameter sets */
  if (set_parameter(vcenc_instance, pEncIn, v, s, p)) goto out;


  /* calculate Jenc_sps->sps_max_num_reorder_pics from pEncIn->gopConfig */
  if (Jenc_vcenc_calculate_num_reorder_frames(vcenc_instance, pEncIn) != OK)
  {
    Jenc_Error(2, ERR, "Jenc_vcenc_calculate_num_reorder_frames() fails");
    return NOK;
  }

  /* init VUI */

  Jenc_VCEncSpsSetVuiAspectRatio(s,
                           vcenc_instance->sarWidth,
                           vcenc_instance->sarHeight);
  Jenc_VCEncSpsSetVuiVideoInfo(s,
                         vcenc_instance->vuiVideoFullRange);
  if(pEncIn->vui_timing_info_enable)
  {
    const rcVirtualBuffer_s *vb = &vcenc_instance->rateControl.virtualBuffer;

    Jenc_VCEncSpsSetVuiTimigInfo(s,
                           vb->timeScale, vb->unitsInTic);
  } else {
    Jenc_VCEncSpsSetVuiTimigInfo(s, 0, 0);
  }

  if(vcenc_instance->vuiVideoSignalTypePresentFlag)
	  Jenc_VCEncSpsSetVuiSignalType(s, vcenc_instance->vuiVideoSignalTypePresentFlag, vcenc_instance->vuiVideoFormat, vcenc_instance->vuiVideoFullRange, vcenc_instance->vuiColorDescription.vuiColorDescripPresentFlag, vcenc_instance->vuiColorDescription.vuiColorPrimaries,
		  vcenc_instance->vuiColorDescription.vuiTransferCharacteristics, vcenc_instance->vuiColorDescription.vuiMatrixCoefficients);

  /* update VUI */
  if (vcenc_instance->rateControl.sei.enabled == ENCHW_YES)
  {
    Jenc_VCEncSpsSetVuiPictStructPresentFlag(s, 1);
  }

  Jenc_VCEncSpsSetVui_field_seq_flag(s, vcenc_instance->preProcess.interlacedFrame);
  if (vcenc_instance->rateControl.hrd == ENCHW_YES)
  {
    Jenc_VCEncSpsSetVuiHrd(s, 1);

    Jenc_VCEncSpsSetVuiHrdBitRate(s,
                            vcenc_instance->rateControl.virtualBuffer.bitRate);

    Jenc_VCEncSpsSetVuiHrdCpbSize(s,
                            vcenc_instance->rateControl.virtualBuffer.bufferSize);
  }
  /* Init SEI */
  Jenc_HevcInitSei(&vcenc_instance->rateControl.sei, s->streamMode == ASIC_VCENC_BYTE_STREAM,
              vcenc_instance->rateControl.hrd, vcenc_instance->rateControl.outRateNum, vcenc_instance->rateControl.outRateDenom);

  /* Create parameter set nal units */
  if (IS_HEVC(vcenc_instance->codecFormat))
  {
    v->ps.b.stream = vcenc_instance->stream.stream;
    Jenc_video_parameter_set(v, inst);
    APITRACEPARAM("Jenc_vps size=%d\n", *v->ps.b.cnt);
    pEncOut->streamSize += *v->ps.b.cnt;
    Jenc_VCEncAddNaluSize(pEncOut, *v->ps.b.cnt);
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, *v->ps.b.cnt);
    vcenc_instance->stream.stream += *v->ps.b.cnt;
  }

  //H264 SVCT enable: insert H264Scalability SEI
  /* For VC8000E 6.0, need minor version >= 6010 */
  if (IS_H264(vcenc_instance->codecFormat) && s->max_num_sub_layers > 1 &&
      (vcenc_instance->asic.regs.asicHwId >= 0x80006010))
  {
    //Code SVCT SEI
    v->ps.b.stream = vcenc_instance->stream.stream;
    struct buffer *b = &v->ps.b;

    Jenc_H264NalUnitHdr(b, 0, H264_SEI, (v->streamMode==VCENC_BYTE_STREAM) ? ENCHW_YES : ENCHW_NO);
    Jenc_H264ScalabilityInfoSei(b,  s, s->max_num_sub_layers-1, vcenc_instance->rateControl.outRateNum*256/vcenc_instance->rateControl.outRateDenom);
    Jenc_rbsp_trailing_bits(b);

    APITRACEPARAM("H264Scalability SEI size=%d\n", *v->ps.b.cnt);
    pEncOut->streamSize += *v->ps.b.cnt;
    Jenc_VCEncAddNaluSize(pEncOut, *v->ps.b.cnt);
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, *v->ps.b.cnt);
    vcenc_instance->stream.stream += *v->ps.b.cnt;
  }

  if (!IS_HEVC(vcenc_instance->codecFormat))
    Jenc_cnt_ref_pic_set(c, s);

  if ((IS_HEVC(vcenc_instance->codecFormat) || IS_H264(vcenc_instance->codecFormat)))
  {
    s->ps.b.stream = vcenc_instance->stream.stream;
    Jenc_sequence_parameter_set(c, s, inst);
    APITRACEPARAM("Jenc_sps size=%d\n", *s->ps.b.cnt);
    pEncOut->streamSize += *s->ps.b.cnt;
    Jenc_VCEncAddNaluSize(pEncOut, *s->ps.b.cnt);
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, *s->ps.b.cnt);
    vcenc_instance->stream.stream += *s->ps.b.cnt;

    Jenc_HevcUpdateSeiMasteringDisplayColour(&vcenc_instance->rateControl.sei, &vcenc_instance->Hdr10Display);
    if ((vcenc_instance->rateControl.sei.hdr10_display_enable == ENCHW_YES) && IS_HEVC(vcenc_instance->codecFormat))
    {
      u32 u32SeiCnt = 0;
      vcenc_instance->stream.cnt = &u32SeiCnt;

      Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, vcenc_instance->rateControl.sei.byteStream);
      Jenc_HevcMasteringDisplayColourSei(&vcenc_instance->stream, &vcenc_instance->rateControl.sei);
      APITRACEPARAM("sei size=%d\n", u32SeiCnt);
      pEncOut->streamSize += u32SeiCnt;
      Jenc_VCEncAddNaluSize(pEncOut, u32SeiCnt);
      Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, u32SeiCnt);
    }

    Jenc_HevcUpdateSeiContentLightLevelInfo(&vcenc_instance->rateControl.sei, &vcenc_instance->Hdr10LightLevel);
    if ((vcenc_instance->rateControl.sei.hdr10_lightlevel_enable == ENCHW_YES) && IS_HEVC(vcenc_instance->codecFormat))
    {
      u32 u32SeiCnt = 0;
      vcenc_instance->stream.cnt = &u32SeiCnt;

      Jenc_HevcNalUnitHdr(&vcenc_instance->stream, PREFIX_SEI_NUT, vcenc_instance->rateControl.sei.byteStream);
      Jenc_HevcContentLightLevelSei(&vcenc_instance->stream, &vcenc_instance->rateControl.sei);
      APITRACEPARAM("sei size=%d\n", u32SeiCnt);
      pEncOut->streamSize += u32SeiCnt;
      Jenc_VCEncAddNaluSize(pEncOut, u32SeiCnt);
      Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, u32SeiCnt);
    }

    p->ps.b.stream = vcenc_instance->stream.stream;
    Jenc_picture_parameter_set(p, inst);
    //APITRACEPARAM("Jenc_pps size", *p->ps.b.cnt);
    APITRACEPARAM("Jenc_pps size=%d\n", *p->ps.b.cnt);
    pEncOut->streamSize += *p->ps.b.cnt;
    Jenc_VCEncAddNaluSize(pEncOut, *p->ps.b.cnt);
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, *p->ps.b.cnt);
  }

  /* Status == START_STREAM   Stream started */
  vcenc_instance->encStatus = VCENCSTAT_START_STREAM;

  if (vcenc_instance->rateControl.hrd == ENCHW_YES)
  {
    /* Update HRD Parameters to RC if needed */
    u32 bitrate = Jenc_VCEncSpsGetVuiHrdBitRate(s);
    u32 cpbsize = Jenc_VCEncSpsGetVuiHrdCpbSize(s);

    if ((vcenc_instance->rateControl.virtualBuffer.bitRate != (i32)bitrate) ||
        (vcenc_instance->rateControl.virtualBuffer.bufferSize != (i32)cpbsize))
    {
      vcenc_instance->rateControl.virtualBuffer.bitRate = bitrate;
      vcenc_instance->rateControl.virtualBuffer.bufferSize = cpbsize;
      (void)JencVCEncInitRc(&vcenc_instance->rateControl, 1);
    }
  }
  if(vcenc_instance->pass==2) {
    VCEncOut encOut;
    VCEncIn encIn;
    memcpy(&encIn, pEncIn, sizeof(VCEncIn));
    encIn.gopConfig.pGopPicCfg = pEncIn->gopConfig.pGopPicCfgPass1;
    VCEncRet ret = Jenc_VCEncStrmStart(vcenc_instance->lookahead.priv_inst, &encIn, &encOut);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncStrmStart: LookaheadStrmStart failed");
      goto out;
    }
    ret = Jenc_StartLookaheadThread(&vcenc_instance->lookahead);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncStrmStart: Jenc_StartLookaheadThread failed");
      goto out;
    }

    Jenc_queue_init(&vcenc_instance->extraParaQ);//for extra parameters.
  }

  APITRACE("Jenc_VCEncStrmStart: OK");
  ret = VCENC_OK;

  vcenc_instance->asic.regs.bStrmStartUpdate = 1;

out:
#ifdef TEST_DATA
  Jenc_Enc_close_stream_trace();
#endif

  return ret;

}

/*------------------------------------------------------------------------------
  vcenc_ref_pic_sets
------------------------------------------------------------------------------*/
i32 Jenc_vcenc_replace_rps(struct vcenc_instance *vcenc_instance, VCEncGopPicConfig *cfg, i32 rps_id)
{
#define RPS_TEMP_BUF_SIZE (RPS_SET_BUFF_SIZE + 60)
  struct vcenc_buffer *vcenc_buffer;
  i32 ret = OK;
  vcenc_instance->temp_size = RPS_TEMP_BUF_SIZE;
  vcenc_instance->temp_bufferBusAddress = 0;

  /* Initialize tb->instance->buffer so that we can cast it to vcenc_buffer
   * by calling hevc_set_parameter(), see api.c TODO...*/
  vcenc_instance->rps_id = -1;
  vcenc_set_ref_pic_set(vcenc_instance);

  u32 iRefPic, idx = 0;

  vcenc_instance->rps_id = rps_id;
  ret = vcenc_set_ref_pic_set(vcenc_instance);

  vcenc_instance->temp_size = 0;
  return ret;
}

struct sw_picture *Jenc_get_ref_picture(struct vcenc_instance *vcenc_instance, VCEncGopPicConfig *cfg,
                                      i32 idx, bool bRecovery, bool *error)
{
  struct node *n;
  struct sw_picture *p, *ref = NULL;
  struct container *c = Jenc_get_container(vcenc_instance);
  i32 curPoc = vcenc_instance->poc;
  i32 deltaPoc = cfg->refPics[idx].ref_pic;
  i32 poc = curPoc + deltaPoc;
  i32 iDelta, i;
  *error = HANTRO_TRUE;
  bRecovery = bRecovery && cfg->refPics[idx].used_by_cur;

  if (poc < 0) return NULL;

  for (n = c->picture.tail; n; n = n->next)
  {
    p = (struct sw_picture *)n;
    if (p->reference)
    {
      iDelta = p->poc - curPoc;
      if (p->poc == poc)
      {
        ref = p;
        *error = HANTRO_FALSE;
        break;
      }

      if (bRecovery && (p->encOrderInGop == 0) &&((deltaPoc * iDelta) > 0))
      {
        bool bCand = 1;
        for (i = 0; i < (i32)cfg->numRefPics; i ++)
        {
          if ((p->poc == (cfg->refPics[i].ref_pic + curPoc)) && cfg->refPics[i].used_by_cur)
          {
            bCand = 0;
            break;
          }
        }

        if (!bCand)
          continue;

        if (!ref)
          ref = p;
        else
        {
          i32 lastDelta = ref->poc - curPoc;
          if (ABS(iDelta) < ABS(lastDelta))
            ref = p;
        }
      }
    }
  }
  return ref;
}

static i32 check_multipass_references (struct vcenc_instance *vcenc_instance, struct Jenc_sps *s,
                                               VCEncGopPicConfig *pConfig, bool bRecovery)
{
  struct sw_picture *p;
  struct container *c = Jenc_get_container(vcenc_instance);
  i32 i, j;
  bool error = HANTRO_FALSE;
  VCEncGopPicConfig tmpConfig = *pConfig;
  VCEncGopPicConfig *cfg = &tmpConfig;

  for (i = 0; i < (i32)cfg->numRefPics; i ++)
  {
    bool iErr;
    i32 refPoc = vcenc_instance->poc + cfg->refPics[i].ref_pic;
    p = Jenc_get_ref_picture(vcenc_instance, cfg, i, bRecovery, &iErr);

    if (iErr)
      error = HANTRO_TRUE;
    else
      continue;

    bool remove = HANTRO_FALSE;
    if (!p)
      remove = HANTRO_TRUE;
    else if (p->poc != refPoc)
    {
      for (j = 0; j < (i32)cfg->numRefPics; j ++)
      {
        cfg->refPics[i].ref_pic = p->poc - vcenc_instance->poc;
        if((j != i) && (cfg->refPics[j].ref_pic == cfg->refPics[i].ref_pic))
        {
          if (cfg->refPics[i].used_by_cur)
            cfg->refPics[j].used_by_cur = 1;
          remove = HANTRO_TRUE;
          break;
        }
      }
    }

    if (remove)
    {
      for (j = i; j < (i32)cfg->numRefPics - 1; j ++)
      {
        cfg->refPics[j] = cfg->refPics[j + 1];
      }
      cfg->numRefPics --;
      i --;
    }
  }

  vcenc_instance->RpsInSliceHeader = HANTRO_FALSE;
  if (error)
  {
    if (cfg->numRefPics == 0)
    {
      vcenc_instance->rps_id = s->num_short_term_ref_pic_sets;
    }
    else
    {
      i32 rps_id = s->num_short_term_ref_pic_sets - 1;
      Jenc_vcenc_replace_rps(vcenc_instance, cfg, rps_id);
      vcenc_instance->rps_id = rps_id;
      if (!IS_H264(vcenc_instance->codecFormat))
        vcenc_instance->RpsInSliceHeader = HANTRO_TRUE;
    }
  }

  return cfg->numRefPics;
}

static VCEncPictureCodingType check_references(struct vcenc_instance *vcenc_instance,
                                                    const VCEncIn *pEncIn,
                                                    struct Jenc_sps *s,
                                                    VCEncGopPicConfig *cfg,
                                                    VCEncPictureCodingType codingType)
{
  u32 i;
  if (vcenc_instance->pass)
  {
    i32 numRef = check_multipass_references(vcenc_instance, s, cfg, pEncIn->gopPicIdx == 0);
    if (numRef == 0)
      codingType = VCENC_INTRA_FRAME;
    else if (numRef == 1)
      codingType = VCENC_PREDICTED_FRAME;
  }
  else
  {
    for (i = 0; i < cfg->numRefPics; i ++)
    {
      if (cfg->refPics[i].used_by_cur && (vcenc_instance->poc + cfg->refPics[i].ref_pic) < 0)
      {
        vcenc_instance->rps_id = s->num_short_term_ref_pic_sets - 1; //IPPPPPP
        codingType = VCENC_PREDICTED_FRAME;
      }
    }
  }
  return codingType;
}

/*------------------------------------------------------------------------------
select RPS according to coding type and interlace option
--------------------------------------------------------------------------------*/
static VCEncPictureCodingType get_rps_id(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn,
                                           struct Jenc_sps *s, u8 *rpsModify)
{
  VCEncGopConfig *gopCfg = (VCEncGopConfig *)(&(pEncIn->gopConfig));
  VCEncPictureCodingType codingType = pEncIn->codingType;
  i32 bak = vcenc_instance->RpsInSliceHeader;

  if ((vcenc_instance->gdrEnabled == 1) && (vcenc_instance->encStatus == VCENCSTAT_START_FRAME) && (vcenc_instance->gdrFirstIntraFrame == 0))
  {

    if (pEncIn->codingType == VCENC_INTRA_FRAME)
    {
      vcenc_instance->gdrStart++ ;
      codingType = VCENC_PREDICTED_FRAME;
    }
  }
  //Intra
  if (codingType == VCENC_INTRA_FRAME && vcenc_instance->poc == 0)
  {
    vcenc_instance->rps_id = s->num_short_term_ref_pic_sets;
  }
  //else if ((codingType == VCENC_INTRA_FRAME) && ((vcenc_instance->u32IsPeriodUsingLTR != 0 && vcenc_instance->u8IdxEncodedAsLTR != 0)
  //    ||  vcenc_instance->poc > 0))
  else if(pEncIn->i8SpecialRpsIdx >= 0)
  {
    vcenc_instance->rps_id = s->num_short_term_ref_pic_sets - 1 - pEncIn->gopConfig.special_size + pEncIn->i8SpecialRpsIdx;
  }
  else
  {
    vcenc_instance->rps_id = gopCfg->id;
    // check reference validness
    VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[vcenc_instance->rps_id]);
    codingType = check_references (vcenc_instance, pEncIn, s, cfg, codingType);
  }

  *rpsModify = vcenc_instance->RpsInSliceHeader;
  vcenc_instance->RpsInSliceHeader = bak;

  return codingType;
}

/*------------------------------------------------------------------------------
calculate the val of H264 nal_ref_idc
--------------------------------------------------------------------------------*/

static u32 h264_refIdc_val(const VCEncIn *pEncIn, struct sw_picture *pic)
{
  u32 nalRefIdc_2bit = 0;
  u8 idx = pEncIn->gopConfig.id;

  if(pEncIn->codingType == VCENC_INTRA_FRAME)
  {
    nalRefIdc_2bit = 3;
    return nalRefIdc_2bit;
  }
  for(int i = 1; i < pEncIn->gopConfig.special_size; i++)
  {
    if(pEncIn->gopConfig.special_size != 0 && (pEncIn->poc >= 0) && (pEncIn->poc % pEncIn->gopConfig.pGopPicSpecialCfg[i].i32Interval == 0))
    {
      if(pEncIn->gopConfig.pGopPicSpecialCfg[i].temporalId == -255)
        nalRefIdc_2bit = 2;
      else
      {
        if(pEncIn->gopConfig.pGopPicSpecialCfg[i].temporalId == 0)
        nalRefIdc_2bit = pic->nalRefIdc;
      else
        nalRefIdc_2bit = pEncIn->gopConfig.pGopPicSpecialCfg[i].temporalId;
      }
      return nalRefIdc_2bit;
    }
  }
  if(pEncIn->gopConfig.size != 0)
  {
    if(pEncIn->gopConfig.pGopPicCfg[idx].temporalId == -255 || pEncIn->gopConfig.pGopPicCfg[idx].temporalId == 0)
      nalRefIdc_2bit = pic->nalRefIdc;
    else
      nalRefIdc_2bit = pEncIn->gopConfig.pGopPicCfg[idx].temporalId;
  }
  return nalRefIdc_2bit;
}


/*------------------------------------------------------------------------------
check if delta_poc is in rps
(0 for unused, 1 for short term ref, 2+LongTermFrameIdx for long term ref)
--------------------------------------------------------------------------------*/
static int h264_ref_in_use(int delta_poc, int poc, struct rps *r, const i32 *long_term_ref_pic_poc)
{
  struct ref_pic *p;
  int i;
  for (i = 0; i < r->num_lt_pics; i++)
  {
    int id = r->ref_pic_lt[i].delta_poc;
    if(id >= 0 && (poc == long_term_ref_pic_poc[id]) && (INVALITED_POC != long_term_ref_pic_poc[id]))
      return 2+id;
  }

  for (i = 0; i < r->num_negative_pics; i++)
  {
    p = &r->ref_pic_s0[i];
    if(delta_poc == p->delta_poc)
      return 1;
  }

  for (i = 0; i < r->num_positive_pics; i++)
  {
    p = &r->ref_pic_s1[i];
    if(delta_poc == p->delta_poc)
      return 1;
  }
  return 0;
}
/*------------------------------------------------------------------------------
collect unused ref frames for H.264 MMO
--------------------------------------------------------------------------------*/
bool Jenc_h264_mmo_collect(struct vcenc_instance *vcenc_instance, struct sw_picture *pic, const VCEncIn *pEncIn)
{
  struct container *c = Jenc_get_container(vcenc_instance);
  if(!c) return HANTRO_FALSE;
  const VCEncGopConfig *gopCfg = (VCEncGopConfig *)(&(pEncIn->gopConfig));

  /* get the next coded pic's info */
  int poc2 = vcenc_instance->poc + gopCfg->delta_poc_to_next;
  int id = gopCfg->id_next;
  if (id == 255)
      id = pic->Jenc_sps->num_short_term_ref_pic_sets - 1 - ((pEncIn->gopConfig.special_size == 0)? 1: pEncIn->gopConfig.special_size);
  //if ( -1 != pEncIn->i8SpecialRpsIdx_next)
  //    id = pic->Jenc_sps->num_short_term_ref_pic_sets - 1 - pEncIn->gopConfig.special_size + pEncIn->i8SpecialRpsIdx_next;
  struct rps *r2 = (struct rps *)Jenc_get_parameter_set(c, RPS, id);
  if (!r2) return HANTRO_FALSE;

  struct rps *r = pic->rps;
  int i,j;

  if (pic->sliceInst->type == I_SLICE) {

    pic->nalRefIdc = 1;

    if (1 == vcenc_instance->layerInRefIdc)
      pic->nalRefIdc_2bit = h264_refIdc_val(pEncIn, pic);
    else
      pic->nalRefIdc_2bit = pic->nalRefIdc;

    pic->markCurrentLongTerm = (pEncIn->u8IdxEncodedAsLTR > 0 ? 1 : 0);
    pic->curLongTermIdx = (pic->markCurrentLongTerm ? (pEncIn->u8IdxEncodedAsLTR-1) : -1);

    if (vcenc_instance->poc == 0)
    {
        vcenc_instance->h264_mmo_nops = 0;
        return HANTRO_TRUE;
    }
  }

  /* marking the pic in the ref list */
  for (i = 0; i < r->before_cnt + r->after_cnt + r->lt_current_cnt; i++) {
    struct sw_picture *ref = pic->rpl[0][i];
    int inuse = h264_ref_in_use(ref->poc - poc2, ref->poc, r2, pEncIn->long_term_ref_pic); /* whether used as ref of next pic */
    if(inuse == 0) {
      vcenc_instance->h264_mmo_unref[vcenc_instance->h264_mmo_nops] = ref->frameNum;
      vcenc_instance->h264_mmo_unref_ext[vcenc_instance->h264_mmo_nops] = ref->frameNumExt;
      bool is_long = (h264_ref_in_use(ref->poc-pic->poc, ref->poc, r, pEncIn->long_term_ref_pic) >= 2);
      vcenc_instance->h264_mmo_long_term_flag[vcenc_instance->h264_mmo_nops] = is_long;
      vcenc_instance->h264_mmo_ltIdx[vcenc_instance->h264_mmo_nops++] = -1;  // unref short/long
    }
    else if(inuse > 1 && h264_ref_in_use(ref->poc-pic->poc, ref->poc, r, pEncIn->long_term_ref_pic) == 1 && (0 == pEncIn->bIsPeriodUsingLTR)) {
      vcenc_instance->h264_mmo_unref[vcenc_instance->h264_mmo_nops] = ref->frameNum;
      vcenc_instance->h264_mmo_unref_ext[vcenc_instance->h264_mmo_nops] = ref->frameNumExt;
      vcenc_instance->h264_mmo_long_term_flag[vcenc_instance->h264_mmo_nops] = 0;
      vcenc_instance->h264_mmo_ltIdx[vcenc_instance->h264_mmo_nops++] = inuse-2;  // str-> ltr
      ref->curLongTermIdx = inuse-2;
    }
  }

  for (i = 0; i < r->lt_follow_cnt; i++) {
    struct sw_picture *ref = Jenc_get_picture(c, r->lt_follow[i]);
    if(ref == NULL) {
      return HANTRO_FALSE;
    }
    int inuse = h264_ref_in_use(ref->poc - poc2, ref->poc, r2, pEncIn->long_term_ref_pic);
    if(inuse == 0) {
      vcenc_instance->h264_mmo_unref[vcenc_instance->h264_mmo_nops] = ref->frameNum;
      vcenc_instance->h264_mmo_unref_ext[vcenc_instance->h264_mmo_nops] = ref->frameNumExt;
      vcenc_instance->h264_mmo_long_term_flag[vcenc_instance->h264_mmo_nops] = 1;
      vcenc_instance->h264_mmo_ltIdx[vcenc_instance->h264_mmo_nops++] = -1;  // unref long
    }
    else if(inuse > 1 && h264_ref_in_use(ref->poc-pic->poc, ref->poc, r, pEncIn->long_term_ref_pic) == 1 && (0 == pEncIn->bIsPeriodUsingLTR)) {
      vcenc_instance->h264_mmo_unref[vcenc_instance->h264_mmo_nops] = ref->frameNum;
      vcenc_instance->h264_mmo_unref_ext[vcenc_instance->h264_mmo_nops] = ref->frameNumExt;
      vcenc_instance->h264_mmo_long_term_flag[vcenc_instance->h264_mmo_nops] = 0;
      vcenc_instance->h264_mmo_ltIdx[vcenc_instance->h264_mmo_nops++] = inuse-2;  // short -> long
      ref->curLongTermIdx = inuse-2;
    }
  }

  /* marking cur coded pic */
  i32 long_term_ref_pic_poc_2[VCENC_MAX_LT_REF_FRAMES];
  for (i = 0; i < VCENC_MAX_LT_REF_FRAMES; i++)
      long_term_ref_pic_poc_2[i] = INVALITED_POC;
  for(i = 0; i < pEncIn->gopConfig.ltrcnt; i++) {
    if(HANTRO_TRUE == pEncIn->bLTR_need_update[i])
      long_term_ref_pic_poc_2[i] = pic->poc;
    else
      long_term_ref_pic_poc_2[i] = pEncIn->long_term_ref_pic[i];
  }
  pic->nalRefIdc = h264_ref_in_use(pic->poc - poc2, pic->poc, r2, long_term_ref_pic_poc_2);
  pic->markCurrentLongTerm = 0;
  pic->curLongTermIdx = -1;
  if(pic->nalRefIdc >= 2) {
    pic->markCurrentLongTerm = 1;
    pic->curLongTermIdx = pic->nalRefIdc - 2;
    pic->nalRefIdc = 1;
  }
  if((0 != pEncIn->bIsPeriodUsingLTR) && (0!= pEncIn->u8IdxEncodedAsLTR)) {
    pic->markCurrentLongTerm = 1;
    pic->curLongTermIdx = pEncIn->u8IdxEncodedAsLTR-1;
    pic->nalRefIdc = 1;
  }
  if(1 == vcenc_instance->layerInRefIdc)
  {
    if(1 == pic->nalRefIdc)
      pic->nalRefIdc_2bit = h264_refIdc_val(pEncIn, pic);
    else
      pic->nalRefIdc_2bit = 0;
  }
  else
    pic->nalRefIdc_2bit = pic->nalRefIdc;
  return HANTRO_TRUE;
}

/*------------------------------------------------------------------------------
mark unused ref frames in lX_used_by_next_pic for H.264 MMO
--------------------------------------------------------------------------------*/
void Jenc_h264_mmo_mark_unref(regValues_s *regs, int frame_num, int ltrflag, int ltIdx, int cnt[2], struct sw_picture *pic)
{
  int i;

  // search frame_num in current reference list
  for (i = 0; i < pic->sliceInst->active_l0_cnt; i++)
  {
    if(frame_num == pic->rpl[0][i]->frameNum) {
      regs->l0_used_by_next_pic[i] = 0;
      regs->l0_long_term_flag[i] = ltrflag;
      regs->l0_referenceLongTermIdx[i] = ltIdx;
      return;
    }
  }

  if (pic->sliceInst->type == B_SLICE)
  {
    for (i = 0; i < pic->sliceInst->active_l1_cnt; i++)
    {
      if(frame_num == pic->rpl[1][i]->frameNum) {
        regs->l1_used_by_next_pic[i] = 0;
        regs->l1_long_term_flag[i] = ltrflag;
        regs->l1_referenceLongTermIdx[i] = ltIdx;
        return;
      }
    }
  }

  // insert in free slot
  ASSERT(cnt[0] + cnt[1] < 4);
  if(cnt[0] < 2) {
    i = cnt[0]++;
    regs->l0_delta_framenum[i] = pic->frameNum - frame_num;
    regs->l0_used_by_next_pic[i] = 0;
    regs->l0_long_term_flag[i] = ltrflag;
    regs->l0_referenceLongTermIdx[i] = ltIdx;
  } else {
    i = cnt[1]++;
    regs->l1_delta_framenum[i] = pic->frameNum - frame_num;
    regs->l1_used_by_next_pic[i] = 0;
    regs->l1_long_term_flag[i] = ltrflag;
    regs->l1_referenceLongTermIdx[i] = ltIdx;
  }
}

/*------------------------------------------------------------------------------
mark unused ref frames using frame_num given from app
--------------------------------------------------------------------------------*/
void Jenc_h264_mmo_mark_unref_ext(regValues_s *regs, int frame_num, int ltrflag, int ltIdx, int cnt[2], const VCEncExtParaIn *pEncExtParaIn)
{
  int i;

  // search frame_num in current reference list
  for (i = 0; i < pEncExtParaIn->params.h264Para.num_ref_idx_l0_active_minus1+1; i++)
  {
    if(frame_num == pEncExtParaIn->reflist0[i].frame_num) {
      regs->l0_used_by_next_pic[i] = 0;
      regs->l0_long_term_flag[i] = ltrflag;
      regs->l0_referenceLongTermIdx[i] = ltIdx;
      return;
    }
  }

  if (pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_B)
  {
    for (i = 0; i < pEncExtParaIn->params.h264Para.num_ref_idx_l1_active_minus1+1; i++)
    {
      if(frame_num == pEncExtParaIn->reflist1[i].frame_num) {
        regs->l1_used_by_next_pic[i] = 0;
        regs->l1_long_term_flag[i] = ltrflag;
        regs->l1_referenceLongTermIdx[i] = ltIdx;
        return;
      }
    }
  }

  // insert in free slot
  ASSERT(cnt[0] + cnt[1] < 4);
  if(cnt[0] < 2) {
    i = cnt[0]++;
    regs->l0_delta_framenum[i] = regs->frameNum - frame_num;
    regs->l0_used_by_next_pic[i] = 0;
    regs->l0_long_term_flag[i] = ltrflag;
    regs->l0_referenceLongTermIdx[i] = ltIdx;
  } else {
    i = cnt[1]++;
    regs->l1_delta_framenum[i] = regs->frameNum - frame_num;
    regs->l1_used_by_next_pic[i] = 0;
    regs->l1_long_term_flag[i] = ltrflag;
    regs->l1_referenceLongTermIdx[i] = ltIdx;
  }
}//*/

#ifdef CTBRC_STRENGTH

static i32 float2fixpoint(float data)
{
    i32 i = 0;
    i32 result = 0;
    float pow2=2.0;
    /*0.16 format*/
    float base = 0.5;
    for(i= 0; i<16 ;i++)
    {
        result <<= 1;
        if(data >= base)
        {
           result |= 1;
           data -= base;

        }

        pow2 *= 2;
        base = 1.0/pow2;

    }
    return result;

}
static i32 float2fixpoint8(float data)
{
    i32 i = 0;
    i32 result = 0;
    float pow2=2.0;
    /*0.16 format*/
    float base = 0.5;
    for(i= 0; i<8 ;i++)
    {
        result <<= 1;
        if(data >= base)
        {
           result |= 1;
           data -= base;

        }

        pow2 *= 2;
        base = 1.0/pow2;

    }
    return result;

}
#endif

static VCEncRet getCtbRcParams (struct vcenc_instance *inst, enum slice_type type)
{
  if (inst == NULL)
    return VCENC_ERROR;

  ctbRateControl_s *pCtbRateCtrl = &(inst->rateControl.ctbRateCtrl);
  asicData_s *asic = &(inst->asic);

  if ((!asic->regs.asicCfg.ctbRcVersion) || (!(asic->regs.rcRoiEnable&0x08)))
    return VCENC_ERROR;

  pCtbRateCtrl->models[type].x0 = asic->regs.ctbRcModelParam0 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTB_RC_MODEL_PARAM0);

  pCtbRateCtrl->models[type].x1 = asic->regs.ctbRcModelParam1 =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTB_RC_MODEL_PARAM1);

  pCtbRateCtrl->models[type].preFrameMad = asic->regs.prevPicLumMad =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_PREV_PIC_LUM_MAD);

  pCtbRateCtrl->qpSumForRc = asic->regs.ctbQpSumForRc =
    Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTB_QP_SUM_FOR_RC) |
   (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTB_QP_SUM_FOR_RC_MSB) << 24);

  pCtbRateCtrl->models[type].started = 1;

  return VCENC_OK;
}

static void onSliceReady (struct vcenc_instance *inst, VCEncSliceReady *slice_callback)
{
  if ((!inst) || (!slice_callback))
    return;

  asicData_s *asic = &inst->asic;
  i32 sliceInc = slice_callback->slicesReady - slice_callback->slicesReadyPrev;
  if (sliceInc > 0)
  {
    slice_callback->nalUnitInfoNum += sliceInc;
    if (asic->regs.prefixnal_svc_ext)
      slice_callback->nalUnitInfoNum += sliceInc;
  }

  if (inst->sliceReadyCbFunc &&
      (slice_callback->slicesReadyPrev < slice_callback->slicesReady) &&
      (inst->rateControl.hrd == ENCHW_NO))
  {
    inst->sliceReadyCbFunc(slice_callback);
  }

  slice_callback->slicesReadyPrev = slice_callback->slicesReady;
  slice_callback->nalUnitInfoNumPrev = slice_callback->nalUnitInfoNum;
}

void Jenc_VCEncAxiFeEnable(void *inst, void *ewl)
{
#ifdef SUPPORT_AXIFE
  u32 axiFeFuse;
  AXIFE_REG_OUT regs;
  struct AxiFeChns channelCfg;
  struct AxiFeCommonCfg commonCfg;
  u32 i;
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  asicData_s *asic = &vcenc_instance->asic;
  REG *reg = &(regs.registers[0]);
  struct ChnDesc *rdChannel = NULL;
  struct ChnDesc *wrChannel = NULL;

  if(vcenc_instance->axiFEEnable == 0)
    return;

 //cutree not support security mode
 if(ewl != NULL && vcenc_instance->axiFEEnable ==  3)
   return;

  if(ewl == NULL)
    ewl = (void *)asic->ewl;

  memset(&regs, 0, sizeof(AXIFE_REG_OUT));
  if(vcenc_instance->axiFEEnable == 3)
  {
    memset(&channelCfg, 0, sizeof(struct AxiFeChns));
    memset(&commonCfg, 0, sizeof(struct AxiFeCommonCfg));
    axiFeFuse = JencEWLReadRegbyClientType(ewl, 0, JENC_EWL_CLIENT_TYPE_AXIFE);

    //example to config AXIFE
    channelCfg.nbr_rd_chns = 1;
    channelCfg.nbr_wr_chns = 1;
    rdChannel = calloc(1, sizeof(struct ChnDesc));
    wrChannel = calloc(1, sizeof(struct ChnDesc));

    rdChannel->sw_axi_base_addr_id = asic->regs.inputLumBase >> 32;
    rdChannel->sw_axi_start_addr = asic->regs.inputLumBase & 0xFFFFFFFF;
    rdChannel->sw_axi_end_addr = (asic->regs.inputLumBase + asic->regs.input_luma_stride * vcenc_instance->preProcess.lumHeightSrc) & 0xFFFFFFFF;
    rdChannel->sw_axi_user = 0;
    rdChannel->sw_axi_ns = 0;

    wrChannel->sw_axi_base_addr_id = asic->regs.inputLumBase >> 32;
    wrChannel->sw_axi_start_addr = asic->regs.inputLumBase & 0xFFFFFFFF;
    wrChannel->sw_axi_end_addr = (asic->regs.inputLumBase + asic->regs.input_luma_stride * vcenc_instance->preProcess.lumHeightSrc) & 0xFFFFFFFF;
    wrChannel->sw_axi_user = 0;
    wrChannel->sw_axi_ns = 0;

    channelCfg.rd_channels = rdChannel;
    channelCfg.wr_channels = wrChannel;

    Jenc_ConfigAxiFeChns(reg, axiFeFuse, &channelCfg);

    commonCfg.sw_secure_mode = 1;
    commonCfg.sw_axi_user_mode = 3;
    commonCfg.sw_axi_prot_mode = 1;
    Jenc_ConfigAxiFe(reg, &commonCfg);
  }

  Jenc_EnableAxiFe(reg, vcenc_instance->axiFEEnable == 2);
  //write registers to AXIFE
  for(i = 0; i < AXIFE_REG_NUM; i++)
  {
    if(regs.registers[i].flag && i!= 10)
      JencEWLWriteRegbyClientType(ewl, regs.registers[i].offset, regs.registers[i].value, JENC_EWL_CLIENT_TYPE_AXIFE);
  }

  //finally set enable register
  JencEWLWriteRegbyClientType(ewl, regs.registers[10].offset, regs.registers[10].value, JENC_EWL_CLIENT_TYPE_AXIFE);

  for(i = 0; i < AXIFE_REG_NUM; i++)
  {
    if(regs.registers[i].flag && i!= 10)
      JencEWLWriteRegbyClientType(ewl, regs.registers[i].offset, regs.registers[i].value, JENC_EWL_CLIENT_TYPE_AXIFE_1);
  }

  //finally set enable register
  JencEWLWriteRegbyClientType(ewl, regs.registers[10].offset, regs.registers[10].value, JENC_EWL_CLIENT_TYPE_AXIFE_1);

  if(rdChannel)
    free(rdChannel);

  if(wrChannel)
    free(wrChannel);

#endif
}

void Jenc_VCEncAxiFeDisable(const void *ewl, void *data)
{
#ifdef SUPPORT_AXIFE
  AXIFE_REG_OUT regs;
  REG *reg = &(regs.registers[0]);

  memset(&regs, 0, sizeof(AXIFE_REG_OUT));
  Jenc_DisableAxiFe(reg);
  JencEWLWriteBackRegbyClientType(ewl, regs.registers[10].offset, regs.registers[10].value, JENC_EWL_CLIENT_TYPE_AXIFE);
#endif
}

VCEncRet Jenc_VCEncSetApbFilter(void *inst)
{
#ifdef SUPPORT_APBFT
  ApbFilterREG *regs;
  struct ApbFilterCfg cfg;
  struct ApbFilterMask *mask;
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  asicData_s *asic = &vcenc_instance->asic;
  u32 i;
  u32 protect_reg_size = 400;//for VC8000E, only 400 regs will be protected

  //example to config ApbFilter
  regs = JencEWLcalloc(protect_reg_size, sizeof(ApbFilterREG));
  if (regs == NULL)
  {
    VLOG_ERROR("JencEWLcalloc protect_reg_size:%d failed!\n", sizeof(ApbFilterREG));
    return VCENC_MEMORY_ERROR;
  }
  mask = JencEWLcalloc(protect_reg_size, sizeof(struct ApbFilterMask));
  if (mask == NULL)
  {
    VLOG_ERROR("JencEWLcalloc protect_reg_size:%d failed!\n", sizeof(ApbFilterMask));
    return VCENC_MEMORY_ERROR;
  }

  for(i = 0; i < protect_reg_size; i++)
  {
    mask[i].page_idx = 0;
    mask[i].reg_idx = i;
    mask[i].value = 0;
  }
  cfg.reg_mask = mask;
  cfg.num_regs = protect_reg_size;

  Jenc_ConfigApbFilter(regs, &cfg);

  //write registers to AXIFE
  for(i = 0; i < protect_reg_size; i++)
  {
    if(regs[i].flag)
      JencEWLWriteRegbyClientType(asic->ewl, regs[i].offset, regs[i].value, JENC_EWL_CLIENT_TYPE_APBFT);
  }

  //set page select
  Jenc_SelApbFilterPage(&regs[0], 0, protect_reg_size*4);
  JencEWLWriteRegbyClientType(asic->ewl, regs[0].offset, regs[0].value, JENC_EWL_CLIENT_TYPE_APBFT);

  free(regs);
  free(mask);
#endif
  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncFindNextPic
    Description   : get gopSize/rps for next frame
    Return type   : void
    Argument      : inst - encoder instance
------------------------------------------------------------------------------*/
VCEncPictureCodingType Jenc_VCEncFindNextPic (VCEncInst inst, VCEncIn *encIn, i32 nextGopSize, const u8 *gopCfgOffset, bool forceIDR)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  VCEncPictureCodingType nextCodingType;
  int idx, offset, cur_poc, delta_poc_to_next;
  bool bIsCodingTypeChanged;
  int next_gop_size = nextGopSize;
  VCEncGopConfig *gopCfg = (VCEncGopConfig *)(&(encIn->gopConfig));
  i32 *p_picture_cnt = &encIn->picture_cnt;
  i32 last_idr_picture_cnt = encIn->last_idr_picture_cnt;
  int picture_cnt_tmp = *p_picture_cnt;
  i32 i32LastPicPoc;

  //get current poc within GOP
  if (encIn->codingType == VCENC_INTRA_FRAME && (encIn->poc == 0))
  {
    // last is an IDR
    cur_poc = 0;
    encIn->gopPicIdx = 0;
  }
  else
  {
    //Update current idx and poc within a GOP
    idx = encIn->gopPicIdx + gopCfgOffset[encIn->gopSize];
    cur_poc = gopCfg->pGopPicCfg[idx].poc;
    encIn->gopPicIdx = (encIn->gopPicIdx + 1) % encIn->gopSize;
    if (encIn->gopPicIdx == 0)
      cur_poc -= encIn->gopSize;
  }

  //a GOP end, to start next GOP
  if (encIn->gopPicIdx == 0)
    offset = gopCfgOffset[next_gop_size];
  else
    offset = gopCfgOffset[encIn->gopSize];

  //get next poc within GOP, and delta_poc
  idx = encIn->gopPicIdx + offset;
  delta_poc_to_next = gopCfg->pGopPicCfg[idx].poc - cur_poc;
  //next picture cnt
  *p_picture_cnt = picture_cnt_tmp + delta_poc_to_next;

  //Handle Tail (seqence end or cut by an I frame)
  {
    //just finished a GOP and will jump to a P frame
    if (encIn->gopPicIdx == 0 && delta_poc_to_next > 1)
    {
       int gop_end_pic = *p_picture_cnt;
       int gop_shorten = 0, gop_shorten_idr = 0, gop_shorten_tail = 0;

       //cut  by an IDR
       if ((gopCfg->idr_interval) && ((gop_end_pic - last_idr_picture_cnt) >= gopCfg->idr_interval) && !gopCfg->gdrDuration)
          gop_shorten_idr = 1 + ((gop_end_pic - last_idr_picture_cnt) - gopCfg->idr_interval);

       //handle sequence tail
       while (((Jenc_CalNextPic(gopCfg, gop_end_pic --) + gopCfg->firstPic) > gopCfg->lastPic) &&
               (gop_shorten_tail < next_gop_size - 1))
         gop_shorten_tail ++;

       gop_shorten = gop_shorten_idr > gop_shorten_tail ? gop_shorten_idr : gop_shorten_tail;

       if (gop_shorten >= next_gop_size)
       {
         //for gopsize = 1
         *p_picture_cnt = picture_cnt_tmp + 1 - cur_poc;
       }
       else if (gop_shorten > 0)
       {
         //reduce gop size
         const int max_reduced_gop_size = gopCfg->gopLowdelay ? 1 : 4;
         next_gop_size -= gop_shorten;
         if (next_gop_size > max_reduced_gop_size)
           next_gop_size = max_reduced_gop_size;

         idx = gopCfgOffset[next_gop_size];
         delta_poc_to_next = gopCfg->pGopPicCfg[idx].poc - cur_poc;
         *p_picture_cnt = picture_cnt_tmp + delta_poc_to_next;
       }
       encIn->gopSize = next_gop_size;
    }

    i32LastPicPoc = encIn->poc;
    encIn->poc += *p_picture_cnt - picture_cnt_tmp;
    bIsCodingTypeChanged = HANTRO_FALSE;
    //next coding type
    bool forceIntra = (gopCfg->idr_interval && ((*p_picture_cnt - last_idr_picture_cnt) >= gopCfg->idr_interval)) || forceIDR;
    if (forceIntra)
    {
      nextCodingType = VCENC_INTRA_FRAME;
      encIn->bIsIDR = HANTRO_TRUE;
      bIsCodingTypeChanged = HANTRO_TRUE;
    }
    else
    {
      encIn->bIsIDR = HANTRO_FALSE;
      idx = encIn->gopPicIdx + gopCfgOffset[encIn->gopSize];
      nextCodingType = gopCfg->pGopPicCfg[idx].codingType;
    }
  }
  gopCfg->id = encIn->gopPicIdx + gopCfgOffset[encIn->gopSize];
  {
    // guess next rps needed for H.264 DPB management (MMO), assume gopSize unchanged.
    // gopSize change only occurs on adaptive GOP or tail GOP (lowdelay = 0).
    // then the next RPS is 1st of default RPS of some gopSize, which only includes the P frame of last GOP
    i32 next_poc = gopCfg->pGopPicCfg[gopCfg->id].poc;
    i32 gopPicIdx = (encIn->gopPicIdx + 1) % encIn->gopSize;
    i32 gopSize = encIn->gopSize;
    if (gopPicIdx == 0)
    {
      next_poc -= gopSize;
    }
    gopCfg->id_next = gopPicIdx + gopCfgOffset[gopSize];
    gopCfg->delta_poc_to_next = gopCfg->pGopPicCfg[gopCfg->id_next].poc - next_poc;

    if ((gopPicIdx == 0) && (gopCfg->delta_poc_to_next > 1) && (gopCfg->idr_interval && ((encIn->poc + gopCfg->delta_poc_to_next) >= gopCfg->idr_interval)))
    {
        i32 i32gopsize;
        i32gopsize = gopCfg->idr_interval - encIn->poc - 2;

        if (i32gopsize > 0)
        {
            int max_reduced_gop_size = gopCfg->gopLowdelay ? 1 : 4;
            if (i32gopsize > max_reduced_gop_size)
                i32gopsize = max_reduced_gop_size;

            idx = gopCfgOffset[i32gopsize];
            delta_poc_to_next = gopCfg->pGopPicCfg[idx].poc - cur_poc;

            gopCfg->id_next = gopPicIdx + gopCfgOffset[i32gopsize];
            gopCfg->delta_poc_to_next = gopCfg->pGopPicCfg[gopCfg->id_next].poc - next_poc;
        }
    }

    if(gopCfg->gdrDuration==0 && gopCfg->idr_interval  && (encIn->poc+gopCfg->delta_poc_to_next) % gopCfg->idr_interval == 0)
      gopCfg->id_next = -1;
  }

  if (vcenc_instance->lookaheadDepth == 0)
  {
    //Handle the first few frames for lowdelay
    if ((nextCodingType != VCENC_INTRA_FRAME))
    {
      int i;
      VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[gopCfg->id]);
      for (i = 0; i < cfg->numRefPics; i ++)
      {
        if ((encIn->poc + cfg->refPics[i].ref_pic) < 0)
        {
          int curCfgEnd = gopCfgOffset[encIn->gopSize] + encIn->gopSize;
          int cfgOffset = encIn->poc - 1;
          if ((curCfgEnd + cfgOffset) > gopCfg->size)
              cfgOffset = 0;

          gopCfg->id = curCfgEnd + cfgOffset;
          nextCodingType = gopCfg->pGopPicCfg[gopCfg->id].codingType;
          bIsCodingTypeChanged = HANTRO_TRUE;
          break;
        }
      }
    }
  }

  Jenc_GenNextPicConfig(encIn, gopCfg->gopCfgOffset, IS_H264(vcenc_instance->codecFormat), i32LastPicPoc);
  if (bIsCodingTypeChanged == HANTRO_FALSE)
      nextCodingType = encIn->gopCurrPicConfig.codingType;
  if (nextCodingType == VCENC_INTRA_FRAME && ((encIn->poc == 0)|| (encIn->bIsIDR)))
  {
    // refresh IDR POC for !GDR
    if(!encIn->gopConfig.gdrDuration) encIn->poc = 0;
    encIn->last_idr_picture_cnt = encIn->picture_cnt;
  }

  encIn->codingType = (encIn->poc == 0) ? VCENC_INTRA_FRAME : nextCodingType;

  return nextCodingType;
}

VCEncRet Jenc_VCEncStrmWaitReady(VCEncInst inst, const VCEncIn *pEncIn, VCEncOut *pEncOut, struct sw_picture *pic, VCEncSliceReady *slice_callback, struct container *c, u32 waitCoreJobid)
{
   struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
   asicData_s *asic = &vcenc_instance->asic;
   struct node *n;
   struct Jenc_sps *s = pic->Jenc_sps;

  i32 ret = VCENC_ERROR;
  u32 status = ASIC_STATUS_ERROR;
  int  sliceNum;
  i32  i;
  JENC_EWLCoreWaitJob_t *out = NULL;

  do
  {
    /* Encode one frame */
    i32 ewl_ret = EWL_OK;

    /* Wait for IRQ for every slice or for complete frame */
    if(!asic->regs.bVCMDEnable)
    {
      if((out = (JENC_EWLCoreWaitJob_t *)JencEWLDequeueCoreOutJob(asic->ewl, waitCoreJobid)) == NULL)
        break;

      if ((asic->regs.sliceNum > 1) && vcenc_instance->sliceReadyCbFunc)
      {
        status = out->out_status;
             slice_callback->slicesReady = out->slices_rdy;
      }
      else
        status = out->out_status;

      memcpy(asic->regs.regMirror, out->VC8000E_reg, sizeof(u32)*ASIC_SWREG_AMOUNT);
      JencEWLPutJobtoPool(asic->ewl, (struct node *)out);
    }
    else
    {
      ewl_ret = JencEncWaitCmdbuf(asic->ewl, pic->cmdbufid, &status);
    }

    if (ewl_ret != EWL_OK && asic->regs.bVCMDEnable)
    {
      status = ASIC_STATUS_ERROR;

      if (ewl_ret == EWL_ERROR)
      {
        /* IRQ error => Stop and release HW */
        ret = VCENC_SYSTEM_ERROR;
      }
      else    /*if(ewl_ret == EWL_HW_WAIT_TIMEOUT) */
      {
        /* IRQ Timeout => Stop and release HW */
        ret = VCENC_HW_TIMEOUT;
      }
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR Fatal system error ewl_ret != EWL_OK.");
      JencEncAsicStop(asic->ewl);
      /* Release HW so that it can be used by other codecs */
      JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
    }
    else
    {
      /* Check ASIC status bits and possibly release HW */
      if(vcenc_instance->asic.regs.bVCMDEnable)
        status = Jenc_EncAsicCheckStatus_V2(asic, status);
      else if(!(status & (ASIC_STATUS_SLICE_READY | ASIC_STATUS_LINE_BUFFER_DONE | ASIC_STATUS_SEGMENT_READY)))
        JencEncAsicGetRegisters(asic->ewl, &asic->regs, asic->dumpRegister, 0);

      switch (status)
      {
        case ASIC_STATUS_ERROR:
          APITRACEERR("Jenc_VCEncStrmEncode: ERROR HW bus access error");
          if(vcenc_instance->asic.regs.bVCMDEnable)
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          ret = VCENC_ERROR;
          break;
        case ASIC_STATUS_FUSE_ERROR:
          if(vcenc_instance->asic.regs.bVCMDEnable)
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          ret = VCENC_ERROR;
          break;
        case ASIC_STATUS_HW_TIMEOUT:
          APITRACEERR("Jenc_VCEncStrmEncode: ERROR HW/IRQ timeout");
          if(vcenc_instance->asic.regs.bVCMDEnable)
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          ret = VCENC_HW_TIMEOUT;
          break;
        case ASIC_STATUS_SLICE_READY:
        case ASIC_STATUS_LINE_BUFFER_DONE: /* low latency */
        case (ASIC_STATUS_LINE_BUFFER_DONE|ASIC_STATUS_SLICE_READY):
        case ASIC_STATUS_SEGMENT_READY:
          if (status&ASIC_STATUS_LINE_BUFFER_DONE)
          {
            APITRACE("Jenc_VCEncStrmEncode: IRQ Line Buffer INT");
            /* clear the interrupt */
            if (!vcenc_instance->inputLineBuf.inputLineBufHwModeEn)
            { /* SW handshaking: Software will clear the line buffer interrupt and then update the
               *   line buffer write pointer, when the next line buffer is ready. The encoder will
               *   continue to run when detected the write pointer is updated.  */
              if (vcenc_instance->inputLineBuf.cbFunc)
                  vcenc_instance->inputLineBuf.cbFunc(vcenc_instance->inputLineBuf.cbData);
            }
          }
          if (status&ASIC_STATUS_SLICE_READY)
          {
            APITRACE("Jenc_VCEncStrmEncode: IRQ Slice Ready");
            /* Issue callback to application telling how many slices
             * are available. */
            onSliceReady (vcenc_instance, slice_callback);
          }

          if (status&ASIC_STATUS_SEGMENT_READY)
          {
            APITRACE("Jenc_VCEncStrmEncode: IRQ stream segment INT");
            while(vcenc_instance->streamMultiSegment.streamMultiSegmentMode != 0 &&
                  vcenc_instance->streamMultiSegment.rdCnt < Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STRM_SEGMENT_WR_PTR))
            {
              if (vcenc_instance->streamMultiSegment.cbFunc)
                vcenc_instance->streamMultiSegment.cbFunc(vcenc_instance->streamMultiSegment.cbData);
              /*note: must make sure the data of one segment is read by app then rd counter can increase*/
              vcenc_instance->streamMultiSegment.rdCnt++;
            }
            Jenc_EncAsicWriteRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STRM_SEGMENT_RD_PTR,vcenc_instance->streamMultiSegment.rdCnt);
          }
          ret = VCENC_OK;
          break;
        case ASIC_STATUS_BUFF_FULL:
          APITRACEERR("Jenc_VCEncStrmEncode: ERROR buffer full.");
          if(vcenc_instance->asic.regs.bVCMDEnable)
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          vcenc_instance->output_buffer_over_flow = 1;
          //inst->stream.overflow = ENCHW_YES;
          ret = VCENC_OK;
          break;
        case ASIC_STATUS_HW_RESET:
          APITRACEERR("Jenc_VCEncStrmEncode: ERROR HW abnormal");
          if(vcenc_instance->asic.regs.bVCMDEnable)
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          ret = VCENC_HW_RESET;
          break;
        case ASIC_STATUS_FRAME_READY:
          APITRACE("Jenc_VCEncStrmEncode: IRQ Frame Ready");
          /* clear all interrupt */
          if (asic->regs.sliceReadyInterrupt)
          {
            //this is used for hardware interrupt.
            slice_callback->slicesReady = asic->regs.sliceNum;
            onSliceReady (vcenc_instance, slice_callback);
          }

          asic->regs.frameCodingType =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_FRAME_CODING_TYPE);
          asic->regs.outputStrmSize[0] =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_OUTPUT_STRM_BUFFER_LIMIT);
          vcenc_instance->stream.byteCnt += asic->regs.outputStrmSize[0];
          vcenc_instance->stream.stream += asic->regs.outputStrmSize[0];
          pEncOut->sliceHeaderSize =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SLICE_HEADER_SIZE);

          sliceNum = 0;
          u32 *sizeTbl = asic->sizeTbl[(vcenc_instance->jobCnt+1)%vcenc_instance->parallelCoreNum].virtualAddress;
          if (sizeTbl)
          {
            /* if size table wasn't written, set it encoded frame size for later use */
            if ((Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_NAL_SIZE_WRITE) == 0))
              sizeTbl[pEncOut->numNalus] = asic->regs.outputStrmSize[0];

            // for ivf file format, freame header should be in one NAL with stream coded by hw
            if(IS_VP9(vcenc_instance->codecFormat) || IS_AV1(vcenc_instance->codecFormat))
              sizeTbl[pEncOut->numNalus] += vcenc_instance->strmHeaderLen;

            for (n = pic->slice.tail; n; n = n->next)
            {
              u32 sliceBytes = sizeTbl[pEncOut->numNalus];
              pEncOut->numNalus++;
              if (asic->regs.prefixnal_svc_ext)
              {
                sliceBytes += sizeTbl[pEncOut->numNalus];
                pEncOut->numNalus++;
              }

              APIPRINT(vcenc_instance->verbose, "POC %3d slice %d size=%d\n", vcenc_instance->poc, sliceNum, sliceBytes);
              sliceNum++;
              pEncOut->maxSliceStreamSize = MAX(pEncOut->maxSliceStreamSize, sliceBytes);
            }
            sizeTbl[pEncOut->numNalus] = 0;
          }
          u32 hashval = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_HASH_VAL);
          u32 hashoffset = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_HASH_OFFSET);
          Jenc_hash_reset(&vcenc_instance->hashctx, hashval, hashoffset);
          hashval = Jenc_hash_finalize(&vcenc_instance->hashctx);
          if(vcenc_instance->hashctx.hash_type == 1)
            printf("POC %3d crc32 %08x\n", vcenc_instance->poc, hashval);
          else if(vcenc_instance->hashctx.hash_type == 2)
            printf("POC %3d Jenc_checksum %08x\n", vcenc_instance->poc, hashval);
          Jenc_hash_init(&vcenc_instance->hashctx, vcenc_instance->hashctx.hash_type);
          vcenc_instance->streamMultiSegment.rdCnt = 0;

#ifdef CTBRC_STRENGTH
          asic->regs.sumOfQP =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_QP_SUM) |
           (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_QP_SUM_MSB) << 26);
          asic->regs.sumOfQPNumber =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_QP_NUM) |
           (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_QP_NUM_MSB) << 20);
          asic->regs.picComplexity =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_PIC_COMPLEXITY) |
           (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_PIC_COMPLEXITY_MSB) << 23);
#else
          asic->regs.averageQP =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_AVERAGEQP);
          asic->regs.nonZeroCount =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_NONZEROCOUNT);
#endif

          //for adaptive GOP
          vcenc_instance->rateControl.intraCu8Num= asic->regs.intraCu8Num =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_INTRACU8NUM) |
           (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_INTRACU8NUM_MSB) << 20);

          vcenc_instance->rateControl.skipCu8Num= asic->regs.skipCu8Num =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SKIPCU8NUM) |
           (Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_SKIPCU8NUM_MSB) << 20);

          vcenc_instance->rateControl.PBFrame4NRdCost = asic->regs.PBFrame4NRdCost =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_PBFRAME4NRDCOST);

          // video stabilization
          asic->regs.stabMotionMin = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MINIMUM);
          asic->regs.stabMotionSum = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MOTION_SUM);
          asic->regs.stabGmvX    = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_GMVX);
          asic->regs.stabGmvY    = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_GMVY);
          asic->regs.stabMatrix1 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX1);
          asic->regs.stabMatrix2 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX2);
          asic->regs.stabMatrix3 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX3);
          asic->regs.stabMatrix4 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX4);
          asic->regs.stabMatrix5 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX5);
          asic->regs.stabMatrix6 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX6);
          asic->regs.stabMatrix7 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX7);
          asic->regs.stabMatrix8 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX8);
          asic->regs.stabMatrix9 = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_STAB_MATRIX9);

          //CTB_RC
          asic->regs.ctbBitsMin =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTBBITSMIN);
          asic->regs.ctbBitsMax =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_CTBBITSMAX);
          asic->regs.totalLcuBits =
            Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_TOTALLCUBITS);
          vcenc_instance->iThreshSigmaCalcd = asic->regs.nrThreshSigmaCalced =
                                               Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_THRESH_SIGMA_CALCED);
          vcenc_instance->iSigmaCalcd = asic->regs.nrFrameSigmaCalced =
                                         Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_FRAME_SIGMA_CALCED);

          /* motion score for 2-pass Agop */
          if (asic->regs.asicCfg.bMultiPassSupport) {
            asic->regs.motionScore[0][0] = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_MOTION_SCORE_L0_0);;
            asic->regs.motionScore[0][1] = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_MOTION_SCORE_L0_1);;
            asic->regs.motionScore[1][0] = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_MOTION_SCORE_L1_0);;
            asic->regs.motionScore[1][1] = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_MOTION_SCORE_L1_1);;
          }

          if (asic->regs.asicCfg.ssimSupport && asic->regs.ssim)
            Jenc_EncGetSSIM(vcenc_instance, pEncOut);

          /*calculate PSNR under several conditions */
          Jenc_EncGetPSNR(vcenc_instance, pEncOut);

          if ((asic->regs.asicCfg.ctbRcVersion > 0) && IS_CTBRC_FOR_BITRATE(vcenc_instance->rateControl.ctbRc))
            getCtbRcParams(vcenc_instance, pic->sliceInst->type);

          /* should before Release */
          if (vcenc_instance->pass!=1)
          {
            void * prof_data = (void*)EncAsicGetAddrRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_COMPRESSEDCOEFF_BASE);
            i32 qp = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_PIC_QP);
            i32 poc = Jenc_EncAsicGetRegisterValue(asic->ewl, asic->regs.regMirror, HWIF_ENC_POC);

            JencEWLTraceProfile(asic->ewl, prof_data,qp,poc);
          }

          if(vcenc_instance->pass == 1 && vcenc_instance->asic.regs.asicCfg.bMultiPassSupport)
          {
            pic->outForCutree.motionScore[0][0] = vcenc_instance->asic.regs.motionScore[0][0];
            pic->outForCutree.motionScore[0][1] = vcenc_instance->asic.regs.motionScore[0][1];
            pic->outForCutree.motionScore[1][0] = vcenc_instance->asic.regs.motionScore[1][0];
            pic->outForCutree.motionScore[1][1] = vcenc_instance->asic.regs.motionScore[1][1];
          }

          if(vcenc_instance->asic.regs.bVCMDEnable)
          {
            JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
          }
          if(s->long_term_ref_pics_present_flag) {
            if( 0 != pEncIn->u8IdxEncodedAsLTR) {
                if(IS_H264(vcenc_instance->codecFormat)) {
                  // H.264 ltr can not be reused after replaced
                  struct sw_picture *p_old;
                  i32 old_poc = pEncIn->long_term_ref_pic[pEncIn->u8IdxEncodedAsLTR-1];
                  if (old_poc >= 0 && (p_old = Jenc_get_picture(c, old_poc))) {
                    p_old->h264_no_ref = HANTRO_TRUE;
                  }
                }
              }
#if 0  /* Not needed (mmco=4, set max long-term index) */
            if(codingType == VCENC_INTRA_FRAME && pic->poc == 0 && vcenc_instance->rateControl.ltrCnt > 0)
              asic->regs.max_long_term_frame_idx_plus1 = vcenc_instance->rateControl.ltrCnt;
            else
#endif
              asic->regs.max_long_term_frame_idx_plus1 = 0;
          }
          ret = VCENC_OK;
          break;

        default:
          APITRACEERR("Jenc_VCEncStrmEncode: ERROR Fatal system error");
          /* should never get here */
          ASSERT(0);
          ret = VCENC_ERROR;
      }
    }
  }
  while (status & (ASIC_STATUS_SLICE_READY|ASIC_STATUS_LINE_BUFFER_DONE|ASIC_STATUS_SEGMENT_READY));

  return ret;
}

static u32 round_this_value(u32 value)
{
  u32 i = 0,tmp = 0;
  while (4095 < (value >> (6 + i++)));
  tmp = (value >> (6 + i))<<(6 + i);
  return tmp;
}
void Jenc_useExtPara(const VCEncExtParaIn *pEncExtParaIn, asicData_s *asic,i32 h264Codec, struct vcenc_instance *vcenc_instance)
{
  i32 i,j;
  regValues_s *regs=&asic->regs;


  regs->poc = pEncExtParaIn->recon.poc;
  regs->frameNum = pEncExtParaIn->recon.frame_num;

  //                = pEncExtParaIn->recon.flags;
  regs->reconLumBase = pEncExtParaIn->recon.busReconLuma;
  regs->reconCbBase  = pEncExtParaIn->recon.busReconChromaUV;

  regs->reconL4nBase = pEncExtParaIn->recon.reconLuma_4n;

  regs->recon_luma_compress_tbl_base = pEncExtParaIn->recon.compressTblReconLuma;
  regs->recon_chroma_compress_tbl_base = pEncExtParaIn->recon.compressTblReconChroma;

  regs->colctbs_store_base = pEncExtParaIn->recon.colBufferH264Recon;



  //cu info output
  regs->cuInfoTableBase = pEncExtParaIn->recon.cuInfoMemRecon;
  regs->cuInfoDataBase = pEncExtParaIn->recon.cuInfoMemRecon +  asic->cuInfoTableSize;


  if(h264Codec)
  {
    //regs->frameNum = pEncExtParaIn->params.h264Para.frame_num;
    if(regs->frameCodingType == 1)//I
    {
      if(pEncExtParaIn->params.h264Para.idr_pic_flag)
      {
        asic->regs.nal_unit_type = H264_IDR;
      }
      else
        asic->regs.nal_unit_type = H264_NONIDR;
    }


    regs->idrPicId = pEncExtParaIn->params.h264Para.idr_pic_id&1;//(pEncExtParaIn->params.h264Para.idr_pic_flag)? (pEncExtParaIn->params.h264Para.idr_pic_id):0;

     regs->nalRefIdc_2bit = regs->nalRefIdc = pEncExtParaIn->params.h264Para.reference_pic_flag;
    //  regs->transform8x8Enable
    //  regs->entropy_coding_mode_flag
    regs->colctbs_load_base = 0;
    if (pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_I ||
        pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_SI)
    {
        if((pEncExtParaIn->params.h264Para.idr_pic_flag))
        {
            //not need curLongTermIdx
            regs->currentLongTermIdx = 0;
            regs->markCurrentLongTerm = !!(pEncExtParaIn->recon.flags&LONG_TERM_REFERENCE);
        }
        else
        {
            //curLongTermIdx
            regs->markCurrentLongTerm = !!(pEncExtParaIn->recon.flags&LONG_TERM_REFERENCE);
            regs->currentLongTermIdx = pEncExtParaIn->recon.frame_idx;
        }
    }



    regs->l0_delta_framenum[0] = 0;
    regs->l0_delta_framenum[1] = 0;
    regs->l1_delta_framenum[0] = 0;
    regs->l1_delta_framenum[1] = 0;

    regs->l0_used_by_curr_pic[0] = 0;
    regs->l0_used_by_curr_pic[1] = 0;
    regs->l1_used_by_curr_pic[0] = 0;
    regs->l1_used_by_curr_pic[1] = 0;
    regs->l0_long_term_flag[0] = 0;
    regs->l0_long_term_flag[1] = 0;
    regs->l1_long_term_flag[0] = 0;
    regs->l1_long_term_flag[1] = 0;
    regs->num_long_term_pics = 0;

    if((pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_P)||(pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_B))
    {
      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l0_active_minus1+1); i ++)
      {
        regs->l0_delta_framenum[i] = regs->frameNum - pEncExtParaIn->reflist0[i].frame_num;
        regs->l0_referenceLongTermIdx[i] = pEncExtParaIn->reflist0[i].frame_idx;
      }
      //regs->l0_referenceLongTermIdx[i] = (pic->rpl[0][i]->long_term_flag ? pic->rpl[0][i]->curLongTermIdx : 0);
      //libva not support mmco so
      if(pEncExtParaIn->recon.flags&LONG_TERM_REFERENCE)
      {
        //curLongTermIdx
        regs->markCurrentLongTerm = 1;
      }
      else
      {
        regs->markCurrentLongTerm = 0;
      }

      regs->currentLongTermIdx = pEncExtParaIn->recon.frame_idx;

      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l0_active_minus1+1); i ++)
        regs->l0_used_by_curr_pic[i] = 1;

      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l0_active_minus1+1); i++)
      {
        regs->pRefPic_recon_l0[0][i] = pEncExtParaIn->reflist0[i].busReconLuma;
        regs->pRefPic_recon_l0[1][i] = pEncExtParaIn->reflist0[i].busReconChromaUV;
        regs->pRefPic_recon_l0_4n[i] =  pEncExtParaIn->reflist0[i].reconLuma_4n;

        regs->l0_delta_poc[i] = pEncExtParaIn->reflist0[i].poc - pEncExtParaIn->recon.poc;
        regs->l0_long_term_flag[i] = !!(pEncExtParaIn->reflist0[i].flags&LONG_TERM_REFERENCE);
        regs->num_long_term_pics += regs->l0_long_term_flag[i];

        //compress
        regs->ref_l0_luma_compressed[i] = regs->recon_luma_compress;
        regs->ref_l0_luma_compress_tbl_base[i] = pEncExtParaIn->reflist0[i].compressTblReconLuma;

        regs->ref_l0_chroma_compressed[i] = regs->recon_chroma_compress;
        regs->ref_l0_chroma_compress_tbl_base[i] = pEncExtParaIn->reflist0[i].compressTblReconChroma;
      }

    }

    if (pEncExtParaIn->params.h264Para.slice_type == SLICE_TYPE_B)
    {
      regs->colctbs_load_base = pEncExtParaIn->reflist1[0].colBufferH264Recon;


      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l1_active_minus1+1); i ++)
      {
        regs->l1_delta_framenum[i] = regs->frameNum - pEncExtParaIn->reflist1[i].frame_num;
        regs->l1_referenceLongTermIdx[i] = pEncExtParaIn->reflist1[i].frame_idx;
      }
      //libva not support mmco so
      if(pEncExtParaIn->recon.flags&LONG_TERM_REFERENCE)
      {
        //curLongTermIdx
        regs->markCurrentLongTerm = 1;
      }
      else
        regs->markCurrentLongTerm = 0;

      regs->currentLongTermIdx = pEncExtParaIn->recon.frame_idx;

      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l1_active_minus1+1); i++)
        regs->l1_used_by_curr_pic[i] = 1;

      for (i = 0; i < (pEncExtParaIn->params.h264Para.num_ref_idx_l1_active_minus1+1); i++)
      {
        regs->pRefPic_recon_l1[0][i] = pEncExtParaIn->reflist1[i].busReconLuma;
        regs->pRefPic_recon_l1[1][i] = pEncExtParaIn->reflist1[i].busReconChromaUV;
        regs->pRefPic_recon_l1_4n[i] =  pEncExtParaIn->reflist1[i].reconLuma_4n;

        regs->l1_delta_poc[i] = pEncExtParaIn->reflist1[i].poc - pEncExtParaIn->recon.poc;
        regs->l1_long_term_flag[i] = !!(pEncExtParaIn->reflist1[i].flags&LONG_TERM_REFERENCE);
        regs->num_long_term_pics += regs->l1_long_term_flag[i];

        //compress
        regs->ref_l1_luma_compressed[i] = regs->recon_luma_compress;
        regs->ref_l1_luma_compress_tbl_base[i] = pEncExtParaIn->reflist1[i].compressTblReconLuma;

        regs->ref_l1_chroma_compressed[i] = regs->recon_chroma_compress;
        regs->ref_l1_chroma_compress_tbl_base[i] = pEncExtParaIn->reflist1[i].compressTblReconChroma;
      }
    }

    /* H.264 MMO  libva not support this feature*/
    regs->l0_used_by_next_pic[0] = 1;
    regs->l0_used_by_next_pic[1] = 1;
    regs->l1_used_by_next_pic[0] = 1;
    regs->l1_used_by_next_pic[1] = 1;

    if(IS_H264(vcenc_instance->codecFormat) && pEncExtParaIn->params.h264Para.reference_pic_flag && vcenc_instance->h264_mmo_nops > 0)
    {
        int cnt[2] = {pEncExtParaIn->params.h264Para.num_ref_idx_l0_active_minus1+1, pEncExtParaIn->params.h264Para.num_ref_idx_l1_active_minus1+1};
        for(i = 0; i < vcenc_instance->h264_mmo_nops; i++)
          Jenc_h264_mmo_mark_unref_ext(&asic->regs, vcenc_instance->h264_mmo_unref_ext[i], vcenc_instance->h264_mmo_long_term_flag[i], vcenc_instance->h264_mmo_ltIdx[i], cnt, pEncExtParaIn);
        vcenc_instance->h264_mmo_nops = 0;
    }
  }
  else
  {
    //hevc
    //regs->frameNum = pEncExtParaIn->params.hevcPara.frame_num;
    if(regs->frameCodingType == 1)//I
    {
      if(pEncExtParaIn->params.hevcPara.idr_pic_flag)
      {
        asic->regs.nal_unit_type = IDR_W_RADL;
      }
      else
        asic->regs.nal_unit_type = TRAIL_R;
    }

    //can del this row, this register is only used for h264
    regs->idrPicId = pEncExtParaIn->params.hevcPara.idr_pic_id&1;//s(regs->frameCodingType == 1)? (pEncExtParaIn->params.hevcPara.idr_pic_id & 1):0;

    //can del this row, this register is only used for h264
    regs->nalRefIdc = pEncExtParaIn->params.hevcPara.reference_pic_flag;
    //  regs->transform8x8Enable
    //  regs->entropy_coding_mode_flag
    regs->colctbs_load_base = 0;
    //
    if (pEncExtParaIn->params.hevcPara.slice_type == SLICE_TYPE_I ||
        pEncExtParaIn->params.hevcPara.slice_type == SLICE_TYPE_SI)
    {
        //can del this row, this register is only used for h264
        regs->markCurrentLongTerm = !!(pEncExtParaIn->recon.flags&LONG_TERM_REFERENCE);
    }



    //not used for hevc
    regs->l0_delta_framenum[0] = 0;
    regs->l0_delta_framenum[1] = 0;
    regs->l1_delta_framenum[0] = 0;
    regs->l1_delta_framenum[1] = 0;

    regs->l0_used_by_curr_pic[0] = 0;
    regs->l0_used_by_curr_pic[1] = 0;
    regs->l1_used_by_curr_pic[0] = 0;
    regs->l1_used_by_curr_pic[1] = 0;
    regs->l0_long_term_flag[0] = 0;
    regs->l0_long_term_flag[1] = 0;
    regs->l1_long_term_flag[0] = 0;
    regs->l1_long_term_flag[1] = 0;
    regs->num_long_term_pics = 0;

    if((pEncExtParaIn->params.hevcPara.slice_type == SLICE_TYPE_P)||(pEncExtParaIn->params.hevcPara.slice_type == SLICE_TYPE_B))
    {
      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l0_active_minus1+1); i ++)
      {
        regs->l0_delta_framenum[i] = regs->frameNum - pEncExtParaIn->reflist0[i].frame_num;
        regs->l0_referenceLongTermIdx[i] = pEncExtParaIn->reflist0[i].frame_idx;
      }
      //libva not support mmco so
      regs->markCurrentLongTerm = 0;

      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l0_active_minus1+1); i ++)
        regs->l0_used_by_curr_pic[i] = 1;

      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l0_active_minus1+1); i++)
      {
        regs->pRefPic_recon_l0[0][i] = pEncExtParaIn->reflist0[i].busReconLuma;
        regs->pRefPic_recon_l0[1][i] = pEncExtParaIn->reflist0[i].busReconChromaUV;
        regs->pRefPic_recon_l0_4n[i] =  pEncExtParaIn->reflist0[i].reconLuma_4n;

        regs->l0_delta_poc[i] = pEncExtParaIn->reflist0[i].poc - pEncExtParaIn->recon.poc;
        regs->l0_long_term_flag[i] = !!(pEncExtParaIn->reflist0[i].flags&LONG_TERM_REFERENCE);
        regs->num_long_term_pics += regs->l0_long_term_flag[i];

        //compress
        regs->ref_l0_luma_compressed[i] = regs->recon_luma_compress;
        regs->ref_l0_luma_compress_tbl_base[i] = pEncExtParaIn->reflist0[i].compressTblReconLuma;

        regs->ref_l0_chroma_compressed[i] = regs->recon_chroma_compress;
        regs->ref_l0_chroma_compress_tbl_base[i] = pEncExtParaIn->reflist0[i].compressTblReconChroma;
      }

    }

    if (pEncExtParaIn->params.hevcPara.slice_type == SLICE_TYPE_B)
    {
      regs->colctbs_load_base = pEncExtParaIn->reflist1[0].colBufferH264Recon;


      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l1_active_minus1+1); i ++)
      {
        regs->l1_delta_framenum[i] = regs->frameNum - pEncExtParaIn->reflist1[i].frame_num;
        regs->l1_referenceLongTermIdx[i] = pEncExtParaIn->reflist1[i].frame_idx;
      }
      //libva not support mmco so
      regs->markCurrentLongTerm = 0;

      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l1_active_minus1+1); i++)
        regs->l1_used_by_curr_pic[i] = 1;

      for (i = 0; i < (pEncExtParaIn->params.hevcPara.num_ref_idx_l1_active_minus1+1); i++)
      {
        regs->pRefPic_recon_l1[0][i] = pEncExtParaIn->reflist1[i].busReconLuma;
        regs->pRefPic_recon_l1[1][i] = pEncExtParaIn->reflist1[i].busReconChromaUV;
        regs->pRefPic_recon_l1_4n[i] =  pEncExtParaIn->reflist1[i].reconLuma_4n;

        regs->l1_delta_poc[i] = pEncExtParaIn->reflist1[i].poc - pEncExtParaIn->recon.poc;
        regs->l1_long_term_flag[i] = !!(pEncExtParaIn->reflist1[i].flags&LONG_TERM_REFERENCE);
        regs->num_long_term_pics += regs->l1_long_term_flag[i];

        //compress
        regs->ref_l1_luma_compressed[i] = regs->recon_luma_compress;
        regs->ref_l1_luma_compress_tbl_base[i] = pEncExtParaIn->reflist1[i].compressTblReconLuma;

        regs->ref_l1_chroma_compressed[i] = regs->recon_chroma_compress;
        regs->ref_l1_chroma_compress_tbl_base[i] = pEncExtParaIn->reflist1[i].compressTblReconChroma;
      }
    }
#if 0
    //used for long term ref?
    {
      for (i = (pEncExtParaIn->params.hevcPara.num_ref_idx_l0_active_minus1+1), j = 0; i < 2 && j < r->lt_follow_cnt; i++, j++) {
        asic->regs.l0_delta_poc[i] = r->lt_follow[j] - pic->poc;
        regs->l0_delta_poc[i] = pEncExtParaIn->reflist0[i].poc - pEncExtParaIn->recon.poc;
        asic->regs.l0_long_term_flag[i] = 1;
      }
      for (i = (pEncExtParaIn->params.hevcPara.num_ref_idx_l1_active_minus1+1); i < 2 && j < r->lt_follow_cnt; i++, j++) {
        asic->regs.l1_delta_poc[i] = r->lt_follow[j] - pic->poc;
        asic->regs.l1_long_term_flag[i] = 1;
      }
    }
#endif
    /* H.264 MMO  libva not support this feature*/
    regs->l0_used_by_next_pic[0] = 1;
    regs->l0_used_by_next_pic[1] = 1;
    regs->l1_used_by_next_pic[0] = 1;
    regs->l1_used_by_next_pic[1] = 1;

    if(regs->num_long_term_pics)
        regs->long_term_ref_pics_present_flag = 1;



    regs->rps_neg_pic_num = pEncExtParaIn->params.hevcPara.rps_neg_pic_num;
	regs->rps_pos_pic_num = pEncExtParaIn->params.hevcPara.rps_pos_pic_num;
	ASSERT(regs->rps_neg_pic_num + regs->rps_pos_pic_num <= VCENC_MAX_REF_FRAMES);
	for ( i = 0; i < (i32)(regs->rps_neg_pic_num+regs->rps_pos_pic_num); i++)
	{
		regs->rps_delta_poc[i] = pEncExtParaIn->params.hevcPara.rps_delta_poc[i];
		regs->rps_used_by_cur[i] = pEncExtParaIn->params.hevcPara.rps_used_by_cur[i];
	}
	for (i=regs->rps_neg_pic_num+regs->rps_pos_pic_num; i < VCENC_MAX_REF_FRAMES; i++)
	{
		regs->rps_delta_poc[i] = 0;
		regs->rps_used_by_cur[i] = 0;
	}
  }
}


/*------------------------------------------------------------------------------
    Function name : LambdaTuningSubjective
    Description   : Tuning lambda for subjective quality
    Argument      : asic - asicData_s structure holding asic settings
                  : pEncIn - user provided input parameters
------------------------------------------------------------------------------*/
static void LambdaTuningSubjective(asicData_s *asic, struct sw_picture *pic, const VCEncIn *pEncIn)
{
  i32 gopDepth = 0;
  i32 gopSize = pEncIn->gopSize;
  if (pic->sliceInst->type != I_SLICE)
  {
    i32 gopPoc = pEncIn->gopCurrPicConfig.poc;
    while (gopPoc % gopSize)
    {
      gopDepth ++;

      i32 mid = gopSize >> 1;
      if (gopPoc > mid)
      {
        gopPoc -= mid;
        gopSize -= mid;
      }
      else
        gopSize = mid;
    }
  }

  double factorSad = 1.0;
  double factorSse = 0.9;
  double factorDepth = 1.0;
  if (gopDepth)
  {
    const double factors[4] = {1.0, 1.15, 1.2, 1.2};
    factorDepth = factors[MIN(3, gopDepth)];
  }
  factorSad *= factorDepth;
  factorSse *= factorDepth * factorDepth;

  asic->regs.qpFactorSad = (u32)((factorSad * (1<<QPFACTOR_FIX_POINT)) + 0.5);
  asic->regs.qpFactorSse = (u32)((factorSse * (1<<QPFACTOR_FIX_POINT)) + 0.5);
  asic->regs.qpFactorSad = MIN(asic->regs.qpFactorSad, 0x7FFF);
  asic->regs.qpFactorSse = MIN(asic->regs.qpFactorSse, 0x7FFF);
  asic->regs.lambdaDepth = 0;
}
/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncStrmEncode
    Description   : Encodes a new picture
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/


VCEncRet Jenc_VCEncStrmEncode(VCEncInst inst, VCEncIn *pEncIn,
                             VCEncOut *pEncOut,
                             VCEncSliceReadyCallBackFunc sliceReadyCbFunc,
                             void *pAppData)
{
  VCEncRet ret = Jenc_VCEncStrmEncodeExt(inst,pEncIn,NULL,pEncOut,sliceReadyCbFunc,pAppData,0);
  return ret;
}
/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncStrmEncode
    Description   : Encodes a new picture
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/


VCEncRet Jenc_VCEncStrmEncodeExt(VCEncInst inst, VCEncIn *pEncIn,
                                const VCEncExtParaIn *pEncExtParaIn,
                               VCEncOut *pEncOut,
                               VCEncSliceReadyCallBackFunc sliceReadyCbFunc,
                               void *pAppData,i32 useExtFlag)

{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  /* Check for illegal inputs. */
  if ((vcenc_instance == NULL) || (pEncIn == NULL) || (pEncOut == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  asicData_s *asic = &vcenc_instance->asic;
  VCEncGopPicConfig sSliceRpsCfg;
  struct container *c;
  struct vcenc_buffer source;
  struct Jenc_vps *v;
  struct Jenc_sps *s;
  struct Jenc_pps *p;
  struct rps *r;
  struct sw_picture *pic;
  struct slice *slice;
  i32 bSkipFrame = 0;
  i32 tmp, i, j;
  i32 ret = VCENC_ERROR;
  VCEncSliceReady slice_callback;
  VCEncPictureCodingType codingType;
  u32 client_type;
  i32 core_id = -1;
  const void *ewl = NULL;
  u8 rpsInSliceHeader = vcenc_instance->RpsInSliceHeader;
  VCDec400data dec400_data;
  u32 waitCoreJobid = 0;
  u32 byteCntSw = 0;
  u32* segcounts = NULL;

  Jenc_StrmEncodeTraceEncInPara(pEncIn, vcenc_instance);
/*for fbdc*/
#ifdef FBDC_ENABLE
	  fbdc_info_s *val = &asic->fbdc_info;

	  val->yaddr = pEncIn->busLuma;
	  val->uvaddr = pEncIn->busChromaU;
	  val->width = vcenc_instance->width;
	  val->crop_x = pEncIn->CropX;
	  val->crop_y = pEncIn->CropY;
	  EncConfigFbdcInfo(asic->ewl, val);
#endif

  VCEncLookaheadJob *outframe = NULL;
  if(vcenc_instance->pass==2) {

    if(pEncExtParaIn != NULL){
      VCEncExtParaIn *pExtParaInBuf = (VCEncExtParaIn*)malloc(sizeof(VCEncExtParaIn));
      memcpy(pExtParaInBuf, pEncExtParaIn, sizeof(VCEncExtParaIn));
      Jenc_queue_put(&vcenc_instance->extraParaQ, (struct node *)pExtParaInBuf);
    }

    if(pEncIn != NULL)
    {
      if(Jenc_AddPictureToLookahead(&vcenc_instance->lookahead, pEncIn, pEncOut) != VCENC_OK)
        return VCENC_ERROR;
    }
    outframe = Jenc_GetLookaheadOutput(&vcenc_instance->lookahead, pEncIn==NULL);

    if (outframe == NULL)
      return VCENC_OK;
    if (outframe->status != VCENC_FRAME_READY) {
      VCEncRet status = outframe->status;
      if (status == VCENC_ERROR)
        ReleaseLookaheadPicture(&vcenc_instance->lookahead, outframe);
      else
        free(outframe);
      return status;
    }
    pEncIn = &outframe->encIn;
    if(pEncIn->roiMapDeltaQpAddr == 0)
    {
      // disable pass2 ROI map
      vcenc_instance->roiMapDeltaQpEnable = 0;
      asic->regs.rcRoiEnable &= ~2;
    }
    else
    {
      // enable pass2 ROI map
      vcenc_instance->roiMapDeltaQpEnable = 1;
      asic->regs.rcRoiEnable |= 2;
    }
    //pEncOut = &outframe->encOut;
    i32 nextGopSize = outframe->frame.gopSize;
    if(outframe->frame.frameNum != 0)
      outframe->encIn.gopSize = vcenc_instance->lookahead.lastGopSize;
    outframe->encIn.picture_cnt = vcenc_instance->lookahead.picture_cnt;
    outframe->encIn.last_idr_picture_cnt = vcenc_instance->lookahead.last_idr_picture_cnt;
    outframe->encIn.codingType = (outframe->frame.frameNum == 0) ? VCENC_INTRA_FRAME : Jenc_VCEncFindNextPic(inst, &outframe->encIn, nextGopSize, pEncIn->gopConfig.gopCfgOffset, false);
    vcenc_instance->lookahead.picture_cnt = outframe->encIn.picture_cnt;
    vcenc_instance->lookahead.last_idr_picture_cnt = outframe->encIn.last_idr_picture_cnt;
    if(vcenc_instance->extDSRatio) {
      /* switch to full resolution yuv for 2nd pass */
      outframe->encIn.busLuma = outframe->encIn.busLumaOrig;
      outframe->encIn.busChromaU = outframe->encIn.busChromaUOrig;
      outframe->encIn.busChromaV = outframe->encIn.busChromaVOrig;
    }
    vcenc_instance->cuTreeCtl.costCur = outframe->frame.cost;
    vcenc_instance->cuTreeCtl.curTypeChar = outframe->frame.typeChar;
    vcenc_instance->lookahead.lastGopPicIdx = outframe->encIn.gopPicIdx;
    vcenc_instance->lookahead.lastGopSize = outframe->encIn.gopSize;
    for (i = 0; i < 4; i ++)
    {
      vcenc_instance->cuTreeCtl.costAvg[i] = outframe->frame.costAvg[i];
      vcenc_instance->cuTreeCtl.FrameTypeNum[i] = outframe->frame.FrameTypeNum[i];
      vcenc_instance->cuTreeCtl.costGop[i] = outframe->frame.costGop[i];
      vcenc_instance->cuTreeCtl.FrameNumGop[i] = outframe->frame.FrameNumGop[i];
    }

    /* VP9 Segmentation counts */
    segcounts = outframe->frame.segmentCountAddr;
  }
  pEncOut->picture_cnt = pEncIn->picture_cnt;

  /* ErrorChecker */
  client_type = VCEncGetClientType(vcenc_instance->codecFormat);
  if ((ret = Jenc_StrmEncodeCheckPara(vcenc_instance, pEncIn, pEncOut, asic, client_type)) != VCENC_OK)
  {
    return ret;
  }

  if (pEncIn->bSkipFrame)
  {
    if ((vcenc_instance->asic.regs.asicCfg.roiMapVersion >= 2) &&
        (IS_H264(vcenc_instance->codecFormat) || IS_HEVC(vcenc_instance->codecFormat)))
        bSkipFrame = pEncIn->bSkipFrame;
    else if (asic->regs.asicHwId >= 0x80006010 && asic->regs.asicHwId < 0x80006200)
      bSkipFrame = pEncIn->bSkipFrame;
    else
    {
      APITRACEERR("Jenc_VCEncStrmEncode: WARNING. FRAME_SKIP not supported by HW, force to disable it");
    }
  }

#ifdef INTERNAL_TEST
  /* Configure the encoder instance according to the test vector */
  Jenc_HevcConfigureTestBeforeFrame(vcenc_instance);
#endif

  JENC_EWLHwConfig_t cfg = JencEncAsicGetAsicConfig(client_type,vcenc_instance->ctx);

  if (client_type == JENC_EWL_CLIENT_TYPE_H264_ENC && cfg.h264Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_HEVC_ENC && cfg.hevcEnabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_AV1_ENC && cfg.av1Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if (client_type == JENC_EWL_CLIENT_TYPE_VP9_ENC && cfg.vp9Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
    return VCENC_INVALID_ARGUMENT;

  if ((cfg.bFrameEnabled == EWL_HW_CONFIG_NOT_SUPPORTED) && ((pEncIn->codingType) == VCENC_BIDIR_PREDICTED_FRAME))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: Invalid coding format, B frame not supported by core");
    return VCENC_INVALID_ARGUMENT;
  }

  if ((cfg.IframeOnly == EWL_HW_CONFIG_ENABLED) && ((pEncIn->codingType) != VCENC_INTRA_FRAME))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: Invalid coding format, only I frame supported by core");
    return VCENC_INVALID_ARGUMENT;
  }

  if (pEncIn->codingType == VCENC_BIDIR_PREDICTED_FRAME)
    vcenc_instance->featureToSupport.bFrameEnabled = 1;

  if (client_type == JENC_EWL_CLIENT_TYPE_H264_ENC)
  {
    vcenc_instance->featureToSupport.h264Enabled = 1;
    vcenc_instance->featureToSupport.hevcEnabled = 0;
    vcenc_instance->featureToSupport.av1Enabled = 0;
    vcenc_instance->featureToSupport.vp9Enabled = 0;
   }
   else if (client_type == JENC_EWL_CLIENT_TYPE_AV1_ENC)
   {
     vcenc_instance->featureToSupport.h264Enabled = 0;
     vcenc_instance->featureToSupport.hevcEnabled = 0;
     vcenc_instance->featureToSupport.av1Enabled = 1;
     vcenc_instance->featureToSupport.vp9Enabled = 0;
   }
   else if (client_type == JENC_EWL_CLIENT_TYPE_VP9_ENC)
   {
     vcenc_instance->featureToSupport.h264Enabled = 0;
     vcenc_instance->featureToSupport.hevcEnabled = 0;
     vcenc_instance->featureToSupport.av1Enabled = 0;
     vcenc_instance->featureToSupport.vp9Enabled = 1;
   }
   else
   {
     vcenc_instance->featureToSupport.h264Enabled = 0;
     vcenc_instance->featureToSupport.hevcEnabled = 1;
     vcenc_instance->featureToSupport.av1Enabled = 0;
     vcenc_instance->featureToSupport.vp9Enabled = 0;
   }
  memset(&sSliceRpsCfg, 0,sizeof(VCEncGopPicConfig));

  asic->regs.roiMapDeltaQpAddr = pEncIn->roiMapDeltaQpAddr;
  asic->regs.RoimapCuCtrlAddr  = pEncIn->RoimapCuCtrlAddr;
  asic->regs.RoimapCuCtrlIndexAddr = pEncIn->RoimapCuCtrlIndexAddr;
  asic->regs.RoimapCuCtrl_enable           = vcenc_instance->RoimapCuCtrl_enable;
  asic->regs.RoimapCuCtrl_index_enable     = vcenc_instance->RoimapCuCtrl_index_enable;
  asic->regs.RoimapCuCtrl_ver              = vcenc_instance->RoimapCuCtrl_ver;
  asic->regs.RoiQpDelta_ver                = vcenc_instance->RoiQpDelta_ver;

  asic->regs.sram_base_lum_fwd = pEncIn->extSRAMLumFwdBase;
  asic->regs.sram_base_lum_bwd = pEncIn->extSRAMLumBwdBase;
  asic->regs.sram_base_chr_fwd = pEncIn->extSRAMChrFwdBase;
  asic->regs.sram_base_chr_bwd = pEncIn->extSRAMChrBwdBase;

  if(vcenc_instance->pass == 1) {
    vcenc_instance->stream.stream = (u8*)vcenc_instance->lookahead.internal_mem.pOutBuf;
    vcenc_instance->stream.stream_bus = vcenc_instance->lookahead.internal_mem.busOutBuf;
    vcenc_instance->stream.size = vcenc_instance->lookahead.internal_mem.outBufSize;
  } else {
    vcenc_instance->stream.stream = (u8 *)pEncIn->pOutBuf[0];
    vcenc_instance->stream.stream_bus = pEncIn->busOutBuf[0];
    vcenc_instance->stream.size = pEncIn->outBufSize[0];
  }
  vcenc_instance->stream.av1pre_size = pEncIn->Av1PreBufferSize;
	vcenc_instance->stream.stream_av1pre_bus = pEncIn->busAv1PrecarryOutBuf;
  vcenc_instance->stream.cnt = &vcenc_instance->stream.byteCnt;

  pEncOut->pNaluSizeBuf = (u32 *)vcenc_instance->asic.sizeTbl[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].virtualAddress;

  pEncOut->streamSize = 0;
  pEncOut->numNalus = 0;
  pEncOut->maxSliceStreamSize = 0;
  pEncOut->codingType = VCENC_NOTCODED_FRAME;

  vcenc_instance->sliceReadyCbFunc = sliceReadyCbFunc;
  vcenc_instance->pAppData[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = pAppData;
  i32 coreIdx = vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum;
  for (i = 0; i < MAX_STRM_BUF_NUM; i ++)
  {
    vcenc_instance->streamBufs[coreIdx].buf[i] = (u8 *)pEncIn->pOutBuf[i];
    vcenc_instance->streamBufs[coreIdx].bufLen[i] = pEncIn->outBufSize[i];
  }

  /* low latency */
  vcenc_instance->inputLineBuf.wrCnt = pEncIn->lineBufWrCnt;
  vcenc_instance->inputLineBuf.initSegNum = pEncIn->initSegNum;

  /* Clear the NAL unit size table */
  if (pEncOut->pNaluSizeBuf != NULL)
    pEncOut->pNaluSizeBuf[0] = 0;

  vcenc_instance->stream.byteCnt = 0;
  pEncOut->sliceHeaderSize = 0;

  asic->regs.outputStrmBase[0] = (ptr_t)vcenc_instance->stream.stream_bus;
  asic->regs.outputStrmSize[0] = vcenc_instance->stream.size;
  asic->regs.Av1PreoutputStrmBase = (ptr_t)vcenc_instance->stream.stream_av1pre_bus;
  asic->regs.Av1PreBufferSize     = vcenc_instance->stream.av1pre_size;;
  if (asic->regs.asicCfg.streamBufferChain)
  {
    asic->regs.outputStrmBase[1] = pEncIn->busOutBuf[1];
    asic->regs.outputStrmSize[1] = pEncIn->outBufSize[1];
  }

  if (!(c = Jenc_get_container(vcenc_instance))) return VCENC_ERROR;
  if ((IS_HEVC(vcenc_instance->codecFormat) || IS_H264(vcenc_instance->codecFormat))){
    VCEncParameterSetHandle(vcenc_instance, inst, pEncIn, pEncOut, c);
  }


  vcenc_instance->poc = pEncIn->poc;

  pEncOut->busScaledLuma = vcenc_instance->asic.scaledImage.busAddress;
  pEncOut->scaledPicture = (u8 *)vcenc_instance->asic.scaledImage.virtualAddress;
  /* Get parameter sets */
  v = (struct Jenc_vps *)Jenc_get_parameter_set(c, VPS_NUT, 0);
  s = (struct Jenc_sps *)Jenc_get_parameter_set(c, SPS_NUT, vcenc_instance->sps_id);
  p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, vcenc_instance->pps_id);

  bool use_ltr_cur; // = pEncOut->boolCurIsLongTermRef = (pEncIn->u8IdxEncodedAsLTR != 0);
  if (!v || !s || !p ) return VCENC_ERROR;

  u32 ltr_used_by_cur[VCENC_MAX_LT_REF_FRAMES];

  if (pEncIn->flexRefsEnable) {
    rpsInSliceHeader = 1;
    codingType = pEncIn->codingType;
    vcenc_instance->rps_id = s->num_short_term_ref_pic_sets;
    Jenc_vcenc_replace_rps(vcenc_instance, (VCEncGopPicConfig*)&(pEncIn->gopCurrPicConfig), 0);
    r = (struct rps *)Jenc_get_parameter_set(c, RPS, vcenc_instance->rps_id);
    if (!r)
      return VCENC_ERROR;

    use_ltr_cur = (pEncOut->boolCurIsLongTermRef = (r->num_lt_pics != 0));
    if (use_ltr_cur) {
      for (i = 0; i < r->num_lt_pics; i++)
      {
        r->long_term_ref_pic_poc[i] = r->ref_pic_lt[i].delta_poc;
        r->ref_pic_lt[i].delta_poc = i;
        ltr_used_by_cur[i] = r->ref_pic_lt[i].used_by_curr_pic;
      }
      for (i = r->num_lt_pics; i < VCENC_MAX_LT_REF_FRAMES; i++)
      {
        r->long_term_ref_pic_poc[i] = -1;
        ltr_used_by_cur[i] = -1;
      }
    }
  } else {
    use_ltr_cur = (pEncOut->boolCurIsLongTermRef = (pEncIn->u8IdxEncodedAsLTR != 0));
    codingType = get_rps_id(vcenc_instance, pEncIn, s, &rpsInSliceHeader);
    r = (struct rps *)Jenc_get_parameter_set(c, RPS,     vcenc_instance->rps_id);
    if (!r)
      return VCENC_ERROR;

    /* Initialize before/after/follow poc list */
    if ((codingType == VCENC_INTRA_FRAME)&&(vcenc_instance->poc == 0)) /* IDR */
        j = 0;
    else
    {
      for (i = 0, j = 0; i < VCENC_MAX_LT_REF_FRAMES; i++)
      {
          if (pEncIn->long_term_ref_pic[i] != INVALITED_POC)
              r->long_term_ref_pic_poc[j++] = pEncIn->long_term_ref_pic[i];
      }
    }
    for (i = j; i < VCENC_MAX_LT_REF_FRAMES; i++)
        r->long_term_ref_pic_poc[i] = -1;

    for (i = 0; i < VCENC_MAX_LT_REF_FRAMES; i++) {
      ltr_used_by_cur[i] = pEncIn->bLTR_used_by_cur[i];
    }
  }

  if (!r) return VCENC_ERROR;

  Jenc_init_poc_list(r, vcenc_instance->poc, use_ltr_cur, codingType, c,
                 IS_H264(vcenc_instance->codecFormat), ltr_used_by_cur);
  /* 6.0 not support */
  if (vcenc_instance->asic.regs.asicHwId < 0x80006010)
    r->lt_follow_cnt = 0;

  if(r->before_cnt + r->after_cnt + r->lt_current_cnt == 1)
    codingType = VCENC_PREDICTED_FRAME;

  /* mark unused picture, so that you can reuse those. TODO: IDR flush */
  if (Jenc_GenralRefPicMarking(vcenc_instance, c, r))
  {
    Jenc_Error(2, ERR, "RPS error: reference picture(s) not available");
    return VCENC_ERROR;
  }

  /* Get free picture (if any) and remove it from picture store */
  if (!(pic = Jenc_get_picture(c, -1)))
  {
    if (!(pic = Jenc_create_picture_ctrlsw(vcenc_instance, v, s, p, asic->regs.sliceSize, vcenc_instance->preProcess.lumWidthSrc, vcenc_instance->preProcess.lumHeightSrc))) return VCENC_ERROR;
  }
  Jenc_create_slices_ctrlswe(pic, p, asic->regs.sliceSize);
  Jenc_queue_remove(&c->picture, (struct node *)pic);

  pic->encOrderInGop = pEncIn->gopPicIdx;
  pic->h264_no_ref = HANTRO_FALSE;
  if(pic->Jenc_pps != p)
    pic->Jenc_pps = p;

  /* store input addr */
  pic->input.lum = pEncIn->busLuma;
  pic->input.cb = pEncIn->busChromaU;
  pic->input.cr = pEncIn->busChromaV;

  if (pic->picture_memeory_init == 0)
  {
    pic->recon.lum = asic->internalreconLuma[pic->picture_memeory_id].busAddress;
    pic->recon.cb = asic->internalreconChroma[pic->picture_memeory_id].busAddress;
    pic->recon.cr = pic->recon.cb + asic->regs.recon_chroma_half_size;
    pic->recon_4n_base = asic->internalreconLuma_4n[pic->picture_memeory_id].busAddress;
    pic->framectx_base = asic->internalAv1FrameContext[pic->picture_memeory_id].busAddress;
    pic->framectx_virtual_addr = (ptr_t)asic->internalAv1FrameContext[pic->picture_memeory_id].virtualAddress;
    pic->mc_sync_addr = asic->internalreconLuma[pic->picture_memeory_id].busAddress + asic->internalreconLuma[pic->picture_memeory_id].size - 64*2;
    pic->mc_sync_ptr = (ptr_t)asic->internalreconLuma[pic->picture_memeory_id].virtualAddress + asic->internalreconLuma[pic->picture_memeory_id].size - 64*2;

    if(useExtFlag && vcenc_instance->parallelCoreNum > 1)
    {
        //pic->mc_sync_addr = pEncExtParaIn->recon.busReconLuma + pic->Jenc_sps->width * pic->Jenc_sps->height * 3 / 2 *(pic->Jenc_sps->bit_depth_luma_minus8 + 8) / 8;
        pic->mc_sync_addr = pEncExtParaIn->recon.mcSyncAddr + pic->picture_memeory_id * 16;
        pic->mc_sync_ptr = pic->mc_sync_addr;
    }
    /* for compress */
    {
      u32 lumaTblSize = asic->regs.recon_luma_compress ?
                        (((pic->Jenc_sps->width + 63) / 64) * ((pic->Jenc_sps->height + 63) / 64) * 8) : 0;
      lumaTblSize = ((lumaTblSize + 15) >> 4) << 4;
      pic->recon_compress.lumaTblBase = asic->compressTbl[pic->picture_memeory_id].busAddress;
      pic->recon_compress.chromaTblBase = (pic->recon_compress.lumaTblBase + lumaTblSize);
    }

    /* for H.264 collocated mb */
    pic->colctbs_store = (struct h264_mb_col *)asic->colBuffer[pic->picture_memeory_id].virtualAddress;
    pic->colctbs_store_base = asic->colBuffer[pic->picture_memeory_id].busAddress;

    /* To collect MV info for TMVP */
    pic->mvInfoBase = asic->mvInfo[pic->picture_memeory_id].busAddress;
    pic->picture_memeory_init = 1;
  }

  // cuInfo buffer layout:
  //   cuTable (size = asic.cuInfoTableSize)
  //   aqData  (size = asic.aqInfoSize)
  //   cuData

  //cu info output
  pic->cuInfoTableBase = asic->cuInfoMem[vcenc_instance->cuInfoBufIdx].busAddress;
  pic->cuInfoDataBase = pic->cuInfoTableBase + asic->cuInfoTableSize + asic->aqInfoSize;

  if(vcenc_instance->pass == 1)
    Jenc_waitCuInfoBufPass1(vcenc_instance);
  if (asic->regs.enableOutputCuInfo)
  {
    u8 *cuInfoMem = (u8 *)asic->cuInfoMem[vcenc_instance->cuInfoBufIdx].virtualAddress;
    pEncOut->cuOutData.ctuOffset = (u32 *)cuInfoMem;
    pEncOut->cuOutData.cuData = cuInfoMem + asic->cuInfoTableSize + asic->aqInfoSize;
  }
  else
  {
    pEncOut->cuOutData.ctuOffset = NULL;
    pEncOut->cuOutData.cuData = NULL;
  }
  vcenc_instance->cuInfoBufIdx++;
  if(vcenc_instance->cuInfoBufIdx == vcenc_instance->numCuInfoBuf)
    vcenc_instance->cuInfoBufIdx = 0;

  //aq information output
  asic->regs.aqInfoOutputMode = (vcenc_instance->pass == 1 ? vcenc_instance->cuTreeCtl.aq_mode : AQ_NONE);
  if(asic->regs.aqInfoOutputMode != AQ_NONE) {
    u32 aqStrength = (u32)(vcenc_instance->cuTreeCtl.aqStrength * (1 << AQ_STRENGTH_SCALE_BITS)); // to Q2.7
    asic->regs.aqStrength = aqStrength;
    asic->regs.aqInfoOutputBase = pic->cuInfoTableBase + asic->cuInfoTableSize;
    asic->regs.aqInfoOutputStride = asic->aqInfoStride;
  }
  //ctb bits info output; Pass 1 turn off ctb bits output enable
  /* Ctb encoded bits output */
  if(asic->regs.enableOutputCtbBits)
  {
    pic->ctbBitsDataBase = asic->ctbBitsMem[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].busAddress;
    pEncOut->ctbBitsData = (u16 *)asic->ctbBitsMem[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].virtualAddress;
  }
  else
  {
    pic->ctbBitsDataBase = 0;
    pEncOut->ctbBitsData = NULL;
  }

  /* Activate reference paremater sets and reference picture set,
   * TODO: if parameter sets if id differs... */
  pic->rps = r;
  ASSERT(pic->Jenc_vps == v);
  ASSERT(pic->Jenc_sps == s);
  ASSERT(pic->Jenc_pps == p);
  pic->poc     = vcenc_instance->poc;

  /* configure GDR parameters */
  Jenc_StrmEncodeGradualDecoderRefresh(vcenc_instance, asic, pEncIn, &codingType, cfg);

  /* setting TRAIL_N/TRAIL_R based on nonReference setting */
  u32 hevc_nal_unit_type = pEncIn->gopCurrPicConfig.nonReference ? TRAIL_N : TRAIL_R;
  if (codingType == VCENC_INTRA_FRAME)
  {
    asic->regs.frameCodingType = 1;
    asic->regs.nal_unit_type = (IS_H264(vcenc_instance->codecFormat) ? H264_IDR : IDR_W_RADL);
    if (vcenc_instance->poc > 0 && !pEncIn->bIsIDR)
      asic->regs.nal_unit_type = (IS_H264(vcenc_instance->codecFormat) ? H264_NONIDR : TRAIL_R);
    pic->sliceInst->type = I_SLICE;
    pEncOut->codingType = VCENC_INTRA_FRAME;
  }
  else if (codingType == VCENC_PREDICTED_FRAME)
  {
    asic->regs.frameCodingType = 0;
    asic->regs.nal_unit_type = (IS_H264(vcenc_instance->codecFormat) ? H264_NONIDR : hevc_nal_unit_type);
    pic->sliceInst->type = P_SLICE;
    pEncOut->codingType = VCENC_PREDICTED_FRAME;
  }
  else if (codingType == VCENC_BIDIR_PREDICTED_FRAME)
  {
    asic->regs.frameCodingType = 2;
    asic->regs.nal_unit_type = (IS_H264(vcenc_instance->codecFormat) ? H264_NONIDR : hevc_nal_unit_type);
    pic->sliceInst->type = B_SLICE;
    pEncOut->codingType = VCENC_BIDIR_PREDICTED_FRAME;
  }

  asic->regs.hashtype = vcenc_instance->hashctx.hash_type;
  Jenc_hash_getstate(&vcenc_instance->hashctx, &asic->regs.hashval, &asic->regs.hashoffset);

  /* Generate reference picture list of current picture using active
   * reference picture set */
  Jenc_reference_picture_list(c, pic);

  vcenc_instance->sHwRps.u1short_term_ref_pic_set_sps_flag = rpsInSliceHeader ? 0 : 1;
  vcenc_instance->asic.regs.short_term_ref_pic_set_sps_flag = vcenc_instance->sHwRps.u1short_term_ref_pic_set_sps_flag;
  if(rpsInSliceHeader)
  {
    VCEncGenPicRefConfig(c, &sSliceRpsCfg, pic, vcenc_instance->poc);
    VCEncGenSliceHeaderRps(vcenc_instance, codingType, &sSliceRpsCfg);
  }

  pic->colctbs = NULL;
  pic->colctbs_load_base = 0;
  if(IS_H264(vcenc_instance->codecFormat) && codingType == VCENC_BIDIR_PREDICTED_FRAME) {
    pic->colctbs = pic->rpl[1][0]->colctbs_store;
    pic->colctbs_load_base = pic->rpl[1][0]->colctbs_store_base;
  }
  if (pic->sliceInst->type != I_SLICE ||((vcenc_instance->poc > 0)&&(!IS_H264(vcenc_instance->codecFormat))))// check only hevc?
  {
    int ref_cnt = r->before_cnt + r->after_cnt + r->lt_current_cnt;
    int used_cnt = 0;
    //H2V2 limit:
    //List lengh is no more than 2
    //number of active ref is no more than 1
    ASSERT(ref_cnt <= 2);
    ASSERT(pic->sliceInst->active_l0_cnt <= 1);
    ASSERT(pic->sliceInst->active_l1_cnt <= 1);
    ASSERT(ref_cnt + r->lt_follow_cnt <= VCENC_MAX_REF_FRAMES);

    asic->regs.l0_used_by_curr_pic[0] = 0;
    asic->regs.l0_used_by_curr_pic[1] = 0;
    asic->regs.l1_used_by_curr_pic[0] = 0;
    asic->regs.l1_used_by_curr_pic[1] = 0;
    asic->regs.l0_long_term_flag[0] = 0;
    asic->regs.l0_long_term_flag[1] = 0;
    asic->regs.l1_long_term_flag[0] = 0;
    asic->regs.l1_long_term_flag[1] = 0;
    asic->regs.num_long_term_pics = 0;

    /* 6.0 use ref_cnt */
    used_cnt = (vcenc_instance->asic.regs.asicHwId < 0x80006010)?ref_cnt : pic->sliceInst->active_l0_cnt;
    for (i = 0; i < used_cnt; i ++)
      asic->regs.l0_used_by_curr_pic[i] = 1;

    for (i = 0; i < pic->sliceInst->active_l0_cnt; i++)
    {
      asic->regs.pRefPic_recon_l0[0][i] = pic->rpl[0][i]->recon.lum;
      asic->regs.pRefPic_recon_l0[1][i] = pic->rpl[0][i]->recon.cb;
      asic->regs.pRefPic_recon_l0[2][i] = pic->rpl[0][i]->recon.cr;
      asic->regs.pRefPic_recon_l0_4n[i] =  pic->rpl[0][i]->recon_4n_base;

      asic->regs.l0_delta_poc[i] = pic->rpl[0][i]->poc - pic->poc;
      asic->regs.l0_long_term_flag[i] = pic->rpl[0][i]->long_term_flag;
      asic->regs.num_long_term_pics += asic->regs.l0_long_term_flag[i];

      //compress
      asic->regs.ref_l0_luma_compressed[i] = pic->rpl[0][i]->recon_compress.lumaCompressed;
      asic->regs.ref_l0_luma_compress_tbl_base[i] = pic->rpl[0][i]->recon_compress.lumaTblBase;

      asic->regs.ref_l0_chroma_compressed[i] = pic->rpl[0][i]->recon_compress.chromaCompressed;
      asic->regs.ref_l0_chroma_compress_tbl_base[i] = pic->rpl[0][i]->recon_compress.chromaTblBase;
    }

    if (pic->sliceInst->type == B_SLICE)
    {
      /* 6.0 use ref_cnt */
      used_cnt = (vcenc_instance->asic.regs.asicHwId < 0x80006010)?ref_cnt : pic->sliceInst->active_l1_cnt;
      for (i = 0; i < used_cnt; i ++)
        asic->regs.l1_used_by_curr_pic[i] = 1;

      for (i = 0; i < pic->sliceInst->active_l1_cnt; i++)
      {
        asic->regs.pRefPic_recon_l1[0][i] = pic->rpl[1][i]->recon.lum;
        asic->regs.pRefPic_recon_l1[1][i] = pic->rpl[1][i]->recon.cb;
        asic->regs.pRefPic_recon_l1[2][i] = pic->rpl[1][i]->recon.cr;
        asic->regs.pRefPic_recon_l1_4n[i] = pic->rpl[1][i]->recon_4n_base;

        asic->regs.l1_delta_poc[i] = pic->rpl[1][i]->poc - pic->poc;
        asic->regs.l1_long_term_flag[i] = pic->rpl[1][i]->long_term_flag;
        asic->regs.num_long_term_pics += asic->regs.l1_long_term_flag[i];

        //compress
        asic->regs.ref_l1_luma_compressed[i] = pic->rpl[1][i]->recon_compress.lumaCompressed;
        asic->regs.ref_l1_luma_compress_tbl_base[i] = pic->rpl[1][i]->recon_compress.lumaTblBase;

        asic->regs.ref_l1_chroma_compressed[i] = pic->rpl[1][i]->recon_compress.chromaCompressed;
        asic->regs.ref_l1_chroma_compress_tbl_base[i] = pic->rpl[1][i]->recon_compress.chromaTblBase;
      }
    }
    if(!IS_H264(vcenc_instance->codecFormat)) {
      for (i = pic->sliceInst->active_l0_cnt, j = 0; i < 2 && j < r->lt_follow_cnt; i++, j++) {
        asic->regs.l0_delta_poc[i] = r->lt_follow[j] - pic->poc;
        asic->regs.l0_long_term_flag[i] = 1;
      }
      for (i = pic->sliceInst->active_l1_cnt; i < 2 && j < r->lt_follow_cnt; i++, j++) {
        asic->regs.l1_delta_poc[i] = r->lt_follow[j] - pic->poc;
        asic->regs.l1_long_term_flag[i] = 1;
      }
    }
    asic->regs.num_long_term_pics += r->lt_follow_cnt;
  }
  if (IS_H264(vcenc_instance->codecFormat)) {
    asic->regs.colctbs_load_base = (ptr_t)pic->colctbs_load_base;
    asic->regs.colctbs_store_base = (ptr_t)pic->colctbs_store_base;
  }

  asic->regs.recon_luma_compress_tbl_base = pic->recon_compress.lumaTblBase;
  asic->regs.recon_chroma_compress_tbl_base = pic->recon_compress.chromaTblBase;

  asic->regs.active_l0_cnt = pic->sliceInst->active_l0_cnt;
  asic->regs.active_l1_cnt = pic->sliceInst->active_l1_cnt;
  asic->regs.active_override_flag = pic->sliceInst->active_override_flag;

  asic->regs.lists_modification_present_flag = pic->Jenc_pps->lists_modification_present_flag;
  asic->regs.ref_pic_list_modification_flag_l0 = pic->sliceInst->ref_pic_list_modification_flag_l0;
  asic->regs.list_entry_l0[0] = pic->sliceInst->list_entry_l0[0];
  asic->regs.list_entry_l0[1] = pic->sliceInst->list_entry_l0[1];
  asic->regs.ref_pic_list_modification_flag_l1 = pic->sliceInst->ref_pic_list_modification_flag_l1;
  asic->regs.list_entry_l1[0] = pic->sliceInst->list_entry_l1[0];
  asic->regs.list_entry_l1[1] = pic->sliceInst->list_entry_l1[1];

  asic->regs.log2_max_pic_order_cnt_lsb = pic->Jenc_sps->log2_max_pic_order_cnt_lsb;
  asic->regs.log2_max_frame_num = pic->Jenc_sps->log2MaxFrameNumMinus4+4;
  asic->regs.pic_order_cnt_type = pic->Jenc_sps->picOrderCntType;

  //cu info output
  asic->regs.cuInfoTableBase = pic->cuInfoTableBase;
  asic->regs.cuInfoDataBase = pic->cuInfoDataBase;

  //Ctb bits output
  asic->regs.ctbBitsDataBase = pic->ctbBitsDataBase;

  //register dump
  asic->dumpRegister = vcenc_instance->dumpRegister;

  //write recon to ddr
  asic->regs.writeReconToDDR = vcenc_instance->writeReconToDDR;

  vcenc_instance->rateControl.hierarchial_bit_allocation_GOP_size = pEncIn->gopSize;
  /* Rate control */
  if (pic->sliceInst->type == I_SLICE)
  {
    vcenc_instance->rateControl.gopPoc = 0;
    vcenc_instance->rateControl.encoded_frame_number = 0;
  }
  else
  {
    vcenc_instance->rateControl.frameQpDelta = pEncIn->gopCurrPicConfig.QpOffset << QP_FRACTIONAL_BITS;
    vcenc_instance->rateControl.gopPoc       = pEncIn->gopCurrPicConfig.poc;
    vcenc_instance->rateControl.encoded_frame_number = pEncIn->gopPicIdx;
    if (vcenc_instance->rateControl.gopPoc > 0)
      vcenc_instance->rateControl.gopPoc -= 1;
  }

  //CTB_RC
  vcenc_instance->rateControl.ctbRcBitsMin = asic->regs.ctbBitsMin;
  vcenc_instance->rateControl.ctbRcBitsMax = asic->regs.ctbBitsMax;
  vcenc_instance->rateControl.ctbRctotalLcuBit = asic->regs.totalLcuBits;

  if (codingType == VCENC_INTRA_FRAME)
  {
    vcenc_instance->rateControl.qpMin = vcenc_instance->rateControl.qpMinI;
    vcenc_instance->rateControl.qpMax = vcenc_instance->rateControl.qpMaxI;
  }
  else
  {
    vcenc_instance->rateControl.qpMin = vcenc_instance->rateControl.qpMinPB;
    vcenc_instance->rateControl.qpMax = vcenc_instance->rateControl.qpMaxPB;
  }
  vcenc_instance->rateControl.inputSceneChange = pEncIn->sceneChange;

  asic->regs.ctbRcQpDeltaReverse = vcenc_instance->rateControl.ctbRcQpDeltaReverse;
  asic->regs.rcQpDeltaRange = vcenc_instance->rateControl.rcQpDeltaRange;
  asic->regs.rcBaseMBComplexity = vcenc_instance->rateControl.rcBaseMBComplexity;

  if (vcenc_instance->pass == 2)
  {
    i32 i;
    i32 nBlk = (vcenc_instance->width/8) * (vcenc_instance->height/8);
    i32 costScale = 4;
    for (i = 0; i < 4; i ++)
    {
      vcenc_instance->rateControl.pass1CurCost = vcenc_instance->cuTreeCtl.costCur * nBlk / costScale;
      vcenc_instance->rateControl.pass1AvgCost[i] = vcenc_instance->cuTreeCtl.costAvg[i] * nBlk / costScale;
      vcenc_instance->rateControl.pass1FrameNum[i]  = vcenc_instance->cuTreeCtl.FrameTypeNum[i];

      vcenc_instance->rateControl.pass1GopCost[i] = vcenc_instance->cuTreeCtl.costGop[i] * nBlk / costScale;
      vcenc_instance->rateControl.pass1GopFrameNum[i]  = vcenc_instance->cuTreeCtl.FrameNumGop[i];
    }
    vcenc_instance->rateControl.predId = Jenc_getFramePredId(vcenc_instance->cuTreeCtl.curTypeChar);
  }

  asic->regs.bSkipCabacEnable = vcenc_instance->bSkipCabacEnable;
  asic->regs.inLoopDSRatio = vcenc_instance->preProcess.inLoopDSRatio;
  asic->regs.bMotionScoreEnable = vcenc_instance->bMotionScoreEnable;

  JencVCEncBeforePicRc(&vcenc_instance->rateControl, pEncIn->timeIncrement,
                  pic->sliceInst->type, use_ltr_cur, pic);

  asic->regs.bitsRatio    = vcenc_instance->rateControl.bitsRatio;

  asic->regs.ctbRcThrdMin = vcenc_instance->rateControl.ctbRcThrdMin;
  asic->regs.ctbRcThrdMax = vcenc_instance->rateControl.ctbRcThrdMax;
  asic->regs.rcRoiEnable |= ((vcenc_instance->rateControl.ctbRc & 3) << 2);

#if 0
  printf("/***********sw***********/\nvcenc_instance->rateControl.ctbRc=%d,asic->regs.ctbRcBitMemAddrCur=0x%x,asic->regs.ctbRcBitMemAddrPre=0x%x\n", vcenc_instance->rateControl.ctbRc, asic->regs.ctbRcBitMemAddrCur, asic->regs.ctbRcBitMemAddrPre);
  printf("asic->regs.bitsRatio=%d,asic->regs.ctbRcThrdMin=%d,asic->regs.ctbRcThrdMax=%d,asic->regs.rcRoiEnable=%d\n", asic->regs.bitsRatio, asic->regs.ctbRcThrdMin, asic->regs.ctbRcThrdMax, asic->regs.rcRoiEnable);
  printf("asic->regs.ctbBitsMin=%d,asic->regs.ctbBitsMax=%d,asic->regs.totalLcuBits=%d\n", asic->regs.ctbBitsMin, asic->regs.ctbBitsMax, asic->regs.totalLcuBits);
#endif

  vcenc_instance->strmHeaderLen = 0;

  /* time stamp updated */
  Jenc_HevcUpdateSeiTS(&vcenc_instance->rateControl.sei, pEncIn->timeIncrement);
  /* Rate control may choose to skip the frame */
  if (vcenc_instance->rateControl.frameCoded == ENCHW_NO)
  {
    APITRACE("Jenc_VCEncStrmEncode: OK, frame skipped");

    //pSlice->frameNum = pSlice->prevFrameNum;    /* restore frame_num */
    pEncOut->codingType = VCENC_NOTCODED_FRAME;
    Jenc_queue_put(&c->picture, (struct node *)pic);
    if(vcenc_instance->pass==2)
      ReleaseLookaheadPicture(&vcenc_instance->lookahead, outframe);

    return VCENC_FRAME_READY;
  }

  if(VCENC_OK != Jenc_VCEncCodecPrepareEncode(vcenc_instance, pEncIn, pEncOut, codingType, pic, c, segcounts))
    return VCENC_ERROR;

#ifdef TEST_DATA
  Jenc_EncTraceReferences(c, pic, vcenc_instance->pass);
#endif

  VCEncExtParaIn* pExtParaQ = NULL;
  if(vcenc_instance->pass == 2)
  {
      pExtParaQ = (VCEncExtParaIn*)Jenc_queue_get(&vcenc_instance->extraParaQ);//this queue will be empty after flush.
  }
  if(vcenc_instance->pass == 2 && pExtParaQ != NULL)
  {
      vcenc_instance->frameNumExt = pExtParaQ->recon.frame_num;
      pic->frameNumExt = vcenc_instance->frameNumExt;
  }

  if (IS_H264(vcenc_instance->codecFormat)) {
    if (!Jenc_h264_mmo_collect(vcenc_instance, pic, pEncIn))
      return VCENC_ERROR;


    /* use default sliding window mode for P-only ltr gap pattern for compatibility */
    if (codingType == VCENC_INTRA_FRAME && (vcenc_instance->poc == 0)) {
      vcenc_instance->frameNum = 0;
      ++vcenc_instance->idrPicId;
    }
    else if(pic->nalRefIdc)
      vcenc_instance->frameNum++;
    pic->frameNum = vcenc_instance->frameNum;

    if (pic->sliceInst->type != I_SLICE)
    {
      for (i = 0; i < pic->sliceInst->active_l0_cnt; i++)
      {
        asic->regs.l0_delta_framenum[i] = pic->frameNum - pic->rpl[0][i]->frameNum;
        asic->regs.l0_referenceLongTermIdx[i] = (pic->rpl[0][i]->long_term_flag ? pic->rpl[0][i]->curLongTermIdx : 0);
      }

      if (pic->sliceInst->type == B_SLICE)
      {
        for (i = 0; i < pic->sliceInst->active_l1_cnt; i++)
        {
          asic->regs.l1_delta_framenum[i] = pic->frameNum - pic->rpl[1][i]->frameNum;
          asic->regs.l1_referenceLongTermIdx[i] = (pic->rpl[1][i]->long_term_flag ? pic->rpl[1][i]->curLongTermIdx : 0);
        }
      }
    }
  } else {
    pic->markCurrentLongTerm = (pEncIn->u8IdxEncodedAsLTR != 0);
  }

  asic->regs.targetPicSize = vcenc_instance->rateControl.targetPicSize;

  if (asic->regs.asicCfg.ctbRcVersion && IS_CTBRC_FOR_BITRATE(vcenc_instance->rateControl.ctbRc))
  {
    // New ctb rc testing
    vcencRateControl_s *rc = &(vcenc_instance->rateControl);
    float f_tolCtbRc = (codingType == VCENC_INTRA_FRAME) ? rc->tolCtbRcIntra : rc->tolCtbRcInter;
    const i32 tolScale = 1<<TOL_CTB_RC_FIX_POINT;
    i32 tolCtbRc = (i32)(f_tolCtbRc * tolScale);
    enum slice_type idxType = pic->sliceInst->type;
    if (tolCtbRc > 0 || (rc->virtualBuffer.bufferSize == 0 && tolCtbRc == 0))
    {
      /// tolCtbRc > 0: user sets tolCtbRcIntra/tolCtbRcInter
      i32 baseSize = rc->virtualBuffer.bitPerPic;
      if ((codingType != VCENC_INTRA_FRAME) && (rc->targetPicSize < baseSize))
        baseSize = rc->targetPicSize;

      i32 minDeltaSize = Jenc_rcCalculate(baseSize, tolCtbRc, (tolScale + tolCtbRc));
      i32 maxDeltaSize = Jenc_rcCalculate(baseSize, tolCtbRc, tolScale);

      asic->regs.minPicSize = MAX(0, (rc->targetPicSize - minDeltaSize));
      asic->regs.maxPicSize = rc->targetPicSize + maxDeltaSize;
    }
    else
    {
      asic->regs.minPicSize = asic->regs.maxPicSize = 0;
    //   if (rc->minPicSize > 0)
    //     asic->regs.minPicSize = rc->minPicSize;
    //   if (rc->maxPicSize > 0)
    //     asic->regs.maxPicSize = rc->maxPicSize;

    //   // reset rc->minPicSize and rc->maxPicSize for next frame use
    //   rc->minPicSize = rc->maxPicSize = 0;
    }
    asic->regs.ctbRcRowFactor = rc->ctbRateCtrl.rowFactor;
    asic->regs.ctbRcQpStep = rc->ctbRateCtrl.qpStep;
    asic->regs.ctbRcMemAddrCur = rc->ctbRateCtrl.ctbMemCurAddr;
    asic->regs.ctbRcModelParamMin = rc->ctbRateCtrl.models[idxType].xMin;
    if(rc->ctbRateCtrl.models[idxType].started == 0)
    {
      if ((idxType == B_SLICE) && rc->ctbRateCtrl.models[P_SLICE].started)
        idxType = P_SLICE;
      else if (rc->ctbRateCtrl.models[I_SLICE].started)
        idxType = I_SLICE;
    }
    asic->regs.ctbRcModelParam0  = rc->ctbRateCtrl.models[idxType].x0;
    asic->regs.ctbRcModelParam1  = rc->ctbRateCtrl.models[idxType].x1;
    asic->regs.prevPicLumMad     = rc->ctbRateCtrl.models[idxType].preFrameMad;
    asic->regs.ctbRcMemAddrPre   = rc->ctbRateCtrl.models[idxType].ctbMemPreAddr;
    asic->regs.ctbRcPrevMadValid = rc->ctbRateCtrl.models[idxType].started ? 1 : 0;
    asic->regs.ctbRcDelay = IS_H264(vcenc_instance->codecFormat) ? 5 : 2;
    if (pic->sliceInst->type != I_SLICE)
    {
      i32 bpBlk = rc->targetPicSize / (rc->picArea >> 6);
      i32 bpTh = 16;
      if (bpBlk >= bpTh)
        asic->regs.ctbRcDelay = IS_H264(vcenc_instance->codecFormat)? 7 : 3;
    }
  }

  asic->regs.inputLumBase = pic->input.lum;
  asic->regs.inputCbBase = pic->input.cb;
  asic->regs.inputCrBase = pic->input.cr;

  /* setup stabilization */
  if (vcenc_instance->preProcess.videoStab)
  {
    asic->regs.stabNextLumaBase = pEncIn->busLumaStab;
  }

  asic->regs.minCbSize = pic->Jenc_sps->log2_min_cb_size;
  asic->regs.maxCbSize = pic->Jenc_pps->log2_ctb_size;
  asic->regs.minTrbSize = pic->Jenc_sps->log2_min_tr_size;
  asic->regs.maxTrbSize = pic->Jenc_pps->log2_max_tr_size;

  asic->regs.picWidth = pic->Jenc_sps->width_min_cbs;
  asic->regs.picHeight = pic->Jenc_sps->height_min_cbs;

  asic->regs.pps_deblocking_filter_override_enabled_flag = pic->Jenc_pps->deblocking_filter_override_enabled_flag;

  /* Enable slice ready interrupts if defined by config and slices in use */
  asic->regs.sliceReadyInterrupt =
    ENCH2_SLICE_READY_INTERRUPT & ((asic->regs.sliceNum > 1));
  asic->regs.picInitQp = pic->Jenc_pps->init_qp;
#ifndef CTBRC_STRENGTH
  asic->regs.qp = vcenc_instance->rateControl.qpHdr;
#else
    //printf("float qp=%f\n",vcenc_instance->rateControl.qpHdr);
    //printf("float qp=%f\n",inst->rateControl.qpHdr);
    asic->regs.qp = (vcenc_instance->rateControl.qpHdr >> QP_FRACTIONAL_BITS);
    asic->regs.qpfrac = (vcenc_instance->rateControl.qpHdr - (asic->regs.qp << QP_FRACTIONAL_BITS)) << (16 - QP_FRACTIONAL_BITS);
    //printf("float qp=%f, int qp=%d,qpfrac=0x%x\n",vcenc_instance->rateControl.qpHdr,asic->regs.qp, asic->regs.qpfrac);
    //#define BLOCK_SIZE_MIN_RC  32 , 2=16x16,1= 32x32, 0=64x64
    asic->regs.rcBlockSize = vcenc_instance->blockRCSize;
    {
        i32 qpDeltaGain;
        float strength = 1.6f;
        float qpDeltaGainFloat;

        qpDeltaGainFloat = vcenc_instance->rateControl.complexity;
        if(qpDeltaGainFloat < 14.0)
        {
            qpDeltaGainFloat = 14.0;
        }
        qpDeltaGainFloat = qpDeltaGainFloat*qpDeltaGainFloat*strength;
        qpDeltaGain = (i32)(qpDeltaGainFloat);

        asic->regs.qpDeltaMBGain = qpDeltaGain ;
    }
#endif
  if(asic->regs.asicCfg.tu32Enable && asic->regs.asicCfg.dynamicMaxTuSize && vcenc_instance->rdoLevel == 0 && asic->regs.qp <= 30 && (IS_HEVC(vcenc_instance->codecFormat) || IS_H264(vcenc_instance->codecFormat)))
    asic->regs.current_max_tu_size_decrease = 1;
  else
    asic->regs.current_max_tu_size_decrease = 0;

  asic->regs.qpMax = vcenc_instance->rateControl.qpMax >> QP_FRACTIONAL_BITS;
  asic->regs.qpMin = vcenc_instance->rateControl.qpMin >> QP_FRACTIONAL_BITS;
  if (IS_CTBRC_FOR_QUALITY(vcenc_instance->rateControl.ctbRc))
  {
    /* if ctbRc can tune subjective quality, not to increase block qp bigger than a big enough frame qp,
       otherwise it will hurt subjective quality. */
    const u32 worstQualityQp = 42;
    u32 qpMaxLimit = MAX(worstQualityQp, asic->regs.qp);
    asic->regs.qpMax = MIN(qpMaxLimit, asic->regs.qpMax);
  }

  if(vcenc_instance->pass == 1)
  {
    pic->outForCutree.poc = vcenc_instance->poc;
    pic->outForCutree.qp = vcenc_instance->rateControl.qpHdr;
    pic->outForCutree.codingType = pEncOut->codingType;
    pic->outForCutree.hierarchial_bit_allocation_GOP_size = vcenc_instance->rateControl.hierarchial_bit_allocation_GOP_size;
    pic->outForCutree.encoded_frame_number = vcenc_instance->rateControl.encoded_frame_number;
    pic->outForCutree.dsRatio = vcenc_instance->preProcess.inLoopDSRatio;
    pic->outForCutree.extDSRatio = vcenc_instance->extDSRatio;
    pic->outForCutree.p0 = ABS(asic->regs.l0_delta_poc[0]);
    pic->outForCutree.p1 = ABS(asic->regs.l1_delta_poc[0]);
    pic->outForCutree.roiMapEnable = vcenc_instance->roiMapEnable && pEncIn->pRoiMapDelta;

    if(vcenc_instance->asic.regs.asicCfg.bMultiPassSupport)
    {
      pic->outForCutree.cuDataIdx = ((ptr_t)pEncOut->cuOutData.cuData-((ptr_t)vcenc_instance->asic.cuInfoMem[0].virtualAddress + vcenc_instance->asic.cuInfoTableSize))/(vcenc_instance->asic.cuInfoMem[1].busAddress - vcenc_instance->asic.cuInfoMem[0].busAddress);
      pic->outForCutree.roiMapEnable = pic->outForCutree.roiMapEnable && pEncIn->roiMapDeltaQpAddr;
      pic->outForCutree.pRoiMapDelta = pEncIn->pRoiMapDelta;
      pic->outForCutree.roiMapDeltaQpAddr = pEncIn->roiMapDeltaQpAddr;
      pic->outForCutree.roiMapDeltaSize = pEncIn->roiMapDeltaSize;
    }
  }

  pic->Jenc_pps->qp = asic->regs.qp;
  pic->Jenc_pps->qpMin = asic->regs.qpMin;
  pic->Jenc_pps->qpMax = asic->regs.qpMax;

  asic->regs.diffCuQpDeltaDepth = pic->Jenc_pps->diff_cu_qp_delta_depth;

  asic->regs.cbQpOffset = pic->Jenc_pps->cb_qp_offset;
  asic->regs.saoEnable = pic->Jenc_sps->sao_enabled_flag;
  asic->regs.maxTransHierarchyDepthInter = pic->Jenc_sps->max_tr_hierarchy_depth_inter;
  asic->regs.maxTransHierarchyDepthIntra = pic->Jenc_sps->max_tr_hierarchy_depth_intra;
  asic->regs.cuQpDeltaEnabled = pic->Jenc_pps->cu_qp_delta_enabled_flag;
  asic->regs.log2ParellelMergeLevel = pic->Jenc_pps->log2_parallel_merge_level;
  if(rpsInSliceHeader || IS_H264(vcenc_instance->codecFormat))
  {
    asic->regs.numShortTermRefPicSets = 0;
  }
  else
  {
    asic->regs.numShortTermRefPicSets = pic->Jenc_sps->num_short_term_ref_pic_sets;
  }
  asic->regs.long_term_ref_pics_present_flag = pic->Jenc_sps->long_term_ref_pics_present_flag;

  asic->regs.reconLumBase = pic->recon.lum;
  asic->regs.reconCbBase = pic->recon.cb;
  asic->regs.reconCrBase = pic->recon.cr;

  asic->regs.reconL4nBase = pic->recon_4n_base;

  /* Map the reset of instance parameters */
  asic->regs.poc = pic->poc;
  asic->regs.frameNum = pic->frameNum;
  asic->regs.idrPicId = (codingType == VCENC_INTRA_FRAME ? (vcenc_instance->idrPicId & 1) : 0);
  asic->regs.nalRefIdc = pic->nalRefIdc;
  asic->regs.nalRefIdc_2bit = pic->nalRefIdc_2bit;
  asic->regs.markCurrentLongTerm = pic->markCurrentLongTerm;
  asic->regs.currentLongTermIdx = pic->curLongTermIdx;
  asic->regs.transform8x8Enable = pic->Jenc_pps->transform8x8Mode;
  asic->regs.entropy_coding_mode_flag = pic->Jenc_pps->entropy_coding_mode_flag;
  if(rpsInSliceHeader || IS_H264(vcenc_instance->codecFormat))
  {
    asic->regs.rpsId = 0;
  }
  else
  {
    asic->regs.rpsId = pic->rps->ps.id;
  }
  // numNegativePics / numNegativePics is only used when short_term_ref_pic_set_sps_flag == 0
  // this relaxes bits limitation for GOP16.
  if(!vcenc_instance->sHwRps.u1short_term_ref_pic_set_sps_flag)
  {
    asic->regs.numNegativePics = pic->rps->num_negative_pics;
    asic->regs.numPositivePics = pic->rps->num_positive_pics;
  }
  else
  {
    asic->regs.numNegativePics = 0;
    asic->regs.numPositivePics = 0;
  }
  /* H.264 MMO */
  asic->regs.l0_used_by_next_pic[0] = 1;
  asic->regs.l0_used_by_next_pic[1] = 1;
  asic->regs.l1_used_by_next_pic[0] = 1;
  asic->regs.l1_used_by_next_pic[1] = 1;
  if(IS_H264(vcenc_instance->codecFormat) && pic->nalRefIdc && vcenc_instance->h264_mmo_nops > 0 && (pExtParaQ == NULL)) {
    int cnt[2] = {pic->sliceInst->active_l0_cnt, pic->sliceInst->active_l1_cnt};
#if 1 // passing all unreferenced frame to hw
    for(i = 0; i < vcenc_instance->h264_mmo_nops; i++)
      Jenc_h264_mmo_mark_unref(&asic->regs, vcenc_instance->h264_mmo_unref[i], vcenc_instance->h264_mmo_long_term_flag[i], vcenc_instance->h264_mmo_ltIdx[i], cnt, pic);
    vcenc_instance->h264_mmo_nops = 0;
#else // passing at most 1 unreferenced frame to hw
    Jenc_h264_mmo_mark_unref(&asic->regs, vcenc_instance->h264_mmo_unref[--vcenc_instance->h264_mmo_nops], cnt, pic);
#endif
  }

  asic->regs.pps_id = pic->Jenc_pps->ps.id;

  asic->regs.filterDisable = vcenc_instance->disableDeblocking;
  asic->regs.tc_Offset = vcenc_instance->tc_Offset * 2;
  asic->regs.beta_Offset = vcenc_instance->beta_Offset * 2;

  /* strong_intra_smoothing_enabled_flag */
  asic->regs.strong_intra_smoothing_enabled_flag = pic->Jenc_sps->strong_intra_smoothing_enabled_flag;

  /* constrained_intra_pred_flag */
  asic->regs.constrained_intra_pred_flag = pic->Jenc_pps->constrained_intra_pred_flag;

  /* skip frame flag */
  asic->regs.skip_frame_enabled = bSkipFrame;

  /*  update rdoLevel from instance per-frame:
    *  if skip_frame_enabled, config rdoLevel=0
    *  otherwise restore instance's rdoLevel setting
    */
  asic->regs.rdoLevel = vcenc_instance->rdoLevel;
  if(asic->regs.skip_frame_enabled)
   asic->regs.rdoLevel =0;

  /* set rdoLevel=0 when HW not support progRdo */
  if(!asic->regs.asicCfg.progRdoEnable)
    asic->regs.rdoLevel =0;

  /* HW base address for NAL unit sizes is affected by start offset
   * and SW created NALUs. */
  asic->regs.sizeTblBase = asic->sizeTbl[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum].busAddress;
  asic->regs.compress_coeff_scan_base = asic->compress_coeff_SACN[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum].busAddress;
  /*clip qp*/
#ifdef CTBRC_STRENGTH

/* configure ROI parameters */
  Jenc_StrmEncodeRegionOfInterest(vcenc_instance, asic);

#endif

  /* HW Base must be 64-bit aligned */
  ASSERT(asic->regs.sizeTblBase % 8 == 0);

  /*inter prediction parameters*/
  double dQPFactor = (HW_ID_MAJOR_NUMBER(asic->regs.asicHwId)==0x60) ? 0.894 : 0.387298335; // sqrt(0.15);
  bool depth0 = HANTRO_TRUE;

  asic->regs.nuh_temporal_id = 0;

  if (pic->sliceInst->type != I_SLICE)
  {
    dQPFactor = pEncIn->gopCurrPicConfig.QpFactor;
    depth0 = (pEncIn->gopCurrPicConfig.poc % pEncIn->gopSize) ? HANTRO_FALSE : HANTRO_TRUE;
    asic->regs.nuh_temporal_id = pEncIn->gopCurrPicConfig.temporalId;
    if(useExtFlag && vcenc_instance->pass == 0)
      asic->regs.nuh_temporal_id = pEncExtParaIn->recon.temporalId;
    else if(useExtFlag && vcenc_instance->pass == 2 && pExtParaQ != NULL)
      asic->regs.nuh_temporal_id = pExtParaQ->recon.temporalId;
    //HEVC support temporal svc
    if((asic->regs.nuh_temporal_id) && (!IS_H264(vcenc_instance->codecFormat)))
      asic->regs.nal_unit_type = TSA_R;
  }

  /* flag for HW to code PrefixNAL */
  /* For VC8000E 6.0, minor version >= 6010 */
  asic->regs.prefixnal_svc_ext = IS_H264(vcenc_instance->codecFormat) && (s->max_num_sub_layers > 1) &&
                                 (vcenc_instance->asic.regs.asicHwId >= 0x80006010);

  VCEncSetQuantParameters(vcenc_instance, pic, pEncIn, dQPFactor, depth0);

  asic->regs.skip_chroma_dc_threadhold = 2;

  /*tuning on intra cu cost bias*/
  asic->regs.bits_est_bias_intra_cu_8 = 22; //25;
  asic->regs.bits_est_bias_intra_cu_16 = 40; //48;
  asic->regs.bits_est_bias_intra_cu_32 = 86; //108;
  asic->regs.bits_est_bias_intra_cu_64 = 38 * 8; //48*8;

  asic->regs.bits_est_1n_cu_penalty = 5;
  asic->regs.bits_est_tu_split_penalty = 3;
  asic->regs.inter_skip_bias = 124;

  /*small resolution, smaller CU/TU prefered*/
  if (pic->Jenc_sps->width <= 832 && pic->Jenc_sps->height <= 480)
  {
    asic->regs.bits_est_1n_cu_penalty = 0;
    asic->regs.bits_est_tu_split_penalty = 2;
  }

  if (IS_H264(vcenc_instance->codecFormat))
    asic->regs.bits_est_1n_cu_penalty = 15;

  // scaling list enable
  asic->regs.scaling_list_enabled_flag = pic->Jenc_sps->scaling_list_enable_flag;

  /*stream multi-segment*/
  asic->regs.streamMultiSegEn = vcenc_instance->streamMultiSegment.streamMultiSegmentMode != 0;
  asic->regs.streamMultiSegSWSyncEn = vcenc_instance->streamMultiSegment.streamMultiSegmentMode == 2;
  asic->regs.streamMultiSegRD = 0;
  asic->regs.streamMultiSegIRQEn = 0;
  vcenc_instance->streamMultiSegment.rdCnt = 0;
  if (asic->regs.streamMultiSegEn)
  {
    //make sure the stream size is equal to N*segment size
    asic->regs.streamMultiSegSize = asic->regs.outputStrmSize[0]/vcenc_instance->streamMultiSegment.streamMultiSegmentAmount;
    asic->regs.streamMultiSegSize = ((asic->regs.streamMultiSegSize + 16 - 1) & (~(16 - 1)));//segment size must be aligned to 16byte
    asic->regs.outputStrmSize[0] = asic->regs.streamMultiSegSize*vcenc_instance->streamMultiSegment.streamMultiSegmentAmount;
    asic->regs.streamMultiSegIRQEn = 1;
    printf("segment size = %d\n",asic->regs.streamMultiSegSize);
  }

  /* smart */
  asic->regs.smartModeEnable = vcenc_instance->smartModeEnable;
  asic->regs.smartH264LumDcTh = vcenc_instance->smartH264LumDcTh;
  asic->regs.smartH264CbDcTh = vcenc_instance->smartH264CbDcTh;
  asic->regs.smartH264CrDcTh = vcenc_instance->smartH264CrDcTh;
  for(i = 0; i < 3; i++) {
    asic->regs.smartHevcLumDcTh[i] = vcenc_instance->smartHevcLumDcTh[i];
    asic->regs.smartHevcChrDcTh[i] = vcenc_instance->smartHevcChrDcTh[i];
    asic->regs.smartHevcLumAcNumTh[i] = vcenc_instance->smartHevcLumAcNumTh[i];
    asic->regs.smartHevcChrAcNumTh[i] = vcenc_instance->smartHevcChrAcNumTh[i];
  }
  asic->regs.smartH264Qp = vcenc_instance->smartH264Qp;
  asic->regs.smartHevcLumQp = vcenc_instance->smartHevcLumQp;
  asic->regs.smartHevcChrQp = vcenc_instance->smartHevcChrQp;
  for(i = 0; i < 4; i++)
    asic->regs.smartMeanTh[i] = vcenc_instance->smartMeanTh[i];
  asic->regs.smartPixNumCntTh = vcenc_instance->smartPixNumCntTh;

  /* Tile */
  asic->regs.tiles_enabled_flag = vcenc_instance->tiles_enabled_flag;
  asic->regs.num_tile_columns = vcenc_instance->num_tile_columns;
  asic->regs.num_tile_rows = vcenc_instance->num_tile_rows;
  asic->regs.loop_filter_across_tiles_enabled_flag = vcenc_instance->loop_filter_across_tiles_enabled_flag;

  /* Global MV */
  Jenc_StrmEncodeGlobalmvConfig  (asic, pic, pEncIn, vcenc_instance );

  /* multi-core sync */
  asic->regs.mc_sync_enable = (vcenc_instance->parallelCoreNum > 1);
  if(asic->regs.mc_sync_enable) {
    asic->regs.mc_sync_l0_addr = (codingType == VCENC_INTRA_FRAME ? 0 : pic->rpl[0][0]->mc_sync_addr);
    asic->regs.mc_sync_l1_addr = (codingType != VCENC_BIDIR_PREDICTED_FRAME ? 0 : pic->rpl[1][0]->mc_sync_addr);
    asic->regs.mc_sync_rec_addr = pic->mc_sync_addr;
    asic->regs.mc_ref_ready_threshold = 0;
    asic->regs.mc_ddr_polling_interval = (IS_H264(vcenc_instance->codecFormat) ? 32 : 128)*pic->Jenc_pps->ctb_per_row;
    /* clear sync address */
    *(int *)pic->mc_sync_ptr = 0;
  }

  //set/clear picture compress flag
  pic->recon_compress.lumaCompressed = asic->regs.recon_luma_compress ? 1 : 0;
  pic->recon_compress.chromaCompressed = asic->regs.recon_chroma_compress ? 1 : 0;

  VCEncHEVCDnfPrepare(vcenc_instance);

#ifdef INTERNAL_TEST
  /* Configure the ASIC penalties according to the test vector */
  Jenc_HevcConfigureTestBeforeStart(vcenc_instance);
#endif

  vcenc_instance->preProcess.bottomField = (vcenc_instance->poc % 2) == vcenc_instance->fieldOrder;
  Jenc_HevcUpdateSeiPS(&vcenc_instance->rateControl.sei, vcenc_instance->preProcess.interlacedFrame, vcenc_instance->preProcess.bottomField);

  /* configure OSD and mosaic parameter */
  Jenc_StrmEncodeOverlayConfig(asic, pEncIn, vcenc_instance);

  JencPreProcess(asic, &vcenc_instance->preProcess, vcenc_instance->ctx);

  /* PREFIX SEI */
  Jenc_StrmEncodePrefixSei(vcenc_instance, s, pEncOut, pic, pEncIn);

  vcenc_instance->numNalus[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = pEncOut->numNalus;

  /* Reset callback struct */
  slice_callback.slicesReadyPrev = 0;
  slice_callback.slicesReady = 0;
  slice_callback.sliceSizes = (u32 *) vcenc_instance->asic.sizeTbl[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum].virtualAddress;
  //slice_callback.sliceSizes += vcenc_instance->numNalus;
  slice_callback.nalUnitInfoNum = vcenc_instance->numNalus[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  slice_callback.nalUnitInfoNumPrev = 0;
  slice_callback.streamBufs = vcenc_instance->streamBufs[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  slice_callback.pAppData = vcenc_instance->pAppData[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];

  VCEncSetNewFrame(vcenc_instance);
  vcenc_instance->output_buffer_over_flow = 0;
  if(!vcenc_instance->asic.regs.bVCMDEnable)
  {
    //printf("reserve hw core_info =%x\n",vcenc_instance->reserve_core_info);


    /* Try to reserve the HW resource */
    if (JencEWLReserveHw(vcenc_instance->asic.ewl,&vcenc_instance->reserve_core_info, &waitCoreJobid) == EWL_ERROR)
    {
      APITRACEERR("Jenc_VCEncStrmEncode: ERROR HW unavailable");
      return VCENC_HW_RESERVED;
    }
  }
  if(useExtFlag)
  {
    if(vcenc_instance->pass == 2 && pExtParaQ != NULL)
        Jenc_useExtPara(pExtParaQ, asic, IS_H264(vcenc_instance->codecFormat), vcenc_instance);
    else if(vcenc_instance->pass == 0)
        Jenc_useExtPara(pEncExtParaIn, asic, IS_H264(vcenc_instance->codecFormat), vcenc_instance);
  }

  if ((!IS_H264(vcenc_instance->codecFormat)) || pic->nalRefIdc)
    pic->reference = HANTRO_TRUE;

  memset(&dec400_data, 0, sizeof(dec400_data));
  dec400_data.format = vcenc_instance->preProcess.inputFormat;
  dec400_data.lumWidthSrc = vcenc_instance->preProcess.lumWidthSrc;
  dec400_data.lumHeightSrc = vcenc_instance->preProcess.lumHeightSrc;
  dec400_data.input_alignment = vcenc_instance->preProcess.input_alignment;
  dec400_data.dec400LumTableBase = pEncIn->dec400LumTableBase;
  dec400_data.dec400CbTableBase = pEncIn->dec400CbTableBase;
  dec400_data.dec400CrTableBase = pEncIn->dec400CrTableBase;
  dec400_data.dec400Enable = pEncIn->dec400Enable;

  dec400_data.wlInstance = asic->ewl;
  dec400_data.regVcmdBuf = asic->regs.vcmdBuf;
  dec400_data.regVcmdBufSize = &asic->regs.vcmdBufSize;
  dec400_data.dec400CrDataBase = asic->regs.inputCrBase;
  dec400_data.dec400CbDataBase = asic->regs.inputCbBase;
  dec400_data.dec400LumDataBase = asic->regs.inputLumBase;

  Jenc_TemporalMvpGenConfig(vcenc_instance, pEncIn, c, pic, codingType);

  /* enable DEC400 to get decompressed input data */
  VCDec400data dec400_osd;
  memset(&dec400_osd, 0, sizeof(dec400_data));
  if (pEncIn->osdDec400Enable)
  {
    dec400_osd.format = VCENC_RGB888;
    dec400_osd.lumWidthSrc = vcenc_instance->preProcess.overlayYStride[0];
    dec400_osd.lumHeightSrc = vcenc_instance->preProcess.overlayHeight[0];
    dec400_osd.input_alignment = vcenc_instance->preProcess.input_alignment;
    dec400_osd.dec400LumTableBase = pEncIn->osdDec400TableBase;
    dec400_osd.dec400CbTableBase = 0;
    dec400_osd.dec400CrTableBase = 0;
    dec400_osd.dec400Enable = 0;

    dec400_osd.wlInstance = asic->ewl;
    dec400_osd.regVcmdBuf = asic->regs.vcmdBuf;
    dec400_osd.regVcmdBufSize = &asic->regs.vcmdBufSize;
    dec400_osd.dec400CrDataBase = asic->regs.overlayVAddr[0];
    dec400_osd.dec400CbDataBase = asic->regs.overlayUAddr[0];
    dec400_osd.dec400LumDataBase = asic->regs.overlayYAddr[0];

    dec400_osd.osdInputSuperTile = vcenc_instance->preProcess.overlaySuperTile[0];
  }

  if(!vcenc_instance->asic.regs.bVCMDEnable)
  {
    //L2CACHE
    if(Jenc_EnableCache(vcenc_instance,asic,pic)  != VCENC_OK)
    {
      printf("Encoder enable cache failed!!\n");
      return VCENC_ERROR;
    }

    //DEC400
    if (pEncIn->dec400Enable == 2 && Jenc_VCEncEnableDec400(&dec400_data) == VCENC_INVALID_ARGUMENT)
    {
      APITRACEERR("Jenc_VCEncStrmEncode: DEC400 doesn't exist or format not supported");
      JencEWLReleaseHw(asic->ewl);
      return VCENC_INVALID_ARGUMENT;
    } else if(pEncIn->dec400Enable == 1) {
      APITRACE("Jenc_VCEncStrmEncode: DEC400 set stream bypass");
      asic->regs.AXI_ENC_WR_ID_E = 1;
      asic->regs.AXI_ENC_RD_ID_E = 1;
      Jenc_VCEncSetDec400StreamBypass(&dec400_data);
    }

    //OSD dec400
    if (pEncIn->osdDec400Enable)
    {
      if (Jenc_VCEncEnableDec400(&dec400_osd) == VCENC_INVALID_ARGUMENT)
      {
        APITRACEERR("Jenc_VCEncStrmEncode: osd DEC400 error\n");
        JencEWLReleaseHw(asic->ewl);
        return VCENC_INVALID_ARGUMENT;
      }
    }

    //AXIFE
    if(pEncIn->axiFEEnable)
    {
      vcenc_instance->axiFEEnable = pEncIn->axiFEEnable;
      Jenc_VCEncAxiFeEnable((void *)vcenc_instance, NULL);
    }

    //APBfilter
    if(pEncIn->apbFTEnable)
    {
      if (Jenc_VCEncSetApbFilter((void *)vcenc_instance) != VCENC_OK)
      {
        APITRACEERR("Jenc_VCEncStrmEncode: set apb filter\n");
        return VCENC_INVALID_ARGUMENT;
      }
    }

     JencEncAsicFrameStart(asic->ewl, &asic->regs, asic->dumpRegister);

     byteCntSw = vcenc_instance->stream.byteCnt;

     JENC_EWLWaitJobCfg_t waitJobCfg;
     JENC_CacheData_t cache_data;
     memset(&waitJobCfg, 0, sizeof(JENC_EWLWaitJobCfg_t));
     waitJobCfg.waitCoreJobid = waitCoreJobid;
     waitJobCfg.dec400_enable = pEncIn->dec400Enable;
     waitJobCfg.dec400_data = NULL;
     waitJobCfg.axife_enable = pEncIn->axiFEEnable;
     waitJobCfg.axife_callback = Jenc_VCEncAxiFeDisable;
    #ifdef SUPPORT_CACHE
     waitJobCfg.l2cache_enable = 1;
    #endif
     cache_data.cache = &vcenc_instance->cache;
     waitJobCfg.l2cache_data = &cache_data;
     waitJobCfg.l2cache_callback = Jenc_DisableCache;

     JencEWLEnqueueWaitjob(asic->ewl, &waitJobCfg);
  }
  else
  {
    //priority = 0, will be set in command line.
    JencEncSetReseveInfo(asic->ewl,vcenc_instance->width,vcenc_instance->height,vcenc_instance->rdoLevel,vcenc_instance->asic.regs.bRDOQEnable,0,client_type);
    JencEncReseveCmdbuf(asic->ewl, &asic->regs);
    pic->cmdbufid = asic->regs.cmdbufid;
    vcenc_instance->asic.regs.vcmdBufSize = 0;
    if(JencEncMakeCmdbufData(asic, &asic->regs,&dec400_data, &dec400_osd)==VCENC_INVALID_ARGUMENT)
    {
      APITRACEERR("Jenc_VCEncStrmEncode: DEC400 doesn't exist or format not supported");
      JencEWLReleaseCmdbuf(asic->ewl,pic->cmdbufid);
      return VCENC_INVALID_ARGUMENT;
    }
    vcenc_instance->asic.regs.totalCmdbufSize = vcenc_instance->asic.regs.vcmdBufSize;
    JencEncCopyDataToCmdbuf(asic->ewl, &asic->regs);

    JencEncLinkRunCmdbuf(asic->ewl,&asic->regs);
  }


  Jenc_sw_ref_cnt_increase(pic);

  // picture instance switch for multi-core encoding
  if(vcenc_instance->parallelCoreNum > 1) {
    pic->picture_cnt = pEncOut->picture_cnt;
    memcpy(&vcenc_instance->streams[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum], &vcenc_instance->stream, sizeof(struct buffer));
    vcenc_instance->pic[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = pic;
    vcenc_instance->waitJobid[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = waitCoreJobid;
	/*buffer EncIn and EncOut of pass 1 in encoding order for they will be used to assemble job to Cutree*/
    if(vcenc_instance->pass == 1)
    {
      vcenc_instance->EncOut[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = *pEncOut;
      vcenc_instance->EncIn[vcenc_instance->jobCnt % vcenc_instance->parallelCoreNum] = *pEncIn;
    }

    if(vcenc_instance->reservedCore >= vcenc_instance->parallelCoreNum-1)
    {
      Jenc_queue_put(&c->picture, (struct node *)pic);
      pic = vcenc_instance->pic[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
      Jenc_queue_remove(&c->picture, (struct node *)pic);
      memcpy(&vcenc_instance->stream, &vcenc_instance->streams[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum], sizeof(struct buffer));
      waitCoreJobid = vcenc_instance->waitJobid[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
     if(vcenc_instance->pass == 1)
      {
        *pEncOut = vcenc_instance->EncOut[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
        *pEncIn = vcenc_instance->EncIn[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
      }
    }
    pEncOut->picture_cnt = pic->picture_cnt;
  }
  vcenc_instance->reservedCore++;
  vcenc_instance->reservedCore = MIN(vcenc_instance->reservedCore, vcenc_instance->parallelCoreNum);
  pEncOut->numNalus = vcenc_instance->numNalus[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];

  if(vcenc_instance->reservedCore == vcenc_instance->parallelCoreNum)
    ret = Jenc_VCEncStrmWaitReady(inst, pEncIn, pEncOut,  pic,  &slice_callback, c, waitCoreJobid);
  else
  {
    ret =VCENC_FRAME_ENQUEUE;
    vcenc_instance->frameCnt++;  // update frame count after one frame is ready.
    vcenc_instance->jobCnt++;  // update job count after one frame is ready.
    Jenc_queue_put(&c->picture, (struct node *)pic);
    return ret;
  }

  vcenc_instance->jobCnt++;  // update job count after one frame is ready.
  pEncOut->pNaluSizeBuf = (u32 *)vcenc_instance->asic.sizeTbl[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].virtualAddress;

  if (ret != VCENC_OK)
    goto out;

  if (vcenc_instance->output_buffer_over_flow == 1)
  {
    vcenc_instance->stream.byteCnt = 0;
    pEncOut->streamSize = vcenc_instance->stream.byteCnt;
    pEncOut->numNalus = 0;
    pEncOut->pNaluSizeBuf[0] = 0;
    vcenc_instance->encStatus = VCENCSTAT_START_FRAME;
    ret = VCENC_OUTPUT_BUFFER_OVERFLOW;
    /* revert frameNum update on output buffer overflow */
    if (IS_H264(vcenc_instance->codecFormat) && pic->nalRefIdc)
      vcenc_instance->frameNum--;
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Output buffer too small");
    goto out;
  }

  i32 stat;
#ifdef CTBRC_STRENGTH
  vcenc_instance->rateControl.rcPicComplexity = asic->regs.picComplexity;
  vcenc_instance->rateControl.complexity = (float)vcenc_instance->rateControl.rcPicComplexity * (vcenc_instance->rateControl.reciprocalOfNumBlk8);
#endif

  const enum slice_type _slctypes[3] = {P_SLICE, I_SLICE, B_SLICE};
  vcenc_instance->rateControl.sliceTypeCur = _slctypes[asic->regs.frameCodingType];
  stat = JencVCEncAfterPicRc(&vcenc_instance->rateControl, 0, vcenc_instance->stream.byteCnt, asic->regs.sumOfQP,asic->regs.sumOfQPNumber);

  /* After HRD overflow discard the coded frame and go back old time,
      * just like not coded frame. But if only one reference frame
      * buffer is in use we can't discard the frame unless the next frame
      * is coded as intra. */
  if (stat == VCENCRC_OVERFLOW && vcenc_instance->pass != 2)
  {
    vcenc_instance->stream.byteCnt = 0;

    pEncOut->numNalus = 0;
    pEncOut->pNaluSizeBuf[0] = 0;

    /* revert frameNum update on HRD overflow */
    if (IS_H264(vcenc_instance->codecFormat) && pic->nalRefIdc)
      vcenc_instance->frameNum--;
    //Jenc_queue_put(&c->picture, (struct node *)pic);
    APITRACE("Jenc_VCEncStrmEncode: OK, Frame discarded (HRD overflow)");
    //return VCENC_FRAME_READY;
  }
  else
    vcenc_instance->rateControl.sei.activated_sps = 1;

#ifdef INTERNAL_TEST
  if(vcenc_instance->testId == TID_RFD) {
    Jenc_HevcRFDTest(vcenc_instance, pic);
  }
#endif
  vcenc_instance->frameCnt++;  // update frame count after one frame is ready.

  //add filler if vbv buffer underflow (stat > 0)
  if((vcenc_instance->rateControl.hrd && (stat > 0)) &&
     (vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_HEVC ||
     vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_H264))
  {
      //printf("-----------------Buffer underflow. add %d bytes filler data.\n", stat);
      i32 has_prefix = (vcenc_instance->asic.regs.streamMode == VCENC_BYTE_STREAM) ? ENCHW_YES : ENCHW_NO;
      i32 is_hevc = vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_HEVC;

      tmp = vcenc_instance->stream.byteCnt;
      //vcenc_instance->stream.stream += (vcenc_instance->stream.byteCnt - byteCntSw);

      if(has_prefix && stat <= 5 + is_hevc) {
          VCEncAddFillerNALU(inst, 0, 1);
          vcenc_instance->rateControl.virtualBuffer.bucketFullness += (5 + is_hevc - stat) * 8;
          vcenc_instance->rateControl.virtualBuffer.realBitCnt += (5 + is_hevc - stat) * 8;
          vcenc_instance->rateControl.virtualBuffer.bucketLevel += (5 + is_hevc - stat) * 8;
      }
      else if(has_prefix && stat > 5 + is_hevc) {
          VCEncAddFillerNALU(inst, stat - is_hevc - 5, 1);
      }
      else if(stat <= 1 + is_hevc) {
          VCEncAddFillerNALU(inst, 0, 0);
          vcenc_instance->rateControl.virtualBuffer.bucketFullness += (1 + is_hevc - stat) * 8;
          vcenc_instance->rateControl.virtualBuffer.realBitCnt += (1 + is_hevc - stat) * 8;
          vcenc_instance->rateControl.virtualBuffer.bucketLevel += (1 + is_hevc - stat) * 8;
      }
      else {
          VCEncAddFillerNALU(inst, stat - is_hevc - 1, 0);
      }

      Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
  }

  if (vcenc_instance->gdrEnabled == 1 && stat != VCENCRC_OVERFLOW)
  {
    if (vcenc_instance->gdrFirstIntraFrame != 0)
    {
      vcenc_instance->gdrFirstIntraFrame--;
    }
    if (vcenc_instance->gdrStart)
      vcenc_instance->gdrCount++;

    if (vcenc_instance->gdrCount == (vcenc_instance->gdrDuration *(1 + (i32)vcenc_instance->interlaced)))
    {
      vcenc_instance->gdrStart--;
      vcenc_instance->gdrCount = 0;
      asic->regs.rcRoiEnable = 0x00;
    }
  }

  pEncOut->nextSceneChanged = 0;

#ifdef VIDEOSTAB_ENABLED
  /* Finalize video stabilization */
  if (vcenc_instance->preProcess.videoStab)
  {
    u32 no_motion;

    VSReadStabData(vcenc_instance->asic.regs.regMirror, &vcenc_instance->vsHwData);

    no_motion = VSAlgStabilize(&vcenc_instance->vsSwData, &vcenc_instance->vsHwData);
    if (no_motion)
    {
      VSAlgReset(&vcenc_instance->vsSwData);
    }

    /* update offset after stabilization */
    VSAlgGetResult(&vcenc_instance->vsSwData, &vcenc_instance->preProcess.horOffsetSrc,
                   &vcenc_instance->preProcess.verOffsetSrc);

    /* output scene change result */
    pEncOut->nextSceneChanged = vcenc_instance->vsSwData.sceneChange;
  }
#endif

  VCEncHEVCDnfUpdate(vcenc_instance);

  /* SUFFIX SEI  */
  Jenc_StrmEncodeSuffixSei(vcenc_instance, pEncIn, pEncOut);

  vcenc_instance->encStatus = VCENCSTAT_START_FRAME;
  ret = VCENC_FRAME_READY;
  vcenc_instance->outForCutree = pic->outForCutree;

  APITRACE("Jenc_VCEncStrmEncode: OK");

out:
  pEncOut->streamSize = vcenc_instance->stream.byteCnt;
  if(VCENC_OK != Jenc_VCEncCodecPostEncodeUpdate(vcenc_instance, pEncIn, pEncOut, codingType, pic))
      return VCENC_ERROR;

  Jenc_sw_ref_cnt_decrease(pic);
  vcenc_instance->reservedCore--;
  if(vcenc_instance->pass==2) {
    ReleaseLookaheadPicture(&vcenc_instance->lookahead, outframe);
    if(ret != VCENC_FRAME_READY) {
      VCEncLookahead *lookahead = &vcenc_instance->lookahead;
      VCEncLookahead *lookahead2 = &((struct vcenc_instance *)(lookahead->priv_inst))->lookahead;
      lookahead->status = lookahead2->status = ret;
      lookahead->bFlush = true;
    }
  }

  /* Put picture back to store */
  Jenc_queue_put(&c->picture, (struct node *)pic);

  /* output the statistics data of cus. */
  pEncOut->cuStatis.intraCu8Num = vcenc_instance->asic.regs.intraCu8Num;
  pEncOut->cuStatis.skipCu8Num = vcenc_instance->asic.regs.skipCu8Num;
  pEncOut->cuStatis.PBFrame4NRdCost = vcenc_instance->asic.regs.PBFrame4NRdCost;

  return ret;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncMultiCoreFlush
    Description   : Flush remaining frames at the end of multi-core encoding.
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/


VCEncRet Jenc_VCEncMultiCoreFlush(VCEncInst inst, VCEncIn *pEncIn,
                             VCEncOut *pEncOut,
                             VCEncSliceReadyCallBackFunc sliceReadyCbFunc)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (pEncIn == NULL) || (pEncOut == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  asicData_s *asic = &vcenc_instance->asic;
  struct container *c;
  struct sw_picture *pic;
  i32 ret = VCENC_ERROR;
  VCEncSliceReady slice_callback;
  i32 i;
  u32 waitCoreJobid;

  APITRACE("Jenc_VCEncStrmEncode#");

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }
  /* Check status, INIT and ERROR not allowed */
  if ((vcenc_instance->encStatus != VCENCSTAT_START_STREAM) &&
      (vcenc_instance->encStatus != VCENCSTAT_START_FRAME))
  {
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Invalid status");
    return VCENC_INVALID_STATUS;
  }

  if(vcenc_instance->reservedCore == 0)
    return VCENC_OK;

  if (!(c = Jenc_get_container(vcenc_instance))) return VCENC_ERROR;

  /* Reset callback struct */
  vcenc_instance->stream.byteCnt = 0;
  slice_callback.slicesReadyPrev = 0;
  slice_callback.slicesReady = 0;
  slice_callback.sliceSizes = (u32 *) vcenc_instance->asic.sizeTbl[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum].virtualAddress;
  //slice_callback.sliceSizes += vcenc_instance->numNalus;
  slice_callback.nalUnitInfoNum = vcenc_instance->numNalus[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  slice_callback.nalUnitInfoNumPrev = 0;
  slice_callback.streamBufs = vcenc_instance->streamBufs[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  slice_callback.pAppData = vcenc_instance->pAppData[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];

  // picture instance switch for multi-core encoding
  pic = vcenc_instance->pic[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  waitCoreJobid = vcenc_instance->waitJobid[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  if(vcenc_instance->pass == 1)
  {
    *pEncOut = vcenc_instance->EncOut[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
    *pEncIn = vcenc_instance->EncIn[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  }
  Jenc_queue_remove(&c->picture, (struct node *)pic);
  pEncOut->numNalus = vcenc_instance->numNalus[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum];
  memcpy(&vcenc_instance->stream, &vcenc_instance->streams[(vcenc_instance->jobCnt+1) % vcenc_instance->parallelCoreNum], sizeof(struct buffer));
  pEncOut->picture_cnt = pic->picture_cnt;

  ret = Jenc_VCEncStrmWaitReady(inst, pEncIn, pEncOut,  pic,  &slice_callback, c, waitCoreJobid);

  if (ret != VCENC_OK)
    goto out;

  //set/clear picture compress flag
  pic->recon_compress.lumaCompressed = asic->regs.recon_luma_compress ? 1 : 0;
  pic->recon_compress.chromaCompressed = asic->regs.recon_chroma_compress ? 1 : 0;

  if (vcenc_instance->output_buffer_over_flow == 1)
  {
    vcenc_instance->stream.byteCnt = 0;
    pEncOut->streamSize = vcenc_instance->stream.byteCnt;
    pEncOut->numNalus = 0;
    pEncOut->pNaluSizeBuf[0] = 0;
    vcenc_instance->encStatus = VCENCSTAT_START_FRAME;
    ret = VCENC_OUTPUT_BUFFER_OVERFLOW;
    /* revert frameNum update on output buffer overflow */
    if (IS_H264(vcenc_instance->codecFormat) && pic->nalRefIdc)
      vcenc_instance->frameNum--;
    APITRACEERR("Jenc_VCEncStrmEncode: ERROR Output buffer too small");
    goto out;
  }

  i32 stat;
  {
#ifdef CTBRC_STRENGTH
    vcenc_instance->rateControl.rcPicComplexity = asic->regs.picComplexity;
    vcenc_instance->rateControl.complexity = (float)vcenc_instance->rateControl.rcPicComplexity * (vcenc_instance->rateControl.reciprocalOfNumBlk8);
#endif

    const enum slice_type _slctypes[3] = {P_SLICE, I_SLICE, B_SLICE};
    vcenc_instance->rateControl.sliceTypeCur = _slctypes[asic->regs.frameCodingType];
    stat = JencVCEncAfterPicRc(&vcenc_instance->rateControl, 0, vcenc_instance->stream.byteCnt, asic->regs.sumOfQP,asic->regs.sumOfQPNumber);

    /* After HRD overflow discard the coded frame and go back old time,
        * just like not coded frame. But if only one reference frame
        * buffer is in use we can't discard the frame unless the next frame
        * is coded as intra. */
    if (stat == VCENCRC_OVERFLOW)
    {
      vcenc_instance->stream.byteCnt = 0;

      pEncOut->numNalus = 0;
      pEncOut->pNaluSizeBuf[0] = 0;

      /* revert frameNum update on HRD overflow */
      if (IS_H264(vcenc_instance->codecFormat) && pic->nalRefIdc)
        vcenc_instance->frameNum--;
      //Jenc_queue_put(&c->picture, (struct node *)pic);
      APITRACE("Jenc_VCEncStrmEncode: OK, Frame discarded (HRD overflow)");
      //return VCENC_FRAME_READY;
    }
    else
      vcenc_instance->rateControl.sei.activated_sps = 1;
  }
#ifdef INTERNAL_TEST
  if(vcenc_instance->testId == TID_RFD) {
    Jenc_HevcRFDTest(vcenc_instance, pic);
  }
#endif
  vcenc_instance->jobCnt++;  // update frame count after one frame is ready.
  pEncOut->pNaluSizeBuf = (u32 *)vcenc_instance->asic.sizeTbl[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].virtualAddress;

  if (vcenc_instance->gdrEnabled == 1 && stat != VCENCRC_OVERFLOW)
  {
    if (vcenc_instance->gdrFirstIntraFrame != 0)
    {
      vcenc_instance->gdrFirstIntraFrame--;
    }
    if (vcenc_instance->gdrStart)
      vcenc_instance->gdrCount++;

    if (vcenc_instance->gdrCount == (vcenc_instance->gdrDuration *(1 + (i32)vcenc_instance->interlaced)))
    {
      vcenc_instance->gdrStart--;
      vcenc_instance->gdrCount = 0;
      asic->regs.rcRoiEnable = 0x00;
    }
  }

  VCEncHEVCDnfUpdate(vcenc_instance);

  vcenc_instance->encStatus = VCENCSTAT_START_FRAME;
  ret = VCENC_FRAME_READY;
  vcenc_instance->outForCutree = pic->outForCutree;

  APITRACE("Jenc_VCEncStrmEncode: OK");

out:
  Jenc_sw_ref_cnt_decrease(pic);
  vcenc_instance->reservedCore--;

  /* Put picture back to store */
  Jenc_queue_put(&c->picture, (struct node *)pic);
  pEncOut->streamSize = vcenc_instance->stream.byteCnt;
  return ret;
}
/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncFlush
    Description   : Flush remaining frames at the end of multi-core/lookahead encoding.
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncFlush(VCEncInst inst, VCEncIn *pEncIn,
                             VCEncOut *pEncOut,
                             VCEncSliceReadyCallBackFunc sliceReadyCbFunc)
{
  VCEncRet ret = VCENC_OK;
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  if(vcenc_instance->pass == 2) {
    // Lookahead flush
    ret = Jenc_VCEncStrmEncodeExt(inst,NULL,NULL,pEncOut,NULL,NULL,0);
    if(ret != VCENC_OK)
      return ret;
  }
  // Multicore flush
  if(vcenc_instance->reservedCore > 0)
    return Jenc_VCEncMultiCoreFlush(inst, pEncIn, pEncOut, sliceReadyCbFunc);

  return VCENC_OK;
}

/*------------------------------------------------------------------------------

    Function name : Jenc_VCEncStrmEnd
    Description   : Ends a stream
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : pEncIn - user provided input parameters
                    pEncOut - place where output info is returned
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncStrmEnd(VCEncInst inst, const VCEncIn *pEncIn,
                          VCEncOut *pEncOut)
{

  /* Status == INIT   Stream ended, next stream can be started */
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  APITRACE("Jenc_VCEncStrmEnd#");
  APITRACEPARAM_X("busLuma", pEncIn->busLuma);
  APITRACEPARAM_X("busChromaU", pEncIn->busChromaU);
  APITRACEPARAM_X("busChromaV", pEncIn->busChromaV);
  APITRACEPARAM("timeIncrement", pEncIn->timeIncrement);
  APITRACEPARAM_X("pOutBuf", pEncIn->pOutBuf[0]);
  APITRACEPARAM_X("busOutBuf", pEncIn->busOutBuf[0]);
  APITRACEPARAM("outBufSize", pEncIn->outBufSize[0]);
  APITRACEPARAM("codingType", pEncIn->codingType);
  APITRACEPARAM("poc", pEncIn->poc);
  APITRACEPARAM("gopSize", pEncIn->gopSize);
  APITRACEPARAM("gopPicIdx", pEncIn->gopPicIdx);
  APITRACEPARAM_X("roiMapDeltaQpAddr", pEncIn->roiMapDeltaQpAddr);


  /* Check for illegal inputs */
  if ((vcenc_instance == NULL) || (pEncIn == NULL) || (pEncOut == NULL))
  {
    APITRACEERR("Jenc_VCEncStrmEnd: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  /* Check for existing instance */
  if (vcenc_instance->inst != vcenc_instance)
  {
    APITRACEERR("Jenc_VCEncStrmEnd: ERROR Invalid instance");
    return VCENC_INSTANCE_ERROR;
  }

  /* Check status, this also makes sure that the instance is valid */
  if ((vcenc_instance->encStatus != VCENCSTAT_START_FRAME) &&
      (vcenc_instance->encStatus != VCENCSTAT_START_STREAM))
  {
    APITRACEERR("Jenc_VCEncStrmEnd: ERROR Invalid status");
    return VCENC_INVALID_STATUS;
  }

  if(vcenc_instance->pass == 1) {
    vcenc_instance->stream.stream = (u8*)vcenc_instance->lookahead.internal_mem.pOutBuf;
    vcenc_instance->stream.stream_bus = vcenc_instance->lookahead.internal_mem.busOutBuf;
    vcenc_instance->stream.size = vcenc_instance->lookahead.internal_mem.outBufSize;
  } else {
    vcenc_instance->stream.stream = (u8 *)pEncIn->pOutBuf[0];
    vcenc_instance->stream.stream_bus = pEncIn->busOutBuf[0];
    vcenc_instance->stream.size = pEncIn->outBufSize[0];
  }
  vcenc_instance->stream.cnt = &vcenc_instance->stream.byteCnt;

  pEncOut->streamSize = 0;
  vcenc_instance->stream.byteCnt = 0;

  /* Set pointer to the beginning of NAL unit size buffer */
  pEncOut->pNaluSizeBuf = (u32 *) vcenc_instance->asic.sizeTbl[0].virtualAddress;
  pEncOut->numNalus = 0;

  /* Clear the NAL unit size table */
  if (pEncOut->pNaluSizeBuf != NULL)
    pEncOut->pNaluSizeBuf[0] = 0;
  else
  {
    APITRACEERR("Jenc_VCEncStrmEnd: pNaluSizeBuf null");
    return VCENC_NULL_ARGUMENT;
  }

  Jenc_EndOfSequence(vcenc_instance, pEncIn, pEncOut);

  pEncOut->streamSize = vcenc_instance->stream.byteCnt;
  if((IS_HEVC(vcenc_instance->codecFormat) || IS_H264(vcenc_instance->codecFormat))){
      pEncOut->numNalus = 1;
      pEncOut->pNaluSizeBuf[0] = vcenc_instance->stream.byteCnt;
      pEncOut->pNaluSizeBuf[1] = 0;
  }

  if(vcenc_instance->pass==2 && vcenc_instance->lookahead.priv_inst) {
    VCEncRet ret = VCENC_OK;
    VCEncOut encOut;
    VCEncIn encIn;
    memcpy(&encIn, pEncIn, sizeof(VCEncIn));
    encIn.gopConfig.pGopPicCfg = pEncIn->gopConfig.pGopPicCfgPass1;
    ret = Jenc_VCEncStrmEnd(vcenc_instance->lookahead.priv_inst, &encIn, &encOut);
    if (ret != VCENC_OK) {
      APITRACE("Jenc_VCEncStrmEnd: LookaheadStrmEnd failed");
      return ret;
    }
  }

  /* Status == INIT   Stream ended, next stream can be started */
  vcenc_instance->encStatus = VCENCSTAT_INIT;

  APITRACE("Jenc_VCEncStrmEnd: OK");
  return VCENC_OK;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncSetError
    Description   : set error flag for thared flushing
    Return type   : NULL
------------------------------------------------------------------------------*/
void Jenc_VCEncSetError(VCEncInst inst)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  vcenc_instance->encStatus = VCENCSTAT_ERROR;
}


/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetBitsPerPixel
    Description   : Returns the amount of bits per pixel for given format.
    Return type   : u32
------------------------------------------------------------------------------*/
u32 Jenc_VCEncGetBitsPerPixel(VCEncPictureType type)
{
  switch (type)
  {
    case VCENC_YUV420_PLANAR:
    case VCENC_YVU420_PLANAR:
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
      return 12;
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444:
      return 16;
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
      return 32;
    case VCENC_YUV420_PLANAR_10BIT_I010:
    case VCENC_YUV420_PLANAR_10BIT_P010:
      return 24;
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
      return 15;
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
      return 16;
    default:
      return 0;
  }
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetAlignedStride
    Description   : Returns the stride in byte by given aligment and format.
    Return type   : u32
------------------------------------------------------------------------------*/
u32 Jenc_VCEncGetAlignedStride(int width, i32 input_format, u32 *luma_stride, u32 *chroma_stride,u32 input_alignment)
{
  return JencGetAlignedByteStride(width, input_format, luma_stride, chroma_stride, input_alignment);
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncSetTestId
    Description   : Sets the encoder configuration according to a test vector
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : testId - test vector ID
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncSetTestId(VCEncInst inst, u32 testId)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) inst;
  (void) pEncInst;
  (void) testId;

  APITRACE("Jenc_VCEncSetTestId#");

#ifdef INTERNAL_TEST
  pEncInst->testId = testId;

  APITRACE("Jenc_VCEncSetTestId# OK");
  return VCENC_OK;
#else
  /* Software compiled without testing support, return error always */
  APITRACEERR("Jenc_VCEncSetTestId# ERROR, testing disabled at compile time");
  return VCENC_ERROR;
#endif
}

/*------------------------------------------------------------------------------
  out_of_memory
------------------------------------------------------------------------------*/
i32 out_of_memory(struct vcenc_buffer *n, u32 size)
{
  return (size > n->cnt);
}

/*------------------------------------------------------------------------------
  init_buffer
------------------------------------------------------------------------------*/
i32 init_buffer(struct vcenc_buffer *vcenc_buffer,
                struct vcenc_instance *vcenc_instance)
{
  if (!vcenc_instance->temp_buffer) return NOK;
  vcenc_buffer->next   = NULL;
  vcenc_buffer->buffer = vcenc_instance->temp_buffer;
  vcenc_buffer->cnt    = vcenc_instance->temp_size;
  vcenc_buffer->busaddr = vcenc_instance->temp_bufferBusAddress;
  return OK;
}

/*------------------------------------------------------------------------------
  get_buffer
------------------------------------------------------------------------------*/
i32 get_buffer(struct buffer *buffer, struct vcenc_buffer *source, i32 size,
               i32 reset)
{
  struct vcenc_buffer *vcenc_buffer;

  if (size < 0) return NOK;
  memset(buffer, 0, sizeof(struct buffer));

  /* New vcenc_buffer node */
  if (out_of_memory(source, sizeof(struct vcenc_buffer))) return NOK;
  vcenc_buffer = (struct vcenc_buffer *)source->buffer;
  if (reset) memset(vcenc_buffer, 0, sizeof(struct vcenc_buffer));
  source->buffer += sizeof(struct vcenc_buffer);
  source->busaddr += sizeof(struct vcenc_buffer);
  source->cnt    -= sizeof(struct vcenc_buffer);

  /* Connect previous vcenc_buffer node */
  if (source->next) source->next->next = vcenc_buffer;
  source->next = vcenc_buffer;

  /* Map internal buffer and user space vcenc_buffer, NOTE that my chunk
   * size is sizeof(struct vcenc_buffer) */
  size = (size / sizeof(struct vcenc_buffer)) * sizeof(struct vcenc_buffer);
  if (out_of_memory(source, size)) return NOK;
  vcenc_buffer->buffer = source->buffer;
  vcenc_buffer->busaddr = source->busaddr;
  buffer->stream      = source->buffer;
  buffer->stream_bus  = source->busaddr;
  buffer->size        = size;
  buffer->cnt         = &vcenc_buffer->cnt;
  source->buffer     += size;
  source->busaddr    += size;
  source->cnt        -= size;

  return OK;
}

/*------------------------------------------------------------------------------
  vcenc_set_ref_pic_set
------------------------------------------------------------------------------*/
i32 vcenc_set_ref_pic_set(struct vcenc_instance *vcenc_instance)
{
  struct container *c;
  struct vcenc_buffer source;
  struct rps *r;

  if (!(c = Jenc_get_container(vcenc_instance))) return NOK;

  /* Create new reference picture set */
  if (!(r = (struct rps *)Jenc_create_parameter_set(RPS))) return NOK;

  /* We will read vcenc_instance->buffer */
  if (init_buffer(&source, vcenc_instance)) goto out;
  if (get_buffer(&r->ps.b, &source, RPS_SET_BUFF_SIZE, HANTRO_FALSE)) goto out;

  /* Initialize parameter set id */
  r->ps.id = vcenc_instance->rps_id;
  r->sps_id = vcenc_instance->sps_id;

  if (Jenc_set_reference_pic_set(r)) goto out;

  /* Replace old reference picture set with new one */
  Jenc_remove_parameter_set(c, RPS, vcenc_instance->rps_id);
  Jenc_queue_put(&c->parameter_set, (struct node *)r);

  return OK;

out:
  Jenc_free_parameter_set((struct ps *)r);
  return NOK;
}


/*------------------------------------------------------------------------------
  vcenc_ref_pic_sets
------------------------------------------------------------------------------*/
i32 vcenc_ref_pic_sets(struct vcenc_instance *vcenc_instance, const VCEncIn *pEncIn)
{
  struct vcenc_buffer *vcenc_buffer;
  const VCEncGopConfig *gopCfg;
  i32 *poc;
  i32 rps_id = 0;

  /* Initialize tb->instance->buffer so that we can cast it to vcenc_buffer
   * by calling hevc_set_parameter(), see api.c TODO...*/
  vcenc_instance->rps_id = -1;
  vcenc_set_ref_pic_set(vcenc_instance);
  vcenc_buffer = (struct vcenc_buffer *)vcenc_instance->temp_buffer;
  poc = (i32 *)vcenc_buffer->buffer;

  gopCfg = &pEncIn->gopConfig;

  //RPS based on user GOP configuration
  int i, j;
  rps_id = 0;

  for (i = 0; i < gopCfg->size; i ++)
  {
    VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[i]);
    u32 iRefPic, idx = 0;
    for (iRefPic = 0; iRefPic < cfg->numRefPics; iRefPic ++)
    {
        if (IS_LONG_TERM_REF_DELTAPOC(cfg->refPics[iRefPic].ref_pic))
            continue;
        poc[idx++] = cfg->refPics[iRefPic].ref_pic;
        poc[idx++] = cfg->refPics[iRefPic].used_by_cur;
    }
    for (j = 0; j <gopCfg->ltrcnt; j++)
    {
        poc[idx++] = gopCfg->u32LTR_idx[j];
        poc[idx++] = 0;
    }
    poc[idx] = 0; //end
    vcenc_instance->rps_id = rps_id;
    if (vcenc_set_ref_pic_set(vcenc_instance))
    {
      Jenc_Error(2, ERR, "vcenc_set_ref_pic_set() fails");
      return NOK;
    }
    rps_id++;
  }

  if (0 != gopCfg->special_size) {//
      for (i = 0; i < gopCfg->special_size; i++)
      {
          VCEncGopPicSpecialConfig *cfg = &(gopCfg->pGopPicSpecialCfg[i]);
          u32 iRefPic, idx = 0;
          if (((i32)cfg->numRefPics) != NUMREFPICS_RESERVED)
          {
              for (iRefPic = 0; iRefPic < cfg->numRefPics; iRefPic++)
              {
                  if (IS_LONG_TERM_REF_DELTAPOC(cfg->refPics[iRefPic].ref_pic))
                      continue;
                  poc[idx++] = cfg->refPics[iRefPic].ref_pic;
                  poc[idx++] = cfg->refPics[iRefPic].used_by_cur;
              }
          }

          // add LTR idx to default GOP setting auto loaded
          for (j = 0; j < gopCfg->ltrcnt; j++)
          {
              poc[idx++] = gopCfg->u32LTR_idx[j];
              poc[idx++] = 0;
          }
          poc[idx] = 0; //end
          vcenc_instance->rps_id = rps_id;
          if (vcenc_set_ref_pic_set(vcenc_instance))
          {
              Jenc_Error(2, ERR, "vcenc_set_ref_pic_set() fails");
              return NOK;
          }
          rps_id++;
      }
  }

  //add some special RPS configuration
  //P frame for sequence starting
  poc[0] = -1;
  poc[1] = 1;
  for (i = 1; i <gopCfg->ltrcnt; i++)
  {
      poc[2 * i] = gopCfg->u32LTR_idx[i-1];
      poc[2 * i + 1] = 0;
  }
  poc[2 * i] = 0;

  vcenc_instance->rps_id = rps_id;
  if (vcenc_set_ref_pic_set(vcenc_instance))
  {
    Jenc_Error(2, ERR, "vcenc_set_ref_pic_set() fails");
    return NOK;
  }
  rps_id++;
  //Intra
  for (i  = 0; i <gopCfg->ltrcnt; i++)
  {
      poc[2*i]     = gopCfg->u32LTR_idx[i];
      poc[2 * i+1] = 0;
  }
  poc[2 * i] = 0;

  vcenc_instance->rps_id = rps_id;
  if (vcenc_set_ref_pic_set(vcenc_instance))
  {
    Jenc_Error(2, ERR, "vcenc_set_ref_pic_set() fails");
    return NOK;
  }
  return OK;
}

/*------------------------------------------------------------------------------
  Jenc_vcenc_get_ref_pic_set
------------------------------------------------------------------------------*/
i32 Jenc_vcenc_get_ref_pic_set(struct vcenc_instance *vcenc_instance)
{
  struct container *c;
  struct vcenc_buffer source;
  struct ps *p;

  if (!(c = Jenc_get_container(vcenc_instance))) return NOK;
  if (!(p = Jenc_get_parameter_set(c, RPS, vcenc_instance->rps_id))) return NOK;
  if (init_buffer(&source, vcenc_instance)) return NOK;
  if (get_buffer(&p->b, &source, PRM_SET_BUFF_SIZE, HANTRO_TRUE)) return NOK;
  if (Jenc_get_reference_pic_set((struct rps *)p)) return NOK;

  return OK;
}

u32 Jenc_VCEncGetRoiMapVersion(u32 core_id, void *ctx)
{
  JENC_EWLHwConfig_t cfg = JencEWLReadAsicConfig(core_id, ctx);

  return cfg.roiMapVersion;
}

/*------------------------------------------------------------------------------

    VCEncCheckCfg

    Function checks that the configuration is valid.

    Input   pEncCfg Pointer to configuration structure.

    Return  ENCHW_OK      The configuration is valid.
            ENCHW_NOK     Some of the parameters in configuration are not valid.

------------------------------------------------------------------------------*/
bool_e VCEncCheckCfg(const VCEncConfig *pEncCfg, void *ctx)
{
  i32 height = pEncCfg->height;
  u32 client_type;

  ASSERT(pEncCfg);

  if ((pEncCfg->streamType != VCENC_BYTE_STREAM) &&
      (pEncCfg->streamType != VCENC_NAL_UNIT_STREAM))
  {
    APITRACEERR("VCEncCheckCfg: Invalid stream type");
    return ENCHW_NOK;
  }

/* Supported codec check */
#ifndef SUPPORT_HEVC
  if(IS_HEVC(pEncCfg->codecFormat))
  {
    APITRACEERR("VCEncCheckCfg: codecFormat=hevc not supported.");
    return ENCHW_NOK;
  }
#endif
#ifndef SUPPORT_H264
  if(IS_H264(pEncCfg->codecFormat))
  {
    APITRACEERR("VCEncCheckCfg: codecFormat=h264 not supported.");
    return ENCHW_NOK;
  }
#endif
#ifndef SUPPORT_AV1
  if(IS_AV1(pEncCfg->codecFormat))
  {
    APITRACEERR("VCEncCheckCfg: codecFormat=av1 not supported.");
    return ENCHW_NOK;
  }
#endif
#ifndef SUPPORT_VP9
  if(IS_VP9(pEncCfg->codecFormat))
  {
    APITRACEERR("VCEncCheckCfg: codecFormat=vp9 not supported.");
    return ENCHW_NOK;
  }
#endif

  if (IS_AV1(pEncCfg->codecFormat) || IS_VP9(pEncCfg->codecFormat)) {
    if (pEncCfg->streamType != VCENC_BYTE_STREAM)
    {
      APITRACEERR("VCEncCheckCfg: Invalid stream type, need byte stream when AV1 or VP9");
      return ENCHW_NOK;
    }

    if (IS_AV1(pEncCfg->codecFormat))
    {
      if (pEncCfg->width > VCENC_AV1_MAX_ENC_WIDTH)
      {
        APITRACEERR("VCEncCheckCfg: Invalid width, need 4096 or smaller when AV1");
        return ENCHW_NOK;
      }

      if (pEncCfg->width*pEncCfg->height > VCENC_AV1_MAX_ENC_AREA)
      {
        APITRACEERR("VCEncCheckCfg: Invalid area, need 4096*2304 or below when AV1");
        return ENCHW_NOK;
      }
    }
    else
    {
      /* In the VP9's spec, the picture's width should not be larger than 8384,
      * but when only ONE tile, the picture's width should NOT be larger than 4096.
      */
      if (pEncCfg->width > VCENC_VP9_MAX_ENC_WIDTH)
      {
        APITRACEERR("VCEncCheckCfg: Invalid width, need 4096 or smaller when only one tile in the VP9");
        return ENCHW_NOK;
      }
      else if (pEncCfg->height > VCENC_VP9_MAX_ENC_HEIGHT)
      {
        APITRACEERR("VCEncCheckCfg: Invalid height, need 8384 or smaller when VP9");
        return ENCHW_NOK;
      }

      if (pEncCfg->width*pEncCfg->height > VCENC_VP9_MAX_ENC_AREA)
      {
        APITRACEERR("VCEncCheckCfg: Invalid picture size, need 4096*2176 or below when VP9");
        return ENCHW_NOK;
      }
    }
  }

  /* Encoded image width limits, multiple of 2 */
  if (pEncCfg->width < VCENC_MIN_ENC_WIDTH ||
      pEncCfg->width > VCENC_MAX_ENC_WIDTH || (pEncCfg->width & 0x1) != 0)
  {
    APITRACEERR("VCEncCheckCfg: Invalid width");
    return ENCHW_NOK;
  }

  /* Encoded image height limits, multiple of 2 */
  if (height < VCENC_MIN_ENC_HEIGHT ||
      height > VCENC_MAX_ENC_HEIGHT_EXT || (height & 0x1) != 0)
  {
    APITRACEERR("VCEncCheckCfg: Invalid height");
    return ENCHW_NOK;
  }

  /* Check frame rate */
  if (pEncCfg->frameRateNum < 1 || pEncCfg->frameRateNum > ((1 << 20) - 1))
  {
    APITRACEERR("VCEncCheckCfg: Invalid frameRateNum");
    return ENCHW_NOK;
  }

  if (pEncCfg->frameRateDenom < 1)
  {
    APITRACEERR("VCEncCheckCfg: Invalid frameRateDenom");
    return ENCHW_NOK;
  }

  /* check profile */
  {
    client_type = VCEncGetClientType(pEncCfg->codecFormat);
    if ((IS_HEVC(pEncCfg->codecFormat) && ((pEncCfg->profile > VCENC_HEVC_MAINREXT) ||
        ((i32)pEncCfg->profile < VCENC_HEVC_MAIN_PROFILE) ||
        (((HW_ID_MAJOR_NUMBER(JencEncAsicGetAsicHWid(client_type, ctx))) < 4) && (pEncCfg->profile == VCENC_HEVC_MAIN_10_PROFILE)))) ||
        (IS_H264(pEncCfg->codecFormat) && (pEncCfg->profile > VCENC_H264_HIGH_10_PROFILE || pEncCfg->profile < VCENC_H264_BASE_PROFILE)))
    {
      APITRACEERR("VCEncCheckCfg: Invalid profile");
      return ENCHW_NOK;
    }
  }

  /* check bit depth for main8 and main still profile */
  if (pEncCfg->profile < (IS_H264(pEncCfg->codecFormat) ? VCENC_H264_HIGH_10_PROFILE : VCENC_HEVC_MAIN_10_PROFILE)
      && (pEncCfg->bitDepthLuma != 8 || pEncCfg->bitDepthChroma != 8) && (IS_HEVC(pEncCfg->codecFormat) || IS_H264(pEncCfg->codecFormat)))
  {
    APITRACEERR("VCEncCheckCfg: Invalid bit depth for the profile");
    return ENCHW_NOK;
  }

  if (pEncCfg->codedChromaIdc > VCENC_CHROMA_IDC_420)
  {
    APITRACEERR("VCEncCheckCfg: Invalid codedChromaIdc, it's should be 0 ~ 1");
    return ENCHW_NOK;
  }

  /* check bit depth for main10 profile */
  if ((pEncCfg->profile == VCENC_HEVC_MAIN_10_PROFILE || pEncCfg->profile == VCENC_H264_HIGH_10_PROFILE)
      && (pEncCfg->bitDepthLuma < 8  || pEncCfg->bitDepthLuma > 10
          || pEncCfg->bitDepthChroma < 8 || pEncCfg->bitDepthChroma > 10))
  {
    APITRACEERR("VCEncCheckCfg: Invalid bit depth for main10 profile");
    return ENCHW_NOK;
  }


  /* check level, if the level==0, don't check. */
  if (((IS_HEVC(pEncCfg->codecFormat) && ((pEncCfg->level > VCENC_HEVC_MAX_LEVEL) ||
      (pEncCfg->level < VCENC_HEVC_LEVEL_1))) ||
      (IS_H264(pEncCfg->codecFormat) && ((pEncCfg->level > VCENC_H264_MAX_LEVEL) ||
      (pEncCfg->level < VCENC_H264_LEVEL_1)))) && (pEncCfg->level != 0))
  {
    APITRACEERR("VCEncCheckCfg: Invalid level");
    return ENCHW_NOK;
  }

  if (((i32)pEncCfg->tier > (i32)VCENC_HEVC_HIGH_TIER) || ((i32)pEncCfg->tier < (i32)VCENC_HEVC_MAIN_TIER))
  {
    APITRACEERR("VCEncCheckCfg: Invalid tier");
    return ENCHW_NOK;
  }

  if ((pEncCfg->tier == VCENC_HEVC_HIGH_TIER) && (IS_H264(pEncCfg->codecFormat) || pEncCfg->level < VCENC_HEVC_LEVEL_4))
  {
    APITRACEERR("VCEncCheckCfg: Invalid codec/level for chosen tier");
    return ENCHW_NOK;
  }

  if (pEncCfg->refFrameAmount > VCENC_MAX_REF_FRAMES)
  {
    APITRACEERR("VCEncCheckCfg: Invalid refFrameAmount");
    return ENCHW_NOK;
  }

  if ((pEncCfg->exp_of_input_alignment<4&&pEncCfg->exp_of_input_alignment>0)||
      (pEncCfg->exp_of_ref_alignment<4&&pEncCfg->exp_of_ref_alignment>0)||
      (pEncCfg->exp_of_ref_ch_alignment<4&&pEncCfg->exp_of_ref_ch_alignment>0))
  {
    APITRACEERR("VCEncCheckCfg: Invalid alignment value");
    return ENCHW_NOK;
  }

  if (IS_H264(pEncCfg->codecFormat) && (pEncCfg->picOrderCntType != 2 && (pEncCfg->picOrderCntType != 0)))
  {
    APITRACEERR("VCEncCheckCfg: H264 POCCntType support 0 or 2");
    return ENCHW_NOK;
  }

  JENC_EWLHwConfig_t cfg = JencEncAsicGetAsicConfig(client_type,ctx);
  /* is HEVC encoding supported */
  if (IS_HEVC(pEncCfg->codecFormat) && cfg.hevcEnabled == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
  APITRACEERR("VCEncCheckCfg: Invalid format, hevc not supported by HW coding core");
  return ENCHW_NOK;
  }

  /* is H264 encoding supported */
  if (IS_H264(pEncCfg->codecFormat) && cfg.h264Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
  APITRACEERR("VCEncCheckCfg: Invalid format, h264 not supported by HW coding core");
  return ENCHW_NOK;
  }

  /* is AV1 encoding supported */
  if (IS_AV1(pEncCfg->codecFormat) && cfg.av1Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
    APITRACEERR("VCEncCheckCfg: Invalid format, av1 not supported by HW coding core");
    return ENCHW_NOK;
  }

  /* is AV1 encoding supported */
  if (IS_VP9(pEncCfg->codecFormat) && cfg.vp9Enabled == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
    APITRACEERR("VCEncCheckCfg: Invalid format, VP9 not supported by HW coding core");
    return ENCHW_NOK;
  }

  if((cfg.cuInforVersion == 0x07) && pEncCfg->enableOutputCuInfo) {
    APITRACEERR("VCEncCheckCfg: Invalid enableOutputCuInfo, not supported by HW coding core");
    return ENCHW_NOK;
  }

  /* max width supported */
  if ((IS_H264(pEncCfg->codecFormat) ? cfg.maxEncodedWidthH264 : cfg.maxEncodedWidthHEVC) < pEncCfg->width)
  {
  APITRACEERR("VCEncCheckCfg: Invalid width, not supported by HW coding core");
  return ENCHW_NOK;
  }

  /* P010 Ref format */
  if (pEncCfg->P010RefEnable && cfg.P010RefSupport == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
  APITRACEERR("VCEncCheckCfg: Invalid format, P010Ref not supported by HW coding core");
  return ENCHW_NOK;
  }

  /*extend video coding height */
  if ((height > VCENC_MAX_ENC_HEIGHT) && (cfg.videoHeightExt == EWL_HW_CONFIG_NOT_SUPPORTED))
  {
  APITRACEERR("VCEncCheckCfg: Invalid height, height extension not supported by HW coding core");
  return ENCHW_NOK;
  }

  /*disable recon write to DDR*/
  if (pEncCfg->writeReconToDDR == 0 && cfg.disableRecWtSupport == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
  APITRACEERR("VCEncCheckCfg: disable recon write to DDR not supported by HW coding core");
  return ENCHW_NOK;
  }

  /* Check ctb bits  */
  if(pEncCfg->enableOutputCtbBits && cfg.CtbBitsOutSupport == EWL_HW_CONFIG_NOT_SUPPORTED)
  {
    APITRACEERR("VCEncCheckCfg: ctb output encoded bits not supported by HW coding core");
    return ENCHW_NOK;
  }

  if (pEncCfg->tune > VCENC_TUNE_SHARP_VISUAL)
  {
    APITRACEERR("VCEncCheckCfg: INVALID tune, it should be within [0..3]");
    return ENCHW_NOK;
  }

  return ENCHW_OK;
}

static i32 getLevelIdx(VCEncVideoCodecFormat codecFormat, VCEncLevel level)
{
  switch(codecFormat)
  {
    case VCENC_VIDEO_CODEC_HEVC:
      return getlevelIdxHevc( level );

    case VCENC_VIDEO_CODEC_H264:
      return getlevelIdxH264( level );

    case VCENC_VIDEO_CODEC_AV1:
      return CLIP3(0, AV1_VALID_MAX_LEVEL-1, (i32)level);

    case VCENC_VIDEO_CODEC_VP9:
      return CLIP3(0, VP9_VALID_MAX_LEVEL-1, (i32)level);

    default:
      ASSERT(0);
  }

  return -1;
}

static i32 getlevelIdxHevc(VCEncLevel level)
{
  switch (level)
  {
    case VCENC_HEVC_LEVEL_1:
      return 0;
    case VCENC_HEVC_LEVEL_2:
      return 1;
    case VCENC_HEVC_LEVEL_2_1:
      return 2;
    case VCENC_HEVC_LEVEL_3:
      return 3;
    case VCENC_HEVC_LEVEL_3_1:
      return 4;
    case VCENC_HEVC_LEVEL_4:
      return 5;
    case VCENC_HEVC_LEVEL_4_1:
      return 6;
    case VCENC_HEVC_LEVEL_5:
      return 7;
    case VCENC_HEVC_LEVEL_5_1:
      return 8;
    case VCENC_HEVC_LEVEL_5_2:
      return 9;
    case VCENC_HEVC_LEVEL_6:
      return 10;
    case VCENC_HEVC_LEVEL_6_1:
      return 11;
    case VCENC_HEVC_LEVEL_6_2:
      return 12;
    default:
      ASSERT(0);
  }
  return 0;
}
static i32 getlevelIdxH264(VCEncLevel level)
{
  switch (level)
  {
    case VCENC_H264_LEVEL_1:
      return 0;
    case VCENC_H264_LEVEL_1_b:
      return 1;
    case VCENC_H264_LEVEL_1_1:
      return 2;
    case VCENC_H264_LEVEL_1_2:
      return 3;
    case VCENC_H264_LEVEL_1_3:
      return 4;
    case VCENC_H264_LEVEL_2:
      return 5;
    case VCENC_H264_LEVEL_2_1:
      return 6;
    case VCENC_H264_LEVEL_2_2:
      return 7;
    case VCENC_H264_LEVEL_3:
      return 8;
    case VCENC_H264_LEVEL_3_1:
      return 9;
    case VCENC_H264_LEVEL_3_2:
      return 10;
    case VCENC_H264_LEVEL_4:
      return 11;
    case VCENC_H264_LEVEL_4_1:
      return 12;
    case VCENC_H264_LEVEL_4_2:
      return 13;
    case VCENC_H264_LEVEL_5:
      return 14;
    case VCENC_H264_LEVEL_5_1:
      return 15;
    case VCENC_H264_LEVEL_5_2:
      return 16;
    case VCENC_H264_LEVEL_6:
      return 17;
    case VCENC_H264_LEVEL_6_1:
      return 18;
    case VCENC_H264_LEVEL_6_2:
      return 19;
    default:
      ASSERT(0);
  }
  return 0;
}

static VCEncLevel getLevelHevc(i32 levelIdx)
{
  switch (levelIdx)
  {
    /*Hevc*/
    case 0:
      return VCENC_HEVC_LEVEL_1;
    case 1:
      return VCENC_HEVC_LEVEL_2;
    case 2:
      return VCENC_HEVC_LEVEL_2_1;
    case 3:
      return VCENC_HEVC_LEVEL_3;
    case 4:
      return VCENC_HEVC_LEVEL_3_1;
    case 5:
      return VCENC_HEVC_LEVEL_4;
    case 6:
      return VCENC_HEVC_LEVEL_4_1;
    case 7:
      return VCENC_HEVC_LEVEL_5;
    case 8:
      return VCENC_HEVC_LEVEL_5_1;
    case 9:
      return VCENC_HEVC_LEVEL_5_2;
    case 10:
      return VCENC_HEVC_LEVEL_6;
    case 11:
      return VCENC_HEVC_LEVEL_6_1;
    default:
      return VCENC_HEVC_LEVEL_6_2;
  }
}

static VCEncLevel getLevelH264(i32 levelIdx)
{
  switch (levelIdx)
  {
    case 0:
      return VCENC_H264_LEVEL_1;
    case 1:
      return VCENC_H264_LEVEL_1_b;
    case 2:
      return VCENC_H264_LEVEL_1_1;
    case 3:
      return VCENC_H264_LEVEL_1_2;
    case 4:
      return VCENC_H264_LEVEL_1_3;
    case 5:
      return VCENC_H264_LEVEL_2;
    case 6:
      return VCENC_H264_LEVEL_2_1;
    case 7:
      return VCENC_H264_LEVEL_2_2;
    case 8:
      return VCENC_H264_LEVEL_3;
    case 9:
      return VCENC_H264_LEVEL_3_1;
    case 10:
      return VCENC_H264_LEVEL_3_2;
    case 11:
      return VCENC_H264_LEVEL_4;
    case 12:
      return VCENC_H264_LEVEL_4_1;
    case 13:
      return VCENC_H264_LEVEL_4_2;
    case 14:
      return VCENC_H264_LEVEL_5;
    case 15:
      return VCENC_H264_LEVEL_5_1;
    case 16:
      return VCENC_H264_LEVEL_5_2;
    case 17:
      return VCENC_H264_LEVEL_6;
    case 18:
      return VCENC_H264_LEVEL_6_1;
    default:
      return VCENC_H264_LEVEL_6_2;
  }
}

static VCEncLevel getLevel(VCEncVideoCodecFormat codecFormat, i32 levelIdx)
{
  switch(codecFormat)
  {
    case VCENC_VIDEO_CODEC_HEVC:
      return getLevelHevc( levelIdx );

    case VCENC_VIDEO_CODEC_H264:
      return getLevelH264( levelIdx );

    case VCENC_VIDEO_CODEC_AV1:
      return (u32)CLIP3(0, AV1_VALID_MAX_LEVEL-1, levelIdx);

    case VCENC_VIDEO_CODEC_VP9:
      return (u32)CLIP3(0, VP9_VALID_MAX_LEVEL-1, levelIdx);

    default:
      ASSERT(0);
  }
  return -1;
}
static VCEncLevel calculate_level(const VCEncConfig *pEncCfg)
{
    u32 sample_per_picture = pEncCfg->width * pEncCfg->height;
    u64 sample_per_second = sample_per_picture * pEncCfg->frameRateNum / pEncCfg->frameRateDenom;
    i32 i = 0, j = 0, leveIdx = 0;
    i32 maxLevel = 0;
    switch(pEncCfg->codecFormat)
    {
      case VCENC_VIDEO_CODEC_HEVC:
        maxLevel = HEVC_LEVEL_NUM - 1;
        break;
      case VCENC_VIDEO_CODEC_H264:
        maxLevel = H264_LEVEL_NUM - 1;
        break;

      case VCENC_VIDEO_CODEC_AV1:
        maxLevel = AV1_VALID_MAX_LEVEL - 1;
        break;

      case VCENC_VIDEO_CODEC_VP9:
        maxLevel = VP9_VALID_MAX_LEVEL - 1;
        break;

      default:
        break;
    }

    if(sample_per_picture >  getMaxPicSize(pEncCfg->codecFormat, maxLevel) || sample_per_second > getMaxSBPS(pEncCfg->codecFormat, maxLevel))
    {
      APITRACEERR("calculate_level: WARNING Invalid parameter.");
      i = j = maxLevel;
    }
    for(i = 0; i < maxLevel; i++)
    {
      if(sample_per_picture <= getMaxPicSize(pEncCfg->codecFormat, i))
        break;
    }
    for(j = 0; j < maxLevel; j++)
    {
      if(sample_per_second <= getMaxSBPS(pEncCfg->codecFormat, j))
        break;
    }

    leveIdx = MAX(i, j);
    return (getLevel(pEncCfg->codecFormat, leveIdx));
}
/*------------------------------------------------------------------------------

    SetParameter

    Set all parameters in instance to valid values depending on user config.

------------------------------------------------------------------------------*/
bool_e SetParameter(struct vcenc_instance *inst, const VCEncConfig   *pEncCfg)
{
  i32 width, height, bps;
  JENC_EWLHwConfig_t cfg;
  int ctb_size;
  true_e bCorrectProfile;

  ASSERT(inst);

  //inst->width = pEncCfg->width;
  //inst->height = pEncCfg->height;

  inst->codecFormat = pEncCfg->codecFormat;
  ctb_size = (IS_H264(inst->codecFormat) ? 16 : 64);
  /* Internal images, next macroblock boundary */
  width = ctb_size * ((inst->width + ctb_size - 1) / ctb_size);
  height = ctb_size * ((inst->height + ctb_size - 1) / ctb_size);

  /* stream type */
  if (pEncCfg->streamType == VCENC_BYTE_STREAM)
  {
    inst->asic.regs.streamMode = ASIC_VCENC_BYTE_STREAM;
    //        inst->rateControl.sei.byteStream = ENCHW_YES;
  }
  else
  {
    inst->asic.regs.streamMode = ASIC_VCENC_NAL_UNIT;
    //        inst->rateControl.sei.byteStream = ENCHW_NO;
  }
  if ((IS_AV1(pEncCfg->codecFormat) || IS_VP9(pEncCfg->codecFormat)) && pEncCfg->streamType != VCENC_BYTE_STREAM) {
    APITRACEERR("WARNING: AV1 and VP9 only supports byte stream mode");
    inst->asic.regs.streamMode = ASIC_VCENC_BYTE_STREAM;
    //        inst->rateControl.sei.byteStream = ENCHW_YES;
  }

  /* ctb */
  inst->ctbPerRow = width / ctb_size;
  inst->ctbPerCol = height / ctb_size;
  inst->ctbPerFrame = inst->ctbPerRow * inst->ctbPerCol;


  /* Disable intra and ROI areas by default */
  inst->asic.regs.intraAreaTop  = inst->asic.regs.intraAreaBottom = INVALID_POS;
  inst->asic.regs.intraAreaLeft = inst->asic.regs.intraAreaRight  = INVALID_POS;

  inst->asic.regs.roi1Top  = inst->asic.regs.roi1Bottom           = INVALID_POS;
  inst->asic.regs.roi1Left = inst->asic.regs.roi1Right            = INVALID_POS;
  inst->asic.regs.roi2Top  = inst->asic.regs.roi2Bottom           = INVALID_POS;
  inst->asic.regs.roi2Left = inst->asic.regs.roi2Right            = INVALID_POS;
  inst->asic.regs.roi3Top  = inst->asic.regs.roi3Bottom           = INVALID_POS;
  inst->asic.regs.roi3Left = inst->asic.regs.roi3Right            = INVALID_POS;
  inst->asic.regs.roi4Top  = inst->asic.regs.roi4Bottom           = INVALID_POS;
  inst->asic.regs.roi4Left = inst->asic.regs.roi4Right            = INVALID_POS;
  inst->asic.regs.roi5Top  = inst->asic.regs.roi5Bottom           = INVALID_POS;
  inst->asic.regs.roi5Left = inst->asic.regs.roi5Right            = INVALID_POS;
  inst->asic.regs.roi6Top  = inst->asic.regs.roi6Bottom           = INVALID_POS;
  inst->asic.regs.roi6Left = inst->asic.regs.roi6Right            = INVALID_POS;
  inst->asic.regs.roi7Top  = inst->asic.regs.roi7Bottom           = INVALID_POS;
  inst->asic.regs.roi7Left = inst->asic.regs.roi7Right            = INVALID_POS;
  inst->asic.regs.roi8Top  = inst->asic.regs.roi8Bottom           = INVALID_POS;
  inst->asic.regs.roi8Left = inst->asic.regs.roi8Right            = INVALID_POS;

  /* Disable IPCM areas by default */
  inst->asic.regs.ipcm1AreaTop  = inst->asic.regs.ipcm1AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm1AreaLeft = inst->asic.regs.ipcm1AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm2AreaTop  = inst->asic.regs.ipcm2AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm2AreaLeft = inst->asic.regs.ipcm2AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm3AreaTop  = inst->asic.regs.ipcm3AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm3AreaLeft = inst->asic.regs.ipcm3AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm4AreaTop  = inst->asic.regs.ipcm4AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm4AreaLeft = inst->asic.regs.ipcm4AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm5AreaTop  = inst->asic.regs.ipcm5AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm5AreaLeft = inst->asic.regs.ipcm5AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm6AreaTop  = inst->asic.regs.ipcm6AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm6AreaLeft = inst->asic.regs.ipcm6AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm7AreaTop  = inst->asic.regs.ipcm7AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm7AreaLeft = inst->asic.regs.ipcm7AreaRight  = INVALID_POS;
  inst->asic.regs.ipcm8AreaTop  = inst->asic.regs.ipcm8AreaBottom = INVALID_POS;
  inst->asic.regs.ipcm8AreaLeft = inst->asic.regs.ipcm8AreaRight  = INVALID_POS;

  /* Slice num */
  inst->asic.regs.sliceSize = 0;
  inst->asic.regs.sliceNum = 1;

  /* compressor */
  inst->asic.regs.recon_luma_compress = (pEncCfg->compressor & 1) ? 1 : 0;
   inst->asic.regs.recon_chroma_compress = ((pEncCfg->compressor & 2)&&(!(( VCENC_CHROMA_IDC_400 == pEncCfg->codedChromaIdc) && (inst->asic.regs.asicCfg.MonoChromeSupport == EWL_HW_CONFIG_ENABLED)))) ? 1 : 0;

  /* CU Info output*/
  inst->asic.regs.enableOutputCuInfo = pEncCfg->enableOutputCuInfo;
  /* Check cuinfo version */
  if (((i32)inst->asic.regs.asicCfg.cuInforVersion < pEncCfg->cuInfoVersion) ||
     (pEncCfg->cuInfoVersion == 0 && inst->asic.regs.asicCfg.cuInforVersion != 0))
  {
    printf("CuInfoVersion %d is not supported\n", pEncCfg->cuInfoVersion);
    return ENCHW_NOK;
  }
  if(inst->asic.regs.asicCfg.cuInforVersion >= 2)
  {
    /* HW IM only support cuinfo version 2; SW cutree only support cuinfo version 1 */
    if (pEncCfg->pass == 1)
      inst->asic.regs.cuInfoVersion = inst->asic.regs.asicCfg.bMultiPassSupport ?
                                      inst->asic.regs.asicCfg.cuInforVersion : 1;
    else
      inst->asic.regs.cuInfoVersion = pEncCfg->cuInfoVersion != -1 ? pEncCfg->cuInfoVersion : 1;
  }
  else
    inst->asic.regs.cuInfoVersion = inst->asic.regs.asicCfg.cuInforVersion;

  /* Ctb encoded bits output */
  inst->asic.regs.enableOutputCtbBits = pEncCfg->enableOutputCtbBits && pEncCfg->pass != 1;

  /* Sequence parameter set */
  inst->bAutoLevel = false;
  if(pEncCfg->level == 0)
  {
    inst->level = calculate_level(pEncCfg);
    inst->bAutoLevel = true;
    if(inst->level == -1)
    {
      return ENCHW_NOK;
    }
  }
  else
  {
    inst->level = pEncCfg->level;
  }

  inst->levelIdx = getLevelIdx(inst->codecFormat, inst->level);
  inst->tier = pEncCfg->tier;

  /* RDO effort level */
  inst->rdoLevel = inst->asic.regs.rdoLevel = pEncCfg->rdoLevel;

  inst->asic.regs.codedChromaIdc = (inst->asic.regs.asicCfg.MonoChromeSupport == EWL_HW_CONFIG_NOT_SUPPORTED) ? VCENC_CHROMA_IDC_420: pEncCfg->codedChromaIdc;
  bCorrectProfile   = ( VCENC_CHROMA_IDC_400 == pEncCfg->codedChromaIdc) && (inst->asic.regs.asicCfg.MonoChromeSupport == EWL_HW_CONFIG_ENABLED);
  switch (pEncCfg->profile)
  {
    case 0:
      //main profile
      inst->profile = bCorrectProfile ? 4:1;
      break;
    case 1:
      //main still picture profile.
      inst->profile = 3;
      break;
    case 2:
      //main 10 profile.
      inst->profile = bCorrectProfile ? 4:2;
      break;
    case 3:
      //main ext profile.
      inst->profile = bCorrectProfile ? 4:2;
      break;
    case 9:
      //H.264 baseline profile
      inst->profile = bCorrectProfile ? 100:66;
      break;
    case 10:
      //H.264 main profile
      inst->profile = bCorrectProfile ? 100:77;
      break;
    case 11:
      //H.264 high profile
      inst->profile = 100;
      break;
    case 12:
      //H.264 high 10 profile
      inst->profile = 110;
      break;
    default:
      break;
  }
  /* enforce maximum frame size in level */
  if ((u32)(inst->width * inst->height) > getMaxPicSize(inst->codecFormat, inst->levelIdx))
  {
    printf("WARNING: MaxFS violates level limit\n");
  }

  /* enforce Max luma sample rate in level */
  {
    u32 sample_rate =
      (pEncCfg->frameRateNum * inst->width * inst->height) /
      pEncCfg->frameRateDenom;

    if (sample_rate > getMaxSBPS(inst->codecFormat, inst->levelIdx))
    {
      printf("WARNING: MaxSBPS violates level limit\n");
    }
  }
  /* intra */
  inst->constrained_intra_pred_flag = 0;
  inst->strong_intra_smoothing_enabled_flag = pEncCfg->strongIntraSmoothing;


  inst->Jenc_vps->max_dec_pic_buffering[0] = pEncCfg->refFrameAmount + 1;
  inst->Jenc_sps->max_dec_pic_buffering[0] = pEncCfg->refFrameAmount + 1;


  inst->Jenc_sps->bit_depth_luma_minus8 = pEncCfg->bitDepthLuma - 8;
  inst->Jenc_sps->bit_depth_chroma_minus8 = pEncCfg->bitDepthChroma - 8;

  inst->Jenc_vps->max_num_sub_layers = pEncCfg->maxTLayers;
  inst->Jenc_vps->temporal_id_nesting_flag =1;
  for(int i = 0; i < inst->Jenc_vps->max_num_sub_layers; i++)
  {
    inst->Jenc_vps->max_dec_pic_buffering[i] =inst->Jenc_vps->max_dec_pic_buffering[0];
  }

  inst->Jenc_sps->max_num_sub_layers = pEncCfg->maxTLayers;
  inst->Jenc_sps->temporal_id_nesting_flag =1;
  for(int i = 0; i < inst->Jenc_sps->max_num_sub_layers; i++)
  {
    inst->Jenc_sps->max_dec_pic_buffering[i] =inst->Jenc_sps->max_dec_pic_buffering[0];
  }

  inst->Jenc_sps->picOrderCntType = pEncCfg->picOrderCntType;
  inst->Jenc_sps->log2_max_pic_order_cnt_lsb  = pEncCfg->log2MaxPicOrderCntLsb;
  inst->Jenc_sps->log2MaxFrameNumMinus4 = (pEncCfg->log2MaxFrameNum - 4);
  inst->Jenc_sps->log2MaxpicOrderCntLsbMinus4 = (pEncCfg->log2MaxPicOrderCntLsb - 4);
  if (HW_ID_MAJOR_NUMBER(inst->asic.regs.asicHwId) == 0x60) /* VC8000E6.0 */
  {
    int log2MaxPicOrderCntLsb = (IS_H264(pEncCfg->codecFormat) ? 16 : 8);
    inst->Jenc_sps->log2_max_pic_order_cnt_lsb  = log2MaxPicOrderCntLsb;
    inst->Jenc_sps->log2MaxFrameNumMinus4 = 12;
    inst->Jenc_sps->log2MaxpicOrderCntLsbMinus4 = (log2MaxPicOrderCntLsb - 4);
  }

  /* Rate control setup */

  /* Maximum bitrate for the specified level */
  bps = getMaxBR(inst->codecFormat, inst->levelIdx, inst->profile, inst->tier);

  {
    vcencRateControl_s *rc = &inst->rateControl;

    rc->outRateDenom = pEncCfg->frameRateDenom;
    rc->outRateNum = pEncCfg->frameRateNum;
    rc->picArea = ((inst->width + 7) & (~7)) * ((inst->height + 7) & (~7));
    rc->ctbPerPic = inst->ctbPerFrame;
    rc->reciprocalOfNumBlk8 = 1.0/(rc->ctbPerPic*(ctb_size/8)*(ctb_size/8));
    rc->ctbRows = inst->ctbPerCol;
    rc->ctbCols = inst->ctbPerRow;
    rc->ctbSize = ctb_size;

    {
      rcVirtualBuffer_s *vb = &rc->virtualBuffer;

      vb->bitRate = bps;
      vb->unitsInTic = pEncCfg->frameRateDenom;
      vb->timeScale = pEncCfg->frameRateNum * (inst->interlaced + 1);
      vb->bufferSize = getMaxCPBS(inst->codecFormat, inst->levelIdx, inst->profile, inst->tier);
    }

    rc->hrd = ENCHW_NO;
    rc->picRc = ENCHW_NO;
    rc->ctbRc = 0;
    rc->picSkip = ENCHW_NO;
    rc->vbr = ENCHW_NO;

    rc->qpHdr = VCENC_DEFAULT_QP << QP_FRACTIONAL_BITS;
    rc->qpMin = 0 << QP_FRACTIONAL_BITS;
    rc->qpMax = 51 << QP_FRACTIONAL_BITS;

    rc->frameCoded = ENCHW_YES;
    rc->sliceTypeCur = I_SLICE;
    rc->sliceTypePrev = P_SLICE;
    rc->bitrateWindow = 150;

    /* Default initial value for intra QP delta */
    rc->intraQpDelta = INTRA_QPDELTA_DEFAULT << QP_FRACTIONAL_BITS;
    rc->fixedIntraQp = 0 << QP_FRACTIONAL_BITS;
    rc->frameQpDelta = 0 << QP_FRACTIONAL_BITS;
    rc->gopPoc       = 0;
  }

  /* no SEI by default */
  inst->rateControl.sei.enabled = ENCHW_NO;

  /* Pre processing */
  inst->preProcess.lumWidth = pEncCfg->width;
  inst->preProcess.lumWidthSrc =
  VCEncGetAllowedWidth(pEncCfg->width, VCENC_YUV420_PLANAR);

  inst->preProcess.lumHeight = pEncCfg->height / ((inst->interlaced + 1));
  inst->preProcess.lumHeightSrc = pEncCfg->height;

  inst->preProcess.horOffsetSrc = 0;
  inst->preProcess.verOffsetSrc = 0;

  inst->preProcess.rotation = ROTATE_0;
  inst->preProcess.mirror = VCENC_MIRROR_NO;
  inst->preProcess.inputFormat = VCENC_YUV420_PLANAR;
  inst->preProcess.videoStab = 0;

  inst->preProcess.scaledWidth    = 0;
  inst->preProcess.scaledHeight   = 0;
  inst->preProcess.scaledOutput   = 0;
  inst->preProcess.interlacedFrame = inst->interlaced;
  inst->asic.scaledImage.busAddress = 0;
  inst->asic.scaledImage.virtualAddress = NULL;
  inst->asic.scaledImage.size = 0;
  inst->preProcess.adaptiveRoi = 0;
  inst->preProcess.adaptiveRoiColor  = 0;
  inst->preProcess.adaptiveRoiMotion = -5;

  inst->preProcess.input_alignment = inst->input_alignment;
  inst->preProcess.colorConversionType = 0;

  JencSetColorConversion(&inst->preProcess, &inst->asic);

  return ENCHW_OK;
}

/*------------------------------------------------------------------------------

    Round the width to the next multiple of 8 or 16 depending on YUV type.

------------------------------------------------------------------------------*/
i32 VCEncGetAllowedWidth(i32 width, VCEncPictureType inputType)
{
  if (inputType == VCENC_YUV420_PLANAR)
  {
    /* Width must be multiple of 16 to make
     * chrominance row 64-bit aligned */
    return ((width + 15) / 16) * 16;
  }
  else
  {
    /* VCENC_YUV420_SEMIPLANAR */
    /* VCENC_YUV422_INTERLEAVED_YUYV */
    /* VCENC_YUV422_INTERLEAVED_UYVY */
    return ((width + 7) / 8) * 8;
  }
}

void IntraLamdaQp(int qp, u32 *lamda_sad, enum slice_type type, int poc, float dQPFactor, bool depth0)
{
  float recalQP = (float)qp;
  float lambda;

  // pre-compute lambda and QP values for all possible QP candidates
  {
    // compute lambda value
    //Int    NumberBFrames = 0;
    //double dLambda_scale = 1.0 - MAX( 0.0, MIN( 0.5, 0.05*(double)NumberBFrames ));
    //double qp_temp = (double) recalQP + bitdepth_luma_qp_scale - SHIFT_QP;
    // Case #1: I or P-slices (key-frame)
    //double dQPFactor = type == B_SLICE ? 0.68 : 0.8;//0.442;//0.576;//0.8;
    //lambda = dQPFactor * pow(2.0, qp_temp / 3.0);
    //if (type == B_SLICE)
    //lambda *= CLIP3(2.0, 4.0, (qp - 12) / 6.0); //* 0.8/0.576;

    //clip
    //    if (((unsigned int)lambda) > ((1<<14)-1))
    //      lambda = (double)((1<<14)-1);

    Int    SHIFT_QP = 12;
    Int    g_bitDepth = 8;
    Int    bitdepth_luma_qp_scale = 6 * (g_bitDepth - 8);
    Int qp_temp = qp + bitdepth_luma_qp_scale;


    lambda = (float)dQPFactor * sqrtPow2QpDiv3[qp_temp];
    if (!depth0)
      lambda *= sqrtQpDiv6[qp];
  }

  // store lambda
  //lambda = sqrt(lambda);

  ASSERT(lambda < 255);

  *lamda_sad = (u32)(lambda * (1 << IMS_LAMBDA_SAD_SHIFT) + 0.5f);
}

void InterLamdaQp(int qp, unsigned int *lamda_sse, unsigned int *lamda_sad, enum slice_type type, float dQPFactor, bool depth0, u32 asicId)
{
  float recalQP = (float)qp;
  float lambda;

  // pre-compute lambda and QP values for all possible QP candidates
  {
    // compute lambda value
    //Int    NumberBFrames = 0;
    //double dLambda_scale = 1.0 - MAX( 0.0, MIN( 0.5, 0.05*(double)NumberBFrames ));
    //double qp_temp = (double) recalQP + bitdepth_luma_qp_scale - SHIFT_QP;
    // Case #1: I or P-slices (key-frame)
    //double dQPFactor = type == B_SLICE ? 0.68 : 0.8;//0.442;//0.576;//0.8;
    //lambda = dQPFactor * pow(2.0, qp_temp / 3.0);
    //if (type == B_SLICE)
    //lambda *= CLIP3(2.0, 4.0, (qp - 12) / 6.0); //* 0.8/0.576;

    Int    SHIFT_QP = 12;
    Int    g_bitDepth = 8;
    Int    bitdepth_luma_qp_scale = 6 * (g_bitDepth - 8);
    Int qp_temp = qp + bitdepth_luma_qp_scale;


    lambda = (float)dQPFactor * sqrtPow2QpDiv3[qp_temp];
    if (!depth0)
      lambda *= sqrtQpDiv6[qp];
  }

  u32 lambdaSSEShift = 0;
  u32 lambdaSADShift = 0;
  if ((HW_ID_MAJOR_NUMBER(asicId)) >= 5) /* H2V5 rev01 */
  {
    lambdaSSEShift = MOTION_LAMBDA_SSE_SHIFT;
    lambdaSADShift = MOTION_LAMBDA_SAD_SHIFT;
  }

  //keep accurate for small QP
  u32 lambdaSSE = (u32)(lambda*lambda * (1 << lambdaSSEShift) + 0.5f);
  u32 lambdaSAD = (u32)(lambda * (1 << lambdaSADShift) + 0.5f);

  //clip
  u32 maxLambdaSSE = (1 << (15+lambdaSSEShift)) - 1;
  u32 maxLambdaSAD = (1 << (8+lambdaSADShift)) - 1;
  lambdaSSE = MIN(lambdaSSE, maxLambdaSSE);
  lambdaSAD = MIN(lambdaSAD, maxLambdaSAD);

  // store lambda
  *lamda_sse = lambdaSSE;
  *lamda_sad = lambdaSAD;
}

void IntraLamdaQpFixPoint(int qp, u32 *lamda_sad, enum slice_type type, int poc, u32 qpFactorSad, bool depth0)
{
  i32 shiftSad = LAMBDA_FIX_POINT + QPFACTOR_FIX_POINT - IMS_LAMBDA_SAD_SHIFT;
  u32 roundSad = 1 << (shiftSad-1);
  u32 maxLambdaSAD = (1 << (8 + IMS_LAMBDA_SAD_SHIFT)) - 1;
  const u32 *lambdaSadTbl = (!depth0) ? lambdaSadDepth1Tbl : lambdaSadDepth0Tbl;

  u64 lambdaSad = ((u64)qpFactorSad * lambdaSadTbl[qp] + roundSad) >> shiftSad;
  *lamda_sad = MIN(lambdaSad, maxLambdaSAD);
}

void InterLamdaQpFixPoint(int qp, unsigned int *lamda_sse, unsigned int *lamda_sad, enum slice_type type, u32 qpFactorSad, u32 qpFactorSse, bool depth0, u32 asicId)
{
  i32 shiftSad = LAMBDA_FIX_POINT + QPFACTOR_FIX_POINT - MOTION_LAMBDA_SAD_SHIFT;
  i32 shiftSse = LAMBDA_FIX_POINT + QPFACTOR_FIX_POINT - MOTION_LAMBDA_SSE_SHIFT;
  u32 roundSad = 1 << (shiftSad-1);
  u32 roundSse = 1 << (shiftSse-1);
  u32 maxLambdaSAD = (1 << (8 + MOTION_LAMBDA_SAD_SHIFT)) - 1;
  u32 maxLambdaSSE = (1 << (15+ MOTION_LAMBDA_SSE_SHIFT)) - 1;
  const u32 *lambdaSadTbl = (!depth0) ? lambdaSadDepth1Tbl : lambdaSadDepth0Tbl;
  const u32 *lambdaSseTbl = (!depth0) ? lambdaSseDepth1Tbl : lambdaSseDepth0Tbl;

  u64 lambdaSad = ((u64)qpFactorSad * lambdaSadTbl[qp] + roundSad) >> shiftSad;
  u64 lambdaSse = ((u64)qpFactorSse * lambdaSseTbl[qp] + roundSse) >> shiftSse;
  lambdaSse = MIN(lambdaSse, maxLambdaSSE);
  lambdaSad = MIN(lambdaSad, maxLambdaSAD);
  if ((HW_ID_MAJOR_NUMBER(asicId)) < 5) /* H2V5 rev01 */
  {
    lambdaSse >>= MOTION_LAMBDA_SSE_SHIFT;
    lambdaSad >>= MOTION_LAMBDA_SAD_SHIFT;
  }

  // store lambda
  *lamda_sse = lambdaSse;
  *lamda_sad = lambdaSad;
}

//Set LamdaTable for all qp
void LamdaTableQp(regValues_s *regs, int qp, enum slice_type type, int poc, double dQPFactor, bool depth0, u32 ctbRc)
{
  int qpoffset, lamdaIdx;
#ifdef FIX_POINT_LAMBDA
  u32 qpFactorSad = (u32)((dQPFactor * (1<<QPFACTOR_FIX_POINT)) + 0.5f);
  u32 qpFactorSse = (u32)((dQPFactor * dQPFactor * (1<<QPFACTOR_FIX_POINT)) + 0.5f);
#endif
#ifndef CTBRC_STRENGTH

  //setup LamdaTable dependent on ctbRc enable
  if (ctbRc)
  {
    for (qpoffset = -2, lamdaIdx = 14; qpoffset <= +2; qpoffset++, lamdaIdx++)
    {
#ifdef FIX_POINT_LAMBDA
      IntraLamdaQpFixPoint(qp - qpoffset, regs->lambda_satd_ims + (lamdaIdx & 0xf), type, poc, qpFactorSad, depth0);
      InterLamdaQpFixPoint(qp - qpoffset, regs->lambda_sse_me + (lamdaIdx & 0xf),  regs->lambda_satd_me + (lamdaIdx & 0xf), type, qpFactorSad, qpFactorSse, depth0, regs->asicHwId);
#else
      IntraLamdaQp(qp - qpoffset, regs->lambda_satd_ims + (lamdaIdx & 0xf), type, poc, dQPFactor, depth0);
      InterLamdaQp(qp - qpoffset, regs->lambda_sse_me + (lamdaIdx & 0xf),  regs->lambda_satd_me + (lamdaIdx & 0xf), type, dQPFactor, depth0, regs->asicHwId);
#endif
    }

  }
  else
  {
    //for ROI-window, ROI-Map
    for (qpoffset = 0, lamdaIdx = 0; qpoffset <= 15; qpoffset++, lamdaIdx++)
    {
#ifdef FIX_POINT_LAMBDA
      IntraLamdaQpFixPoint(qp - qpoffset, regs->lambda_satd_ims + lamdaIdx, type, poc, qpFactorSad, depth0);
      InterLamdaQpFixPoint(qp - qpoffset, regs->lambda_sse_me + lamdaIdx,   regs->lambda_satd_me + lamdaIdx, type, qpFactorSad, qpFactorSse, depth0, regs->asicHwId);
#else
      IntraLamdaQp(qp - qpoffset, regs->lambda_satd_ims + lamdaIdx, type, poc, dQPFactor, depth0);
      InterLamdaQp(qp - qpoffset, regs->lambda_sse_me + lamdaIdx,   regs->lambda_satd_me + lamdaIdx, type, dQPFactor, depth0, regs->asicHwId);
#endif
    }
  }
#else

	regs->offsetSliceQp = 0;
	if( qp >= 35)
	{
		regs->offsetSliceQp = 35 - qp;
	}
	if(qp <= 15)
	{
		regs->offsetSliceQp = 15 - qp;
	}

  for (qpoffset = -16, lamdaIdx = 16 /* - regs->offsetSliceQp*/; qpoffset <= +15; qpoffset++, lamdaIdx++)
  {
#ifdef FIX_POINT_LAMBDA
    IntraLamdaQpFixPoint(CLIP3(0,51,qp - qpoffset + regs->offsetSliceQp), regs->lambda_satd_ims + (lamdaIdx & 0x1f), type, poc, qpFactorSad, depth0);
    InterLamdaQpFixPoint(CLIP3(0,51,qp - qpoffset + regs->offsetSliceQp), regs->lambda_sse_me + (lamdaIdx & 0x1f),  regs->lambda_satd_me + (lamdaIdx & 0x1f), type, qpFactorSad, qpFactorSse, depth0, regs->asicHwId);
#else
    IntraLamdaQp(CLIP3(0,51,qp - qpoffset + regs->offsetSliceQp), regs->lambda_satd_ims + (lamdaIdx & 0x1f), type, poc, dQPFactor, depth0);
    InterLamdaQp(CLIP3(0,51,qp - qpoffset + regs->offsetSliceQp), regs->lambda_sse_me + (lamdaIdx & 0x1f),  regs->lambda_satd_me + (lamdaIdx & 0x1f), type, dQPFactor, depth0, regs->asicHwId);
#endif
  }

  if (regs->asicCfg.roiAbsQpSupport)
  {
#ifdef LARGE_QPFACTOR_FOR_BIGQP
    /*
       purpose is to lower bitrate when -u2 is enabled and qp is very large,
       which indicates bitrate may be out of control.
    */
    if (IS_CTBRC_FOR_BITRATE(ctbRc) && qp >= 45)
    {
      float qpFactorForBigQp[7] = {1.0, 1.1180, 1.2247, 1.3038, 1.3601, 1.3964, 1.4141};
      dQPFactor = MAX(dQPFactor, qpFactorForBigQp[qp-45]);
    }
#endif
    regs->qpFactorSad = (u32)((dQPFactor * (1<<QPFACTOR_FIX_POINT)) + 0.5);
    regs->qpFactorSse = (u32)((dQPFactor * dQPFactor * (1<<QPFACTOR_FIX_POINT)) + 0.5);
    regs->lambdaDepth = !depth0;
  }
#endif
}

void FillIntraFactor(regValues_s *regs)
{
#if 0
  const double weight = 0.57 / 0.8;
  const double size_coeff[4] =
  {
    30.0,
    30.0,
    42.0,
    42.0
  };
  const u32 mode_coeff[3] =
  {
    0x6276 + 1 * 0x8000,
    0x6276 + 2 * 0x8000,
    0x6276 + 5 * 0x8000,
  };

  regs->intra_size_factor[0] = double_to_u6q4(sqrt(weight) * (1 / 0.8) * size_coeff[0]);
  regs->intra_size_factor[1] = double_to_u6q4(sqrt(weight) * (1 / 0.8) * size_coeff[1]);
  regs->intra_size_factor[2] = double_to_u6q4(sqrt(weight) * (1 / 0.8) * size_coeff[2]);
  regs->intra_size_factor[3] = double_to_u6q4(sqrt(weight) * (1 / 0.8) * size_coeff[3]);

  regs->intra_mode_factor[0] = double_to_u6q4(sqrt(weight) * (double) mode_coeff[0] / 32768.0);
  regs->intra_mode_factor[1] = double_to_u6q4(sqrt(weight) * (double) mode_coeff[1] / 32768.0);
  regs->intra_mode_factor[2] = double_to_u6q4(sqrt(weight) * (double) mode_coeff[2] / 32768.0);
#else
  regs->intra_size_factor[0] = 506;
  regs->intra_size_factor[1] = 506;
  regs->intra_size_factor[2] = 709;
  regs->intra_size_factor[3] = 709;

  if(regs->codingType == ASIC_H264) {
    regs->intra_mode_factor[0] = 24;
    regs->intra_mode_factor[1] = 12;
    regs->intra_mode_factor[2] = 48;
  } else {
    regs->intra_mode_factor[0] = 24;
    regs->intra_mode_factor[1] = 37;
    regs->intra_mode_factor[2] = 78;
  }
#endif

  return;
}

/*------------------------------------------------------------------------------

    Set QP related parameters at the beginning of a new frame.

------------------------------------------------------------------------------*/
static void VCEncSetQuantParameters(struct vcenc_instance *vcenc_instance,
                                         struct sw_picture *pic, const VCEncIn *pEncIn,
                                          double qp_factor, bool is_depth0)
{
  if (!vcenc_instance)
    return;

  asicData_s *asic = &vcenc_instance->asic;
  u32 enable_ctu_rc = vcenc_instance->rateControl.ctbRc;
  enum slice_type type = pic->sliceInst->type;

  /* Intra Penalty for TU 4x4 vs. 8x8 */
  static unsigned short VCEncIntraPenaltyTu4[52] =
  {
    7,    7,    8,   10,   11,   12,   14,   15,   17,   20,
    22,   25,   28,   31,   35,   40,   44,   50,   56,   63,
    71,   80,   89,  100,  113,  127,  142,  160,  179,  201,
    226,  254,  285,  320,  359,  403,  452,  508,  570,  640,
    719,  807,  905, 1016, 1141, 1281, 1438, 1614, 1811, 2033,
    2282, 2562
  };//max*3=13bit

  /* Intra Penalty for TU 8x8 vs. 16x16 */
  static unsigned short VCEncIntraPenaltyTu8[52] =
  {
    7,    7,    8,   10,   11,   12,   14,   15,   17,   20,
    22,   25,   28,   31,   35,   40,   44,   50,   56,   63,
    71,   80,   89,  100,  113,  127,  142,  160,  179,  201,
    226,  254,  285,  320,  359,  403,  452,  508,  570,  640,
    719,  807,  905, 1016, 1141, 1281, 1438, 1614, 1811, 2033,
    2282, 2562
  };//max*3=13bit

  /* Intra Penalty for TU 16x16 vs. 32x32 */
  static unsigned short VCEncIntraPenaltyTu16[52] =
  {
    9,   11,   12,   14,   15,   17,   19,   22,   24,   28,
    31,   35,   39,   44,   49,   56,   62,   70,   79,   88,
    99,  112,  125,  141,  158,  177,  199,  224,  251,  282,
    317,  355,  399,  448,  503,  564,  634,  711,  799,  896,
    1006, 1129, 1268, 1423, 1598, 1793, 2013, 2259, 2536, 2847,
    3196, 3587
  };//max*3=14bit

  /* Intra Penalty for TU 32x32 vs. 64x64 */
  static unsigned short VCEncIntraPenaltyTu32[52] =
  {
    9,   11,   12,   14,   15,   17,   19,   22,   24,   28,
    31,   35,   39,   44,   49,   56,   62,   70,   79,   88,
    99,  112,  125,  141,  158,  177,  199,  224,  251,  282,
    317,  355,  399,  448,  503,  564,  634,  711,  799,  896,
    1006, 1129, 1268, 1423, 1598, 1793, 2013, 2259, 2536, 2847,
    3196, 3587
  };//max*3=14bit

  /* Intra Penalty for Mode a */
  static unsigned short VCEncIntraPenaltyModeA[52] =
  {
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    1,    1,    1,    1,    1,    1,    2,    2,    2,    2,
    3,    3,    4,    4,    5,    5,    6,    7,    8,    9,
    10,   11,   13,   15,   16,   19,   21,   23,   26,   30,
    33,   38,   42,   47,   53,   60,   67,   76,   85,   95,
    107,  120
  };//max*3=9bit

  /* Intra Penalty for Mode b */
  static unsigned short VCEncIntraPenaltyModeB[52] =
  {
    0,    0,    0,    0,    0,    0,    1,    1,    1,    1,
    1,    1,    2,    2,    2,    2,    3,    3,    4,    4,
    5,    5,    6,    7,    8,    9,   10,   11,   13,   14,
    16,   18,   21,   23,   26,   29,   33,   37,   42,   47,
    53,   59,   66,   75,   84,   94,  106,  119,  133,  150,
    168,  189
  };////max*3=10bit

  /* Intra Penalty for Mode c */
  static unsigned short VCEncIntraPenaltyModeC[52] =
  {
    1,    1,    1,    1,    1,    1,    2,    2,    2,    3,
    3,    3,    4,    4,    5,    6,    6,    7,    8,    9,
    10,   12,   13,   15,   17,   19,   21,   24,   27,   31,
    34,   39,   43,   49,   55,   62,   69,   78,   87,   98,
    110,  124,  139,  156,  175,  197,  221,  248,  278,  312,
    351,  394
  };//max*3=11bit

  switch (HW_ID_MAJOR_NUMBER(asic->regs.asicHwId))
  {
    case 1: /* H2V1 rev01 */
      asic->regs.intraPenaltyPic4x4  = VCEncIntraPenaltyTu4[asic->regs.qp];
      asic->regs.intraPenaltyPic8x8  = VCEncIntraPenaltyTu8[asic->regs.qp];
      asic->regs.intraPenaltyPic16x16 = VCEncIntraPenaltyTu16[asic->regs.qp];
      asic->regs.intraPenaltyPic32x32 = VCEncIntraPenaltyTu32[asic->regs.qp];

      asic->regs.intraMPMPenaltyPic1 = VCEncIntraPenaltyModeA[asic->regs.qp];
      asic->regs.intraMPMPenaltyPic2 = VCEncIntraPenaltyModeB[asic->regs.qp];
      asic->regs.intraMPMPenaltyPic3 = VCEncIntraPenaltyModeC[asic->regs.qp];

      u32 roi1_qp = CLIP3(0, 51, ((int)asic->regs.qp - (int)asic->regs.roi1DeltaQp));
      asic->regs.intraPenaltyRoi14x4 = VCEncIntraPenaltyTu4[roi1_qp];
      asic->regs.intraPenaltyRoi18x8 = VCEncIntraPenaltyTu8[roi1_qp];
      asic->regs.intraPenaltyRoi116x16 = VCEncIntraPenaltyTu16[roi1_qp];
      asic->regs.intraPenaltyRoi132x32 = VCEncIntraPenaltyTu32[roi1_qp];

      asic->regs.intraMPMPenaltyRoi11 = VCEncIntraPenaltyModeA[roi1_qp];
      asic->regs.intraMPMPenaltyRoi12 = VCEncIntraPenaltyModeB[roi1_qp];
      asic->regs.intraMPMPenaltyRoi13 = VCEncIntraPenaltyModeC[roi1_qp];

      u32 roi2_qp = CLIP3(0, 51, ((int)asic->regs.qp - (int)asic->regs.roi2DeltaQp));
      asic->regs.intraPenaltyRoi24x4 = VCEncIntraPenaltyTu4[roi2_qp];
      asic->regs.intraPenaltyRoi28x8 = VCEncIntraPenaltyTu8[roi2_qp];
      asic->regs.intraPenaltyRoi216x16 = VCEncIntraPenaltyTu16[roi2_qp];
      asic->regs.intraPenaltyRoi232x32 = VCEncIntraPenaltyTu32[roi2_qp];

      asic->regs.intraMPMPenaltyRoi21 = VCEncIntraPenaltyModeA[roi2_qp]; //need to change
      asic->regs.intraMPMPenaltyRoi22 = VCEncIntraPenaltyModeB[roi2_qp]; //need to change
      asic->regs.intraMPMPenaltyRoi23 = VCEncIntraPenaltyModeC[roi2_qp];  //need to change

      /*inter prediction parameters*/
#ifndef FIX_POINT_LAMBDA
      InterLamdaQp(asic->regs.qp, &asic->regs.lamda_motion_sse, &asic->regs.lambda_motionSAD,
                   type, qp_factor, is_depth0, asic->regs.asicHwId);
      InterLamdaQp(asic->regs.qp - asic->regs.roi1DeltaQp, &asic->regs.lamda_motion_sse_roi1,
                   &asic->regs.lambda_motionSAD_ROI1, type,
                   qp_factor, is_depth0, asic->regs.asicHwId);
      InterLamdaQp(asic->regs.qp - asic->regs.roi2DeltaQp, &asic->regs.lamda_motion_sse_roi2,
                   &asic->regs.lambda_motionSAD_ROI2, type,
                   qp_factor, is_depth0, asic->regs.asicHwId);
#else
      u32 qpFactorSad = (u32)((qp_factor * (1<<QPFACTOR_FIX_POINT)) + 0.5f);
      u32 qpFactorSse = (u32)((qp_factor * qp_factor * (1<<QPFACTOR_FIX_POINT)) + 0.5f);
      InterLamdaQpFixPoint(asic->regs.qp, &asic->regs.lamda_motion_sse, &asic->regs.lambda_motionSAD,
                   type, qpFactorSad, qpFactorSse, is_depth0, asic->regs.asicHwId);
      InterLamdaQpFixPoint(asic->regs.qp - asic->regs.roi1DeltaQp, &asic->regs.lamda_motion_sse_roi1,
                   &asic->regs.lambda_motionSAD_ROI1, type,
                   qpFactorSad, qpFactorSse, is_depth0, asic->regs.asicHwId);
      InterLamdaQpFixPoint(asic->regs.qp - asic->regs.roi2DeltaQp, &asic->regs.lamda_motion_sse_roi2,
                   &asic->regs.lambda_motionSAD_ROI2, type,
                   qpFactorSad, qpFactorSse, is_depth0, asic->regs.asicHwId);
#endif

      asic->regs.lamda_SAO_luma = asic->regs.lamda_motion_sse;
      asic->regs.lamda_SAO_chroma = 0.75 * asic->regs.lamda_motion_sse;

      break;
    case 2: /* H2V2 rev01 */
    case 3: /* H2V3 rev01 */
      LamdaTableQp(&asic->regs, asic->regs.qp, type, asic->regs.poc,
                   qp_factor, is_depth0, enable_ctu_rc);
      FillIntraFactor(&asic->regs);
      asic->regs.lamda_SAO_luma = asic->regs.lambda_sse_me[0];
      asic->regs.lamda_SAO_chroma = 0.75 * asic->regs.lambda_sse_me[0];
      break;
    case 4: /* H2V4 rev01 */
      LamdaTableQp(&asic->regs, asic->regs.qp, type, asic->regs.poc,
                   qp_factor, is_depth0, enable_ctu_rc);
      FillIntraFactor(&asic->regs);
      asic->regs.lamda_SAO_luma = asic->regs.lambda_sse_me[0];
      asic->regs.lamda_SAO_chroma = 0.75 * asic->regs.lambda_sse_me[0];
      break;
    case 5: /* H2V5 rev01 */
    case 6: /* H2V6 rev01 */
    case 7: /* H2V7 rev01 */
    case 0x60: /* VC8000E 6.0 */
    case 0x61: /* VC8000E 6.1 */
    case 0x62:
    case 0x81:
    case 0x82:
    default:
      LamdaTableQp(&asic->regs, asic->regs.qp, type, asic->regs.poc,
                   qp_factor, is_depth0, enable_ctu_rc);
      FillIntraFactor(&asic->regs);
      asic->regs.lamda_SAO_luma = asic->regs.lambda_sse_me[0];
      asic->regs.lamda_SAO_chroma = 0.75 * asic->regs.lambda_sse_me[0];
      // sao lambda registers are not expanded
      asic->regs.lamda_SAO_luma >>= MOTION_LAMBDA_SSE_SHIFT;
      asic->regs.lamda_SAO_chroma >>= MOTION_LAMBDA_SSE_SHIFT;
      break;
  }

  {
    u32 maxSaoLambda = (1<<14)-1;
    asic->regs.lamda_SAO_luma = MIN(asic->regs.lamda_SAO_luma, maxSaoLambda);
    asic->regs.lamda_SAO_chroma = MIN(asic->regs.lamda_SAO_chroma, maxSaoLambda);
  }

//   /* For experiment, lambda setting for subjective quality */
//   if (vcenc_instance->rateControl.visualLmdTuning && asic->regs.asicCfg.roiAbsQpSupport)
//     LambdaTuningSubjective(asic, pic, pEncIn);

//   /* For experiment, tuning rdoq lambda for subjective quality */
//   true_e rdoqMapEnable = asic->regs.rdoqMapEnable && (asic->regs.asicCfg.roiMapVersion == 4) && (asic->regs.RoiQpDelta_ver == 4);
//   if (vcenc_instance->bRdoqLambdaAdjust &&
//       (asic->regs.bRDOQEnable || rdoqMapEnable ) &&
//       asic->regs.asicCfg.roiAbsQpSupport)
//   {
//      const u32 factorIntra = RDOQ_LMD_INTRA_FACTOR_SCALED;
//      const u32 factorInter = RDOQ_LMD_INTER_FACTOR_SCALED;
//      asic->regs.rdoqLambdaAdjustIntra = asic->regs.rdoqLambdaAdjustInter = 0;
//      if (factorIntra < asic->regs.qpFactorSse)
//      {
//        asic->regs.rdoqLambdaAdjustIntra =
//           (factorIntra * (1<<QPFACTOR_FIX_POINT) + asic->regs.qpFactorSse/2) / asic->regs.qpFactorSse;
//      }

//      if (factorInter < asic->regs.qpFactorSse)
//      {
//        asic->regs.rdoqLambdaAdjustInter =
//           (factorInter * (1<<QPFACTOR_FIX_POINT) + asic->regs.qpFactorSse/2) / asic->regs.qpFactorSse;
//      }
//   }
}

/*------------------------------------------------------------------------------

    Set encoding parameters at the beginning of a new frame.

------------------------------------------------------------------------------*/
void VCEncSetNewFrame(VCEncInst inst)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  asicData_s *asic = &vcenc_instance->asic;
  regValues_s *regs = &vcenc_instance->asic.regs;
  i32 qpHdr, qpMin, qpMax;
  i32 qp[4];
  i32 s, i, aroiDeltaQ = 0, tmp;

  regs->outputStrmSize[0] -= vcenc_instance->stream.byteCnt;
  /* stream base address */
  regs->outputStrmBase[0] += vcenc_instance->stream.byteCnt;

  /* Enable slice ready interrupts if defined by config and slices in use */
  regs->sliceReadyInterrupt =
    ENCH2_SLICE_READY_INTERRUPT & (regs->sliceNum > 1);

  /* HW base address for NAL unit sizes is affected by start offset
   * and SW created NALUs. */
  regs->sizeTblBase = asic->sizeTbl[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum].busAddress + vcenc_instance->numNalus[vcenc_instance->jobCnt%vcenc_instance->parallelCoreNum] * 4;


  /* HW Base must be 64-bit aligned */
  //ASSERT(regs->sizeTblBase%8 == 0);

  /* low latency: configure related register.*/
  regs->lineBufferEn = vcenc_instance->inputLineBuf.inputLineBufEn;
  regs->lineBufferHwHandShake = vcenc_instance->inputLineBuf.inputLineBufHwModeEn;
  regs->lineBufferLoopBackEn = vcenc_instance->inputLineBuf.inputLineBufLoopBackEn;
  regs->lineBufferDepth = vcenc_instance->inputLineBuf.inputLineBufDepth;
  regs->amountPerLoopBack = vcenc_instance->inputLineBuf.amountPerLoopBack;
  regs->mbWrPtr = vcenc_instance->inputLineBuf.wrCnt;
  regs->mbRdPtr = 0;
  regs->lineBufferInterruptEn = ENCH2_INPUT_BUFFER_INTERRUPT &
                                regs->lineBufferEn &
                                (regs->lineBufferHwHandShake == 0) &
                                (regs->lineBufferDepth > 0);
  regs->initSegNum = vcenc_instance->inputLineBuf.initSegNum;
  regs->sbi_id_0 = vcenc_instance->inputLineBuf.sbi_id_0;
  regs->sbi_id_1 = vcenc_instance->inputLineBuf.sbi_id_1;
  regs->sbi_id_2 = vcenc_instance->inputLineBuf.sbi_id_2;
}

/* DeNoise Filter */
static void VCEncHEVCDnfInit(struct vcenc_instance *vcenc_instance)
{
  vcenc_instance->uiNoiseReductionEnable = 0;

#if USE_TOP_CTRL_DENOISE
  vcenc_instance->iNoiseL = 10 << FIX_POINT_BIT_WIDTH;
  vcenc_instance->iSigmaCur = vcenc_instance->iFirstFrameSigma = 11 << FIX_POINT_BIT_WIDTH;
  //printf("init seq noiseL = %d, SigCur = %d, first = %d\n\n\n\n\n",pEncInst->iNoiseL, regs->nrSigmaCur,  pCodeParams->firstFrameSigma);
#endif
}

static void VCEncHEVCDnfSetParameters(struct vcenc_instance *inst, const VCEncCodingCtrl *pCodeParams)
{
  regValues_s *regs = &inst->asic.regs;

  //wiener denoise paramter set
  regs->noiseReductionEnable = inst->uiNoiseReductionEnable = pCodeParams->noiseReductionEnable;//0: disable noise reduction; 1: enable noise reduction
  regs->noiseLow = pCodeParams->noiseLow;//0: use default value; valid value range: [1, 30]

#if USE_TOP_CTRL_DENOISE
  inst->iNoiseL = pCodeParams->noiseLow << FIX_POINT_BIT_WIDTH;
  regs->nrSigmaCur = inst->iSigmaCur = inst->iFirstFrameSigma = pCodeParams->firstFrameSigma << FIX_POINT_BIT_WIDTH;
  //printf("init seq noiseL = %d, SigCur = %d, first = %d\n\n\n\n\n",pEncInst->iNoiseL, regs->nrSigmaCur,  pCodeParams->firstFrameSigma);
#endif
}

static void VCEncHEVCDnfGetParameters(struct vcenc_instance *inst, VCEncCodingCtrl *pCodeParams)
{
  pCodeParams->noiseReductionEnable = inst->uiNoiseReductionEnable;
#if USE_TOP_CTRL_DENOISE
  pCodeParams->noiseLow =  inst->iNoiseL >> FIX_POINT_BIT_WIDTH;
  pCodeParams->firstFrameSigma = inst->iFirstFrameSigma >> FIX_POINT_BIT_WIDTH;
#endif
}

// run before HW run, set register's value according to coding settings
static void VCEncHEVCDnfPrepare(struct vcenc_instance *vcenc_instance)
{
  asicData_s *asic = &vcenc_instance->asic;
#if USE_TOP_CTRL_DENOISE
  asic->regs.nrSigmaCur = vcenc_instance->iSigmaCur;
  asic->regs.nrThreshSigmaCur = vcenc_instance->iThreshSigmaCur;
  asic->regs.nrSliceQPPrev = vcenc_instance->iSliceQPPrev;
#endif
}

// run after HW finish one frame, update collected parameters
static void VCEncHEVCDnfUpdate(struct vcenc_instance *vcenc_instance)
{
#if USE_TOP_CTRL_DENOISE
  const int KK=102;
  unsigned int j = 0;
  int CurSigmaTmp = 0;
  unsigned int SigmaSmoothFactor[5] = {1024, 512, 341, 256, 205};
  int dSumFrmNoiseSigma = 0;
  int QpSlc = vcenc_instance->asic.regs.qp;
  int FrameCodingType = vcenc_instance->asic.regs.frameCodingType;
  unsigned int uiFrmNum = vcenc_instance->uiFrmNum++;

  // check pre-conditions
  if (vcenc_instance->uiNoiseReductionEnable == 0 || vcenc_instance->stream.byteCnt == 0)
    return;

  if (uiFrmNum == 0)
    vcenc_instance->FrmNoiseSigmaSmooth[0] = vcenc_instance->iFirstFrameSigma; //(pvcenc_instance->asic.regs.firstFrameSigma<< FIX_POINT_BIT_WIDTH);//pvcenc_instance->iFirstFrmSigma;//(double)((51-QpSlc-5)/2);
  int iFrmSigmaRcv = vcenc_instance->iSigmaCalcd;
  //int iThSigmaRcv = vcenc_instance->iThreshSigmaCalcd;
  int iThSigmaRcv = (FrameCodingType != 1) ? vcenc_instance->iThreshSigmaCalcd : vcenc_instance->iThreshSigmaPrev;
  //printf("iFrmSigRcv = %d\n\n\n", iFrmSigmaRcv);
  if (iFrmSigmaRcv == 0xFFFF)
  {
    iFrmSigmaRcv = vcenc_instance->iFirstFrameSigma;
    //printf("initial to %d\n", iFrmSigmaRcv);
  }
  iFrmSigmaRcv = (iFrmSigmaRcv * KK) >> 7;
  if (iFrmSigmaRcv < vcenc_instance->iNoiseL) iFrmSigmaRcv = 0;
  vcenc_instance->FrmNoiseSigmaSmooth[(uiFrmNum+1)%SIGMA_SMOOTH_NUM] = iFrmSigmaRcv;
  for (j = 0; j < (MIN(SIGMA_SMOOTH_NUM - 1, uiFrmNum + 1) + 1); j++)
  {
    dSumFrmNoiseSigma += vcenc_instance->FrmNoiseSigmaSmooth[j];
    //printf("FrmNoiseSig %d = %d\n", j, pvcenc_instance->FrmNoiseSigmaSmooth[j]);
  }
  CurSigmaTmp = (dSumFrmNoiseSigma * SigmaSmoothFactor[MIN(SIGMA_SMOOTH_NUM-1, uiFrmNum+1)]) >> 10;
  vcenc_instance->iSigmaCur = CLIP3(0, (SIGMA_MAX << FIX_POINT_BIT_WIDTH), CurSigmaTmp);
  vcenc_instance->iThreshSigmaCur = vcenc_instance->iThreshSigmaPrev = iThSigmaRcv;
  vcenc_instance->iSliceQPPrev = QpSlc;
  //printf("TOP::uiFrmNum = %d, FrmSig=%d, Th=%d, QP=%d, QP2=%d\n", uiFrmNum,pvcenc_instance->asic.regs.nrSigmaCur, iThSigmaRcv, QpSlc, QpSlc2 );
#endif
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetEncodedMbLines
    Description   : Get how many MB lines has been encoded by encoder.
    Return type   : int
    Argument      : inst - encoder instance
------------------------------------------------------------------------------*/
u32 Jenc_VCEncGetEncodedMbLines(VCEncInst inst)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  u32 lines;

  APITRACE("Jenc_VCEncGetEncodedMbLines#");

  /* Check for illegal inputs */
  if (!vcenc_instance) {
    APITRACE("Jenc_VCEncGetEncodedMbLines: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  if (!vcenc_instance->inputLineBuf.inputLineBufEn) {
    APITRACE("Jenc_VCEncGetEncodedMbLines: ERROR Invalid mode for input control");
    return VCENC_INVALID_ARGUMENT;
  }

  if (vcenc_instance->inputLineBuf.inputLineBufHwModeEn)
  {
    lines = JencEWLReadReg(vcenc_instance->asic.ewl, 196*4);
    lines = ((lines & 0x000ffc00) >> 10);
  }
  else
    lines = Jenc_EncAsicGetRegisterValue(vcenc_instance->asic.ewl, vcenc_instance->asic.regs.regMirror, HWIF_CTB_ROW_RD_PTR);

  return lines;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncSetInputMBLines
    Description   : Set the input buffer lines available of current picture.
    Return type   : VCEncRet
    Argument      : inst - encoder instance
    Argument      : mbNum - macroblock number
------------------------------------------------------------------------------*/
VCEncRet Jenc_VCEncSetInputMBLines(VCEncInst inst, u32 lines)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;

  APITRACE("Jenc_VCEncSetInputMBLines#");

  /* Check for illegal inputs */
  if (!vcenc_instance) {
    APITRACE("Jenc_VCEncSetInputMBLines: ERROR Null argument");
    return VCENC_NULL_ARGUMENT;
  }

  if (!vcenc_instance->inputLineBuf.inputLineBufEn) {
    APITRACE("Jenc_VCEncSetInputMBLines: ERROR Invalid mode for input control");
    return VCENC_INVALID_ARGUMENT;
  }
  Jenc_EncAsicWriteRegisterValue(vcenc_instance->asic.ewl, vcenc_instance->asic.regs.regMirror, HWIF_CTB_ROW_WR_PTR, lines);
  return VCENC_OK;
}

/*------------------------------------------------------------------------------
Function name : VCEncGenSliceHeaderRps
Description   : cal RPS parameter in the slice header.
Return type   : void
Argument      : VCEncPictureCodingType codingType
Argument      : VCEncGopPicConfig *cfg
------------------------------------------------------------------------------*/
void VCEncGenSliceHeaderRps(struct vcenc_instance *vcenc_instance, VCEncPictureCodingType codingType, VCEncGopPicConfig *cfg)
{
	regValues_s *regs = &vcenc_instance->asic.regs;
	HWRPS_CONFIG *pHwRps = &vcenc_instance->sHwRps;
	i32 i, j, tmp, i32TempPoc;
	i32 i32NegDeltaPoc[VCENC_MAX_REF_FRAMES], i32PosDeltaPoc[VCENC_MAX_REF_FRAMES];
	i32 i32NegDeltaPocUsed[VCENC_MAX_REF_FRAMES], i32PosDeltaPocUsed[VCENC_MAX_REF_FRAMES];
	u32 used_by_cur;

	ASSERT(cfg != NULL);
	ASSERT(codingType < VCENC_NOTCODED_FRAME);

	for (i = 0; i < VCENC_MAX_REF_FRAMES; i++)
	{
		pHwRps->u20DeltaPocS0[i] = 0;
		pHwRps->u20DeltaPocS1[i] = 0;

		i32NegDeltaPoc[i] = 0;
		i32PosDeltaPoc[i] = 0;
		i32NegDeltaPocUsed[i] = 0;
		i32PosDeltaPocUsed[i] = 0;
	}

	pHwRps->u3NegPicNum = 0;
	pHwRps->u3PosPicNum = 0;

	for (i = 0; i < (i32)cfg->numRefPics; i++)
	{
		if (cfg->refPics[i].ref_pic < 0)
		{
			i32NegDeltaPoc[pHwRps->u3NegPicNum]	   = cfg->refPics[i].ref_pic;
			i32NegDeltaPocUsed[pHwRps->u3NegPicNum] = cfg->refPics[i].used_by_cur;

			pHwRps->u3NegPicNum++;
		}
		else
		{
			i32PosDeltaPoc[pHwRps->u3PosPicNum]	   = cfg->refPics[i].ref_pic;
			i32PosDeltaPocUsed[pHwRps->u3PosPicNum] = cfg->refPics[i].used_by_cur;

			pHwRps->u3PosPicNum++;
		}
	}

	for (i = 0; i < pHwRps->u3NegPicNum; i++)
	{
		i32TempPoc = i32NegDeltaPoc[i];
		for (j = i; j < (i32)pHwRps->u3NegPicNum; j++)
		{
			if (i32NegDeltaPoc[j] > i32TempPoc)
			{
				i32NegDeltaPoc[i] = i32NegDeltaPoc[j];
				i32NegDeltaPoc[j] = i32TempPoc;
				i32TempPoc = i32NegDeltaPoc[i];

				used_by_cur = i32NegDeltaPocUsed[i];
				i32NegDeltaPocUsed[i] = i32NegDeltaPocUsed[j];
				i32NegDeltaPocUsed[j] = used_by_cur;
			}
		}
	}

	for (i = 0; i < pHwRps->u3PosPicNum; i++)
	{
		i32TempPoc = i32PosDeltaPoc[i];
		for (j = i; j < (i32)pHwRps->u3PosPicNum; j++)
		{
			if (i32PosDeltaPoc[j] < i32TempPoc)
			{
				i32PosDeltaPoc[i] = i32PosDeltaPoc[j];
				i32PosDeltaPoc[j] = i32TempPoc;
				i32TempPoc = i32PosDeltaPoc[i];

				used_by_cur = i32PosDeltaPocUsed[i];
				i32PosDeltaPocUsed[i] = i32PosDeltaPocUsed[j];
				i32PosDeltaPocUsed[j] = used_by_cur;
			}
		}
	}

	tmp = 0;
	for ( i = 0; i < pHwRps->u3NegPicNum; i++)
	{
		ASSERT((-i32NegDeltaPoc[i] - 1 + tmp) < 0x100000);
		pHwRps->u1DeltaPocS0Used[i] = i32NegDeltaPocUsed[i] & 0x01;
		pHwRps->u20DeltaPocS0[i] = -i32NegDeltaPoc[i] - 1 + tmp;
		tmp = i32NegDeltaPoc[i];
	}
	tmp = 0;
	for ( i = 0; i < pHwRps->u3PosPicNum; i++)
	{
		ASSERT((i32PosDeltaPoc[i] - 1 - tmp) < 0x100000);
		pHwRps->u1DeltaPocS1Used[i] = i32PosDeltaPocUsed[i] & 0x01;
		pHwRps->u20DeltaPocS1[i] = i32PosDeltaPoc[i] - 1 - tmp;
		tmp = i32PosDeltaPoc[i];
	}

	regs->short_term_ref_pic_set_sps_flag = pHwRps->u1short_term_ref_pic_set_sps_flag;
	regs->rps_neg_pic_num = pHwRps->u3NegPicNum;
	regs->rps_pos_pic_num = pHwRps->u3PosPicNum;
	ASSERT(pHwRps->u3NegPicNum + pHwRps->u3PosPicNum <= VCENC_MAX_REF_FRAMES);
	for ( i = 0, j = 0; i < pHwRps->u3NegPicNum; i++, j++)
	{
		regs->rps_delta_poc[j] = pHwRps->u20DeltaPocS0[i];
		regs->rps_used_by_cur[j] = pHwRps->u1DeltaPocS0Used[i];
	}
	for ( i = 0; i < pHwRps->u3PosPicNum; i++, j++)
	{
		regs->rps_delta_poc[j] = pHwRps->u20DeltaPocS1[i];
		regs->rps_used_by_cur[j] = pHwRps->u1DeltaPocS1Used[i];
	}
	for (; j < VCENC_MAX_REF_FRAMES; j++)
	{
		regs->rps_delta_poc[j] = 0;
		regs->rps_used_by_cur[j] = 0;
	}

}

/*------------------------------------------------------------------------------
Function name : VCEncGenPicRefConfig
Description   : cal the ref pic of current pic.
Return type   : void
Argument      : struct container *c
Argument      : VCEncGopPicConfig *cfg
Argument      : struct sw_picture *pCurPic
Argument      : i32 curPicPoc
------------------------------------------------------------------------------*/
void VCEncGenPicRefConfig(struct container *c, VCEncGopPicConfig *cfg, struct sw_picture *pCurPic, i32 curPicPoc)
{
	struct sw_picture *p;
	struct node *n;
	i32 i, j;
	i32 i32PicPoc[VCENC_MAX_REF_FRAMES];

	ASSERT(c != NULL);
	ASSERT(cfg != NULL);
	ASSERT(pCurPic != NULL);
	ASSERT(curPicPoc >= 0);

	for (n = c->picture.tail; n; n = n->next)
	{
		p = (struct sw_picture *)n;
		if ((p->long_term_flag == HANTRO_FALSE) && (p->reference == HANTRO_TRUE) && (p->poc > -1))
		{
			i32PicPoc[cfg->numRefPics] = p->poc;  /* looking short_term ref */
			cfg->numRefPics++;
		}
	}

	for (i = 0; i < (i32)cfg->numRefPics; i++)
	{
		cfg->refPics[i].used_by_cur = 0;

		for (j = 0; j < pCurPic->sliceInst->active_l0_cnt; j++)
		{
			//ASSERT(pCurPic->rpl[0][j]->long_term_flag == HANTRO_FALSE );
			if (pCurPic->rpl[0][j]->poc == i32PicPoc[i])
			{
				cfg->refPics[i].used_by_cur = 1;
				break;
			}
		}

		if (j == pCurPic->sliceInst->active_l0_cnt)
		{
			for (j = 0; j < pCurPic->sliceInst->active_l1_cnt; j++)
			{
				//ASSERT(pCurPic->rpl[1][j]->long_term_flag == HANTRO_FALSE);
				if (pCurPic->rpl[1][j]->poc == i32PicPoc[i])
				{
					cfg->refPics[i].used_by_cur = 1;
					break;
				}
			}
		}
	}

	for (i = 0; i < (i32)cfg->numRefPics; i++)
	{
		cfg->refPics[i].ref_pic = i32PicPoc[i] - curPicPoc;
	}
}

/*------------------------------------------------------------------------------

    API tracing
        TRacing as defined by the API.
    Params:
        msg - null terminated tracing message
------------------------------------------------------------------------------*/
void Jenc_VCEncTrace(const char *msg)
{
#ifdef APITRC_STDOUT
    FILE *fp = stdout;
#else
    static FILE *fp = NULL;

    if(fp == NULL)
        fp = fopen("api.trc", "wt");
#endif
    if(fp)
        fprintf(fp, "%s\n", msg);
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncTraceProfile
    Description   : Tracing PSNR profile result
    Return type   : void
    Argument      : inst - encoder instance
------------------------------------------------------------------------------*/
void Jenc_VCEncTraceProfile(VCEncInst inst)
{
    ASSERT(inst != NULL);
    struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
    JencEWLTraceProfile(vcenc_instance->asic.ewl,NULL,0,0);
}
/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetEwl
    Description   : Get the ewl instance.
    Return type   : ewl instance pointer
    Argument      : inst - encoder instance
------------------------------------------------------------------------------*/
const void *Jenc_VCEncGetEwl(VCEncInst inst)
{
    const void * ewl = NULL;
    if(inst == NULL)
    {
      APITRACEERR("Jenc_VCEncGetEwl: ERROR Null argument");
      ASSERT(0);
    }
    else
    {
      ewl = ((struct vcenc_instance *)inst)->asic.ewl;
      if(ewl == NULL)
      {
        APITRACEERR("Jenc_VCEncGetEwl: EWL instance get failed.");
        ASSERT(0);
      }
    }

    return ewl;
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetAsicConfig
    Description   : Get HW configuration.
    Return type   : JENC_EWLHwConfig_t
    Argument      : codecFormat - codec format
------------------------------------------------------------------------------*/
JENC_EWLHwConfig_t Jenc_VCEncGetAsicConfig(VCEncVideoCodecFormat codecFormat, void *ctx)
{
  u32 clientType = VCEncGetClientType(codecFormat);
  return JencEncAsicGetAsicConfig(clientType,ctx);
}

/*------------------------------------------------------------------------------
    Function name : Jenc_VCEncGetPass1UpdatedGopSize
    Description   : Get pass1 updated GopSize.
    Return type   : pass1 updated GopSize.
    Argument      : inst - encoder instance
------------------------------------------------------------------------------*/
i32 Jenc_VCEncGetPass1UpdatedGopSize(VCEncInst inst)
{
  struct vcenc_instance *pEncInst = (struct vcenc_instance *) inst;
  if(pEncInst->pass == 2)
    pEncInst = (struct vcenc_instance *)pEncInst->lookahead.priv_inst;
  struct cuTreeCtr *m_param = &pEncInst->cuTreeCtl;

  pthread_mutex_lock(&m_param->agop_mutex);
  while(m_param->agop.head == NULL) {
    if(m_param->bStatus >= THREAD_STATUS_CUTREE_FLUSH)
    {
      pthread_mutex_unlock(&m_param->agop_mutex);
      return 1;
    }
    pthread_cond_wait(&m_param->agop_cond, &m_param->agop_mutex);
  }
  struct agop_res *res = (struct agop_res *)Jenc_queue_get(&m_param->agop);
  pthread_mutex_unlock(&m_param->agop_mutex);
  i32 size = res->agop_size;
  free(res);

  return size;
}

/*------------------------------------------------------------------------------
    Function name : VCEncAddFillerNALU
    Description   : Add filler nalu
    Return type   : void
    Argument      : inst encoder instance, cnt payload size, byteStream byteStream
------------------------------------------------------------------------------*/
static void VCEncAddFillerNALU(VCEncInst inst, i32 cnt, true_e byteStream)
{
    struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;

    ASSERT(inst != NULL);
    ASSERT(&vcenc_instance->stream != NULL);

    i32 i = cnt;

    if(vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_H264)
        Jenc_H264NalUnitHdr(&vcenc_instance->stream, 0, H264_FILLERDATA, byteStream);
    else if(vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_HEVC)
        Jenc_HevcNalUnitHdr(&vcenc_instance->stream, FD_NUT, byteStream);

    for(; i > 0; i--)
    {
        Jenc_put_bit(&vcenc_instance->stream, 0xFF, 0x8);
    }

    Jenc_rbsp_trailing_bits(&vcenc_instance->stream);

}


/* Parameter set send handle */
static void VCEncParameterSetHandle(struct vcenc_instance *vcenc_instance, VCEncInst inst, const VCEncIn *pEncIn,
                                       VCEncOut *pEncOut, struct container *c)
{
  i32 tmp, i;/* tmp is to store temp byteCnt */

  if((pEncIn->resendVPS) && (vcenc_instance->codecFormat == VCENC_VIDEO_CODEC_HEVC))
  {
    struct Jenc_vps * v;

    v = (struct Jenc_vps *)Jenc_get_parameter_set(c, VPS_NUT, vcenc_instance->vps_id);
    v->ps.b = vcenc_instance->stream;
    tmp = vcenc_instance->stream.byteCnt;
    //Generate Jenc_vps
    Jenc_video_parameter_set(v, inst);

    //Update recorded streamSize and add new nal into buffer
    pEncOut->streamSize += vcenc_instance->stream.byteCnt-tmp;
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, vcenc_instance->stream.byteCnt-tmp);
    Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);

    tmp = vcenc_instance->stream.byteCnt;
    vcenc_instance->stream = v->ps.b;
    vcenc_instance->stream.byteCnt = tmp;
  }

  if(pEncIn->sendAUD)
  {
    tmp = vcenc_instance->stream.byteCnt;
    if(IS_H264(vcenc_instance->codecFormat))
    {
      Jenc_H264AccessUnitDelimiter(&vcenc_instance->stream,vcenc_instance->asic.regs.streamMode,pEncIn->codingType);
    }
    else
    {
      Jenc_HEVCAccessUnitDelimiter(&vcenc_instance->stream,vcenc_instance->asic.regs.streamMode,pEncIn->codingType);
    }
    pEncOut->streamSize += vcenc_instance->stream.byteCnt-tmp;
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, vcenc_instance->stream.byteCnt-tmp);
    Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);
  }

  bool update_pps_after_sps = 0;
  struct Jenc_sps * s_br = (struct Jenc_sps *)Jenc_get_parameter_set(c, SPS_NUT, vcenc_instance->sps_id);

  //BitRate has been rounded in Jenc_VCEncStrmStart().[WriteVui(),or H264WriteVui()] when hrd=1; BitRate is 0 when hrd = 0.
  u32 old_bitrate = s_br->vui.bitRate;

  //need to round new bitrate
  u32 new_bitrate = round_this_value((u32)vcenc_instance->rateControl.virtualBuffer.bitRate);

  i32 old_frame_rate_num = vcenc_instance->rateControl.virtualBuffer.timeScale;
  i32 old_frame_rate_denom = vcenc_instance->rateControl.virtualBuffer.unitsInTic;
  i32 new_frame_rate_num = vcenc_instance->rateControl.outRateNum*(vcenc_instance->interlaced+1);
  i32 new_frame_rate_denom = vcenc_instance->rateControl.outRateDenom;
  u32 old_hrd = vcenc_instance->rateControl.sei.hrd;//This hrd has not been update.
  u32 new_hrd = vcenc_instance->rateControl.hrd;//This value already has been update in Jenc_VCEncSetRateCtrl.

  if(old_bitrate == 0) //hrd == 0
  {
    s_br->vui.bitRate = new_bitrate;//save this value.
  }
  if(pEncIn->resendSPS ||
     ((new_bitrate != old_bitrate) && (old_bitrate != 0)) || //bitrate change
     (new_frame_rate_num != old_frame_rate_num || new_frame_rate_denom != old_frame_rate_denom) || //framerate change
     (new_hrd != old_hrd))//hrd conformance change
  {
    s_br->ps.b = vcenc_instance->stream;
    tmp = vcenc_instance->stream.byteCnt;

    Jenc_VCEncSpsSetVuiAspectRatio(s_br, vcenc_instance->sarWidth, vcenc_instance->sarHeight);
    Jenc_VCEncSpsSetVuiVideoInfo(s_br, vcenc_instance->vuiVideoFullRange);

    if(vcenc_instance->vuiVideoSignalTypePresentFlag)
      Jenc_VCEncSpsSetVuiSignalType(s_br, vcenc_instance->vuiVideoSignalTypePresentFlag, vcenc_instance->vuiVideoFormat, vcenc_instance->vuiVideoFullRange, vcenc_instance->vuiColorDescription.vuiColorDescripPresentFlag, vcenc_instance->vuiColorDescription.vuiColorPrimaries,
        vcenc_instance->vuiColorDescription.vuiTransferCharacteristics, vcenc_instance->vuiColorDescription.vuiMatrixCoefficients);

    if((new_bitrate != old_bitrate) && (old_bitrate != 0)) //bitrate change, update vui.
    {
      Jenc_VCEncSpsSetVuiHrd(s_br, vcenc_instance->rateControl.hrd);
      Jenc_VCEncSpsSetVuiHrdBitRate(s_br,vcenc_instance->rateControl.virtualBuffer.bitRate);
      Jenc_VCEncSpsSetVuiHrdCpbSize(s_br,vcenc_instance->rateControl.virtualBuffer.bufferSize);
      update_pps_after_sps = 1;
    }

    if(new_frame_rate_num != old_frame_rate_num || new_frame_rate_denom != old_frame_rate_denom)//frame rate change, update vui.
    {
      rcVirtualBuffer_s *vb = &vcenc_instance->rateControl.virtualBuffer;
      vb->timeScale = new_frame_rate_num;
      vb->unitsInTic = new_frame_rate_denom;
      if(pEncIn->vui_timing_info_enable)
      {
        Jenc_VCEncSpsSetVuiTimigInfo(s_br, vb->timeScale, vb->unitsInTic);
      }
      else
      {
        Jenc_VCEncSpsSetVuiTimigInfo(s_br, 0, 0);
      }
      update_pps_after_sps = 1;
    }
    if(new_hrd != old_hrd)//hrd change, update vui.
    {
      vcenc_instance->rateControl.sei.hrd = (u32)vcenc_instance->rateControl.hrd;
      Jenc_VCEncSpsSetVuiHrd(s_br, vcenc_instance->rateControl.hrd);
      update_pps_after_sps = 1;
    }
    Jenc_sequence_parameter_set(c, s_br, inst);

    pEncOut->streamSize += vcenc_instance->stream.byteCnt-tmp;
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, vcenc_instance->stream.byteCnt-tmp);
    Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);

    tmp = vcenc_instance->stream.byteCnt;
    vcenc_instance->stream = s_br->ps.b;
    vcenc_instance->stream.byteCnt = tmp;

  }

  if(pEncIn->resendPPS || update_pps_after_sps)
  {
    if(update_pps_after_sps)
      update_pps_after_sps = 0;
    struct Jenc_pps * p;
    for(i=0;i<=vcenc_instance->maxPPSId;i++)
    {
      p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, i);
      p->ps.b = vcenc_instance->stream;
      tmp = vcenc_instance->stream.byteCnt;
      //printf("byteCnt=%d\n",vcenc_instance->stream.byteCnt);
      Jenc_picture_parameter_set(p, inst);

      //printf("Jenc_pps inserted size=%d\n", vcenc_instance->stream.byteCnt-tmp);
      pEncOut->streamSize += vcenc_instance->stream.byteCnt-tmp;
      Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, vcenc_instance->stream.byteCnt-tmp);
      Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);

      tmp = vcenc_instance->stream.byteCnt;
      vcenc_instance->stream = p->ps.b;
      vcenc_instance->stream.byteCnt = tmp;
    }

  }

  if(vcenc_instance->insertNewPPS)
  {
    struct Jenc_pps * p;

    p = (struct Jenc_pps *)Jenc_get_parameter_set(c, PPS_NUT, vcenc_instance->insertNewPPSId);
    p->ps.b = vcenc_instance->stream;
    tmp = vcenc_instance->stream.byteCnt;
    //printf("byteCnt=%d\n",vcenc_instance->stream.byteCnt);
    Jenc_picture_parameter_set(p, inst);

    //printf("Jenc_pps inserted size=%d\n", vcenc_instance->stream.byteCnt-tmp);
    pEncOut->streamSize += vcenc_instance->stream.byteCnt-tmp;
    Jenc_hash(&vcenc_instance->hashctx, vcenc_instance->stream.stream, vcenc_instance->stream.byteCnt-tmp);
    Jenc_VCEncAddNaluSize(pEncOut, vcenc_instance->stream.byteCnt - tmp);

    //printf("Jenc_pps size=%d\n", *p->ps.b.cnt);
    tmp = vcenc_instance->stream.byteCnt;
    vcenc_instance->stream = p->ps.b;
    vcenc_instance->stream.byteCnt = tmp;

    //printf("byteCnt=%d\n",vcenc_instance->stream.byteCnt);
    vcenc_instance->insertNewPPS = 0;
  }
}

/*Get Dec400 VersionId*/
i32 Jenc_VCEncDec400GetVersionId(const void*wlInstance, i32* version_id)
{
  i32 ret = Jenc_Dec400GetVersionId(wlInstance,version_id);
  return ret;
}

u64 getMaxSBPS( VCEncVideoCodecFormat codecFormat , i32 levelIdx )
{
  ASSERT( levelIdx >= 0);
  i32 level   = MAX(0, levelIdx);
  u64 maxSBPS = 0;

  switch( codecFormat )
  {
    case VCENC_VIDEO_CODEC_HEVC:
      ASSERT( level < HEVC_LEVEL_NUM );
      level   = MIN( level, (HEVC_LEVEL_NUM - 1));
      maxSBPS = Jenc_VCEncMaxSBPSHevc[ level ];
      break;

    case VCENC_VIDEO_CODEC_H264:
      ASSERT( level < H264_LEVEL_NUM );
      level   = MIN( level, (H264_LEVEL_NUM - 1));
      maxSBPS = Jenc_VCEncMaxSBPSH264[ level ];
      break;

    case VCENC_VIDEO_CODEC_AV1:
      level   = MIN( level, (AV1_VALID_MAX_LEVEL - 1));
      maxSBPS = Jenc_VCEncMaxSBPSAV1[ level ];
      break;

    case VCENC_VIDEO_CODEC_VP9:
      level   = MIN( level, (VP9_VALID_MAX_LEVEL - 1));
      maxSBPS = Jenc_VCEncMaxSBPSVP9[ level ];
      break;

    default:
      break;
  }

  return maxSBPS;
}

u32 getMaxPicSize( VCEncVideoCodecFormat codecFormat , i32 levelIdx )
{
  ASSERT( levelIdx >= 0);
  i32 level      = MAX(0, levelIdx);
  u32 maxPicSize = 0;

  switch( codecFormat )
  {
    case VCENC_VIDEO_CODEC_HEVC:
      ASSERT( level < HEVC_LEVEL_NUM );
      level      = MIN( level, (HEVC_LEVEL_NUM - 1));
      maxPicSize = Jenc_VCEncMaxPicSizeHevc[ level ];
      break;

    case VCENC_VIDEO_CODEC_H264:
      ASSERT( level < H264_LEVEL_NUM );
      level      = MIN( level, (H264_LEVEL_NUM - 1));
      maxPicSize = Jenc_VCEncMaxFSH264[ level ];
      break;

    case VCENC_VIDEO_CODEC_AV1:
      level      = MIN( level, (AV1_VALID_MAX_LEVEL - 1));
      maxPicSize = Jenc_VCEncMaxPicSizeAV1[ level ];
      break;

    case VCENC_VIDEO_CODEC_VP9:
      level      = MIN( level, (VP9_VALID_MAX_LEVEL - 1));
      maxPicSize = Jenc_VCEncMaxPicSizeVP9[ level ];
      break;

    default:
      break;
  }

  return maxPicSize;
}

u32 getMaxCPBS( VCEncVideoCodecFormat codecFormat, i32 levelIdx, i32 profile, i32 tier )
{
  ASSERT( levelIdx >= 0);
  i32 level      = MAX(0, levelIdx);
  u32 maxCBPS    = 0;

  switch( codecFormat )
  {
    case VCENC_VIDEO_CODEC_HEVC:
      ASSERT( level < HEVC_LEVEL_NUM );
      level   = MIN( level, (HEVC_LEVEL_NUM - 1));
      maxCBPS = (tier == VCENC_HEVC_HIGH_TIER) ? Jenc_VCEncMaxCPBSHighTierHevc[ level ] : Jenc_VCEncMaxCPBSHevc[ level ];
      break;

    case VCENC_VIDEO_CODEC_H264:
      ASSERT( level < H264_LEVEL_NUM );
      level   = MIN( level, (H264_LEVEL_NUM - 1));
      float h264_high10_factor = 1;
      if(profile == 100)
        h264_high10_factor = 1.25;
      else if(profile == 110)
        h264_high10_factor = 3.0;
      maxCBPS = Jenc_VCEncMaxCPBSH264[ level ] * h264_high10_factor;
      break;

    case VCENC_VIDEO_CODEC_AV1:
      level   = MIN( level, (AV1_VALID_MAX_LEVEL - 1));
      maxCBPS = ((tier == VCENC_HEVC_HIGH_TIER)|| (level > 7)) ? Jenc_VCEncMaxCPBSHighTierAV1[ level ] : Jenc_VCEncMaxCPBSAV1[ level ];
      break;

    case VCENC_VIDEO_CODEC_VP9:
      level   = MIN( level, (VP9_VALID_MAX_LEVEL - 1));
      maxCBPS = Jenc_VCEncMaxCPBSVP9[ level ];
      break;

    default:
      break;
  }

  return maxCBPS;
}

u32 getMaxBR( VCEncVideoCodecFormat codecFormat , i32 levelIdx, i32 profile, i32 tier )
{
  ASSERT( levelIdx >= 0);
  i32 level      = MAX(0, levelIdx);
  u32 maxBR      = 0;

  switch( codecFormat )
  {
    case VCENC_VIDEO_CODEC_HEVC:
      ASSERT( level < HEVC_LEVEL_NUM );
      level   = MIN( level, (HEVC_LEVEL_NUM - 1));
      maxBR   = (tier == VCENC_HEVC_HIGH_TIER) ? Jenc_VCEncMaxCPBSHighTierHevc[ level ] : Jenc_VCEncMaxCPBSHevc[ level ];
      break;

    case VCENC_VIDEO_CODEC_H264:
      ASSERT( level < H264_LEVEL_NUM );
      level   = MIN( level, (H264_LEVEL_NUM - 1));
      float h264_high10_factor = 1;
      if(profile == 100)
        h264_high10_factor = 1.25;
      else if(profile == 110)
        h264_high10_factor = 3.0;
      maxBR   = Jenc_VCEncMaxBRH264[ level ] * h264_high10_factor;
      break;

    case VCENC_VIDEO_CODEC_AV1:
      level   = MIN( level, (AV1_VALID_MAX_LEVEL - 1));
      maxBR   = ((tier == VCENC_HEVC_HIGH_TIER)|| (level > 7)) ? Jenc_VCEncMaxCPBSHighTierAV1[ level ] : Jenc_VCEncMaxCPBSAV1[ level ];
      break;

    case VCENC_VIDEO_CODEC_VP9:
      level   = MIN( level, (VP9_VALID_MAX_LEVEL - 1));
      maxBR   = Jenc_VCEncMaxBRVP9[ level ];
      break;

    default:
      break;
  }

  return maxBR;
}

/** @} */

