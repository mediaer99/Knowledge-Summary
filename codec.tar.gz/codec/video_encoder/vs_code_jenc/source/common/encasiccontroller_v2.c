/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------
--
--  Description : ASIC low level controller
--
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    Include headers
------------------------------------------------------------------------------*/
#include "encpreprocess.h"
#include "encasiccontroller.h"
#include "enccommon.h"
#include "jenc_ewl.h"


/*------------------------------------------------------------------------------
    External compiler flags
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    Module defines
------------------------------------------------------------------------------*/

/* Mask fields */
#define mask_2b         (u32)0x00000003
#define mask_3b         (u32)0x00000007
#define mask_4b         (u32)0x0000000F
#define mask_5b         (u32)0x0000001F
#define mask_6b         (u32)0x0000003F
#define mask_11b        (u32)0x000007FF
#define mask_14b        (u32)0x00003FFF
#define mask_16b        (u32)0x0000FFFF

#define HSWREG(n)       ((n)*4)

/*------------------------------------------------------------------------------
    Local function prototypes
------------------------------------------------------------------------------*/
void Jenc_EncAsicGetSizeAndSetRegs(asicData_s *asic, asicMemAlloc_s *allocCfg,
                                          u32 *internalImageLumaSize, u32 *lumaSize,
                                          u32 *lumaSize4N, u32 *chromaSize, u32 *u32FrameContextSize)
{
    u32 width = allocCfg->width;
    u32 height = allocCfg->height;
    bool codecH264 = allocCfg->encodingType == ASIC_H264;
    u32 alignment = allocCfg->ref_alignment;
    u32 alignment_ch = allocCfg->ref_ch_alignment;
    regValues_s *regs = &asic->regs;
    u32 width_4n, height_4n;

    width = ((width + 63) >> 6) << 6;
    height = ((height + 63) >> 6) << 6;
    //width_4n = width / 4;
    width_4n = ((allocCfg->width + 15) / 16) * 4;
    height_4n = height / 4;

    asic->regs.recon_chroma_half_size = ((width * height)+(width * height)*(allocCfg->bitDepthLuma-8)/8) / 4;

    /* 6.0 software:  merge*/
    *u32FrameContextSize = (regs->codingType == ASIC_AV1) ? FRAME_CONTEXT_LENGTH : (regs->codingType == ASIC_VP9)? VP9_FRAME_CONTEXT_LENGTH : 0;
    if (HW_ID_MAJOR_NUMBER(asic->regs.asicHwId) == 0x60) /* VC8000E6.0 */
    {
      asic->regs.recon_chroma_half_size = (width * height + (width/4) * height_4n)*(allocCfg->bitDepthLuma) / 8 / 4;
      asic->regs.ref_frame_stride = STRIDE(STRIDE(width*4*allocCfg->bitDepthLuma/8,16),alignment);
      *lumaSize = STRIDE(width*4,alignment) * height/4+(width * height)*(allocCfg->bitDepthLuma-8)/8;
      *lumaSize4N = STRIDE(width_4n*4,alignment) * height_4n/4+(width_4n * height_4n)*(allocCfg->bitDepthLuma-8)/8;
      *internalImageLumaSize = *lumaSize + *lumaSize4N;
      *chromaSize = (alignment==1?*internalImageLumaSize/2:STRIDE(width*4,alignment) * height/4);
    }
    else
    {
  #ifdef RECON_REF_1KB_BURST_RW
      asic->regs.ref_frame_stride = STRIDE((STRIDE(width,128)*8),alignment);
      *lumaSize = asic->regs.ref_frame_stride * (height/(8/(allocCfg->bitDepthLuma/8)));
  #else
      asic->regs.ref_frame_stride = STRIDE(STRIDE(width*4*allocCfg->bitDepthLuma/8,16),alignment);
      *lumaSize = asic->regs.ref_frame_stride * height/4;
  #endif
      *lumaSize4N = STRIDE(STRIDE(width_4n*4*allocCfg->bitDepthLuma/8,16),alignment) * height_4n/4;
      *internalImageLumaSize = ((*lumaSize + *lumaSize4N + *u32FrameContextSize + 0xf) & (~0xf)) + 64*2;
      *internalImageLumaSize = STRIDE(*internalImageLumaSize, alignment);
      *chromaSize = *lumaSize/2;
  #ifdef RECON_REF_1KB_BURST_RW
      if(allocCfg->compressor & 2) {
        *chromaSize = STRIDE((width*4*allocCfg->bitDepthChroma/8), alignment_ch) * (height/8);
        asic->regs.recon_chroma_half_size = *chromaSize/2;
      }
  #endif
    }

}


/*------------------------------------------------------------------------------
    Local function prototypes
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------

    Jenc_EncAsicMemAlloc_V2

    Allocate HW/SW shared memory

    Input:
        asic        asicData structure
        width       width of encoded image, multiple of four
        height      height of encoded image
        numRefBuffs amount of reference luma frame buffers to be allocated

    Output:
        asic        base addresses point to allocated memory areas

    Return:
        ENCHW_OK        Success.
        ENCHW_NOK       Jenc_Error: memory allocation failed, no memories allocated
                        and EWL instance released

------------------------------------------------------------------------------*/
i32 Jenc_EncAsicMemAlloc_V2(asicData_s *asic, asicMemAlloc_s *allocCfg)
{
  u32  i;
  u32 width = allocCfg->width;
  u32 height = allocCfg->height;
  bool codecH264 = allocCfg->encodingType == ASIC_H264;
  u32 alignment = allocCfg->ref_alignment;
  u32 alignment_ch = allocCfg->ref_ch_alignment;
  regValues_s *regs;
  JENC_EWLLinearMem_t *buff = NULL;
  u32 internalImageLumaSize, u32FrameContextSize;
  u32 total_allocated_buffers;
  u32 width_4n, height_4n;
  u32 block_unit,block_size;
  u32 maxSliceNals;
  u32 log2_ctu_size = (codecH264?4:6);
  u32 ctu_size = (1<<log2_ctu_size);
  i32 ctb_per_row = ((width + ctu_size - 1) / ctu_size);
  i32 ctb_per_column = ((height + ctu_size - 1) / ctu_size);
  i32 ctb_per_picture = ctb_per_row * ctb_per_column;

  ASSERT(asic != NULL);
  ASSERT(width != 0);
  ASSERT(height != 0);
  ASSERT((height % 2) == 0);
  ASSERT((width % 2) == 0);
  //scaledWidth=((scaledWidth+7)/8)*8;
  regs = &asic->regs;

  regs->codingType = allocCfg->encodingType;

 if(allocCfg->encodingType == ASIC_JPEG || allocCfg->encodingType == ASIC_CUTREE)
    return ENCHW_OK;

  /*
    allocate scan coeff buffer before reference frame to avoid roimap overeading(64~1536 bytes) hit reference frame:
    reference frame could be in DEC400(1024B burst size)
   */
  for (i = 0; i < MAX_CORE_NUM; i++)
  {
    asic->compress_coeff_SACN[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
    if(allocCfg->is_malloc) {
      if (JencEWLMallocLinear(asic->ewl, 288 * 1024 / 8,alignment,
            &asic->compress_coeff_SACN[i]) != EWL_OK)
      {
        Jenc_EncAsicMemFree_V2(asic);
        return ENCHW_NOK;
      }
    }
  }

  ASSERT(allocCfg->numRefBuffsLum < ASIC_FRAME_BUF_LUM_MAX);
  total_allocated_buffers = allocCfg->numRefBuffsLum + 1;

  if(allocCfg->tmvpEnable && allocCfg->encodingType == ASIC_VP9)
    total_allocated_buffers += 1; //For VP9 TMVP

  width = ((width + 63) >> 6) << 6;
  height = ((height + 63) >> 6) << 6;
  //width_4n = width / 4;
  width_4n = ((allocCfg->width + 15) / 16) * 4;
  height_4n = height / 4;

  /* 6.0 software:  merge*/
  u32 lumaSize = 0;
  u32 lumaSize4N = 0;
  u32 chromaSize = 0;

  Jenc_EncAsicGetSizeAndSetRegs(asic, allocCfg, &internalImageLumaSize, &lumaSize, &lumaSize4N, &chromaSize, &u32FrameContextSize);

  {

    for (i = 0; i < total_allocated_buffers; i++)
    {
      if(!allocCfg->exteralReconAlloc)
      {
        asic->internalreconLuma[i].mem_type = EWL_MEM_TYPE_DPB;
        if(allocCfg->is_malloc) {
          if (JencEWLMallocRefFrm(asic->ewl, internalImageLumaSize,alignment,
                              &asic->internalreconLuma[i]) != EWL_OK)
          {
            Jenc_EncAsicMemFree_V2(asic);
            return ENCHW_NOK;
          }
        }

        asic->internalreconLuma_4n[i].busAddress = asic->internalreconLuma[i].busAddress + lumaSize;
        asic->internalreconLuma_4n[i].size = lumaSize4N;
        asic->internalAv1FrameContext[i].busAddress = asic->internalreconLuma[i].busAddress + lumaSize + lumaSize4N;
        asic->internalAv1FrameContext[i].virtualAddress = (u32 *)((ptr_t)asic->internalreconLuma[i].virtualAddress + lumaSize + lumaSize4N);
        asic->internalAv1FrameContext[i].size       = u32FrameContextSize;
      }
    }

    for (i = 0; i < total_allocated_buffers; i++)
    {
      if(!allocCfg->exteralReconAlloc)
      {
        asic->internalreconChroma[i].mem_type = EWL_MEM_TYPE_DPB;
        if(allocCfg->is_malloc) {
          if (JencEWLMallocRefFrm(asic->ewl, chromaSize,alignment_ch,
                              &asic->internalreconChroma[i]) != EWL_OK)
          {
            Jenc_EncAsicMemFree_V2(asic);
            return ENCHW_NOK;
          }
        }
      }

    }

    asic->regs.ref_ds_luma_stride = STRIDE(STRIDE(width_4n*4*allocCfg->bitDepthLuma/8,16),alignment);
    asic->regs.ref_frame_stride_ch = STRIDE((width*4*allocCfg->bitDepthChroma/8), alignment_ch);

    /*  VP9: The table is used for probability tables, 1208 bytes. */
    if (regs->codingType == ASIC_VP9)
    {
      i = 8 * 55 + 8 * 96;
      asic->cabacCtx.mem_type = EWL_MEM_TYPE_VPU_WORKING;
      if(allocCfg->is_malloc) {
        if (JencEWLMallocLinear(asic->ewl, i,0, &asic->cabacCtx) != EWL_OK)
        {
          Jenc_EncAsicMemFree_V2(asic);
          return ENCHW_NOK;
        }
      }
    }

    regs->cabacCtxBase = asic->cabacCtx.busAddress;

    if (regs->codingType == ASIC_VP9)
    {
      /* VP9: Table of counter for probability updates. */
      asic->probCount.mem_type = EWL_MEM_TYPE_VPU_WORKING;
      if(allocCfg->is_malloc) {
        if (JencEWLMallocLinear(asic->ewl, ASIC_VP9_PROB_COUNT_SIZE,0,
                            &asic->probCount) != EWL_OK)
        {
          Jenc_EncAsicMemFree_V2(asic);
          return ENCHW_NOK;
        }
      }
      regs->probCountBase = asic->probCount.busAddress;

    }

    /* NAL size table, table size must be 64-bit multiple,
     * space for SEI, MVC prefix, filler and zero at the end of table.
     * Atleast 1 macroblock row in every slice.
     */
    maxSliceNals = (height + 15) / 16;
    if (codecH264 && (allocCfg->maxTemporalLayers > 1))
      maxSliceNals *= 2;
    asic->sizeTblSize = STRIDE((((sizeof(u32) * (maxSliceNals + 1) + 7) & (~7)) + (sizeof(u32) * 10)), alignment);

    for (i = 0; i < MAX_CORE_NUM; i++)
    {
      buff = &asic->sizeTbl[i];
      buff->mem_type = EWL_MEM_TYPE_VPU_WORKING;
      if(allocCfg->is_malloc) {
        if (JencEWLMallocLinear(asic->ewl, asic->sizeTblSize,alignment, buff) != EWL_OK)
        {
          Jenc_EncAsicMemFree_V2(asic);
          return ENCHW_NOK;
        }
      }
    }

    /* Ctb RC*/
    if(allocCfg->ctbRcMode & 2)
    {
      i32 ctbRcMadsize = width*height/ctu_size/ctu_size; // 1 byte per ctb
      for (i = 0; i < CTB_RC_BUF_NUM; i ++)
      {
        asic->ctbRcMem[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
        if(allocCfg->is_malloc) {
          if (JencEWLMallocLinear(asic->ewl, ctbRcMadsize, alignment, &(asic->ctbRcMem[i])) != EWL_OK)
          {
            Jenc_EncAsicMemFree_V2(asic);
            return ENCHW_NOK;
          }
        }
      }
    }

    //allocate compressor table
    if (allocCfg->compressor)
    {
      u32 tblLumaSize = 0;
      u32 tblChromaSize = 0;
      u32 tblSize = 0;
      if (allocCfg->compressor & 1)
      {
        tblLumaSize = ((width + 63) / 64) * ((height + 63) / 64) * 8; //ctu_num * 8
        tblLumaSize = ((tblLumaSize + 15) >> 4) << 4;
      }
      if (allocCfg->compressor & 2)
      {
        int cbs_w = ((width >> 1) + 7) / 8;
        int cbs_h = ((height >> 1) + 3) / 4;
        int cbsg_w = (cbs_w + 15) / 16;
        tblChromaSize = cbsg_w * cbs_h * 16;
      }

      tblSize = tblLumaSize + tblChromaSize;

      for (i = 0; i < total_allocated_buffers; i++)
      {
        if(!allocCfg->exteralReconAlloc)
        {
          asic->compressTbl[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
          if(allocCfg->is_malloc) {
            if (JencEWLMallocLinear(asic->ewl, tblSize, alignment,&asic->compressTbl[i]) != EWL_OK)
            {
              Jenc_EncAsicMemFree_V2(asic);
              return ENCHW_NOK;
            }
          }
        }
      }
    }

    //allocate collocated buffer for H.264
    if (codecH264)
    {
      // 4 bits per mb, 2 mbs per struct h264_mb_col
      u32 bufSize = (ctb_per_picture+1)/2*sizeof(struct h264_mb_col);

      for (i = 0; i < total_allocated_buffers; i++)
      {
        if(!allocCfg->exteralReconAlloc)
        {
          asic->colBuffer[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
          if(allocCfg->is_malloc) {
            if (JencEWLMallocLinear(asic->ewl, bufSize, alignment,&asic->colBuffer[i]) != EWL_OK)
            {
              Jenc_EncAsicMemFree_V2(asic);
              return ENCHW_NOK;
            }
          }
        }
      }
    }

    /* allocate mv info buffer for tmvp */
    if (allocCfg->tmvpEnable)
    {
      /* for every 4x4:
         2 bits pred direction + 2 bits pred mode + mv(m_iHor + m_iVer)*/
      u32 bufSize = (width /4) * (height / 4) * sizeof(struct MvInfo);
      for (i = 0; i < total_allocated_buffers; i++)
      {
        if (!allocCfg->exteralReconAlloc)
        {
          asic->mvInfo[i].mem_type = EWL_MEM_TYPE_VPU_ONLY;
          if(allocCfg->is_malloc) {
            if (JencEWLMallocLinear(asic->ewl, bufSize, alignment,&asic->mvInfo[i]) != EWL_OK)
            {
              Jenc_EncAsicMemFree_V2(asic);
              return ENCHW_NOK;
            }
          }
        }
      }
    }

    //allocation CU infomation memory
    if (allocCfg->outputCuInfo)
    {
      i32 cuInfoSizes[] = {CU_INFO_OUTPUT_SIZE, CU_INFO_OUTPUT_SIZE_V1, CU_INFO_OUTPUT_SIZE_V2, CU_INFO_OUTPUT_SIZE_V3};
      i32 ctuNum = (width >> log2_ctu_size) * (height >> log2_ctu_size);
      i32 maxCuNum = ctuNum * (ctu_size/8)*(ctu_size/8);
      i32 cuInfoVersion = regs->asicCfg.cuInforVersion;
      if(cuInfoVersion == 2)
        cuInfoVersion = (regs->asicCfg.bMultiPassSupport && allocCfg->pass == 1 ? cuInfoVersion : 1);
      i32 infoSizePerCu = cuInfoSizes[cuInfoVersion];
      i32 cuInfoTblSize = ctuNum * CU_INFO_TABLE_ITEM_SIZE;
      i32 cuInfoSize = maxCuNum * infoSizePerCu;
      i32 cuInfoTotalSize = 0;
      i32 widthInUnit = (allocCfg->width + 15) / 16;
      i32 heightInUnit =  (allocCfg->height + 15) / 16;
      i32 aqInfoStride = 0;
      i32 aqInfoSize = 0;
      if(cuInfoVersion == 2)
      {
        aqInfoStride = STRIDE(widthInUnit * sizeof(uint32_t), allocCfg->aqInfoAlignment);
        aqInfoSize = (heightInUnit + 1) * aqInfoStride; // extra row for avgAdj & strength
      }

      cuInfoTblSize = ((cuInfoTblSize + 63) >> 6) << 6;
      cuInfoSize = ((cuInfoSize + 63) >> 6) << 6;
      cuInfoTotalSize = cuInfoTblSize + aqInfoSize + cuInfoSize;
      asic->cuInfoTableSize = cuInfoTblSize;
      asic->aqInfoSize = aqInfoSize;
      asic->aqInfoStride = aqInfoStride;

      if(!allocCfg->exteralReconAlloc)
      {
        asic->cuInfoMem[0].mem_type = EWL_MEM_TYPE_VPU_WORKING;
        if(allocCfg->is_malloc) {
          if (JencEWLMallocLinear(asic->ewl, cuInfoTotalSize*allocCfg->numCuInfoBuf, alignment,&asic->cuInfoMem[0]) != EWL_OK)
          {
            Jenc_EncAsicMemFree_V2(asic);
            return ENCHW_NOK;
          }
        }
        i32 total_size = asic->cuInfoMem[0].size;
        for (i = 0; i < allocCfg->numCuInfoBuf; i++)
        {
          asic->cuInfoMem[i].virtualAddress = (u32*)((ptr_t)asic->cuInfoMem[0].virtualAddress + i*cuInfoTotalSize);
          asic->cuInfoMem[i].busAddress = asic->cuInfoMem[0].busAddress + i*cuInfoTotalSize;
          asic->cuInfoMem[i].size = (i < allocCfg->numCuInfoBuf-1 ? cuInfoTotalSize : total_size - (allocCfg->numCuInfoBuf-1)*cuInfoTotalSize);
        }
      }
    }

    /* Allocate ctb encoded bits memory */
    if(allocCfg->outputCtbBits)
    {
      /* 2bytes per ctb to store bits info */
      i32 ctbBitsSize = ctb_per_picture * 2;

      for (i = 0; i < allocCfg->numCtbBitsBuf; i++)
      {
        buff = &asic->ctbBitsMem[i];
        buff->mem_type = EWL_MEM_TYPE_VPU_WORKING;
        if(allocCfg->is_malloc) {
          if (JencEWLMallocLinear(asic->ewl, ctbBitsSize, alignment, buff) != EWL_OK)
          {
            Jenc_EncAsicMemFree_V2(asic);
            return ENCHW_NOK;
          }
        }
      }
    }

  }
  return ENCHW_OK;
}

/*------------------------------------------------------------------------------

    Jenc_EncAsicMemFree_V2

    Free HW/SW shared memory

------------------------------------------------------------------------------*/
void Jenc_EncAsicMemFree_V2(asicData_s *asic)
{
  i32 i;

  ASSERT(asic != NULL);
  ASSERT(asic->ewl != NULL);

  for (i = 0; i < ASIC_FRAME_BUF_LUM_MAX; i++)
  {
    if (EWL_DEVMEM_VAILD(asic->internalreconLuma[i]))
      JencEWLFreeRefFrm(asic->ewl, &asic->internalreconLuma[i]);
    asic->internalreconLuma[i].virtualAddress = NULL;

    if (EWL_DEVMEM_VAILD(asic->internalreconChroma[i]))
      JencEWLFreeRefFrm(asic->ewl, &asic->internalreconChroma[i]);
    asic->internalreconChroma[i].virtualAddress = NULL;

    if (asic->compressTbl[i].virtualAddress != NULL)
      JencEWLFreeRefFrm(asic->ewl, &asic->compressTbl[i]);
    asic->compressTbl[i].virtualAddress = NULL;

    if (asic->colBuffer[i].virtualAddress != NULL)
      JencEWLFreeRefFrm(asic->ewl, &asic->colBuffer[i]);
    asic->colBuffer[i].virtualAddress = NULL;

    if (asic->mvInfo[i].virtualAddress != NULL)
      JencEWLFreeRefFrm(asic->ewl, &asic->mvInfo[i]);
    asic->mvInfo[i].virtualAddress = NULL;
  }

  if (asic->cuInfoMem[0].virtualAddress != NULL) {
    for (i = 1; i < ASIC_FRAME_BUF_CUINFO_MAX; i ++)
    {
      if(asic->cuInfoMem[i].virtualAddress)
        asic->cuInfoMem[0].size += asic->cuInfoMem[i].size;
      asic->cuInfoMem[i].virtualAddress = NULL;
    }
    JencEWLFreeRefFrm(asic->ewl, &asic->cuInfoMem[0]);
    asic->cuInfoMem[0].virtualAddress = NULL;
  }

  for (i = 0; i < MAX_CORE_NUM; i ++)
  {
    if(asic->ctbBitsMem[i].virtualAddress)
      JencEWLFreeRefFrm(asic->ewl, &asic->ctbBitsMem[i]);
    asic->ctbBitsMem[i].virtualAddress = NULL;
  }

  if (asic->cabacCtx.virtualAddress != NULL)
    JencEWLFreeLinear(asic->ewl, &asic->cabacCtx);

  if (asic->probCount.virtualAddress != NULL)
    JencEWLFreeLinear(asic->ewl, &asic->probCount);

  for (i = 0; i < MAX_CORE_NUM; i++)
  {
    if(asic->compress_coeff_SACN[i].virtualAddress != NULL)
      JencEWLFreeLinear(asic->ewl, &asic->compress_coeff_SACN[i]);

    if (asic->sizeTbl[i].virtualAddress != NULL)
      JencEWLFreeLinear(asic->ewl, &asic->sizeTbl[i]);
    asic->sizeTbl[i].virtualAddress = NULL;
  }

  for (i = 0; i < 4; i ++)
  {
    if (asic->ctbRcMem[i].virtualAddress != NULL)
      JencEWLFreeLinear(asic->ewl, &(asic->ctbRcMem[i]));
    asic->ctbRcMem[i].virtualAddress = NULL;
  }

  if (EWL_DEVMEM_VAILD(asic->loopbackLineBufMem))
    JencEWLFreeLinear(asic->ewl, &asic->loopbackLineBufMem);
  asic->loopbackLineBufMem.virtualAddress = NULL;

  asic->cabacCtx.virtualAddress = NULL;
  asic->mvOutput.virtualAddress = NULL;
  asic->probCount.virtualAddress = NULL;
  asic->segmentMap.virtualAddress = NULL;
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
i32 Jenc_EncAsicCheckStatus_V2(asicData_s *asic,u32 status)
{
  i32 ret;
  u32 dumpRegister = asic->dumpRegister;

  status &= ASIC_STATUS_ALL;

  if (status & ASIC_STATUS_ERROR)
  {
    /* Get registers for debugging */
    JencEncAsicGetRegisters(asic->ewl, &asic->regs, dumpRegister, 1);
    ret = ASIC_STATUS_ERROR;
  }
  else if (status & ASIC_STATUS_FUSE_ERROR)
  {
    /* Get registers for debugging */
    JencEncAsicGetRegisters(asic->ewl, &asic->regs, dumpRegister, 1);
    ret = ASIC_STATUS_ERROR;
  }
  else if (status & ASIC_STATUS_HW_TIMEOUT)
  {
    /* Get registers for debugging */
    JencEncAsicGetRegisters(asic->ewl, &asic->regs, dumpRegister, 1);
    ret = ASIC_STATUS_HW_TIMEOUT;
  }
  else if (status & ASIC_STATUS_FRAME_READY)
  {
    /* read out all register */
    JencEncAsicGetRegisters(asic->ewl, &asic->regs, dumpRegister, 1);
    ret = ASIC_STATUS_FRAME_READY;
  }
  else if (status & ASIC_STATUS_BUFF_FULL)
  {
    /* ASIC doesn't support recovery from buffer full situation,
     * at the same time with buff full ASIC also resets itself. */
    ret = ASIC_STATUS_BUFF_FULL;
  }
  else if (status & ASIC_STATUS_HW_RESET)
  {
    ret = ASIC_STATUS_HW_RESET;
  }
  else if (status & ASIC_STATUS_SEGMENT_READY)
  {
    ret = ASIC_STATUS_SEGMENT_READY;
  }
  else
  {
    ret = status;
  }

  return ret;
}
