/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#ifndef TOOLS_H
#define TOOLS_H

#include "base_type.h"
#include "vsi_queue.h"

typedef struct
{
  u8 *stream;
  u32 cache;
  u32 bit_cnt;
  u32 accu_bits;
} bits_buffer_s;

i32 Jenc_vs_log2i(i32 x, i32 *result);
i32 Jenc_checkRange(i32 x, i32 min, i32 max);
void **Jenc_malloc_array(struct queue *q, i32 r, i32 c, i32 size);
void *Jenc_qalloc(struct queue *q, i32 nmemb, i32 size);
void Jenc_qfree(struct queue *q);
i32 Jenc_get_value (bits_buffer_s *b, i32 number, bool bSigned);
void Jenc_get_align (bits_buffer_s *b, u32 bytes);
char *Jenc_nextIntToken (char *str, i16 *ret);
i32 Jenc_getGMVRange (i16 *maxX, i16 *maxY, i32 rangeCfg, i32 isH264, i32 isBSlice);
i32 Jenc_tile_log2(i32 blk_size, i32 target);
int Jenc_clamp(int value, int low, int high);
int64_t Jenc_clamp64(int64_t value, int64_t low, int64_t high);
double Jenc_fclamp(double value, double low, double high) ;

#endif
