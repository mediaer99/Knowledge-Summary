/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#include "base_type.h"
#include "vsi_queue.h"
#include "osal.h"

/*------------------------------------------------------------------------------
  Jenc_queue_init
------------------------------------------------------------------------------*/
void Jenc_queue_init(struct queue *queue)
{
  queue->head = NULL;
  queue->tail = NULL;
}

/*------------------------------------------------------------------------------
  Jenc_queue_put
------------------------------------------------------------------------------*/
void Jenc_queue_put(struct queue *queue, struct node *node)
{
  node->next = NULL;
  if (queue->head)
  {
    queue->head->next = node;
    queue->head = node;
  }
  else
  {
    queue->tail = node;
    queue->head = node;
  }
}

/*------------------------------------------------------------------------------
  Jenc_queue_put_tail
------------------------------------------------------------------------------*/
void Jenc_queue_put_tail(struct queue *queue, struct node *node)
{
  if (queue->tail)
  {
    node->next = queue->tail;
    queue->tail = node;
  }
  else
  {
    node->next = NULL;
    queue->tail = node;
    queue->head = node;
  }
}

/*------------------------------------------------------------------------------
  Jenc_queue_get
------------------------------------------------------------------------------*/
struct node *Jenc_queue_get(struct queue *queue)
{
  struct node *node = queue->tail;

  if (!node) return NULL;     /* Empty queue */

  if (queue->head == queue->tail)   /* The last node */
  {
    queue->head = NULL;
  }
  queue->tail = node->next;

  return node;
}

/*------------------------------------------------------------------------------
  Jenc_queue_tail
------------------------------------------------------------------------------*/
struct node *Jenc_queue_tail(struct queue *queue)
{
  return queue->tail;
}

/*------------------------------------------------------------------------------
  Jenc_queue_remove
------------------------------------------------------------------------------*/
void Jenc_queue_remove(struct queue *queue, struct node *node)
{
  struct node *prev, *p;

  /* Less than one node left is special case */
  if (queue->tail == queue->head)
  {
    if (queue->head == node)
    {
      Jenc_queue_init(queue);
    }
    return;
  }

  for (prev = p = queue->tail; p; p = p->next)
  {
    if (p == node)
    {
      prev->next = p->next;
      if (queue->head == node) queue->head = prev;
      if (queue->tail == node) queue->tail = p->next;
      break;
    }
    prev = p;
  }
}

/*------------------------------------------------------------------------------
  Jenc_free_nodes
------------------------------------------------------------------------------*/
void Jenc_free_nodes(struct node *tail)
{
  struct node *node;

  while (tail)
  {
    node = tail;
    tail = tail->next;
    free(node);
  }
}
