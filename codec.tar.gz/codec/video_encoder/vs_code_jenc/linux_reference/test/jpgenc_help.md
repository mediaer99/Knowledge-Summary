# Options in Testbench for VC8000E JPEG

./jpeg_testenc [options] -i inputfile

## General Usage

```
  -H    --help              Display this help.
```

## Parameters affecting input frame and encoded frame resolutions and cropping:

```
  -i[s] --input             Read input from file. [input.yuv]
  -I[s] --inputThumb        Read thumbnail input from file. [thumbnail.jpg]
  -o[s] --output            Write output to file. [stream.jpg]
  -a[n] --firstPic          First picture of input file. [0]
  -b[n] --lastPic           Last picture of input file. [0]
  -w[n] --lumWidthSrc       Width of source image. [176]
  -h[n] --lumHeightSrc      Height of source image. [144]
  -x[n] --width             Width of output image. [--lumWidthSrc]
  -y[n] --height            Height of output image. [--lumHeightSrc]
  -X[n] --horOffsetSrc      Output image horizontal offset. [0]
  -Y[n] --verOffsetSrc      Output image vertical offset. [0]
  -W[n] --write             0=NO, 1=YES write output. [1]
```

## Parameters for pre-processing frames before encoding:

```
  -g[n] --frameType         Input YUV format. [0]
                               0 - YUV420 planar CbCr (IYUV/I420)
                               1 - YUV420 semi-planar CbCr (NV12)
                               2 - YUV420 semi-planar CrCb (NV21)
                               3 - YUYV422 interleaved (YUYV/YUY2)
                               4 - UYVY422 interleaved (UYVY/Y422)
                               5 - RGB565 16bpp
                               6 - BGR565 16bpp
                               7 - RGB555 16bpp
                               8 - BGR555 16bpp
                               9 - RGB444 16bpp
                               10 - BGR444 16bpp
                               11 - RGB888 32bpp
                               12 - BGR888 32bpp
                               13 - RGB101010 32bpp
                               15 - YUV420 10 bit planar CbCr (I010)
                               16 - YUV420 10 bit planar CbCr (P010)
                               19 - YUV420 customer private tile for HEVC
                               20 - YUV420 customer private tile for H.264
                               21 - YUV420 semiplanar CbCr customer private tile
                               22 - YUV420 semiplanar CrCb customer private tile
                               23 - YUV420 P010 customer private tile
                               37 - YVU420 8 bit planar CrCb 
                               38 - YUV420 FBC 8 bit 64x2 tile
  -v[n] --colorConversion   RGB to YCbCr color conversion type. [0]
                               0 - ITU-R BT.601, RGB limited [16...235] (BT601_l.mat)
                               1 - ITU-R BT.709, RGB limited [16...235] (BT709_l.mat)
                               2 - User defined, coefficients defined in test bench.
                               3 - ITU-R BT.2020
                               4 - ITU-R BT.601, RGB full [0...255] (BT601_f.mat)
                               5 - ITU-R BT.601, RGB limited [0...219] (BT601_219.mat)
                               6 - ITU-R BT.709, RGB full [0...255] (BT709_f.mat)
  -G[n] --rotation          Rotate input image. [0]
                               0 - disabled
                               1 - 90 degrees right
                               2 - 90 degrees left
                               3 - 180 degrees
  -M[n]  --mirror           Mirror input image. [0]
                               0 - disabled horizontal mirror
                               1 - enable horizontal mirror
  -Q[n]  --inputAlignmentExp Alignment value of input frame buffer. [4]
                               0 = Disable alignment 
                               4..12 = Base address of input frame buffer and each line are aligned to 2^inputAlignmentExp 
        );
    fprintf(stdout,
  -d[n] --enableConstChroma   0..1 Enable/Disable setting chroma to a constant pixel value. [0]
                                 0 = Disable. 
                                 1 = Enable. 
  -e[n] --constCb             0..255. The constant pixel value for Cb. [128]
  -f[n] --constCr             0..255. The constant pixel value for Cr. [128]
```

## Parameters affecting the output stream and encoding tools:

```
  -R[n] --restartInterval   Restart interval in MCU rows. [0]
  -q[n] --qLevel            0..10, quantization scale. [1]
                            10 = use testbench defined qtable
  -p[n] --codingType        0=whole frame, 1=partial frame encoding. [0]
  -m[n] --codingMode        0=YUV420, 1=YUV422, 2=Monochrome [0]
  -t[n] --markerType        Quantization/Huffman table markers. [0]
                               0 = Single marker
                               1 = Multiple markers
  -u[n] --units             Units type of x- and y-density. [0]
                               0 = pixel aspect ratio
                               1 = dots/inch
                               2 = dots/cm
  -k[n] --xdensity          Xdensity to APP0 header. [1]
  -l[n] --ydensity          Ydensity to APP0 header. [1]
        --streamBufChain    Enable two output stream buffers. [0]
                               0 - Single output stream buffer.
                               1 - Two output stream buffers chained together.
                            Note the minimum allowable size of the first stream buffer is 1k bytes + thumbnail data size if any.

  -T[n] --thumbnail         0=NO, 1=JPEG, 2=RGB8, 3=RGB24 Thumbnail to stream. [0]
  -K[n] --widthThumb        Width of thumbnail output image. [32]
  -L[n] --heightThumb       Height of thumbnail output image. [32]
  -c[n] --comLength         Comment header data length. [0]
  -C[s] --comFile           Comment header data file. [com.txt]);
```

## Parameters affecting stream multi-segment output:

```
        --streamMultiSegmentMode 0..2 Stream multi-segment mode control. [0]
                                 0 = Disable stream multi-segment.
                                 1 = Enable. No SW handshaking. Loop-back enabled.
                                 2 = Enable. SW handshaking. Loop-back enabled.
        --streamMultiSegmentAmount 2..16. the total amount of segments to control loopback/sw-handshake/IRQ. [4]
```

## Parameters affecting lossless encoding:

```
        --lossless          0=lossy, 1~7 Enalbe lossless with prediction select mode n [0]
        --ptrans            0..7 Point transform value for lossless encoding. [0]);
```

## Parameters affecting the low latency mode:

```
  -S[n] --inputLineBufferMode 0..4. Input buffer mode control (Line-Buffer Mode). [0]
                                 0 = Disable input line buffer. 
                                 1 = Enable. SW handshaking. Loopback enabled.
                                 2 = Enable. HW handshaking. Loopback enabled.
                                 3 = Enable. SW handshaking. Loopback disabled.
                                 4 = Enable. HW handshaking. Loopback disabled.
  -N[n] --inputLineBufferDepth 0..511 The number of MCU rows to control loop-back/handshaking [1]
                                 Control loop-back mode if it is enabled:
                                   There are two continuous ping-pong input buffers; each contains inputLineBufferDepth MCU rows.
                                 Control hardware handshaking if it is enabled:
                                   Handshaking signal is processed per inputLineBufferDepth CTB/MB rows.
                                 Control software handshaking if it is enabled:
                                   IRQ is sent and Read Count Register is updated every time inputLineBufferDepth MCU rows have been read.
                                 0 is only allowed with inputLineBufferMode = 3, IRQ won't be sent and Read Count Register won't be updated.
  -s[n] --inputLineBufferAmountPerLoopback 0..1023. Handshake sync amount for every loopback [0]);
```

## Parameters affecting Motion JPEG, rate control, JPEG bitsPerPic:

```
  -J[n] --mjpeg             Enable Motion JPEG[0]
                               0 = Disable motion JPEG.
                               1 = Enable motion JPEG.
  -B[n] --bitPerSecond      Target bit per second. [0]
                               0 - RC OFF
                               none zero - RC ON
  -n[n] --frameRateNum      1..1048575 Output picture rate numerator. [30]
  -r[n] --frameRateDenom    1..1048575 Output picture rate denominator. [1]
  -V[n] --rcMode            0..2, JPEG/MJPEG RC mode. [1]
                               0 = single frame RC mode. 
                               1 = video RC with CBR. 
                               2 = video RC with VBR. 
  -U[n:m] --picQpDeltaRange Min:Max. Qp Delta range in picture-level rate control.
                               Min: -10..-1 Minimum Qp_Delta in picture RC. [-2]
                               Max:  1..10  Maximum Qp_Delta in picture RC. [3]
                               This range only applies to two neighboring frames.
  -E[n] --qpMin             0..51, Minimum frame qp. [0]
  -F[n] --qpMax             0..51, Maxmum frame qp. [51]
  -O[n] --fixedQP           -1..51, Fixed qp for every frame. [-1]
                               -1 = disable fixed qp mode
                               0-51 = value of fixed qp.
```

## Parameters for DEC400 compressed table(tile status):

```
  --dec400TableInput            Read input DEC400 compressed table from file. [dec400CompTableinput.bin]

```

## Testing parameters that are not supported for end-user:

```
  -P[n] --trigger           Logic Analyzer trigger at picture <n>. [-1]
                            -1 = Disable the trigger.
  -D[n] --XformCustomerPrivateFormat    -1..4 Convert YUV420 to customer private format. [-1]
                               -1 - No conversion to customer private format
                               0 - customer private tile format for HEVC
                               1 - customer private tile format for H.264
                               2 - customer private YUV422_888
                               3 - common data 8-bit tile 4x4
                               4 - common data 10-bit tile 4x4
                               5 - customer private tile format for JPEG
  --osdDec400TableInput            Read osd input DEC400 compressed table from file. [osdDec400CompTableinput.bin]
```

## Parameters for OSD overlay controls (i should be a number from 1 to 8):

```
  --overlayEnables             8 bits indicate enable for 8 overlay region. [0]
                                   1: region 1 enabled
                                   2: region 2 enabled
                                   3: region 1 and 2 enabled
                                   and so on.
  --olInputi                   input file for overlay region 1-8. [olInputi.yuv]
                                   for example --olInput1
  --olFormati                  0..1 Specify the overlay input format. [0]
                                   0: ARGB8888
                                   1: NV12
  --olAlphai                   0..255 Specify a global alpha value for NV12 overlay format. [0]
  --olWidthi                   Width of overlay region. Must be set if region enabled. [0]
  --olHeighti                  Height of overlay region. Must be set if region enabled. [0]
  --olXoffseti                 Horizontal offset of overlay region top left pixel. [0]
                                   must be under 2 aligned condition. [0]
  --olYoffseti                 Vertical offset of overlay region top left pixel. [0]
                                   must be under 2 aligned condition. [0]
  --olYStridei                 Luma stride in bytes. Default value is based on format.
                                   [olWidthi * 4] if ARGB888.
                                   [olWidthi] if NV12.
  --olUVStridei                Chroma stride in bytes. Default value is based on luma stride.
  --olCropXoffseti             OSD cropping top left horizontal offset. [0]
                                   must be under 2 aligned condition. [0]
  --olCropYoffseti             OSD cropping top left vertical offset. [0]
                                   must be under 2 aligned condition. [0]
  --olCropWidthi               OSD cropping width. [olWidthi]
  --olCropHeighti              OSD cropping height. [olHeighti]
```

## Parameters for AXI:

```
  --AXIAlignment               AXI alignment setting (in hexadecimal format). [0]
                                   bit[31:28] AXI_burst_align_wr_common
                                   bit[27:24] AXI_burst_align_wr_stream
                                   bit[23:20] AXI_burst_align_wr_chroma_ref
                                   bit[19:16] AXI_burst_align_wr_luma_ref
                                   bit[15:12] AXI_burst_align_rd_common
                                   bit[11: 8] AXI_burst_align_rd_prp
                                   bit[ 7: 4] AXI_burst_align_rd_ch_ref_prefetch
                                   bit[ 3: 0] AXI_burst_align_rd_lu_ref_prefetch
								  
  --burstMaxLength  		   Maximum AXI burst length. [16]
```

## Parameters for RoiMap: (developing)

```
  --roimapfile                 Input file for roimap region. [jpeg_roimap.roi]
  --nonRoiFilter               Input file for nonroimap region filter. [filter.txt]
  --nonRoiLevel                0...9 nonRoiFliter Level
```
