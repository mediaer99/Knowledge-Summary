/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Hantro Products Oy.                             --
--                                                                            --
--                   (C) COPYRIGHT 2006 HANTRO PRODUCTS OY                    --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : Jpeg Encoder testbench
--
------------------------------------------------------------------------------*/

/* For parameter parsing */
#include "EncGetOption.h"
#include "JpegTestBench.h"

/* For SW/HW shared memory allocation */
#include "jenc_ewl.h"

/* For accessing the EWL instance inside the encoder */
//#include "EncJpegInstance.h"

/* For compiler flags, test data, debug and tracing */
#include "enccommon.h"

/* For Hantro Jpeg encoder */
#include "jenc_api.h"
#include "mjpegencapi.h"

#include "osal.h"
#include <stddef.h>

#include "encinputlinebuffer.h"
#include "EncJpegNonRoiFilterTables.h"
#include "enccfg.h"

#ifdef SYS_CMA_ENABLE
#include "ax_sys_api.h"
#endif

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)

#define DEBUG_LOG(str, arg...)        do{ \
        printf(" tid:%ld JpegTestBench.c %s %d "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)        do{ \
        printf(" tid:%ld JpegTestBench.c %s %d Jenc_Error! "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)


/*--------------------------------------------------------------------------------
    3. Module defines
------------------------------------------------------------------------------*/

/* User selectable testbench configuration */

/* Define this if you want to save each frame of motion jpeg
 * into frame%d.jpg */
/* #define SEPARATE_FRAME_OUTPUT */

/* Define this if yuv don't want to use debug printf */
/*#define ASIC_WAVE_TRACE_TRIGGER*/

/* Output stream is not written to file. This should be used
   when running performance simulations. */
/*#define NO_OUTPUT_WRITE */

/* Define these if you want to use testbench defined
 * comment header */
/*#define TB_DEFINED_COMMENT */

#define USER_DEFINED_QTABLE 10

#define MOVING_AVERAGE_FRAMES    30


/* Global variables */

/* Command line options */

static option_s options[] = {
    {"help", 'H', 0},
    {"inputThumb", 'I', 1},
    {"thumbnail", 'T', 1},
    {"widthThumb", 'K', 1},
    {"heightThumb", 'L', 1},
    {"output", 'o', 1},
    {"firstPic", 'a', 1},
    {"lastPic", 'b', 1},
    {"lumWidthSrc", 'w', 1},
    {"lumHeightSrc", 'h', 1},
    {"width", 'x', 1},
    {"height", 'y', 1},
    {"horOffsetSrc", 'X', 1},
    {"verOffsetSrc", 'Y', 1},
    {"restartInterval", 'R', 1},
    {"qLevel", 'q', 1},
    {"frameType", 'g', 1},
    {"colorConversion", 'v', 1},
    {"rotation", 'G', 1},
    {"codingType", 'p', 1},
    {"codingMode", 'm', 1},
    {"markerType", 't', 1},
    {"units", 'u', 1},
    {"xdensity", 'k', 1},
    {"ydensity", 'l', 1},
    {"write", 'W', 1},
    {"comLength", 'c', 1},
    {"comFile", 'C', 1},
    {"trigger", 'P', 1},
    {"inputLineBufferMode", 'S', 1},
    {"inputLineBufferDepth", 'N', 1},
    {"inputLineBufferAmountPerLoopback", 's', 1},
    {"inputAlignmentExp", 'Q', 1},
    {"input", 'i', 1},
    {"hashtype", 'A', 1},  /* hash frame data, 0--disable, 1--crc32, 2--Jenc_checksum */
    {"mirror", 'M', 1},
    {"XformCustomerPrivateFormat", 'D', 1},
    {"enableConstChroma", 'd', 1},
    {"constCb", 'e', 1},
    {"constCr", 'f', 1},
    {"lossless", '1', 1},
    {"ptrans", '2', 1},
    {"bitPerSecond", 'B', 1},
    {"mjpeg", 'J', 1},
    {"frameRateNum", 'n', 1},
    {"frameRateDenom", 'r', 1},
    {"qpMin", 'E', 1},
    {"qpMax", 'F', 1},
    {"rcMode", 'V', 1 },
    {"picQpDeltaRange", 'U', 1 },
    {"roimapFile", '0', 1},
    {"nonRoiFilter", '0', 1},
    {"nonRoiLevel", '0', 1},
    {"fixedQP", 'O', 1},
    {"streamBufChain", '0', 1},
    {"streamMultiSegmentMode", '0', 1},
    {"streamMultiSegmentAmount", '0', 1},
    {"qTableFile", '0', 1},
    {"dec400TableInput", '0', 1},
    {"osdDec400TableInput", '0', 1},
    {"overlayEnables", '0', 1},
    {"olInput1", '0', 1},
    {"olFormat1", '0', 1},
    {"olAlpha1", '0', 1},
    {"olWidth1", '0', 1},
    {"olCropWidth1", '0', 1},
    {"olHeight1", '0', 1},
    {"olCropHeight1", '0', 1},
    {"olXoffset1", '0', 1},
    {"olCropXoffset1", '0', 1},
    {"olYoffset1", '0', 1},
    {"olCropYoffset1", '0', 1},
    {"olYStride1", '0', 1},
    {"olUVStride1", '0', 1},
    {"olSuperTile1", '0', 1},
    {"olScaleWidth1", '0', 1},
    {"olScaleHeight1", '0', 1},
#ifdef FBDC_ENABLE
    {"UVheaderSize",   '0', 1},
    {"UVpayloadSize",    '0', 1},
    {"YheaderSize", '0', 1},
    {"YpayloadSize", '0', 1},
    {"CropX", '0', 1},
    {"CropY", '0', 1},
#endif
    {"olInput2", '0', 1},
    {"olFormat2", '0', 1},
    {"olAlpha2", '0', 1},
    {"olWidth2", '0', 1},
    {"olCropWidth2", '0', 1},
    {"olHeight2", '0', 1},
    {"olCropHeight2", '0', 1},
    {"olXoffset2", '0', 1},
    {"olCropXoffset2", '0', 1},
    {"olYoffset2", '0', 1},
    {"olCropYoffset2", '0', 1},
    {"olYStride2", '0', 1},
    {"olUVStride2", '0', 1},
    {"olInput3", '0', 1},
    {"olFormat3", '0', 1},
    {"olAlpha3", '0', 1},
    {"olWidth3", '0', 1},
    {"olCropWidth3", '0', 1},
    {"olHeight3", '0', 1},
    {"olCropHeight3", '0', 1},
    {"olXoffset3", '0', 1},
    {"olCropXoffset3", '0', 1},
    {"olYoffset3", '0', 1},
    {"olCropYoffset3", '0', 1},
    {"olYStride3", '0', 1},
    {"olUVStride3", '0', 1},
    {"olInput4", '0', 1},
    {"olFormat4", '0', 1},
    {"olAlpha4", '0', 1},
    {"olWidth4", '0', 1},
    {"olCropWidth4", '0', 1},
    {"olHeight4", '0', 1},
    {"olCropHeight4", '0', 1},
    {"olXoffset4", '0', 1},
    {"olCropXoffset4", '0', 1},
    {"olYoffset4", '0', 1},
    {"olCropYoffset4", '0', 1},
    {"olYStride4", '0', 1},
    {"olUVStride4", '0', 1},
    {"olInput5", '0', 1},
    {"olFormat5", '0', 1},
    {"olAlpha5", '0', 1},
    {"olWidth5", '0', 1},
    {"olCropWidth5", '0', 1},
    {"olHeight5", '0', 1},
    {"olCropHeight5", '0', 1},
    {"olXoffset5", '0', 1},
    {"olCropXoffset5", '0', 1},
    {"olYoffset5", '0', 1},
    {"olCropYoffset5", '0', 1},
    {"olYStride5", '0', 1},
    {"olUVStride5", '0', 1},
    {"olInput6", '0', 1},
    {"olFormat6", '0', 1},
    {"olAlpha6", '0', 1},
    {"olWidth6", '0', 1},
    {"olCropWidth6", '0', 1},
    {"olHeight6", '0', 1},
    {"olCropHeight6", '0', 1},
    {"olXoffset6", '0', 1},
    {"olCropXoffset6", '0', 1},
    {"olYoffset6", '0', 1},
    {"olCropYoffset6", '0', 1},
    {"olYStride6", '0', 1},
    {"olUVStride6", '0', 1},
    {"olInput7", '0', 1},
    {"olFormat7", '0', 1},
    {"olAlpha7", '0', 1},
    {"olWidth7", '0', 1},
    {"olCropWidth7", '0', 1},
    {"olHeight7", '0', 1},
    {"olCropHeight7", '0', 1},
    {"olXoffset7", '0', 1},
    {"olCropXoffset7", '0', 1},
    {"olYoffset7", '0', 1},
    {"olCropYoffset7", '0', 1},
    {"olYStride7", '0', 1},
    {"olUVStride7", '0', 1},
    {"olInput8", '0', 1},
    {"olFormat8", '0', 1},
    {"olAlpha8", '0', 1},
    {"olWidth8", '0', 1},
    {"olCropWidth8", '0', 1},
    {"olHeight8", '0', 1},
    {"olCropHeight8", '0', 1},
    {"olXoffset8", '0', 1},
    {"olCropXoffset8", '0', 1},
    {"olYoffset8", '0', 1},
    {"olCropYoffset8", '0', 1},
    {"olYStride8", '0', 1},
    {"olUVStride8", '0', 1},
    {"AXIAlignment", '0', 1},
    {"useVcmd", '3', 1},
    {"useMMU", '3', 1},
    {"useDec400", '3', 1},
    {"useL2Cache", '3', 1},
    {"sramPowerdownDisable", '0', 1},
    {"mmuEnable", '0', 1},
    /*AXI max burst length */
    {"burstMaxLength", '0', 1},
    {NULL, 0, 0}
};

typedef struct {
    i32 frame[MOVING_AVERAGE_FRAMES];
    i32 length;
    i32 count;
    i32 pos;
    i32 frameRateNumer;
    i32 frameRateDenom;
} Jenc_ma_s;


/* SW/HW shared memories for input/output buffers */
JENC_EWLLinearMem_t pictureMem;
JENC_EWLLinearMem_t dec400CompTblMem;
JENC_EWLLinearMem_t outbufMem[MAX_STRM_BUF_NUM];
JENC_EWLLinearMem_t overlayMem[MAX_OVERLAY_NUM];
JENC_EWLLinearMem_t osdDec400CompTblMem;

JENC_EWLLinearMem_t roimapMem;

typedef struct {
    int argc;
    char **argv;
} MainArgs;

#ifdef __FREERTOS__
typedef void * RET_TYPE;
u8 user_freertos_vcmd_en = 1; //used for use_freertos to switch normal_driver or vcmd_driver
static pthread_t tid_task;
#else
typedef int RET_TYPE;
#endif /* __FREERTOS__ */

/* Test bench definition of comment header */
#ifdef TB_DEFINED_COMMENT
    /* COM data */
static u32 comLen = 38;
static u8 comment[39] = "This is Hantro's test COM data header.";
#endif

static JpegEncCfg cfg;

static u32 writeOutput = 1;

/* Logic Analyzer trigger point */
i32 trigger_point = -1;

u32 thumbDataLength;
u8 * thumbData = NULL; /* thumbnail data buffer */

/* input mb line buffer struct */
static inputLineBufferCfg inputMbLineBuf;
static JencSegmentCtl_s streamSegCtl;

/*------------------------------------------------------------------------------
    4. Local function prototypes
------------------------------------------------------------------------------*/
RET_TYPE MainTask(void *args);
static void JencFreeRes(JpegEncInst enc);
static int AllocRes(commandLine_s * cmdl, JpegEncInst encoder);
static int OpenEncoder(commandLine_s * cml, JpegEncInst * encoder);
static void CloseEncoder(JpegEncInst encoder);
static int ReadPic(u8 * image, i32 width, i32 height, i32 sliceNum,
                   i32 sliceRows, i32 frameNum, char *name, u32 inputMode, u32 alignment);
static int Parameter(i32 argc, char **argv, commandLine_s * ep);
static void Help(void);
static void JencWriteStrm(FILE * fout, u32 * outbuf, u32 size, u32 endian);
static void JencWriteStrmBufs (FILE *fout, JENC_EWLLinearMem_t *bufs, u32 offset, u32 size, u32 invalid_size, u32 endian);
static u32 GetResolution(char *filename, i32 *pWidth, i32 *pHeight);

#ifdef SEPARATE_FRAME_OUTPUT
static void WriteFrame(char *filename, u32 * strmbuf, u32 size);
static void writeFrameBufs (char *filename, JENC_EWLLinearMem_t *bufs, u32 offset, u32 size);
#endif
static i32 InitInputLineBuffer(inputLineBufferCfg * lineBufCfg, JpegEncCfg * encCfg, JpegEncIn * encIn, JpegEncInst inst);
static void SetInputLineBuffer(inputLineBufferCfg * lineBufCfg, JpegEncCfg * encCfg, JpegEncIn * encIn, JpegEncInst inst, i32 sliceIdx);
static void EncStreamSegmentReady(void *cb_data);
static void InitStreamSegmentCrl(JencSegmentCtl_s *ctl, commandLine_s *cml, FILE *out, JpegEncIn * encIn);
static void JencGetAlignedPicSizebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                             u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size);
static i32 JpegReadDEC400Data(JpegEncInst encoder, u8 *compDataBuf, u8 *compTblBuf, u32 inputFormat,u32 src_width,
                               u32 src_height,char *inputDataFile,FILE *dec400Table,i32 num, u64 dec400FrameTableSize, i32 dec400VersionId);
static int ReadFilter(commandLine_s * cmdl);
static int JencReadRoimap(commandLine_s * cmdl, const void* ewl_inst);
static i32 file_read(FILE *file, u8 *data, u64 seek, size_t size)
{
    if ((file == NULL) || (data == NULL)) return NOK;

    fseeko(file, seek, SEEK_SET);
    if (fread(data, sizeof(u8), size, file) < size)
    {
        if (!feof(file))
        {
            return NOK;
        }
        return NOK;
    }

    return OK;
}

// Helper function to calculate time diffs.
static unsigned int uTimeDiff(struct timeval end, struct timeval start)
{
    return (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec);
}

void JPEGtransYUVtoDHformat(commandLine_s *cml)
{
    u8 *transform_buf = NULL;
    u8 *picture_buf = NULL;
    u32 i,j,k,col,row,p;
    u8 *start_add,*src_addr,*tile_addr,*cb_start_add,*cr_start_add,*cb_tile_add,*cr_tile_add,*cb_src_add,*cr_src_add;
    u32 transform_size,pictureSize;
    u64 seek;
    u8 *lum,*cb,*cr,*out;
    FILE *yuv_out = NULL;
    FILE *yuv_in = NULL;
    u32 mb_total = 0;

    /* Default resolution, try parsing input file name */
    if(cml->lumWidthSrc == DEFAULT || cml->lumHeightSrc == DEFAULT)
    {
        if (GetResolution(cml->input, &cml->lumWidthSrc, &cml->lumHeightSrc))
        {
            /* No dimensions found in filename, using default QCIF */
            cml->lumWidthSrc = 176;
            cml->lumHeightSrc = 144;
        }
    }

    if (cml->formatCustomizedType==0)//hevc
        transform_size = ((cml->lumWidthSrc + 32 - 1) & (~(32 - 1))) *
                            ((cml->lumHeightSrc + 32 - 1) & (~(32 - 1))) *
                            JencGetBitsPerPixel(cml->frameType) / 8;
    else//h264
    {
        mb_total = ((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/16 * ((cml->lumHeightSrc + 16 - 1) & (~(16 - 1)))/16;
        transform_size = mb_total/5*2048+mb_total%5*400;
    }

    out = transform_buf = malloc(transform_size);

    pictureSize = (cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc *
                      JencGetBitsPerPixel(cml->frameType)/8;
    picture_buf = malloc(pictureSize);

    lum = picture_buf;
    cb = lum+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc;
    cr = cb+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc/4;

    if (yuv_out==NULL)
        yuv_out = fopen("trans_to_dahua_format","w");

    if (yuv_in==NULL)
        yuv_in = fopen(cml->input,"r");

    for (p=cml->firstPic;p<=cml->lastPic;p++)
    {
        seek = ((u64)p) * ((u64)pictureSize);
        if (file_read(yuv_in, lum , seek, pictureSize)) goto end;

        if (cml->formatCustomizedType==0)//hevc format
        {
            u32 row_32 = ((cml->lumHeightSrc + 32 - 1) & (~(32 - 1)))/32;
            u32 num32_per_row = ((cml->lumWidthSrc + 32 - 1) & (~(32 - 1)))/32;
            //luma
            for (i=0;i<row_32;i++)
            {
                start_add = lum+i*32*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)));
                for (j=0;j<num32_per_row*2;j++)
                {
                    tile_addr = start_add+j*16;
                    if (j<(((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/16))
                    {
                        for(k=0;k<32;k++)
                        {
                            if ((i*32+k)>=cml->lumHeightSrc)
                            {
                                for(col=0;col<16;col++)
                                {
                                    *transform_buf++ = 0;
                                }
                            }
                            else
                            {
                                src_addr = tile_addr;
                                for(col=0;col<16;col++)
                                {
                                    *transform_buf++ = *(src_addr+col);
                                }
                                tile_addr = tile_addr + ((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)));
                            }
                        }
                    }
                    else
                    {
                        for(k=0;k<32;k++)
                        {
                            for(col=0;col<16;col++)
                            {
                                *transform_buf++ = 0;
                            }
                        }
                    }
                }
            }
            //chroma
            for (i=0;i<row_32;i++)
            {
                cb_start_add = cb+i*16*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                cr_start_add = cr+i*16*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;

                for (j=0;j<num32_per_row;j++)
                {
                    cb_tile_add = cb_start_add+j*16;
                    cr_tile_add = cr_start_add+j*16;

                    for(k=0;k<16;k++)
                    {
                        if ((i*16+k)>=(cml->lumHeightSrc/2))
                        {
                            for(col=0;col<32;col++)
                            {
                                *transform_buf++ = 0;
                            }
                        }
                        else
                        {
                            cb_src_add = cb_tile_add;
                            cr_src_add = cr_tile_add;
                            //cb
                            for(col=0;col<16;col++)
                            {
                                if (16*j+col>=(((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2))
                                    *transform_buf++ = 0;
                                else
                                    *transform_buf++ = *(cb_src_add+col);
                            }
                            //cr
                            for(col=0;col<16;col++)
                            {
                                if (16*j+col>=(((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2))
                                    *transform_buf++ = 0;
                                else
                                    *transform_buf++ = *(cr_src_add+col);
                            }
                            cb_tile_add = cb_tile_add + ((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                            cr_tile_add = cr_tile_add + ((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                        }
                    }
                }
            }
        }
        else//h264 format
        {
            u32 row_16 = ((cml->lumHeightSrc + 16 - 1) & (~(16 - 1)))/16;
            u32 mb_per_row = ((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/16;
            u32 mb_total = 0;
            for (i=0;i<row_16;i++)
            {
                start_add = lum+i*16*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)));
                cb_start_add = cb+i*8*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                cr_start_add = cr+i*8*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                for(j=0;j<mb_per_row;j++)
                {
                    tile_addr = start_add+16*j;
                    cb_tile_add = cb_start_add+8*j;
                    cr_tile_add = cr_start_add+8*j;
                    for(k=0;k<4;k++)
                    {
                        for (row=0;row<4;row++)
                        {
                            //luma
                            if ((i*16+k*4+row)<cml->lumHeightSrc)
                            {
                                src_addr = tile_addr+(k*4+row)*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)));
                                memcpy(transform_buf,src_addr,16);
                                transform_buf+=16;
                            }
                            else
                            {
                                memset(transform_buf,0,16);
                                transform_buf+=16;
                            }
                        }

                        //cb
                        for (row=0;row<2;row++)
                        {
                            if ((i*8+k*2+row)<cml->lumHeightSrc/2)
                            {
                                src_addr = cb_tile_add+(k*2+row)*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                                memcpy(transform_buf,src_addr,8);
                                transform_buf+=8;
                            }
                            else
                            {
                                memset(transform_buf,0,8);
                                transform_buf+=8;
                            }
                        }

                        //cr
                        for (row=0;row<2;row++)
                        {
                            if ((i*8+k*2+row)<cml->lumHeightSrc/2)
                            {
                                src_addr = cr_tile_add+(k*2+row)*((cml->lumWidthSrc + 16 - 1) & (~(16 - 1)))/2;
                                memcpy(transform_buf,src_addr,8);
                                transform_buf+=8;
                            }
                            else
                            {
                                memset(transform_buf,0,8);
                                transform_buf+=8;
                            }
                        }
                    }
                    memset(transform_buf,0,16);
                    transform_buf+=16;
                    mb_total++;
                    if (mb_total%5==0)
                    {
                        memset(transform_buf,0,48);
                        transform_buf+=48;
                    }

                }
            }
        }

        u32 output_size = 0;

        if (cml->formatCustomizedType==0)
            output_size = ((cml->lumWidthSrc + 32 - 1) & (~(32 - 1))) * ((cml->lumHeightSrc + 32 - 1) & (~(32 - 1))) *
                            JencGetBitsPerPixel(JPEGENC_YUV420_8BIT_DAHUA_HEVC) / 8;
        else
            output_size = mb_total/5*2048+mb_total%5*400;

        for (i=0;i<output_size;i++)
            fwrite((u8 *)(out)+i, sizeof(u8), 1, yuv_out);

        transform_buf = out;

    }
end:
    fclose(yuv_out);
    fclose(yuv_in);
    free(picture_buf);
    free(out);
    strcpy(cml->input,"trans_to_dahua_format");
    cml->lastPic = cml->lastPic-cml->firstPic;
    cml->firstPic = 0;
    if (cml->formatCustomizedType==0)
    {
        cml->frameType = JPEGENC_YUV420_8BIT_DAHUA_HEVC;
        cml->horOffsetSrc = cml->horOffsetSrc&(~(32-1));
        cml->verOffsetSrc = cml->verOffsetSrc&(~(32-1));
        cml->restartInterval = (cml->restartInterval+1)/2*2;
    }
    else
    {
        cml->frameType = JPEGENC_YUV420_8BIT_DAHUA_H264;
        cml->horOffsetSrc = cml->horOffsetSrc&(~(16-1));
        cml->verOffsetSrc = cml->verOffsetSrc&(~(16-1));
    }

}

void JPEGtransToDJformat(commandLine_s *cml)
{
    u8 *transform_buf = NULL;
    u8 *picture_buf = NULL;
    u32 i,j,k,p;
    u32 transform_size = 0;
    u64 pictureSize;
    u64 seek;
    u8 *lum,*cb,*cr,*out;
    FILE *yuv_out = NULL;
    FILE *yuv_in = NULL;


    /* Default resolution, try parsing input file name */
    if(cml->lumWidthSrc == DEFAULT || cml->lumHeightSrc == DEFAULT)
    {
            if (GetResolution(cml->input, &cml->lumWidthSrc, &cml->lumHeightSrc))
            {
                    /* No dimensions found in filename, using default QCIF */
                    cml->lumWidthSrc = 176;
                    cml->lumHeightSrc = 144;
            }
    }

    if (cml->formatCustomizedType==2)//422_888
            transform_size = cml->lumWidthSrc * cml->lumHeightSrc * 2;

    out = transform_buf = malloc(transform_size);

    pictureSize = (u64)(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc *
                                       JencGetBitsPerPixel(cml->frameType)/8;
    picture_buf = malloc(pictureSize);

    lum = picture_buf;
    cb = lum+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc;
    cr = cb+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc/4;

    if (yuv_out==NULL)
        yuv_out = fopen("trans_to_422_888_format","w");

    if (yuv_in==NULL)
        yuv_in = fopen(cml->input,"r");

    for (p = cml->firstPic; p <= cml->lastPic; p++)
    {
        seek    = ((u64)p) * ((u64)pictureSize);
        if (file_read(yuv_in, lum , seek, pictureSize)) goto end;

        if (cml->formatCustomizedType==2)
        {
            printf("transform YUV 420 to 422 888\n");

            //luma
            for (i = 0; i < cml->lumWidthSrc * cml->lumHeightSrc; i++)
            {
                memcpy(transform_buf++, lum+i, 1);
            }

            //chroma
            for (i = 0; i < cml->lumHeightSrc/2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    for (k = 0; k < cml->lumWidthSrc/2; k++)
                    {
                        memcpy(transform_buf++, cb+cml->lumWidthSrc/2*i+k, 1);
                        memcpy(transform_buf++, cr+cml->lumWidthSrc/2*i+k, 1);
                    }
                }
            }
        }

        for (i = 0; i< transform_size; i++)
            fwrite((u8 *)(out)+i, sizeof(u8), 1, yuv_out);

        transform_buf = out;
    }
end:
    fclose(yuv_out);
    fclose(yuv_in);
    free(picture_buf);
    free(out);
    strcpy(cml->input,"trans_to_422_888_format");
    cml->lastPic = cml->lastPic-cml->firstPic;
    cml->firstPic = 0;
    cml->frameType = JPEGENC_YUV422_888;
}


void JPEGtransToFBformat(commandLine_s *cml)
{
    u8 *transform_buf, *picture_buf;
    u8 *lum,*cb,*cr,*out;
    u64 picture_size, transform_size, seek;
    u32 x,y,i,p;
    u64 pic_lum_size, pic_chroma_size;
    u32 alignment = (cml->exp_of_input_alignment == 0) ? 1 : (1 << cml->exp_of_input_alignment);
    u32 byte_per_compt = 0;

    FILE *yuv_out = NULL;
    FILE *yuv_in = NULL;

    JencGetAlignedPicSizebyFormat(cml->frameType, cml->lumWidthSrc, cml->lumHeightSrc,alignment,&pic_lum_size,&pic_chroma_size,&picture_size);
    switch(cml->frameType)
    {
    case JPEGENC_YUV420_SEMIPLANAR:
        byte_per_compt = 1;
        cml->frameType = JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4;
        break;
    case JPEGENC_YUV420_SEMIPLANAR_VU:
        byte_per_compt = 1;
        cml->frameType = JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4;
        break;
    case JPEGENC_YUV420_MS_P010:
        byte_per_compt = 2;
        cml->frameType = JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4;
    }

    JencGetAlignedPicSizebyFormat(cml->frameType, cml->lumWidthSrc, cml->lumHeightSrc,alignment,NULL,NULL,&transform_size);

    out = transform_buf = malloc(transform_size);
    picture_buf = malloc(picture_size);

    lum = picture_buf;
    cb = lum + pic_lum_size;

    if (yuv_out==NULL)
        yuv_out = fopen("trans_to_fb_format","w");

    if (yuv_in==NULL)
        yuv_in = fopen(cml->input,"r");

    printf("transform YUV to FB format\n");

    for(p = cml->firstPic; p <= cml->lastPic; p++)
    {
        seek = ((u64)p) * ((u64)picture_size);
        if (file_read(yuv_in, lum , seek, picture_size)) goto end;

        u32 stride = (cml->lumWidthSrc*4*byte_per_compt + alignment - 1) & (~(alignment - 1));

        //luma
        for (x = 0; x < cml->lumWidthSrc/4; x++)
        {
            for (y = 0; y < cml->lumHeightSrc; y++)
                memcpy(transform_buf + y%4*4*byte_per_compt + stride*(y/4) + x*16*byte_per_compt, lum + y*((cml->lumWidthSrc+15)&(~15))*byte_per_compt + x*4*byte_per_compt, 4*byte_per_compt);
        }

        transform_buf += stride * cml->lumHeightSrc/4;

        //chroma
        for (x = 0; x < cml->lumWidthSrc/4; x++)
        {
            for (y = 0; y < ((cml->lumHeightSrc/2)+3)/4*4; y++)
                memcpy(transform_buf + y%4*4*byte_per_compt + stride*(y/4) + x*16*byte_per_compt, cb + y*((cml->lumWidthSrc+15)&(~15))*byte_per_compt + x*4*byte_per_compt, 4*byte_per_compt);
        }

        for (i = 0; i< transform_size; i++)
            fwrite((u8 *)(out)+i, sizeof(u8), 1, yuv_out);
        transform_buf = out;
    }



end:
    fclose(yuv_out);
    fclose(yuv_in);
    free(picture_buf);
    free(out);
    strcpy(cml->input,"trans_to_fb_format");
    cml->lastPic = cml->lastPic-cml->firstPic;
    cml->firstPic = 0;
}

void JPEGtransToCommdataformat(commandLine_s *cml)
{
    u8 *transform_buf = NULL;
    u8 *picture_buf = NULL;
    u32 x,y,ix,iy,i,j,p;
    u64 transform_size = 0;
    u64 pictureSize;
    u64 seek;
    u8 *lum,*cb,*cr;
    FILE *yuv_out = NULL;
    FILE *yuv_in = NULL;
    u32 trans_format = 0;
    u32 byte_per_compt = 0;
    u8 *tile_start_addr,*dst_8_addr = NULL,*cb_start,*cr_start;
    u16 *dst_16_addr = NULL;

    /* Default resolution, try parsing input file name */
    if(cml->lumWidthSrc == DEFAULT || cml->lumHeightSrc == DEFAULT)
    {
        if (GetResolution(cml->input, &cml->lumWidthSrc, &cml->lumHeightSrc))
        {
            /* No dimensions found in filename, using default QCIF */
            cml->lumWidthSrc = 176;
            cml->lumHeightSrc = 144;
        }
    }

    if (cml->formatCustomizedType==3)//tile 4x4 8bit
            trans_format = JPEGENC_YUV420_8BIT_TILE_8_8;
    else if (cml->formatCustomizedType==4)//tile 4x4 10bit
            trans_format = JPEGENC_YUV420_10BIT_TILE_8_8;

    JencGetAlignedPicSizebyFormat(trans_format,cml->lumWidthSrc,cml->lumHeightSrc,0,NULL,NULL,&transform_size);

    transform_buf = malloc(transform_size);

    pictureSize = (u64)(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc *
                      JencGetBitsPerPixel(cml->frameType)/8;
    picture_buf = malloc(pictureSize);

    lum = picture_buf;
    cb = lum+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc;
    cr = cb+(cml->lumWidthSrc+15)/16*16 * cml->lumHeightSrc/4;

    if (yuv_out==NULL)
        yuv_out = fopen("trans_to_tile8x8_commdata_format","w");

    if (yuv_in==NULL)
        yuv_in = fopen(cml->input,"r");

    printf("transform YUV to CommData format\n");

    for (p = cml->firstPic; p <= cml->lastPic; p++)
    {
        seek = ((u64)p) * ((u64)pictureSize);
        if (file_read(yuv_in, lum , seek, pictureSize)) goto end;

        if (cml->formatCustomizedType == 3)
        {
            byte_per_compt = 1;
            dst_8_addr = transform_buf;
        }
        else
        {
            byte_per_compt = 2;
            dst_16_addr = (u16 *)transform_buf;
        }

        u32 orig_stride = cml->lumWidthSrc;

        //luma
        for (y = 0; y < ((cml->lumHeightSrc+7)/8); y++)
            for (x = 0; x < ((cml->lumWidthSrc+7)/8); x++)
            {
               tile_start_addr = lum + 8*x + orig_stride*8*y;

              for (iy = 0; iy < 2; iy++)
                  for (ix = 0; ix < 2; ix++)
                        for (i = 0; i < 4; i++)
                            if (cml->formatCustomizedType == 3)
                            {
                                memcpy(dst_8_addr, tile_start_addr + orig_stride*i+4*ix+orig_stride*4*iy, 4);
                                dst_8_addr += 4;
                            }
                            else
                            {
                                u8 *tmp_addr = tile_start_addr + orig_stride*i+4*ix+orig_stride*4*iy;
                                u64 tmp = 0;
                                for (j = 0; j < 4; j++)
                                    tmp = tmp | (((u64)(*(tmp_addr+j)) << 8) << (16*j));
                                memcpy(dst_16_addr, &tmp, 4*byte_per_compt);
                                dst_16_addr += 4;
                            }
            }

        //chroma
        for (y = 0; y < ((cml->lumHeightSrc/2+3)/4); y++)
        {
            for (x = 0; x < ((cml->lumWidthSrc+15)/16); x++)
            {
                cb_start = cb + 8*x + orig_stride/2*4*y;
                cr_start = cr + 8*x + orig_stride/2*4*y;

                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 16; j++)
                    {
                        if (j%2 == 0)
                        {
                            if (cml->formatCustomizedType == 3)
                                *dst_8_addr++ = *(cb_start + (j%4)/2 + orig_stride/2*(j/4)+i*2);
                            else
                                *dst_16_addr++ = *(cb_start + (j%4)/2 + orig_stride/2*(j/4)+i*2)<<8;
                        }
                        else
                        {
                            if (cml->formatCustomizedType == 3)
                                *dst_8_addr++ = *(cr_start + (j%4)/2 + orig_stride/2*(j/4)+i*2);
                            else
                                *dst_16_addr++ = *(cr_start + (j%4)/2 + orig_stride/2*(j/4)+i*2)<<8;
                        }
                    }
                }
            }
        }

        if (cml->formatCustomizedType == 3)
            transform_size = dst_8_addr - transform_buf;
        else
            transform_size = (u8 *)dst_16_addr - (u8 *)transform_buf;

        for (i=0;i<transform_size;i++)
            fwrite(transform_buf+i, sizeof(u8), 1, yuv_out);
     }

end:
    fclose(yuv_out);
    fclose(yuv_in);
    free(picture_buf);
    free(transform_buf);
    strcpy(cml->input,"trans_to_tile8x8_commdata_format");
    cml->lastPic = cml->lastPic-cml->firstPic;
    cml->firstPic = 0;
    if (cml->formatCustomizedType == 3)
        cml->frameType = JPEGENC_YUV420_8BIT_TILE_8_8;
    else
        cml->frameType = JPEGENC_YUV420_10BIT_TILE_8_8;
}

void JencGetOsdDec400SizeJpeg(commandLine_s *cmdl, u8 dec400VersionId, u8 idx, u32 *dec400TableSize)
{
    i32 ret = 0;
    u32 luma_stride=cmdl->olYStride[idx];
    u32 height = (cmdl->olHeight[idx] + 63)/64;
    u32 pictureSize = 0;

    ASSERT(cmdl->olFormat[idx] == 0 && cmdl->olSuperTile[idx]);

    u32 tileSize = 256;
    if(1 == dec400VersionId || 3 == dec400VersionId)
    {
        tileSize = 128;
    }
    else if(2 == dec400VersionId)
    {
        tileSize = 64;
    }

    /* Since SuperTile format will always be 64x64 aligned, no need to take care tile align */
    pictureSize = STRIDE(luma_stride * height/tileSize*4,8)/ 8;

    *dec400TableSize = pictureSize;
}


void JencGetAlignedPicSizebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size)
{
    u32 luma_stride=0, chroma_stride = 0;
    u64 lumaSize = 0, chromaSize = 0, pictureSize = 0;

    JencGetAlignedStride(width,type,&luma_stride,&chroma_stride,alignment);
    switch(type)
    {
        case JPEGENC_YUV420_PLANAR:
        case JPEGENC_YVU420_PLANAR:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)chroma_stride * height/2*2;
            break;
        case JPEGENC_YUV420_SEMIPLANAR:
        case JPEGENC_YUV420_SEMIPLANAR_VU:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)chroma_stride * height/2;
            break;
        case JPEGENC_YUV422_INTERLEAVED_YUYV:
        case JPEGENC_YUV422_INTERLEAVED_UYVY:
        case JPEGENC_RGB565:
        case JPEGENC_BGR565:
        case JPEGENC_RGB555:
        case JPEGENC_BGR555:
        case JPEGENC_RGB444:
        case JPEGENC_BGR444:
        case JPEGENC_RGB888:
        case JPEGENC_BGR888:
        case JPEGENC_RGB101010:
        case JPEGENC_BGR101010:
            lumaSize = (u64)luma_stride * height;
            chromaSize = 0;
            break;
        case JPEGENC_YUV420_I010:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)chroma_stride * height/2*2;
            break;
        case JPEGENC_YUV420_MS_P010:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)chroma_stride * height/2;
            break;
        case JPEGENC_YUV420_8BIT_DAHUA_HEVC:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)lumaSize/2;
            break;
        case JPEGENC_YUV420_8BIT_DAHUA_H264:
            lumaSize = (u64)luma_stride * height * 2* 12/ 8;
            chromaSize = 0;
            break;
        case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
        case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
        case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
            lumaSize = (u64)luma_stride * ((height+3)/4);
            chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
            break;
        case JPEGENC_YUV422_888:
            lumaSize = (u64)luma_stride * height;
            chromaSize = (u64)chroma_stride * height;
            break;
        case JPEGENC_YUV420_8BIT_TILE_8_8:
            lumaSize = (u64)luma_stride * ((height+7)/8);
            chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
            break;
        case JPEGENC_YUV420_10BIT_TILE_8_8:
            lumaSize = (u64)luma_stride * ((height+7)/8);
            chromaSize = (u64)chroma_stride * (((height/2)+3)/4);
            break;
        case JPEGENC_YUV420_FBC:
            lumaSize = luma_stride *((height +1)/2);
            chromaSize = chroma_stride * (((height/2)+1)/2);
            break;
        default:
            printf("not support this format\n");
            chromaSize = lumaSize = 0;
            break;
    }

    pictureSize = lumaSize + chromaSize;
    if (luma_Size != NULL)
        *luma_Size = lumaSize;
    if (chroma_Size != NULL)
        *chroma_Size = chromaSize;
    if (picture_Size != NULL)
        *picture_Size = pictureSize;
}

void getDec400CompTablebyFormat(JpegEncFrameType type,u32 width, u32 height, u32 alignment,
                                  u64 *luma_Size,u64 *chroma_Size,u64 *picture_Size, i32 dec400VersionId)
{
    u32 luma_stride=0, chroma_stride = 0;
    u64 lumaSize = 0, chromaSize = 0, pictureSize = 0;
    u64 chromaPaddingSize = 0;
    if (alignment == 0)
        alignment = 256;
    JencGetAlignedStride(width,type,&luma_stride,&chroma_stride,alignment);

    u32 tileSize = 256;
    if(1 == dec400VersionId || 3 == dec400VersionId)
    {
        tileSize = 128;
    }
    else if(2 == dec400VersionId)
    {
        tileSize = 64;
    }

    switch(type)
    {
    case JPEGENC_YUV420_PLANAR:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize * 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize * 2, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        //OYB M1 planner format: padding cb cr respectively
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8*2;
        }
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8;
        break;
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = 0;
        break;
    case JPEGENC_YUV420_I010:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize * 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize * 2, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8*2;
        }
        break;
    case JPEGENC_YUV420_MS_P010:
        lumaSize = STRIDE(luma_stride/tileSize*2 * height,8*16)/ 8;
        chromaSize = STRIDE(chroma_stride/tileSize*2 * height/2,8*16)/ 8;
        break;
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        if(dec400VersionId == 1)
        {
            lumaSize = STRIDE(STRIDE((luma_stride * height) / tileSize / 2, 8) / 8, 16);
            chromaSize = STRIDE((chroma_stride * height) / tileSize / 4, 8) / 8;
            chromaPaddingSize = STRIDE(chromaSize, 16) - chromaSize;
        }
        else
        {
            lumaSize = STRIDE(luma_stride/tileSize*4 * ((height+3)/4),8*16)/ 8;
            chromaSize = STRIDE(chroma_stride/tileSize*4 * (((height/2)+3)/4),8*16)/ 8;
        }
        break;
    default:
        printf("not support this format\n");
        chromaSize = lumaSize = 0;
        break;
    }

    pictureSize = lumaSize + chromaSize;
    pictureSize += chromaPaddingSize;

    if (luma_Size != NULL)
        *luma_Size = lumaSize;
    if (chroma_Size != NULL)
        *chroma_Size = chromaSize;
    if (picture_Size != NULL)
        *picture_Size = pictureSize;
}

/*------------------------------------------------------------------------------
    Add new frame bits for moving average bitrate calculation
------------------------------------------------------------------------------*/
static void MaAddFrame(Jenc_ma_s *ma, i32 frameSizeBits)
{
    ma->frame[ma->pos++] = frameSizeBits;

    if (ma->pos == ma->length)
        ma->pos = 0;

    if (ma->count < ma->length)
        ma->count++;
}

/*------------------------------------------------------------------------------
    Calculate average bitrate of moving window
------------------------------------------------------------------------------*/
i32 Ma(Jenc_ma_s *ma)
{
    i32 i;
    unsigned long long sum = 0;     /* Using 64-bits to avoid overflow */

    for (i = 0; i < ma->count; i++)
        sum += ma->frame[i];

    if (!ma->frameRateDenom)
        return 0;

    sum = sum / ma->count;

    return sum * (ma->frameRateNumer+ma->frameRateDenom-1) / ma->frameRateDenom;
}

/*------------------------------------------------------------------------------
    Read overlay input file and set up overlay buffer
------------------------------------------------------------------------------*/
void SetupOverlayBuffer(JpegEncIn * pEncIn, i32 frameNum)
{
    int i,j;
    u8 *lum, *cb, *cr;
    u32 src_width, size_luma;
    u64 seek;
    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        pEncIn->busOlLum[i] = 0;
        pEncIn->busOlCb[i] = 0;
        pEncIn->busOlCr[i] = 0;
        pEncIn->overlayEnable[i] = cfg.olEnable[i];
        if(cfg.olEnable[i])
        {
            int num = frameNum % cfg.olFrameNum[i];
            u32 y_stride = cfg.olYStride[i];
            u32 uv_stride = cfg.olUVStride[i];
            u32 read_height = cfg.olHeight[i];
            pEncIn->busOlLum[i] = overlayMem[i].busAddress;
            lum = (u8*)overlayMem[i].virtualAddress;

            switch(cfg.olFormat[i])
            {
            case 0:    //ARGB
                src_width = cfg.olWidth[i] * 4;
                seek = num * (cfg.olHeight[i]*cfg.olWidth[i]*4);
                if(cfg.olSuperTile[i])
                {
                    src_width = cfg.olYStride[i];
                    read_height = (cfg.olHeight[i] + 63)/64;
                    seek = num * src_width * read_height;
                }
                for(j = 0; j < read_height; j++)
                {
                    if(file_read(cfg.olFile[i], lum, seek, src_width))
                    {
                        printf("Jenc_Error: fail to read overlay\n");
                        pEncIn->overlayEnable[i] = 0;
                        break;
                    }
                    else
                    {
                        seek += src_width;
                        lum += y_stride;
                    }
                }
                break;
            case 1: //NV12
                size_luma = cfg.olYStride[i]*cfg.olHeight[i];
                seek = num * ((cfg.olWidth[i]*cfg.olHeight[i]) + (cfg.olWidth[i])*cfg.olHeight[i]/2);
                src_width = cfg.olWidth[i];
                pEncIn->busOlCb[i] = pEncIn->busOlLum[i] + size_luma; //Cb and Cr
                cb = lum + size_luma;
                //Luma
                for(j = 0; j < read_height;j++)
                {
                    if(file_read(cfg.olFile[i], lum, seek, src_width))
                    {
                        printf("Jenc_Error: fail to read overlay\n");
                        pEncIn->overlayEnable[i] = 0;
                        break;
                    }
                    else
                    {
                        seek += src_width;
                        lum += y_stride;
                    }
                }
                //Cb and Cr
                for(j = 0; j < (read_height/2);j++)
                {
                    if(file_read(cfg.olFile[i], cb, seek, src_width))
                    {
                        //This situation means corrupted input, so do not rolling back
                        pEncIn->overlayEnable[i] = 0;
                        break;
                    }
                    seek += src_width;
                    cb += uv_stride;
                }
                break;
            case 2: //Bitmat
                break;
            case 3: //YUV420 PLANAR
                break;
            defualt:
                break;
            }
        }
    }

    pEncIn->osdDec400Enable = 0;
    if (cfg.osdDec400TableFile && osdDec400CompTblMem.virtualAddress)
    {
        int num = frameNum % cfg.olFrameNum[0];
        seek = ((u64)num) * ((u64)cfg.osdDec400TableSize);
        pEncIn->osdDec400TableBase = osdDec400CompTblMem.busAddress;
        lum = (u8*)osdDec400CompTblMem.virtualAddress;

        if (file_read(cfg.osdDec400TableFile, lum, seek, cfg.osdDec400TableSize))
            printf("Jenc_Error: fail to read osd dec400 table file\n");
        else
            pEncIn->osdDec400Enable = 1;
    }
}
/*------------------------------------------------------------------------------

        main

------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    osal_thread_init();
    MainArgs args = { argc, argv };
#ifdef __FREERTOS__
#ifndef FREERTOS_SIMULATOR
    Platform_init();
#endif
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&tid_task, &attr, &MainTask, &args);
    vTaskStartScheduler();

    return 0; //should not arrive here if start scheduler successfully in real env
#else

#ifdef SYS_CMA_ENABLE
    int ret;
    AX_SYS_Init();
    ret = MainTask(&args);
    AX_SYS_Deinit();
    return ret;
#else
    return MainTask(&args);
#endif

#endif
}

RET_TYPE MainTask(void *args)
{
    MainArgs *args_ = (MainArgs *)args;
    int argc = args_->argc;
    char **argv = args_->argv;

    u32 retMain = 0;
    JpegEncInst encoder;
    JpegEncRet ret;
    JpegEncIn encIn;
    JpegEncOut encOut;
    JpegEncApiVersion encVer;
    JpegEncBuild encBuild;
    int encodeFail = 0;

    FILE *fout = NULL;
    i32 picBytes = 0;
    u32 i=0;
    u32 mjpeg_length = 0,mjpeg_movi_idx = 0;
    IDX_CHUNK *idx = NULL;
    Jenc_ma_s ma;
    u32 total_bits = 0;
    long numbersquareoferror = 0;
    i32 maxerrorovertarget = 0;
    i32 maxerrorundertarget = 0;
    float sumsquareoferror = 0;
    float averagesquareoferror = 0;
    struct timeval timeFrameStart;
    struct timeval timeFrameEnd;
    int filter_ret = 0;
    int SliceRoimapByteNum = 0;
    u32 SliceWidthMB = 0;
    u32 SliceHeightMB = 0;

    commandLine_s cmdl;

    fprintf(stdout,
        "\n* * * * * * * * * * * * * * * * * * * * *\n\n"
            "      HANTRO JPEG ENCODER TESTBENCH\n"
            "\n* * * * * * * * * * * * * * * * * * * * *\n\n");

    /* Print API and build version numbers */
    encVer = JencGetApiVersion();
    /* Version */
    fprintf(stdout, "JPEG Encoder API v%d.%d.%d\n", encVer.major, encVer.minor,
            encVer.clnum);


    if(argc < 2)
    {
        Help();
        exit(0);
    }

    /* Parse command line parameters */
    if(Parameter(argc, argv, &cmdl) != 0)
    {
        fprintf(stderr, "Input parameter error\n");
        retMain = -1;
        goto return_;
    }

    JencEWLAttach(NULL,0,cmdl.useVcmd);
    encBuild = JencGetBuild(JENC_EWL_CLIENT_TYPE_JPEG_ENC,NULL);

    fprintf(stdout, "HW ID:  0x%08x\t SW Build: %u.%u.%u\n\n",
            encBuild.hwBuild, encBuild.swBuild / 1000000,
            (encBuild.swBuild / 1000) % 1000, encBuild.swBuild % 1000);

    if(cmdl.nonRoiFilter == NULL || cmdl.roimapFile == NULL)
    {
        cfg.enableRoimap = 0;
        filter_ret = -1;
    }
    else
    {
        cfg.enableRoimap = 1;
        filter_ret = ReadFilter(&cmdl);
    }

    cfg.osdDec400TableFile = fopen(cmdl.osdDec400CompTableInput, "rb");

    if ((cmdl.formatCustomizedType == 0 || cmdl.formatCustomizedType == 1)&&(cmdl.frameType==JPEGENC_YUV420_PLANAR))
    {
        JPEGtransYUVtoDHformat(&cmdl);
    }

    if ((cmdl.formatCustomizedType == 2)&&(cmdl.frameType==JPEGENC_YUV420_PLANAR))
    {
        JPEGtransToDJformat(&cmdl);
    }

    if (((cmdl.formatCustomizedType == 3)||(cmdl.formatCustomizedType == 4))&&(cmdl.frameType==JPEGENC_YUV420_PLANAR))
    {
        JPEGtransToCommdataformat(&cmdl);
    }

    if ((cmdl.formatCustomizedType == 5)&&
       ((cmdl.frameType==JPEGENC_YUV420_SEMIPLANAR)
       ||(cmdl.frameType==JPEGENC_YUV420_SEMIPLANAR_VU)
       ||(cmdl.frameType==JPEGENC_YUV420_MS_P010)))
    {
        JPEGtransToFBformat(&cmdl);
    }

    /* Encoder initialization */
    if((ret = OpenEncoder(&cmdl, &encoder)) != 0)
    {
        retMain = -ret;
        goto return_;    /* Return positive value for test scripts */
    }

    /* Allocate input and output buffers */
    if(AllocRes(&cmdl, encoder) != 0)
    {
        fprintf(stderr, "Failed to allocate the external resources!\n");
        JencFreeRes(encoder);
        CloseEncoder(encoder);
        retMain = 1;
        goto return_;
    }

    /* Setup encoder input */
    memset (&encIn, 0, sizeof(JpegEncIn));
    for (i = 0; i < (cmdl.streamBufChain ? 2 : 1); i ++)
    {
        encIn.pOutBuf[i] = (u8 *)outbufMem[i].virtualAddress;
        encIn.busOutBuf[i] = outbufMem[i].busAddress;
        encIn.outBufSize[i] = outbufMem[i].size;
        printf("encIn.pOutBuf[%d] %p\n", i, encIn.pOutBuf[i]);
    }
    encIn.frameHeader = 1;

    ma.pos = ma.count = 0;
    ma.frameRateNumer = cmdl.frameRateNum;
    ma.frameRateDenom = cmdl.frameRateDenom;

    ma.length = MOVING_AVERAGE_FRAMES;

    {
        i32 slice = 0, sliceRows = 0;
        i32 next = 0, last = 0, picCnt = 0;
        i32 widthSrc, heightSrc;
        char *input,*dec400TblInput;
        u64 lumaSize = 0,chromaSize = 0,dec400LumaTblSize  = 0,dec400ChrTblSize = 0;
        u32 input_alignment = 1<<cmdl.exp_of_input_alignment;
        i32 mcuh = (cmdl.codingMode == 1 ? 8 : 16);
        FILE *dec400Table = NULL;

        /* If no slice mode, the slice equals whole frame */
        if(cmdl.partialCoding == 0)
            sliceRows = cmdl.lumHeightSrc;
        else
            sliceRows = cmdl.restartInterval * mcuh;

        widthSrc = (cmdl.lumWidthSrc+15)/16*16;
        heightSrc = cmdl.lumHeightSrc;

        if(cmdl.frameType == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
        {
            u32 w,h;

            w = (cmdl.lumWidthSrc + 31) & (~31);
            h = (cmdl.lumHeightSrc + 31) & (~31);

            if(cmdl.partialCoding == 0)
                sliceRows = h;
            else
                sliceRows = cmdl.restartInterval * 16;

            widthSrc = w;
            heightSrc = h;
        }
        else if (cmdl.frameType == JPEGENC_YUV420_8BIT_DAHUA_H264)
        {
            if(cmdl.partialCoding == 0)
                sliceRows = (cmdl.lumHeightSrc + 15) & (~15);
            else
                sliceRows = cmdl.restartInterval * 16;
        }

        input = cmdl.input;

        dec400TblInput = cmdl.dec400CompTableinput;
        last = cmdl.lastPic;

        JencGetLumaSize(encoder, &lumaSize, &dec400LumaTblSize);
        JencGetChromaSize(encoder, &chromaSize, &dec400ChrTblSize);
        encIn.busLum = pictureMem.busAddress;
        encIn.busCb = encIn.busLum + lumaSize;
        encIn.busCr = encIn.busCb + chromaSize/2;

        if(roimapMem.virtualAddress != NULL)
            encIn.busRoiMap = roimapMem.busAddress;
        else
            encIn.busRoiMap = 0;
        if(filter_ret == -1)
            encIn.filter = NULL;
        else
            encIn.filter = cfg.filter;

        encIn.dec400TableBusLum = dec400CompTblMem.busAddress;
        encIn.dec400TableBusCb = encIn.dec400TableBusLum + dec400LumaTblSize;
        encIn.dec400TableBusCr = encIn.dec400TableBusCb + dec400ChrTblSize/2;
        /* Virtual addresses of input picture, used by software encoder */
        encIn.pLum = (u8 *)pictureMem.virtualAddress;
        encIn.pCb = encIn.pLum + lumaSize;
        encIn.pCr = encIn.pCb + chromaSize/2;

        encIn.dec400TablepLum = (u8 *)dec400CompTblMem.virtualAddress;
        encIn.dec400TablepCb = encIn.dec400TablepLum + dec400LumaTblSize;
        encIn.dec400TablepCr = encIn.dec400TablepCb  + dec400ChrTblSize/2;

        //for VC8000EJ test bench, disable axiFE by default
        encIn.axiFEEnable = 0;

        fout = fopen(cmdl.output, "wb");
        if(fout == NULL)
        {
            fprintf(stderr, "Failed to create the output file.\n");
            JencFreeRes(encoder);
            CloseEncoder(encoder);
            retMain = -1;
            goto return_;
        }

        if (cmdl.inputLineBufMode)
        {
            if (InitInputLineBuffer(&inputMbLineBuf, &cfg, &encIn, encoder))
            {
                fprintf(stderr, "Fail to Init Input Line Buffer: virt_addr=%p, bus_addr=%08x\n",
                                inputMbLineBuf.sram, (u32)(inputMbLineBuf.sramBusAddr));
                goto end;
            }
        }

        if (cmdl.streamMultiSegmentMode != 0)
        {
            InitStreamSegmentCrl(&streamSegCtl, &cmdl, fout, &encIn);
        }

        /* Set Full Resolution mode */
        ret = JencSetPictureSize(encoder, &cfg);
        /* Handle error situation */
        if(ret != JPEGENC_OK)
        {
#ifndef ASIC_WAVE_TRACE_TRIGGER
            printf("FAILED. Jenc_Error code: %i\n", ret);
#endif
            goto end;
        }

        /* Set up overlay input file pointers and frame numbers */
        for(i = 0; i < MAX_OVERLAY_NUM; i++)
        {
            if((cmdl.overlayEnables >> i) & 1)
            {
                u32 frameByte = 1;
                cfg.olFile[i] = fopen(cmdl.olInput[i], "rb");
                if (!cfg.olFile[i])
                {
                    goto end;
                }
                //Get number of input overlay frames
                fseeko(cfg.olFile[i], 0, SEEK_END);
                if(cmdl.olFormat[i] == 0)
                {
                    if(cmdl.olSuperTile[i] == 0)
                        frameByte = (cmdl.olWidth[i] * cmdl.olHeight[i])*4;
                    else
                        frameByte = (((cmdl.olWidth[i] + 63)/64) * 64) * (((cmdl.olHeight[i] + 63)/64) * 64) * 4;
                }
                else if(cmdl.olFormat[i] == 1)
                {
                    frameByte = (cmdl.olWidth[i] * cmdl.olHeight[i]) / 2 * 3;
                }
                else if(cmdl.olFormat[i] == 2)
                {
                    frameByte = (cmdl.olWidth[i] / 8) * (cmdl.olHeight[i]);
                }
                cfg.olFrameNum[i] = ftello(cfg.olFile[i]) / frameByte;
            }
            else
            {
                cfg.olFrameNum[i] = 0;
            }
        }

        /*if mjpeg is enabled, assemble mjpeg container header*/
        if (cmdl.mjpeg == 1)
        {
            mjpeg_length = MjpegEncodeAVIHeader(outbufMem[0].virtualAddress, cfg.codingWidth, cfg.codingHeight,
                                                cmdl.frameRateNum, cmdl.frameRateDenom, cmdl.lastPic-cmdl.firstPic+1);
            if(writeOutput)
                JencWriteStrm(fout, outbufMem[0].virtualAddress, mjpeg_length, 0);

            mjpeg_movi_idx = mjpeg_length+4;
            u32 *output_buf = outbufMem[0].virtualAddress;
            MjpegAVIchunkheader((u8 **)&output_buf,"LIST","movi",0);
            if(writeOutput)
                JencWriteStrm(fout, outbufMem[0].virtualAddress, 12, 0);

            mjpeg_length += 12;
            idx = malloc((cmdl.lastPic-cmdl.firstPic+1)*sizeof(IDX_CHUNK));
        }

        if(cfg.enableRoimap)
        {
            if(cmdl.partialCoding)
            {
                if(cmdl.codingMode == JPEGENC_420_MODE)
                {
                    SliceWidthMB = (cmdl.width+15)/16;
                    SliceHeightMB = sliceRows/16;
                }
                else if(cmdl.codingMode == JPEGENC_422_MODE)
                {
                    SliceWidthMB = (cmdl.width+15)/16;
                    SliceHeightMB = sliceRows/8;
                }
                else if(cmdl.codingMode == JPEGENC_MONO_MODE)
                {
                    SliceWidthMB = (cmdl.width+7)/8;
                    SliceHeightMB = sliceRows/8;
                }
                SliceRoimapByteNum = (SliceWidthMB*SliceHeightMB+7)/8;
            }
        }
        /* Main encoding loop */
        ret = JPEGENC_FRAME_READY;
        next = cmdl.firstPic;
        while(next <= last &&
              (ret == JPEGENC_FRAME_READY || ret == JPEGENC_OUTPUT_BUFFER_OVERFLOW))
        {
#ifdef SEPARATE_FRAME_OUTPUT
            char framefile[50];
            sprintf(framefile, "frame%d%s.jpg", picCnt, mode == 1 ? "tn" : "");
            remove(framefile);
#endif
#ifndef ASIC_WAVE_TRACE_TRIGGER
            printf("Frame %3d started...\n", picCnt);
#endif
            fflush(stdout);

            if (cmdl.mjpeg == 1)
            {
                u32 *output_buf = outbufMem[0].virtualAddress;

                MjpegAVIchunkheader((u8 **)&output_buf,"00dc",NULL,0);
                if(writeOutput)
                    JencWriteStrm(fout, outbufMem[0].virtualAddress, 8, 0);

                mjpeg_length += 8;
                idx[picCnt].offset = mjpeg_length - 8;
            }

            /* Set up overlay input buffer */
            SetupOverlayBuffer(&encIn, next);
            if(cfg.enableRoimap)
            {
                encIn.busRoiMap = roimapMem.busAddress;
            }

            const void* ewl_inst = JencGetEwl(encoder);
            i32 dec400VersionId = 0;
            JencDec400GetVersionId(ewl_inst, &dec400VersionId);
            /* Loop until one frame is encoded */
            do
            {
#ifdef FBDC_ENABLE
                FILE *file = NULL;
                u32 size;

                file = fopen(input, "rb");
                if(file == NULL)
                {
                    fprintf(stderr, "\nUnable to open VOP file: %s\n", input);
                    return -1;
                }
                fseek(file, 0L, SEEK_SET);

                i32 sLen = ftell(file);
                rewind(file);
                size = cmdl.YheaderSize + cmdl.YpayloadSize + cmdl.UVheaderSize + cmdl.UVpayloadSize;

                fread((u8 *) pictureMem.virtualAddress, sizeof(u8), size, file);
                encIn.busLum = pictureMem.busAddress + cmdl.YheaderSize;
                encIn.busCb = encIn.busCr = encIn.busLum + cmdl.YpayloadSize + cmdl.UVheaderSize;

                printf("encodering Ydata addr is %x,UV=%x,sLen=%d\n", encIn.busLum, encIn.busCb,sLen);
#else
    #ifndef NO_INPUT_YUV
                /* Read next slice */
                if (ReadPic((u8 *) pictureMem.virtualAddress, cmdl.lumWidthSrc, heightSrc, slice,
                      sliceRows, next, input, cmdl.frameType,input_alignment) != 0)
                    break;

                if ((dec400Table = fopen(dec400TblInput, "rb")) == NULL)
                {
                    if(dec400VersionId == 1) /* 0: no any operation 1: bypass 2: enable */
                        encIn.dec400Enable = 1;
                    else
                        encIn.dec400Enable = 0;
                }
                else if (JpegReadDEC400Data(encoder, (u8 *) pictureMem.virtualAddress, (u8 *) dec400CompTblMem.virtualAddress,
                    cmdl.frameType, cmdl.lumWidthSrc, cmdl.lumHeightSrc, input,
                    dec400Table, next, cmdl.dec400FrameTableSize, dec400VersionId) == NOK)
                {
                    break;
                }
                else
                    encIn.dec400Enable = 2;
    #endif
#endif
                if (cmdl.inputLineBufMode)
                    SetInputLineBuffer (&inputMbLineBuf, &cfg, &encIn, encoder, slice);

                //Get overlay slice info
                JencGetOverlaySlice(encoder, &encIn, cmdl.restartInterval, cmdl.partialCoding, slice, sliceRows);

                gettimeofday(&timeFrameStart, NULL);

                ret = JencEncode(encoder, &encIn, &encOut);
                if((cmdl.partialCoding == 1 && cmdl.verOffsetSrc > 0) && slice < (cmdl.verOffsetSrc/sliceRows))
                {
                    //encIn.busRoiMap = encIn.busRoiMap;
                }
                else
                {
                    encIn.busRoiMap += SliceRoimapByteNum;
                }

                switch (ret)
                {
                case JPEGENC_RESTART_INTERVAL:
#ifndef ASIC_WAVE_TRACE_TRIGGER
                    printf("Frame %3d restart interval! %6u bytes\n",
                           picCnt, encOut.jfifSize);
                    fflush(stdout);
#endif

                    if(writeOutput)
                        JencWriteStrmBufs(fout, outbufMem, 0, encOut.jfifSize, encOut.invalidBytesInBuf0Tail, 0);
#ifdef SEPARATE_FRAME_OUTPUT
                    if(writeOutput)
                        writeFrameBufs(framefile, outbufMem, 0, encOut.jfifSize);
#endif
                    picBytes += encOut.jfifSize;
                    slice++;    /* Encode next slice */
                    break;

                case JPEGENC_FRAME_READY:
#ifndef ASIC_WAVE_TRACE_TRIGGER
                    printf("Frame %3d ready! %6u bytes\n",
                           picCnt, encOut.jfifSize);
                    fflush(stdout);
#endif
                    if (cmdl.inputLineBufMode)
                        Jenc_VCEncUpdateInitSegNum(&inputMbLineBuf);

                    gettimeofday(&timeFrameEnd, NULL);

                    if(writeOutput)
                    {
                        if (cmdl.streamMultiSegmentMode == 0)
                            JencWriteStrmBufs(fout, outbufMem, 0, encOut.jfifSize, encOut.invalidBytesInBuf0Tail, 0);
                        else
                        {
                            u8 *streamBase = streamSegCtl.streamBase + (streamSegCtl.streamRDCounter % streamSegCtl.segmentAmount) * streamSegCtl.segmentSize;
                            JencWriteStrm(streamSegCtl.outStreamFile, (u32 *)streamBase, encOut.jfifSize - streamSegCtl.streamRDCounter * streamSegCtl.segmentSize, 0);
                            streamSegCtl.streamRDCounter = 0;
                        }
                    }
#ifdef SEPARATE_FRAME_OUTPUT
                    if(writeOutput)
                        writeFrameBufs(framefile, outbufMem, 0, encOut.jfifSize);
#endif
                    if (cmdl.mjpeg == 1)
                    {
                        picBytes += encOut.jfifSize;
                        mjpeg_length += picBytes;
                        if (mjpeg_length%4!=0)
                        {
                            memset(outbufMem[0].virtualAddress,0,4-(mjpeg_length%4));
                            if(writeOutput)
                                JencWriteStrm(fout, outbufMem[0].virtualAddress, 4-(mjpeg_length%4),0);

                            mjpeg_length = (mjpeg_length+3)&(~3);
                            picBytes = (picBytes+3)&(~3);
                        }
                        idx[picCnt].length = picBytes;
                        fseek(fout,-(picBytes+4),SEEK_CUR);
                        putw(picBytes,fout);
                        fseek(fout,0,SEEK_END);

                        /*rate control statistic log*/
                        total_bits += picBytes*8;
                        MaAddFrame(&ma, picBytes*8);

                        #ifndef QP_FRACTIONAL_BITS
                            #ifndef CTBRC_STRENGTH
                            #define QP_FRACTIONAL_BITS    0
                            #else
                            #define QP_FRACTIONAL_BITS    8
                            #endif
                        #endif
                        printf("=== Encoded %i Qp=%d bits=%d TotalBits=%d averagebitrate=%lld HWCycles=%d Time(us %d HW +SW) \n",
                            picCnt, (JencGetQpHdr(encoder) >> QP_FRACTIONAL_BITS), picBytes*8, total_bits,
                            ((unsigned long long)total_bits * cmdl.frameRateNum) / ((picCnt+1) * cmdl.frameRateDenom),
                            JencGetPerformance(encoder), uTimeDiff(timeFrameEnd, timeFrameStart));

                        if(cmdl.bitPerSecond!=0&&(picCnt+1)>=ma.length)
                        {
                            numbersquareoferror++;
                            if(maxerrorovertarget<(Ma(&ma)- cmdl.bitPerSecond))
                                maxerrorovertarget=(Ma(&ma)- cmdl.bitPerSecond);
                            if(maxerrorundertarget<(cmdl.bitPerSecond-Ma(&ma)))
                                maxerrorundertarget=(cmdl.bitPerSecond-Ma(&ma));
                            sumsquareoferror+=((float)(ABS(Ma(&ma)- (i32)cmdl.bitPerSecond))*100/cmdl.bitPerSecond);
                            averagesquareoferror=(sumsquareoferror/numbersquareoferror);
                            printf("++++RateControl(movingBitrate=%d MaxOvertarget=%d%% MaxUndertarget=%d%% AveDeviationPerframe=%f%%) \n",
                                Ma(&ma),maxerrorovertarget*100/cmdl.bitPerSecond,maxerrorundertarget*100/cmdl.bitPerSecond,averagesquareoferror);
                        }
                    }
                    else
                        printf("=== Encoded %i bits=%d HWCycles=%d Time(us %d HW +SW) \n",
                            picCnt, encOut.jfifSize, JencGetPerformance(encoder), uTimeDiff(timeFrameEnd, timeFrameStart));
                    picBytes = 0;
                    slice = 0;

                    break;

                case JPEGENC_OUTPUT_BUFFER_OVERFLOW:
#ifndef ASIC_WAVE_TRACE_TRIGGER
                    printf("Jenc_Error: Frame %3d lost! Output buffer overflow.\n",
                           picCnt);
#endif

                    /* For debugging
                    if(writeOutput)
                        JencWriteStrm(fout, outbufMem.virtualAddress,
                                outbufMem.size, 0);*/
                    /* Rewind the file back this picture's bytes
                    fseek(fout, -picBytes, SEEK_CUR);*/
                    picBytes = 0;
                    slice = 0;
                    break;
                default:
#ifndef ASIC_WAVE_TRACE_TRIGGER
                    printf("FAILED. Jenc_Error code: %i\n", ret);
#endif
                    encodeFail = (int)ret;
                    /* For debugging */
                    if(writeOutput)
                        JencWriteStrmBufs(fout, outbufMem, 0, encOut.jfifSize, encOut.invalidBytesInBuf0Tail, 0);
                    break;
                }
            }
            while(ret == JPEGENC_RESTART_INTERVAL);

            picCnt++;
            next = picCnt + cmdl.firstPic;
        }   /* End of main encoding loop */
    }   /* End of encoding modes */
end:

#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("Release encoder\n");
#endif
    if (cmdl.mjpeg == 1)
    {
        u32 idx_length;
        fseek(fout,mjpeg_movi_idx,SEEK_SET);
        putw(mjpeg_length - mjpeg_movi_idx -4 ,fout);

        idx_length = MjpegEncodeAVIidx(outbufMem[0].virtualAddress,idx,mjpeg_movi_idx+4, (cmdl.lastPic-cmdl.firstPic+1));
        mjpeg_length += idx_length;

        fseek(fout,0,SEEK_END);
        if(writeOutput)
            JencWriteStrm(fout, outbufMem[0].virtualAddress, idx_length, 0);

        fseek(fout,4,SEEK_SET);
        putw(mjpeg_length-8,fout);
        if (idx != NULL)
            free(idx);
    }

    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        if (cfg.olFile[i])
            fclose(cfg.olFile[i]);
    }
    if (cfg.osdDec400TableFile) fclose(cfg.osdDec400TableFile);

    /* Free all resources */
    JencFreeRes(encoder);
    CloseEncoder(encoder);
    if(fout != NULL)
        fclose(fout);

    retMain = encodeFail;
    JencEWLDetach();

    DEBUG_LOG("%s %s EXIT! BYEBYE! ", __DATE__, __TIME__);
return_:
#ifdef __FREERTOS__
#ifdef FREERTOS_SIMULATOR
    vTaskEndScheduler(); // need to open in simulator, and need to close on real env
#endif
    (void)(retMain);

    return (void *)NULL;
#else
    return retMain;
#endif
}

/*------------------------------------------------------------------------------

    AllocRes

    Allocation of the physical memories used by both SW and HW:
    the input picture and the output stream buffer.

    NOTE! The implementation uses the EWL instance from the encoder
          for OS independence. This is not recommended in final environment
          because the encoder will release the EWL instance in case of error.
          Instead, the memories should be allocated from the OS the same way
          as inside JencEWLMallocLinear().

------------------------------------------------------------------------------*/
static int AllocRes(commandLine_s * cmdl, JpegEncInst enc)
{
    i32 sliceRows = 0;
    u64 pictureSize;
    u32 streamBufTotalSize;
    u32 headerSize = JPEGENC_STREAM_MIN_BUF0_SIZE;
    i32 i, ret;
    u64 lumaSize,chromaSize,dec400LumaTblSize,dec400ChrTblSize;
    u32 input_alignment = (cmdl->exp_of_input_alignment==0?0:(1<<cmdl->exp_of_input_alignment));
    i32 mcuh = (cmdl->codingMode == 1 ? 8 : 16);
    i32 strmBufNum = cmdl->streamBufChain ? 2 : 1;
    u64 bufSizes[2] = {0, 0}; // change for 32kx32k test
    i32 dec400VersionId = 0;

    const void* ewl_inst = JencGetEwl(enc);

    /* Set slice size and output buffer size
     * For output buffer size, 1 byte/pixel is enough for most images.
     * Some extra is needed for testing purposes (noise input) */

    if(cmdl->partialCoding == 0)
    {
        if(cmdl->frameType == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
            sliceRows = ((cmdl->lumHeightSrc + 32 - 1) & (~(32 - 1)));
        else if(cmdl->frameType == JPEGENC_YUV420_8BIT_DAHUA_H264)
            sliceRows = ((cmdl->lumHeightSrc + mcuh - 1) & (~(mcuh - 1)));
        else
            sliceRows = cmdl->lumHeightSrc;
    }
    else
    {
        sliceRows = cmdl->restartInterval * mcuh;
    }

    streamBufTotalSize = cmdl->width * sliceRows * 2;
    if(cmdl->thumbnail)
        headerSize += thumbDataLength;

    JencDec400GetVersionId(ewl_inst, &dec400VersionId);

    JencGetAlignedPicSizebyFormat(cmdl->frameType,cmdl->lumWidthSrc,sliceRows,input_alignment,&lumaSize,&chromaSize,&pictureSize);
    if(dec400VersionId == 1)
        getDec400CompTablebyFormat(cmdl->frameType,cmdl->lumWidthSrc,cmdl->lumHeightSrc,input_alignment,&dec400LumaTblSize,&dec400ChrTblSize,&cmdl->dec400FrameTableSize,dec400VersionId);
    else
        getDec400CompTablebyFormat(cmdl->frameType,cmdl->lumWidthSrc,cmdl->lumHeightSrc,input_alignment,&dec400LumaTblSize,&dec400ChrTblSize,NULL,dec400VersionId);
    JencSetLumaSize(enc, lumaSize, dec400LumaTblSize);//((jpegInstance_s *)enc)->lumaSize = lumaSize;
    JencSetChromaSize(enc, chromaSize, dec400ChrTblSize);//((jpegInstance_s *)enc)->chromaSize = chromaSize;

    pictureMem.virtualAddress = NULL;
     /* Here we use the EWL instance directly from the encoder
     * because it is the easiest way to allocate the linear memories */
    pictureMem.mem_type = EWL_MEM_TYPE_DPB;
#ifdef FBDC_ENABLE
    pictureSize = cmdl->UVheaderSize + cmdl->UVpayloadSize + cmdl->YheaderSize + cmdl->YpayloadSize;
    printf("JPEG input memory size is %lld\n", pictureSize);
#endif
    ret = JencEWLMallocLinear(ewl_inst, pictureSize, 0, &pictureMem);
    if (ret != EWL_OK)
    {
        fprintf(stderr, "Failed to allocate input picture!\n");
        pictureMem.virtualAddress = NULL;
        return 1;
    }

    dec400CompTblMem.virtualAddress = NULL;
    if (dec400LumaTblSize + dec400ChrTblSize > 0)
    {
        dec400CompTblMem.mem_type = EWL_MEM_TYPE_DPB;
        ret = JencEWLMallocLinear(ewl_inst, dec400LumaTblSize + dec400ChrTblSize, 16, &dec400CompTblMem);
        if (ret != EWL_OK)
        {
            fprintf(stderr, "Failed to allocate dec400 compress table!\n");
            dec400CompTblMem.virtualAddress = NULL;
            return 1;
        }
    }

    if (strmBufNum == 1)
        bufSizes[0] = (cmdl->streamMultiSegmentMode != 0 ? streamBufTotalSize/128 : streamBufTotalSize);
    else
    {
        /* set small stream buffer0 to test two stream buffers */
        bufSizes[0] = streamBufTotalSize / 100;
        bufSizes[1] = streamBufTotalSize - bufSizes[0];
    }
    bufSizes[0] += headerSize;
    memset(outbufMem, 0, sizeof(outbufMem));
    for (i = 0; i < strmBufNum; i ++)
    {
        u64 size = 160*1024*1024; //bufSizes[i];

        /* For FPGA testing, smaller size maybe specified. */
        /* Max output buffer size is less than 256MB */
        //comment out outbufSize hard limitation for 16K*16K testing
        //size = size < (1024*1024*64) ? size : (1024*1024*64);

        outbufMem[i].mem_type = EWL_MEM_TYPE_SLICE;
        ret = JencEWLMallocLinear(ewl_inst, size, 0, &outbufMem[i]);
        if (ret != EWL_OK)
        {
                fprintf(stderr, "Failed to allocate output buffer!\n");
                outbufMem[i].virtualAddress = NULL;
                return 1;
        }
    }
    //RoiMap assume cmdl->width/height % 16 == 0
    if(cfg.enableRoimap)
        JencReadRoimap(cmdl, ewl_inst);

    /*Overlay input buffer*/
    for(i = 0; i < 8; i++)
    {
        u32 block_size = 0;
        u32 dec400TableSize = 0;
        if((cmdl->overlayEnables >> i)&1)
        {
            switch(cmdl->olFormat[i])
            {
                case 0: //ARGB
                    if(cmdl->olSuperTile[i] == 0)
                        block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                    else
                        block_size = cmdl->olYStride[i]*((cmdl->olHeight[i] + 63) / 64);
                    break;
                case 1: //NV12
                    block_size = cmdl->olYStride[i]*cmdl->olHeight[i] + cmdl->olUVStride[i]*cmdl->olHeight[i]/2;
                    break;
                case 2: //Bitmap
                    block_size = cmdl->olYStride[i]*cmdl->olHeight[i];
                    break;
                default: //3
                    block_size = 0;
            }
            overlayMem[i].mem_type = EWL_MEM_TYPE_VPU_WORKING;
            if(JencEWLMallocLinear(ewl_inst, block_size, 0, &overlayMem[i]) != EWL_OK)
            {
                overlayMem[i].virtualAddress = NULL;
                return 1;
            }
            memset(overlayMem[i].virtualAddress, 0, block_size);

            /* Dec400 buffer */
            if (cfg.osdDec400TableFile && i == 0)
                JencGetOsdDec400SizeJpeg(cmdl, dec400VersionId, i, &dec400TableSize);

            if (dec400TableSize)
            {
                if(JencEWLMallocLinear(ewl_inst, dec400TableSize, 0, &osdDec400CompTblMem) != EWL_OK)
                {
                    osdDec400CompTblMem.virtualAddress = NULL;
                    return 1;
                }
                memset(osdDec400CompTblMem.virtualAddress, 0, dec400TableSize);
                cfg.osdDec400TableSize = dec400TableSize;
            }
            else if(i == 0)
                osdDec400CompTblMem.virtualAddress = NULL;
        }
        else
        {
            overlayMem[i].virtualAddress = NULL;
        }
    }


#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("Input %dx%d + %dx%d encoding at %dx%d + %dx%d ",
               cmdl->lumWidthSrcThumb, cmdl->lumHeightSrcThumb,
               cmdl->lumWidthSrc, cmdl->lumHeightSrc,
               cmdl->widthThumb, cmdl->heightThumb, cmdl->width, cmdl->height);

    if(cmdl->partialCoding != 0)
        printf("in slices of %dx%d", cmdl->width, sliceRows);
    printf("\n");
#endif


#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("Input buffer size:          %u bytes\n", pictureMem.size);
    printf("Input buffer bus address:   %p\n", (void *)pictureMem.busAddress);
    printf("Input buffer user address:  %10p\n", pictureMem.virtualAddress);
    for (i = 0; i < strmBufNum; i ++)
    {
        printf("Output buffer%d size:         %u bytes\n", i, outbufMem[i].size);
        printf("Output buffer%d bus address:  %p\n", i, (void *)outbufMem[i].busAddress);
        printf("Output buffer%d user address: %10p\n", i, outbufMem[i].virtualAddress);
    }
#endif

    return 0;
}

/*------------------------------------------------------------------------------

    JencFreeRes

------------------------------------------------------------------------------*/
void JencFreeRes(JpegEncInst enc)
{
    i32 i;
    const void* ewl_inst = JencGetEwl(enc);

    if(EWL_DEVMEM_VAILD(pictureMem))
            JencEWLFreeLinear(ewl_inst, &pictureMem);
    for (i = 0; i < MAX_STRM_BUF_NUM; i ++)
    {
        if(outbufMem[i].virtualAddress != NULL)
            JencEWLFreeLinear(ewl_inst, &outbufMem[i]);
    }
    if(EWL_DEVMEM_VAILD(dec400CompTblMem))
            JencEWLFreeLinear(ewl_inst, &dec400CompTblMem);
    if(thumbData != NULL)
            free(thumbData);
#ifndef TB_DEFINED_COMMENT
    if(cfg.pCom != NULL)
        free((void *)cfg.pCom);
#endif

    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        if(overlayMem[i].virtualAddress != NULL)
            JencEWLFreeLinear(ewl_inst, &overlayMem[i]);
    }
    if (osdDec400CompTblMem.virtualAddress != NULL)
        JencEWLFreeLinear(ewl_inst, &osdDec400CompTblMem);

    if(roimapMem.virtualAddress != NULL)
        JencEWLFreeLinear(ewl_inst, &roimapMem);
}

int ReadQTable(char *qTableFileName, u8 *qTableLuma, u8 *qTableChroma)
{
    FILE *fp = NULL;
    u8 *qTable;
    int line[8];
    int ret = -1;
    int i, j, num;

    fp = fopen(qTableFileName, "rt");
    if (fp==NULL)
        return -1;

    qTable = qTableLuma;
    for(i=0; i<16; i++)
    {
        num = fscanf(fp, "%d %d %d %d %d %d %d %d\n", line, line+1, line+2, line+3,
                                             line+4, line+5, line+6, line+7);
        if (num != 8)
        {
            fclose(fp);
            return -1;
        }
        for(j=0; j<8; j++)
        {
            if (line[j]>255)
            {
                fprintf(stderr, "Invalid Quant Table value %d at %d.\n", line[j], i*8+j);
                fclose(fp);
                return -1;
            }
            qTable[j] = (u8) line[j];
        }

        if (i==7)
            qTable = qTableChroma;
        else
            qTable += 8;
    }

    fclose(fp);
    return 0;
}

int ReadFilter(commandLine_s * cmdl)
{
    FILE *fpFilter = NULL;
    char buf[32];
    int val[8];
    int ret = -1;
    int num = 0;

    fpFilter = fopen(cmdl->nonRoiFilter, "r");
    if (fpFilter == NULL)
    {
        printf("filter.txt: Jenc_Error, Can Not Open File %s\n", cmdl->nonRoiFilter);
        return -1;
    }
    while(fgets(buf, 32, fpFilter)!= NULL)
    {
        if(buf[0] == '#' || buf[0] == '\r' || buf[0] == '\n')
        {
            continue;
        }
        sscanf(buf, "%d %d %d %d %d %d %d %d", &val[0], &val[1], &val[2], &val[3], &val[4], &val[5], &val[6], &val[7]);
        for(int i = 0; i < 8; i++)
        {
            cfg.filter[num] = (u8)val[i];
            num++;
        }
    }
    if(cmdl->nonRoiLevel >= 0 && cmdl->nonRoiLevel <= 9)
    {
        for(int j = 0; j < 64; j++)
        {
            cfg.filter[j] = NonRoiFilterLuminance[cmdl->nonRoiLevel][j];
            cfg.filter[j+64] = NonRoiFilterChrominance[cmdl->nonRoiLevel][j];
        }
    }
    fclose(fpFilter);
    return 0;
}

int JencReadRoimap(commandLine_s * cmdl, const void* ewl_inst)
{
    FILE *fpROI;
    char buf[30];
    i32 RoiRectNum = 0;
    u32 RoiRectLeft[30];
    u32 RoiRectTop[30];
    u32 RoiRectWidth[30];
    u32 RoiRectHeight[30];
    u32 RoiRegionCal = 0;
    u32 RoiRegionCalWidth = 0;
    u32 RoiSize = 0;
    u32 ImageWidthMB = 0;
    u32 ImageHeightMB = 0;
    u8 NumsBit = 0;
    u8 BitSet = 0;
    u32 byte_start[30];
    u32 byte_offest[30];
    u8 *roimap_virtualAddr = NULL;
    u8 RoiRegion_SetVal[8] = {0};
    u32 bitNum = 0;
    u8 roiValTmp = 0;
    u32 sliceRows = 0;
    u32 sliceRowsMb = 0;
    u32 mcuh = 0;
    u32 RoiSizePerSlice = 0;
    u32 MbNumPerSlice = 0;
    static const u8 set_val[9] = {0x00, 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};
    fpROI = fopen(cmdl->roimapFile, "r");
    if (fpROI == NULL)
    {
        printf("jpeg_map.roi: Jenc_Error, Can Not Open File %s\n", cmdl->roimapFile);
        return -1;
    }
    while(fgets(buf, 30, fpROI)!=NULL)
    {
        if(buf[0] == 'r')
        {
            sscanf(buf,"roi=(%d,%d,%d,%d)",&RoiRectLeft[RoiRectNum],&RoiRectTop[RoiRectNum],&RoiRectWidth[RoiRectNum],&RoiRectHeight[RoiRectNum]);
            if(RoiRectLeft[RoiRectNum]+RoiRectWidth[RoiRectNum] > cmdl->width || RoiRectTop[RoiRectNum]+RoiRectHeight[RoiRectNum] > cmdl->height)
            {
                printf("jpeg_map.roi: Jenc_Error, The Roi Region Coordinate Input Is Out Of Picture Range!\n");
                fclose(fpROI);
                return -1;
            }
            if(cmdl->codingMode == JPEGENC_420_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/16;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/16;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+15)/16;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+15)/16;
            }
            else if(cmdl->codingMode == JPEGENC_422_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/16;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/8;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+15)/16;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+7)/8;
            }
            else if(cmdl->codingMode == JPEGENC_MONO_MODE)
            {
                RoiRectLeft[RoiRectNum] = RoiRectLeft[RoiRectNum]/8;
                RoiRectTop[RoiRectNum] = RoiRectTop[RoiRectNum]/8;
                RoiRectWidth[RoiRectNum] = (RoiRectWidth[RoiRectNum]+7)/8;
                RoiRectHeight[RoiRectNum] = (RoiRectHeight[RoiRectNum]+7)/8;
            }
            RoiRectNum++;
        }
    }
    fclose(fpROI);

    if(cmdl->codingMode == JPEGENC_420_MODE)
    {
        ImageWidthMB = (cmdl->width+15)/16;
        ImageHeightMB = (cmdl->height+15)/16;
    }
    else if(cmdl->codingMode == JPEGENC_422_MODE)
    {
        ImageWidthMB = (cmdl->width+15)/16;
        ImageHeightMB = (cmdl->height+7)/8;
    }
    else if(cmdl->codingMode == JPEGENC_MONO_MODE)
    {
        ImageWidthMB = (cmdl->width+7)/8;
        ImageHeightMB = (cmdl->height+7)/8;
    }
    if(cmdl->partialCoding == 0)
    {
        RoiSize = (ImageWidthMB*ImageHeightMB+7)/8;
        sliceRowsMb = ImageHeightMB;
    }
    else
    {
        if(cmdl->codingMode == JPEGENC_420_MODE)
        {
            sliceRowsMb = cmdl->restartInterval;
        }
        else
        {
            sliceRowsMb = cmdl->restartInterval*2;
        }
        RoiSizePerSlice = (sliceRowsMb*ImageWidthMB+7)/8;
        RoiSize = RoiSizePerSlice*((ImageHeightMB+sliceRowsMb-1)/sliceRowsMb);
    }
    roimapMem.mem_type = EWL_MEM_TYPE_VPU_WORKING;
    if(JencEWLMallocLinear(ewl_inst, RoiSize, 0, &roimapMem) != EWL_OK)
    {
        fprintf(stderr, "Failed to allocate RoiMap Memory!\n");
        roimapMem.virtualAddress = NULL;
        return 1;
    }
    memset(roimapMem.virtualAddress, 0, RoiSize);
    // ROI bitmap need 1
    roimap_virtualAddr = (u8 *)roimapMem.virtualAddress;

    for(int roinum = 0; roinum < RoiRectNum; roinum++)
    {
        roimap_virtualAddr = (u8 *)roimapMem.virtualAddress;
        for(int rows = 0; rows < ImageHeightMB; rows++)
        {
            for(int cals = 0; cals < ImageWidthMB; cals++)
            {
                if((rows >= RoiRectTop[roinum] && rows < (RoiRectTop[roinum] + RoiRectHeight[roinum]))
                     && cals >= RoiRectLeft[roinum] && cals < (RoiRectLeft[roinum] + RoiRectWidth[roinum]))//ROI
                {
                     RoiRegion_SetVal[bitNum] = 1;
                }
                else
                {
                    RoiRegion_SetVal[bitNum] = 0;
                }
                bitNum++;
                if(bitNum == 8 || (rows == ImageHeightMB-1 && cals == ImageWidthMB-1) || (MbNumPerSlice == sliceRowsMb*ImageWidthMB-1))
                {
                    roiValTmp = RoiRegion_SetVal[0]*128+RoiRegion_SetVal[1]*64+RoiRegion_SetVal[2]*32+
                    RoiRegion_SetVal[3]*16+RoiRegion_SetVal[4]*8+RoiRegion_SetVal[5]*4+RoiRegion_SetVal[6]*2+
                    RoiRegion_SetVal[7]*1;
                    *roimap_virtualAddr = *roimap_virtualAddr | roiValTmp;
                    roimap_virtualAddr++;
                    roiValTmp = 0;
                    bitNum = 0;
                    memset(RoiRegion_SetVal, 0, sizeof(RoiRegion_SetVal));
                }
                MbNumPerSlice++;
                if(MbNumPerSlice == sliceRowsMb*ImageWidthMB || (rows == ImageHeightMB-1 && cals == ImageWidthMB-1))
                {
                    MbNumPerSlice=0;
                }
            }
        }
    }
    return 0;
}


/*------------------------------------------------------------------------------
    Function name   : Jenc_osd_overlap
    Description     : check osd input overlap
    Return type     : i32
    Argument        : cml
    Argument        : i - osd channel to check
------------------------------------------------------------------------------*/
i32 jpeg_osd_overlap(commandLine_s *cml, u8 id)
{
    int i,tmpx, tmpy;
    int blockW = 64;
    int blockH = 16;
    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        if(!((cml->overlayEnables >> i) & 1) || i == id) continue;
        u32 xoffsetId = cml->olXoffset[id];
        u32 yoffsetId = cml->olYoffset[id];
        u32 cropWidthId = cml->olCropWidth[id];
        u32 cropHeightId = cml->olCropHeight[id];


        u32 xoffset = cml->olXoffset[i];
        u32 yoffset = cml->olYoffset[i];
        u32 cropWidth = cml->olCropWidth[i];
        u32 cropHeight = cml->olCropHeight[i];

        if(!((xoffsetId+cropWidthId) <= xoffset || (yoffsetId + cropHeightId) <= yoffset ||
             xoffsetId >= (xoffset + cropWidth) || yoffsetId >= (yoffset + cropHeight)))
        {
            return -1;
        }

        /* Check not share CTB: avoid loop all ctb */
        if((xoffsetId+cropWidthId) <= xoffset && (yoffsetId+cropHeightId) <= yoffset)
        {
            tmpx = ((xoffsetId+cropWidthId -1)/blockW) * blockW;
            tmpy = ((yoffsetId+cropHeightId -1)/blockH) * blockH;

            if(tmpx + blockW    > xoffset && tmpy + blockH    > yoffset)
            {
                return -1;
            }
        }
        else if((xoffsetId+cropWidthId) <= xoffset && yoffsetId >= (yoffset + cropHeight))
        {
            tmpx = ((xoffsetId+cropWidthId -1)/blockW) * blockW;
            tmpy = ((yoffset + cropHeight - 1)/blockH) * blockH;
            if(tmpx + blockW    > xoffset && tmpy + blockH > yoffsetId)
            {
                return -1;
            }
        }
        else if(xoffsetId >= (xoffset + cropWidth) && (yoffsetId+cropHeightId) <= yoffset)
        {
            tmpx = ((xoffset+cropWidth -1)/blockW) * blockW;
            tmpy = ((yoffsetId + cropHeightId -1)/blockH) * blockH;
            if(tmpx + blockW > xoffsetId && tmpy + blockH > yoffset)
            {
                return -1;
            }
        }
        else if(xoffsetId >= (xoffset + cropWidth) && yoffsetId >= (yoffset + cropHeight))
        {
            tmpx = ((xoffset+cropWidth - 1)/blockW) * blockW;
            tmpy = ((yoffset + cropHeight - 1)/blockH) * blockH;
            if(tmpx + blockW > xoffsetId && tmpy + blockH > yoffsetId)
            {
                return -1;
            }
        }
        else if((xoffsetId+cropWidthId) <= xoffset)
        {
            tmpx = ((xoffsetId+cropWidthId - 1)/blockW) * blockW;
            if(tmpx + blockW > xoffset)
                return -1;
        }
        else if((yoffsetId+cropHeightId) <= yoffset)
        {
            tmpy = ((yoffsetId+cropHeightId - 1)/blockH) * blockH;
            if(tmpy + blockH > yoffset)
                return -1;
        }
        else if(xoffsetId >= (xoffset + cropWidth))
        {
            tmpx = ((xoffset+cropWidth - 1)/blockW) * blockW;
            if(tmpx + blockW > xoffsetId)
                return -1;
        }
        else if(yoffsetId >= (yoffset + cropHeight))
        {
            tmpy = ((yoffset+cropHeight - 1)/blockH) * blockH;
            if(tmpy + blockH > yoffsetId)
                return -1;
        }
    }

    return 0;
}


/*------------------------------------------------------------------------------

    OpenEncoder

------------------------------------------------------------------------------*/
static int OpenEncoder(commandLine_s * cml, JpegEncInst * pEnc)
{
    JpegEncRet ret;

    /* An example of user defined quantization table */
    u8 qTableLuma[64] = {
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1 };
    u8 qTableChroma[64] = {
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1,
                     1, 1, 1, 1, 1, 1, 1, 1 };

    if ((cml->qLevel == USER_DEFINED_QTABLE) && (0 != strcmp(cml->qTablePath, "")))
    {
        if (0 != ReadQTable(cml->qTablePath, qTableLuma, qTableChroma))
        {
            fprintf(stderr, "Failed to open qtable from file %s\n. ", cml->qTablePath);
            return -1;
        }
    }

#ifndef TB_DEFINED_COMMENT
    FILE *fileCom = NULL;
#endif

    /* Default resolution, try parsing input file name */
    if(cml->lumWidthSrc == DEFAULT || cml->lumHeightSrc == DEFAULT)
    {
        if (GetResolution(cml->input, &cml->lumWidthSrc, &cml->lumHeightSrc))
        {
            /* No dimensions found in filename, using default QCIF */
            cml->lumWidthSrc = 176;
            cml->lumHeightSrc = 144;
        }
    }

    /* Encoder initialization */
    if(cml->width == DEFAULT)
        cml->width = cml->lumWidthSrc;

    if(cml->height == DEFAULT)
        cml->height = cml->lumHeightSrc;

    /* Not sure the usage of following codes, comment out for now */
    /*if (cml->exp_of_input_alignment == 7)
    {
      if (cml->frameType==JPEGENC_YUV420_PLANAR || cml->frameType==JPEGENC_YVU420_PLANAR)
        cml->horOffsetSrc = ((cml->horOffsetSrc + 256 - 1) & (~(256 - 1)));
      else
        cml->horOffsetSrc = ((cml->horOffsetSrc + 128 - 1) & (~(128 - 1)));

      if ((cml->lumWidthSrc - cml->horOffsetSrc)< cml->width)
        cml->horOffsetSrc = 0;
    }*/

    /* overlay controls */
    u32 i;
    for(i = 0; i< MAX_OVERLAY_NUM; i++)
    {
        if((cml->overlayEnables >> i) & 1)
        {
            if(cml->olYStride[i] == 0)
            {
                switch(cml->olFormat[i])
                {
                case 0: //ARGB
                    if(cml->olSuperTile[i] == 0)
                        cml->olYStride[i] = cml->olWidth[i]*4;
                    else
                        cml->olYStride[i] = ((cml->olWidth[i]+63) / 64) * 64 * 64 * 4;
                    break;
                case 1: //NV12
                    cml->olYStride[i] = cml->olWidth[i];
                    break;
                case 2: //Bitmap
                    cml->olYStride[i] = cml->olWidth[i] / 8;
                    break;
                default: break;
                }
            }

            if(cml->olUVStride[i] == 0) cml->olUVStride[i] = cml->olYStride[i];

            if(cml->olCropHeight[i] == 0) cml->olCropHeight[i] = cml->olHeight[i];
            if(cml->olCropWidth[i] == 0) cml->olCropWidth[i] = cml->olWidth[i];
            if(cml->olScaleWidth[i] == 0) cml->olScaleWidth[i] = cml->olCropWidth[i];
            if(cml->olScaleHeight[i] == 0) cml->olScaleHeight[i] = cml->olCropHeight[i];

            if(cml->olWidth[i] == 0 || cml->olHeight[i] == 0 || cml->olCropWidth == 0 || cml->olCropHeight == 0)
            {
                fprintf(stderr, "\nInvalid overlay region %d size\n", i);
                return -1;
            }

            u64 widthMax = (cml->rotation == 1 || cml->rotation == 2)?
                                          (cml->height - cml->verOffsetSrc) : (cml->width - cml->horOffsetSrc);
            u64 heightMax = (cml->rotation == 1 || cml->rotation == 2)?
                                            (cml->width - cml->horOffsetSrc) : (cml->height - cml->verOffsetSrc);
            if(cml->olCropWidth[i] + cml->olXoffset[i] > widthMax ||
            cml->olCropHeight[i] + cml->olYoffset[i] > heightMax)
            {
                fprintf(stderr, "\nInvalid overlay region %d offset\n", i);
                return -1;
            }

            if(cml->olCropXoffset[i] + cml->olCropWidth[i] > cml->olWidth[i] ||
                  cml->olCropYoffset[i] + cml->olCropHeight[i] > cml->olHeight[i])
            {
                fprintf(stderr, "\nInvalid overlay region %d cropping offset\n", i);
                return -1;
            }

            if(cml->olFormat[i] == 2 && (cml->olCropWidth[i] % 8 != 0))
            {
                fprintf(stderr,"\nInvalid overlay region %d cropping width for bitmap \n", i);
                return -1;
            }

            if(jpeg_osd_overlap(cml, i))
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR overlay area overlapping \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 && cml->olFormat[i] != 0)
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR Super tile only support ARGB8888 format \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 && i != 0)
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR Super tile only support for channel 1 \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 && cml->partialCoding != 0)
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR OSD Super tile does not support partialCoding  \n");
                return -1;
            }

            if((cml->olSuperTile[i] == 0 && cml->olScaleWidth[i] != cml->olCropWidth[i]) ||
                    (cml->olSuperTile[i] == 0 && cml->olScaleHeight[i] != cml->olCropHeight[i]) ||
                    (cml->olScaleWidth[i] != cml->olCropWidth[i] && i != 0) ||
                    (cml->olScaleHeight[i]!= cml->olCropHeight[i] && i != 0))
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR Up scale only work for special usage \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 &&
                (cml->olCropXoffset[i] % 64 != 0    || cml->olCropYoffset[i] % 64 != 0))
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR super tile cropping offset must be 64 aligned \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 &&
                  (cml->olScaleWidth[i] < cml->olCropWidth[i] ||
                    cml->olScaleHeight[i] < cml->olCropHeight[i]))
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR osd only support upscaling but no downscaling \n");
                return -1;
            }

            if(cml->olSuperTile[i] != 0 &&
                  ((cml->olScaleWidth[i] & 1) ||
                  cml->olScaleWidth[i] > (cml->olCropWidth[i]*2) ||
                  (cml->olScaleHeight[i] & 1) ||
                  cml->olScaleHeight[i] > (cml->olCropHeight[i] * 2)))
            {
                fprintf(stderr, "Jenc_VCEncSetCodingCtrl: ERROR osd upscaling width or height \n");
                return -1;
            }
        }
    }

    /* lossless mode */
    if (cml->predictMode!=0)
    {
        cfg.losslessEn = 1;
        cfg.predictMode = cml->predictMode;
        cfg.ptransValue = cml->ptransValue;
    }
    else
    {
        cfg.losslessEn = 0;
    }

    cfg.rotation = (JpegEncPictureRotation)cml->rotation;
    /* Currently Not sure why having this limitation, will delete after regression verified
       This may cause some JPEG cases fail md5 comparasion */
    cfg.inputWidth = (cml->lumWidthSrc + 15) & (~15);   /* API limitation */
    if (cfg.inputWidth != (u32)cml->lumWidthSrc)
        fprintf(stdout, "Warning: Input width must be multiple of 16!\n");
    cfg.inputWidth = cml->lumWidthSrc;
    cfg.inputHeight = cml->lumHeightSrc;

    if(cfg.rotation && cfg.rotation != JPEGENC_ROTATE_180)
    {
        /* full */
        cfg.xOffset = cml->verOffsetSrc;
        cfg.yOffset = cml->horOffsetSrc;

        cfg.codingWidth = cml->height;
        cfg.codingHeight = cml->width;
        cfg.xDensity = cml->ydensity;
        cfg.yDensity = cml->xdensity;
    }
    else
    {
        /* full */
        cfg.xOffset = cml->horOffsetSrc;
        cfg.yOffset = cml->verOffsetSrc;

        cfg.codingWidth = cml->width;
        cfg.codingHeight = cml->height;
        cfg.xDensity = cml->xdensity;
        cfg.yDensity = cml->ydensity;
    }
    cfg.mirror = cml->mirror;

    if (cml->qLevel == USER_DEFINED_QTABLE)
    {
        cfg.qTableLuma = qTableLuma;
        cfg.qTableChroma = qTableChroma;
    }
    else
    {
        cfg.qLevel = cml->qLevel;
    }

    cfg.restartInterval = cml->restartInterval;
    cfg.codingType = (JpegEncCodingType)cml->partialCoding;
    cfg.frameType = (JpegEncFrameType)cml->frameType;
    cfg.unitsType = (JpegEncAppUnitsType)cml->unitsType;
    cfg.markerType = (JpegEncTableMarkerType)cml->markerType;
    cfg.colorConversion.type = (JpegEncColorConversionType)cml->colorConversion;
    if (cfg.colorConversion.type == JPEGENC_RGBTOYUV_USER_DEFINED)
    {
        /* User defined RGB to YCbCr conversion coefficients, scaled by 16-bits */
        cfg.colorConversion.coeffA = 20000;
        cfg.colorConversion.coeffB = 44000;
        cfg.colorConversion.coeffC = 5000;
        cfg.colorConversion.coeffE = 35000;
        cfg.colorConversion.coeffF = 38000;
        cfg.colorConversion.coeffG = 35000;
        cfg.colorConversion.coeffH = 38000;
        cfg.colorConversion.LumaOffset = 0;
    }
    writeOutput = cml->writeOut;
    cfg.codingMode = (JpegEncCodingMode)cml->codingMode;

    /* low latency */
    cfg.inputLineBufEn = (cml->inputLineBufMode>0) ? 1 : 0;
    cfg.inputLineBufLoopBackEn = (cml->inputLineBufMode==1||cml->inputLineBufMode==2) ? 1 : 0;
    cfg.inputLineBufDepth = cml->inputLineBufDepth;
    cfg.amountPerLoopBack = cml->amountPerLoopBack;
    cfg.inputLineBufHwModeEn = (cml->inputLineBufMode==2||cml->inputLineBufMode==4) ? 1 : 0;
    cfg.inputLineBufCbFunc = Jenc_VCEncInputLineBufDone;
    cfg.inputLineBufCbData = &inputMbLineBuf;
    cfg.hashType = cml->hashtype;

    /*stream multi-segment*/
    cfg.streamMultiSegmentMode = cml->streamMultiSegmentMode;
    cfg.streamMultiSegmentAmount = cml->streamMultiSegmentAmount;
    cfg.streamMultiSegCbFunc = &EncStreamSegmentReady;
    cfg.streamMultiSegCbData = &streamSegCtl;

    /* constant chroma control */
    cfg.constChromaEn = cml->constChromaEn;
    cfg.constCb = cml->constCb;
    cfg.constCr = cml->constCr;

    /* jpeg rc*/
    cfg.targetBitPerSecond = cml->bitPerSecond;
    cfg.frameRateNum = 1;
    cfg.frameRateDenom = 1;

    //framerate valid only when RC enabled
    if (cml->bitPerSecond)
    {
        cfg.frameRateNum = cml->frameRateNum;
        cfg.frameRateDenom = cml->frameRateDenom;
    }
    cfg.qpmin = cml->qpmin;
    cfg.qpmax = cml->qpmax;
    cfg.fixedQP = cml->fixedQP;
    cfg.rcMode   = cml->rcMode;
    cfg.picQpDeltaMax = cml->picQpDeltaMax;
    cfg.picQpDeltaMin = cml->picQpDeltaMin;

    /*stride*/
    cfg.exp_of_input_alignment = cml->exp_of_input_alignment;

    /* overlay control */
    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        cfg.olEnable[i] = (cml->overlayEnables >> i) & 1;
        cfg.olFormat[i] = cml->olFormat[i];
        cfg.olAlpha[i] = cml->olAlpha[i];
        cfg.olWidth[i] = cml->olWidth[i];
        cfg.olCropWidth[i] = cml->olCropWidth[i];
        cfg.olHeight[i] = cml->olHeight[i];
        cfg.olCropHeight[i] = cml->olCropHeight[i];
        cfg.olXoffset[i] = cml->olXoffset[i];
        cfg.olCropXoffset[i] = cml->olCropXoffset[i];
        cfg.olYoffset[i] = cml->olYoffset[i];
        cfg.olCropYoffset[i] = cml->olCropYoffset[i];
        cfg.olYStride[i] = cml->olYStride[i];
        cfg.olUVStride[i] = cml->olUVStride[i];
        cfg.olSuperTile[i] = cml->olSuperTile[i];
        cfg.olScaleWidth[i] = cml->olScaleWidth[i];
        cfg.olScaleHeight[i] = cml->olScaleHeight[i];
    }

    /* SRAM power down mode disable  */
    cfg.sramPowerdownDisable = cml->sramPowerdownDisable;

#ifdef NO_OUTPUT_WRITE
    writeOutput = 0;
#endif

    if(cml->thumbnail < 0 || cml->thumbnail > 3)
    {
        fprintf(stderr, "\nNot valid thumbnail format!");
        return -1;
    }

    if(cml->thumbnail != 0)
    {
        FILE *fThumb;
        size_t size;
        fThumb = fopen(cml->inputThumb, "rb");
        if(fThumb == NULL)
        {
            fprintf(stderr, "\nUnable to open Thumbnail file: %s\n", cml->inputThumb);
            return -1;
        }

        switch(cml->thumbnail)
        {
        case 1:
            fseek(fThumb,0,SEEK_END);
            thumbDataLength = ftell(fThumb);
            fseek(fThumb,0,SEEK_SET);
            break;
        case 2:
            thumbDataLength = 3*256 + cml->widthThumb * cml->heightThumb;
            break;
        case 3:
            thumbDataLength = cml->widthThumb * cml->heightThumb * 3;
            break;
        default:
            assert(0);
        }

        thumbData = (u8*)malloc(thumbDataLength);
        size = fread(thumbData,1,thumbDataLength, fThumb);
        fclose(fThumb);
    }

    cfg.AXIAlignment = cml->AXIAlignment;
    cfg.burstMaxLength = cml->burstMaxLength;

    cfg.mmuEnable = cml->mmuEnable;

/* use either "hard-coded"/testbench COM data or user specific */
#ifdef TB_DEFINED_COMMENT
    cfg.comLength = comLen;
    cfg.pCom = comment;
#else
    cfg.comLength = cml->comLength;

    if(cfg.comLength)
    {
        /* allocate mem for & read comment data */
        cfg.pCom = (u8 *) malloc(cfg.comLength);

        fileCom = fopen(cml->com, "rb");
        if(fileCom == NULL)
        {
            fprintf(stderr, "\nUnable to open COMMENT file: %s\n", cml->com);
            return -1;
        }

        fread((void *)cfg.pCom, 1, cfg.comLength, fileCom);
        fclose(fileCom);
    }

#endif

#ifndef ASIC_WAVE_TRACE_TRIGGER
    fprintf(stdout, "Init config: %dx%d @ x%dy%d => %dx%d   \n",
            cfg.inputWidth, cfg.inputHeight, cfg.xOffset, cfg.yOffset,
            cfg.codingWidth, cfg.codingHeight);

    fprintf(stdout,
            "\n\t**********************************************************\n");
    fprintf(stdout, "\n\t-JPEG: ENCODER CONFIGURATION\n");
    if (cml->qLevel == USER_DEFINED_QTABLE)
    {
        i32 i;
        fprintf(stdout, "JPEG: qTableLuma \t:");
        for (i = 0; i < 64; i++)
            fprintf(stdout, " %d", cfg.qTableLuma[i]);
        fprintf(stdout, "\n");
        fprintf(stdout, "JPEG: qTableChroma \t:");
        for (i = 0; i < 64; i++)
            fprintf(stdout, " %d", cfg.qTableChroma[i]);
        fprintf(stdout, "\n");
    }
    else
        fprintf(stdout, "\t-JPEG: qp \t\t:%d\n", cfg.qLevel);
    fprintf(stdout, "\t-JPEG: inX \t\t:%d\n", cfg.inputWidth);
    fprintf(stdout, "\t-JPEG: inY \t\t:%d\n", cfg.inputHeight);
    fprintf(stdout, "\t-JPEG: outX \t\t:%d\n", cfg.codingWidth);
    fprintf(stdout, "\t-JPEG: outY \t\t:%d\n", cfg.codingHeight);
    fprintf(stdout, "\t-JPEG: rst \t\t:%d\n", cfg.restartInterval);
    fprintf(stdout, "\t-JPEG: xOff \t\t:%d\n", cfg.xOffset);
    fprintf(stdout, "\t-JPEG: yOff \t\t:%d\n", cfg.yOffset);
    fprintf(stdout, "\t-JPEG: frameType \t:%d\n", cfg.frameType);
    fprintf(stdout, "\t-JPEG: colorConversionType :%d\n", cfg.colorConversion.type);
    fprintf(stdout, "\t-JPEG: colorConversionA    :%d\n", cfg.colorConversion.coeffA);
    fprintf(stdout, "\t-JPEG: colorConversionB    :%d\n", cfg.colorConversion.coeffB);
    fprintf(stdout, "\t-JPEG: colorConversionC    :%d\n", cfg.colorConversion.coeffC);
    fprintf(stdout, "\t-JPEG: colorConversionE    :%d\n", cfg.colorConversion.coeffE);
    fprintf(stdout, "\t-JPEG: colorConversionF    :%d\n", cfg.colorConversion.coeffF);
    fprintf(stdout, "\t-JPEG: rotation \t:%d\n", cfg.rotation);
    fprintf(stdout, "\t-JPEG: codingType \t:%d\n", cfg.codingType);
    fprintf(stdout, "\t-JPEG: codingMode \t:%d\n", cfg.codingMode);
    fprintf(stdout, "\t-JPEG: markerType \t:%d\n", cfg.markerType);
    fprintf(stdout, "\t-JPEG: units \t\t:%d\n", cfg.unitsType);
    fprintf(stdout, "\t-JPEG: xDen \t\t:%d\n", cfg.xDensity);
    fprintf(stdout, "\t-JPEG: yDen \t\t:%d\n", cfg.yDensity);


    fprintf(stdout, "\t-JPEG: thumbnail format\t:%d\n", cml->thumbnail);
    fprintf(stdout, "\t-JPEG: Xthumbnail\t:%d\n", cml->widthThumb);
    fprintf(stdout, "\t-JPEG: Ythumbnail\t:%d\n", cml->heightThumb);

    fprintf(stdout, "\t-JPEG: First picture\t:%d\n", cml->firstPic);
    fprintf(stdout, "\t-JPEG: Last picture\t\t:%d\n", cml->lastPic);
    fprintf(stdout, "\t-JPEG: inputLineBufEn \t\t:%d\n", cfg.inputLineBufEn);
    fprintf(stdout, "\t-JPEG: inputLineBufLoopBackEn \t:%d\n", cfg.inputLineBufLoopBackEn);
    fprintf(stdout, "\t-JPEG: inputLineBufHwModeEn \t:%d\n", cfg.inputLineBufHwModeEn);
    fprintf(stdout, "\t-JPEG: inputLineBufDepth \t:%d\n", cfg.inputLineBufDepth);
    fprintf(stdout, "\t-JPEG: amountPerLoopBack \t:%d\n", cfg.amountPerLoopBack);

    fprintf(stdout, "\t-JPEG: streamMultiSegmentMode \t:%d\n", cfg.streamMultiSegmentMode);
    fprintf(stdout, "\t-JPEG: streamMultiSegmentAmount \t:%d\n", cfg.streamMultiSegmentAmount);

    fprintf(stdout, "\t-JPEG: constChromaEn \t:%d\n", cfg.constChromaEn);
    fprintf(stdout, "\t-JPEG: constCb \t:%d\n", cfg.constCb);
    fprintf(stdout, "\t-JPEG: constCr \t:%d\n", cfg.constCr);

#ifdef TB_DEFINED_COMMENT
    fprintf(stdout, "\n\tNOTE! Using comment values defined in testbench!\n");
#else
    fprintf(stdout, "\t-JPEG: comlen \t\t:%d\n", cfg.comLength);
    fprintf(stdout, "\t-JPEG: COM \t\t:%s\n", cfg.pCom);
#endif
    fprintf(stdout,
            "\n\t**********************************************************\n\n");
#endif

    if((ret = JencInit(&cfg, pEnc, NULL)) != JPEGENC_OK)
    {
        fprintf(stderr, "Failed to initialize the encoder. Jenc_Error code: %8i\n", ret);
        return (int)ret;
    }

    if(thumbData != NULL)
    {
        JpegEncThumb jpegThumb;
        jpegThumb.format = cml->thumbnail == 1 ? JPEGENC_THUMB_JPEG : cml->thumbnail == 3 ?
                            JPEGENC_THUMB_RGB24 : JPEGENC_THUMB_PALETTE_RGB8;
        jpegThumb.width = cml->widthThumb;
        jpegThumb.height = cml->heightThumb;
        jpegThumb.data = thumbData;
        jpegThumb.dataLength = thumbDataLength;

        ret = JencSetThumbnail(*pEnc, &jpegThumb );
        if(ret != JPEGENC_OK )
        {
            fprintf(stderr, "Failed to set thumbnail. Jenc_Error code: %8i\n", ret);
            return -1;
        }
    }
    return 0;
}

/*------------------------------------------------------------------------------

    CloseEncoder

------------------------------------------------------------------------------*/
void CloseEncoder(JpegEncInst encoder)
{
    JpegEncRet ret;

    if((ret = JencRelease(encoder)) != JPEGENC_OK)
    {
        fprintf(stderr, "Failed to release the encoder. Jenc_Error code: %8i\n", ret);
    }
}

/*------------------------------------------------------------------------------

    Parameter

------------------------------------------------------------------------------*/
int ParseDelim(char *optArg, char delim)
{
    i32 i;

    for (i = 0; i < (i32)strlen(optArg); i++)
        if (optArg[i] == delim)
        {
            optArg[i] = 0;
            return i;
        }

    return -1;
}

int Parameter(i32 argc, char **argv, commandLine_s * cml)
{
    i32 ret,i;
    char *optarg;
    argument_s argument;
    int status = 0;

    memset(cml, 0, sizeof(commandLine_s));
    strcpy(cml->input, "input.yuv");
    strcpy(cml->inputThumb, "thumbnail.jpg");
    strcpy(cml->com, "com.txt");
    strcpy(cml->output, "stream.jpg");
    strcpy(cml->qTablePath, "");
    cml->useVcmd = -1;
    cml->roimapFile = NULL;
    cml->nonRoiFilter = NULL;
    cml->nonRoiLevel = 10;
    cml->firstPic = 0;
    cml->lastPic = 0;
    cml->lumWidthSrc = DEFAULT;
    cml->lumHeightSrc = DEFAULT;
    cml->width = DEFAULT;
    cml->height = DEFAULT;
    cml->horOffsetSrc = 0;
    cml->verOffsetSrc = 0;
    cml->qLevel = 1;
    cml->restartInterval = 0;
    cml->thumbnail = 0;
    cml->widthThumb = 32;
    cml->heightThumb = 32;
    cml->frameType = 0;
    cml->colorConversion = 0;
    cml->rotation = 0;
    cml->partialCoding = 0;
    cml->codingMode = 0;
    cml->markerType = 0;
    cml->unitsType = 0;
    cml->xdensity = 1;
    cml->ydensity = 1;
    cml->writeOut = 1;
    cml->comLength = 0;
    cml->inputLineBufMode = 0;
    cml->inputLineBufDepth = 1;
    cml->amountPerLoopBack = 0;
    cml->hashtype = 0;
    cml->mirror = 0;
    cml->formatCustomizedType = -1;
    cml->constChromaEn = 0;
    cml->constCb = 0x80;
    cml->constCr = 0x80;
    cml->predictMode = 0;
    cml->ptransValue = 0;
    cml->bitPerSecond =0;
    cml->mjpeg = 0;
    cml->frameRateNum = 30;
    cml->frameRateDenom = 1;
    cml->rcMode        = 1;
    cml->picQpDeltaMin = -2;
    cml->picQpDeltaMax = 3;
    cml->qpmin = 0;
    cml->qpmax = 51;
    cml->fixedQP = -1;
    cml->exp_of_input_alignment = 4;
    cml->streamBufChain = 0;
    cml->streamMultiSegmentMode = 0;
    cml->streamMultiSegmentAmount = 4;
    strcpy(cml->dec400CompTableinput, "dec400CompTableinput.bin");
    cml->AXIAlignment = 0;
    cml->mmuEnable = 0;
    /*Overlay*/
    cml->overlayEnables = 0;
    strcpy(cml->osdDec400CompTableInput, "osdDec400CompTableinput.bin");

    for(i = 0; i < MAX_OVERLAY_NUM; i++)
    {
        strcpy(cml->olInput[i], "olInput.yuv");
        cml->olFormat[i] = 0;
        cml->olAlpha[i] = 0;
        cml->olWidth[i] = 0;
        cml->olHeight[i] = 0;
        cml->olXoffset[i] = 0;
        cml->olYoffset[i] = 0;
        cml->olYStride[i] = 0;
        cml->olUVStride[i] = 0;
        cml->olSuperTile[i] = 0;
        cml->olScaleWidth[i] = 0;
        cml->olScaleHeight[i] = 0;
    }

    cml->sramPowerdownDisable = 0;
    cml->burstMaxLength = ENCH2_DEFAULT_BURST_LENGTH;

    argument.optCnt = 1;
    while((ret = EncGetOption(argc, argv, options, &argument)) != -1)
    {
        if(ret == -2)
        {
            status = -1;
        }

        optarg = argument.optArg;
        switch (argument.shortOpt)
        {
        case 'H':
            Help();
            exit(0);
        case 'i':
            if(strlen(optarg) < MAX_PATH)
            {
                strcpy(cml->input, optarg);
            }
            else
            {
                status = -1;
            }
            break;
        case 'I':
            if(strlen(optarg) < MAX_PATH)
            {
                strcpy(cml->inputThumb, optarg);
            }
            else
            {
                status = -1;
            }
            break;
        case 'o':
            if(strlen(optarg) < MAX_PATH)
            {
                strcpy(cml->output, optarg);
            }
            else
            {
                status = -1;
            }
            break;
        case 'C':
            if(strlen(optarg) < MAX_PATH)
            {
                strcpy(cml->com, optarg);
            }
            else
            {
                status = -1;
            }
            break;
        case 'a':
            cml->firstPic = atoi(optarg);
            break;
        case 'b':
            cml->lastPic = atoi(optarg);
            break;
        case 'x':
            cml->width = atoi(optarg);
            break;
        case 'y':
            cml->height = atoi(optarg);
            break;
        case 'w':
            cml->lumWidthSrc = atoi(optarg);
            break;
        case 'h':
            cml->lumHeightSrc = atoi(optarg);
            break;
        case 'X':
            cml->horOffsetSrc = atoi(optarg);
            break;
        case 'Y':
            cml->verOffsetSrc = atoi(optarg);
            break;
        case 'R':
            cml->restartInterval = atoi(optarg);
            break;
        case 'q':
            cml->qLevel = atoi(optarg);
            break;
        case 'g':
            cml->frameType = atoi(optarg);
            break;
        case 'v':
            cml->colorConversion = atoi(optarg);
            break;
        case 'G':
            cml->rotation = atoi(optarg);
            break;
        case 'p':
            cml->partialCoding = atoi(optarg);
            break;
        case 'm':
            cml->codingMode = atoi(optarg);
            break;
        case 't':
            cml->markerType = atoi(optarg);
            break;
        case 'u':
            cml->unitsType = atoi(optarg);
            break;
        case 'k':
            cml->xdensity = atoi(optarg);
            break;
        case 'l':
            cml->ydensity = atoi(optarg);
            break;
        case 'T':
            cml->thumbnail = atoi(optarg);
            break;
        case 'K':
            cml->widthThumb = atoi(optarg);
            break;
        case 'L':
            cml->heightThumb = atoi(optarg);
            break;
        case 'W':
            cml->writeOut = atoi(optarg);
            break;
        case 'c':
            cml->comLength = atoi(optarg);
            break;
        case 'P':
            trigger_point = atoi(optarg);
            break;
        case 'S':
            cml->inputLineBufMode = atoi(optarg);
            break;
        case 'N':
            cml->inputLineBufDepth = atoi(optarg);
            break;
        case 's':
            cml->amountPerLoopBack = atoi(optarg);
            break;
        case 'A':
            cml->hashtype = atoi(optarg);
            break;
        case 'M':
            cml->mirror = atoi(optarg);
            break;
        case 'D':
            cml->formatCustomizedType = atoi(optarg);
            break;
        case 'd':
            cml->constChromaEn = atoi(optarg);
            break;
        case 'e':
            cml->constCb = atoi(optarg);
            break;
        case 'f':
            cml->constCr = atoi(optarg);
            break;

        case '1':  /* --lossless [n] */
            cml->predictMode = atoi(optarg);
            break;
        case '2':  /* --ptrans [n] */
            cml->ptransValue = atoi(optarg);
            break;
        case 'B':
            cml->bitPerSecond = atoi(optarg);
            break;
        case 'J':
            cml->mjpeg = atoi(optarg);
            break;
        case 'n':
            cml->frameRateNum = atoi(optarg);
            break;
        case 'r':
            cml->frameRateDenom = atoi(optarg);
            break;
        case 'V':
            cml->rcMode = atoi(optarg);
            if((cml->rcMode < 0) || (cml->rcMode > 2))
                status = -1;
            break;
        case 'E':
            cml->qpmin = atoi(optarg);
            break;
        case 'F':
            cml->qpmax = atoi(optarg);
            break;
        case 'U':
            if ((i = ParseDelim(optarg, ':')) == -1) break;
            cml->picQpDeltaMin = atoi(optarg);
            optarg += i + 1;
            cml->picQpDeltaMax = atoi(optarg);

            if((cml->picQpDeltaMin < -10) || (cml->picQpDeltaMin > -1) || (cml->picQpDeltaMax < 1) || (cml->picQpDeltaMax > 10))
                status = -1;
            break;
        case 'O':
            cml->fixedQP = atoi(optarg);
            break;
        case 'Q':
            cml->exp_of_input_alignment = atoi(optarg);
            break;

        case '0':
            /* Check long option */
            if (strcmp(argument.longOpt, "streamBufChain") == 0)
            {
                cml->streamBufChain = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "streamMultiSegmentMode") == 0)
            {
                cml->streamMultiSegmentMode = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "streamMultiSegmentAmount") == 0)
            {
                cml->streamMultiSegmentAmount = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "qTableFile") == 0)
            {
                strcpy(cml->qTablePath, optarg);
                break;
            }

            if (strcmp(argument.longOpt, "dec400TableInput") == 0)
            {
                strcpy(cml->dec400CompTableinput, optarg);
                break;
            }

            if (strcmp(argument.longOpt, "overlayEnables") == 0)
            {
                cml->overlayEnables = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "osdDec400TableInput") == 0)
                strcpy(cml->osdDec400CompTableInput, optarg);

            if (strcmp(argument.longOpt, "olInput1") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[0], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat1") == 0)
            {
                cml->olFormat[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha1") == 0)
            {
                cml->olAlpha[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth1") == 0)
            {
                cml->olWidth[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth1") == 0)
            {
                cml->olCropWidth[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight1") == 0)
            {
                cml->olHeight[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight1") == 0)
            {
                cml->olCropHeight[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset1") == 0)
            {
                cml->olXoffset[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset1") == 0)
            {
                cml->olCropXoffset[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset1") == 0)
            {
                cml->olYoffset[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset1") == 0)
            {
                cml->olCropYoffset[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride1") == 0)
            {
                cml->olYStride[0] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride1") == 0)
            {
                cml->olUVStride[0] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olSuperTile1") == 0)
            {
                cml->olSuperTile[0] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olScaleWidth1") == 0)
            {
                cml->olScaleWidth[0] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olScaleHeight1") == 0)
            {
                cml->olScaleHeight[0] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput2") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[1], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat2") == 0)
            {
                cml->olFormat[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha2") == 0)
            {
                cml->olAlpha[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth2") == 0)
            {
                cml->olWidth[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth2") == 0)
            {
                cml->olCropWidth[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight2") == 0)
            {
                cml->olHeight[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight2") == 0)
            {
                cml->olCropHeight[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset2") == 0)
            {
                cml->olXoffset[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset2") == 0)
            {
                cml->olCropXoffset[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset2") == 0)
            {
                cml->olYoffset[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset2") == 0)
            {
                cml->olCropYoffset[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride2") == 0)
            {
                cml->olYStride[1] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride2") == 0)
            {
                cml->olUVStride[1] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput3") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[2], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat3") == 0)
            {
                cml->olFormat[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha3") == 0)
            {
                cml->olAlpha[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth3") == 0)
            {
                cml->olWidth[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth3") == 0)
            {
                cml->olCropWidth[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight3") == 0)
            {
                cml->olHeight[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight3") == 0)
            {
                cml->olCropHeight[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset3") == 0)
            {
                cml->olXoffset[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset3") == 0)
            {
                cml->olCropXoffset[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset3") == 0)
            {
                cml->olYoffset[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset3") == 0)
            {
                cml->olCropYoffset[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride3") == 0)
            {
                cml->olYStride[2] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride3") == 0)
            {
                cml->olUVStride[2] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput4") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[3], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat4") == 0)
            {
                cml->olFormat[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha4") == 0)
            {
                cml->olAlpha[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth4") == 0)
            {
                cml->olWidth[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth4") == 0)
            {
                cml->olCropWidth[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight4") == 0)
            {
                cml->olHeight[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight4") == 0)
            {
                cml->olCropHeight[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset4") == 0)
            {
                cml->olXoffset[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset4") == 0)
            {
                cml->olCropXoffset[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset4") == 0)
            {
                cml->olYoffset[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset4") == 0)
            {
                cml->olCropYoffset[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride4") == 0)
            {
                cml->olYStride[3] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride4") == 0)
            {
                cml->olUVStride[3] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput5") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[4], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat5") == 0)
            {
                cml->olFormat[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha5") == 0)
            {
                cml->olAlpha[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth5") == 0)
            {
                cml->olWidth[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth5") == 0)
            {
                cml->olCropWidth[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight5") == 0)
            {
                cml->olHeight[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight5") == 0)
            {
                cml->olCropHeight[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset5") == 0)
            {
                cml->olXoffset[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset5") == 0)
            {
                cml->olCropXoffset[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset5") == 0)
            {
                cml->olYoffset[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset5") == 0)
            {
                cml->olCropYoffset[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride5") == 0)
            {
                cml->olYStride[4] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride5") == 0)
            {
                cml->olUVStride[4] = atoi(optarg);
                break;
            }


            if (strcmp(argument.longOpt, "olInput6") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[5], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat6") == 0)
            {
                cml->olFormat[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha6") == 0)
            {
                cml->olAlpha[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth6") == 0)
            {
                cml->olWidth[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth6") == 0)
            {
                cml->olCropWidth[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight6") == 0)
            {
                cml->olHeight[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight6") == 0)
            {
                cml->olCropHeight[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset6") == 0)
            {
                cml->olXoffset[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset6") == 0)
            {
                cml->olCropXoffset[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset6") == 0)
            {
                cml->olYoffset[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset6") == 0)
            {
                cml->olCropYoffset[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride6") == 0)
            {
                cml->olYStride[5] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride6") == 0)
            {
                cml->olUVStride[5] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput7") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[6], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat7") == 0)
            {
                cml->olFormat[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha7") == 0)
            {
                cml->olAlpha[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth7") == 0)
            {
                cml->olWidth[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth7") == 0)
            {
                cml->olCropWidth[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight7") == 0)
            {
                cml->olHeight[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight7") == 0)
            {
                cml->olCropHeight[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset7") == 0)
            {
                cml->olXoffset[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset7") == 0)
            {
                cml->olCropXoffset[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset7") == 0)
            {
                cml->olYoffset[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset7") == 0)
            {
                cml->olCropYoffset[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride7") == 0)
            {
                cml->olYStride[6] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride7") == 0)
            {
                cml->olUVStride[6] = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "olInput8") == 0)
            {
                if(strlen(optarg) < MAX_PATH)
                {
                    strcpy(cml->olInput[7], optarg);
                }
                else
                {
                    status = -1;
                }
                break;
            }
            if (strcmp(argument.longOpt, "olFormat8") == 0)
            {
                cml->olFormat[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olAlpha8") == 0)
            {
                cml->olAlpha[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olWidth8") == 0)
            {
                cml->olWidth[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropWidth8") == 0)
            {
                cml->olCropWidth[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olHeight8") == 0)
            {
                cml->olHeight[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropHeight8") == 0)
            {
                cml->olCropHeight[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olXoffset8") == 0)
            {
                cml->olXoffset[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropXoffset8") == 0)
            {
                cml->olCropXoffset[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYoffset8") == 0)
            {
                cml->olYoffset[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olCropYoffset8") == 0)
            {
                cml->olCropYoffset[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olYStride8") == 0)
            {
                cml->olYStride[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "olUVStride8") == 0)
            {
                cml->olUVStride[7] = atoi(optarg);
                break;
            }
            if (strcmp(argument.longOpt, "AXIAlignment") == 0)
            {
                cml->AXIAlignment = strtoul(optarg, NULL, 16);
                break;
            }
            if (strcmp(argument.longOpt, "roimapFile") == 0)
            {
                cml->roimapFile = optarg;
                break;
            }
            if (strcmp(argument.longOpt, "nonRoiFilter") == 0)
            {
                cml->nonRoiFilter = optarg;
                break;
            }
            if (strcmp(argument.longOpt, "nonRoiLevel") == 0)
            {
                cml->nonRoiLevel = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "sramPowerdownDisable") == 0)
            {
                cml->sramPowerdownDisable = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "mmuEnable") == 0)
            {
                cml->mmuEnable = atoi(optarg);
                break;
            }
#ifdef FBDC_ENABLE
            if (strcmp(argument.longOpt, "UVheaderSize") == 0) {
                        cml->UVheaderSize = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "UVpayloadSize") == 0) {
                cml->UVpayloadSize = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "YheaderSize") == 0) {
                cml->YheaderSize = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "YpayloadSize") == 0) {
                cml->YpayloadSize = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "CropX") == 0) {
                        cml->CropX = atoi(optarg);
                break;
            }

            if (strcmp(argument.longOpt, "CropY") == 0) {
                cml->CropY = atoi(optarg);
                break;
            }
#endif
            /*AXI max burst length */
            if (strcmp(argument.longOpt, "burstMaxLength") == 0)
            {
                cml->burstMaxLength = atoi(optarg);
                break;
            }

        case '3':
            if (strcmp(argument.longOpt, "useVcmd") == 0)
                cml->useVcmd =    atoi(optarg);
            if (strcmp(argument.longOpt, "useMMU") == 0)
                cml->useMMU =    atoi(optarg);
            if (strcmp(argument.longOpt, "useDec400") == 0)
                cml->useDec400 =    atoi(optarg);
            if (strcmp(argument.longOpt, "useL2Cache") == 0)
                cml->useL2Cache =    atoi(optarg);
            break;

        default:
            break;
        }
    }

    return status;
}

/*------------------------------------------------------------------------------

    ReadPic

    Read raw YUV image data from file
    Image is divided into slices, each slice consists of equal amount of
    image rows except for the bottom slice which may be smaller than the
    others. sliceNum is the number of the slice to be read
    and sliceRows is the amount of rows in each slice (or 0 for all rows).

------------------------------------------------------------------------------*/
int ReadPic(u8 * image, i32 width, i32 height, i32 sliceNum, i32 sliceRows,
            i32 frameNum, char *name, u32 inputMode, u32 input_alignment)
{
    FILE *file = NULL;
    u64 frameSize;
    i64 frameOffset;
    u32 luma_stride,chroma_stride;
    i64 sliceLumOffset = 0;
    i64 sliceCbOffset = 0;
    i64 sliceCrOffset = 0;
    u64 sliceLumSize;        /* The size of one slice in bytes */
    u64 sliceChromaSize;     /* The size of one slice in bytes */
    u64 sliceCbSize;
    u64 sliceCrSize;
    i32 sliceLumWidth;       /* Picture line length to be read */
    i32 sliceCbWidth;
    i32 sliceCrWidth;
    i32 i;
    i32 lumRowBpp, cbRowBpp, crRowBpp; /* Bits per pixel for lum,cb,cr */
    i32 total_mb = 0;
    i32 sliceRowsOrg = sliceRows;
    size_t size;
    u32 lumaStrideSrc,chrStrideSrc;


    if(sliceRows == 0)
        sliceRows = height;

    if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
        width = (width + 31) & (~31);

    if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
    {
        frameSize = (i64)width * height * JencGetBitsPerPixel(inputMode)/8;
    }
    else if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_H264)
    {
        total_mb = (width/16) * (height/16);
        frameSize = (i64)total_mb/5*2048 + total_mb%5*400;
    }
    else
        JencGetAlignedPicSizebyFormat(inputMode,(u32)width,(u32)height,0,NULL,NULL,&frameSize);

    JencGetAlignedStride(width,inputMode,&luma_stride,&chroma_stride,input_alignment);

    JencGetAlignedStride(width,inputMode,&lumaStrideSrc,&chrStrideSrc,0);

    switch(inputMode)
    {
    case JPEGENC_YUV420_PLANAR:
    case JPEGENC_YVU420_PLANAR:
        lumRowBpp = 8;
        cbRowBpp = 4;
        crRowBpp = 4;
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
    case JPEGENC_YUV422_888:
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_FBC:
        lumRowBpp = 8;
        cbRowBpp = 8;
        crRowBpp = 0;
        break;
    case JPEGENC_YUV422_INTERLEAVED_YUYV:
    case JPEGENC_YUV422_INTERLEAVED_UYVY:
    case JPEGENC_RGB565:
    case JPEGENC_BGR565:
    case JPEGENC_RGB555:
    case JPEGENC_BGR555:
    case JPEGENC_RGB444:
    case JPEGENC_BGR444:
        lumRowBpp = 16;
        cbRowBpp = 0;
        crRowBpp = 0;
        break;
    case JPEGENC_YUV420_I010:
        lumRowBpp = 16;
        cbRowBpp = 8;
        crRowBpp = 8;
        break;
    case JPEGENC_YUV420_MS_P010:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        lumRowBpp = 16;
        cbRowBpp = 16;
        crRowBpp = 0;
        break;
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
    default:
        lumRowBpp = 32;
        cbRowBpp = 0;
        crRowBpp = 0;
        break;
    }

    sliceLumWidth = width*lumRowBpp/8;  /* Luma bytes per input row */
    sliceCbWidth = width*cbRowBpp/8;    /* Cb bytes per input row */
    sliceCrWidth = width*crRowBpp/8;
    /* Size of complete slice in input file */
    sliceLumSize = (u64)sliceLumWidth * sliceRows;
    sliceCbSize = (u64)sliceCbWidth * sliceRows / 2;
    sliceCrSize = (u64)sliceCrWidth * sliceRows / 2;

    /* Offset for frame start from start of file */
    frameOffset = frameSize * frameNum;
    /* Offset for slice luma start from start of frame */
    sliceLumOffset = sliceLumSize * sliceNum;
    /* Offset for slice cb start from start of frame */
    if(sliceCbSize)
        sliceCbOffset = (u64)width * height*(lumRowBpp/8) + sliceCbSize * sliceNum;
    /* Offset for slice cr start from start of frame */
    if(sliceCrSize)
        sliceCrOffset = (u64)width * height*(lumRowBpp/8) +
                        (u64)width/2 * height/2*(lumRowBpp/8) + sliceCrSize * sliceNum;

    /* Size of completed slice*/
    JencGetAlignedPicSizebyFormat(inputMode,(u32)width,(u32)sliceRows,input_alignment,&sliceLumSize,&sliceChromaSize,NULL);

    if (inputMode == JPEGENC_YUV420_PLANAR || inputMode == JPEGENC_YUV420_I010 || inputMode == JPEGENC_YUV420_8BIT_DAHUA_HEVC
            || inputMode == JPEGENC_YVU420_PLANAR)
    {
        sliceCbSize = sliceChromaSize / 2;
        sliceCrSize = sliceChromaSize / 2;
    }
    else
    {
        sliceCbSize = sliceChromaSize;
        sliceCrSize = 0;
    }

    /* The bottom slice may be smaller than the others */
    if(sliceRows * (sliceNum + 1) > height)
        sliceRows = height - sliceRows * sliceNum;

    if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
    {
        sliceLumOffset = (u64)width*sliceRowsOrg*sliceNum;
        sliceCbOffset = (u64)width * height+width*sliceRowsOrg*sliceNum/2;
    }
    else if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_H264)
    {
        total_mb = (width/16) * sliceRowsOrg/16*sliceNum;
        sliceLumOffset = total_mb/5*2048 + total_mb%5*400;
    }
    else if(inputMode == JPEGENC_YUV422_888)
    {
        sliceLumOffset = (u64)width*sliceRowsOrg*sliceNum;
        sliceCbOffset = (u64)width * height+(u64)width*sliceRowsOrg*sliceNum;
    }
    else if((inputMode == JPEGENC_YUV420_8BIT_TILE_8_8) || (inputMode == JPEGENC_YUV420_10BIT_TILE_8_8))
    {
        sliceLumOffset = (u64)lumaStrideSrc * (sliceRowsOrg/8)*sliceNum;
        sliceCbOffset = (u64)lumaStrideSrc * ((height+7)/8) + chrStrideSrc* (((sliceRowsOrg/2)+3)/4)*sliceNum;
    }
    else if(inputMode == JPEGENC_YUV420_FBC)
    {
        sliceLumOffset = (u64)lumaStrideSrc * (sliceRowsOrg/2)*sliceNum;
        sliceCbOffset = (u64)lumaStrideSrc * ((height+1)/2) + chrStrideSrc* (((sliceRowsOrg/2)+1)/2)*sliceNum;
    }

    if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_HEVC)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
            fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
            return -1;
        }
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);
        size = fread(image, 1, width*sliceRows, file);
        fseek(file, frameOffset + sliceCbOffset, SEEK_SET);
        size = fread(image+width*sliceRows, 1, width*sliceRows/2, file);

        goto end; //goto error;
    }
    else if(inputMode == JPEGENC_YUV420_8BIT_DAHUA_H264)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
            fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
            return -1;
        }
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);
        size = fread(image, 1, width*sliceRows*2*3/2, file);
        goto end;
    }
    else if(inputMode == JPEGENC_YUV420_8BIT_TILE_8_8 || inputMode == JPEGENC_YUV420_10BIT_TILE_8_8)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
            fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
            return -1;
        }

        //luma
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);
        for(i = 0; i < ((sliceRows+7)/8); i++)
            size = fread(image + i*luma_stride, 1, lumaStrideSrc, file);

        sliceLumSize = luma_stride * ((sliceRows+7)/8);

        //chroma
        fseek(file, frameOffset + sliceCbOffset, SEEK_SET);
        for(i = 0; i < (((sliceRows/2)+3)/4); i++)
            size = fread(image + sliceLumSize + i*chroma_stride, 1, chrStrideSrc, file);

        goto end;
    }
    else if(inputMode == JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4 || inputMode == JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4 ||
                    inputMode == JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
                fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
                return -1;
        }

        /* Luma */
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);
        for(i = 0; i < ((sliceRows+3)/4); i++)
            size = fread(image + i*luma_stride, 1, lumaStrideSrc, file);

        sliceLumSize = (u64)luma_stride * ((sliceRows+3)/4);

        /* Chroma */
        fseek(file, frameOffset + sliceCbOffset, SEEK_SET);
        for(i = 0; i < (((sliceRows/2) + 3)/4); i++)
            size = fread(image + sliceLumSize + i*chroma_stride, 1, chrStrideSrc, file);

        goto end;
    }
    else if(inputMode == JPEGENC_YVU420_PLANAR)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
            fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
            return -1;
        }
        //luma
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);

        i64 scan = luma_stride;

        for(i = 0; i < sliceRows; i++)
            size = fread(image+scan*i, 1, sliceLumWidth, file);

        //cr
        if (sliceCrSize)
        {
            fseek(file, frameOffset + sliceCbOffset, SEEK_SET);

            scan = chroma_stride;

            for(i = 0; i < sliceRows/2; i++)
                size = fread(image + sliceLumSize + sliceCrSize + scan*i, 1, sliceCrWidth, file);
        }

        //cb
        if (sliceCbSize)
        {
            fseek(file, frameOffset + sliceCrOffset, SEEK_SET);

            scan = chroma_stride;

            for(i = 0; i < sliceRows/2; i++)
                size = fread(image + sliceLumSize + scan*i, 1, sliceCbWidth, file);
        }
        goto end;
    }
    else if(inputMode == JPEGENC_YUV420_FBC)
    {
        file = fopen(name, "rb");
        if(file == NULL)
        {
            fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
            return -1;
        }

        //luma
        fseek(file, frameOffset + sliceLumOffset, SEEK_SET);
        for(i = 0; i < ((sliceRows+1)/2); i++)
            size = fread(image + i*luma_stride, 1, lumaStrideSrc, file);

        sliceLumSize = (u64)luma_stride * ((sliceRows+1)/2);

        /* Chroma */
        fseek(file, frameOffset + sliceCbOffset, SEEK_SET);
        for(i = 0; i < (((sliceRows/2) + 1)/2); i++)
            size = fread(image + sliceLumSize + i*chroma_stride, 1, chrStrideSrc, file);

        goto end;
    }

    /* Read input from file frame by frame */
#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("%s %d Reading frame %d slice %d (%d bytes) from %s... \n",
            __func__, __LINE__, frameNum, sliceNum,
            sliceLumWidth*sliceRows + sliceCbWidth*sliceRows/2 +
            sliceCrWidth*sliceRows/2, name);
    fflush(stdout);
#endif

    file = fopen(name, "rb");
    if(file == NULL)
    {
        fprintf(stderr, "\n %s %d Unable to open VOP file: %s\n", __func__, __LINE__, name);
        return -1;
    }

    //luma
    fseek(file, frameOffset + sliceLumOffset, SEEK_SET);

    i64 scan = luma_stride;

    for(i = 0; i < sliceRows; i++)
        size = fread(image+scan*i, 1, sliceLumWidth, file);

    //cb
    if (sliceCbSize)
    {
        fseek(file, frameOffset + sliceCbOffset, SEEK_SET);

        scan = chroma_stride;

        if (inputMode == JPEGENC_YUV422_888)
        {
            for(i = 0; i < sliceRows; i++)
                size = fread(image + sliceLumSize + scan*i, 1, sliceCbWidth, file);
        }
        else
        {
            for(i = 0; i < sliceRows/2; i++)
                size = fread(image + sliceLumSize + scan*i, 1, sliceCbWidth, file);
        }
    }

    //cr
    if (sliceCrSize)
    {
        fseek(file, frameOffset + sliceCrOffset, SEEK_SET);

        scan = chroma_stride;

        for(i = 0; i < sliceRows/2; i++)
            size = fread(image + sliceLumSize + sliceCbSize + scan*i, 1, sliceCrWidth, file);
    }


    error:
    /* Stop if last VOP of the file */
    if(feof(file)) {
        fprintf(stderr, "\nError! I can't read VOP no: %d ", frameNum);
        fprintf(stderr, "from file: %s\n", name);
        fclose(file);
        return -1;
    }
    end:

    #ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("%s OK\n", __func__);
    fflush(stdout);
    #endif

    fclose(file);

    return 0;
}
i32 JpegReadDEC400Data(JpegEncInst encoder, u8 *compDataBuf, u8 *compTblBuf, u32 inputFormat,u32 src_width,
                               u32 src_height,char *inputDataFile,FILE *dec400Table,i32 num, u64 dec400FrameTableSize, i32 dec400VersionId)
{
    u64 seek;
    u8 *lum;
    u8 *cb;
    u8 *cr;
    u64 lumaSize,chrSize;
    u64 src_img_size;
    u64 SrcLumaSize = 0,srcChrSize = 0,dec400LumaTblSize    = 0,dec400ChrTblSize = 0;
    FILE *dec400Data = NULL;
    dec400Data = fopen(inputDataFile, "rb");
    if(dec400Data == NULL)
    {
        return NOK;
    }
    JencGetLumaSize(encoder, &SrcLumaSize, &dec400LumaTblSize);
    JencGetChromaSize(encoder, &srcChrSize, &dec400ChrTblSize);
    lumaSize = dec400LumaTblSize;
    chrSize = dec400ChrTblSize;
    if(dec400VersionId == 1)
        src_img_size = dec400FrameTableSize;
    else
        src_img_size = lumaSize + chrSize;
    seek = ((u64)num) * ((u64)src_img_size);
    lum = compTblBuf;
    cb = lum + lumaSize;
    cr = cb + chrSize/2;
    switch(inputFormat)
    {
    case JPEGENC_YUV420_PLANAR:
    case JPEGENC_YUV420_I010:
        if (file_read(dec400Table, lum , seek, lumaSize))
        {
            fclose(dec400Data);
            return NOK;
        }
        seek += lumaSize;
        if (file_read(dec400Table, cb , seek, chrSize/2))
        {
            fclose(dec400Data);
            return NOK;
        }
        seek += chrSize/2;
        if (file_read(dec400Table, cr , seek, chrSize/2))
        {
            fclose(dec400Data);
            return NOK;
        }
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
    case JPEGENC_YUV420_MS_P010:
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        if (file_read(dec400Table, lum , seek, lumaSize))
        {
            fclose(dec400Data);
            return NOK;
        }
        seek += lumaSize;
        if (file_read(dec400Table, cb , seek, chrSize))
        {
            fclose(dec400Data);
            return NOK;
        }
        break;
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
        if (file_read(dec400Table, lum , seek, lumaSize))
        {
            fclose(dec400Data);
            return NOK;
        }
        break;
    case JPEGENC_YVU420_PLANAR:
        if (file_read(dec400Table, lum , seek, lumaSize))
        {
            fclose(dec400Data);
            return NOK;
        }
        seek += lumaSize;
        if (file_read(dec400Table, cr , seek, chrSize/2))
        {
            fclose(dec400Data);
            return NOK;
        }
        seek += chrSize/2;
        if (file_read(dec400Table, cb , seek, chrSize/2))
        {
            fclose(dec400Data);
            return NOK;
        }
        break;
    default:
        printf("DEC400 not support this format\n");
        fclose(dec400Data);
        return NOK;
    }
    lumaSize = SrcLumaSize;
    chrSize = srcChrSize;
    src_img_size = lumaSize + chrSize;
    seek         = ((u64)num) * ((u64)src_img_size);
    lum = compDataBuf;
    cb = lum + lumaSize;
    cr = cb + chrSize/2;
    switch(inputFormat)
    {
    case JPEGENC_YUV420_PLANAR:
    case JPEGENC_YUV420_I010:
        if (file_read(dec400Data, lum , seek, lumaSize))
            return NOK;
        seek += lumaSize;
        if (file_read(dec400Data, cb , seek, chrSize/2))
            return NOK;
        seek += chrSize/2;
        if (file_read(dec400Data, cr , seek, chrSize/2))
            return NOK;
        break;
    case JPEGENC_YUV420_SEMIPLANAR:
    case JPEGENC_YUV420_SEMIPLANAR_VU:
    case JPEGENC_YUV420_MS_P010:
    case JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4:
    case JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4:
    case JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4:
        if (file_read(dec400Data, lum , seek, lumaSize))
            return NOK;
        seek += lumaSize;
        if (file_read(dec400Data, cb , seek, chrSize))
            return NOK;
        break;
    case JPEGENC_RGB888:
    case JPEGENC_BGR888:
    case JPEGENC_RGB101010:
    case JPEGENC_BGR101010:
        if (file_read(dec400Data, lum , seek, lumaSize))
            return NOK;
        break;
    default:
        printf("DEC400 not support this format\n");
        return NOK;
    }
    return OK;
}

/*------------------------------------------------------------------------------

    Help

------------------------------------------------------------------------------*/
void Help(void)
{
    fprintf(stdout, "Usage:  %s [options] -i inputfile\n", "jpeg_testenc");
    fprintf(stdout,
            "  -H    --help              Display this help.\n\n"
           );

    fprintf(stdout,
            " Parameters affecting input frame and encoded frame resolutions and cropping:\n"
            "  -i[s] --input             Read input from file. [input.yuv]\n"
            "  -I[s] --inputThumb        Read thumbnail input from file. [thumbnail.jpg]\n"
            "  -o[s] --output            Write output to file. [stream.jpg]\n"
            "  -a[n] --firstPic          First picture of input file. [0]\n"
            "  -b[n] --lastPic           Last picture of input file. [0]\n"
            "  -w[n] --lumWidthSrc       Width of source image. [176]\n"
            "  -h[n] --lumHeightSrc      Height of source image. [144]\n"
            "  -x[n] --width             Width of output image. [--lumWidthSrc]\n"
            "  -y[n] --height            Height of output image. [--lumHeightSrc]\n"
            "  -X[n] --horOffsetSrc      Output image horizontal offset. [0]\n"
            "  -Y[n] --verOffsetSrc      Output image vertical offset. [0]\n"
            "  -W[n] --write             0=NO, 1=YES write output. [1]\n"
                );

    fprintf(stdout,
            "\n Parameters for pre-processing frames before encoding:\n"
            "  -g[n] --frameType         Input YUV format. [0]\n"
            "                               0 - YUV420 planar CbCr (IYUV/I420)\n"
            "                               1 - YUV420 semi-planar CbCr (NV12)\n"
            "                               2 - YUV420 semi-planar CrCb (NV21)\n"
            "                               3 - YUYV422 interleaved (YUYV/YUY2)\n"
            "                               4 - UYVY422 interleaved (UYVY/Y422)\n"
            "                               5 - RGB565 16bpp\n"
            "                               6 - BGR565 16bpp\n"
            "                               7 - RGB555 16bpp\n"
            "                               8 - BGR555 16bpp\n"
            "                               9 - RGB444 16bpp\n"
            "                               10 - BGR444 16bpp\n"
            "                               11 - RGB888 32bpp\n"
            "                               12 - BGR888 32bpp\n"
            "                               13 - RGB101010 32bpp\n"
            "                               15 - YUV420 10 bit planar CbCr (I010)\n"
            "                               16 - YUV420 10 bit planar CbCr (P010)\n"
            "                               19 - YUV420 customer private tile for HEVC\n"
            "                               20 - YUV420 customer private tile for H.264\n"
            "                               21 - YUV420 semiplanar CbCr customer private tile\n"
            "                               22 - YUV420 semiplanar CrCb customer private tile\n"
            "                               23 - YUV420 P010 customer private tile\n"
            "                               37 - YVU420 8 bit planar CrCb \n"
            "  -v[n] --colorConversion   RGB to YCbCr color conversion type. [0]\n"
            "                               0 - ITU-R BT.601, RGB limited [16...235] (BT601_l.mat)\n"
            "                               1 - ITU-R BT.709, RGB limited [16...235] (BT709_l.mat)\n"
            "                               2 - User defined, coefficients defined in test bench.\n"
            "                               3 - ITU-R BT.2020\n"
            "                               4 - ITU-R BT.601, RGB full [0...255] (BT601_f.mat)\n"
            "                               5 - ITU-R BT.601, RGB limited [0...219] (BT601_219.mat)\n"
            "                               6 - ITU-R BT.709, RGB full [0...255] (BT709_f.mat)\n"
            "  -G[n] --rotation          Rotate input image. [0]\n"
            "                               0 - disabled\n"
            "                               1 - 90 degrees right\n"
            "                               2 - 90 degrees left\n"
            "                               3 - 180 degrees\n"
            "  -M[n]  --mirror           Mirror input image. [0]\n"
            "                               0 - disabled horizontal mirror\n"
            "                               1 - enable horizontal mirror\n"
            "  -Q[n]  --inputAlignmentExp Alignment value of input frame buffer. [4]\n"
            "                               0 = Disable alignment \n"
            "                               4..12 = Base address of input frame buffer and each line are aligned to 2^inputAlignmentExp \n"
        );
    fprintf(stdout,
            "  -d[n] --enableConstChroma   0..1 Enable/Disable setting chroma to a constant pixel value. [0]\n"
            "                                 0 = Disable. \n"
            "                                 1 = Enable. \n"
            "  -e[n] --constCb             0..255. The constant pixel value for Cb. [128]\n"
            "  -f[n] --constCr             0..255. The constant pixel value for Cr. [128]\n"
        );

    fprintf(stdout,
            "\n Parameters affecting the output stream and encoding tools:\n"
            "  -R[n] --restartInterval   Restart interval in MCU rows. [0]\n"
            "  -q[n] --qLevel            0..10, quantization scale. [1]\n"
            "                            10 = use testbench defined qtable\n"
            "  -p[n] --codingType        0=whole frame, 1=partial frame encoding. [0]\n"
            "  -m[n] --codingMode        0=YUV420, 1=YUV422, 2=Monochrome [0]\n"
            "  -t[n] --markerType        Quantization/Huffman table markers. [0]\n"
            "                               0 = Single marker\n"
            "                               1 = Multiple markers\n"
            "  -u[n] --units             Units type of x- and y-density. [0]\n"
            "                               0 = pixel aspect ratio\n"
            "                               1 = dots/inch\n"
            "                               2 = dots/cm\n"
            "  -k[n] --xdensity          Xdensity to APP0 header. [1]\n"
            "  -l[n] --ydensity          Ydensity to APP0 header. [1]\n"
            "        --streamBufChain    Enable two output stream buffers. [0]\n"
            "                               0 - Single output stream buffer.\n"
            "                               1 - Two output stream buffers chained together.\n"
            "                            Note the minimum allowable size of the first stream buffer is 1k bytes + thumbnail data size if any.\n"

            );
    fprintf(stdout,
            "  -T[n] --thumbnail         0=NO, 1=JPEG, 2=RGB8, 3=RGB24 Thumbnail to stream. [0]\n"
            "  -K[n] --widthThumb        Width of thumbnail output image. [32]\n"
            "  -L[n] --heightThumb       Height of thumbnail output image. [32]\n"
            );

    fprintf(stdout,
            "        --hashtype          Hash type for frame data hash. [0]\n"
            "                                 0=disable, 1=CRC32, 2=checksum32. \n"
         );

    fprintf(stdout,
            "\n Parameters affecting stream multi-segment output:\n"
            "        --streamMultiSegmentMode 0..2 Stream multi-segment mode control. [0]\n"
            "                                 0 = Disable stream multi-segment.\n"
            "                                 1 = Enable. No SW handshaking. Loop-back enabled.\n"
            "                                 2 = Enable. SW handshaking. Loop-back enabled.\n"
            "        --streamMultiSegmentAmount 2..16. the total amount of segments to control loopback/sw-handshake/IRQ. [4]\n"
        );

    fprintf(stdout,
            "\n");
    fprintf(stdout,
            "\n Parameters affecting lossless encoding:\n"
            "        --lossless          0=lossy, 1~7 Enalbe lossless with prediction select mode n [0]\n"
            "        --ptrans            0..7 Point transform value for lossless encoding. [0]\n");
#ifdef TB_DEFINED_COMMENT
    fprintf(stdout,
            "\n   Using comment values defined in testbench!\n");
#else
    fprintf(stdout,
            "  -c[n] --comLength         Comment header data length. [0]\n"
            "  -C[s] --comFile           Comment header data file. [com.txt]\n");
#endif
    fprintf(stdout,
           "\n Parameters affecting the low latency mode:\n"
            "  -S[n] --inputLineBufferMode 0..4. Input buffer mode control (Line-Buffer Mode). [0]\n"
            "                                 0 = Disable input line buffer. \n"
            "                                 1 = Enable. SW handshaking. Loopback enabled.\n"
            "                                 2 = Enable. HW handshaking. Loopback enabled.\n"
            "                                 3 = Enable. SW handshaking. Loopback disabled.\n"
            "                                 4 = Enable. HW handshaking. Loopback disabled.\n"
            "  -N[n] --inputLineBufferDepth 0..511 The number of MCU rows to control loop-back/handshaking [1]\n"
            "                                 Control loop-back mode if it is enabled:\n"
            "                                   There are two continuous ping-pong input buffers; each contains inputLineBufferDepth MCU rows.\n"
            "                                 Control hardware handshaking if it is enabled:\n"
            "                                   Handshaking signal is processed per inputLineBufferDepth CTB/MB rows.\n"
            "                                 Control software handshaking if it is enabled:\n"
            "                                   IRQ is sent and Read Count Register is updated every time inputLineBufferDepth MCU rows have been read.\n"
            "                                 0 is only allowed with inputLineBufferMode = 3, IRQ won't be sent and Read Count Register won't be updated.\n"
            "  -s[n] --inputLineBufferAmountPerLoopback 0..1023. Handshake sync amount for every loopback [0]\n");

    fprintf(stdout,
    "\n Parameters affecting Motion JPEG, rate control, JPEG bitsPerPic:\n"
            "  -J[n] --mjpeg             Enable Motion JPEG[0]\n"
            "                               0 = Disable motion JPEG.\n"
            "                               1 = Enable motion JPEG.\n"
            "  -B[n] --bitPerSecond      Target bit per second. [0]\n"
            "                               0 - RC OFF\n"
            "                               none zero - RC ON\n"
            "  -n[n] --frameRateNum      1..1048575 Output picture rate numerator. [30]\n"
            "  -r[n] --frameRateDenom    1..1048575 Output picture rate denominator. [1]\n"
            "  -V[n] --rcMode            0..2, JPEG/MJPEG RC mode. [1]\n"
            "                               0 = single frame RC mode. \n"
            "                               1 = video RC with CBR. \n"
            "                               2 = video RC with VBR. \n"
            "  -U[n:m] --picQpDeltaRange Min:Max. Qp Delta range in picture-level rate control.\n"
            "                               Min: -10..-1 Minimum Qp_Delta in picture RC. [-2]\n"
            "                               Max:  1..10  Maximum Qp_Delta in picture RC. [3]\n"
            "                               This range only applies to two neighboring frames.\n"
            "  -E[n] --qpMin             0..51, Minimum frame qp. [0]\n"
            "  -F[n] --qpMax             0..51, Maxmum frame qp. [51]\n"
            "  -O[n] --fixedQP           -1..51, Fixed qp for every frame. [-1]\n"
            "                               -1 = disable fixed qp mode\n"
            "                               0-51 = value of fixed qp.\n"
           );

    fprintf(stdout,
            "\n Parameters for DEC400 compressed table(tile status):\n"
            "  --dec400TableInput            Read input DEC400 compressed table from file. [dec400CompTableinput.bin]\n"
            );

    fprintf(stdout,
            "\nTesting parameters that are not supported for end-user:\n"
            "  -P[n] --trigger           Logic Analyzer trigger at picture <n>. [-1]\n"
            "                            -1 = Disable the trigger.\n"
            "  -D[n] --XformCustomerPrivateFormat    -1..4 Convert YUV420 to customer private format. [-1]\n"
            "                               -1 - No conversion to customer private format\n"
            "                               0 - customer private tile format for HEVC\n"
            "                               1 - customer private tile format for H.264\n"
            "                               2 - customer private YUV422_888\n"
            "                               3 - common data 8-bit tile 4x4\n"
            "                               4 - common data 10-bit tile 4x4\n"
            "                               5 - customer private tile format for JPEG\n"
            "\n");

    fprintf(stdout,
            "\n Parameters for OSD overlay controls (i should be a number from 1 to 8):\n"
            "  --overlayEnables             8 bits indicate enable for 8 overlay region. [0]\n"
            "                                   1: region 1 enabled\n"
            "                                   2: region 2 enabled\n"
            "                                   3: region 1 and 2 enabled\n"
            "                                   and so on.\n"
            "  --olInputi                   input file for overlay region 1-8. [olInputi.yuv]\n"
            "                                   for example --olInput1\n"
            "  --olFormati                  0..1 Specify the overlay input format. [0]\n"
            "                                   0: ARGB8888\n"
            "                                   1: NV12\n"
            "  --olAlphai                   0..255 Specify a global alpha value for NV12 overlay format. [0]\n"
            "  --olWidthi                   Width of overlay region. Must be set if region enabled. [0]\n"
            "  --olHeighti                  Height of overlay region. Must be set if region enabled. [0]\n"
            "  --olXoffseti                 Horizontal offset of overlay region top left pixel. [0]\n"
            "                                   must be under 2 aligned condition. [0]\n"
            "  --olYoffseti                 Vertical offset of overlay region top left pixel. [0]\n"
            "                                   must be under 2 aligned condition. [0]\n"
            "  --olYStridei                 Luma stride in bytes. Default value is based on format.\n"
            "                                   [olWidthi * 4] if ARGB888.\n"
            "                                   [olWidthi] if NV12.\n"
            "  --olUVStridei                Chroma stride in bytes. Default value is based on luma stride.\n"
            "  --olCropXoffseti             OSD cropping top left horizontal offset. [0]\n"
            "                                   must be under 2 aligned condition. [0]\n"
            "  --olCropYoffseti             OSD cropping top left vertical offset. [0]\n"
            "                                   must be under 2 aligned condition. [0]\n"
            "  --olCropWidthi               OSD cropping width. [olWidthi]\n"
            "  --olCropHeighti              OSD cropping height. [olHeighti]\n"
            "\n");

    fprintf(stdout,
            "\n Parameters for AXI alignment:\n"
            "  --AXIAlignment               AXI alignment setting (in hexadecimal format). [0]\n"
            "                                   bit[31:28] AXI_burst_align_wr_common\n"
            "                                   bit[27:24] AXI_burst_align_wr_stream\n"
            "                                   bit[23:20] AXI_burst_align_wr_chroma_ref\n"
            "                                   bit[19:16] AXI_burst_align_wr_luma_ref\n"
            "                                   bit[15:12] AXI_burst_align_rd_common\n"
            "                                   bit[11: 8] AXI_burst_align_rd_prp\n"
            "                                   bit[ 7: 4] AXI_burst_align_rd_ch_ref_prefetch\n"
            "                                   bit[ 3: 0] AXI_burst_align_rd_lu_ref_prefetch\n"
            "\n");
        fprintf(stdout,
            "\n Parameters for AXI alignment:\n"
            "  --mmuEnable                  0=disable MMU if MMU exists, 1=enable MMU if MMU exists. [0]\n");

    fprintf(stdout,
            "\n Parameters for RoiMap:\n"
            "  --roimapfile                 Input file for roimap region. [jpeg_roimap.roi]\n"
            "  --nonRoiFilter               Input file for nonroimap region filter. [filter.txt]\n"
            "  --nonRoiLevel                0...9 nonRoiFliter Level\n"
            );
}

/*------------------------------------------------------------------------------

    Write encoded stream to file

------------------------------------------------------------------------------*/
void JencWriteStrm(FILE * fout, u32 * strmbuf, u32 size, u32 endian)
{

    /* Swap the stream endianess before writing to file if needed */
    if(endian == 1)
    {
        u32 i = 0, words = (size + 3) / 4;

        while(words)
        {
            u32 val = strmbuf[i];
            u32 tmp = 0;

            tmp |= (val & 0xFF) << 24;
            tmp |= (val & 0xFF00) << 8;
            tmp |= (val & 0xFF0000) >> 8;
            tmp |= (val & 0xFF000000) >> 24;
            strmbuf[i] = tmp;
            words--;
            i++;
        }

    }

    /* Write the stream to file */

#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("Writing stream (%i bytes)... ", size);
    fflush(stdout);
#endif

    fwrite(strmbuf, 1, size, fout);

#ifndef ASIC_WAVE_TRACE_TRIGGER
    printf("OK\n");
    fflush(stdout);
#endif
}

/*------------------------------------------------------------------------------

    JencWriteStrmBufs
        Write encoded stream to file

    Params:
        fout - file to write
        bufs - stream buffers
        offset - stream buffer offset
        size - amount of data to write
        endian - data endianess, big or little

------------------------------------------------------------------------------*/
void JencWriteStrmBufs (FILE *fout, JENC_EWLLinearMem_t *bufs, u32 offset, u32 size, u32 invalid_size, u32 endian)
{
    u8 *buf0 = (u8 *)bufs[0].virtualAddress;
    u8 *buf1 = (u8 *)bufs[1].virtualAddress;
    u32 buf0Len = bufs[0].size;

    if (!buf0) return;

    if (offset < buf0Len)
    {
        u32 size0 = MIN(size, buf0Len-offset-invalid_size);
        JencWriteStrm(fout, (u32 *)(buf0 + offset), size0, endian);
        if ((size0 < size) && buf1)
            JencWriteStrm(fout, (u32 *)buf1, size-size0, endian);
    }
    else if (buf1)
    {
        JencWriteStrm(fout, (u32 *)(buf1 + offset - buf0Len), size, endian);
    }
}

#ifdef SEPARATE_FRAME_OUTPUT
/*------------------------------------------------------------------------------

    Write encoded frame to file

------------------------------------------------------------------------------*/
void WriteFrame(char *filename, u32 * strmbuf, u32 size)
{
    FILE *fp;

    fp = fopen(filename, "ab");

    if(fp)
    {
        fwrite(strmbuf, 1, size, fp);
        fclose(fp);
    }
}

/*------------------------------------------------------------------------------

    WriteFrameBufs
        Write encoded stream to file

    Params:
        bufs - stream buffers
        offset - stream buffer offset
        size - amount of data to write

------------------------------------------------------------------------------*/
void writeFrameBufs (char *filename, JENC_EWLLinearMem_t *bufs, u32 offset, u32 size)
{
    u8 *buf0 = (u8 *)bufs[0].virtualAddress;
    u8 *buf1 = (u8 *)bufs[1].virtualAddress;
    u32 buf0Len = bufs[0].size;

    if (!buf0) return;

    if (offset < buf0Len)
    {
        u32 size0 = MIN(size, buf0Len-offset);
        WriteFrame(filename, (u32 *)(buf0 + offset), size0);
        if ((size0 < size) && buf1)
            WriteFrame(filename, (u32 *)buf1, size-size0);
    }
    else if (buf1)
    {
        WriteFrame(filename, (u32 *)(buf1 + offset - buf0Len), size);
    }
}

#endif

/*------------------------------------------------------------------------------
    GetResolution
        Parse image resolution from file name
------------------------------------------------------------------------------*/
u32 GetResolution(char *filename, i32 *pWidth, i32 *pHeight)
{
    i32 i;
    u32 w, h;
    i32 len = strlen(filename);
    i32 filenameBegin = 0;

    /* Find last '/' in the file name, it marks the beginning of file name */
    for (i = len-1; i; --i)
        if (filename[i] == '/') {
            filenameBegin = i+1;
            break;
        }

    /* If '/' found, it separates trailing path from file name */
    for (i = filenameBegin; i <= len-3; ++i)
    {
        if ((strncmp(filename+i, "subqcif", 7) == 0) ||
            (strncmp(filename+i, "sqcif", 5) == 0))
        {
            *pWidth = 128;
            *pHeight = 96;
            printf("Detected resolution SubQCIF (128x96) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "qcif", 4) == 0)
        {
            *pWidth = 176;
            *pHeight = 144;
            printf("Detected resolution QCIF (176x144) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "4cif", 4) == 0)
        {
            *pWidth = 704;
            *pHeight = 576;
            printf("Detected resolution 4CIF (704x576) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "cif", 3) == 0)
        {
            *pWidth = 352;
            *pHeight = 288;
            printf("Detected resolution CIF (352x288) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "qqvga", 5) == 0)
        {
            *pWidth = 160;
            *pHeight = 120;
            printf("Detected resolution QQVGA (160x120) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "qvga", 4) == 0)
        {
            *pWidth = 320;
            *pHeight = 240;
            printf("Detected resolution QVGA (320x240) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "vga", 3) == 0)
        {
            *pWidth = 640;
            *pHeight = 480;
            printf("Detected resolution VGA (640x480) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "720p", 4) == 0)
        {
            *pWidth = 1280;
            *pHeight = 720;
            printf("Detected resolution 720p (1280x720) from file name.\n");
            return 0;
        }
        if (strncmp(filename+i, "1080p", 5) == 0)
        {
            *pWidth = 1920;
            *pHeight = 1080;
            printf("Detected resolution 1080p (1920x1080) from file name.\n");
            return 0;
        }
        if (filename[i] == 'x')
        {
            if (sscanf(filename+i-4, "%ux%u", &w, &h) == 2)
            {
                *pWidth = w;
                *pHeight = h;
                printf("Detected resolution %dx%d from file name.\n", w, h);
                return 0;
            }
            else if (sscanf(filename+i-3, "%ux%u", &w, &h) == 2)
            {
                *pWidth = w;
                *pHeight = h;
                printf("Detected resolution %dx%d from file name.\n", w, h);
                return 0;
            }
            else if (sscanf(filename+i-2, "%ux%u", &w, &h) == 2)
            {
                *pWidth = w;
                *pHeight = h;
                printf("Detected resolution %dx%d from file name.\n", w, h);
                return 0;
            }
        }
        if (filename[i] == 'w')
        {
            if (sscanf(filename+i, "w%uh%u", &w, &h) == 2)
            {
                *pWidth = w;
                *pHeight = h;
                printf("Detected resolution %dx%d from file name.\n", w, h);
                return 0;
            }
        }
    }

    return 1;   /* Jenc_Error - no resolution found */
}

/*------------------------------------------------------------------------------

    API tracing

------------------------------------------------------------------------------*/
void JpegEnc_Trace(const char *msg)
{
    static FILE *fp = NULL;

    if(fp == NULL)
        fp = fopen("api.trc", "wt");

    if(fp)
        fprintf(fp, "%s\n", msg);
}

/*------------------------------------------------------------------------------

    InitInputLineBuffer
    -get address of input line buffer

------------------------------------------------------------------------------*/
i32 InitInputLineBuffer(inputLineBufferCfg * lineBufCfg, JpegEncCfg * encCfg, JpegEncIn * encIn, JpegEncInst inst)
{
    u32 luma_stride, chroma_stride;
    JencGetAlignedStride(encCfg->inputWidth,encCfg->frameType,&luma_stride,&chroma_stride,1<< encCfg->exp_of_input_alignment);
    memset(lineBufCfg, 0, sizeof(inputLineBufferCfg));
    lineBufCfg->inst   = (void *)inst;
    //lineBufCfg->asic   = &(((jpegInstance_s *)inst)->asic);
    lineBufCfg->wrCnt  = 0;
    lineBufCfg->depth  = encCfg->inputLineBufDepth;
    lineBufCfg->inputFormat = encCfg->frameType;
    lineBufCfg->lumaStride = luma_stride;
    lineBufCfg->chromaStride = chroma_stride;
    lineBufCfg->encWidth  = encCfg->codingWidth;
    lineBufCfg->encHeight = encCfg->codingHeight;
    lineBufCfg->hwHandShake = encCfg->inputLineBufHwModeEn;
    lineBufCfg->loopBackEn = encCfg->inputLineBufLoopBackEn;
    lineBufCfg->amountPerLoopBack = encCfg->amountPerLoopBack;
    lineBufCfg->srcHeight = encCfg->codingType ? encCfg->restartInterval*16 : encCfg->inputHeight;
    lineBufCfg->srcVerOffset = encCfg->codingType ? 0 : encCfg->yOffset;
    lineBufCfg->getMbLines = &JencGetEncodedMbLines;
    lineBufCfg->setMbLines = &JencSetInputMBLines;
    lineBufCfg->ctbSize = 16;
    lineBufCfg->lumSrc = (u8 *)encIn->pLum;
    lineBufCfg->cbSrc  = (u8 *)encIn->pCb;
    lineBufCfg->crSrc  = (u8 *)encIn->pCr;
    lineBufCfg->initSegNum = 0;

    if (Jenc_VCEncInitInputLineBuffer(lineBufCfg))
      return -1;

    /* loopback mode */
    if (lineBufCfg->loopBackEn && lineBufCfg->lumBuf.buf)
    {
        encIn->busLum = lineBufCfg->lumBuf.busAddress;
        encIn->busCb = lineBufCfg->cbBuf.busAddress;
        encIn->busCr = lineBufCfg->crBuf.busAddress;

        /* data in SRAM start from the line to be encoded*/
        if(encCfg->codingType == JPEGENC_WHOLE_FRAME)
            encCfg->yOffset = 0;
    }

    return 0;
}

/*------------------------------------------------------------------------------

    SetInputLineBuffer
    -setup inputLineBufferCfg
    -initialize line buffer

------------------------------------------------------------------------------*/
void SetInputLineBuffer(inputLineBufferCfg * lineBufCfg, JpegEncCfg * encCfg, JpegEncIn * encIn, JpegEncInst inst, i32 sliceIdx)
{
    if (encCfg->codingType == JPEGENC_SLICED_FRAME)
    {
        i32 h = encCfg->codingHeight + encCfg->yOffset;
        i32 sliceRows = encCfg->restartInterval * 16;
        i32 rows = sliceIdx * sliceRows;
        if((rows + sliceRows) <= h)
            lineBufCfg->encHeight = sliceRows;
        else
            lineBufCfg->encHeight = h % sliceRows;
    }
    lineBufCfg->wrCnt = 0;
    encIn->lineBufWrCnt = Jenc_VCEncStartInputLineBuffer(lineBufCfg, HANTRO_FALSE);
    encIn->initSegNum = lineBufCfg->initSegNum;
    return;
}

void InitStreamSegmentCrl(JencSegmentCtl_s *ctl, commandLine_s *cml, FILE *out, JpegEncIn * encIn)
{
    ctl->streamRDCounter = 0;
    ctl->streamMultiSegEn = cml->streamMultiSegmentMode != 0;
    ctl->streamBase = (u8 *)encIn->pOutBuf[0];
    ctl->segmentSize = encIn->outBufSize[0]/ cml->streamMultiSegmentAmount;
    ctl->segmentSize = ((ctl->segmentSize + 16 - 1) & (~(16 - 1)));//segment size must be aligned to 16byte
    ctl->segmentAmount = cml->streamMultiSegmentAmount;
    ctl->outStreamFile = out;
}

/* Callback function called by the encoder SW after "segment ready"
    interrupt from HW. Note that this function is called after every segment is ready.
------------------------------------------------------------------------------*/
void EncStreamSegmentReady(void *cb_data)
{
    u8 *streamBase;
    JencSegmentCtl_s *ctl = (JencSegmentCtl_s*)cb_data;

    if(ctl->streamMultiSegEn)
    {
        streamBase = ctl->streamBase + (ctl->streamRDCounter % ctl->segmentAmount) * ctl->segmentSize;

        printf("receive segment irq %d,length=%d\n",ctl->streamRDCounter,ctl->segmentSize);
        if(writeOutput)
            JencWriteStrm(ctl->outStreamFile, (u32 *)streamBase, ctl->segmentSize, 0);

        ctl->streamRDCounter++;
    }
}
