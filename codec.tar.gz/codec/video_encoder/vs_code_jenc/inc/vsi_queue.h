/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#ifndef QUEUE_H_
#define QUEUE_H_

#ifdef __cplusplus
extern "C" {
#endif

struct node
{
  struct node *next;
};

struct queue
{
  struct node *head;
  struct node *tail;
};

void Jenc_queue_init(struct queue *);
void Jenc_queue_put(struct queue *, struct node *);
void Jenc_queue_put_tail(struct queue *, struct node *);
void Jenc_queue_remove(struct queue *, struct node *);
void Jenc_free_nodes(struct node *tail);
struct node *Jenc_queue_get(struct queue *);
struct node *Jenc_queue_tail(struct queue *queue);

#ifdef __cplusplus
}
#endif

#endif
