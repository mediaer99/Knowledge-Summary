/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Hantro Products Oy.                             --
--                                                                            --
--                   (C) COPYRIGHT 2006 HANTRO PRODUCTS OY                    --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : Hantro H1 JPEG Encoder API
--
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------

    Table of contents

    1. Include headers
    2. Module defines
    3. Data types
    4. Function prototypes

------------------------------------------------------------------------------*/

#ifndef __JENC_API_H__
#define __JENC_API_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 \mainpage Overview

This document describes the Application Programming Interface (API) of the Hantro VC8000E jpeg encoder hardware.

Details of the Hantro VC Encoder API are described in this document.
- First, components such as data types, return codes, enumerations and relevant structures are described
- Then, function syntax and description is presented.
- Finally, a programming overview and examples are presented.

The code is written in C and parameter types follow standard C conventions. This document assumes that the reader
understands the fundamentals of C-language and the JPEG standard.

Currently, there are no deprecated functions in this API.

\section intro_s1 Supported Standards
The API discussed in this version of the document is compatible with the following jpeg encoder standards and
profiles. Additional levels may be supported via software.

- JPEG ITU-T Rec. T.81 (09/92), Baseline interleaved/JFIF

\section intro_s2 Compatible Hardware

- Hantro VC8000E Video Encoder v6.0.x, v6.1.x or v6.2.x or later

\section intro_s3 Standard References
- ISO/IEC International Standard 10918-1:1999. Information technology ¨C Digital compression and coding of continuous-tone still images.

 *
 * \section intro_s2 Compatible Hardware
 * Hantro VC8000E Video Encoder IP v6.2.xx or earlier.
 *
 * \section intro_s3 Deprecated Functions
 * This API includes some deprecated functions which may have been supported for earlier
 * Hantro encoders but which are no longer supported for use with VCCORE hardware. These
 * are listed in a separate section near the end of the document.
 */

/**
 * \page ch2 Feature Descriptions
 *
 * This chapter will describe the features of the encoder and related data structure to
 * enable the features. Following is a list of the features in this chapter.
 *
 * \subpage osd
 *
 * \subpage jpgroi
 */

/**
 * \defgroup jpegenc_api JPEG Encoder API
 *
 * @{
 */

#include "base_type.h"
#include "enccommon.h"

/*------------------------------------------------------------------------------
    2. Module defines
------------------------------------------------------------------------------*/

    #define JPEGENC_STREAM_MIN_BUF0_SIZE 1024

    typedef const void *JpegEncInst;

/** Function return values */
    typedef enum
    {
        JPEGENC_FRAME_READY = 1,
        JPEGENC_RESTART_INTERVAL = 2,
        JPEGENC_OK = 0,
        JPEGENC_ERROR = -1,
        JPEGENC_NULL_ARGUMENT = -2,
        JPEGENC_INVALID_ARGUMENT = -3,
        JPEGENC_MEMORY_ERROR = -4,
        JPEGENC_INVALID_STATUS = -5,
        JPEGENC_OUTPUT_BUFFER_OVERFLOW = -6,
        JPEGENC_EWL_ERROR = -7,
        JPEGENC_EWL_MEMORY_ERROR = -8,
        JPEGENC_HW_BUS_ERROR = -9,
        JPEGENC_HW_DATA_ERROR = -10,
        JPEGENC_HW_TIMEOUT = -11,
        JPEGENC_HW_RESERVED = -12,
        JPEGENC_SYSTEM_ERROR = -13,
        JPEGENC_INSTANCE_ERROR = -14,
        JPEGENC_HW_RESET = -15
    } JpegEncRet;

/** Picture YUV type for initialization */
    typedef enum
    {
        JPEGENC_YUV420_PLANAR = 0,                           /* YYYY... UUUU... VVVV...  */
        JPEGENC_YUV420_SEMIPLANAR,                           /* YYYY... UVUVUV...        */
        JPEGENC_YUV420_SEMIPLANAR_VU,                        /* YYYY... VUVUVU...        */
        JPEGENC_YUV422_INTERLEAVED_YUYV,                     /* YUYVYUYV...              */
        JPEGENC_YUV422_INTERLEAVED_UYVY,                     /* UYVYUYVY...              */
        JPEGENC_RGB565,                                      /* 16-bit RGB 16bpp         */
        JPEGENC_BGR565,                                      /* 16-bit RGB 16bpp         */
        JPEGENC_RGB555,                                      /* 15-bit RGB 16bpp         */
        JPEGENC_BGR555,                                      /* 15-bit RGB 16bpp         */
        JPEGENC_RGB444,                                      /* 12-bit RGB 16bpp         */
        JPEGENC_BGR444,                                      /* 12-bit RGB 16bpp         */
        JPEGENC_RGB888,                                      /* 24-bit RGB 32bpp         */
        JPEGENC_BGR888,                                      /* 24-bit RGB 32bpp         */
        JPEGENC_RGB101010,                                   /* 30-bit RGB 32bpp         */
        JPEGENC_BGR101010,                                   /* 30-bit RGB 32bpp         */
        JPEGENC_YUV420_I010 = 15,                            /* 10-bit YUV 24bpp         */
        JPEGENC_YUV420_MS_P010 = 16,                         /* 10-bit YUVSP 24bpp       */
        JPEGENC_YUV420_8BIT_DAHUA_HEVC = 19,                 /* 8-bit DAHUA_HEVC         */
        JPEGENC_YUV420_8BIT_DAHUA_H264 = 20,                 /* 8-bit DAHUA_H264         */
        JPEGENC_YUV420_SEMIPLANAR_8BIT_TILE_4_4 = 21,        /* YYYY... UVUVUV...        */
        JPEGENC_YUV420_SEMIPLANAR_VU_8BIT_TILE_4_4 = 22,     /* YYYY... VUVUVU...        */
        JPEGENC_YUV420_PLANAR_10BIT_P010_TILE_4_4 = 23,      /* YYYY... UVUV... */
        JPEGENC_YUV422_888 = 25,                             /* YYYY... UVUVUV...        */
        JPEGENC_YUV420_8BIT_TILE_8_8 = 35,                   /* 8-bit 8x8 tile              */
        JPEGENC_YUV420_10BIT_TILE_8_8 = 36,                  /* 10-bit 8x8 tile              */
        JPEGENC_YVU420_PLANAR = 37,                          /* 10-bit 8x8 tile              */
        JPEGENC_YUV420_FBC = 38                              /* 8-bit 64x2 tile          */
    } JpegEncFrameType;

/** Picture rotation for initialization */
    typedef enum
    {
        JPEGENC_ROTATE_0 = 0,
        JPEGENC_ROTATE_90R = 1, /**< Rotate 90 degrees clockwise */
        JPEGENC_ROTATE_90L = 2, /**< Rotate 90 degrees counter-clockwise */
        JPEGENC_ROTATE_180 = 3  /**< Rotate 180 degrees */
    } JpegEncPictureRotation;

/** Picture color space conversion for RGB input */
    typedef enum
    {
        JPEGENC_RGBTOYUV_BT601 = 0, /**< Color conversion of limited range[16,235] according to BT.601 */
        JPEGENC_RGBTOYUV_BT709 = 1, /**< Color conversion of limited range[16,235] according to BT.709 */
        JPEGENC_RGBTOYUV_USER_DEFINED = 2,   /**< User defined color conversion */
        JPEGENC_RGBTOYUV_BT2020 = 3, /**< Color conversion according to BT.2020 */
        JPEGENC_RGBTOYUV_BT601_FULL_RANGE = 4, /**< Color conversion of full range[0,255] according to BT.601*/
        JPEGENC_RGBTOYUV_BT601_LIMITED_RANGE = 5, /**< Color conversion of limited range[0,219] according to BT.601*/
        JPEGENC_RGBTOYUV_BT709_FULL_RANGE = 6 /**< Color conversion of full range[0,255] according to BT.709*/
    } JpegEncColorConversionType;

/** The encoding type */
    typedef enum
    {
        JPEGENC_WHOLE_FRAME = 0,    /**< The whole frame is stored in linear memory */
        JPEGENC_SLICED_FRAME        /**< The frame is sliced into restart intervals;
                                      * Input address is given for each slice */
    } JpegEncCodingType;

/** The encoding mode */
    typedef enum
    {
        JPEGENC_420_MODE = 0,    /**< Encoding in YUV 4:2:0 mode */
        JPEGENC_422_MODE = 1,    /**< Encoding in YUV 4:2:2 mode(prp only supports one special 422 format)*/
        JPEGENC_MONO_MODE = 2,   /**< Encoding in monochrome mode */
        JPEGENC_CNT_MODE
    } JpegEncCodingMode;

    typedef enum
    {
        JPEGENC_NO_UNITS = 0,   /* No units,
                                 * X and Y specify the pixel aspect ratio */
        JPEGENC_DOTS_PER_INCH = 1,  /* X and Y are dots per inch */
        JPEGENC_DOTS_PER_CM = 2 /* X and Y are dots per cm   */
    } JpegEncAppUnitsType;

    typedef enum
    {
        JPEGENC_SINGLE_MARKER = 0,  /* Luma/Chroma tables are written behind
                                     * one marker */
        JPEGENC_MULTI_MARKER    /* Luma/Chroma tables are written behind
                                 * one marker/component */
    } JpegEncTableMarkerType;

    typedef enum
    {
        JPEGENC_THUMB_JPEG = 0x10,  /* Thumbnail coded using JPEG  */
        JPEGENC_THUMB_PALETTE_RGB8 = 0x11,  /* Thumbnail stored using 1 byte/pixel */
        JPEGENC_THUMB_RGB24 = 0x13  /* Thumbnail stored using 3 bytes/pixel */
    } JpegEncThumbFormat;

    typedef enum
    {
        JPEGENC_SINGLEFRAME = 0,  /* single RC mode */
        JPEGENC_CBR         = 1,  /* CBR RC mode */
        JPEGENC_VBR         = 2,  /* VBR RC mode */
        JPEGENC_FIXQP
    } JpegEncRcMode;

/*------------------------------------------------------------------------------
    3. Data types
------------------------------------------------------------------------------*/
/** Version information */
    typedef struct
    {
        u32 major;           /**< Encoder API major version                    */
        u32 minor;           /**< Encoder API minor version                    */
        u32 clnum;           /**< CL# */
    } JpegEncApiVersion;

/** Build information*/
    typedef struct
    {
        u32 swBuild;         /**< Software build ID */
        u32 hwBuild;         /**< Hardware build ID */
    } JpegEncBuild;

/** thumbnail info */
    typedef struct
    {
        JpegEncThumbFormat format;  /* Format of the thumbnail */
        u8 width;            /* Width in pixels of thumbnail */
        u8 height;           /* Height in pixels of thumbnail */
        const void *data;    /* Thumbnail data */
        u16 dataLength;      /* Data amount in bytes */
    } JpegEncThumb;

/** RGB input to YUV color conversion */
    typedef struct
    {
        JpegEncColorConversionType type;
        u16 coeffA;          /**< User defined color conversion coefficient  */
        u16 coeffB;          /**< User defined color conversion coefficient  */
        u16 coeffC;          /**< User defined color conversion coefficient  */
        u16 coeffE;          /**< User defined color conversion coefficient  */
        u16 coeffF;          /**< User defined color conversion coefficient  */
        u16 coeffG;          /**< User defined color conversion coefficient  */
        u16 coeffH;          /**< User defined color conversion coefficient  */
        u16 LumaOffset;      /**< User defined color conversion coefficient  */
    } JpegEncColorConversion;

/** Encoder configuration */
    typedef struct
    {
        u32 inputWidth;      /**< Number of pixels/line in input image       */
        u32 inputHeight;     /**< Number of lines in input image               */
        u32 xOffset;         /**< Pixels from top-left corner of input image   */
        u32 yOffset;         /**< to top-left corner of encoded image        */
        u32 codingWidth;     /**< Width of encoded image                       */
        u32 codingHeight;    /**< Height of encoded image                      */
        u32 picStride[3];    /* < Picture stride */
        u32 restartInterval; /**< Restart interval (MCU lines)                 */
        u32 qLevel;          /**< Quantization level (0 - 9)                   */
        u32 qFactor;         /**< Quantization factor (1 - 99)                 */
        const u8 *qTableLuma;   /**< Quantization table for luminance [64],
                                 * overrides quantization level, zigzag order   */
        const u8 *qTableChroma; /**< Quantization table for chrominance [64],
                                 * overrides quantization level, zigzag order   */
        /** \page jpgroi ROI Map with Different Quality
         *
         * JPEG Encoder can define some region with ROI map where the quality not in ROI map
         * will degrade.
         * Roi region position is relative to effective encoding area
         */
        u8 filter[128];       /**< two 8x8 filter defined for luma and chroma non-roi region*/
        u32 enableRoimap;     /**< Enable roimap*/
        u32 nonRoiLevel;      /**< non_roi filter level (0 - 9)*/

        JpegEncFrameType frameType; /**< Input frame YUV / RGB format     */
        JpegEncColorConversion colorConversion; /**< RGB to YUV conversion    */
        JpegEncPictureRotation rotation;    /**< rotation off/-90/+90             */
        u32 mirror;   /**< 0:disable mirror 1:enable mirror*/
        JpegEncCodingType codingType;   /**< Whole frame / restart interval   */
        JpegEncCodingMode codingMode;   /**< 4:2:0 / monochrome / 4:2:2 coding(prp only supports one special 422 format)             */
        JpegEncAppUnitsType unitsType;  /**< Units for X & Y density in APP0  */
        JpegEncTableMarkerType markerType;  /**< Table marker type            */
        u32 xDensity;        /**< Horizontal pixel density                     */
        u32 yDensity;        /**< Vertical pixel density                       */
        u32 comLength;       /**< Length of COM header                         */
        const u8 *pCom;      /**< Comment header pointer                       */

        /* low latency */
        u32 inputLineBufEn;            /**< enable input image control signals */
        u32 inputLineBufLoopBackEn;    /**< input buffer loopback mode enable */
        u32 inputLineBufDepth;         /**< input buffer depth in mb lines */
        u32 inputLineBufHwModeEn;      /**< hw handshake*/
        u32 amountPerLoopBack;         /**< Handshake sync amount for every loopback */
        EncInputLineBufCallBackFunc inputLineBufCbFunc;  /**< callback function */
        void *inputLineBufCbData;     /**< callback function data */
        u32 hashType; /**< hash type, 0=disable, 1=CRC32, 2=Jenc_checksum */

        /* constant chroma control */
        i32 constChromaEn;
        u32 constCb;
        u32 constCr;
        /* lossless mode */
        u32 losslessEn;
        u32 predictMode;
        u32 ptransValue;

        /*Rate control*/
        u32 targetBitPerSecond;  /**< targetBitPerSecond*/

        /*Rate control for MJPEG purpose*/
        u32 frameRateNum;    /**< The stream time scale, [1..1048575] */
        u32 frameRateDenom;  /**< Maximum frame rate is frameRateNum/frameRateDenom
                                        * in frames/second. The actual frame rate will be
                                        * defined by timeIncrement of encoded pictures,
                                        * [1..frameRateNum] */
        u32 qpmin;
        u32 qpmax;
        i32 fixedQP; /**< fix qp no RC*/
        JpegEncRcMode rcMode;
        i32 picQpDeltaMin;
        i32 picQpDeltaMax;
        /*Stride*/
        u32 exp_of_input_alignment;

        /* slice node index */
        u32 slice_idx;

        /*stream multi-segment*/
        u32 streamMultiSegmentMode; /**< 0:single segment 1:multi-segment with no sync 2:multi-segment with sw handshake mode*/
        u32 streamMultiSegmentAmount; /**< must be more than 1*/
        EncStreamMultiSegCallBackFunc streamMultiSegCbFunc; /**< callback function*/
        void *streamMultiSegCbData; /**< callback data*/

        u32 burstMaxLength; /**< AXI max burst length */
        /* AXI alignment */
        u32 AXIAlignment; // bit[31:28] AXI_burst_align_wr_common
                          // bit[27:24] AXI_burst_align_wr_stream
                          // bit[23:20] AXI_burst_align_wr_chroma_ref
                          // bit[19:16] AXI_burst_align_wr_luma_ref
                          // bit[15:12] AXI_burst_align_rd_common
                          // bit[11: 8] AXI_burst_align_rd_prp
                          // bit[ 7: 4] AXI_burst_align_rd_ch_ref_prefetch
                          // bit[ 3: 0] AXI_burst_align_rd_lu_ref_prefetch
        u32 mmuEnable;
        /* overlay controls */
        FILE *olFile[MAX_OVERLAY_NUM];
        u32 olFrameNum[MAX_OVERLAY_NUM]; /**< Record number of osd input frames to support roll back feature */
        u32 olEnable[MAX_OVERLAY_NUM];
        u32 olFormat[MAX_OVERLAY_NUM];
        u32 olAlpha[MAX_OVERLAY_NUM];
        u32 olWidth[MAX_OVERLAY_NUM];
        u32 olCropWidth[MAX_OVERLAY_NUM];
        u32 olHeight[MAX_OVERLAY_NUM];
        u32 olCropHeight[MAX_OVERLAY_NUM];
        u32 olXoffset[MAX_OVERLAY_NUM];
        u32 olCropXoffset[MAX_OVERLAY_NUM];
        u32 olYoffset[MAX_OVERLAY_NUM];
        u32 olCropYoffset[MAX_OVERLAY_NUM];
        u32 olYStride[MAX_OVERLAY_NUM];
        u32 olUVStride[MAX_OVERLAY_NUM];
        u32 olSuperTile[MAX_OVERLAY_NUM];
        u32 olScaleWidth[MAX_OVERLAY_NUM];
        u32 olScaleHeight[MAX_OVERLAY_NUM];
        FILE *osdDec400TableFile;
        u32 osdDec400TableSize;

        u32 sramPowerdownDisable;
        i32 ChnId;
    } JpegEncCfg;

/** Input info */
    typedef struct
    {
        bool enableFBDC;
        i32 width;
        i32 cropX;
        i32 cropY;
    } VCEncFbdcInfo;

/** Input info */
    typedef struct
    {
        u32 frameHeader;       /**< Enable/disable creation of frame headers     */
        ptr_t busLum;          /**< Bus address of luminance input   (Y)         */
        ptr_t busCb;           /**< Bus address of chrominance input (Cb)        */
        ptr_t busCr;           /**< Bus address of chrominance input (Cr)        */
        ptr_t busRoiMap;       /**< bitmap for ROI defines */
        u8 *filter;
        const u8 *pLum;      /**< Pointer to luminance input   (Y)             */
        const u8 *pCb;       /**< Pointer to chrominance input (Cb)            */
        const u8 *pCr;       /**< Pointer to chrominance input (Cr)            */
        // FBDC_ENABLE
        //i32 CropX;
        //i32 CropY;
        ptr_t dec400TableBusLum;          /**< Bus address of dec400 compress table luminance input   (Y)         */
        ptr_t dec400TableBusCb;           /**< Bus address of dec400 compress table chrominance input (Cb)        */
        ptr_t dec400TableBusCr;           /**< Bus address of dec400 compress table chrominance input (Cr)        */
        const u8 *dec400TablepLum;        /**< Pointer to dec400 compress table luminance input   (Y)             */
        const u8 *dec400TablepCb;         /**< Pointer to dec400 compress table chrominance input (Cb)            */
        const u8 *dec400TablepCr;         /**< Pointer to dec400 compress table chrominance input (Cr)            */
        u32 dec400Enable;
        u32 axiFEEnable;  /*0: axiFE disable   1:axiFE normal mode enable   2:axiFE bypass  3.security mode*/
        u8 *pOutBuf[MAX_STRM_BUF_NUM];          /**< Pointer to output buffer                     */
        ptr_t busOutBuf[MAX_STRM_BUF_NUM];      /**< Bus address of output stream buffer          */
        u32 outBufSize[MAX_STRM_BUF_NUM];       /**< Size of output buffer (bytes)                */
        u32 lineBufWrCnt;    /**< The number of MB lines already in input MB line buffer */
        u32 initSegNum;  /**< The number of segments which input data is stored */
        u32 overlayEnable[MAX_OVERLAY_NUM];
        ptr_t busOlLum[MAX_OVERLAY_NUM];
        ptr_t busOlCb[MAX_OVERLAY_NUM];
        ptr_t busOlCr[MAX_OVERLAY_NUM];
        u32 osdDec400Enable;
        ptr_t osdDec400TableBase;
        VCEncFbdcInfo fbdcInfo;
        bool bEnableRoi;
    } JpegEncIn;

/** Output info */
    typedef struct
    {
        u32 jfifSize;        /**< Encoded JFIF size (bytes)                    */
        u32 invalidBytesInBuf0Tail; /**< unused bytes in buf0 tail*/
    } JpegEncOut;

/* MJPEG Rate control parameters */
    typedef struct
    {
      i32 crf;             /*CRF constant [0,51]*/
      u32 pictureRc;       /* Adjust QP between pictures, [0,1] */
      u32 ctbRc;           /* Adjust QP between Lcus, [0,1] */ //CTB_RC
      u32 blockRCSize;    /*size of block rate control : 2=16x16,1= 32x32, 0=64x64*/
      u32 pictureSkip;     /* Allow rate control to skip pictures, [0,1] */
      i32 qpHdr;           /* QP for next encoded picture, [-1..51]
                                * -1 = Let rate control calculate initial QP
                                * This QP is used for all pictures if
                                * HRD and pictureRc and mbRc are disabled
                                * If HRD is enabled it may override this QP
                                */
      u32 qpMin;           /* Minimum QP for current picture, [0..51] */
      u32 qpMax;           /* Maximum QP for current picture, [0..51] */
      u32 bitPerSecond;    /* Target bitrate in bits/second, this is
                                * needed if pictureRc, mbRc, pictureSkip or
                                * hrd is enabled
                                */
      i32 FixedQp;      /* RW; Range:[-1, 51]; max image quailty allowed
                                * -1 = disable fixed qp mode
                                * 0-51 = value of fixed qp.*/
      u32 hrd;             /* Hypothetical Reference Decoder model, [0,1]
                                * restricts the instantaneous bitrate and
                                * total bit amount of every coded picture.
                                * Enabling HRD will cause tight constrains
                                * on the operation of the rate control
                                */
      u32 hrdCpbSize;      /* Size of Coded Picture Buffer in HRD (bits) */
      u32 bitrateWindow;          /* Length for Group of Pictures, indicates
                                * the distance of two intra pictures,
                                * including first intra [1..300]
                                */
      i32 intraQpDelta;    /* Intra QP delta. intraQP = QP + intraQpDelta
                                * This can be used to change the relative quality
                                * of the Intra pictures or to lower the size
                                * of Intra pictures. [-12..12]
                                */
      u32 fixedIntraQp;    /* Fixed QP value for all Intra pictures, [0..51]
                                * 0 = Rate control calculates intra QP.
                                */
      i32 tolMovingBitRate;/*tolerance of max Moving bit rate */
      i32 monitorFrames;/*monitor frame length for moving bit rate*/
      i32 smoothPsnrInGOP;  /* dynamic bits allocation among GOP using SSE feed back for smooth psnr, 1 - enable, 0 - disable */
      u32 u32StaticSceneIbitPercent; /* I frame bits percent in static scene */
      u32 rcQpDeltaRange; /* ctb rc qp delta range */
      u32 rcBaseMBComplexity; /* ctb rc mb complexity base */
      i32 picQpDeltaMin;  /* minimum pic qp delta */
      i32 picQpDeltaMax;  /* maximum pic qp delta */
      i32 longTermQpDelta; /* QP delta of the frame using long term reference */
      i32 vbr; /* Variable Bit Rate Control by qpMin */
      float tolCtbRcInter; /*Tolerance of Ctb Rate Control for INTER frames*/
      float tolCtbRcIntra; /*Tolerance of Ctb Rate Control for INTRA frames*/
      i32 ctbRcRowQpStep;  /* max accumulated QP adjustment step per CTB Row by Ctb Rate Control.
                                              QP adjustment step per CTB is ctbRcRowQpStep/ctb_per_row. */
      u32 ctbRcQpDeltaReverse; /*ctbrc qpdelta value reversed*/
    } JpegEncRateCtrl;


/*------------------------------------------------------------------------------
    4. Function prototypes
------------------------------------------------------------------------------*/

/** Version information */
    JpegEncApiVersion JencGetApiVersion(void);

/** Build information */
    JpegEncBuild JencGetBuild(u32 core_id, void *ctx);

/** Check if any core has the specified feature or not*/
    int JencCoreHasFeatures(JENC_EWLHwConfig_t *feature,JENC_EWLHwConfig_t *cfg);

/** Helper for input format bit-depths */
    u32 JencGetBitsPerPixel(JpegEncFrameType type);

/** Returns the stride in byte by given aligment and format */
    u32 JencGetAlignedStride(int width, i32 input_format, u32 *luma_stride, u32 *chroma_stride,u32 input_alignment);

/**
   * Initializes the encoder and returns an instance of it. The configuration contains stream
   * parameters that can’t be altered during encoding.
   *
   * \brief Create and Initialize Jpeg Encoder Intstance.
   *
   * \param [in] config Points to the JpegEncCfg structure that contains the encoder’s initial
   *             configuration parameters. Generally, the configure parameter cannot be changed
   *             when encoding.
   * \param [inout] instAddr Points to a space where the new jpeg encoder instance pointer will be stored.
   * \param [in] ctx The context is initialized in application and maybe used by EWL. For example,
   *             when the device is open before initialize, the ctx can be use to transfer this
   *             data. It can be NULL if application don't use it.
   * \return JPEGENC_OK initialize successfully;
   * \return others see \ref JpegEncRet
   */
    JpegEncRet JencInit(const JpegEncCfg * pEncCfg, JpegEncInst * instAddr, void *ctx);

/**  Release Jpeg Encoder Intstance.   */
    JpegEncRet JencRelease(JpegEncInst inst);

/** Encoding configuration */
    JpegEncRet JencSetPictureSize(JpegEncInst inst,
                                     const JpegEncCfg * pEncCfg);

    JpegEncRet JencSetThumbnail(JpegEncInst inst,
                                   const JpegEncThumb * JpegThumb);

/** Jfif generation  */
    JpegEncRet JencEncode(JpegEncInst inst,
                                   const JpegEncIn * pEncIn, JpegEncOut * pEncOut);

/** Get how many MB lines has been encoded by encoder */
    u32 JencGetEncodedMbLines(JpegEncInst inst);

/** Set the input buffer lines available of current picture */
    JpegEncRet JencSetInputMBLines(JpegEncInst inst, u32 lines);

/*------------------------------------------------------------------------------
    5. Encoder API tracing callback function
------------------------------------------------------------------------------*/
    void JpegEnc_Trace(const char *msg);

/*------------------------------------------------------------------------------
    6. Encoder API for special application
------------------------------------------------------------------------------*/

    // /** Run HW without block */
    // JpegEncRet JpegEncEncodeRun(JpegEncInst inst,
    //                                const JpegEncIn * pEncIn,
    //                                JpegEncOut * pEncOut);
    // /* Wait HW status */
    // JpegEncRet JpegEncEncodeWait(JpegEncInst inst,
    //                                JpegEncOut * pEncOut);

/*------------------------------------------------------------------------------
	7. Encoder API for set/get luma chroma size and QpHdr
------------------------------------------------------------------------------*/
/** Get luma size */
    JpegEncRet JencGetLumaSize(JpegEncInst inst, u64 *lumaSize, u64 *dec400LumaTableSize);

/** Set luma size */
    JpegEncRet JencSetLumaSize(JpegEncInst inst, u64 lumaSize, u64 dec400LumaTableSize);

/** Get chroma size*/
    JpegEncRet JencGetChromaSize(JpegEncInst inst, u64 *chromaSize, u64 *dec400ChrTableSize);

/** Set chroma size*/
    JpegEncRet JencSetChromaSize(JpegEncInst inst, u64 chromaSize, u64 dec400ChrTableSize);

/** Get qp hdr*/
    int JencGetQpHdr(JpegEncInst inst);
/*------------------------------------------------------------------------------
	8. Encoder API for get ewl
------------------------------------------------------------------------------*/

/** Get the ewl instance */
    const void *JencGetEwl(JpegEncInst inst);

/** Encoder API for get OSD slice info */
	void JencGetOverlaySlice(JpegEncInst inst, JpegEncIn * pEncIn, i32 restartInterval, i32 partialCoding, i32 slice, i32 sliceRows);

/** Encoder API for get jpeg encoding performance */
    u32 JencGetPerformance(JpegEncInst inst);

/** Get Dec400 VersionId*/
    i32 JencDec400GetVersionId(const void*wlInstance, i32* version_id);

/** set AXIFE enable*/
    void JencAxiFeEnable(void *inst);

/** set AXIFE disable*/
    void JencAxiFeDisable(const void *ewl);


/*------------------------------------------------------------------------------
    AX Add New Interface or Renew Interface
------------------------------------------------------------------------------*/

    JpegEncRet AXJencInit(const JpegEncCfg * pEncCfg, JpegEncInst * instAddr, void *ctx);

/** Set encode preprocess and jpeg data from EncCfg before encode */
    JpegEncRet AXJencSetPictureSize(JpegEncInst inst, const JpegEncCfg * pEncCfg);

/** Encode One Frame */
    JpegEncRet AXJencEncode(JpegEncInst inst, const JpegEncIn * pEncIn, JpegEncOut * pEncOut);

/** Set user qfactor and qTable */
    JpegEncRet AXJencSetUserQpTable(JpegEncInst * instAddr, const u32 qfactor, const u8 *qTableLuma, const u8* qTableChrom);
    JpegEncRet AXJencGetUserQpTable(JpegEncInst * instAddr, u32 *qfactor, u8 *qTableLuma, u8* qTableChrom);

    JpegEncRet AXJencGetLumaSize(JpegEncInst inst, u64 *lumaSize);
    JpegEncRet AXJencSetLumaSize(JpegEncInst inst, u64 lumaSize);
    JpegEncRet AXJencGetChromaSize(JpegEncInst inst, u64 *chromaSize);
    JpegEncRet AXJencSetChromaSize(JpegEncInst inst, u64 chromaSize);

    JpegEncRet AXJpegEncSetRC(JpegEncInst * instAddr,const JpegEncRateCtrl * pRateCtrl);
    JpegEncRet AXJpegEncGetRC(JpegEncInst * instAddr,JpegEncRateCtrl * pRateCtrl);

  /**@}*/



#ifdef __cplusplus
}
#endif

#endif
