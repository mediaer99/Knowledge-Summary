/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2014 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : H2 Encoder Wrapper Layer for OS services
--
------------------------------------------------------------------------------*/

#ifndef __JENC_EWL_H__
#define __JENC_EWL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "base_type.h"
#include "vsi_queue.h"
#include "osal.h"
#include "encswhwregisters.h"
#include "vsi_string.h"


/**
 * \mainpage Overview
 *
 * This document describes the Application Programming Interface (API) of the
 * Hantro VCCORE Encoder Wrapper Layer for VCCORE Video Encoder hardware.
 * Encoder software is written in ANSI C and a compliant compiler is the
 * fundamental requirement for porting the software. Encoder functionality is
 * exposed to an application through an API on top of all the format specific
 * algorithms and control software. Control software relies on an operating
 * system abstraction called the Encoder Wrapper Layer (EWL), which provides
 * all the needed system dependent resources. This structure was chosen to
 * remove the need of modifications in the control software when ported to a
 * new target system.
 *
 * Details of the EWL Encoder Wrapper Layer API are described in this document.
 *  - First components such as data types, return codes, enumerations and relevant structures are described
 *  - Then function syntax and description is presented.
 *  - Finally a software integration guide is presented.
 *
 * \section intro_s1 Supported Standards
 * The API discussed in this version of the document is compatible with the following
 * video encoder standards and profiles:
 *  - HEVC (H.265) - ITU-T Rec. H.265 (04/2013), ISO/IEC 23008-2
 *
 * \section intro_s2 Compatible Hardware
 * Hantro VC8000E Video Encoder IP v6.2.xx or earlier.
 *
 * \section intro_s3 Deprecated Functions
 * This API includes some deprecated functions which may have been supported for earlier
 * Hantro encoders but which are no longer supported for use with VCCORE hardware. These
 * are listed in a separate section near the end of the document.
 */

/**
\page Document Revision History

This section describes top level differences in the versions of this document.

Note: This document is not necessarily updated for each patch or minor revision. The information
in this document tends to be stable across a revision (nnn) series.

| Revision | Date       | Compatible cores                       | Comments |
| -------- | ---------- | -------------------------------------- | -------- |
| 1.00     | 2017-03-28 | VC8000E Series (as of VC8000E v6.0.00) | Initial  |

*/

/** integration.md */

/* HW ID check. */
#define HW_ID_PRODUCT_MASK  0xFFFF0000
#define HW_ID_MAJOR_NUMBER_MASK  0x0000FF00
#define HW_ID_MINOR_NUMBER_MASK  0x000000FF
#define HW_ID_PRODUCT(x) (((x &  HW_ID_PRODUCT_MASK) >> 16))
#define HW_ID_MAJOR_NUMBER(x) (((x &  HW_ID_MAJOR_NUMBER_MASK) >> 8))
#define HW_ID_MINOR_NUMBER(x) ((x &  HW_ID_MINOR_NUMBER_MASK))

#define HW_ID_PRODUCT_H2       0x4832
#define HW_ID_PRODUCT_VC8000E  0x8000

#define HWIF_REG_CFG1  (80)
#define HWIF_REG_CFG2  (214)
#define HWIF_REG_CFG3  (226)
#define HWIF_REG_CFG4  (287)
#define HWIF_REG_CFGAXI  (319)
#define HWIF_REG_CFG5  (430)
#define HWIF_CFG_NUM 7

#define CORE_INFO_MODE_OFFSET       31
#define CORE_INFO_AMOUNT_OFFSET     28

#define MAX_SUPPORT_CORE_NUM        4
/* HW status register bits */
#define ASIC_STATUS_SEGMENT_READY       0x1000
#define ASIC_STATUS_FUSE_ERROR          0x200
#define ASIC_STATUS_SLICE_READY         0x100
#define ASIC_STATUS_LINE_BUFFER_DONE    0x080  /* low latency */
#define ASIC_STATUS_HW_TIMEOUT          0x040
#define ASIC_STATUS_BUFF_FULL           0x020
#define ASIC_STATUS_HW_RESET            0x010
#define ASIC_STATUS_ERROR               0x008
#define ASIC_STATUS_FRAME_READY         0x004
#define ASIC_IRQ_LINE                   0x001

#define ASIC_STATUS_ALL       (ASIC_STATUS_SEGMENT_READY |\
                               ASIC_STATUS_FUSE_ERROR |\
                               ASIC_STATUS_SLICE_READY |\
                               ASIC_STATUS_LINE_BUFFER_DONE |\
                               ASIC_STATUS_HW_TIMEOUT |\
                               ASIC_STATUS_BUFF_FULL |\
                               ASIC_STATUS_HW_RESET |\
                               ASIC_STATUS_ERROR |\
                               ASIC_STATUS_FRAME_READY)

  /* Return values */
#define EWL_OK                      0
#define EWL_ERROR                  -1

#define EWL_HW_WAIT_OK              EWL_OK
#define EWL_HW_WAIT_ERROR           EWL_ERROR
#define EWL_HW_WAIT_TIMEOUT         1

  /* HW configuration values */
#define EWL_HW_BUS_TYPE_UNKNOWN     0
#define EWL_HW_BUS_TYPE_AHB         1
#define EWL_HW_BUS_TYPE_OCP         2
#define EWL_HW_BUS_TYPE_AXI         3
#define EWL_HW_BUS_TYPE_PCI         4

#define EWL_HW_BUS_WIDTH_UNKNOWN     0
#define EWL_HW_BUS_WIDTH_32BITS      1
#define EWL_HW_BUS_WIDTH_64BITS      2
#define EWL_HW_BUS_WIDTH_128BITS     3

#define EWL_HW_SYNTHESIS_LANGUAGE_UNKNOWN     0
#define EWL_HW_SYNTHESIS_LANGUAGE_VHDL        1
#define EWL_HW_SYNTHESIS_LANGUAGE_VERILOG     2

#define EWL_HW_CONFIG_NOT_SUPPORTED    0
#define EWL_HW_CONFIG_ENABLED          1

  /** core_id : bit0~7 is core index, bit 16~23 is slice node index. */
  /* get core slice index from core ID */
#define CORE(id) ((u32)(id)&0xff)
#define NODE(id) ((u32)(id)>>16)
  /* combine slice node and core index as COREID */
#define COREID(node,core) (((u32)(node)<<16)|((u32)(core)&0xff))


#define MEM_CHUNKS      720

#define EWL_MEM_TYPE_CPU                 0U /* CPU RW. non-secure CMA memory */
#define EWL_MEM_TYPE_SLICE               1U /* VPU W, CPU RW. As output buffer for Encoder */
#define EWL_MEM_TYPE_DPB                 2U /* VPU W. As Input/Recon buffer for Encoder*/
#define EWL_MEM_TYPE_VPU_WORKING         3U /* VPU RW, CPU RW. non-secure memory. As working buffer for Encoder */
#define EWL_MEM_TYPE_VPU_WORKING_SPECIAL 4U /* VPU R, CPU RW. */
#define EWL_MEM_TYPE_VPU_ONLY            5U /* VPU RW only. */

#ifdef MEM_ONLY_DEV_CHECK
#define EWL_DEVMEM_VAILD(mem) ((mem).busAddress != 0)
#else
#define EWL_DEVMEM_VAILD(mem) ((mem).virtualAddress != NULL)
#endif
/**
 * \defgroup api_ewl Encoder Wrapper Layer(EWL) API
 *
 * @{
 */

  /* Hardware configuration description */
//swreg80 bit             name                                      function

//    bit 30                 sw_enc_HWScalingSupport         Down-scaling supported by HW. 0=not supported. 1=supported
//    bit 29                 sw_enc_HWBFrameSupport         HW bframe support. 0=not support bframe. 1=support bframe
//    bit 28                 sw_enc_HWRgbSupport              RGB to YUV conversion supported by HW. 0=not supported. 1=supported
//    bit 27                 sw_enc_HWHevcSupport             HEVC encoding supported by HW. 0=not supported. 1=supported
//    bit 26                 sw_enc_HWVp9Support              VP9 encoding supported by HW. 0=not supported. 1=supported
//    bit 25                 sw_enc_HWDenoiseSupport        Denoise supported by HW, 0=not supported. 1=supported
//    bit [23:21]           sw_enc_HWBus                         Bus connection of HW. 1=AHB. 2=OCP. 3=AXI. 4=PCI. 5=AXIAHB. 6=AXIAPB.
//    bit 20                 sw_enc_HWCavlcSupport            CAVLC supported by HW, 0=not supported. 1=supported
//    bit 19                 sw_enc_HWLineBufSupport         LineBuffer input mode supported by HW, 0=not supported. 1=supported
//    bit 18                 sw_enc_HWProgRdoSupport       Prog Rdo supported by HW, 0=not supported. 1=supported
//    bit 17                 sw_enc_HWRFCSupport             Reference frame compression supported by HW, 0=not supported. 1=supported
//    bit 16                 sw_enc_HWTU32Support            TU32 supported by HW, 0=not supported. 1=supported
//    bit 15                 sw_enc_HWJPEGSupport           JPEG encoder supported by HW, 0=not supported. 1=supported
//    bit [14:13]          sw_enc_HWBusWidth                 Bus width of HW. 0=32b. 1=64b. 2=128b
//    bit [12:00]          sw_enc_HWMaxVideoWidth         Maximum video width supported by HW (pixels)
  /** A structure containing the EWL hardware configuration parameters.
   */
  typedef struct JENC_EWLHwConfig
  {
    u32 h264Enabled;     /**< swreg80[31] HW supports H264.<br>      0: not supported,   1: supported */
    u32 scalingEnabled;  /**< swreg80[30] HW supports Down-scaling.<br>     0: not supported;   1: supported */
    u32 bFrameEnabled;   /**< swreg80[29] HW supports B-frame.<br>   0: not supported;   1: supported */
    u32 rgbEnabled;      /**< swreg80[28] HW supports RGB input */
    u32 hevcEnabled;     /**< bit 27 *//**< HW supports HEVC */
    u32 vp9Enabled;      /**<bit 26 *//**< HW supports VP9 */
    u32 deNoiseEnabled;      /**<bit 25 *//**< HW supports DeNoise */
    u32 main10Enabled;      /**<bit 24 *//**< HW supports Main10 */
    u32 busType;      /**<bit 23:21 *//**< HW bus type in use  1=AHB. 2=OCP. 3=AXI. 4=PCI. 5=AXIAHB. 6=AXIAPB.*/
    u32 cavlcEnable; /**<bit 20 *//**< HW support H264 CAVLC */
    u32 lineBufEnable; /**<bit 19 *//**< HW support line buffer input mode */
    u32 progRdoEnable; /**<bit 18 *//**< HW support prog rdo for HEVC */
    u32 rfcEnable;         /**<bit 17 *//**< HW support reference frame compression */
    u32 tu32Enable;      /**<bit 16 *//**< HW support TU32 transform for HEVC */
    u32 jpegEnabled;     /**< bit 15   */ /**< HW support jpeg encoder */
    u32 busWidth;           /**<bit 14:13 *//**< bus width  */
    u32 maxEncodedWidthHEVC; /**<bit 12:0 *//**< Maximum supported width for video encoding (HEVC mode on V62 and later) */

    /**< second part fuse in reg 214 */
    u32 ljpegSupport;        /**<bit 31 */ /**< HW supports Loss JPEG or not */
    u32 roiAbsQpSupport; /**<bit 30 */ /**< HW supports ROI Absolute QP or not */
    u32 intraTU32Enable;  /**<bit 29 */ /**< HW supports IntraTU32 or not */
    u32 roiMapVersion;    /**<bit 28:26 */ /**< roi map buffer format version */
    u32 maxEncodedWidthH264; /**<bit 25:13 *//**< Maximum supported width for video encoding (H264 mode) */
    u32 maxEncodedWidthJPEG; /**<bit 12:0 *//**< Maximum supported width for video encoding (JPEG mode) */

    /**< third part fuse in reg 226 */
    u32 ssimSupport;        /**<bit 31 */ /**< HW supports SSIM calculation or not */
    u32 P010RefSupport;        /**<bit 30 */ /**< HW supports P010 tile-raster format for reference frame buffer or not */
    u32 cuInforVersion;     /**<bit 29:27*/ /**< Version of the output CU information format. */
    u32 meVertSearchRangeHEVC;  /**<bit 26:21*/ /**<ME vertical search range in 8 pixel unit for HEVC*/
    u32 meVertSearchRangeH264;   /**<bit 20:15*/ /**<ME vertical search range in 8 pixel unit for H264*/
    u32 ctbRcVersion;          /**<bit 14:12 */ /**< CTB RC Version */
    u32 jpeg422Support;        /**<bit 11 */ /**< HW supports JPEG422 coding or not */
    u32 gmvSupport;            /**<bit 10*/ /**<Global MV supported by HW. 0=not supported. 1=supported*/
    u32 ROI8Support;           /**<bit 9 */ /**<8 ROIs supported by HW. 0=not supported. 1=supported*/

    /**< multi-pass features*/
    u32 meHorSearchRangeBframe;/**< bit 8:7 */ /**< ME4N horizontal search range in 64 pixel unit for BFrame (0: 64 pixel)*/
    u32 RDOQSupportHEVC;       /**< bit 6 */ /**< HW support HEVC RDOQ or not */
    u32 bMultiPassSupport;     /**< bit 5 */ /**< HW support multipass: 0=not supported. 1=supoorted.*/
    u32 inLoopDSRatio;         /**< bit 4*/  /**< HW support in-loop down scale: 0=1:1, 1=1:2.*/
    u32 streamBufferChain;     /**< bit 3 */ /**< Stream Buffer Chain supported by HW. 0=not supported. 1=supported */
    u32 streamMultiSegment;    /**< bit 2 */ /**< Stream multi-segment supported by HW. 0=not supported. 1=supported */
    u32 IframeOnly;  /**< bit 1 */ /**< Only I frame supported by HW. 0=I/P/B supported. 1=I only supported */
    u32 dynamicMaxTuSize;         /**< bit 0 */ /**< Dynamic max TU size change per frame supported by HW. 0=not supported. 1=supported */

    /**< fourth part fuse in reg 287 */
    u32 videoHeightExt;    /**< bit 31*/ /**< Maximum allowed video height extended from 8192 to 8640. 0=Not. 1=Yes. */
    u32 cscExtendSupport;  /**< bit 30*/ /**< RGB to YUV conversion extension. 0=not supported. 1=supported */
    u32 scaled420Support;  /**< bit 29*/ /**< out-loop scaler output YUV420SP. 0=not supported. 1=supported */
    u32 cuTreeSupport;     /**< bit 28*/ /**< Support of CuTree Lookahead */
    u32 maxAXIAlignment; /**< bit 27:24 */ /**< Maximum DDR alignment supported by HW */
    u32 meVertRangeProgramable;  /**<bit 22*/ /**<Programable ME vertical search range.  0=not supported. 1=supported*/
    u32 MonoChromeSupport; /**< bit21 */ /**< monochrome supported by HW. 0=not supported. 1=supported */
    u32 ExtSramSupport; /**< bit20 */ /**< external SRAM supported by HW. 0=not supported. 1=supported */
    u32 vsSupport;      /**< bit19 */ /**< HW supports video stabilization. 0=not supported. 1=supported */
    u32 RDOQSupportH264;   /**< bit 18 */ /**< HW support H264 RDOQ or not */
    u32 disableRecWtSupport;  /**< bit 17 */ /**< HW supports disable to write recon to DDR. 0=not supported. 1=supported */
    u32 OSDSupport;        /**< bit 16 */ /**< HW support OSD or not */
    u32 H264NalRefIdc2bit; /**< bit 15 */ /**< HW support H264 2bitNalRefIdc or not */
    u32 dynamicRdoSupport; /**< bit 14 */ /**< HW support HEVC/AV1 Dynamic RDO or not. 0=not supported. 1=supported */
    u32 av1Enabled; /**< bits13 */ /**< HW support AV1 encoding or not. 0=not supported. 1=supported */
    u32 maxEncodedWidthAV1; /**< bits 12:00 */ /**< Maximum video width supported by HW for AV1 (in 8x8 blocks) */

    /**< AXI fuse in reg 319 */
    u32 AXIAlignFuse;

    /**< fifth part fuse in reg 430 */
    u32 RDOQSupportAV1; /**< bit 31 */ /**< HW support AV1 RDOQ or not. 0=not supported. 1=supported */
    u32 av1InterpFilterSwitchable; /**< bit 30 */ /**< HW support AV1 interp filter switchable or not. 0=not supported. 1=supported */
    u32 JpegRoiMapSupport; /**< bit 29 */ /**< HW support Jpeg Roi Map or not*/
    u32 backgroundDetSupport; /**< bit 28 */ /**< HW support background detection Map or not*/
    u32 RDOQSupportVP9; /**< bit 27 */ /**< HW support VP9 RDOQ or not. 0=not supported. 1=supported */
    u32 CtbBitsOutSupport; /**< bit 26 */ /**< HW support output encoded bits for each ctb. 0=not supported. 1=supported */
    u32 encVisualTuneSupport; /**< bit 25 */ /**< HW support visual tune. 0=not supported. 1=supported */
    u32 encPsyTuneSupport; /**< bit 24 */ /**< HW support psy tune. 0=not supported. 1=supported */
    u32 NonRotationSupport; /**< bit 23 */ /**< HW not suport rotation. 0=supported. 1= not supported */
    u32 NVFormatOnlySupport; /**< bit 22 */ /**< HW only support nv input format. 0=support all input format. 1=only support nv input format */
    u32 MosaicSupport;     /**< bit 21 */ /**< HW mosaic feature support. 0=not supported. 1=supported */
    u32 IPCM8Support;      /**< bit 20 */ /**<8 IPCMs supported by HW. 0=not supported. 1=supported*/

    u32 psnrSupport;       /**< bit 18 */ /**<H264/H265 PSNR supported by HW. 0=not supported. 1=supported*/
    u32 prpSbiSupport;     /**< bit 17 */ /**<prp sbi supported by HW. 0=not supported. 1=supported*/
  } JENC_EWLHwConfig_t;


  /** Allocated linear memory area information */
  typedef struct JENC_EWLLinearMem
  {
    u32 *virtualAddress;     /**< aligned virtural address access by CPU */
    ptr_t busAddress;        /**< aligned bus address access by HW */
    u32 size;                /**< size in byte */
    u32 *allocVirtualAddr;   /**< allocated virtural address access by CPU */
    ptr_t allocBusAddr;     /**< allocated bus address access by HW */
    unsigned long id;       /**< ID to identify buffer */
    u32 mem_type;           /**< to indicate the memory type -- which master will access it */
  } JENC_EWLLinearMem_t;

  /** EWLInitParam is used to pass parameters when initializing the EWL */
  typedef struct JENC_EWLInitParam
  {
    u32 clientType;
    void *context;
    u32 slice_idx;   /* for multi-node VPU */
    u32 mmuEnable;
  } JENC_EWLInitParam_t;

  typedef struct JENC_CacheData
  {
    void** cache;
  }JENC_CacheData_t;

  typedef void (*CoreWaitCallBackFunc)(const void *ewl, void *data);
  typedef struct JENC_EWLCoreWaitJob
  {
    struct node *next;
    u32 id;       /**< ID to identify job */
    u32 core_id; /*HW subsystem id*/
    const void *inst;
    u32 VC8000E_reg[ASIC_SWREG_AMOUNT];
    i32 out_status;
    u32 slices_rdy;
    u32 low_latency_rd;
    u32 dec400_enable;
    //VCDec400data dec400_data;
    CoreWaitCallBackFunc dec400_callback;
    u32 axife_enable;
    CoreWaitCallBackFunc axife_callback;
	  u32 l2cache_enable;
    JENC_CacheData_t l2cache_data;
    CoreWaitCallBackFunc l2cache_callback;

  } JENC_EWLCoreWaitJob_t;

  typedef struct JENC_EWLCoreWait
  {
    struct queue jobs;
    pthread_mutex_t job_mutex;
    pthread_cond_t job_cond;
    struct queue out;
    pthread_mutex_t out_mutex;
    pthread_cond_t out_cond;
    pthread_t *tid_CoreWait;
    bool bFlush;
    u32 refer_counter;
    struct queue job_pool;
  }JENC_EWLCoreWait_t;

  typedef struct JENC_EWLWaitJobCfg
  {
    u32 waitCoreJobid;
    u32 dec400_enable;
    void *dec400_data;
    u32 axife_enable;
    CoreWaitCallBackFunc axife_callback;
	  u32 l2cache_enable;
    void* l2cache_data;
    CoreWaitCallBackFunc l2cache_callback;
  } JENC_EWLWaitJobCfg_t;

#if 0
#define JENC_EWL_CLIENT_TYPE_H264_ENC         0U
#define JENC_EWL_CLIENT_TYPE_HEVC_ENC         1U
#define JENC_EWL_CLIENT_TYPE_VP9_ENC          2U
#define JENC_EWL_CLIENT_TYPE_JPEG_ENC         3U
#define JENC_EWL_CLIENT_TYPE_CUTREE           4U
#define JENC_EWL_CLIENT_TYPE_VIDEOSTAB        5U
#define JENC_EWL_CLIENT_TYPE_DEC400           6U
#define JENC_EWL_CLIENT_TYPE_AV1_ENC          7U
#endif

  /** JENC_CLIENT_TYPE is used to select available HW engine when initializing the EWL */
  typedef enum{
    JENC_EWL_CLIENT_TYPE_H264_ENC = 0U,          /**< H264 Encoder */
    JENC_EWL_CLIENT_TYPE_HEVC_ENC        =1U,   /**< HEVC Encoder */
    JENC_EWL_CLIENT_TYPE_VP9_ENC         =2U,    /**< VP9 Encoder */
    JENC_EWL_CLIENT_TYPE_JPEG_ENC        =3U,    /**< JPEG Encoder */
    JENC_EWL_CLIENT_TYPE_CUTREE          =4U,    /**< CU Tree Analyzer Engine */
    JENC_EWL_CLIENT_TYPE_VIDEOSTAB       =5U,    /**< Video Stabilization Engine (invalid now) */
    JENC_EWL_CLIENT_TYPE_DEC400          =6U,    /**< DEC400 engine */
    JENC_EWL_CLIENT_TYPE_AV1_ENC         =7U,    /**< AV1 Encoder */
	  JENC_EWL_CLIENT_TYPE_L2CACHE			=8U,    /**< L2CACHE engine */
    JENC_EWL_CLIENT_TYPE_AXIFE           =9U,    /**< AXIfe engine */
    JENC_EWL_CLIENT_TYPE_APBFT           =10U,    /**< APBfilter engine */
    JENC_EWL_CLIENT_TYPE_AXIFE_1         =11U,
    JENC_JENC_EWL_CLIENT_TYPE_MAX
  }JENC_CLIENT_TYPE;

  typedef struct
  {
      i32 (*EWLGetLineBufSramP)(const void *, JENC_EWLLinearMem_t *);
      i32 (*JencEWLMallocLoopbackLineBufP)(const void *, u32 , JENC_EWLLinearMem_t *);
      u32 (*EWLGetClientTypeP)(const void *);
      u32 (*EWLGetCoreTypeByClientTypeP)(u32 );
      i32 (*EWLCheckCutreeValidP)(const void *);
      u32 (*EWLReadAsicIDP)(u32 , void *);
      JENC_EWLHwConfig_t (*EWLReadAsicConfigP)(u32 , void *);
      const void *(*EWLInitP)(JENC_EWLInitParam_t *);
      i32 (*EWLReleaseP)(const void *);
      void (*EwlReleaseCoreWaitP)(void *);
      JENC_EWLCoreWaitJob_t* (*EWLDequeueCoreOutJobP)(const void *, u32 );
      void (*EWLEnqueueOutToWaitP)(const void *, JENC_EWLCoreWaitJob_t *);
      void (*EWLEnqueueWaitjobP)(const void *, u32);
      void (*EWLPutJobtoPoolP)(const void *, struct node *);
      void (*JencEWLPutJobtoPool)(const void *, struct node *);
      void (*EWLWriteCoreRegP)(const void *, u32 , u32 , u32 );
      void (*EWLWriteRegP)(const void *, u32 , u32 );
      void (*JencEWLSetReserveBaseDataP)(const void *,u32 ,u32 ,u32 ,u32 ,u32 ,u16 );
      void (*JencEWLCollectWriteRegDataP)(const void *, u32*, u32*,u16 , u32 ,u32*);
      void (*EWLCollectNopDataP)(const void *,u32*,u32*);
      void (*EWLCollectStallDataEncVideoP)(const void *,u32*,u32*);
      void (*EWLCollectStallDataCuTreeP)(const void *,u32*,u32*);
      void (*EWLCollectReadRegDataP)(const void *,u32*,u16, u32,u32*,u16);
      void (*EWLCollectIntDataP)(const void *,u32*,u32*,u16);
      void (*EWLCollectJmpDataP)(const void *,u32*,u32*,u16);
      void (*EWLCollectClrIntDataP)(const void *,u32*,u32*);
      void (*EWLCollectClrIntReadClearDec400DataP)(const void *,u32*,u32*,u16);
      void (*EWLCollectStopHwDataP)(const void *,u32*,u32*);
      void (*EWLCollectReadVcmdRegDataP)(const void *,u32*,u16, u32,u32*,u16);
      void (*JencEWLCollectWriteDec400RegDataP)(const void *, u32*, u32*,u16, u32,u32*);
      void (*JencEWLCollectStallDec400P)(const void *, u32*,u32*);
      void (*EWLWriteBackRegP)(const void *, u32, u32);
      void (*EWLEnableHWP)(const void *, u32, u32);
      u32 (*EWLGetPerformanceP)(const void *);
      void (*EWLDisableHWP)(const void *, u32, u32);
      u32 (*EWLReadRegP)(const void *, u32 );
      u32 (*EWLReadRegInitP)(const void *, u32);
      i32 (*JencEWLMallocRefFrmP)(const void *, u32, u32,JENC_EWLLinearMem_t *);
      void (*JencEWLFreeRefFrmP)(const void *, JENC_EWLLinearMem_t *);
      i32 (*JencEWLMallocLinearP)(const void *, u32, u32,JENC_EWLLinearMem_t *);
      void (*JencEWLFreeLinearP)(const void *, JENC_EWLLinearMem_t *);
      void (*EWLDCacheRangeFlushP)(const void *, JENC_EWLLinearMem_t *);
      i32 (*EWLWaitHwRdyP)(const void *, u32 *,void *,u32*);
      void (*EWLDCacheRangeRefreshP)(const void *, JENC_EWLLinearMem_t *);
      void (*EWLReleaseHwP)(const void *);
      i32 (*EWLReserveHwP)(const void *, u32 *, u32 *);
      u32 (*EWLGetCoreNumP)(void *);
      i32 (*EWLGetDec400CoreidP)(const void *);
      u32 (*EWLGetDec400CustomerIDP)(const void *, u32);
      i32 (*EWLReserveCmdbufP)(const void *, u16,u16*);
      void (*EWLCopyDataToCmdbufP)(const void *, u32*,u32,u16);
      i32 (*EWLLinkRunCmdbufP)(const void *, u16,u16);
      i32 (*EWLWaitCmdbufP)(const void *, u16, u32 *);
      i32 (*EWLReleaseCmdbufP)(const void *, u16);
      void (*EWLTraceProfileP)(const void *, void *,i32, i32);
      u32 (*EWLGetVCMDSupportP)();
      void (*EWLSetVCMDModeP)(const void *inst, u32 mode);
      u32 (*EWLGetVCMDModeP)(const void *inst);

      u32 (*EWLReleaseEwlWorkerInstP)(const void *inst);
      void (*EWLClearTraceProfileP)(const void *);
  } Jenc_EWLFun;

  extern u32 (*JencPollInputLineBufTestFunc)(void);

  /*------------------------------------------------------------------------------
      4.  Function prototypes
  ------------------------------------------------------------------------------*/

/**
 * Reads and returns the hardware ID register value, static implementation.
 * \param [in] core_id Describes the hardware core to read.
 * \param [in] ctx context to access this hardware if needed, e.g the device descriptions for this instance.
 * \return The hardware ID register value.
 */
  u32 JencEWLReadAsicID(u32 core_id, void *ctx);

  u32 JencEWLGetCoreNum(void *ctx);

  i32 JencEWLGetDec400Coreid(const void *inst);

  void JencEWLDisableDec400(const void *inst);

  int JencMapAsicRegisters(void * ewl);

  u32 JencEWLGetClientType(const void *inst);

  u32 JencEWLGetCoreTypeByClientType(u32 client_type);

  i32 JencEWLCheckCutreeValid(const void *inst);

  u32 JencEWLGetDec400CustomerID(const void *inst, u32 core_id);

  /** Read and return HW configuration info, static implementation */
  JENC_EWLHwConfig_t JencEWLReadAsicConfig(u32 core_id, void *ctx);

  /**
   * \brief Initialize the EWL instance
   *
   * JencEWLInit is called when the encoder instance is initialized.
   *
   * \param [in] param the configure for this instance
   * \return a wrapper instance or NULL for error
   *
   */
  const void *JencEWLInit(JENC_EWLInitParam_t *param);

  /**
   * Release the EWL instance. It is called when the encoder instance is released
   * \return EWL_OK or EWL_ERROR
   */
  i32 JencEWLRelease(const void *inst);

  /**
   * Reserve the HW resource for one codec instance. JencEWLReserveHw is called when beginning a frame encoding
   * The function may block until the resource is available.
   * \return EWL_OK if the resource was successfully reserved for this instance
   * \return EWL_ERROR if unable to reserve the resource.
   */
  i32 JencEWLReserveHw(const void *inst, u32 *core_info, u32 *job_id);

  /**
   * \brief Release the HW resource
   *
   * JencEWLReleaseHw is called when the HW has finished the frame encoding. Software should save the hardware
   *   status locally and continue the further processing according to such information. Hardware resource
   *   will not available then. The HW can be used by another instance then.
   */
  void JencEWLReleaseHw(const void *inst);

  void JencEwlReleaseCoreWait(void *inst);

  JENC_EWLCoreWaitJob_t *JencEWLDequeueCoreOutJob(const void *inst, u32 waitCoreJobid);

  void JencEWLEnqueueOutToWait(const void *inst, JENC_EWLCoreWaitJob_t *job);

  void JencEWLEnqueueWaitjob(const void *inst, JENC_EWLWaitJobCfg_t *cfg);

  void JencEWLPutJobtoPool(const void *inst, struct node *job);

  u32 JencEWLGetPerformance(const void *inst);

  /** Frame buffers memory */
  i32 JencEWLMallocRefFrm(const void *instance, u32 size, u32 alignment,JENC_EWLLinearMem_t * info);
  void JencEWLFreeRefFrm(const void *inst, JENC_EWLLinearMem_t *info);

  /** SW/HW shared memory */
  i32 JencEWLMallocLinear(const void *instance, u32 size, u32 alignment,JENC_EWLLinearMem_t * info);
  void JencEWLFreeLinear(const void *inst, JENC_EWLLinearMem_t *info);

  /* D-Cache coherence *//* Not in use currently */
  void JencEWLDCacheRangeFlush(const void *instance, JENC_EWLLinearMem_t *info);
  void JencEWLDCacheRangeRefresh(const void *instance, JENC_EWLLinearMem_t *info);

  /**
   * \brief Write value to a HW register
   *
   * All registers are written at once at the beginning of frame encoding
   * Offset is relative to the the HW ID register (#0) in bytes
   * Enable indicates when the HW is enabled. If shadow registers are used then
   * they must be flushed to the HW registers when enable is '1' before
   * writing the register that enables the HW
   */
  void JencEWLWriteReg(const void *inst, u32 offset, u32 val);
  /** Write back value to a HW register on callback/frame done (for multicore) */
  void JencEWLWriteBackReg(const void *inst, u32 offset, u32 val);
  /** Write value to HW register by specified core id*/
  void JencEWLWriteCoreReg(const void *inst, u32 offset, u32 val, u32 core_id);

  void JencEWLWriteRegbyClientType(const void *inst, u32 offset, u32 val, u32 client_type);

  void JencEWLWriteBackRegbyClientType(const void *inst, u32 offset, u32 val, u32 client_type);

  /** Read and return the value of a HW register
   * The status register is read after every macroblock encoding by SW
   * The other registers which may be updated by the HW are read after
   * BUFFER_FULL or FRAME_READY interrupt
   * Offset is relative to the the HW ID register (#0) in bytes */
  u32 JencEWLReadReg(const void *inst, u32 offset);

  u32 JencEWLReadRegbyClientType(const void *inst, u32 offset, u32 client_type);

  /** Writing all registers in one call *//*Not in use currently */
  void EWLWriteRegAll(const void *inst, const u32 *table, u32 size);
  /** Reading all registers in one call *//*Not in use currently */
  void EWLReadRegAll(const void *inst, u32 *table, u32 size);

  /** HW enable/disable. This will write <val> to register <offset> and by */
  /** this enablig/disabling the hardware. */
  void JencEWLEnableHW(const void *inst, u32 offset, u32 val);
  void JencEWLDisableHW(const void *inst, u32 offset, u32 val);

  /**
   * \brief Synchronize SW with HW
   *
   * JencEWLWaitHwRdy is called after enabling the HW to wait for IRQ from HW.
   * If slicesReady pointer is given, at input it should contain the number
   * of slicesReady received. The function will return when the HW has finished
   * encoding next slice. Upon return the slicesReady pointer will contain
   * the number of slices that are ready and available in the HW output buffer.
   *
   * \return EWL_HW_WAIT_OK when hardware can work normally even if error is detected
   * \return EWL_HW_WAIT_ERROR error is detected by software
   * \return EWL_HW_WAIT_TIMEOUT hardware timeout happens.
   */
  i32 JencEWLWaitHwRdy(const void *instance, u32 *slicesReady, void *waitOut, u32* status_register);


  /** SW/SW shared memory handling */
  void *JencEWLmalloc(u32 n);
  void *JencEWLcalloc(u32 n, u32 s);
  void JencEWLfree(void *p);
  mem_ret JencEWLmemcpy(void *d, const void *s, u32 n);
  mem_ret JencEWLmemset(void *d, i32 c, u32 n);
  int JencEWLmemcmp(const void *s1, const void *s2, u32 n);

  /** Get the address/size of on-chip sram used for input line buffer. */
  i32 JencEWLGetLineBufSram (const void *instance, JENC_EWLLinearMem_t *info);

  /** allocate loopback line buffer in memory, mainly used when there is no on-chip sram */
  i32 JencEWLMallocLoopbackLineBuf (const void *instance, u32 size, JENC_EWLLinearMem_t *info);

  /**
   * Get the PSNR/SSIM result, valid only in the c-model.
   */
  void JencEWLTraceProfile(const void *inst, void *prof_data,i32 qp, i32 poc);

  void JencEWLCollectWriteRegData(const void *inst, u32* src, u32* dst,u16 reg_start, u32 reg_length,u32* total_length);
  void JencEWLCollectStallDataEncVideo(const void *inst,u32* dst,u32* total_length);
  void JencEWLCollectStallDataCuTree(const void *inst,u32* dst,u32* total_length);
  void JencEWLCollectStallDec400(const void *inst, u32* dst,u32* total_length);
  void JencEWLCollectReadRegData(const void *inst,u32* dst,u16 reg_start, u32 reg_length,u32* total_length,u16 cmdbuf_id);
  void JencEWLCollectWriteMMURegData(const void *inst, u32* src, u32* dst,u16 reg_start, u32 reg_length,u32* total_length);
  void JencEWLCollectReadVcmdRegData(const void *inst,u32* dst,u16 reg_start, u32 reg_length,u32* total_length,u16 cmdbuf_id);
  void JencEWLCollectWriteDec400RegData(const void *inst, u32* src, u32* dst,u16 reg_start, u32 reg_length,u32* total_length);
  void JencEWLCollectClrIntReadClearDec400Data(const void *inst,u32* dst,u32* total_length,u16 addr_offset);
  void JencEWLCollectIntData(const void *inst,u32* dst,u32* total_length,u16 cmdbuf_id);
  void JencEWLCollectJmpData(const void *inst,u32* dst,u32* total_length,u16 cmdbuf_id);
  void JencEWLCollectClrIntData(const void *inst,u32* dst,u32* total_length);
  void JencEWLCollectStopHwData(const void *inst,u32* dst,u32* total_length);
  void JencEWLCollectNopData(const void *inst,u32* dst,u32* total_length);
  u32 JencEWLReadRegInit(const void *inst, u32 offset);
  i32 JencEWLReserveCmdbuf(const void *inst, u16 size,u16* cmdbufid);
  void JencEWLCopyDataToCmdbuf(const void *inst, u32* src,u32 size,u16 cmdbuf_id);
  i32 JencEWLLinkRunCmdbuf(const void *inst, u16 cmdbufid,u16 cmdbuf_size);
  i32 JencEWLWaitCmdbuf(const void *inst, u16 cmdbufid, u32 * status);
  i32 JencEWLReleaseCmdbuf(const void *inst, u16 cmdbufid);
  void JencEWLSetReserveBaseData(const void *inst,u32 width,u32 height,u32 rdoLevel,u32 bRDOQEnable,u32 module_type,u16 priority);

  void JencEWLSetVCMDMode(const void *inst, u32 mode);
  u32 JencEWLGetVCMDMode(const void *inst);

  u32 JencEWLGetVCMDSupport();

  void JencEWLAttach(void *ctx,int slice_idx,i32 vcmd_support);
  void JencEWLDetach();
  // FBDC_ENABLE
  i32 JencEWLConfigFbdcInfo(const void *inst, u16 crop_x,u16 crop_y,u32 uvaddr,u32 yaddr,u32 width);

  u32* JencEWLLoadAsicConfig(u32 *regs, u32 *configs);
  void JencEWLParseAsicConfig(JENC_EWLHwConfig_t     *cfg_info, u32 *configs);
  u32 JencEWLReleaseEwlWorkerInst(const void *inst);
  void JencEWLClearTraceProfile(const void *inst);
  /**@}*/

#ifdef __cplusplus
}
#endif
#endif /*__EWL_H__*/
