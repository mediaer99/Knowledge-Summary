#ifndef _AX_VENC_PROC_H_
#define _AX_VENC_PROC_H_

#include <pthread.h>
#include "ax_global_type.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VENC_PROC_MSG_LEN           (64*1024)

typedef  void  EncProcCatCallback(char *msg, int msgMaxLen);
typedef void EncProcUpdate();

typedef struct EncProcParams {
  AX_BOOL bExit;
  pthread_t threadId;
  EncProcCatCallback *callback;
} ENC_PROC_PARAMS_S;

/* reserve for video encoder proc */
AX_S32 VencProcInit(EncProcCatCallback *vencCallback);
AX_S32 VencProcDeinit(void);
void VencProcCatCallback(char *msg, int msgMaxLen);

AX_VOID VencProcUpdate();

#ifdef __cplusplus
}
#endif

#endif