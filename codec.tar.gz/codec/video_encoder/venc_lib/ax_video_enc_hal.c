#include "ax_video_enc_hal.h"
#include "ax_venc_interface.h"
#include "ax_fifo.h"
#include "ax_video_enc.h"
#include <math.h>
#include <sys/prctl.h>
#include <sys/ioctl.h>
#include "vsi_string.h"
#include "base_type.h"

#include "hevcencapi.h"
#include "vcenc_stream_ctrl.h"
#include "enccommon.h"
#include "ax_video_enc_utils.h"
#include "ax_video_enc_init.h"
#include "ax_video_enc_pic_config.h"
#include "ax_sys_api.h"
#include "ax_sys_api_internal.h"
#include "ax_utils.h"
#include "ax_frame.h"

#include "ax_venc_log.h"
#include "vc8000_driver.h"

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)

#define DEBUG_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_enc_hal.c %s %d "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_enc_hal.c %s %d Error! "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define ALIGN_UP(x,a)    (((x)+(a)-1)&~(a-1))

AX_AVCHEVC_HANDLE_S *gAvcHevcHandle[MAX_VENC_NUM] = {NULL};

extern AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM];
extern AX_VENC_MOD_INSTANCE_S gModCtx;

static int VencRoiAttrCheck(VENC_CHN VeChn, const AX_VENC_ROI_ATTR_S *pstRoiAttr, AX_AVCHEVC_HANDLE_S *pHandle);
static void VencRoiAttrPrint(AX_S32 VeChn, VCEncCodingCtrl *pstCodingCfg);
static void VencRoiAttrSetting(AX_S32 VeChn, const AX_VENC_ROI_ATTR_S *pstRoiAttr,
				VENC_ROI_MB_AREA_T *pstRoiArea, VCEncCodingCtrl *pstCodingCfg);

static int VencRcParamCheck(AX_AVCHEVC_HANDLE_S *pHandle, const AX_VENC_RC_PARAM_S *pstRcParam);

static AX_BOOL IsVencFifoFull(VENC_CHN VeChn, FifoInst fifoObj);
static AX_BOOL IsVencFifoEmpty(VENC_CHN VeChn, FifoInst fifoObj);
static AX_BOOL IsVencChnResReady(AX_S32 Vechn, AX_LINK_MODE_E enMode);
static AX_BOOL IsVencAllChnStoped(AX_U32 loopIndex);
static int VencChannelDyamicAttrCheck(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pChnAttr);
static int VencChangeTypeAttrReset(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pChnAttr);
static int VencResetRateCtrlInfo(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pChnAttr);

AX_S32 VencCreateChn(AX_S32 VeChn, const AX_VENC_CHN_ATTR_S *pstAttr, AX_VOID *pCtx)
{
	AX_S32 s32Ret = -1;
	AX_AVCHEVC_HANDLE_S *pHandle;
    AX_VENC_CHN_ATTR_S *pstVencChnAttr = NULL;

	pHandle = (AX_AVCHEVC_HANDLE_S *)calloc(1, sizeof(AX_AVCHEVC_HANDLE_S));
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: create handle error.\n", VeChn);
		return AX_ERR_VENC_NOMEM;
	}

	default_parameter_new(pHandle);

	pHandle->VeChn = VeChn;
    pstVencChnAttr = &(((AX_VENC_CHN_INSTANCE_S *)pCtx)->stVencChnAttr);

	s32Ret = GetVencChnAttr(VeChn, pstAttr, pHandle, pstVencChnAttr);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: init channel attribute error. s32Ret:0x%x\n", VeChn, s32Ret);
		s32Ret = AX_ERR_VENC_ILLEGAL_PARAM;
        goto ERR_FERR_HANDLE;
	}

	/* Encoder initialization */
	s32Ret = OpenEncoderNew(&pHandle->vencInst, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: open encoder error. s32Ret:0x%x\n", VeChn, s32Ret);
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
        goto ERR_FERR_HANDLE;
	}

	s32Ret = AllocResNew(pHandle->vencInst, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: alloc res error. s32Ret:0x%x\n", VeChn, s32Ret);
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
        goto ERR_CLOSE_ENCODER;
	}

	s32Ret = VencEncodeHeader(pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: encode header err. s32Ret:0x%x\n", VeChn, s32Ret);
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
        goto ERR_CLOSE_ENCODER;
	}

	s32Ret = AllocSceneChangeRefbuf(pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: alloc scene change ref bug err. s32Ret:0x%x\n", VeChn, s32Ret);
		s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
		goto ERR_CLOSE_ENCODER;
	}

	pHandle->marginSizeScale = 5;

	((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx = pHandle;

	gAvcHevcHandle[VeChn] = pHandle;

	return AX_SUCCESS;

ERR_CLOSE_ENCODER:
    CloseEncoder(pHandle->vencInst, pHandle);
ERR_FERR_HANDLE:
    free(pHandle);
    return s32Ret;
}

AX_S32 VencDestroyChn(AX_VOID *pCtx)
{
	/* AX_S32 s32Ret; */

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

	VENC_CHN VencChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VencChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	VencEncodeEnd(pHandle);

	FreeSceneChangeRefbuf(pHandle);

	FreeRes(pHandle->vencInst, pHandle);  // not useful now? for AllocResNew seems not to alloc any mem.

	CloseEncoder(pHandle->vencInst, pHandle);

	free(pHandle);

	return AX_SUCCESS;
}

AX_S32 VencSendFrame(AX_VOID *pCtx, const AX_VIDEO_FRAME_INFO_S *pstFrame , AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstFrame) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencSendFrameEx(AX_VOID *pCtx, const AX_USER_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstFrame) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencGetStream(AX_VOID *pCtx, AX_VENC_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
	AX_S32 VeChn;

    if (NULL == pstStream) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencReleaseStream(AX_VOID *pCtx, const AX_VENC_STREAM_S *pstStream)
{
	AX_S32 VeChn;

    if (NULL == pstStream) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencStartRecvFrame(AX_VOID *pCtx, const AX_VENC_RECV_PIC_PARAM_S *pstRecvParam)
{
	AX_S32 VeChn;

    if (NULL == pstRecvParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencStopRecvFrame(AX_VOID *pCtx)
{
	AX_S32 VeChn;

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencSetOsdLayer(AX_VOID *pCtx, const AX_OSD_BMP_ATTR_S *pstOSDAttr)
{
	AX_S32 VeChn;

    if (NULL == pstOSDAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencRefreshOsdLayer(AX_VOID *pCtx, AX_U32 u32OsdIndex, AX_U8* pBitmap)
{
	AX_S32 VeChn;

    if (NULL == pBitmap) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencResetOsd(AX_VOID *pCtx)
{
	AX_S32 VeChn;

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

void LimitQpMinROIenable(AX_VOID *pCtx, VCEncCodingCtrl* pCodeParams)
{
	VCEncRet VencRet = 0;
	AX_S32 VeChn = 0;
	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;
	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	VencRet = VCEncGetCodingCtrl(pHandle->vencInst, pCodeParams);
	if (VCENC_OK != VencRet) {
		VLOG_ERROR("VencChn %d: venc get coding ctrl failed.\n", VeChn);
		return AX_ERR_VENC_ATTR_NOT_CFG;
	}

	if( pCodeParams->roi1Area.enable !=0 || pCodeParams->roi2Area.enable !=0 || pCodeParams->roi3Area.enable !=0 || pCodeParams->roi4Area.enable !=0
		  || pCodeParams->roi5Area.enable !=0 || pCodeParams->roi6Area.enable !=0 || pCodeParams->roi7Area.enable !=0 || pCodeParams->roi8Area.enable !=0)
	{
		pHandle->qpMin = ROI_LIMIT_MINQP;
		pHandle->qpMinI = ROI_LIMIT_MINQP;
	}

	return;
}

AX_S32 VencSetRoiAttr(AX_VOID *pCtx, const AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
	VCEncRet VencRet;
	AX_S32 s32Ret = -1;
	AX_S32 VeChn;
	/* coding ctrl */
	VCEncCodingCtrl codingCfg;
	//transfer actual width and height to area index
	VENC_ROI_MB_AREA_T stRoiArea;

    if (NULL == pstRoiAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	s32Ret = VencRoiAttrCheck(VeChn, pstRoiAttr, pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: Invalid ROI Attribute.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

    if (!pstRoiAttr->bEnable && !pHandle->stRoiAttr[pstRoiAttr->u32Index].bEnable) {
        return AX_SUCCESS;
    }

	//transfer user area to index for encoder inner use.
	//align down pixel, for ctb index start from 0. (0 ~ n-1)
	if (VCENC_VIDEO_CODEC_H264 == pHandle->codecFormat) {
		stRoiArea.u32LeftMbs = pstRoiAttr->stRoiArea.u32X / 16;
		stRoiArea.u32TopMbs = pstRoiAttr->stRoiArea.u32Y / 16;

		stRoiArea.u32RightMbs = (ALIGN_UP((pstRoiAttr->stRoiArea.u32X + pstRoiAttr->stRoiArea.u32Width), 16) - 16) / 16;
		stRoiArea.u32BottomMbs = (ALIGN_UP((pstRoiAttr->stRoiArea.u32Y + pstRoiAttr->stRoiArea.u32Height), 16) - 16) / 16;
	} else if (VCENC_VIDEO_CODEC_HEVC == pHandle->codecFormat) {
		stRoiArea.u32LeftMbs = pstRoiAttr->stRoiArea.u32X / 64;
		stRoiArea.u32TopMbs = pstRoiAttr->stRoiArea.u32Y / 64;

		stRoiArea.u32RightMbs = (ALIGN_UP((pstRoiAttr->stRoiArea.u32X + pstRoiAttr->stRoiArea.u32Width), 64) - 64) / 64;
		stRoiArea.u32BottomMbs = (ALIGN_UP((pstRoiAttr->stRoiArea.u32Y + pstRoiAttr->stRoiArea.u32Height), 64) - 64) / 64;
	} else {
		VLOG_ERROR("VencChn %d: invalid codec format %d\n", VeChn, pHandle->codecFormat);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	//transfer actual width and height to ROI index, ROI area index check
	if ((16 != pHandle->max_cu_size) && (64 != pHandle->max_cu_size)) {
		VLOG_ERROR("VencChn %d: invalid max cu size %d.\n", VeChn, pHandle->max_cu_size);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	i32 w = (pHandle->width + pHandle->max_cu_size - 1) / pHandle->max_cu_size;
	i32 h = (pHandle->height + pHandle->max_cu_size - 1) / pHandle->max_cu_size;

	if ((stRoiArea.u32LeftMbs > (u32)w) || (stRoiArea.u32RightMbs > (u32)w) ||
	(stRoiArea.u32TopMbs > (u32)h) || (stRoiArea.u32BottomMbs > (u32)h))
	{
		VLOG_ERROR("VencChn %d: Invalid ROI Area: Top:%d, Bottom:%d, Left:%d, Right:%d.\n",
				VeChn,
				stRoiArea.u32TopMbs,
				stRoiArea.u32BottomMbs,
				stRoiArea.u32LeftMbs,
				stRoiArea.u32RightMbs);

		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	LimitQpMinROIenable(pCtx, &codingCfg);

	VencRoiAttrSetting(VeChn, pstRoiAttr, &stRoiArea, &codingCfg);

	//print info of roi enabled
	VencRoiAttrPrint(VeChn, &codingCfg);

	VencRet = VCEncSetCodingCtrlRoi(pHandle->vencInst, &codingCfg);
	if (VCENC_OK != VencRet) {
		VLOG_ERROR("VencChn %d: VCEncSetCodingCtrl() failed.\n", VeChn);
		return AX_ERR_VENC_ATTR_NOT_CFG;
	}

	memcpy(&pHandle->stRoiAttr[pstRoiAttr->u32Index], pstRoiAttr, sizeof(AX_VENC_ROI_ATTR_S));

	return AX_SUCCESS;
}

AX_S32 VencGetRoiAttr(AX_VOID *pCtx, AX_U32 u32Index, AX_VENC_ROI_ATTR_S *pstRoiAttr)
{
    AX_S32 VeChn;
    if (NULL == pstRoiAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	memcpy(pstRoiAttr, &pHandle->stRoiAttr[u32Index], sizeof(AX_VENC_ROI_ATTR_S));

	return AX_SUCCESS;
}

AX_S32 VencSetRcParam(AX_VOID *pCtx, const AX_VENC_RC_PARAM_S *pstRcParam)
{
	VCEncRet vencRet;
	VCEncRateCtrl rcCfg;
	VCEncCodingCtrl codingCfg;
	AX_S32 VeChn;
	AX_S32 s32Ret = -1;
    AX_VENC_CHN_ATTR_S *pstVencChnAttr = NULL;

    if (NULL == pstRcParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	pstVencChnAttr = &(((AX_VENC_CHN_INSTANCE_S *)pCtx)->stVencChnAttr);

	if (pstVencChnAttr->stRcAttr.enRcMode != pstRcParam->enRcMode) {
		VLOG_ERROR("VencChn %d: setRcParam, Invalid enRcMode(%d),which is inconsistent with the enRcMode(%d) of stRcAttr.\n", \
			VeChn,pstRcParam->enRcMode,pstVencChnAttr->stRcAttr.enRcMode);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	VeChn = pHandle->VeChn;
	rcCfg = pHandle->rcCfg;

	s32Ret = VencRcParamCheck(pHandle, pstRcParam);
	if (AX_SUCCESS != s32Ret) {
		VLOG_ERROR("VencChn %d: setRcParam, Invalid Rc Params.\n", VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	switch (pHandle->codecFormat)
	{
	case VCENC_VIDEO_CODEC_HEVC:
	{
		if (VENC_RC_MODE_H265CBR == pHandle->enRcMode) {
			rcCfg.vbr = 0;

			rcCfg.qpMinI = pstRcParam->stH265Cbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH265Cbr.u32MaxIQp;
			rcCfg.ctbRc = VCENC_CTBRC_TARRC;
			rcCfg.qpMinPB = pstRcParam->stH265Cbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH265Cbr.u32MaxQp;
			LimitQpMinROIenable(pCtx, &codingCfg);
			rcCfg.bitPerSecond = pstRcParam->stH265Cbr.u32BitRate * VENC_BITRATE_RATIO;
            pHandle->inputRateNumer = pstRcParam->stH265Cbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH265Cbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH265Cbr.u32SrcFrameRate = pstRcParam->stH265Cbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH265Cbr.fr32DstFrameRate = pstRcParam->stH265Cbr.fr32DstFrameRate;
			if (pstRcParam->stH265Cbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH265Cbr.fr32DstFrameRate;
			}
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH265Cbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;
			if (pstRcParam->stH265Cbr.u32MaxIprop && pstRcParam->stH265Cbr.u32MaxIprop <= 100) {
				rcCfg.IpropMax = pstRcParam->stH265Cbr.u32MaxIprop;
				pHandle->stH265Cbr.u32MaxIprop = pstRcParam->stH265Cbr.u32MaxIprop;
			}
			if (pstRcParam->stH265Cbr.u32MinIprop && pstRcParam->stH265Cbr.u32MinIprop <= rcCfg.IpropMax) {
				rcCfg.IpropMin = pstRcParam->stH265Cbr.u32MinIprop;
				pHandle->stH265Cbr.u32MinIprop = pstRcParam->stH265Cbr.u32MinIprop;
			}
			if (pstRcParam->stH265Cbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH265Cbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH265Cbr.s32IntraQpDelta;
			}

            if(pstRcParam->stH265Cbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH265Cbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH265Cbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH265Cbr.u32IdrDeltaRange = pstRcParam->stH265Cbr.u32IdrDeltaRange;
            }
		} else if (VENC_RC_MODE_H265VBR == pHandle->enRcMode) {
			rcCfg.bitPerSecond = pstRcParam->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH265Vbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

			rcCfg.vbr = 1;

			rcCfg.qpMinI = pstRcParam->stH265Vbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH265Vbr.u32MaxIQp;

			rcCfg.qpMinPB = pstRcParam->stH265Vbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH265Vbr.u32MaxQp;

            pHandle->inputRateNumer = pstRcParam->stH265Vbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH265Vbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH265Vbr.u32SrcFrameRate = pstRcParam->stH265Vbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH265Vbr.fr32DstFrameRate = pstRcParam->stH265Vbr.fr32DstFrameRate;
			if (pstRcParam->stH265Vbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH265Vbr.fr32DstFrameRate;
			}
			if (pstRcParam->stH265Vbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH265Vbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH265Vbr.s32IntraQpDelta;
			}

            if(pstRcParam->stH265Vbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH265Vbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH265Vbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH265Vbr.u32IdrDeltaRange = pstRcParam->stH265Vbr.u32IdrDeltaRange;
            }

			rcCfg.pictureRc = 1;
			rcCfg.crf = 0;
			rcCfg.hrd = 0;
			rcCfg.hrdCpbSize = 2 * (pstRcParam->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO);
		}
		else if (VENC_RC_MODE_H265AVBR == pHandle->enRcMode) {
			rcCfg.bitPerSecond = pstRcParam->stH265AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH265AVbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

			rcCfg.vbr = 1;

			rcCfg.qpMinI = pstRcParam->stH265AVbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH265AVbr.u32MaxIQp;

			rcCfg.qpMinPB = pstRcParam->stH265AVbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH265AVbr.u32MaxQp;

            pHandle->inputRateNumer = pstRcParam->stH265AVbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH265AVbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH265AVbr.u32SrcFrameRate = pstRcParam->stH265AVbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH265AVbr.fr32DstFrameRate = pstRcParam->stH265AVbr.fr32DstFrameRate;
			if (pstRcParam->stH265AVbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH265AVbr.fr32DstFrameRate;
			}
			if (pstRcParam->stH265AVbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH265AVbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH265AVbr.s32IntraQpDelta;
			}

            if(pstRcParam->stH265AVbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH265AVbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH265AVbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH265AVbr.u32IdrDeltaRange = pstRcParam->stH265AVbr.u32IdrDeltaRange;
            }

			rcCfg.pictureRc = 1;
			rcCfg.crf = 0;
			rcCfg.hrd = 0;
			rcCfg.hrdCpbSize = 2 * (pstRcParam->stH265AVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
		}
        else if (VENC_RC_MODE_H265CVBR == pHandle->enRcMode) {
            rcCfg.bitPerSecond = pstRcParam->stH265CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;
           pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH265CVbr.u32Gop;

           rcCfg.vbr = 0;

           rcCfg.qpMinI = pstRcParam->stH265CVbr.u32MinIQp;
           rcCfg.qpMaxI = pstRcParam->stH265CVbr.u32MaxIQp;

            if (pstRcParam->stH265CVbr.s32IntraQpDelta != pHandle->intraQpDelta) {
               rcCfg.intraQpDelta = pstRcParam->stH265CVbr.s32IntraQpDelta;
               pHandle->intraQpDelta = pstRcParam->stH265CVbr.s32IntraQpDelta;
           }

           rcCfg.qpMinPB = pstRcParam->stH265CVbr.u32MinQp;
           rcCfg.qpMaxPB = pstRcParam->stH265CVbr.u32MaxQp;
            rcCfg.u32MaxBitRate = pstRcParam->stH265CVbr.u32MaxBitRate;
            rcCfg.u32ShortTermStatTime = pstRcParam->stH265CVbr.u32ShortTermStatTime;
            rcCfg.u32LongTermStatTime = pstRcParam->stH265CVbr.u32LongTermStatTime;

            rcCfg.u32LongTermMaxBitrate = pstRcParam->stH265CVbr.u32LongTermMaxBitrate;
            rcCfg.u32LongTermMinBitrate = pstRcParam->stH265CVbr.u32LongTermMinBitrate;

            rcCfg.u32ExtraBitPercent = pstRcParam->stH265CVbr.u32ExtraBitPercent;
            rcCfg.u32LongTermStatTimeUnit = pstRcParam->stH265CVbr.u32LongTermStatTimeUnit;

           pHandle->inputRateNumer = pstRcParam->stH265CVbr.u32SrcFrameRate;
           pHandle->outputRateNumer = pstRcParam->stH265CVbr.fr32DstFrameRate;
           pstVencChnAttr->stRcAttr.stH265CVbr.u32SrcFrameRate = pstRcParam->stH265CVbr.u32SrcFrameRate;
           pstVencChnAttr->stRcAttr.stH265CVbr.fr32DstFrameRate = pstRcParam->stH265CVbr.fr32DstFrameRate;
           if (pstRcParam->stH265CVbr.fr32DstFrameRate) {
               rcCfg.frameRateNum = pstRcParam->stH265CVbr.fr32DstFrameRate;
           }

           if(pstRcParam->stH265CVbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH265CVbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH265CVbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH265CVbr.u32IdrDeltaRange = pstRcParam->stH265CVbr.u32IdrDeltaRange;
            }

            pstVencChnAttr->stRcAttr.stH265CVbr.u32MaxBitRate = pstRcParam->stH265CVbr.u32MaxBitRate;
            pstVencChnAttr->stRcAttr.stH265CVbr.u32ShortTermStatTime = pstRcParam->stH265CVbr.u32ShortTermStatTime;
            pstVencChnAttr->stRcAttr.stH265CVbr.u32LongTermStatTime = pstRcParam->stH265CVbr.u32LongTermStatTime;
            pstVencChnAttr->stRcAttr.stH265CVbr.u32LongTermMaxBitrate = pstRcParam->stH265CVbr.u32LongTermMaxBitrate;
            pstVencChnAttr->stRcAttr.stH265CVbr.u32LongTermMinBitrate = pstRcParam->stH265CVbr.u32LongTermMinBitrate;

           rcCfg.pictureRc = 1;
           rcCfg.crf = 0;
           rcCfg.hrd = 0;
           rcCfg.hrdCpbSize = 2 * (pstRcParam->stH265CVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
           pstVencChnAttr->stRcAttr.stH265CVbr.stQpmapInfo.enCtbRcMode = pstRcParam->stH265CVbr.stQpmapInfo.enCtbRcMode;
           pstVencChnAttr->stRcAttr.stH265CVbr.stQpmapInfo.enQpmapQpType = pstRcParam->stH265CVbr.stQpmapInfo.enQpmapQpType;
           pstVencChnAttr->stRcAttr.stH265CVbr.stQpmapInfo.u32QpmapBlockUnit = pstRcParam->stH265CVbr.stQpmapInfo.u32QpmapBlockUnit;

        }
		else if (VENC_RC_MODE_H265FIXQP == pHandle->enRcMode) {
            pHandle->inputRateNumer = pstRcParam->stH265FixQp.u32SrcFrameRate;
            pHandle->inputRateDenom = 1;
            pHandle->outputRateNumer = pstRcParam->stH265FixQp.fr32DstFrameRate;
            pHandle->outputRateDenom = 1;
            pstVencChnAttr->stRcAttr.stH265FixQp.u32SrcFrameRate = pstRcParam->stH265FixQp.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH265FixQp.fr32DstFrameRate = pstRcParam->stH265FixQp.fr32DstFrameRate;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH265FixQp.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;
            if (pstRcParam->stH265FixQp.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH265FixQp.fr32DstFrameRate;
			}
			rcCfg.hrdCpbSize = 2 * (pstRcParam->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO);
            rcCfg.fixedIntraQp = pstRcParam->stH265FixQp.u32IQp; //fix qp for I slice
            rcCfg.qpHdr = pstRcParam->stH265FixQp.u32PQp;
            if (pHandle->stH265FixQp.u32PQp < pHandle->stH265FixQp.u32BQp)
            pHandle->bFrameQpDelta = pstRcParam->stH265FixQp.u32BQp - pstRcParam->stH265FixQp.u32PQp;
            else
            pHandle->bFrameQpDelta = pstRcParam->stH265FixQp.u32PQp - pstRcParam->stH265FixQp.u32BQp;


		} else if (VENC_RC_MODE_H265QPMAP == pHandle->enRcMode) {

        rcCfg.vbr = 1;
        pHandle->picRc = 1;
        pHandle->inputRateNumer = pstRcParam->stH265QpMap.u32SrcFrameRate;
        pHandle->inputRateDenom = 1;
        pHandle->outputRateNumer = pstRcParam->stH265QpMap.fr32DstFrameRate;
        pHandle->outputRateDenom = 1;
        pstVencChnAttr->stRcAttr.stH265QpMap.u32SrcFrameRate = pstRcParam->stH265QpMap.u32SrcFrameRate;
        pstVencChnAttr->stRcAttr.stH265QpMap.fr32DstFrameRate = pstRcParam->stH265QpMap.fr32DstFrameRate;
        pHandle->intraPicRate = pstRcParam->stH265QpMap.u32Gop;
        rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;
        pHandle->bitPerSecond = pstRcParam->stH265QpMap.u32TargetBitRate;

        pHandle->ctbRc = VCENC_CTBRC_SUBQ;
        pHandle->qpHdr = pstRcParam->s32FirstFrameStartQp;



        if (VENC_QPMAP_ENABLE_DELTAQP == pstRcParam->stH265QpMap.enQpmapQpType) {
          pHandle->roiMapDeltaQpEnable = 1;
          pHandle->ctbRc = pstRcParam->stH265QpMap.enCtbRcMode;
        } else if (VENC_QPMAP_ENABLE_ABSQP == pstRcParam->stH265QpMap.enQpmapQpType) { //enable absolute qpmap mode
          pHandle->roiMapDeltaQpEnable = 1;
          pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
        } else if (VENC_QPMAP_ENABLE_IPCM == pstRcParam->stH265QpMap.enQpmapQpType) { //enable ipcm qpmap mode
          pHandle->ipcmMapEnable = 1;
          pHandle->ctbRc = pstRcParam->stH265QpMap.enCtbRcMode;
        } else {
          VLOG_ERROR("VENC %d: h265 Invalid qpmap qp type = %d.\n", pHandle->VeChn, pHandle->stH265QpMap.enQpmapQpType);
        }

        pHandle->roiMapDeltaQpBlockUnit = pstRcParam->stH265QpMap.u32QpmapBlockUnit;


		} else {
			VLOG_ERROR("VencChn %d: Invalid Rc mode (%d).\n", VeChn, pHandle->enRcMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;
	}
	case VCENC_VIDEO_CODEC_H264:
	{
		if (VENC_RC_MODE_H264CBR == pHandle->enRcMode) {
			rcCfg.bitPerSecond = pstRcParam->stH264Cbr.u32BitRate * VENC_BITRATE_RATIO;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH264Cbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

			rcCfg.vbr = 0;

			rcCfg.qpMinI = pstRcParam->stH264Cbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH264Cbr.u32MaxIQp;

			rcCfg.qpMinPB = pstRcParam->stH264Cbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH264Cbr.u32MaxQp;
			rcCfg.ctbRc = VCENC_CTBRC_AVG;
			LimitQpMinROIenable(pCtx, &codingCfg);
			pHandle->inputRateNumer = pstRcParam->stH264Cbr.u32SrcFrameRate;
			pHandle->outputRateNumer = pstRcParam->stH264Cbr.fr32DstFrameRate;
			pstVencChnAttr->stRcAttr.stH264Cbr.u32SrcFrameRate = pstRcParam->stH264Cbr.u32SrcFrameRate;
			pstVencChnAttr->stRcAttr.stH264Cbr.fr32DstFrameRate = pstRcParam->stH264Cbr.fr32DstFrameRate;
			if (pstRcParam->stH264Cbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH264Cbr.fr32DstFrameRate;
			}
			if (pstRcParam->stH264Cbr.u32MaxIprop && pstRcParam->stH264Cbr.u32MaxIprop <= 100) {
				rcCfg.IpropMax = pstRcParam->stH264Cbr.u32MaxIprop;
				pHandle->stH264Cbr.u32MaxIprop = pstRcParam->stH264Cbr.u32MaxIprop;
			}
			if (pstRcParam->stH264Cbr.u32MinIprop && pstRcParam->stH264Cbr.u32MinIprop <= rcCfg.IpropMax) {
				rcCfg.IpropMin = pstRcParam->stH264Cbr.u32MinIprop;
				pHandle->stH264Cbr.u32MinIprop = pstRcParam->stH264Cbr.u32MinIprop;
			}
			if (pstRcParam->stH264Cbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH264Cbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH264Cbr.s32IntraQpDelta;
			}
            if(pstRcParam->stH264Cbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH264Cbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH264Cbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH264Cbr.u32IdrDeltaRange = pstRcParam->stH264Cbr.u32IdrDeltaRange;
            }
		} else if (VENC_RC_MODE_H264VBR == pHandle->enRcMode) {
			rcCfg.bitPerSecond = pstRcParam->stH264Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH264Vbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

			rcCfg.vbr = 1;

			rcCfg.qpMinI = pstRcParam->stH264Vbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH264Vbr.u32MaxIQp;

			rcCfg.qpMinPB = pstRcParam->stH264Vbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH264Vbr.u32MaxQp;
            pHandle->inputRateNumer = pstRcParam->stH264Vbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH264Vbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH264Vbr.u32SrcFrameRate = pstRcParam->stH264Vbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH264Vbr.fr32DstFrameRate = pstRcParam->stH264Vbr.fr32DstFrameRate;
			if (pstRcParam->stH264Vbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH264Vbr.fr32DstFrameRate;
			}
			if (pstRcParam->stH264Vbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH264Vbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH264Vbr.s32IntraQpDelta;
			}

            if(pstRcParam->stH264Vbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH264Vbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH264Vbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH264Vbr.u32IdrDeltaRange = pstRcParam->stH264Vbr.u32IdrDeltaRange;
            }

			rcCfg.pictureRc = 1;
			rcCfg.crf = 0;
			rcCfg.hrd = 0;
			rcCfg.hrdCpbSize = 2 * (pstRcParam->stH264Vbr.u32MaxBitRate * VENC_BITRATE_RATIO);
		}
		else if (VENC_RC_MODE_H264AVBR == pHandle->enRcMode) {
			rcCfg.bitPerSecond = pstRcParam->stH264AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH264AVbr.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

			rcCfg.vbr = 1;

			rcCfg.qpMinI = pstRcParam->stH264AVbr.u32MinIQp;
			rcCfg.qpMaxI = pstRcParam->stH264AVbr.u32MaxIQp;

			rcCfg.qpMinPB = pstRcParam->stH264AVbr.u32MinQp;
			rcCfg.qpMaxPB = pstRcParam->stH264AVbr.u32MaxQp;
            pHandle->inputRateNumer = pstRcParam->stH264AVbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH264AVbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH264AVbr.u32SrcFrameRate = pstRcParam->stH264AVbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH264AVbr.fr32DstFrameRate = pstRcParam->stH264AVbr.fr32DstFrameRate;
			if (pstRcParam->stH264AVbr.fr32DstFrameRate) {
				rcCfg.frameRateNum = pstRcParam->stH264AVbr.fr32DstFrameRate;
			}
			if (pstRcParam->stH264AVbr.s32IntraQpDelta != pHandle->intraQpDelta) {
				rcCfg.intraQpDelta = pstRcParam->stH264AVbr.s32IntraQpDelta;
				pHandle->intraQpDelta = pstRcParam->stH264AVbr.s32IntraQpDelta;
			}
            if(pstRcParam->stH264AVbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH264AVbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH264AVbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH264AVbr.u32IdrDeltaRange = pstRcParam->stH264AVbr.u32IdrDeltaRange;
            }

			rcCfg.pictureRc = 1;
			rcCfg.crf = 0;
			rcCfg.hrd = 0;
			rcCfg.hrdCpbSize = 2 * (pstRcParam->stH264AVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
		}
        else if (VENC_RC_MODE_H264CVBR == pHandle->enRcMode) {
            rcCfg.bitPerSecond = pstRcParam->stH264CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;
            pHandle->encIn.gopConfig.idr_interval = pstRcParam->stH264CVbr.u32Gop;

            rcCfg.vbr = 0;

            rcCfg.qpMinI = pstRcParam->stH264CVbr.u32MinIQp;
            rcCfg.qpMaxI = pstRcParam->stH264CVbr.u32MaxIQp;

            rcCfg.qpMinPB = pstRcParam->stH264CVbr.u32MinQp;
            rcCfg.qpMaxPB = pstRcParam->stH264CVbr.u32MaxQp;
            if (pstRcParam->stH264CVbr.s32IntraQpDelta != pHandle->intraQpDelta) {
                rcCfg.intraQpDelta = pstRcParam->stH264CVbr.s32IntraQpDelta;
                pHandle->intraQpDelta = pstRcParam->stH264CVbr.s32IntraQpDelta;
            }
            rcCfg.u32MaxBitRate = pstRcParam->stH264CVbr.u32MaxBitRate;
            rcCfg.u32ShortTermStatTime = pstRcParam->stH264CVbr.u32ShortTermStatTime;
            rcCfg.u32LongTermStatTime = pstRcParam->stH264CVbr.u32LongTermStatTime;
            rcCfg.u32LongTermMaxBitrate = pstRcParam->stH264CVbr.u32LongTermMaxBitrate;
            rcCfg.u32LongTermMinBitrate = pstRcParam->stH264CVbr.u32LongTermMinBitrate;

            rcCfg.u32ExtraBitPercent = pstRcParam->stH264CVbr.u32ExtraBitPercent;
            rcCfg.u32LongTermStatTimeUnit = pstRcParam->stH264CVbr.u32LongTermStatTimeUnit;
            pHandle->inputRateNumer = pstRcParam->stH264CVbr.u32SrcFrameRate;
            pHandle->outputRateNumer = pstRcParam->stH264CVbr.fr32DstFrameRate;
            pstVencChnAttr->stRcAttr.stH264CVbr.u32SrcFrameRate = pstRcParam->stH264CVbr.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH264CVbr.fr32DstFrameRate = pstRcParam->stH264CVbr.fr32DstFrameRate;
            if (pstRcParam->stH264CVbr.fr32DstFrameRate) {
                rcCfg.frameRateNum = pstRcParam->stH264CVbr.fr32DstFrameRate;
            }
            if(pstRcParam->stH264CVbr.u32IdrDeltaRange != pHandle->idrDeltaRange)
            {
                rcCfg.idrDeltaRange = pstRcParam->stH264CVbr.u32IdrDeltaRange;
                pHandle->idrDeltaRange = pstRcParam->stH264CVbr.u32IdrDeltaRange;
                pstVencChnAttr->stRcAttr.stH264CVbr.u32IdrDeltaRange = pstRcParam->stH264CVbr.u32IdrDeltaRange;
            }

            pstVencChnAttr->stRcAttr.stH264CVbr.u32MaxBitRate = pstRcParam->stH264CVbr.u32MaxBitRate;
            pstVencChnAttr->stRcAttr.stH264CVbr.u32ShortTermStatTime = pstRcParam->stH264CVbr.u32ShortTermStatTime;
            pstVencChnAttr->stRcAttr.stH264CVbr.u32LongTermStatTime = pstRcParam->stH264CVbr.u32LongTermStatTime;
            pstVencChnAttr->stRcAttr.stH264CVbr.u32LongTermMaxBitrate = pstRcParam->stH264CVbr.u32LongTermMaxBitrate;
            pstVencChnAttr->stRcAttr.stH264CVbr.u32LongTermMinBitrate = pstRcParam->stH264CVbr.u32LongTermMinBitrate;

            rcCfg.pictureRc = 1;
            rcCfg.crf = 0;
            rcCfg.hrd = 0;
            rcCfg.hrdCpbSize = 2 * (pstRcParam->stH264CVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
            pstVencChnAttr->stRcAttr.stH264CVbr.stQpmapInfo.enCtbRcMode = pstRcParam->stH264CVbr.stQpmapInfo.enCtbRcMode;
            pstVencChnAttr->stRcAttr.stH264CVbr.stQpmapInfo.enQpmapQpType = pstRcParam->stH264CVbr.stQpmapInfo.enQpmapQpType;
            pstVencChnAttr->stRcAttr.stH264CVbr.stQpmapInfo.u32QpmapBlockUnit = pstRcParam->stH264CVbr.stQpmapInfo.u32QpmapBlockUnit;

       }
        else if (VENC_RC_MODE_H264FIXQP == pHandle->enRcMode) {

            pHandle->inputRateNumer = pstRcParam->stH264FixQp.u32SrcFrameRate;
            pHandle->inputRateDenom = 1;
            pHandle->outputRateNumer = pstRcParam->stH264FixQp.fr32DstFrameRate;
            pHandle->outputRateDenom = 1;
            pHandle->intraPicRate = pstRcParam->stH264FixQp.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;

            pstVencChnAttr->stRcAttr.stH264FixQp.u32SrcFrameRate = pstRcParam->stH264FixQp.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH264FixQp.fr32DstFrameRate = pstRcParam->stH264FixQp.fr32DstFrameRate;
            pHandle->fixedIntraQp = pstRcParam->stH264FixQp.u32IQp; //fix qp for I slice
            rcCfg.qpHdr = pstRcParam->stH264FixQp.u32PQp;
            if (pstRcParam->stH264FixQp.u32PQp < pstRcParam->stH264FixQp.u32BQp)
                pHandle->bFrameQpDelta = pstRcParam->stH264FixQp.u32BQp - pstRcParam->stH264FixQp.u32PQp;
            else
                pHandle->bFrameQpDelta = pstRcParam->stH264FixQp.u32PQp - pstRcParam->stH264FixQp.u32BQp;
		}
        else if (VENC_RC_MODE_H264QPMAP == pHandle->enRcMode) {

            rcCfg.vbr = 1;
            rcCfg.pictureRc = 1;
            pHandle->inputRateNumer = pstRcParam->stH264QpMap.u32SrcFrameRate;
            pHandle->inputRateDenom = 1;
            pHandle->outputRateNumer = pstRcParam->stH264QpMap.fr32DstFrameRate;
            pHandle->outputRateDenom = 1;
            pstVencChnAttr->stRcAttr.stH264QpMap.u32SrcFrameRate = pstRcParam->stH264QpMap.u32SrcFrameRate;
            pstVencChnAttr->stRcAttr.stH264QpMap.fr32DstFrameRate = pstRcParam->stH264QpMap.fr32DstFrameRate;
            pHandle->intraPicRate = pstRcParam->stH264QpMap.u32Gop;
            rcCfg.GopSize = pstRcParam->stH265Cbr.u32Gop;
            pHandle->bitPerSecond = pstRcParam->stH264QpMap.u32TargetBitRate;
            pHandle->ctbRc = VCENC_CTBRC_SUBQ;

            rcCfg.qpHdr = pstRcParam->s32FirstFrameStartQp;
            /* enable qpDelta qpmap mode */
            if (VENC_QPMAP_ENABLE_DELTAQP == pstRcParam->stH264QpMap.enQpmapQpType) {
            pHandle->roiMapDeltaQpEnable = 1;
            pHandle->ctbRc = pstRcParam->stH264QpMap.enCtbRcMode;
            } else if (VENC_QPMAP_ENABLE_ABSQP == pstRcParam->stH264QpMap.enQpmapQpType) { //enable absolute qpmap mode
            pHandle->roiMapDeltaQpEnable = 1;
            pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
            } else if (VENC_QPMAP_ENABLE_IPCM == pstRcParam->stH264QpMap.enQpmapQpType) { //enable ipcm qpmap mode
            pHandle->ipcmMapEnable = 1;
            pHandle->ctbRc = pstRcParam->stH264QpMap.enCtbRcMode;
            } else {
            VLOG_ERROR("VENC %d: h264 Invalid qpmap qp type = %d.\n", pHandle->VeChn, pstRcParam->stH264QpMap.enQpmapQpType);
            }

            pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264QpMap.u32QpmapBlockUnit;
		} else {
			VLOG_ERROR("VencChn %d: setRcParam, Invalid Rc mode (%d).\n", VeChn, pHandle->enRcMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;
	}
	default:
		VLOG_ERROR("VencChn %d: setRcParam, Invalid CodecFormat(%d).\n", VeChn, pHandle->codecFormat);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstRcParam->stSceneChangeDetect.bDetectSceneChange) {
		pHandle->sceneChangeEnable = true;
	} else {
		pHandle->sceneChangeEnable = false;
	}

	vencRet = VCEncSetRateCtrl(pHandle->vencInst, &rcCfg);
	if (VCENC_OK != vencRet) {
		VLOG_ERROR("VencChn %d: setRcParam, setRateCtrl failed.\n", VeChn);
		return AX_ERR_VENC_NOT_PERMIT;
	}

	//backup rc settings (possibly) trimmed by VS HAL driver
	pHandle->rcCfg = rcCfg;

	//backup original rc settings from user interface (not trimmed)
	memcpy(&pHandle->stRcParam, pstRcParam, sizeof(AX_VENC_RC_PARAM_S));

	VLOG_DEBUG("VencChn %d: setRcParam, vbr %d qp %2d qpRange I[%2d, %2d] PB[%2d, %2d] %9d bps  "
		"pic %d skip %d  hrd %d"
		"  cpbSize %d bitrateWindow %d intraQpDelta %2d "
		"fixedIntraQp %2d, idr length=%d.\n",
		VeChn,
		rcCfg.vbr,
		rcCfg.qpHdr,
		rcCfg.qpMinI, rcCfg.qpMaxI, rcCfg.qpMinPB, rcCfg.qpMaxPB,
		rcCfg.bitPerSecond,
		rcCfg.pictureRc,
		rcCfg.pictureSkip,
		rcCfg.hrd,
		rcCfg.hrdCpbSize,
		rcCfg.bitrateWindow,
		rcCfg.intraQpDelta,
		rcCfg.fixedIntraQp,
		pHandle->encIn.gopConfig.idr_interval);

	return AX_SUCCESS;
}

AX_S32 VencGetRcParam(AX_VOID *pCtx, AX_VENC_RC_PARAM_S *pstRcParam)
{
    AX_S32 VeChn;
    if (NULL == pstRcParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	memcpy(pstRcParam, &pHandle->stRcParam, sizeof(AX_VENC_RC_PARAM_S));

	return AX_SUCCESS;
}

static int VencChannelDyamicAttrCheck(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pChnAttr)
{
	AX_S32 s32Ret = -1;
    AX_S32 VeChn;

    if (NULL == pChnAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	s32Ret = VencChnAttrCheck(pHandle->VeChn, pChnAttr);
	if (AX_SUCCESS != s32Ret)
	{
		VLOG_ERROR("VencChn %d: Invalid channel attribute.\n", pHandle->VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pChnAttr->stVencAttr.u32PicWidthSrc > pHandle->maxPicWidth ||
		pChnAttr->stVencAttr.u32PicHeightSrc > pHandle->maxPicHeight)
	{
		VLOG_ERROR("VencChn %d: attribute u32PicWidthSrc/u32PicHeightSrc invalid.\n", pHandle->VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	return AX_SUCCESS;
}

static int VencResetRateCtrlInfo(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	if (NULL == pCtx || NULL == pstChnAttr)
    {
		VLOG_ERROR("Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}
	AX_S32 VeChn;
	VCEncCodingCtrl codingCfg;
	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	switch (pstChnAttr->stVencAttr.enType)
	{
		case PT_H265:
		{
			if (VENC_RC_MODE_H265CBR == pstChnAttr->stRcAttr.enRcMode)
			{
				memcpy(&pHandle->stH265Cbr, &pstChnAttr->stRcAttr.stH265Cbr, sizeof(AX_VENC_H265_CBR_S));
				pHandle->vbr = 0;
				pHandle->inputRateNumer = pHandle->stH265Cbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH265Cbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH265Cbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH265Cbr.u32BitRate * VENC_BITRATE_RATIO;
				pHandle->enRcMode = VENC_RC_MODE_H265CBR;
				/* quality control */
				pHandle->ctbRc = VCENC_CTBRC_TARRC;
				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;
				pHandle->qpMin = pHandle->stH265Cbr.u32MinQp;
				pHandle->qpMax = pHandle->stH265Cbr.u32MaxQp;
				pHandle->qpMinI = pHandle->stH265Cbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH265Cbr.u32MaxIQp;

				LimitQpMinROIenable(pCtx, &codingCfg);
				if (pHandle->stH265Cbr.u32MaxIprop && pHandle->stH265Cbr.u32MaxIprop <= MAX_I_PROP) {
					pHandle->IpropMax = pHandle->stH265Cbr.u32MaxIprop;
				} else {
					pHandle->IpropMax = 40;
					pHandle->stH265Cbr.u32MaxIprop = 40;
				}
				if (pHandle->stH265Cbr.u32MinIprop && pHandle->stH265Cbr.u32MinIprop <= pHandle->IpropMax) {
					pHandle->IpropMin = pHandle->stH265Cbr.u32MinIprop;
				} else {
					pHandle->IpropMin = 10;
					pHandle->stH265Cbr.u32MinIprop = 10;
				}
                if(pHandle->stH265Cbr.u32IdrDeltaRange && pHandle->stH265Cbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH265Cbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_CBR;
                     pHandle->stH265Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
                }
				pHandle->intraQpDelta = pHandle->stH265Cbr.s32IntraQpDelta;
				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265Cbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH265Cbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h265 Cbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h265 Cbr Invalid qpmap qp type = %d.\n",
						pHandle->VeChn, pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType);
				}
				memcpy(&pHandle->stRcParam.stH265Cbr, &pstChnAttr->stRcAttr.stH265Cbr, sizeof(AX_VENC_H265_CBR_S));
			} else if (VENC_RC_MODE_H265VBR == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH265Vbr, &pstChnAttr->stRcAttr.stH265Vbr, sizeof(AX_VENC_H265_VBR_S));
				pHandle->vbr = 1;
				pHandle->inputRateNumer = pHandle->stH265Vbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH265Vbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH265Vbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;
				pHandle->enRcMode = VENC_RC_MODE_H265VBR;
				/*RC param*/
				pHandle->ctbRc = VCENC_CTBRC_AVG;
				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;
				pHandle->intraQpDelta = pHandle->stH265Vbr.s32IntraQpDelta;
				pHandle->qpMin = pHandle->stH265Vbr.u32MinQp;
				pHandle->qpMax = pHandle->stH265Vbr.u32MaxQp;
				pHandle->qpMinI = pHandle->stH265Vbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH265Vbr.u32MaxIQp;

                if(pHandle->stH265Vbr.u32IdrDeltaRange && pHandle->stH265Vbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH265Vbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_VBR;
                     pHandle->stH265Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
                }

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265Vbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265Vbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH265Vbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH265Vbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h265 Vbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h265 Vbr Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pstChnAttr->stRcAttr.stH265Vbr.stQpmapInfo.enQpmapQpType);
				}
				memcpy(&pHandle->stRcParam.stH265Vbr, &pstChnAttr->stRcAttr.stH265Vbr, sizeof(AX_VENC_H265_VBR_S));
			} else if (VENC_RC_MODE_H265AVBR == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH265AVbr, &pstChnAttr->stRcAttr.stH265AVbr, sizeof(AX_VENC_H265_AVBR_S));
				pHandle->vbr = 1;
				pHandle->inputRateNumer = pHandle->stH265AVbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH265AVbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH265AVbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH265AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
				pHandle->enRcMode = VENC_RC_MODE_H265AVBR;
				/*RC param*/
				pHandle->ctbRc = VCENC_CTBRC_AVG;
				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;
				pHandle->intraQpDelta = pHandle->stH265AVbr.s32IntraQpDelta;
				pHandle->qpMin = pHandle->stH265AVbr.u32MinQp;
				pHandle->qpMax = pHandle->stH265AVbr.u32MaxQp;
				pHandle->qpMinI = pHandle->stH265AVbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH265AVbr.u32MaxIQp;

                if(pHandle->stH265AVbr.u32IdrDeltaRange && pHandle->stH265AVbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH265AVbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_AVBR;
                    pHandle->stH265AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
                }

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265AVbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265AVbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH265AVbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH265AVbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h265 AVbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h265 AVbr Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pstChnAttr->stRcAttr.stH265AVbr.stQpmapInfo.enQpmapQpType);
				}
				memcpy(&pHandle->stRcParam.stH265AVbr, &pstChnAttr->stRcAttr.stH265AVbr, sizeof(AX_VENC_H265_AVBR_S));
            } else if (VENC_RC_MODE_H265CVBR == pstChnAttr->stRcAttr.enRcMode) {
               memcpy(&pHandle->stH265CVbr, &pstChnAttr->stRcAttr.stH265CVbr, sizeof(AX_VENC_H265_CVBR_S));
               pHandle->vbr = 0;
               pHandle->inputRateNumer = pHandle->stH265CVbr.u32SrcFrameRate;
               pHandle->inputRateDenom = 1;
               pHandle->outputRateNumer = pHandle->stH265CVbr.fr32DstFrameRate;
               pHandle->outputRateDenom = 1;
               pHandle->intraPicRate = pHandle->stH265CVbr.u32Gop;
               pHandle->bitPerSecond = pHandle->stH265CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;
               pHandle->enRcMode = VENC_RC_MODE_H265CVBR;
               /*RC param*/
               pHandle->ctbRc = VCENC_CTBRC_AVG;
               pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;
               pHandle->intraQpDelta = pHandle->stH265CVbr.s32IntraQpDelta;
               pHandle->qpMin = pHandle->stH265CVbr.u32MinQp;
               pHandle->qpMax = pHandle->stH265CVbr.u32MaxQp;
               pHandle->qpMinI = pHandle->stH265CVbr.u32MinIQp;
               pHandle->qpMaxI = pHandle->stH265CVbr.u32MaxIQp;
                pHandle->u32MaxBitRate = pHandle->stH265CVbr.u32MaxBitRate;

                pHandle->u32ShortTermStatTime = pHandle->stH265CVbr.u32ShortTermStatTime;
                pHandle->u32LongTermStatTime = pHandle->stH265CVbr.u32LongTermStatTime;
                pHandle->u32LongTermMaxBitrate = pHandle->stH265CVbr.u32LongTermMaxBitrate;
                pHandle->u32LongTermMinBitrate = pHandle->stH265CVbr.u32LongTermMinBitrate;

                pHandle->u32ExtraBitPercent = pHandle->stH265CVbr.u32ExtraBitPercent;
                pHandle->u32LongTermStatTimeUnit = pHandle->stH265CVbr.u32LongTermStatTimeUnit;

                if(pHandle->stH265CVbr.u32IdrDeltaRange && pHandle->stH265CVbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH265CVbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_CVBR;
                    pHandle->stH265CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
                }

               if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265CVbr.stQpmapInfo.enQpmapQpType)
               {
                   pHandle->roiMapDeltaQpEnable = 1;
                   pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265CVbr.stQpmapInfo.u32QpmapBlockUnit;
                   pHandle->ctbRc = pHandle->stH265CVbr.stQpmapInfo.enCtbRcMode;
               }
               else if (VENC_QPMAP_DISABLE == pHandle->stH265CVbr.stQpmapInfo.enQpmapQpType)
               {
                   VLOG_DEBUG("VencChn %d: h265 AVbr Disable QpMap.\n", pHandle->VeChn);
               }
               else
               {
                   VLOG_ERROR("VencChn %d: h265 AVbr Invalid qpmap qp type = %d.\n",
                       pHandle->VeChn, pstChnAttr->stRcAttr.stH265CVbr.stQpmapInfo.enQpmapQpType);
               }
               memcpy(&pHandle->stRcParam.stH265CVbr, &pstChnAttr->stRcAttr.stH265CVbr, sizeof(AX_VENC_H265_CVBR_S));
			} else if (VENC_RC_MODE_H265FIXQP == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH265FixQp, &pstChnAttr->stRcAttr.stH265FixQp, sizeof(AX_VENC_H265_FIXQP_S));
				pHandle->inputRateNumer = pHandle->stH265FixQp.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH265FixQp.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH265FixQp.u32Gop;
				pHandle->enRcMode = VENC_RC_MODE_H265FIXQP;
				pHandle->fixedIntraQp = pHandle->stH265FixQp.u32IQp; //fix qp for I slice
				pHandle->qpHdr = pHandle->stH265FixQp.u32PQp;
				if (pHandle->stH265FixQp.u32PQp < pHandle->stH265FixQp.u32BQp)
					pHandle->bFrameQpDelta = pHandle->stH265FixQp.u32BQp - pHandle->stH265FixQp.u32PQp;
				else
					pHandle->bFrameQpDelta = pHandle->stH265FixQp.u32PQp - pHandle->stH265FixQp.u32BQp;

				VLOG_DEBUG("VencChn %d: qpHdr = %u, fixedIntraQp=%u, bFrameQpDelta=%u.\n",
					pHandle->VeChn, pHandle->qpHdr, pHandle->fixedIntraQp, pHandle->bFrameQpDelta);
				memcpy(&pHandle->stRcParam.stH265FixQp, &pstChnAttr->stRcAttr.stH265FixQp, sizeof(AX_VENC_H265_FIXQP_S));
			} else if (VENC_RC_MODE_H265QPMAP == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH265QpMap, &pstChnAttr->stRcAttr.stH265QpMap, sizeof(AX_VENC_H265_QPMAP_S));

				pHandle->vbr = 1;
				pHandle->picRc = 1;
				pHandle->inputRateNumer = pHandle->stH265QpMap.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH265QpMap.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH265QpMap.u32Gop;
				pHandle->bitPerSecond = pHandle->stH265QpMap.u32TargetBitRate * VENC_BITRATE_RATIO;
				pHandle->enRcMode = VENC_RC_MODE_H265QPMAP;
				pHandle->ctbRc = 1;
				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265QpMap.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->ctbRc = pHandle->stH265QpMap.enCtbRcMode;
				}
				else if (VENC_QPMAP_ENABLE_ABSQP == pHandle->stH265QpMap.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
				}
				else if (VENC_QPMAP_ENABLE_IPCM == pHandle->stH265QpMap.enQpmapQpType)
				{
					pHandle->ipcmMapEnable = 1;
					pHandle->ctbRc = pHandle->stH265QpMap.enCtbRcMode;
				}
				else
				{
					VLOG_ERROR("VencChn %d: h265 Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pHandle->stH265QpMap.enQpmapQpType);
				}
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265QpMap.u32QpmapBlockUnit;
				memcpy(&pHandle->stRcParam.stH265QpMap, &pstChnAttr->stRcAttr.stH265QpMap, sizeof(AX_VENC_H265_QPMAP_S));
			}
		}
		break;
		case PT_H264:
		{
			if (VENC_RC_MODE_H264CBR == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH264Cbr, &pstChnAttr->stRcAttr.stH264Cbr, sizeof(AX_VENC_H264_CBR_S));

				pHandle->vbr = 0;
				pHandle->inputRateNumer = pHandle->stH264Cbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH264Cbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH264Cbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH264Cbr.u32BitRate * VENC_BITRATE_RATIO;

				pHandle->enRcMode = VENC_RC_MODE_H264CBR;

				pHandle->ctbRc = VCENC_CTBRC_AVG;
				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;
				pHandle->qpMin = pHandle->stH264Cbr.u32MinQp;
				pHandle->qpMax = pHandle->stH264Cbr.u32MaxQp;
				pHandle->qpMinI = pHandle->stH264Cbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH264Cbr.u32MaxIQp;

				LimitQpMinROIenable(pCtx, &codingCfg);

				if (pHandle->stH264Cbr.u32MaxIprop && pHandle->stH264Cbr.u32MaxIprop <= MAX_I_PROP) {
					pHandle->IpropMax = pHandle->stH264Cbr.u32MaxIprop;
				} else {
					pHandle->IpropMax = 40;
					pHandle->stH264Cbr.u32MaxIprop = 40;
				}
				if (pHandle->stH264Cbr.u32MinIprop && pHandle->stH264Cbr.u32MinIprop <= pHandle->IpropMax) {
					pHandle->IpropMin = pHandle->stH264Cbr.u32MinIprop;
				} else {
					pHandle->IpropMin = 10;
					pHandle->stH264Cbr.u32MinIprop = 10;
				}
                if(pHandle->stH264Cbr.u32IdrDeltaRange && pHandle->stH264Cbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH264Cbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_CBR;
                    pHandle->stH264Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
                }
				pHandle->intraQpDelta = pHandle->stH264Cbr.s32IntraQpDelta;

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264Cbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH264Cbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h264 Cbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h264 Cbr Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType);
				}
				memcpy(&pHandle->stRcParam.stH264Cbr, &pstChnAttr->stRcAttr.stH264Cbr, sizeof(AX_VENC_H264_CBR_S));
			} else if (VENC_RC_MODE_H264VBR == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH264Vbr, &pstChnAttr->stRcAttr.stH264Vbr, sizeof(AX_VENC_H264_VBR_S));

				pHandle->vbr = 1;
				pHandle->inputRateNumer = pHandle->stH264Vbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH264Vbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH264Vbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH264Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;

				pHandle->enRcMode = VENC_RC_MODE_H264VBR;
				/* Rc param*/
				pHandle->ctbRc = VCENC_CTBRC_AVG;

				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;

				pHandle->qpMin = pHandle->stH264Vbr.u32MinQp;
				pHandle->qpMax = pHandle->stH264Vbr.u32MaxQp;

				pHandle->qpMinI = pHandle->stH264Vbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH264Vbr.u32MaxIQp;
				pHandle->intraQpDelta = pHandle->stH264Vbr.s32IntraQpDelta;

                if(pHandle->stH264Vbr.u32IdrDeltaRange && pHandle->stH264Vbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH264Vbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_VBR;
                    pHandle->stH264Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
                }

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264Vbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264Vbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH264Vbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH264Vbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h264 Vbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h264 Vbr Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pstChnAttr->stRcAttr.stH264Vbr.stQpmapInfo.enQpmapQpType);
				}

				memcpy(&pHandle->stRcParam.stH264Vbr, &pstChnAttr->stRcAttr.stH264Vbr, sizeof(AX_VENC_H264_VBR_S));
			} else if (VENC_RC_MODE_H264AVBR == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH264AVbr, &pstChnAttr->stRcAttr.stH264AVbr, sizeof(AX_VENC_H264_AVBR_S));

				pHandle->vbr = 1;
				pHandle->inputRateNumer = pHandle->stH264AVbr.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH264AVbr.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH264AVbr.u32Gop;
				pHandle->bitPerSecond = pHandle->stH264AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;

				pHandle->enRcMode = VENC_RC_MODE_H264AVBR;
				/* Rc param*/
				pHandle->ctbRc = VCENC_CTBRC_AVG;

				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;

				pHandle->qpMin = pHandle->stH264AVbr.u32MinQp;
				pHandle->qpMax = pHandle->stH264AVbr.u32MaxQp;
				pHandle->qpMinI = pHandle->stH264AVbr.u32MinIQp;
				pHandle->qpMaxI = pHandle->stH264AVbr.u32MaxIQp;
				pHandle->intraQpDelta = pHandle->stH264AVbr.s32IntraQpDelta;

                if(pHandle->stH264AVbr.u32IdrDeltaRange && pHandle->stH264AVbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH264AVbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_AVBR;
                    pHandle->stH264AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
                }

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264AVbr.stQpmapInfo.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264AVbr.stQpmapInfo.u32QpmapBlockUnit;
					pHandle->ctbRc = pHandle->stH264AVbr.stQpmapInfo.enCtbRcMode;
				}
				else if (VENC_QPMAP_DISABLE == pHandle->stH264AVbr.stQpmapInfo.enQpmapQpType)
				{
					VLOG_DEBUG("VencChn %d: h264 AVbr Disable QpMap.\n", pHandle->VeChn);
				}
				else
				{
					VLOG_ERROR("VencChn %d: h264 AVbr Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pstChnAttr->stRcAttr.stH264AVbr.stQpmapInfo.enQpmapQpType);
				}
				memcpy(&pHandle->stRcParam.stH264AVbr, &pstChnAttr->stRcAttr.stH264AVbr, sizeof(AX_VENC_H264_AVBR_S));
            } else if (VENC_RC_MODE_H264CVBR == pstChnAttr->stRcAttr.enRcMode) {
               memcpy(&pHandle->stH264CVbr, &pstChnAttr->stRcAttr.stH264CVbr, sizeof(AX_VENC_H264_CVBR_S));

               pHandle->vbr = 0;
               pHandle->inputRateNumer = pHandle->stH264CVbr.u32SrcFrameRate;
               pHandle->inputRateDenom = 1;
               pHandle->outputRateNumer = pHandle->stH264CVbr.fr32DstFrameRate;
               pHandle->outputRateDenom = 1;
               pHandle->intraPicRate = pHandle->stH264CVbr.u32Gop;
               pHandle->bitPerSecond = pHandle->stH264CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;

               pHandle->enRcMode = VENC_RC_MODE_H264CVBR;
               /* Rc param*/
               pHandle->ctbRc = VCENC_CTBRC_AVG;

               pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;

               pHandle->qpMin = pHandle->stH264CVbr.u32MinQp;
               pHandle->qpMax = pHandle->stH264CVbr.u32MaxQp;
               pHandle->qpMinI = pHandle->stH264CVbr.u32MinIQp;
               pHandle->qpMaxI = pHandle->stH264CVbr.u32MaxIQp;
                pHandle->intraQpDelta = pHandle->stH264CVbr.s32IntraQpDelta;
                pHandle->u32MaxBitRate = pHandle->stH264CVbr.u32MaxBitRate;
                pHandle->u32ShortTermStatTime = pHandle->stH264CVbr.u32ShortTermStatTime;
                pHandle->u32LongTermStatTime = pHandle->stH264CVbr.u32LongTermStatTime;
                pHandle->u32LongTermMaxBitrate = pHandle->stH264CVbr.u32LongTermMaxBitrate;
                pHandle->u32LongTermMinBitrate = pHandle->stH264CVbr.u32LongTermMinBitrate;

                pHandle->u32ExtraBitPercent = pHandle->stH264CVbr.u32ExtraBitPercent;
                pHandle->u32LongTermStatTimeUnit = pHandle->stH264CVbr.u32LongTermStatTimeUnit;


                if(pHandle->stH264CVbr.u32IdrDeltaRange && pHandle->stH264CVbr.u32IdrDeltaRange <= 10)
                {
                    pHandle->idrDeltaRange = pHandle->stH264CVbr.u32IdrDeltaRange;
                }else {
                    pHandle->idrDeltaRange = IDR_DELTA_RANGE_CVBR;
                    pHandle->stH264CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
                }

               if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264CVbr.stQpmapInfo.enQpmapQpType)
               {
                   pHandle->roiMapDeltaQpEnable = 1;
                   pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264CVbr.stQpmapInfo.u32QpmapBlockUnit;
                   pHandle->ctbRc = pHandle->stH264CVbr.stQpmapInfo.enCtbRcMode;
               }
               else if (VENC_QPMAP_DISABLE == pHandle->stH264CVbr.stQpmapInfo.enQpmapQpType)
               {
                   VLOG_DEBUG("VencChn %d: h264 AVbr Disable QpMap.\n", pHandle->VeChn);
               }
               else
               {
                   VLOG_ERROR("VencChn %d: h264 AVbr Invalid qpmap qp type = %d.\n",
                       pHandle->VeChn, pstChnAttr->stRcAttr.stH264CVbr.stQpmapInfo.enQpmapQpType);
               }
               memcpy(&pHandle->stRcParam.stH264CVbr, &pstChnAttr->stRcAttr.stH264CVbr, sizeof(AX_VENC_H264_CVBR_S));
			} else if (VENC_RC_MODE_H264FIXQP == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH264FixQp, &pstChnAttr->stRcAttr.stH264FixQp, sizeof(AX_VENC_H264_FIXQP_S));

				pHandle->inputRateNumer = pHandle->stH264FixQp.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH264FixQp.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH264FixQp.u32Gop;

				pHandle->enRcMode = VENC_RC_MODE_H264FIXQP;

				pHandle->fixedIntraQp = pHandle->stH264FixQp.u32IQp; //fix qp for I slice
				pHandle->qpHdr = pHandle->stH264FixQp.u32PQp;
				if (pHandle->stH264FixQp.u32PQp < pHandle->stH264FixQp.u32BQp)
					pHandle->bFrameQpDelta = pHandle->stH264FixQp.u32BQp - pHandle->stH264FixQp.u32PQp;
				else
					pHandle->bFrameQpDelta = pHandle->stH264FixQp.u32PQp - pHandle->stH264FixQp.u32BQp;

				VLOG_DEBUG("VencChn %d: qpHdr = %u, fixedIntraQp=%u, bFrameQpDelta=%u.\n",
					pHandle->VeChn, pHandle->qpHdr, pHandle->fixedIntraQp, pHandle->bFrameQpDelta);
				memcpy(&pHandle->stRcParam.stH264FixQp, &pstChnAttr->stRcAttr.stH264FixQp, sizeof(AX_VENC_H264_FIXQP_S));
			} else if (VENC_RC_MODE_H264QPMAP == pstChnAttr->stRcAttr.enRcMode) {
				memcpy(&pHandle->stH264QpMap, &pstChnAttr->stRcAttr.stH264QpMap, sizeof(AX_VENC_H264_QPMAP_S));

				pHandle->vbr = 1;
				pHandle->picRc = 1;
				pHandle->inputRateNumer = pHandle->stH264QpMap.u32SrcFrameRate;
				pHandle->inputRateDenom = 1;
				pHandle->outputRateNumer = pHandle->stH264QpMap.fr32DstFrameRate;
				pHandle->outputRateDenom = 1;
				pHandle->intraPicRate = pHandle->stH264QpMap.u32Gop;
				pHandle->bitPerSecond = pHandle->stH264QpMap.u32TargetBitRate * VENC_BITRATE_RATIO;
				pHandle->ctbRc = 1;

				pHandle->enRcMode = VENC_RC_MODE_H264QPMAP;

				pHandle->qpHdr = pstChnAttr->stRcAttr.s32FirstFrameStartQp;

				if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264QpMap.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->ctbRc = pHandle->stH264Vbr.stQpmapInfo.enCtbRcMode;;
				}
				else if (VENC_QPMAP_ENABLE_ABSQP == pHandle->stH264QpMap.enQpmapQpType)
				{
					pHandle->roiMapDeltaQpEnable = 1;
					pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
				}
				else if (VENC_QPMAP_ENABLE_IPCM == pHandle->stH264QpMap.enQpmapQpType)
				{
					pHandle->ipcmMapEnable = 1;
					pHandle->ctbRc = pHandle->stH264QpMap.enCtbRcMode;
				}
                else
				{
					VLOG_ERROR("VencChn %d: h264 Invalid qpmap qp type = %d.\n",
                        pHandle->VeChn, pHandle->stH264QpMap.enQpmapQpType);
				}
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264QpMap.u32QpmapBlockUnit;
				memcpy(&pHandle->stRcParam.stH264QpMap, &pstChnAttr->stRcAttr.stH264QpMap, sizeof(AX_VENC_H264_QPMAP_S));
			}
		}
		break;
		default:
		{
			VLOG_ERROR("VencChn %d: CODEC type (enType %d) not supported!\n",
                pHandle->VeChn, pstChnAttr->stVencAttr.enType);
			return AX_ERR_VENC_NOT_SUPPORT;
		}
	}

	if (pHandle->qpHdr != DEFAULT)
		pHandle->rcCfg.qpHdr = pHandle->qpHdr;
	else
		pHandle->rcCfg.qpHdr = -1;
	if (pHandle->qpMin != DEFAULT)
		pHandle->rcCfg.qpMinI = pHandle->rcCfg.qpMinPB = pHandle->qpMin;
	if (pHandle->qpMax != DEFAULT)
		pHandle->rcCfg.qpMaxI = pHandle->rcCfg.qpMaxPB = pHandle->qpMax;
	if (pHandle->qpMinI != DEFAULT)
		pHandle->rcCfg.qpMinI = pHandle->qpMinI;
	if (pHandle->qpMaxI != DEFAULT)
		pHandle->rcCfg.qpMaxI = pHandle->qpMaxI;
	if (pHandle->picSkip != DEFAULT)
		pHandle->rcCfg.pictureSkip = pHandle->picSkip;
	if (pHandle->picRc != DEFAULT)
		pHandle->rcCfg.pictureRc = pHandle->picRc;
	if (pHandle->ctbRc != DEFAULT)
	{
		if(pHandle->ctbRc == 4 || pHandle->ctbRc == 6)
		{
			pHandle->rcCfg.ctbRc = pHandle->ctbRc - 3;
			pHandle->rcCfg.ctbRcQpDeltaReverse = 1;
		}
		else
		{
			pHandle->rcCfg.ctbRc = pHandle->ctbRc;
			pHandle->rcCfg.ctbRcQpDeltaReverse = 0;
		}
	}

	pHandle->rcCfg.blockRCSize = 0;
	if (pHandle->blockRCSize != DEFAULT)
		pHandle->rcCfg.blockRCSize = pHandle->blockRCSize;

	pHandle->rcCfg.rcQpDeltaRange = 10;
	if (pHandle->rcQpDeltaRange != DEFAULT)
		pHandle->rcCfg.rcQpDeltaRange = pHandle->rcQpDeltaRange;

	pHandle->rcCfg.rcBaseMBComplexity = 15;
	if (pHandle->rcBaseMBComplexity != DEFAULT)
		pHandle->rcCfg.rcBaseMBComplexity = pHandle->rcBaseMBComplexity;

	if (pHandle->picQpDeltaMax != DEFAULT)
		pHandle->rcCfg.picQpDeltaMax = pHandle->picQpDeltaMax;
	if (pHandle->picQpDeltaMin != DEFAULT)
		pHandle->rcCfg.picQpDeltaMin = pHandle->picQpDeltaMin;
	if (pHandle->bitPerSecond != DEFAULT)
		pHandle->rcCfg.bitPerSecond = pHandle->bitPerSecond;
	if (pHandle->cpbMaxRate != DEFAULT)
		pHandle->rcCfg.cpbMaxRate = pHandle->cpbMaxRate;
	if (pHandle->bitVarRangeI != DEFAULT)
		pHandle->rcCfg.bitVarRangeI = pHandle->bitVarRangeI;
	if (pHandle->bitVarRangeP != DEFAULT)
		pHandle->rcCfg.bitVarRangeP = pHandle->bitVarRangeP;
	if (pHandle->bitVarRangeB != DEFAULT)
		pHandle->rcCfg.bitVarRangeB = pHandle->bitVarRangeB;

	if (pHandle->tolMovingBitRate != DEFAULT)
		pHandle->rcCfg.tolMovingBitRate = pHandle->tolMovingBitRate;

	if (pHandle->tolCtbRcInter != DEFAULT)
		pHandle->rcCfg.tolCtbRcInter = pHandle->tolCtbRcInter;

	if (pHandle->tolCtbRcIntra != DEFAULT)
		pHandle->rcCfg.tolCtbRcIntra = pHandle->tolCtbRcIntra;

	if (pHandle->ctbRcRowQpStep != DEFAULT)
		pHandle->rcCfg.ctbRcRowQpStep = pHandle->ctbRcRowQpStep;

	pHandle->rcCfg.longTermQpDelta = pHandle->longTermQpDelta;

	if (pHandle->monitorFrames != DEFAULT)
		pHandle->rcCfg.monitorFrames = pHandle->monitorFrames;
	else
    {
		pHandle->rcCfg.monitorFrames =(pHandle->outputRateNumer+pHandle->outputRateDenom-1) / pHandle->outputRateDenom;
		pHandle->monitorFrames = (pHandle->outputRateNumer+pHandle->outputRateDenom-1) / pHandle->outputRateDenom;
	}

	if(pHandle->rcCfg.monitorFrames>MOVING_AVERAGE_FRAMES)
		pHandle->rcCfg.monitorFrames=MOVING_AVERAGE_FRAMES;

	if (pHandle->rcCfg.monitorFrames < 10)
	{
		pHandle->rcCfg.monitorFrames = (pHandle->outputRateNumer > pHandle->outputRateDenom)? 10:LEAST_MONITOR_FRAME;
	}

	if (pHandle->hrdConformance != DEFAULT)
		pHandle->rcCfg.hrd = pHandle->hrdConformance;

	if (pHandle->cpbSize != DEFAULT)
		pHandle->rcCfg.hrdCpbSize = pHandle->cpbSize;

	if (pHandle->intraPicRate != 0)
		pHandle->rcCfg.bitrateWindow = MIN(pHandle->intraPicRate, MAX_GOP_LEN);

	if (pHandle->bitrateWindow != DEFAULT)
		pHandle->rcCfg.bitrateWindow = pHandle->bitrateWindow;

	if (pHandle->intraQpDelta != DEFAULT)
		pHandle->rcCfg.intraQpDelta = pHandle->intraQpDelta;

	if (pHandle->vbr != DEFAULT)
		pHandle->rcCfg.vbr = pHandle->vbr;

	if (pHandle->crf != DEFAULT)
		pHandle->rcCfg.crf = pHandle->crf;

	pHandle->rcCfg.fixedIntraQp = pHandle->fixedIntraQp;
	pHandle->rcCfg.smoothPsnrInGOP = pHandle->smoothPsnrInGOP;
	pHandle->rcCfg.u32StaticSceneIbitPercent = pHandle->u32StaticSceneIbitPercent;

	pHandle->rcCfg.frameRateNum = pHandle->outputRateNumer;
	pHandle->rcCfg.frameRateDenom = pHandle->outputRateDenom;
	pHandle->rcCfg.IpropMax = pHandle->IpropMax;
	pHandle->rcCfg.IpropMin = pHandle->IpropMin;
    pHandle->rcCfg.GopSize = pHandle->gopSize;

	VCEncRet ret = VCEncSetRateCtrl(pHandle->vencInst, &pHandle->rcCfg);
	if (ret != VCENC_OK) {
		VLOG_ERROR("VencChn %d:VCEncSetRateCtrl() failed, ret = %d\n", pHandle->VeChn, ret);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}
	return AX_SUCCESS;
}

static int VencChangeTypeAttrReset(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	if (NULL == pCtx || NULL == pstChnAttr)
	{
		VLOG_ERROR("Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}
	AX_S32 s32Ret = AX_SUCCESS;

    AX_S32 VeChn;
    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	switch (pstChnAttr->stVencAttr.enType)
	{
		case PT_H265:
		{
			pHandle->codecFormat = VCENC_VIDEO_CODEC_HEVC;
			pHandle->max_cu_size = 64;
			pHandle->min_cu_size = 8;
			pHandle->max_tr_size = 16;
			pHandle->min_tr_size = 4;
			pHandle->tr_depth_intra = 2;
			pHandle->tr_depth_inter = 4;
			pHandle->enableCabac = 1;
			pHandle->profile = pstChnAttr->stVencAttr.enProfile;
			pHandle->level = pstChnAttr->stVencAttr.enLevel;
			pHandle->tier = pstChnAttr->stVencAttr.enTier;
			break;
		}
		case PT_H264:
		{
			pHandle->codecFormat = VCENC_VIDEO_CODEC_H264;
			pHandle->max_cu_size = 16;
			pHandle->min_cu_size = 8;
			pHandle->max_tr_size = 16;
			pHandle->min_tr_size = 4;
			pHandle->tr_depth_intra = 1;
			pHandle->tr_depth_inter = 2;
			pHandle->layerInRefIdc = 0;
			pHandle->enableCabac = 1;
			pHandle->profile = pstChnAttr->stVencAttr.enProfile;
			if (pHandle->profile == VCENC_H264_BASE_PROFILE)
            {
				pHandle->enableCabac = 0;
			}
			pHandle->level = pstChnAttr->stVencAttr.enLevel;
			break;
		}
		default:
		{
			VLOG_ERROR("VencChn %d: CODEC type (enType %d) not supported!\n", pHandle->VeChn, pstChnAttr->stVencAttr.enType);
			return AX_ERR_VENC_NOT_SUPPORT;
		}
	}

	VCEncConfig encCfg;
	encCfg.level = pHandle->level;
	encCfg.profile = pHandle->profile;
	encCfg.tier = pHandle->tier;
	encCfg.codedChromaIdc = pHandle->codedChromaIdc;
	encCfg.codecFormat = pHandle->codecFormat;
	encCfg.frameRateDenom = pHandle->outputRateDenom;
	encCfg.frameRateNum = pHandle->outputRateNumer;
	encCfg.width = pHandle->lumWidthSrc;
	encCfg.height = pHandle->lumHeightSrc;
	encCfg.rdoLevel = 0;
	encCfg.ctbRcMode = pHandle->ctbRc;
	s32Ret = VCEncChangeTypeReset(pHandle->vencInst, &encCfg);
	if (s32Ret != AX_SUCCESS)
	{
		VLOG_ERROR("VencChn %d: Change encode type info reset failed!\n", pHandle->VeChn, pstChnAttr->stVencAttr.enType);
		return AX_ERR_VENC_NOT_SUPPORT;
	}

	return AX_SUCCESS;
}

AX_S32 VencSetChnAttr(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	AX_S32 s32Ret = -1;
	AX_U32 u32ChangeEncodeType = 0;
    AX_VENC_CHN_ATTR_S *pstVencChnAttr = NULL;

    AX_S32 VeChn;
    if (NULL == pstChnAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;
    pstVencChnAttr = &(((AX_VENC_CHN_INSTANCE_S *)pCtx)->stVencChnAttr);

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	if (pHandle->stChnnelAttr.stVencAttr.enType == PT_JPEG ||
		pHandle->stChnnelAttr.stVencAttr.enType == PT_MJPEG)
	{
		return AX_SUCCESS;
	}
	VCEncStrmCtrl newResolutionParam;

	s32Ret = VencChannelDyamicAttrCheck(pCtx, pstChnAttr);
	if (AX_SUCCESS != s32Ret)
	{
		VLOG_ERROR("VencChn %d: Channel static attribute cannot change.\n", pHandle->VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	pHandle->lumWidthSrc = pstChnAttr->stVencAttr.u32PicWidthSrc;
	pHandle->lumHeightSrc = pstChnAttr->stVencAttr.u32PicHeightSrc;

	if (pHandle->stChnnelAttr.stVencAttr.enType != pstChnAttr->stVencAttr.enType ||
		pHandle->profile != pstChnAttr->stVencAttr.enProfile ||
		pHandle->level != pstChnAttr->stVencAttr.enLevel ||
		pHandle->stChnnelAttr.stRcAttr.enRcMode != pstChnAttr->stRcAttr.enRcMode)
	{
		s32Ret = VencChangeTypeAttrReset(pCtx, pstChnAttr);
		if (AX_SUCCESS != s32Ret)
		{
			VLOG_ERROR("VencChn %d: Channel change encode type attr set failed.\n", pHandle->VeChn);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		u32ChangeEncodeType = 1;
	}

    if ( (0 != pstChnAttr->stVencAttr.u32CropWidth) &&
            (0 != pstChnAttr->stVencAttr.u32CropHeight) ) {
        /* cropping offset */
        pHandle->horOffsetSrc = pstChnAttr->stVencAttr.u32CropOffsetX;
        pHandle->verOffsetSrc = pstChnAttr->stVencAttr.u32CropOffsetY;
        /*widht height of encoded picture*/
        pHandle->width = pstChnAttr->stVencAttr.u32CropWidth;
        pHandle->height = pstChnAttr->stVencAttr.u32CropHeight;
        pHandle->dynamicCropEnable = AX_FALSE;
    } else {
        pHandle->horOffsetSrc = 0;
        pHandle->verOffsetSrc = 0;
        /*widht height of encoded picture*/
        pHandle->width = pstChnAttr->stVencAttr.u32PicWidthSrc;
        pHandle->height = pstChnAttr->stVencAttr.u32PicHeightSrc;
        pHandle->dynamicCropEnable = AX_TRUE;
    }

	newResolutionParam.width = pHandle->width;
	newResolutionParam.height = pHandle->height;

	VCEncRet ret = VCEncSetStrmCtrl(pHandle->vencInst, &newResolutionParam, u32ChangeEncodeType);
	if (VCENC_OK != ret)
	{
		VLOG_ERROR("VencChn %d: Dynamic change resolution failed.\n", pHandle->VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (u32ChangeEncodeType)
	{
		s32Ret = VencResetRateCtrlInfo(pCtx, pstChnAttr);
		if (s32Ret != AX_SUCCESS)
		{
			VLOG_ERROR("VencChn %d: CODEC type (enType %d) Rate control info reset failed!\n",
                pHandle->VeChn, pstChnAttr->stVencAttr.enType);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}

	VCEncPreProcessingCfg preProcCfg = {0};
	if ((ret = VCEncGetPreProcessing(pHandle->vencInst, &preProcCfg)) != VCENC_OK)
	{
		VLOG_ERROR("VCEncGetPreProcessing ret:0x%x\n", __func__, ret);
		return AX_ERR_VENC_UNKNOWN;
	}
	preProcCfg.origWidth = pHandle->lumWidthSrc;
	preProcCfg.origHeight = pHandle->lumHeightSrc;
	preProcCfg.xOffset = pHandle->horOffsetSrc;
	preProcCfg.yOffset = pHandle->verOffsetSrc;

	if ((ret = VCEncSetPreProcessing(pHandle->vencInst, &preProcCfg)) != VCENC_OK)
	{
		VLOG_ERROR("%s VCEncSetPreProcessing ret:0x%x\n", __func__, ret);
		return AX_ERR_VENC_UNKNOWN;
	}
	if(0 != memcmp(&pHandle->stChnnelAttr.stRcAttr,&pstChnAttr->stRcAttr,sizeof(AX_VENC_RC_ATTR_S)))
	{
		CloseEncoder(pHandle->vencInst, pHandle);
		s32Ret = GetVencChnAttr(VeChn, pstChnAttr, pHandle, pstVencChnAttr);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: set channel attribute error. s32Ret:0x%x\n", VeChn, s32Ret);
			s32Ret = AX_ERR_VENC_ILLEGAL_PARAM;
		}
		pHandle->encIn.gopConfig.size--;
		/* Encoder initialization */
		s32Ret = OpenEncoderNew(&pHandle->vencInst, pHandle);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: open encoder error. s32Ret:0x%x\n", VeChn, s32Ret);
			s32Ret = AX_ERR_VENC_CREATE_CHAN_ERR;
		}
	}
	memcpy(&pHandle->stChnnelAttr, pstChnAttr, sizeof(AX_VENC_CHN_ATTR_S));

	s32Ret = VencEncodeHeader(pHandle);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: encode header err. s32Ret:0x%x\n", pHandle->VeChn, s32Ret);
		return AX_ERR_VENC_UNKNOWN;
	}

	return AX_SUCCESS;
}

AX_S32 VencSetSpsVuiParam(AX_VOID *pCtx, const AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam)
{
	VCEncRet ret;
    AX_S32 VeChn;
	VCEncCodingCtrl codingCfg;

    if (NULL == pstSpsVuiParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	memset(&codingCfg, 0, sizeof(VCEncCodingCtrl));

	ret = VCEncGetCodingCtrl(pHandle->vencInst, &codingCfg);
	if (ret != VCENC_OK)
	{
		VLOG_ERROR("VencChn %d: VCEncGetCodingCtrl failed!\n", pHandle->VeChn);
		return AX_ERR_VENC_UNKNOWN;
	}

	memcpy(&codingCfg.spsVuiParam, pstSpsVuiParam, sizeof(AX_VENC_SPS_VUI_PARAM_S));

	if (VCENC_OK != VCEncSetCodingCtrl(pHandle->vencInst, &codingCfg))
	{
		VLOG_ERROR("VencChn %d: VCEncSetCodingCtrl() failed.\n", pHandle->VeChn);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}

AX_S32 VencSetSuperFrameCfg(AX_VOID *pCtx, const AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg)
{
	AX_S32 VeChn;
	if (NULL == pstSuperFrameCfg) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(&pHandle->stSuperFrmCfg, pstSuperFrameCfg, sizeof(AX_VENC_SUPERFRAME_CFG_S));

	VCEncReEncodeCfg stReEncodeCfg;
	stReEncodeCfg.bStrategyEn = pstSuperFrameCfg->bStrategyEn;
	stReEncodeCfg.u32MaxReEncodeTimes = pstSuperFrameCfg->u32MaxReEncodeTimes;
	stReEncodeCfg.u32SuperIFrmBitsThr = pstSuperFrameCfg->u32SuperIFrmBitsThr;
	stReEncodeCfg.u32SuperPFrmBitsThr = pstSuperFrameCfg->u32SuperPFrmBitsThr;
	stReEncodeCfg.u32SuperBFrmBitsThr = pstSuperFrameCfg->u32SuperBFrmBitsThr;
	stReEncodeCfg.reEncodeCb =  VCEncReEncodeStrategy;

	VCEncRet ret = VCEncReEncodeSet(pHandle->vencInst, &stReEncodeCfg);
	if (VCENC_OK != ret)
	{
		VLOG_ERROR("VencChn %d: VCEncReEncodeSet fail.\n", VeChn);
		return -1;
	}

	return AX_SUCCESS;
}

AX_S32 VencGetSuperFrameCfg(AX_VOID *pCtx, AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg)
{
	AX_S32 VeChn;
	if (NULL == pstSuperFrameCfg) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	VCEncReEncodeCfg stReEncodeCfg;
	memset(&stReEncodeCfg, 0, sizeof(VCEncReEncodeCfg));

	VCEncRet ret = VCEncReEncodeGet(pHandle->vencInst, &stReEncodeCfg);
	if (VCENC_OK != ret)
	{
		VLOG_ERROR("VencChn %d: VCEncReEncodeGet fail.\n", VeChn);
		return -1;
	}

	pstSuperFrameCfg->bStrategyEn = stReEncodeCfg.bStrategyEn;
	pstSuperFrameCfg->u32MaxReEncodeTimes = stReEncodeCfg.u32MaxReEncodeTimes;
	pstSuperFrameCfg->u32SuperIFrmBitsThr = stReEncodeCfg.u32SuperIFrmBitsThr;
	pstSuperFrameCfg->u32SuperPFrmBitsThr = stReEncodeCfg.u32SuperPFrmBitsThr;
	pstSuperFrameCfg->u32SuperBFrmBitsThr = stReEncodeCfg.u32SuperBFrmBitsThr;

	return AX_SUCCESS;
}

AX_S32 VencGetSpsVuiParam(AX_VOID *pCtx, AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam)
{
	VCEncRet ret;
	VCEncCodingCtrl codingCfg;

    AX_S32 VeChn;
    if (NULL == pstSpsVuiParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	memset(&codingCfg, 0, sizeof(VCEncCodingCtrl));

	ret = VCEncGetCodingCtrl(pHandle->vencInst, &codingCfg);
	if (ret != VCENC_OK)
	{
		VLOG_ERROR("VencChn %d: VCEncGetCodingCtrl failed!\n", pHandle->VeChn);
		return AX_ERR_VENC_UNKNOWN;
	}

	memcpy(pstSpsVuiParam, &codingCfg.spsVuiParam, sizeof(VCEncSpsVuiParam));

	return AX_SUCCESS;
}

AX_S32 VencSetRateJamStrategyParam(AX_VOID *pCtx, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	/* VCEncRet ret; */
	AX_S32 VeChn;

	if (NULL == pstRateJamParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(&pHandle->stRateJamStrategyParam, pstRateJamParam, sizeof(AX_VENC_RATE_JAM_CFG_S));

	return AX_SUCCESS;
}

AX_S32 VencGetRateJamStrategyParam(AX_VOID *pCtx, AX_VENC_RATE_JAM_CFG_S *pstRateJamParam)
{
	/* VCEncRet ret; */
	AX_S32 VeChn;
	if (NULL == pstRateJamParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	memcpy(pstRateJamParam, &pHandle->stRateJamStrategyParam, sizeof(AX_VENC_RATE_JAM_CFG_S));

	return AX_SUCCESS;
}

AX_S32 VencGetChnAttr(AX_VOID *pCtx, AX_VENC_CHN_ATTR_S *pstChnAttr)
{
	AX_S32 VeChn;

    if (NULL == pstChnAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

	return AX_SUCCESS;
}

AX_S32 VencInsertUserData(AX_VOID *pCtx, const AX_U8 *pu8Data, AX_U32 u32Len)
{
	AX_S32 s32Ret;

	if (NULL == pu8Data) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", pChnInst->ChnId);
		return AX_ERR_VENC_NULL_PTR;
	}

	if (u32Len > pHandle->stUserDataQueueAttr.u32UserDataBufferSize || u32Len < 16)  // 16 is the sei uuid size
	{
		VLOG_ERROR("userdata size should in [16, %d]. \n", pHandle->stUserDataQueueAttr.u32UserDataBufferSize);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pChnInst->pstUserDataBufferQueue == NULL)
	{
		pChnInst->pstUserDataBufferQueue = (AX_USERDATA_BUFFER_QUEUE_S *)calloc(1, sizeof(AX_USERDATA_BUFFER_QUEUE_S));
		if (NULL == pChnInst->pstUserDataBufferQueue) {
			VLOG_ERROR("VencChn %d: calloc userdata buffer queue err.\n", pChnInst->ChnId);
			return AX_ERR_VENC_NOMEM;
		}
		pChnInst->pstUserDataBufferQueue->stBufferNode = (AX_USERDATA_NODE_S *)calloc(pHandle->stUserDataQueueAttr.u32UserDataBufferCount, sizeof(AX_USERDATA_NODE_S));
		if (NULL == pChnInst->pstUserDataBufferQueue->stBufferNode) {
			free(pChnInst->pstUserDataBufferQueue);
			pChnInst->pstUserDataBufferQueue = NULL;

			VLOG_ERROR("VencChn %d: calloc userdata buffer queue node err.\n", pChnInst->ChnId);
			return AX_ERR_VENC_NOMEM;
		}

		s32Ret = InitUserDataBufferQueue(pChnInst->ChnId, pChnInst->pstUserDataBufferQueue, &pHandle->stUserDataQueueAttr);
		if (s32Ret != AX_SUCCESS)
		{
			free(pChnInst->pstUserDataBufferQueue->stBufferNode);
			pChnInst->pstUserDataBufferQueue->stBufferNode = NULL;

			free(pChnInst->pstUserDataBufferQueue);
			pChnInst->pstUserDataBufferQueue = NULL;

			VLOG_ERROR("VencChn %d: init userdata buffer queue err.\n", pChnInst->ChnId);
			return AX_ERR_VENC_UNKNOWN;
		}
	}

	AX_USERDATA_NODE_S stUserDataNode;
	stUserDataNode.pBufferAddr = (AX_U8 *)pu8Data;
	stUserDataNode.u32BufferSize = u32Len;

	s32Ret = UserDataInsertQueue(pChnInst->ChnId, pChnInst->pstUserDataBufferQueue, &stUserDataNode);
	if (s32Ret != AX_SUCCESS)
	{
		VLOG_ERROR("VencChn %d: user data buffer queue insert err(%d).\n", pChnInst->ChnId, s32Ret);
		return AX_ERR_VENC_UNKNOWN;
	}

	return AX_SUCCESS;
}

AX_S32 VencRequestIDR(AX_VOID *pCtx, AX_BOOL bInstant)
{
    AX_S32 VeChn;

    if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

    VeChn = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->ChnId;

	AX_AVCHEVC_HANDLE_S *pHandle = ((AX_VENC_CHN_INSTANCE_S *)pCtx)->pHalCtx;
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    pHandle->bRequestIDR = true;
    pHandle->bInstantIDR = bInstant;
    if (VENC_GOPMODE_ONELTR == pHandle->stChnnelAttr.stGopAttr.enGopMode)
    {
        pHandle->bInstantIDR = false;
    }

	return AX_SUCCESS;
}

AX_S32 VencQueryStatus(AX_VOID *pCtx, AX_VENC_CHN_STATUS_S *pstStatus)
{
	AX_S32 VeChn;
	AX_S32 s32Ret = 0;
	AX_S32 LeftFrames = 0;
	VENC_IOC_PARAM_S stVencIocParam = {0};

	if (NULL == pstStatus) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	if (NULL == pCtx) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
	}

	AX_VENC_CHN_INSTANCE_S *VencInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;

	VeChn = VencInst->ChnId;

	if (AX_NONLINK_MODE == VencInst->stVencChnAttr.stVencAttr.enLinkMode) {
		LeftFrames = AX_Fifo_Count(VeChn, VencInst->inputQueue);
	}else if (AX_LINK_MODE == VencInst->stVencChnAttr.stVencAttr.enLinkMode) {
		stVencIocParam.chnID = VeChn;
		s32Ret = ioctl(VencInst->devFd, HANTRO_IOCH_FIFO_LEN, &stVencIocParam);
		if (s32Ret) {
			VLOG_ERROR("VencChn %d: get frames length in input fifo failed.\n", VeChn);
			return AX_ERR_VENC_UNKNOWN;
		}
		LeftFrames = stVencIocParam.fifoLength;
	}

	pstStatus->u32LeftPics = LeftFrames;
	pstStatus->u32LeftStreamBytes = VencInst->u64LeftStreamBytes;
	pstStatus->u32LeftStreamFrames = VencInst->u64TotalEncodeNum - VencInst->u64TotalGetStrmNum;
	pstStatus->u32CurPacks = 0;  // not support
	pstStatus->u32LeftRecvPics = 0;  // not support
	pstStatus->u32LeftEncPics = 0;  // not support

	VLOG_DEBUG("JencChn %d: LeftPics %d, LeftStreamBytes %d, LeftStreamFrames %d.\n",
				VeChn,
				pstStatus->u32LeftPics,
				pstStatus->u32LeftStreamBytes,
				pstStatus->u32LeftStreamFrames);

	return AX_SUCCESS;
}

AX_VOID VencUpdateCvbrLongBps(AX_VOID *pCtx)
{
   AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;
   struct timeval timeGetFrmEncode;
    AX_U64 u64LongTermTimeUs = 0;
    AX_VENC_RC_MODE_E enRcMode = pChnInst->stVencChnAttr.stRcAttr.enRcMode;
   gettimeofday(&timeGetFrmEncode, NULL);
    if (VENC_RC_MODE_H264CVBR == enRcMode)
    {
        u64LongTermTimeUs = (AX_U64)pChnInst->stVencChnAttr.stRcAttr.stH264CVbr.u32LongTermStatTime * 1000 * 1000 ;
    }
    else if(VENC_RC_MODE_H265CVBR == enRcMode)
    {
        u64LongTermTimeUs = (AX_U64)pChnInst->stVencChnAttr.stRcAttr.stH265CVbr.u32LongTermStatTime * 1000 * 1000 ;
    }
   gettimeofday(&timeGetFrmEncode, NULL);

   AX_U64 timediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetLongTermFrmEncodeStart);
    if (timediff > u64LongTermTimeUs) // CVBR short term time, set  byuser
   {
       pChnInst->u64LongTermBitRate = pChnInst->u64LongTermtrmSize * 8 * 1000 * 1000 / timediff;
       pChnInst->u64LongTermBitRate >>= 10;

       pChnInst->u64LongTermtrmSize = 0;

       pChnInst->timeGetLongTermFrmEncodeStart = pChnInst->timeGetFrmEncodeStart;
   }

   return AX_SUCCESS;
}


AX_VOID VencUpdateCvbrShortBps(AX_VOID *pCtx)
{
   AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;
   struct timeval timeGetFrmEncode;
    AX_U32 u32ShortTermTimeUs = 0;
    AX_VENC_RC_MODE_E enRcMode = pChnInst->stVencChnAttr.stRcAttr.enRcMode;
   gettimeofday(&timeGetFrmEncode, NULL);
    if (VENC_RC_MODE_H264CVBR == enRcMode)
    {
        u32ShortTermTimeUs = pChnInst->stVencChnAttr.stRcAttr.stH264CVbr.u32ShortTermStatTime * 1000 * 1000 ;
    }
    else if(VENC_RC_MODE_H265CVBR == enRcMode)
    {
        u32ShortTermTimeUs = pChnInst->stVencChnAttr.stRcAttr.stH265CVbr.u32ShortTermStatTime * 1000 * 1000 ;
    }
   gettimeofday(&timeGetFrmEncode, NULL);

    AX_U32 timediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetShortTermFrmEncodeStart);
   if (timediff > u32ShortTermTimeUs) // CVBR short term time, set  byuser
   {
       pChnInst->u64ShortTermBitRate = pChnInst->u64ShortTermtrmSize * 8 * 1000 * 1000 / timediff;
       pChnInst->u64ShortTermBitRate >>= 10;
       pChnInst->u64ShortTermtrmSize = 0;

       pChnInst->timeGetShortTermFrmEncodeStart = pChnInst->timeGetFrmEncodeStart;
   }

   return AX_SUCCESS;
}

AX_VOID VencUpdateFpsBr(AX_VOID *pCtx)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst = (AX_VENC_CHN_INSTANCE_S *)pCtx;
	struct timeval timeGetFrmEncode;

	gettimeofday(&timeGetFrmEncode, NULL);

	AX_U32 timediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetFrmEncodeStart);
	if (timediff > 1000000) // 1000000us == 1s
	{
		pChnInst->F32RealTimeFrameRate = (AX_F32)(pChnInst->u64StatisticalEncodeFrm * 1000 * 1000) / timediff;
		pChnInst->u64RealTimeBitRate = pChnInst->u64PerSecondStrmSize * 8 * 1000 * 1000 / timediff;
		pChnInst->u64RealTimeBitRate >>= 10;

		pChnInst->u64PerSecondStrmSize = 0;
		pChnInst->u64StatisticalEncodeFrm = 0;

		pChnInst->timeGetFrmEncodeStart = timeGetFrmEncode;
	}

	// update for instantaneous bps
	AX_U32 bpstimediff = VencTimeDiff(timeGetFrmEncode, pChnInst->timeGetFrmEncodeStartForInstantBps);
	if (pChnInst->u64EncodeFrmNumForInstantaneousBps > 5 || bpstimediff > 1000000) // update per 5 frames, we think it is instantanous data
	{
		pChnInst->u64InstantaneousBitRate = pChnInst->u64InstantaneousEncodeStrmSize * 8 * 1000 * 1000 / bpstimediff;
		pChnInst->u64InstantaneousEncodeStrmSize = 0;
		pChnInst->u64EncodeFrmNumForInstantaneousBps = 0;

		pChnInst->timeGetFrmEncodeStartForInstantBps = timeGetFrmEncode;
	}

	return;
}


AX_S32 VencSetJpegParam(AX_VOID *pCtx, const AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	//
	return AX_ERR_VENC_NOT_SUPPORT;
}

AX_S32 VencGetJpegParam(AX_VOID *pCtx, AX_VENC_JPEG_PARAM_S *pstJpegParam)
{
	//
	return AX_ERR_VENC_NOT_SUPPORT;
}

static int VencRoiAttrCheck(VENC_CHN VeChn, const AX_VENC_ROI_ATTR_S *pstRoiAttr, AX_AVCHEVC_HANDLE_S *pHandle)
{
	if (NULL == pHandle) {
		VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
    }

    if (NULL == pstRoiAttr) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

	//ROI index check
	if (pstRoiAttr->u32Index > 7) {
		VLOG_ERROR("VencChn %d: Invalid ROI Index : %d.\n", VeChn, pstRoiAttr->u32Index);
		return -1;
	}

	if (false == pstRoiAttr->bEnable) {
		VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
		return 0;
	}

	//if Abs Qp
	if (pstRoiAttr->bAbsQp) {
		if (pstRoiAttr->s32RoiQp < 0 || pstRoiAttr->s32RoiQp > 51) {
			VLOG_ERROR("VencChn %d: Use Abs Qp, Qp=%d, out of range[0, 51].\n",
						VeChn, pstRoiAttr->s32RoiQp);
			return -1;
		}
	}

	//if Relative Qp
	if (false == pstRoiAttr->bAbsQp) {
		if (pstRoiAttr->s32RoiQp < -51 || pstRoiAttr->s32RoiQp > 51) {
			VLOG_ERROR("VencChn %d: Use Relative Qp, Qp=%d, out of range[-51, 51].\n",
						VeChn, pstRoiAttr->s32RoiQp);
			return -1;
		}
	}

	//ROI area check, get from user
	if (pstRoiAttr->stRoiArea.u32X < 0) {
		VLOG_ERROR("VencChn %d: invalid roi startX=%u.\n",
					VeChn, pstRoiAttr->stRoiArea.u32X);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstRoiAttr->stRoiArea.u32Y < 0) {
		VLOG_ERROR("VencChn %d: invalid roi startY=%u.\n",
					VeChn, pstRoiAttr->stRoiArea.u32Y);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstRoiAttr->stRoiArea.u32Width <= 0) {
		VLOG_ERROR("VencChn %d: invalid roi width=%d, must more than 0.\n",
					VeChn, pstRoiAttr->stRoiArea.u32Width);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if (pstRoiAttr->stRoiArea.u32Height <= 0) {
		VLOG_ERROR("VencChn %d: invalid roi height=%d, must more than 0.\n",
					VeChn, pstRoiAttr->stRoiArea.u32Height);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ((pstRoiAttr->stRoiArea.u32X + pstRoiAttr->stRoiArea.u32Width) > pHandle->width) {
		VLOG_ERROR("VencChn %d: invalid roi startX=%d or width=%d, (startX + width) over encode width %d.\n",
			VeChn,
			pstRoiAttr->stRoiArea.u32X,
			pstRoiAttr->stRoiArea.u32Width,
			pHandle->width);

		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ((pstRoiAttr->stRoiArea.u32Y + pstRoiAttr->stRoiArea.u32Height) > pHandle->height) {
		VLOG_ERROR("VencChn %d: invalid roi startY=%d or height=%d, (startY + height) over encode height %d.\n",
			VeChn,
			pstRoiAttr->stRoiArea.u32Y,
			pstRoiAttr->stRoiArea.u32Height,
			pHandle->height);

		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return 0;
}

static void VencRoiAttrPrint(AX_S32 VeChn, VCEncCodingCtrl *pstCodingCfg)
{
    if (NULL == pstCodingCfg) {
		VLOG_ERROR(" Param is null pointer. \n");
		return;
    }

	if (pstCodingCfg->roi1Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 1: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi1Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi1Qp >= 0 ? pstCodingCfg->roi1Qp : pstCodingCfg->roi1DeltaQp,
			pstCodingCfg->roi1Area.left, pstCodingCfg->roi1Area.top,
			pstCodingCfg->roi1Area.right, pstCodingCfg->roi1Area.bottom);

	if (pstCodingCfg->roi2Area.enable)
		VLOG_DEBUG("VencChn %d: ROI 2: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi2Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi2Qp >= 0 ? pstCodingCfg->roi2Qp : pstCodingCfg->roi2DeltaQp,
			pstCodingCfg->roi2Area.left, pstCodingCfg->roi2Area.top,
			pstCodingCfg->roi2Area.right, pstCodingCfg->roi2Area.bottom);

	if (pstCodingCfg->roi3Area.enable)
		VLOG_DEBUG("VencChn %d: ROI 3: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi3Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi3Qp >= 0 ? pstCodingCfg->roi3Qp : pstCodingCfg->roi3DeltaQp,
			pstCodingCfg->roi3Area.left, pstCodingCfg->roi3Area.top,
			pstCodingCfg->roi3Area.right, pstCodingCfg->roi3Area.bottom);

	if (pstCodingCfg->roi4Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 4: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi4Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi4Qp >= 0 ? pstCodingCfg->roi4Qp : pstCodingCfg->roi4DeltaQp,
			pstCodingCfg->roi4Area.left, pstCodingCfg->roi4Area.top,
			pstCodingCfg->roi4Area.right, pstCodingCfg->roi4Area.bottom);

	if (pstCodingCfg->roi5Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 5: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi5Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi5Qp >= 0 ? pstCodingCfg->roi5Qp : pstCodingCfg->roi5DeltaQp,
			pstCodingCfg->roi5Area.left, pstCodingCfg->roi5Area.top,
			pstCodingCfg->roi5Area.right, pstCodingCfg->roi5Area.bottom);

	if (pstCodingCfg->roi6Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 6: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi6Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi6Qp >= 0 ? pstCodingCfg->roi6Qp : pstCodingCfg->roi6DeltaQp,
			pstCodingCfg->roi6Area.left, pstCodingCfg->roi6Area.top,
			pstCodingCfg->roi6Area.right, pstCodingCfg->roi6Area.bottom);

	if (pstCodingCfg->roi7Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 7: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi7Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi7Qp >= 0 ? pstCodingCfg->roi7Qp : pstCodingCfg->roi7DeltaQp,
			pstCodingCfg->roi7Area.left, pstCodingCfg->roi7Area.top,
			pstCodingCfg->roi7Area.right, pstCodingCfg->roi7Area.bottom);

	if (pstCodingCfg->roi8Area.enable)
		VLOG_DEBUG("VencChn %d:  ROI 8: %s %d  %dx%d-%dx%d.\n",
			VeChn,
			pstCodingCfg->roi8Qp >= 0 ? "QP" : "QP Delta",
			pstCodingCfg->roi8Qp >= 0 ? pstCodingCfg->roi8Qp : pstCodingCfg->roi8DeltaQp,
			pstCodingCfg->roi8Area.left, pstCodingCfg->roi8Area.top,
			pstCodingCfg->roi8Area.right, pstCodingCfg->roi8Area.bottom);
}

static void VencRoiAttrSetting(AX_S32 VeChn, const AX_VENC_ROI_ATTR_S *pstRoiAttr,
				VENC_ROI_MB_AREA_T *pstRoiArea, VCEncCodingCtrl *pstCodingCfg)
{
	if (pstCodingCfg->gdrDuration == 0) {
		if (0 == pstRoiAttr->u32Index) {
			if (pstRoiAttr->bEnable) {
				pstCodingCfg->roi1Area.enable = 1;

				pstCodingCfg->roi1Area.top = pstRoiArea->u32TopMbs;
				pstCodingCfg->roi1Area.left = pstRoiArea->u32LeftMbs;
				pstCodingCfg->roi1Area.bottom = pstRoiArea->u32BottomMbs;
				pstCodingCfg->roi1Area.right = pstRoiArea->u32RightMbs;

				if (pstRoiAttr->bAbsQp) {
					pstCodingCfg->roi1Qp = pstRoiAttr->s32RoiQp;
					pstCodingCfg->roi1DeltaQp = 0;
				} else {
					pstCodingCfg->roi1DeltaQp = pstRoiAttr->s32RoiQp;
					pstCodingCfg->roi1Qp = -1;
				}
			} else {
				VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
				pstCodingCfg->roi1Area.enable = 0;
			}
		}
	} else {
		pstCodingCfg->roi1Area.enable = 0;
		VLOG_INFO("VencChn %d: Enable GDR, ROI-0 is not enable.\n", VeChn);
	}

	if (1 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi2Area.enable = 1;

			pstCodingCfg->roi2Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi2Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi2Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi2Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi2Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi2DeltaQp = 0;
			} else {
				pstCodingCfg->roi2DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi2Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi2Area.enable = 0;
		}
	}

	if (2 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi3Area.enable = 1;

			pstCodingCfg->roi3Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi3Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi3Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi3Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi3Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi3DeltaQp = 0;
			} else {
				pstCodingCfg->roi3DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi3Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi3Area.enable = 0;
		}
	}

	if (3 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi4Area.enable = 1;

			pstCodingCfg->roi4Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi4Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi4Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi4Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi4Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi4DeltaQp = 0;
			} else{
				pstCodingCfg->roi4DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi4Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi4Area.enable = 0;
		}
	}

	if (4 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi5Area.enable = 1;

			pstCodingCfg->roi5Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi5Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi5Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi5Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi5Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi5DeltaQp = 0;
			} else {
				pstCodingCfg->roi5DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi5Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi5Area.enable = 0;
		}
	}

	if (5 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi6Area.enable = 1;

			pstCodingCfg->roi6Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi6Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi6Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi6Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi6Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi6DeltaQp = 0;
			} else {
				pstCodingCfg->roi6DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi6Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi6Area.enable = 0;
		}
	}

	if (6 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi7Area.enable = 1;

			pstCodingCfg->roi7Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi7Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi7Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi7Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi7Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi7DeltaQp = 0;
			} else {
				pstCodingCfg->roi7DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi7Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi7Area.enable = 0;
		}
	}

	if (7 == pstRoiAttr->u32Index) {
		if (pstRoiAttr->bEnable) {
			pstCodingCfg->roi8Area.enable = 1;

			pstCodingCfg->roi8Area.top = pstRoiArea->u32TopMbs;
			pstCodingCfg->roi8Area.left = pstRoiArea->u32LeftMbs;
			pstCodingCfg->roi8Area.bottom = pstRoiArea->u32BottomMbs;
			pstCodingCfg->roi8Area.right = pstRoiArea->u32RightMbs;

			if (pstRoiAttr->bAbsQp) {
				pstCodingCfg->roi8Qp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi8DeltaQp = 0;
			} else {
				pstCodingCfg->roi8DeltaQp = pstRoiAttr->s32RoiQp;
				pstCodingCfg->roi8Qp = -1;
			}
		} else {
			VLOG_INFO("VencChn %d: Disable ROI-%d.\n", VeChn, pstRoiAttr->u32Index);
			pstCodingCfg->roi8Area.enable = 0;
		}
	}
}

static AX_BOOL IsVencFifoFull(VENC_CHN VeChn, FifoInst fifoObj)
{
	FifoRet fifoRet;

	fifoRet = AX_IsFifoFull(VeChn, fifoObj);
	if (FIFO_FULL == fifoRet) {
		//VLOG_ERROR("fifo is full.\n");
		return AX_TRUE;
	}

	return AX_FALSE;
}

static AX_BOOL IsVencFifoEmpty(VENC_CHN VeChn, FifoInst fifoObj)
{
	FifoRet fifoRet;

	fifoRet = AX_IsFifoEmpty(VeChn, fifoObj);
	if (FIFO_EMPTY == fifoRet) {
		//VLOG_ERROR("fifo is empty.\n");
		return AX_TRUE;
	}

	return AX_FALSE;
}

static AX_BOOL IsVencChnResReady(AX_S32 Vechn, AX_LINK_MODE_E enMode)
{
	AX_BOOL bReady = AX_FALSE;
	VENC_FRAME_INFO_S stKfifoFrameInfo;
	AX_S32 isEmpty = -1;

	if (NULL == gAvcHevcHandle[Vechn] || NULL == gChnInst[Vechn])
		return AX_FALSE;

	if (AX_NONLINK_MODE == enMode) {
		bReady = IsVencFifoEmpty(Vechn, gChnInst[Vechn]->inputQueue);
		if (bReady)
			return AX_FALSE;
	}else if (AX_LINK_MODE == enMode) {
		stKfifoFrameInfo.chnID = Vechn;
		isEmpty = ioctl(gChnInst[Vechn]->devFd, HANTRO_IOCH_FIFO_IS_EMPTY, &stKfifoFrameInfo);
		if (isEmpty)
			return AX_FALSE;
	}
	bReady = IsVencFifoFull(Vechn, gChnInst[Vechn]->outputQueue);
	if (bReady)
		return AX_FALSE;

	return AX_TRUE;
}

static AX_BOOL IsVencAllChnResNotReady(AX_U32 loopIndex)
{
	AX_BOOL bReady = AX_FALSE;
	AX_S32 i;

	for (i = 0; i < MAX_VENC_NUM; i++) {

		if (gModCtx.VencChnLoopIndex[i] != loopIndex)
			continue;

		if ((PT_H264 != gModCtx.enChnCodecType[i]) && (PT_H265 != gModCtx.enChnCodecType[i]))
			continue;

		if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[i])
			continue;

		if (NULL == gChnInst[i])
			continue;

		bReady = IsVencChnResReady(i, gChnInst[i]->stVencChnAttr.stVencAttr.enLinkMode);

		if (bReady)
			return AX_FALSE;
	}

	return AX_TRUE;
}

static AX_BOOL IsVencAllChnStoped(AX_U32 loopIndex)
{
	AX_S32 i;

	for (i = 0; i < MAX_VENC_NUM; i++) {

		if (gModCtx.VencChnLoopIndex[i] != loopIndex)
			continue;

		if ((PT_H264 != gModCtx.enChnCodecType[i]) && (PT_H265 != gModCtx.enChnCodecType[i]))
			continue;

		if (VENC_CHN_STATE_STARTED == gModCtx.enChnState[i])
			return AX_FALSE;
	}

	return AX_TRUE;
}

static AX_S32 VencGetOutputBufferFromPool(AX_S32 chnID,AX_S32 BufSize,AX_BLK *pOutBlkId,AX_U64 *pPhyAddr,AX_VOID **ppVirAddr)
{
	AX_S32 s32Ret = 0;
	AX_BLK u32BlkId = 0;
	AX_U64 u64PhyAddr = 0;
	AX_VOID *pVirAddr = NULL;

	u32BlkId = AX_POOL_GetBlock_Inter(AX_INVALID_POOLID,BufSize,NULL,AX_ID_VENC);

	if(u32BlkId == AX_INVALID_BLOCKID){
		VLOG_WARNING("VencChn %d: failed to get block of size %d for output buffer.\n\n",chnID,BufSize);
		return AX_ERR_VENC_NOMEM;
	}

	u64PhyAddr = AX_POOL_Handle2PhysAddr(u32BlkId);

	if(!u64PhyAddr){
		VLOG_ERROR("VencChn %d: size %d AX_POOL_Handle2PhysAddr failed.\n\n",chnID,BufSize);

		s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,AX_ID_VENC);
		if (s32Ret) {
			VLOG_ERROR("VencChn %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32BlkId, s32Ret);
		}
		return AX_ERR_VENC_NOMEM;
	}

	pVirAddr = AX_POOL_GetBlockVirAddr(u32BlkId);

	if(!pVirAddr){
		VLOG_ERROR("VencChn %d: size %d AX_POOL_GetBlockVirAddr failed.\n\n",chnID,BufSize);

		s32Ret = AX_POOL_ReleaseBlock_Inter(u32BlkId,AX_ID_VENC);
		if (s32Ret) {
			VLOG_ERROR("VencChn %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32BlkId, s32Ret);
		}
		return AX_ERR_VENC_NOMEM;
	}

	*pOutBlkId = u32BlkId;
	*pPhyAddr = u64PhyAddr;
	*ppVirAddr = pVirAddr;

	return AX_SUCCESS;
}

static AX_BOOL IsReadyEnterSleepMode(AX_VOID)
{
	AX_S32 i;
	AX_BOOL isReadyEnterSleep = AX_TRUE;

	for (i = 0; i < AX_VENC_LOOP_THREAD_NUM; i++) {
		isReadyEnterSleep &= gModCtx.isVencEnterSleep[i];
	}

	return isReadyEnterSleep;
}

AX_VOID *VencEncodeLoop(void *loopIndex)
{
	AX_S32 s32Ret = -1;
	FifoRet fifoRet = FIFO_OK;
	AX_S32 s32BufferSize = 0;
	VENC_GRP grpId = 0;
	AX_ENCODR_METADATA_INFO_S stFrameInfo;
	AX_ENCODR_METADATA_INFO_S stStreamInfo;
	VENC_FRAME_INFO_S stKfifoFrameInfo;
	const AX_FRAME_DESCRIPTOR_S *pstFrameDesc = NULL;
	AX_BOOL bAllChnResNotReady = AX_TRUE;
	AX_BOOL bIsFifoFull = AX_FALSE;
	AX_BLK u32BlkId[3]={0};//must set 0 by default
	AX_BLK u32OutBlkId = 0;
	AX_VENC_MOD_INSTANCE_S *pCtx = (AX_VENC_MOD_INSTANCE_S *)&gModCtx;

    AX_VENC_RC_MODE_E enRcMode;
	sigset_t set;
	sigemptyset(&set);
	sigaddset(&set,SIGALRM);
	pthread_sigmask(SIG_SETMASK,&set,NULL);
	pthread_t thread_id =0;
	AX_S32 threadIndex = (*(AX_S32 *)loopIndex);
	AX_CHAR threadname[40] = {0};

	sprintf(threadname,"VencEncodeLoop%d", threadIndex);
	/* set encode thread name */
	prctl(PR_SET_NAME, threadname);

	VLOG_INFO("VENC loop enter +++.\n");
	while(VENC_MOD_INITED != pCtx->enModState) {
		usleep(1);
	}
	VLOG_INFO("VENC loop enter ---.\n");

	thread_id = (int)syscall(__NR_gettid);

	VLOG_INFO("VencEncodeLoop%d tid=%d\n", threadIndex, thread_id);

	while (VENC_MOD_INITED == pCtx->enModState) {
		pCtx->isVencEncodeLoopCreate[threadIndex] = AX_TRUE;
		for (int chnID = 0; chnID < MAX_VENC_NUM; chnID++) {

			pthread_mutex_lock(&pCtx->stVencMutex[threadIndex]);
			while ((VENC_MOD_INITED == pCtx->enModState) && IsVencAllChnStoped(threadIndex)) {
				VLOG_INFO("venc loop thread_%d tid:%d wait +++.\n", threadIndex, thread_id);
				pthread_cond_wait(&pCtx->stVencCond[threadIndex], &pCtx->stVencMutex[threadIndex]);
				VLOG_INFO("venc loop thread_%d tid:%d wait ---.\n", threadIndex, thread_id);
				if (pCtx->isVencEncodeLoopExit[threadIndex] || pCtx->isVencEnterSleep[threadIndex])
					break;
			}
			pthread_mutex_unlock(&pCtx->stVencMutex[threadIndex]);

			if ((VENC_MOD_INITED != pCtx->enModState) || pCtx->isVencEncodeLoopExit[threadIndex]) {
				VLOG_INFO("venc encode loop thread_%d tid:%d exit...\n", threadIndex, thread_id);
				return NULL;
			}

			if (pCtx->isVencEnterSleep[threadIndex] == AX_TRUE) {

				if (pCtx->isVencWaitUnlock && IsReadyEnterSleepMode()) {
					AX_SYS_WakeUnlock(AX_ID_VENC);
					pCtx->isVencWaitUnlock = AX_FALSE;
				}
				usleep(1000);
				continue;
			}

			/*
			Should call usleep(1000) when there is not data to be processed
			in all channels to avoid excessive CPU loading.
			*/
			bAllChnResNotReady = IsVencAllChnResNotReady(threadIndex);
			if (bAllChnResNotReady) {
				usleep(1000);
				continue;
			}

			if (gModCtx.VencChnLoopIndex[chnID] != threadIndex) {
				continue;
			}

			if ((PT_H264 != gModCtx.enChnCodecType[chnID]) && (PT_H265 != gModCtx.enChnCodecType[chnID])) {
				continue;
			}

			pthread_mutex_lock(&gModCtx.stChnStateMutex[chnID]);

			if (VENC_CHN_STATE_STARTED != gModCtx.enChnState[chnID]) {
				pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
				continue;
			}

			if (!IsVencChnResReady(chnID, gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode)) {
				pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
				continue;
			}

			/* peek one frame from input queue */
			if (AX_LINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				/*peek should never failed*/
				stKfifoFrameInfo.chnID = chnID;
				s32Ret = ioctl(gChnInst[chnID]->devFd, HANTRO_IOCH_FIFO_PEEK, &stKfifoFrameInfo);
				if (0 != s32Ret) {
					VLOG_DEBUG("VencChn %d: ioctl peek fifo failed,ret=%d.\n", chnID,s32Ret);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				pstFrameDesc = (AX_FRAME_DESCRIPTOR_S *)AX_POOL_GetMetaVirAddr(stKfifoFrameInfo.blockID);

				/*shall never fail*/
				if (!pstFrameDesc) {
					VLOG_ERROR("VencChn %d, failed to get frame info from metadata\n", chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				if (0 == pstFrameDesc->stFrameInfo.stVFrame.u64PhyAddr[0]) {
					VLOG_DEBUG("VencChn %d: invalid phyAddr[0].\n", chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				stFrameInfo.inputFrameType = FRAME_NORMAL_TYPE;
				stFrameInfo.inputFrameInfo.stFrameInfo = pstFrameDesc->stFrameInfo;

				for (int i = 0; i < 3; i++) {
					if (stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[i]) {
						stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[i] -= VENC_ADDR_OFFSET;
					}
				}

				if (pstFrameDesc->stFrameInfo.stVFrame.u32Width != gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc ||
					pstFrameDesc->stFrameInfo.stVFrame.u32Height != gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc) {
					VLOG_DEBUG("VencChn %d: frame width/height is invalid,input.width=%d,input.height=%d,input.stride=%d,chn.width=%d,chn.height=%d\n",
						chnID,
						pstFrameDesc->stFrameInfo.stVFrame.u32Width,
						pstFrameDesc->stFrameInfo.stVFrame.u32Height,
						pstFrameDesc->stFrameInfo.stVFrame.u32PicStride[0],
						gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc,
						gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc);
					goto DROP_FRAME;
				}
			} else if (AX_NONLINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				/*peek shall never failed*/
				fifoRet = AX_Fifo_Peek(chnID, gChnInst[chnID]->inputQueue, &stFrameInfo, 0);
				if (FIFO_OK != fifoRet) {
					VLOG_ERROR("VencChn %d: input fifo peek failed,ret=%d.\n", chnID,fifoRet);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}
			}

			// frame rate control: reduce frame mode
            if (AX_FALSE == gChnInst[chnID]->bInstant)
			{
				s32Ret = VencIsFrameRateCtrlDrop(gChnInst[chnID]->src_frameRate, gChnInst[chnID]->dst_frameRate, gChnInst[chnID]->u64FrameEncodeIndex);
				if (s32Ret)
				{
					VLOG_DEBUG("VencChn %d: encode framerate control: drop index[%lld] frame\n",
                    	chnID, gChnInst[chnID]->u64FrameEncodeIndex);
					gChnInst[chnID]->u64FrameEncodeIndex++;
					goto DROP_FRAME;
				}
			}

ENLARGE_FRAME:

			/*shall check whether out fifo is full in enlarge frame mode*/
			if(gChnInst[chnID]->enStateMachine == VENC_STATE_MACHINE_ENLARGE){
				bIsFifoFull = IsVencFifoFull(chnID, gChnInst[chnID]->outputQueue);
				if(bIsFifoFull){
					VLOG_DEBUG("VencChn %d: enlarge frame mode but output fifo is full,try next time\n", chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}
			}

			if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
				s32BufferSize = (gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicWidthSrc * gChnInst[chnID]->stVencChnAttr.stVencAttr.u32PicHeightSrc * 3/2);

				AX_U64 u64OutBufPhyAddr = 0;
				AX_VOID *pOutBufVirAddr = NULL;

				s32Ret = VencGetOutputBufferFromPool(chnID,s32BufferSize,&u32OutBlkId,&u64OutBufPhyAddr,&pOutBufVirAddr);

				if(AX_SUCCESS != s32Ret){
					VLOG_WARNING("VencChn %d: failed to get output buffer from pool,try next time.\n\n",chnID);
					gChnInst[chnID]->u64TotalBlkGetFailNum++;
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				gAvcHevcHandle[chnID]->encIn.busOutBuf[0] = u64OutBufPhyAddr - VENC_ADDR_OFFSET;
				gAvcHevcHandle[chnID]->encIn.pOutBuf[0] = pOutBufVirAddr;
				gAvcHevcHandle[chnID]->encIn.outBufSize[0] = s32BufferSize;

				VLOG_DEBUG("VencChn %d: output buffer success,BlkId=0x%x.\n\n",chnID,u32OutBlkId);
			}

			VLOG_DEBUG("VencChn %d out: phyAddr=0x%lx, virAddr=%p, size=%u.\n",
						chnID, gAvcHevcHandle[chnID]->encIn.busOutBuf[0],
						gAvcHevcHandle[chnID]->encIn.pOutBuf[0],
						gAvcHevcHandle[chnID]->encIn.outBufSize[0]);
            enRcMode = gChnInst[chnID]->stVencChnAttr.stRcAttr.enRcMode;

			// calculate instantaneous fps and bps
			if (gChnInst[chnID]->enType == PT_H264 || gChnInst[chnID]->enType == PT_H265)
			{
				if (gChnInst[chnID]->u64TotalEncodeNum == 0 )
				{
					gettimeofday(&gChnInst[chnID]->timeGetFrmEncodeStart, NULL);
					gChnInst[chnID]->timeGetFrmEncodeStartForInstantBps = gChnInst[chnID]->timeGetFrmEncodeStart;

                    if ((VENC_RC_MODE_H264CVBR == enRcMode) || (VENC_RC_MODE_H265CVBR == enRcMode))
                    {
                        gChnInst[chnID]->timeGetShortTermFrmEncodeStart = gChnInst[chnID]->timeGetFrmEncodeStart;
                        gChnInst[chnID]->timeGetLongTermFrmEncodeStart = gChnInst[chnID]->timeGetFrmEncodeStart;
                    }
				}
				else
				{
					gChnInst[chnID]->pEncoder->pfnUpdateFpsBr(gChnInst[chnID]);
                    if ((VENC_RC_MODE_H264CVBR == enRcMode) || (VENC_RC_MODE_H265CVBR == enRcMode))
                    {
                        gChnInst[chnID]->pEncoder->pfnUpdateCvbrShortBps(gChnInst[chnID]);
                        gChnInst[chnID]->pEncoder->pfnUpdateCvbrLongBps(gChnInst[chnID]);
                    }
				}
			}

			// rate jam strategy
			gChnInst[chnID]->u64EncodeFrmNumForInstantaneousBps++;
			if (gAvcHevcHandle[chnID]->stRateJamStrategyParam.bDropFrmEn)
			{
				s32Ret = VencRateJamProcess(gAvcHevcHandle[chnID], chnID);
				if (s32Ret != AX_SUCCESS)
				{
					/* release block used by output buffer */
					if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
						s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId, AX_ID_VENC);
						if (s32Ret) {
							VLOG_DEBUG("VencChn %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
						}
					}
					goto DROP_FRAME;
				}
			}

			/* encode one frame */
			s32Ret = VencProcess(chnID, gAvcHevcHandle[chnID], &stFrameInfo, &stStreamInfo);
			if (AX_SUCCESS != s32Ret) {
				/* When ringbuffer is not enough,will try next time instead of dropping this frame*/
				if(AX_ERR_VENC_NOMEM == s32Ret){
					VLOG_WARNING("VencChn %d: stream buffer is not enough,try next time.\n\n",chnID);
					pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
					continue;
				}

				VLOG_DEBUG("VencChn %d: encode error(%d).\n", chnID, s32Ret);

				/* release block used by output buffer */
				if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
					s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId, AX_ID_VENC);
					if (s32Ret) {
						VLOG_DEBUG("VencChn %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
					}
				}
				goto DROP_FRAME;
			}

            AX_VENC_RC_MODE_E enRcMode = gChnInst[chnID]->stVencChnAttr.stRcAttr.enRcMode;
			gChnInst[chnID]->u64TotalEncodeNum++;
			gChnInst[chnID]->u64PerSecondStrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
            if ((VENC_RC_MODE_H264CVBR == enRcMode) || (VENC_RC_MODE_H265CVBR == enRcMode))
            {
                gChnInst[chnID]->u64ShortTermtrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
                gChnInst[chnID]->u64LongTermtrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
            }
            gChnInst[chnID]->u64StatisticalEncodeFrm++;
			gChnInst[chnID]->u64InstantaneousEncodeStrmSize += stStreamInfo.outputStreamInfo.stPackage.u32Len;
			gChnInst[chnID]->u64FrameEncodeIndex++;

			if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL){
				ringbuffer_write_finalize(chnID, gChnInst[chnID]->pstRingBuf, stStreamInfo.outputStreamInfo.stPackage.u32Len);
			}

			/* enqueue one nalu stream to output queue */
			fifoRet = AX_Fifo_Push(chnID, gChnInst[chnID]->outputQueue, stStreamInfo, 0);
			if (FIFO_OK != fifoRet) {
				/* shall never happen because it has been checked before */
				VLOG_DEBUG("VencChn %d: output fifo push failed\n", chnID);

				/* release block used by output buffer */
				if(gChnInst[chnID]->stVencChnAttr.stVencAttr.enMemSource == AX_MEMORY_SOURCE_POOL){
					s32Ret = AX_POOL_ReleaseBlock_Inter(u32OutBlkId, AX_ID_VENC);
					if (s32Ret) {
						VLOG_ERROR("VencChn %d: ReleaseBlock for output buffer failed,blockid(0x%x),s32Ret:0x%x\n", chnID, u32OutBlkId, s32Ret);
					}
				}
				goto DROP_FRAME;
			}
			gChnInst[chnID]->u64LeftStreamBytes += stStreamInfo.outputStreamInfo.stPackage.u32Len;

			// frame rate control: enlarge frame mode
			if (AX_FALSE == gChnInst[chnID]->bInstant)
			{
				s32Ret = VencIsFrameRateCtrlEnlarge(gChnInst[chnID]->src_frameRate, gChnInst[chnID]->dst_frameRate, gChnInst[chnID]->u64FrameEncodeIndex);
				if (s32Ret)
				{
					VLOG_DEBUG("VencChn %d: encode framerate control: duplicate index[%lld] frame\n",
                    	chnID, gChnInst[chnID]->u64FrameEncodeIndex);

					/*state machine switch to enlarge frame mode*/
					gChnInst[chnID]->enStateMachine = VENC_STATE_MACHINE_ENLARGE;

					goto ENLARGE_FRAME;
				}
			}

			grpId = pCtx->vencGrpId[chnID];
			if((MAX_VENC_GRP_NUM > grpId) && (grpId >= 0)) {
				pthread_mutex_lock(&pCtx->stVencSelectGrp[grpId].stEncSelectMutex);
				pthread_cond_signal(&pCtx->stVencSelectGrp[grpId].stEncSelectCond);
				pthread_mutex_unlock(&pCtx->stVencSelectGrp[grpId].stEncSelectMutex);
			} else {
				pthread_mutex_lock(&pCtx->stEncSelectMutex);
				pthread_cond_signal(&pCtx->stEncSelectCond);
				pthread_mutex_unlock(&pCtx->stEncSelectMutex);
			}

DROP_FRAME:

			/*state machine switch to normal state*/
			gChnInst[chnID]->enStateMachine = VENC_STATE_MACHINE_NORMAL;

			/* pop one frame from input queue*/
			if (AX_LINK_MODE == gChnInst[chnID]->stVencChnAttr.stVencAttr.enLinkMode) {
				/*pop should never failed*/
				s32Ret = ioctl(gChnInst[chnID]->devFd, HANTRO_IOCH_FIFO_POP, &stKfifoFrameInfo);
				if (0 != s32Ret) {
					VLOG_DEBUG("VencChn %d: ioctl fifo pop failed,ret=%d.\n", chnID,s32Ret);
				}
				gChnInst[chnID]->u64TotalRecvFrameNum++;
			}else {
				/*pop should never failed*/
				fifoRet = AX_Fifo_Pop(chnID, gChnInst[chnID]->inputQueue, &stFrameInfo, 0);
				if (FIFO_OK != fifoRet) {
					VLOG_ERROR("VencChn %d: input fifo pop failed,ret=%d.\n", chnID,fifoRet);
				}
			}

			if (stFrameInfo.inputFrameType == FRAME_NORMAL_TYPE)
			{
				/*get BlkId from struct AX_VIDEO_FRAME_S*/
				for(int i = 0; i < 3; i++)
				{
					u32BlkId[i] = stFrameInfo.inputFrameInfo.stFrameInfo.stVFrame.u32BlkId[i];

					if(u32BlkId[i] > 0){
						s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], AX_ID_VENC);
						if (0 != s32Ret) {
							VLOG_DEBUG("VencChn %d: AX_POOL_DecreaseRefCnt_Inter block_%d(0x%x) err(0x%x).\n", chnID, i, u32BlkId[i], s32Ret);
						}
					}
				}
			}
			else if (stFrameInfo.inputFrameType == FRAME_USER_TYPE)
			{
				/*get BlkId from struct AX_VIDEO_FRAME_S*/
				for(int i = 0; i < 3; i++)
				{
					u32BlkId[i] = stFrameInfo.inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u32BlkId[i];

					if(u32BlkId[i] > 0){
						s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId[i], AX_ID_VENC);
						if (0 != s32Ret) {
							VLOG_DEBUG("VencChn %d: AX_POOL_DecreaseRefCnt_Inter block_%d(0x%x) err(0x%x).\n", chnID, i, u32BlkId[i], s32Ret);
						}
					}
				}
			}
			gChnInst[chnID]->u64TotalReleaseFrameNum++;
			pthread_mutex_unlock(&gModCtx.stChnStateMutex[chnID]);
		}
	}
	return NULL;
}

AX_VENC_ENCODER_S gVencEncoder = {
	.enType = PT_H264,
	.pfnCreateChn = VencCreateChn,
	.pfnDestroyChn = VencDestroyChn,

	.pfnSendFrame = VencSendFrame,
	.pfnSendFrameEx = VencSendFrameEx,

	.pfnGetStream = VencGetStream,
	.pfnReleaseStream = VencReleaseStream,

	.pfnStartRecvFrame = VencStartRecvFrame,
	.pfnStopRecvFrame = VencStopRecvFrame,

#if 0
	.pfnSetOsdLayer = VencSetOsdLayer,
	.pfnRefreshOsdLayer = VencRefreshOsdLayer,
	.pfnResetOsd = VencResetOsd,
#endif

	.pfnSetRoiAttr = VencSetRoiAttr,
	.pfnGetRoiAttr = VencGetRoiAttr,

	.pfnSetRcParam = VencSetRcParam,
	.pfnGetRcParam = VencGetRcParam,

	.pfnSetChnAttr = VencSetChnAttr,
	.pfnGetChnAttr = VencGetChnAttr,

	.pfnSetSpsVuiParam = VencSetSpsVuiParam,
	.pfnGetSpsVuiParam = VencGetSpsVuiParam,

	.pfnSetRateJamStrategyParam = VencSetRateJamStrategyParam,
	.pfnGetRateJamStrategyParam = VencGetRateJamStrategyParam,

	.pfnSetSuperFrameCfg = VencSetSuperFrameCfg,
	.pfnGetSuperFrameCfg = VencGetSuperFrameCfg,

	.pfnInsertUserData = VencInsertUserData,
	.pfnRequestIDR = VencRequestIDR,
	.pfnQueryStatus = VencQueryStatus,

	.pfnUpdateFpsBr = VencUpdateFpsBr,		// update realtime frame rate and bit rate

    .pfnUpdateCvbrShortBps = VencUpdateCvbrShortBps,
    .pfnUpdateCvbrLongBps = VencUpdateCvbrLongBps,

	.pfnSetJpegParam = NULL,
	.pfnGetJpegParam = NULL
};

static int VencRcParamCheck(AX_AVCHEVC_HANDLE_S *pHandle, const AX_VENC_RC_PARAM_S *pstRcParam)
{
    if (NULL == pstRcParam) {
		VLOG_ERROR(" Param is null pointer. \n");
		return AX_ERR_VENC_NULL_PTR;
    }

	if (NULL == pHandle) {
		VLOG_ERROR(" pHandle param is null pointer.\n");
		return AX_ERR_VENC_NULL_PTR;
    }

	AX_S32 VeChn = pHandle->VeChn;

	switch (pHandle->codecFormat)
	{
	case VCENC_VIDEO_CODEC_HEVC:
	{
		if (VENC_RC_MODE_H265CBR == pHandle->enRcMode) {
			if (pstRcParam->stH265Cbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265Cbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265Cbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265Cbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH265Cbr.u32MaxIprop > 100) {
				VLOG_ERROR("VencChn %d: setRcParamCheck u32MaxIprop range over 100: %u.\n",
						VeChn,
						pstRcParam->stH265Cbr.u32MaxIprop);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265Cbr.u32MinIprop > pstRcParam->stH265Cbr.u32MaxIprop) {
				VLOG_ERROR("VencChn %d: setRcParamCheck u32MinIprop range over u32MaxIprop: %u.\n",
						VeChn,
						pstRcParam->stH265Cbr.u32MinIprop);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH265Cbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH265Cbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH265Cbr.u32MaxIQp < pstRcParam->stH265Cbr.u32MinIQp) ||
				(pstRcParam->stH265Cbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH265Cbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH265Cbr.u32MaxQp < pstRcParam->stH265Cbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParamCheckalid qp range: MinIQp=%u, \
							MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
						VeChn,
						pstRcParam->stH265Cbr.u32MinIQp,
						pstRcParam->stH265Cbr.u32MaxIQp,
						pstRcParam->stH265Cbr.u32MinQp,
						pstRcParam->stH265Cbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH265Cbr.u32BitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH265Cbr.u32BitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),      \
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH265Cbr.u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH265Cbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH265Cbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH265Cbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		} else if (VENC_RC_MODE_H265VBR == pHandle->enRcMode) {
			if (pstRcParam->stH265Vbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265Vbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265Vbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265Vbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH265Vbr.s32IntraQpDelta > VENC_MAX_INTRADELTAQP ||
				pstRcParam->stH265Vbr.s32IntraQpDelta < VENC_MIN_INTRADELTAQP) {
				VLOG_ERROR("VencChn %d: setRcParamCheck s32IntraQpDelta range over [-51.51]: %u.\n",
						VeChn,
						pstRcParam->stH265Vbr.s32IntraQpDelta);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH265Vbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH265Vbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH265Vbr.u32MaxIQp < pstRcParam->stH265Vbr.u32MinIQp) ||
				(pstRcParam->stH265Vbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH265Vbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH265Vbr.u32MaxQp < pstRcParam->stH265Vbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
				VeChn,
				pstRcParam->stH265Vbr.u32MinIQp,
				pstRcParam->stH265Vbr.u32MaxIQp,
				pstRcParam->stH265Vbr.u32MinQp,
				pstRcParam->stH265Vbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH265Vbr.u32MaxBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH265Vbr.u32MaxBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),    \
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH265Vbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH265Vbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH265Vbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH265Vbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
		else if (VENC_RC_MODE_H265AVBR == pHandle->enRcMode) {
			if (pstRcParam->stH265AVbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265AVbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265AVbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265AVbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH265AVbr.s32IntraQpDelta > VENC_MAX_INTRADELTAQP ||
				pstRcParam->stH265AVbr.s32IntraQpDelta < VENC_MIN_INTRADELTAQP) {
				VLOG_ERROR("VencChn %d: setRcParamCheck s32IntraQpDelta range over [-51.51]: %u.\n",
						VeChn,
						pstRcParam->stH265AVbr.s32IntraQpDelta);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH265AVbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH265AVbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH265AVbr.u32MaxIQp < pstRcParam->stH265Vbr.u32MinIQp) ||
				(pstRcParam->stH265AVbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH265AVbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH265AVbr.u32MaxQp < pstRcParam->stH265Vbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
				VeChn,
				pstRcParam->stH265AVbr.u32MinIQp,
				pstRcParam->stH265AVbr.u32MaxIQp,
				pstRcParam->stH265AVbr.u32MinQp,
				pstRcParam->stH265AVbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH265AVbr.u32MaxBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH265AVbr.u32MaxBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),    \
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH265AVbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH265AVbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH265AVbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH265AVbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
        else if (VENC_RC_MODE_H265CVBR == pHandle->enRcMode) {
           if (pstRcParam->stH265CVbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
               VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
                       VeChn,
                       pstRcParam->stH265CVbr.u32SrcFrameRate);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }
           if (pstRcParam->stH265CVbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
               VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
                       VeChn,
                       pstRcParam->stH265CVbr.fr32DstFrameRate);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           if ((pstRcParam->stH265CVbr.u32MinIQp < VENC_MIN_QP) ||
               (pstRcParam->stH265CVbr.u32MaxIQp > VENC_MAX_QP) ||
               (pstRcParam->stH265CVbr.u32MaxIQp < pstRcParam->stH265CVbr.u32MinIQp) ||
               (pstRcParam->stH265CVbr.u32MinQp < VENC_MIN_QP) ||
               (pstRcParam->stH265CVbr.u32MaxQp > VENC_MAX_QP) ||
               (pstRcParam->stH265CVbr.u32MaxQp < pstRcParam->stH265CVbr.u32MinQp))
           {
               VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
               VeChn,
               pstRcParam->stH265CVbr.u32MinIQp,
               pstRcParam->stH265CVbr.u32MaxIQp,
               pstRcParam->stH265CVbr.u32MinQp,
               pstRcParam->stH265CVbr.u32MaxQp);

               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           //BitRate setting
           if (pstRcParam->stH265CVbr.u32MaxBitRate < VENC_MIN_BITRATE ||
               pstRcParam->stH265CVbr.u32MaxBitRate > VENC_MAX_BITRATE)
           {
               VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps), \
                           MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
                   VeChn, pstRcParam->stH265CVbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           //IDR interval, 0: only first frame is IDR
           if (pstRcParam->stH265CVbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
               pstRcParam->stH265CVbr.u32Gop > VENC_MAX_IDR_INTERVAL)
           {
               VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
                   VeChn, pstRcParam->stH265CVbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }
       }
        else if (VENC_RC_MODE_H265FIXQP == pHandle->enRcMode) {
			if (pstRcParam->stH265FixQp.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265FixQp.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265FixQp.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265FixQp.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH265FixQp.u32IQp < VENC_MIN_QP) ||
				(pstRcParam->stH265FixQp.u32IQp > VENC_MAX_QP) ||
				(pstRcParam->stH265FixQp.u32PQp < VENC_MIN_QP) ||
				(pstRcParam->stH265FixQp.u32PQp > VENC_MAX_QP) ||
				(pstRcParam->stH265FixQp.u32BQp < VENC_MIN_QP) ||
				(pstRcParam->stH265FixQp.u32BQp > VENC_MAX_QP))
            {
                VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: u32IQp=%u, u32PQp=%u, u32BQp=%u,\n",
                    VeChn,
                    pstRcParam->stH265FixQp.u32IQp,
                    pstRcParam->stH265FixQp.u32PQp,
                    pstRcParam->stH265FixQp.u32BQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
            }
            if (pstRcParam->stH265FixQp.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH265FixQp.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH265FixQp.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
        else if (VENC_RC_MODE_H265QPMAP == pHandle->enRcMode) {
			// VIDEO_QPMAP_CTBRC_RANGE_CHECK(VeChn, pstRcParam->stH265QpMap.enCtbRcMode, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE);
            // VIDEO_QPMAP_QPTYPE_RANGE_CHECK(VeChn, pstRcParam->stH265QpMap.enQpmapQpType, VENC_MIN_QPMAP_QPTYPE, VENC_MAX_QPMAP_QPTYPE);
            // VIDEO_QPMAP_BLOCK_UNIT_RANGE_CHECK(VeChn, pstRcParam->stH265QpMap.u32QpmapBlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H264_QPMAP_BLOCK_UNIT);
			if (pstRcParam->stH265QpMap.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265QpMap.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH265QpMap.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH265QpMap.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

            if (pstRcParam->stH265QpMap.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH265QpMap.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH265QpMap.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
            if (pstRcParam->stH265QpMap.u32TargetBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH265QpMap.u32TargetBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),	\
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH265QpMap.u32TargetBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
        else {
			VLOG_ERROR("VencChn %d: Invalid Rc mode (%d).\n", VeChn, pHandle->enRcMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;
	}
	case VCENC_VIDEO_CODEC_H264:
	{
		if (VENC_RC_MODE_H264CBR == pHandle->enRcMode) {
			if (pstRcParam->stH264Cbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264Cbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264Cbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264Cbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH264Cbr.u32MaxIprop > 100) {
				VLOG_ERROR("VencChn %d: setRcParamCheck u32MaxIprop range over 100: %u.\n",
						VeChn,
						pstRcParam->stH264Cbr.u32MaxIprop);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264Cbr.u32MinIprop > pstRcParam->stH265Cbr.u32MaxIprop) {
				VLOG_ERROR("VencChn %d: setRcParamCheck u32MinIprop range over u32MaxIprop: %u.\n",
						VeChn,
						pstRcParam->stH264Cbr.u32MinIprop);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH264Cbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH264Cbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH264Cbr.u32MaxIQp < pstRcParam->stH264Cbr.u32MinIQp) ||
				(pstRcParam->stH264Cbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH264Cbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH264Cbr.u32MaxQp < pstRcParam->stH264Cbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
                    VeChn,
                    pstRcParam->stH264Cbr.u32MinIQp,
                    pstRcParam->stH264Cbr.u32MaxIQp,
                    pstRcParam->stH264Cbr.u32MinQp,
                    pstRcParam->stH264Cbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH264Cbr.u32BitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH264Cbr.u32BitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),	\
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH264Cbr.u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH264Cbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH264Cbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH264Cbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		} else if (VENC_RC_MODE_H264VBR == pHandle->enRcMode) {
			if (pstRcParam->stH264Vbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264Vbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264Vbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264Vbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH264Vbr.s32IntraQpDelta > VENC_MAX_INTRADELTAQP ||
				pstRcParam->stH264Vbr.s32IntraQpDelta < VENC_MIN_INTRADELTAQP) {
				VLOG_ERROR("VencChn %d: setRcParamCheck s32IntraQpDelta range over [-51.51]: %u.\n",
						VeChn,
						pstRcParam->stH264Vbr.s32IntraQpDelta);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH264Vbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH264Vbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH264Vbr.u32MaxIQp < pstRcParam->stH264Vbr.u32MinIQp) ||
				(pstRcParam->stH264Vbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH264Vbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH264Vbr.u32MaxQp < pstRcParam->stH264Vbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
                    VeChn,
                    pstRcParam->stH264Vbr.u32MinIQp,
                    pstRcParam->stH264Vbr.u32MaxIQp,
                    pstRcParam->stH264Vbr.u32MinQp,
                    pstRcParam->stH264Vbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH264Vbr.u32MaxBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH264Vbr.u32MaxBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),	\
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH264Vbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH264Vbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH264Vbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH264Vbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
		else if (VENC_RC_MODE_H264AVBR == pHandle->enRcMode) {
			if (pstRcParam->stH264AVbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264AVbr.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264AVbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264AVbr.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if (pstRcParam->stH264AVbr.s32IntraQpDelta > VENC_MAX_INTRADELTAQP ||
				pstRcParam->stH264AVbr.s32IntraQpDelta < VENC_MIN_INTRADELTAQP) {
				VLOG_ERROR("VencChn %d: setRcParamCheck s32IntraQpDelta range over [-51.51]: %u.\n",
						VeChn,
						pstRcParam->stH264AVbr.s32IntraQpDelta);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			if ((pstRcParam->stH264AVbr.u32MinIQp < VENC_MIN_QP) ||
				(pstRcParam->stH264AVbr.u32MaxIQp > VENC_MAX_QP) ||
				(pstRcParam->stH264AVbr.u32MaxIQp < pstRcParam->stH264Vbr.u32MinIQp) ||
				(pstRcParam->stH264AVbr.u32MinQp < VENC_MIN_QP) ||
				(pstRcParam->stH264AVbr.u32MaxQp > VENC_MAX_QP) ||
				(pstRcParam->stH264AVbr.u32MaxQp < pstRcParam->stH264Vbr.u32MinQp))
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
                    VeChn,
                    pstRcParam->stH264AVbr.u32MinIQp,
                    pstRcParam->stH264AVbr.u32MaxIQp,
                    pstRcParam->stH264AVbr.u32MinQp,
                    pstRcParam->stH264AVbr.u32MaxQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//BitRate setting
			if (pstRcParam->stH264AVbr.u32MaxBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH264AVbr.u32MaxBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),	\
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH264AVbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

			//IDR interval, 0: only first frame is IDR
			if (pstRcParam->stH264AVbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH264AVbr.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH264AVbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
		}
        else if (VENC_RC_MODE_H264CVBR == pHandle->enRcMode) {
           if (pstRcParam->stH264CVbr.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
               VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
                       VeChn,
                       pstRcParam->stH264CVbr.u32SrcFrameRate);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }
           if (pstRcParam->stH264CVbr.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
               VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
                       VeChn,
                       pstRcParam->stH264CVbr.fr32DstFrameRate);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           if ((pstRcParam->stH264CVbr.u32MinIQp < VENC_MIN_QP) ||
               (pstRcParam->stH264CVbr.u32MaxIQp > VENC_MAX_QP) ||
               (pstRcParam->stH264CVbr.u32MaxIQp < pstRcParam->stH264CVbr.u32MinIQp) ||
               (pstRcParam->stH264CVbr.u32MinQp < VENC_MIN_QP) ||
               (pstRcParam->stH264CVbr.u32MaxQp > VENC_MAX_QP) ||
               (pstRcParam->stH264CVbr.u32MaxQp < pstRcParam->stH264CVbr.u32MinQp))
           {
               VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: MinIQp=%u, MaxIQp=%u, MinQp=%u, MaxQp=%u.\n",
                   VeChn,
                   pstRcParam->stH264CVbr.u32MinIQp,
                   pstRcParam->stH264CVbr.u32MaxIQp,
                   pstRcParam->stH264CVbr.u32MinQp,
                   pstRcParam->stH264CVbr.u32MaxQp);

               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           //BitRate setting
           if (pstRcParam->stH264CVbr.u32MaxBitRate < VENC_MIN_BITRATE ||
               pstRcParam->stH264CVbr.u32MaxBitRate > VENC_MAX_BITRATE)
           {
               VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps), \
                           MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
                   VeChn, pstRcParam->stH264CVbr.u32MaxBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

               return AX_ERR_VENC_ILLEGAL_PARAM;
           }

           //IDR interval, 0: only first frame is IDR
           if (pstRcParam->stH264CVbr.u32Gop < VENC_MIN_IDR_INTERVAL ||
               pstRcParam->stH264CVbr.u32Gop > VENC_MAX_IDR_INTERVAL)
           {
               VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
                   VeChn, pstRcParam->stH264CVbr.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
               return AX_ERR_VENC_ILLEGAL_PARAM;
           }
       }
		else if (VENC_RC_MODE_H264FIXQP == pHandle->enRcMode) {
			if (pstRcParam->stH264FixQp.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264FixQp.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264FixQp.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264FixQp.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

            if ((pstRcParam->stH264FixQp.u32IQp < VENC_MIN_QP) ||
				(pstRcParam->stH264FixQp.u32IQp > VENC_MAX_QP) ||
				(pstRcParam->stH264FixQp.u32PQp < VENC_MIN_QP) ||
				(pstRcParam->stH264FixQp.u32PQp > VENC_MAX_QP) ||
				(pstRcParam->stH264FixQp.u32BQp < VENC_MIN_QP) ||
				(pstRcParam->stH264FixQp.u32BQp > VENC_MAX_QP))
            {
                VLOG_ERROR("VencChn %d: setRcParam, Invalid qp range: u32IQp=%u, u32PQp=%u, u32BQp=%u,\n",
                    VeChn,
                    pstRcParam->stH264FixQp.u32IQp,
                    pstRcParam->stH264FixQp.u32PQp,
                    pstRcParam->stH264FixQp.u32BQp);

				return AX_ERR_VENC_ILLEGAL_PARAM;
            }

            if (pstRcParam->stH264FixQp.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH264FixQp.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH264FixQp.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

		}
        else if (VENC_RC_MODE_H264QPMAP == pHandle->enRcMode) {
            // VIDEO_QPMAP_CTBRC_RANGE_CHECK(VeChn, pstRcParam->stH264QpMap.enCtbRcMode, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE);
            // VIDEO_QPMAP_QPTYPE_RANGE_CHECK(VeChn, pstRcParam->stH264QpMap.enQpmapQpType, VENC_MIN_QPMAP_QPTYPE, VENC_MAX_QPMAP_QPTYPE);
            // VIDEO_QPMAP_BLOCK_UNIT_RANGE_CHECK(VeChn, pstRcParam->stH264QpMap.u32QpmapBlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H264_QPMAP_BLOCK_UNIT);
			if (pstRcParam->stH264QpMap.u32SrcFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck srcFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264QpMap.u32SrcFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}
			if (pstRcParam->stH264QpMap.fr32DstFrameRate > VENC_MAX_FRAME_RATE) {
				VLOG_ERROR("VencChn %d: setRcParamCheck dstFrameRate range over 240: %u.\n",
						VeChn,
						pstRcParam->stH264QpMap.fr32DstFrameRate);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

             if (pstRcParam->stH264QpMap.u32Gop < VENC_MIN_IDR_INTERVAL ||
				pstRcParam->stH264QpMap.u32Gop > VENC_MAX_IDR_INTERVAL)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Invalid GOP Length=%d, Rang in [%u, %u]\n",
					VeChn, pstRcParam->stH264FixQp.u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

            if (pstRcParam->stH264QpMap.u32TargetBitRate < VENC_MIN_BITRATE ||
				pstRcParam->stH264QpMap.u32TargetBitRate > VENC_MAX_BITRATE)
			{
				VLOG_ERROR("VencChn %d: setRcParam, Input Bitrate=%d(kbps),	\
							MinBitrate=%d(kbps),MaxBitrate=%d(kbps).\n",
					VeChn, pstRcParam->stH264QpMap.u32TargetBitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

				return AX_ERR_VENC_ILLEGAL_PARAM;
			}

		}
        else {
			VLOG_ERROR("VencChn %d: setRcParam, Invalid Rc mode (%d).\n", VeChn, pHandle->enRcMode);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		break;
	}
	default:
		VLOG_ERROR("VencChn %d: setRcParam, Invalid CodecFormat(%d).\n", VeChn, pHandle->codecFormat);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	return AX_SUCCESS;
}
