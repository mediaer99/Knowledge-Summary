
#include "ax_video_enc.h"
#include "ax_venc_log.h"
#include "ax_sys_api.h"
#include "ax_video_enc_utils.h"
#include "ax_video_enc_pic_config.h"
#include "ax_video_enc_init.h"

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)

#define DEBUG_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_enc.c %s %d "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_video_enc.c %s %d Error! "str"\n", \
        gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define VENC_ENCODE_MUTEX_LOCK(lock) \
    do { \
        int res = pthread_mutex_lock(&lock); \
        if (0 != res) { \
            VLOG_ERROR("VENC_ENCODE_MUTEX_LOCK failed\n"); \
        } \
    } while(0)

#define VENC_ENCODE_MUTEX_UNLOCK(lock) \
    do { \
        int res = pthread_mutex_unlock(&lock); \
        if (0 != res) { \
            VLOG_ERROR("VENC_ENCODE_MUTEX_UNLOCK failed\n"); \
        } \
    } while(0)


#define ADAPTIVE_ADJUST_MARGIN

#ifdef ADAPTIVE_ADJUST_MARGIN

#define GLB_MMAP_PATH "/dev/mem"
#define VENC_GLB_BASE (0x4030000)
#define MARGIN_CLIP3(x, y, z)   ((z) < (x) ? (x) : ((z) > (y) ? (y) : (z)))

#define PIXEL_HEIGHT 20
#define PIXEL_WIDTH 20

extern AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM];
#endif

extern AX_S32 g_fd_devmem;
static pthread_mutex_t g_venc_encode_mutex_lock = PTHREAD_MUTEX_INITIALIZER;
static int SceneChangeCheck(AX_AVCHEVC_HANDLE_S *pHandle);

static void processFrameNew(AX_AVCHEVC_HANDLE_S *tb, VCEncInst encoder, VCEncOut *pEncOut, SliceCtl_s *ctl,
    u64 *streamSize, u32 *maxSliceSize, ma_s *ma, u64 *total_bits, VCEncRateCtrl *rc, u32 *frameCntOutput);

static AX_S32 UpdateVencConfig(VENC_CHN VeChn,AX_AVCHEVC_HANDLE_S *pHandle, AX_ENCODR_METADATA_INFO_S *pFrame)
{
    VCEncRet ret = VCENC_ERROR;
    AX_BOOL isUpdata = AX_FALSE;
    AX_U32 new_stride = 0;
    AX_VIDEO_FRAME_S stFrame = {0};
    VCEncPreProcessingCfg preProcCfg = {0};
    AX_S32 newXOffset = 0;
    AX_S32 newYOffset = 0;
    AX_U32 newCodingWidth = 0;
    AX_U32 newCodingHeight = 0;

    if(NULL == pHandle || NULL == pFrame)
    {
        VLOG_ERROR("VencChn %d: pHandle or pFrame is NULL.\n", VeChn);
        return -1;
    }

    if(pFrame->inputFrameType == FRAME_NORMAL_TYPE)
        stFrame = pFrame->inputFrameInfo.stFrameInfo.stVFrame;
    else if(pFrame->inputFrameType == FRAME_USER_TYPE)
        stFrame = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame;

    /* update image format */
    if(pHandle->inputFormat != stFrame.enImgFormat)
    {
        VLOG_DEBUG("VencChn %d: image format update from %d to %d\n",VeChn,pHandle->inputFormat,stFrame.enImgFormat);
        pHandle->inputFormat = stFrame.enImgFormat;
        isUpdata = AX_TRUE;
    }

    /* update image width */
    if(pHandle->lumWidthSrc != stFrame.u32Width)
    {
        VLOG_DEBUG("VencChn %d: image width update from %d to %d\n",VeChn,pHandle->lumWidthSrc,stFrame.u32Width);
        pHandle->lumWidthSrc = stFrame.u32Width;
        isUpdata = AX_TRUE;
    }

    /* update image height */
    if(pHandle->lumHeightSrc != stFrame.u32Height)
    {
        VLOG_DEBUG("VencChn %d: image height update from %d to %d\n",VeChn,pHandle->lumHeightSrc,stFrame.u32Height);
        pHandle->lumHeightSrc = stFrame.u32Height;
        isUpdata = AX_TRUE;
    }

    /* update stride[0] */
    new_stride = stFrame.u32PicStride[0];
    if(!new_stride)
    {
        if (stFrame.enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
            new_stride = stFrame.u32Width;
        else if (stFrame.enImgFormat <= AX_YUV422_INTERLEAVED_UYVY)
            new_stride = stFrame.u32Width * 2;
    }

    if(pHandle->u32PicStride[0] != new_stride)
    {
        VLOG_DEBUG("VencChn %d: image stride[0] update from %d to %d\n",VeChn, pHandle->u32PicStride[0],new_stride);
        pHandle->u32PicStride[0] = new_stride;
        isUpdata = AX_TRUE;
    }

    /* update stride[1] */
    new_stride = stFrame.u32PicStride[1];
    if(!new_stride)
    {
        if (stFrame.enImgFormat == AX_YUV420_PLANAR)
            new_stride = pHandle->u32PicStride[0] / 2;
        else if (stFrame.enImgFormat <= AX_YUV420_SEMIPLANAR_VU)
            new_stride = pHandle->u32PicStride[0];
    }

    if(pHandle->u32PicStride[1] != new_stride)
    {
        VLOG_DEBUG("VencChn %d: image stride[1] update from %d to %d\n",VeChn, pHandle->u32PicStride[1],new_stride);
        pHandle->u32PicStride[1] = new_stride;
        isUpdata = AX_TRUE;
    }

    /* update stride[2] */
    new_stride = stFrame.u32PicStride[2];
    if(!new_stride)
    {
        if (stFrame.enImgFormat == AX_YUV420_PLANAR){
            new_stride = pHandle->u32PicStride[0] / 2;
        }
    }

    if(pHandle->u32PicStride[2] != new_stride)
    {
        VLOG_DEBUG("VencChn %d: image stride[2] update from %d to %d\n",VeChn, pHandle->u32PicStride[2],new_stride);
        pHandle->u32PicStride[2] = new_stride;
        isUpdata = AX_TRUE;
    }

    switch(pHandle->inputFormat)
    {
    case VCENC_YUV420_PLANAR:
         pHandle->lumaSize = pHandle->u32PicStride[0] * pHandle->lumHeightSrc;
         pHandle->chromaSize = pHandle->u32PicStride[1] * pHandle->lumHeightSrc;
         break;
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
         pHandle->lumaSize = pHandle->u32PicStride[0] * pHandle->lumHeightSrc;
         pHandle->chromaSize = pHandle->u32PicStride[1] * pHandle->lumHeightSrc / 2;
         break;
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_YUV422_INTERLEAVED_YUYV:
         pHandle->lumaSize = pHandle->u32PicStride[0] * pHandle->lumHeightSrc;
         pHandle->chromaSize = pHandle->u32PicStride[0] * pHandle->lumHeightSrc;
         break;
    default:
         break;
    }

    /* Get the last configuration*/
    ret = VCEncGetPreProcessing(pHandle->vencInst, &preProcCfg);
    if (ret != VCENC_OK)
    {
        VLOG_ERROR("VencChn %d: GetPreProcessing failed!ret:0x%x\n", VeChn, ret);
        return -1;
    }

    preProcCfg.inputType = (VCEncPictureType)pHandle->inputFormat;
    preProcCfg.origWidth = pHandle->lumWidthSrc;
    preProcCfg.origHeight = pHandle->lumHeightSrc;
    preProcCfg.stride[0] = pHandle->u32PicStride[0];
    preProcCfg.stride[1] = pHandle->u32PicStride[1];
    preProcCfg.stride[2] = pHandle->u32PicStride[2];

    if(pHandle->dynamicCropEnable){ //use crop parameters of frame info
        newXOffset = stFrame.s16OffsetLeft;
        newYOffset = stFrame.s16OffsetTop;
        newCodingWidth = stFrame.s16OffsetRight - stFrame.s16OffsetLeft;
        newCodingHeight = stFrame.s16OffsetBottom - stFrame.s16OffsetTop;
        pHandle->width = newCodingWidth;
        pHandle->height = newCodingHeight;
    }else{ //use crop parameters of channel attr
        newXOffset = pHandle->horOffsetSrc;
        newYOffset = pHandle->verOffsetSrc;
        newCodingWidth = pHandle->width;
        newCodingHeight = pHandle->height;
    }

    if(preProcCfg.xOffset != newXOffset)
    {
        VLOG_DEBUG("VencChn %d: crop info xOffset update from %d to %d\n",VeChn, preProcCfg.xOffset,newXOffset);
        preProcCfg.xOffset = newXOffset;
        isUpdata = AX_TRUE;
    }

    if(preProcCfg.yOffset != newYOffset)
    {
        VLOG_DEBUG("VencChn %d: crop info yOffset update from %d to %d\n",VeChn, preProcCfg.yOffset,newYOffset);
        preProcCfg.yOffset = newYOffset;
        isUpdata = AX_TRUE;
    }

    if(!newCodingWidth)
    {
      newCodingWidth = stFrame.u32Width;
      pHandle->width = stFrame.u32Width;
    }

    if(preProcCfg.codingWidth != newCodingWidth)
    {
        VLOG_DEBUG("VencChn %d:codingWidth update from %d to %d\n",VeChn,preProcCfg.codingWidth,newCodingWidth);
        preProcCfg.codingWidth = newCodingWidth;
        isUpdata = AX_TRUE;
    }

    if(!newCodingHeight)
    {
      newCodingHeight = stFrame.u32Height;
      pHandle->height = stFrame.u32Height;
    }

    if(preProcCfg.codingHeight != newCodingHeight)
    {
        VLOG_DEBUG("VencChn %d:codingHeight update from %d to %d\n",VeChn,preProcCfg.codingHeight,newCodingHeight);
        preProcCfg.codingHeight = newCodingHeight;
        isUpdata = AX_TRUE;
    }

    if(isUpdata != AX_TRUE)
    {
        VLOG_DEBUG("VencChn %d: no configuration need to update\n",VeChn);
        return 0;
    }

    VLOG_DEBUG("VencChn %d:  frame crop info s16OffsetLeft=%d,s16OffsetTop=%d,s16OffsetBottom=%d,s16OffsetRight=%d,\n\
               channel crop info u32CropOffsetX=%d,u32CropOffsetY=%d,u32CropWidth=%d,u32CropHeight=%d\n",
               VeChn, stFrame.s16OffsetLeft,stFrame.s16OffsetTop,stFrame.s16OffsetBottom,stFrame.s16OffsetRight,
               pHandle->horOffsetSrc,pHandle->verOffsetSrc,pHandle->width,pHandle->height);

    if(pHandle->dynamicCropEnable){ //use crop parameters of frame info
        ret = VCEncSetResolution(pHandle->vencInst, pHandle->width, pHandle->height);
        if (ret != VCENC_OK)
        {
            VLOG_ERROR("VencChn %d:  VCEncSetResolution failed!ret:0x%x\n", VeChn, ret);
            return -1;
        }
    }

    /* Set the new configuration*/
    ret = VCEncSetPreProcessing(pHandle->vencInst, &preProcCfg);
    if (ret != VCENC_OK)
    {
        VLOG_ERROR("VencChn %d:  SetPreProcessing failed!ret:0x%x\n", VeChn, ret);
        return -1;
    }

    return 0;
}

AX_S32 VencEncodeHeader(AX_AVCHEVC_HANDLE_S *tb)
{
    VCEncIn *pEncIn = &(tb->encIn);
    VCEncOut encOut;
    AX_S32 s32Ret = 0, ret = 0;

    AX_S32 BufferSize = VCENC_STREAM_MIN_BUF0_SIZE;

    const void *ewl_inst = VCEncGetEwl(tb->vencInst);

    ret = EWLMallocLinear(ewl_inst, BufferSize, tb->input_alignment, &tb->outStrmbufMem);
    if (ret != EWL_OK) {
        s32Ret = AX_ERR_VENC_NOMEM;
        goto ERROR_RET;
    }

    tb->streamBufSize = BufferSize;

    SetupOutputBuffer(tb, pEncIn);

    tb->validencodedframenumber = 0;
    tb->ma.pos = tb->ma.count = 0;
    tb->ma.frameRateNumer = tb->outputRateNumer;
    tb->ma.frameRateDenom = tb->outputRateDenom;
    if (tb->outputRateDenom)
        tb->ma.length = MAX(LEAST_MONITOR_FRAME, MIN(tb->monitorFrames, MOVING_AVERAGE_FRAMES));
    else
        tb->ma.length = MOVING_AVERAGE_FRAMES;

    InitPicConfig(pEncIn, tb);

    if (tb->sendAUD)
        pEncIn->sendAUD = 1;

    /* Video, sequence and picture parameter sets */
    for (int p = 0; p < 1; p++)
    {
        s32Ret = VCEncStrmStart(tb->vencInst, pEncIn, &encOut);
        if (s32Ret) {
            VLOG_ERROR("VCEncStrmStart() fails s32Ret:0x%x\n", s32Ret);
            goto ERROR_RET;
        }

        // VCEncStrmBufs bufs;
        // getStreamBufs (&bufs, tb, HANTRO_FALSE);
        // writeStrmBufs(tb->out, &bufs, 0, encOut.streamSize, 0);

        tb->total_bits += encOut.streamSize * 8;
        tb->streamSize += encOut.streamSize;
    }

    if (EWL_DEVMEM_VAILD(tb->outStrmbufMem)) {
        EWLFreeLinear(ewl_inst, &tb->outStrmbufMem);
        tb->outStrmbufMem.virtualAddress = NULL;
    }

    tb->nextCodingType = VCENC_INTRA_FRAME;
    VCEncGetRateCtrl(tb->vencInst, &tb->rcCfg);

    return 0;

ERROR_RET:
    if (EWL_DEVMEM_VAILD(tb->outStrmbufMem)) {
        EWLFreeLinear(ewl_inst, &tb->outStrmbufMem);
        tb->outStrmbufMem.virtualAddress = NULL;
    }

    return s32Ret;
}

AX_S32 VencEncodeEnd(AX_AVCHEVC_HANDLE_S *tb)
{
    VCEncIn *pEncIn = &(tb->encIn);
    VCEncOut encOut;
    int ret;
    AX_S32 s32Ret = 0;
    AX_S32 BufferSize = VCENC_STREAM_MIN_BUF0_SIZE;

    const void *ewl_inst = VCEncGetEwl(tb->vencInst);

    ret = EWLMallocLinear(ewl_inst, BufferSize, tb->input_alignment, &tb->outStrmbufMem);
    if (ret != EWL_OK) {
        s32Ret = AX_ERR_VENC_NOMEM;
        goto ERROR_RET;
    }

    tb->streamBufSize = BufferSize;

    SetupOutputBuffer(tb, pEncIn);

    ret = VCEncStrmEnd(tb->vencInst, pEncIn, &encOut);
    if (ret == VCENC_OK)
    {
        // VCEncStrmBufs bufs;
        // getStreamBufs (&bufs, tb, HANTRO_FALSE);

        // writeStrmBufs(tb->out, &bufs, 0, encOut.streamSize, 0);
        tb->streamSize += encOut.streamSize;
    }

    if (EWL_DEVMEM_VAILD(tb->outStrmbufMem)) {
        EWLFreeLinear(ewl_inst, &tb->outStrmbufMem);
        tb->outStrmbufMem.virtualAddress = NULL;
    }

    VLOG_DEBUG("Total of %d frames processed, %d frames encoded, %lu bytes, maxSliceBytes=%d\n",
            tb->frameCntTotal, tb->picture_enc_cnt - (tb->frame_delay-1), (long unsigned int)tb->streamSize, tb->maxSliceSize);

    return 0;

ERROR_RET:


//  VC_FCLOSE(tb->in);
//  VC_FCLOSE(tb->inDS);
//  VC_FCLOSE(tb->out);
//  VC_FCLOSE(tb->flexRefsFile);
//  VC_FCLOSE(tb->roiMapFile);
//  VC_FCLOSE(tb->roiMapBinFile);
//  VC_FCLOSE(tb->ipcmMapFile);
//  VC_FCLOSE(tb->fmv);
//  VC_FCLOSE(tb->gmvFile[0]);
//  VC_FCLOSE(tb->gmvFile[1]);
//  VC_FCLOSE(tb->skipMapFile);
//  VC_FCLOSE(tb->roiMapInfoBinFile);
//  VC_FCLOSE(tb->RoimapCuCtrlInfoBinFile);
//  VC_FCLOSE(tb->RoimapCuCtrlIndexBinFile);
//  VC_FCLOSE(tb->dec400Table);
//  VC_FCLOSE(tb->osdDec400TableFile);
//  for(i = 0; i < MAX_OVERLAY_NUM; i++)
//  {
//    VC_FCLOSE(tb->overlayFile[i]);
//  }
//  VC_FCLOSE(tb->extSEIFile);
//  VC_FCLOSE(tb->rdLogFile);

    if (EWL_DEVMEM_VAILD(tb->outStrmbufMem)) {
        EWLFreeLinear(ewl_inst, &tb->outStrmbufMem);
        tb->outStrmbufMem.virtualAddress = NULL;
    }

    return s32Ret;
}

AX_VOID SetSpsPps(AX_AVCHEVC_HANDLE_S *pHandle)
{
    VCEncIn *pEncIn = &(pHandle->encIn);
    /*set SPS/PPS by coding type and codecformat*/
    if (pEncIn->codingType == VCENC_INTRA_FRAME)
    {
        pEncIn->resendSPS = 1;
        pEncIn->resendPPS = 1;
        if (pHandle->codecFormat == VCENC_VIDEO_CODEC_HEVC)
        pEncIn->resendVPS = 1;
    } else {
        pEncIn->resendSPS = 0;
        pEncIn->resendPPS = 0;
        pEncIn->resendVPS = 0;
    }

    if (pEncIn->codingType == VCENC_INTRA_FRAME&& pHandle->gdrDuration == 0 && ((pEncIn->poc == 0)|| (pEncIn->bIsIDR)))
    {
        if(!pHandle->lookaheadDepth)
        {
            pHandle->frameCntOutput = 0;
        }

    }

    return;
}

AX_S32 SceneCutEnableConfig(AX_AVCHEVC_HANDLE_S *pHandle)
{
    AX_BOOL rcModeCbrVbr = AX_FALSE;

    if (NULL == pHandle)
    {
        VLOG_ERROR("SceneCutEnableConfig: input pointer pHandle NULL!\n");
        return AX_FAILURE;
    }

    VCEncIn *pEncIn = &(pHandle->encIn);

    rcModeCbrVbr = (VENC_RC_MODE_H264CBR == pHandle->enRcMode) || (VENC_RC_MODE_H264VBR == pHandle->enRcMode)\
                            || (VENC_RC_MODE_H265CBR == pHandle->enRcMode) || (VENC_RC_MODE_H265VBR == pHandle->enRcMode) \
                            ||(VENC_RC_MODE_H264AVBR == pHandle->enRcMode) || (VENC_RC_MODE_H265AVBR == pHandle->enRcMode) \
                            ||(VENC_RC_MODE_H264CVBR == pHandle->enRcMode) || (VENC_RC_MODE_H265CVBR == pHandle->enRcMode);
    if ((AX_TRUE != pEncIn->fbdcInfo.enableFBDC) && (AX_TRUE == rcModeCbrVbr))
    {
        pHandle->sceneChangeEnable = AX_TRUE;
    }
    else
    {
        pHandle->sceneChangeEnable = AX_FALSE;
    }

    return AX_SUCCESS;
}

AX_S32 DynamicSetStreamBufMarginSize(AX_AVCHEVC_HANDLE_S *pHandle, int chnIdx, VCEncPictureCodingType codingType)
{
	AX_S32 s32BufferSize = 0;

	if(NULL == pHandle)
	{
		VLOG_ERROR("VencChn %d: pHandle is NULL.\n", chnIdx);
		return AX_FAILURE;
	}

	if(gChnInst[chnIdx]->stVencChnAttr.stVencAttr.enMemSource != AX_MEMORY_SOURCE_POOL)
	{
		AX_U32 init_margin_size = gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin_Init;
		if (codingType == VCENC_PREDICTED_FRAME && pHandle->lastPframeSize > 0)
		{
			if (pHandle->sceneChangeEnable && pHandle->encIn.sceneChangeRatio < 50) // ratio < 50, we don't think the scence has changed so much
			{
				gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin = pHandle->lastPframeSize * pHandle->marginSizeScale;

				if (gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin > init_margin_size)
					gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin = init_margin_size;
				if (gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin < VCENC_STREAM_MIN_BUF0_SIZE) {
					gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin = VCENC_STREAM_MIN_BUF0_SIZE;
				}
			}
		}
		else
		{
			gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin = init_margin_size;
		}

		s32BufferSize = ringbuffer_usable_size(chnIdx, gChnInst[chnIdx]->pstRingBuf);
		if (s32BufferSize < gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin) {
				VLOG_WARNING("VencChn %d: stream buffer is not enough, Writeable BufferSize = %d, margin = %u \n"
					"\t\t\t startPtr=0x%llx, endPtr=0x%llx, writePtr=0x%llx, readPtr=0x%llx \n"
					"\t\t\t TotalEncodeNum=%llu, TotalGetStrmNum=%llu, TotalReleaseStrmNum=%llu.\n\n",
					chnIdx,
					s32BufferSize,
					gChnInst[chnIdx]->pstRingBuf->stream_buffer_margin,
					gChnInst[chnIdx]->pstRingBuf->phyaddr_buffer_start,
					gChnInst[chnIdx]->pstRingBuf->phyaddr_buffer_end,
					gChnInst[chnIdx]->pstRingBuf->phyaddr_for_write,
					gChnInst[chnIdx]->pstRingBuf->phyaddr_for_read,
					gChnInst[chnIdx]->u64TotalEncodeNum,
					gChnInst[chnIdx]->u64TotalGetStrmNum,
					gChnInst[chnIdx]->u64TotalReleaseStrmNum);

				return AX_FAILURE;
		}

		pHandle->encIn.busOutBuf[0] = gChnInst[chnIdx]->pstRingBuf->phyaddr_for_write;
		pHandle->encIn.pOutBuf[0] = (u32 *)gChnInst[chnIdx]->pstRingBuf->viraddr_for_write;
		pHandle->encIn.outBufSize[0] = s32BufferSize;
	}

	return AX_SUCCESS;
}

AX_S32 VencRateJamProcess(AX_AVCHEVC_HANDLE_S *pHandle, AX_S32 VeChn)
{
	if (gChnInst[VeChn]->u64InstantaneousBitRate > pHandle->stRateJamStrategyParam.u32DropFrmThrBps)
	{
		if (DROPFRM_NORMAL == pHandle->stRateJamStrategyParam.enDropFrmMode)
		{
			while (1)
			{
				if (pHandle->stRateJamStrategyParam.u32MaxApplyCount == 0)
				{
					return -1;
				}
				if (pHandle->dropFrameCnt < pHandle->stRateJamStrategyParam.u32MaxApplyCount)
				{
					VLOG_DEBUG("VencChn %d: instant bitrate: %llu exceed the threshold, discard it...\n",
						  VeChn,
						  gChnInst[VeChn]->u64InstantaneousBitRate);

					pHandle->dropFrameCnt++;
					return -1;
				}

				pHandle->dropFrameCnt = 0;
				break;
			}
		}
		else if (DROPFRM_PSKIP == pHandle->stRateJamStrategyParam.enDropFrmMode)
		{
			while (1)
			{
				if (pHandle->stRateJamStrategyParam.u32MaxApplyCount == 0)
				{
					pHandle->skip_frame_enabled_flag = 1;
					pHandle->skip_frame_poc = pHandle->encIn.poc;
					break;
				}
				if (pHandle->dropFrameCnt < pHandle->stRateJamStrategyParam.u32MaxApplyCount)
				{
					VLOG_DEBUG("VencChn %d: instant bitrate: %llu exceed the threshold, encode as pskip...\n",
						VeChn,
						gChnInst[VeChn]->u64InstantaneousBitRate);

					pHandle->skip_frame_enabled_flag = 1;
					pHandle->skip_frame_poc = pHandle->encIn.poc;
					pHandle->dropFrameCnt++;
					break;
				}

				pHandle->dropFrameCnt = 0;
				break;
			}
		}
	}
	else
	{
		pHandle->dropFrameCnt = 0;
	}

  return AX_SUCCESS;
}

AX_S32 VencProcess(int i, AX_AVCHEVC_HANDLE_S *pHandle, AX_ENCODR_METADATA_INFO_S *pFrame, AX_ENCODR_METADATA_INFO_S *pOut)
{
    VCEncIn *pEncIn = &(pHandle->encIn);
    VCEncOut encOut;
    VCEncRet ret;
    AX_S32 Ret = AX_SUCCESS;
    AX_USERDATA_NODE_S stUserDataNode;
    AX_BOOL bVirFrm = AX_FALSE;

    UpdateVencConfig(i,pHandle,pFrame);
    VencConfigFrameBuffer(i, pHandle, pEncIn, pFrame, pOut);

    pEncIn->dec400Enable = 0;
    pEncIn->axiFEEnable = 0;
    pEncIn->apbFTEnable = 0;

    pHandle->frameCntTotal++;

    if(pHandle->bRequestIDR)
    {
        pEncIn->insertIdr = 2;
    }

    /*set codingType*/
    if (pHandle->bInstantIDR && pHandle->bRequestIDR && (VENC_GOPMODE_ONELTR != pHandle->enGopMode))
    {
        pEncIn->codingType = VCENC_INTRA_FRAME;
        pEncIn->bIsIDR = true;
        if (pHandle->gdrDuration == 0)
        {
            pEncIn->poc = 0;
        }
        pHandle->bRequestIDR = false;
        pHandle->bInstantIDR = false;
        gChnInst[i]->bInstant = false;
        pEncIn->insertIdr = 1;
    }
    else
    {
        pEncIn->codingType = (pEncIn->poc == 0) ? VCENC_INTRA_FRAME : pHandle->nextCodingType;
    }

    SetSpsPps(pHandle);

    /* 5. encoding specific frame from user: all CU/MB are SKIP*/
    pEncIn->bSkipFrame = pHandle->skip_frame_enabled_flag && (pEncIn->poc == pHandle->skip_frame_poc);

    VLOG_DEBUG("VencChn %d:  Encoding %i  codeType=%d pHandle->gopSize:%d",
            i, pHandle->picture_enc_cnt, pEncIn->codingType, pHandle->gopSize);

    pEncIn->externalSEICount = 0;
    pEncIn->pExternalSEI = NULL;

    if(pHandle->insertIDR == pEncIn->poc && pHandle->gopSize == 1) {
      //printf("insert IDR.\n");
      pEncIn->codingType = VCENC_INTRA_FRAME;
      pEncIn->bIsIDR = 1;
    }

    Ret = SceneCutEnableConfig(pHandle);
    if (AX_SUCCESS != Ret)
    {
        VLOG_DEBUG("VencChn %d: SceneCutEnableConfig : pHandle is NULL. Ret:%d\n", i, Ret);
        return -1;
    }

    if (pHandle->sceneChangeEnable) {
        pEncIn->sceneChangeRatio = SceneChangeCheck(pHandle);
        // VLOG_DEBUG("VENC %d: scene change ratio %d\n", pHandle->VeChn, pEncIn->sceneChangeRatio);
    } else {
        pEncIn->sceneChangeRatio = 0;
    }

    pEncIn->u64ShortTermBitRate = gChnInst[i]->u64ShortTermBitRate;
    pEncIn->u64LongTermBitRate = gChnInst[i]->u64LongTermBitRate;
    // printf("%s:line_%d, u64ShortTermBitRate %llu\n", __func__, __LINE__, pEncIn->u64ShortTermBitRate);
    // printf("%s:line_%d, u64LongTermBitRate %llu\n", __func__, __LINE__, pEncIn->u64LongTermBitRate);

    Ret = DynamicSetStreamBufMarginSize(pHandle, i, pEncIn->codingType);
    if (AX_SUCCESS != Ret)
    {
      VLOG_WARNING("VencChn %d: stream buffer is not enough. Ret:%d\n", i, Ret);
      return AX_ERR_VENC_NOMEM;
    }

    if (gChnInst[i]->pstUserDataBufferQueue)
    {
      AX_S32 s32Ret = UserDataPopQueue(i, gChnInst[i]->pstUserDataBufferQueue, &stUserDataNode);
      if (s32Ret == AX_SUCCESS)
      {
        ret = VCEncSetSeiUserData(pHandle->vencInst, stUserDataNode.pBufferAddr, stUserDataNode.u32BufferSize);
        if (ret != VCENC_OK)
        {
          VLOG_ERROR("VENC %d: set sei userdata error.", i);
          return ret;
        }
      }
      else
      {
        ret = VCEncSetSeiUserData(pHandle->vencInst, NULL, 0);
        if (ret != VCENC_OK)
        {
          VLOG_ERROR("VENC %d: set sei userdata error.", i);
          return ret;
        }
      }
    }

    if ((pEncIn->poc != 0) && (pHandle->enGopMode == VENC_GOPMODE_ONELTR)) {
        AX_S32 s32Internel = pHandle->stOneLTR.stPicSpecialConfig.s32Interval;
        if ((s32Internel > 0) && ((pEncIn->poc % s32Internel) == 0)) {
            bVirFrm = AX_TRUE;
        }
    }

    pEncIn->bVirtualFrm = bVirFrm;

    VENC_ENCODE_MUTEX_LOCK(g_venc_encode_mutex_lock);
    ret = VCEncStrmEncode(pHandle->vencInst, pEncIn, &encOut, NULL, NULL);
    VENC_ENCODE_MUTEX_UNLOCK(g_venc_encode_mutex_lock);

    if (pEncIn->externalSEICount != 0) {
      for (int k = 0; k < pEncIn->externalSEICount; k++) {
        free(pEncIn->pExternalSEI[k].pPayloadData);
      }
      free(pEncIn->pExternalSEI);
      pEncIn->externalSEICount = 0;
      pEncIn->pExternalSEI = NULL;
    }

    switch (ret)
    {
      case VCENC_FRAME_ENQUEUE:
      {
        pHandle->picture_enc_cnt++;
        //Adaptive GOP size decision

        if (pHandle->bRequestIDR)
        {
            pHandle->nextCodingType = VCEncFindNextPic(pHandle->vencInst, pEncIn, pHandle->nextGopSize, pHandle->encIn.gopConfig.gopCfgOffset, true);
            pHandle->bRequestIDR = false;
        } else
        {
            pHandle->nextCodingType = VCEncFindNextPic(pHandle->vencInst, pEncIn, pHandle->nextGopSize, pHandle->encIn.gopConfig.gopCfgOffset, false);
        }

        pEncIn->timeIncrement = pHandle->outputRateDenom;

        VLOG_DEBUG("VencChn %d: frame enqueue, ret = %d.\n", i, ret);
        return -1;
      }
      case VCENC_FRAME_READY:
      {
        if (encOut.isReEncode && !encOut.isDiscard)
        {
          gChnInst[i]->u64ReEncodeCount++;
        }
        else if (encOut.isDiscard)
        {
          gChnInst[i]->u64DiscardCount++;
          VLOG_DEBUG("VencChn %d: the frame discard", i);
          return -1;
        }

        if(encOut.codingType != VCENC_NOTCODED_FRAME)
          pHandle->picture_enc_cnt++;

        if (encOut.streamSize == 0) {
          pHandle->encIn.picture_cnt ++;
          break;
        }

        pOut->outputStreamInfo.stPackage.enType = pHandle->codecFormat == VCENC_VIDEO_CODEC_HEVC ? PT_H265 : PT_H264;
        pOut->outputStreamInfo.stPackage.enCodingType = bVirFrm ? VCENC_VIRTUAL_INTRA_FRAME : pEncIn->codingType;
        pOut->outputStreamInfo.stPackage.ulPhyAddr = pEncIn->busOutBuf[0];
        pOut->outputStreamInfo.stPackage.pu8Addr = (unsigned char *)pEncIn->pOutBuf[0];
        pOut->outputStreamInfo.stPackage.u32Len = encOut.streamSize;

        if(pFrame->inputFrameType == FRAME_NORMAL_TYPE){
          pOut->outputStreamInfo.stPackage.u64PTS = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PTS;
          pOut->outputStreamInfo.stPackage.u64SeqNum = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64SeqNum;
        }else{
          pOut->outputStreamInfo.stPackage.u64PTS = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PTS;
          pOut->outputStreamInfo.stPackage.u64SeqNum = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64SeqNum;
        }

        //svc-t layer id
        if (VCENC_INTRA_FRAME == pEncIn->codingType)
          pOut->outputStreamInfo.stPackage.u32TemporalID = 0;
        else
          pOut->outputStreamInfo.stPackage.u32TemporalID = pEncIn->gopCurrPicConfig.temporalId;

        VencParseNaluType(i, pHandle, pEncIn, &encOut, pOut);

        VLOG_DEBUG("VencChn %d: encoded: codingType=%d, phyAddr=0x%lx, vir_addr=ox%lx, packetSize=%u, tempID=%u, pts=%lld, seqNum=%lld.\n",
                i,
                pOut->outputStreamInfo.stPackage.enCodingType,
                pOut->outputStreamInfo.stPackage.ulPhyAddr,
                pOut->outputStreamInfo.stPackage.pu8Addr,
                pOut->outputStreamInfo.stPackage.u32Len,
                pOut->outputStreamInfo.stPackage.u32TemporalID,
                pOut->outputStreamInfo.stPackage.u64PTS,
                pOut->outputStreamInfo.stPackage.u64SeqNum);

        processFrameNew(pHandle,
                        pHandle->vencInst,
                        &encOut,
                        pHandle->sliceCtlOut,
                        &pHandle->streamSize,
                        &pHandle->maxSliceSize,
                        &pHandle->ma,
                        &pHandle->total_bits,
                        &pHandle->rcCfg,
                        &pHandle->frameCntOutput);

        if (pEncIn->codingType == VCENC_PREDICTED_FRAME)
        {
          pHandle->lastPframeSize = encOut.streamSize;
        }
        else
        {
          // margin of P_frame equals to 5 * lastPframeSize. So set magin of P_frame as 1.5 * size of I_frame.
          pHandle->lastPframeSize = encOut.streamSize / 2;
          pHandle->marginSizeScale = 5;
        }

        if (pHandle->bRequestIDR)
        {
            pHandle->nextCodingType = VCEncFindNextPic(pHandle->vencInst, pEncIn, pHandle->nextGopSize, pHandle->encIn.gopConfig.gopCfgOffset, true);
            pHandle->bRequestIDR = false;
        }
        else
        {
            pHandle->nextCodingType = VCEncFindNextPic(pHandle->vencInst, pEncIn, pHandle->nextGopSize, pHandle->encIn.gopConfig.gopCfgOffset, false);
        }
        break;
      }
      case VCENC_OUTPUT_BUFFER_OVERFLOW:
      {

        if (pEncIn->codingType == VCENC_PREDICTED_FRAME)
        {
            pHandle->marginSizeScale *=2;
            VLOG_DEBUG("VencChn %d: adjust marginSizeScale=%d\n", i,pHandle->marginSizeScale);
        }

        gChnInst[i]->u64HwBufferOverflowCount++;
        if (encOut.isReEncode && !encOut.isDiscard)
        {
          gChnInst[i]->u64ReEncodeCount++;
        }
        else if (encOut.isDiscard)
        {
          gChnInst[i]->u64DiscardCount++;
          VLOG_DEBUG("VencChn %d: the frame discard", i);
          return -1;
        }

        VLOG_ERROR("VencChn %d: stream buffer overflow, buffSize=%u, encodeStreamSize=(%u), ret=%d.\n",
              i,
              pEncIn->outBufSize[0],
              encOut.streamSize,
              ret);
        return -1;
      }
      case VCENC_HW_TIMEOUT:
      {
        gChnInst[i]->u64HwTimeOutCount++;
        VLOG_ERROR("VencChn %d: stream buffer timeout, ret=%d.\n", i, ret);
        return -1;
      }
      default:
      {
        VLOG_ERROR("VencChn %d:  encode error, ret = %d.\n", i, ret);
        return -1;
      }

    }

	  return 0;
}

void tb_init_pic(AX_AVCHEVC_HANDLE_S *tb,  ma_s *ma, adapGopCtr *agop)
{
  tb->validencodedframenumber=0;

  //Adaptive Gop variables
  agop->last_gopsize = MAX_ADAPTIVE_GOP_SIZE;
  agop->gop_frm_num = 0;
  agop->sum_intra_vs_interskip = 0;
  agop->sum_skip_vs_interskip = 0;
  agop->sum_intra_vs_interskipP = 0;
  agop->sum_intra_vs_interskipB = 0;
  agop->sum_costP = 0;
  agop->sum_costB = 0;

  ma->pos = ma->count = 0;
  ma->frameRateNumer = tb->outputRateNumer;
  ma->frameRateDenom = tb->outputRateDenom;
  if (tb->outputRateDenom)
      ma->length = MAX(LEAST_MONITOR_FRAME, MIN(tb->monitorFrames,MOVING_AVERAGE_FRAMES));
  else
      ma->length = MOVING_AVERAGE_FRAMES;
}

void CloseEncoder(VCEncInst encoder, AX_AVCHEVC_HANDLE_S *tb)
{
  VCEncRet ret;
  const void *ewl_inst = VCEncGetEwl(encoder);

  if (EWL_DEVMEM_VAILD(tb->scaledPictureMem))
    EWLFreeLinear(ewl_inst, &tb->scaledPictureMem);
  if ((ret = VCEncRelease(encoder)) != VCENC_OK)
  {
    //PrintErrorValue("VCEncRelease() failed.", ret);
  }
}

int AllocResNew(VCEncInst enc, AX_AVCHEVC_HANDLE_S *tb)
{
  u32 pictureSize = 0;
  u32 lumaSize = 0,chromaSize = 0;
  u32 coreIdx=0;
  i32 iBuf = 0;
  u32 block_size = 0;
  u32 alignment = 0;
  const EWLHwConfig_t asicCfg = VCEncGetAsicConfig(tb->codecFormat, NULL);

  //alignment = (tb->formatCustomizedType != -1? 0 : tb->input_alignment);
  alignment = 0;
  getAlignedPicSizebyFormat(tb->inputFormat,tb->lumWidthSrc,tb->lumHeightSrc,alignment,&lumaSize,&chromaSize,&pictureSize);

#ifdef FBDC_ENABLE
   pictureSize = tb->YheaderSize + tb->YpayloadSize + tb->UVheaderSize + tb->UVpayloadSize;
#endif

  /* Here we use the EWL instance directly from the encoder
   * because it is the easiest way to allocate the linear memories */

  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
    tb->pictureMemFactory[coreIdx].virtualAddress = NULL;
    tb->transformMemFactory[coreIdx].virtualAddress = NULL;
	  tb->pictureDSMemFactory[coreIdx].virtualAddress = NULL;
	  tb->Dec400CmpTableMemFactory[coreIdx].virtualAddress = NULL;
  }

  //allocate delta qp map memory.
  // 4 bits per block.
  block_size=((tb->width+tb->max_cu_size-1)& (~(tb->max_cu_size - 1)))*((tb->height+tb->max_cu_size-1)& (~(tb->max_cu_size - 1)))/(8*8*2);
  // 8 bits per block if ipcm map/absolute roi qp is supported
  if (asicCfg.roiMapVersion >= 1)
    block_size *= 2;
  block_size = ((block_size+63)&(~63));

  tb->mvReplaceBuffer.virtualAddress = NULL;

  for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
      VLOG_DEBUG("Output buffer[%d] size:         %d bytes\n", coreIdx, tb->streamBufSize);
      VLOG_DEBUG("Output buffer[%d] bus address:  %p\n", coreIdx, (void *)tb->outStrmbufMem.busAddress);
      VLOG_DEBUG("Output buffer[%d] user address: %p\n",  coreIdx, tb->outStrmbufMem.virtualAddress);
    }
  }
  return 0;
}

void FreeRes(VCEncInst enc,  AX_AVCHEVC_HANDLE_S *tb)
{
  u32 coreIdx=0;
  i32 iBuf;
  const void *ewl_inst = VCEncGetEwl(enc);

  if (EWL_DEVMEM_VAILD(tb->pictureStabMem))
  {
    EWLFreeLinear(ewl_inst, &tb->pictureStabMem);
  }

  if (tb->roiMapDeltaQpMemFactory[0].virtualAddress != NULL)
  {
    for(coreIdx = 1; coreIdx < tb->buffer_cnt; coreIdx++)
      tb->roiMapDeltaQpMemFactory[0].size += tb->roiMapDeltaQpMemFactory[coreIdx].size;
    EWLFreeLinear(ewl_inst, &tb->roiMapDeltaQpMemFactory[0]);
  }
  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
	if (tb->Dec400CmpTableMemFactory[coreIdx].virtualAddress != NULL)
	{
	  EWLFreeLinear(ewl_inst, &tb->Dec400CmpTableMemFactory[coreIdx]);
	}

    if (EWL_DEVMEM_VAILD(tb->pictureMemFactory[coreIdx]))
      EWLFreeLinear(ewl_inst, &tb->pictureMemFactory[coreIdx]);
    if (EWL_DEVMEM_VAILD(tb->pictureDSMemFactory[coreIdx]))
      EWLFreeLinear(ewl_inst, &tb->pictureDSMemFactory[coreIdx]);

    if (EWL_DEVMEM_VAILD(tb->transformMemFactory[coreIdx]))
      EWLFreeLinear(ewl_inst, &tb->transformMemFactory[coreIdx]);
    if (tb->RoimapCuCtrlInfoMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(ewl_inst, &tb->RoimapCuCtrlInfoMemFactory[coreIdx]);
    if (tb->RoimapCuCtrlIndexMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(ewl_inst, &tb->RoimapCuCtrlIndexMemFactory[coreIdx]);
  }
  for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
      if (tb->outbufMemFactory[coreIdx][iBuf].virtualAddress != NULL)
        EWLFreeLinear(ewl_inst, &tb->outbufMemFactory[coreIdx][iBuf]);
    }

    // for AV1's precarry
    if (tb->Av1PreoutbufMemFactory[coreIdx].virtualAddress != NULL)
        EWLFreeLinear(ewl_inst, &tb->Av1PreoutbufMemFactory[coreIdx]);

    if (tb->extSRAMMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(ewl_inst, &tb->extSRAMMemFactory[coreIdx]);
  }

  for (coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
    for (iBuf = 0; iBuf < MAX_OVERLAY_NUM; iBuf++)
    {
      if (tb->overlayInputMemFactory[coreIdx][iBuf].virtualAddress != NULL)
      {
        EWLFreeLinear(ewl_inst, &tb->overlayInputMemFactory[coreIdx][iBuf]);
      }
    }

    if (tb->osdDec400CmpTableMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(ewl_inst, &tb->osdDec400CmpTableMemFactory[coreIdx]);
  }

  if (tb->mvReplaceBuffer.virtualAddress != NULL)
  {
    EWLFreeLinear(ewl_inst, &tb->mvReplaceBuffer);
  }
}

int OpenEncoderNew(VCEncInst *pEnc, AX_AVCHEVC_HANDLE_S *tb)
{
  VCEncRet ret;
  VCEncConfig cfg;
  VCEncCodingCtrl codingCfg;

  memset(&codingCfg, 0, sizeof(VCEncCodingCtrl));

  VCEncPreProcessingCfg preProcCfg;
  VCEncInst encoder;
  i32 i;
  const void *ewl_inst = NULL;

  /* Encoder initialization */
  if (tb->width == DEFAULT)
    tb->width = tb->lumWidthSrc;

  if (tb->height == DEFAULT)
    tb->height = tb->lumHeightSrc;

  /* outputRateNumer */
  if (tb->outputRateNumer == DEFAULT)
    tb->outputRateNumer = tb->inputRateNumer;

  /* outputRateDenom */
  if (tb->outputRateDenom == DEFAULT)
    tb->outputRateDenom = tb->inputRateDenom;

  /*cfg.ctb_size = tb->max_cu_size;*/
  if (tb->rotation&&tb->rotation!=3)
  {
    cfg.width = tb->height;
    cfg.height = tb->width;
    cfg.maxRefWidth = tb->maxPicHeight;
    cfg.maxRefHeight = tb->maxPicWidth;
  }
  else
  {
    cfg.width = tb->width;
    cfg.height = tb->height;
    cfg.maxRefWidth = tb->maxPicWidth;
    cfg.maxRefHeight = tb->maxPicHeight;
  }

  for (int i = 0; i < 3; i++) {
    cfg.stride[i] = tb->u32PicStride[i];
  }

  cfg.frameRateDenom = tb->outputRateDenom;
  cfg.frameRateNum = tb->outputRateNumer;

  /* intra tools in sps and pps */
  cfg.strongIntraSmoothing = tb->strong_intra_smoothing_enabled_flag;

  cfg.streamType = (tb->byteStream) ? VCENC_BYTE_STREAM : VCENC_NAL_UNIT_STREAM;

  cfg.level = (IS_H264(tb->codecFormat) ? VCENC_H264_LEVEL_5_1 : VCENC_HEVC_LEVEL_6);

  /* hard coded level for H.264 */
  if (tb->level != DEFAULT && tb->level != 0)
    cfg.level = (VCEncLevel)tb->level;
  /*api will calculate level.*/
  if(tb->level == 0)
  {
    cfg.level = 0;
  }

  cfg.tier = VCENC_HEVC_MAIN_TIER;
  if (tb->tier != DEFAULT)
    cfg.tier = (VCEncTier)tb->tier;

  cfg.profile = (IS_H264(tb->codecFormat) ? VCENC_H264_HIGH_PROFILE : VCENC_HEVC_MAIN_PROFILE);

  cfg.codecFormat = tb->codecFormat;

  if (tb->profile != DEFAULT && tb->profile != 0)
    cfg.profile = (VCEncProfile)tb->profile;

  /* convert between H.264/HEVC profiles for testing purpose */
  if(IS_H264(tb->codecFormat)) {
    if(((int)cfg.profile >= VCENC_HEVC_MAIN_PROFILE && cfg.profile < VCENC_HEVC_MAIN_10_PROFILE) || cfg.profile == VCENC_HEVC_MAINREXT)
      cfg.profile = VCENC_H264_HIGH_PROFILE;
  } else {
    if(cfg.profile >= VCENC_H264_BASE_PROFILE && cfg.profile <= VCENC_H264_HIGH_PROFILE)
      cfg.profile = VCENC_HEVC_MAIN_PROFILE;
  }

  cfg.bitDepthLuma = 8;
  if (tb->bitDepthLuma != DEFAULT)
    cfg.bitDepthLuma = tb->bitDepthLuma;

  cfg.bitDepthChroma= 8;
  if (tb->bitDepthChroma != DEFAULT)
    cfg.bitDepthChroma = tb->bitDepthChroma;

  if(tb->codecFormat == VCENC_VIDEO_CODEC_VP9)
  {
    if(cfg.bitDepthLuma != cfg.bitDepthChroma)
    {
      printf("Different bit depth for luma and chroma is not supported for VP9\n");
      cfg.bitDepthChroma = cfg.bitDepthLuma;
    }
  }

  if ((tb->interlacedFrame && tb->gopSize != 1) || IS_H264(tb->codecFormat))
  {
    //printf("OpenEncoder: treat interlace to progressive for gopSize!=1 case\n");
    tb->interlacedFrame = 0;
  }

  //default maxTLayer
  cfg.maxTLayers = 1;

  u32 maxRefPics = 0;
  u32 maxTemporalId = 0;
  int idx;
  for (idx = 0; idx < tb->encIn.gopConfig.size; idx ++)
  {
    VCEncGopPicConfig *cfg = &(tb->encIn.gopConfig.pGopPicCfg[idx]);
    if (cfg->codingType != VCENC_INTRA_FRAME)
    {
      if (maxRefPics < cfg->numRefPics)
        maxRefPics = cfg->numRefPics;

      if (maxTemporalId < cfg->temporalId)
        maxTemporalId = cfg->temporalId;
    }
  }
  for (idx = 0; idx < tb->encIn.gopConfig.special_size; idx ++)
  {
    VCEncGopPicSpecialConfig *cfg = &(tb->encIn.gopConfig.pGopPicSpecialCfg[idx]);

    if ( (cfg->temporalId != TEMPORALID_RESERVED ) && (maxTemporalId < cfg->temporalId) )
      maxTemporalId = cfg->temporalId;
  }
  cfg.refFrameAmount = maxRefPics + tb->interlacedFrame + tb->encIn.gopConfig.ltrcnt;
  cfg.maxTLayers = maxTemporalId +1;
  if (tb->flexRefs!=NULL) {
    cfg.refFrameAmount = 4;
    cfg.maxTLayers = 4;
  }

  cfg.compressor = tb->compressor;
  cfg.interlacedFrame = tb->interlacedFrame;
  cfg.enableOutputCuInfo = (tb->enableOutputCuInfo > 0) ? 1 : 0;
  cfg.enableOutputCtbBits = (tb->enableOutputCtbBits > 0)? 1 : 0;
  cfg.rdoLevel = CLIP3(1, 3, tb->rdoLevel) - 1;
  cfg.verbose = tb->verbose;
  cfg.exp_of_input_alignment = tb->exp_of_input_alignment;
  cfg.exp_of_ref_alignment = tb->exp_of_ref_alignment;
  cfg.exp_of_ref_ch_alignment = tb->exp_of_ref_ch_alignment;
  cfg.exp_of_aqinfo_alignment = tb->exp_of_aqinfo_alignment;

  VLOG_DEBUG("input_alignment=%d, ref_alignment=%d, ch_alignment=%d, aqinfo_alignment=%d\n",
  			tb->exp_of_input_alignment, tb->exp_of_ref_alignment,
			tb->exp_of_ref_ch_alignment, tb->exp_of_aqinfo_alignment);

  cfg.exteralReconAlloc = 0;
  cfg.P010RefEnable = tb->P010RefEnable;
  cfg.enableSsim = tb->ssim;
  cfg.enablePsnr = tb->psnr;
  cfg.ctbRcMode = (tb->ctbRc != DEFAULT) ? tb->ctbRc : 0;
  cfg.rcMode = tb->stRcParam.enRcMode%10 -1; // enRCMode[1-18] transfer to rcMode[0-2]. Warning: only 2 used.
  /*for CVBR*/
  cfg.u32MaxBitRate = tb->u32MaxBitRate;
  cfg.u32ShortTermStatTime = tb->u32ShortTermStatTime;
  cfg.u32LongTermStatTime = tb->u32LongTermStatTime;

  cfg.u32LongTermMaxBitrate = tb->u32LongTermMaxBitrate;
  cfg.u32LongTermMinBitrate = tb->u32LongTermMinBitrate;

  cfg.u32ExtraBitPercent = tb->u32ExtraBitPercent;
  cfg.u32LongTermStatTimeUnit = tb->u32LongTermStatTimeUnit;

  cfg.idrDeltaRange =  tb->idrDeltaRange;
  cfg.parallelCoreNum = tb->parallelCoreNum;
  cfg.pass = (tb->lookaheadDepth?2:0);
  cfg.bPass1AdaptiveGop = (tb->gopSize == 0);
  cfg.picOrderCntType = tb->picOrderCntType;
  cfg.dumpRegister = tb->dumpRegister;
  cfg.dumpCuInfo = (tb->enableOutputCuInfo==2)?1:0;
  cfg.dumpCtbBits = (tb->enableOutputCtbBits == 2)?1:0;
  cfg.rasterscan = tb->rasterscan;
  cfg.log2MaxPicOrderCntLsb = tb->log2MaxPicOrderCntLsb;
  cfg.log2MaxFrameNum = tb->log2MaxFrameNum;
  cfg.lookaheadDepth = tb->lookaheadDepth;
  cfg.extDSRatio = (tb->lookaheadDepth && tb->halfDsInput ? 1 : 0);
  cfg.inLoopDSRatio = tb->inLoopDSRatio;
  cfg.cuInfoVersion = tb->cuInfoVersion;
  cfg.extSramLumHeightBwd = tb->extSramLumHeightBwd;
  cfg.extSramChrHeightBwd = tb->extSramChrHeightBwd;
  cfg.extSramLumHeightFwd = tb->extSramLumHeightFwd;
  cfg.extSramChrHeightFwd = tb->extSramChrHeightFwd;
  cfg.AXIAlignment = tb->AXIAlignment;
  cfg.mmuEnable = tb->mmuEnable;
  cfg.slice_idx = tb->sliceNode;
  cfg.gopSize = tb->gopSize;

  if (tb->parallelCoreNum > 1 && cfg.width * cfg.height < 256*256) {
    printf("Disable multicore for small resolution (< 255*255)\n");
    cfg.parallelCoreNum = tb->parallelCoreNum = 1;
  }
  cfg.codedChromaIdc = tb->codedChromaIdc;
  cfg.writeReconToDDR = (tb->writeReconToDDR ||tb->intraPicRate != 1);
  cfg.TxTypeSearchEnable = tb->TxTypeSearchEnable;
  cfg.av1InterFiltSwitch = tb->av1InterFiltSwitch;
  cfg.tune        = tb->tune;
  cfg.burstMaxLength = tb->burstMaxLength;

  cfg.fileListExist = (tb->inputFileLinkListNum) ? 1 : 0;

  cfg.frameFormat = tb->inputFormat;
  cfg.idr_interval = tb->intraPicRate;
  cfg.bitRate = tb->bitPerSecond;

  //tb->enRcMode
  ret = VCEncInit(&cfg, pEnc, NULL);
  if (ret != VCENC_OK) {
    VLOG_ERROR("VCEncInit() failed, ret = %d.", ret);
    return (int)ret;
  }

  encoder = *pEnc;
  ewl_inst = VCEncGetEwl(encoder);

  /* Encoder setup: coding control */
  ret = VCEncGetCodingCtrl(encoder, &codingCfg);
  if (ret != VCENC_OK) {
    VLOG_ERROR("VCEncGetCodingCtrl() failed, ret = %d", ret);
    CloseEncoder(encoder, tb);
    return -1;
  } else {

    if (tb->sliceSize != DEFAULT)
      codingCfg.sliceSize = tb->sliceSize;
    if (tb->enableCabac != DEFAULT)
      codingCfg.enableCabac = tb->enableCabac;
    if (tb->cabacInitFlag != DEFAULT)
      codingCfg.cabacInitFlag = tb->cabacInitFlag;
    codingCfg.vuiVideoFullRange = 0;
    if (tb->videoRange != DEFAULT)
      codingCfg.vuiVideoFullRange = tb->videoRange;
    if (tb->enableRdoQuant != DEFAULT)
      codingCfg.enableRdoQuant = tb->enableRdoQuant;
    if(tb->layerInRefIdc != DEFAULT)
      codingCfg.layerInRefIdcEnable = tb->layerInRefIdc;

    codingCfg.sramPowerdownDisable = tb->sramPowerdownDisable;
    codingCfg.disableDeblockingFilter = (tb->disableDeblocking != 0);
    codingCfg.tc_Offset = tb->tc_Offset;
    codingCfg.beta_Offset = tb->beta_Offset;
    codingCfg.enableSao = tb->enableSao;
    codingCfg.enableDeblockOverride = tb->enableDeblockOverride;
    codingCfg.deblockOverride = tb->deblockOverride;
    codingCfg.enableDynamicRdo = tb->dynamicRdoEnable;
    codingCfg.dynamicRdoCu16Bias = tb->dynamicRdoCu16Bias;
    codingCfg.dynamicRdoCu16Factor = tb->dynamicRdoCu16Factor;
    codingCfg.dynamicRdoCu32Bias = tb->dynamicRdoCu32Bias;
    codingCfg.dynamicRdoCu32Factor = tb->dynamicRdoCu32Factor;

    if (tb->sei)
      codingCfg.seiMessages = 1;
    else
      codingCfg.seiMessages = 0;

    codingCfg.gdrDuration = tb->gdrDuration;
    codingCfg.fieldOrder = tb->fieldOrder;

    codingCfg.cirStart = tb->cirStart;
    codingCfg.cirInterval = tb->cirInterval;

    if(codingCfg.gdrDuration == 0)
    {
      codingCfg.intraArea.top = tb->intraAreaTop;
      codingCfg.intraArea.left = tb->intraAreaLeft;
      codingCfg.intraArea.bottom = tb->intraAreaBottom;
      codingCfg.intraArea.right = tb->intraAreaRight;
      //codingCfg.intraArea.enable = CheckArea(&codingCfg.intraArea, cml);
    }
    else
    {
      //intraArea will be used by GDR, customer can not use intraArea when GDR is enabled.
      codingCfg.intraArea.enable = 0;
    }

    codingCfg.pcm_loop_filter_disabled_flag = tb->pcm_loop_filter_disabled_flag;

    codingCfg.ipcm1Area.top = tb->ipcm1AreaTop;
    codingCfg.ipcm1Area.left = tb->ipcm1AreaLeft;
    codingCfg.ipcm1Area.bottom = tb->ipcm1AreaBottom;
    codingCfg.ipcm1Area.right = tb->ipcm1AreaRight;
//    codingCfg.ipcm1Area.enable = CheckArea(&codingCfg.ipcm1Area, cml);

    codingCfg.ipcm2Area.top = tb->ipcm2AreaTop;
    codingCfg.ipcm2Area.left = tb->ipcm2AreaLeft;
    codingCfg.ipcm2Area.bottom = tb->ipcm2AreaBottom;
    codingCfg.ipcm2Area.right = tb->ipcm2AreaRight;
//    codingCfg.ipcm2Area.enable = CheckArea(&codingCfg.ipcm2Area, cml);

    codingCfg.ipcm3Area.top    = tb->ipcm3AreaTop;
    codingCfg.ipcm3Area.left   = tb->ipcm3AreaLeft;
    codingCfg.ipcm3Area.bottom = tb->ipcm3AreaBottom;
    codingCfg.ipcm3Area.right  = tb->ipcm3AreaRight;
//    codingCfg.ipcm3Area.enable = CheckArea(&codingCfg.ipcm3Area, cml);

    codingCfg.ipcm4Area.top    = tb->ipcm4AreaTop;
    codingCfg.ipcm4Area.left   = tb->ipcm4AreaLeft;
    codingCfg.ipcm4Area.bottom = tb->ipcm4AreaBottom;
    codingCfg.ipcm4Area.right  = tb->ipcm4AreaRight;
//    codingCfg.ipcm4Area.enable = CheckArea(&codingCfg.ipcm4Area, cml);

    codingCfg.ipcm5Area.top    = tb->ipcm5AreaTop;
    codingCfg.ipcm5Area.left   = tb->ipcm5AreaLeft;
    codingCfg.ipcm5Area.bottom = tb->ipcm5AreaBottom;
    codingCfg.ipcm5Area.right  = tb->ipcm5AreaRight;
//    codingCfg.ipcm5Area.enable = CheckArea(&codingCfg.ipcm5Area, cml);

    codingCfg.ipcm6Area.top    = tb->ipcm6AreaTop;
    codingCfg.ipcm6Area.left   = tb->ipcm6AreaLeft;
    codingCfg.ipcm6Area.bottom = tb->ipcm6AreaBottom;
    codingCfg.ipcm6Area.right  = tb->ipcm6AreaRight;
//    codingCfg.ipcm6Area.enable = CheckArea(&codingCfg.ipcm6Area, cml);

    codingCfg.ipcm7Area.top    = tb->ipcm7AreaTop;
    codingCfg.ipcm7Area.left   = tb->ipcm7AreaLeft;
    codingCfg.ipcm7Area.bottom = tb->ipcm7AreaBottom;
    codingCfg.ipcm7Area.right  = tb->ipcm7AreaRight;
//    codingCfg.ipcm7Area.enable = CheckArea(&codingCfg.ipcm7Area, cml);

    codingCfg.ipcm8Area.top    = tb->ipcm8AreaTop;
    codingCfg.ipcm8Area.left   = tb->ipcm8AreaLeft;
    codingCfg.ipcm8Area.bottom = tb->ipcm8AreaBottom;
    codingCfg.ipcm8Area.right  = tb->ipcm8AreaRight;
//    codingCfg.ipcm8Area.enable = CheckArea(&codingCfg.ipcm8Area, cml);

    codingCfg.ipcmMapEnable = tb->ipcmMapEnable;
    codingCfg.pcm_enabled_flag = (codingCfg.ipcm1Area.enable || codingCfg.ipcm2Area.enable || codingCfg.ipcm3Area.enable || codingCfg.ipcm4Area.enable ||
                                  codingCfg.ipcm5Area.enable || codingCfg.ipcm6Area.enable || codingCfg.ipcm7Area.enable || codingCfg.ipcm8Area.enable ||
                                  codingCfg.ipcmMapEnable);

    if(codingCfg.gdrDuration == 0)
    {
      codingCfg.roi1Area.top = tb->roi1AreaTop;
      codingCfg.roi1Area.left = tb->roi1AreaLeft;
      codingCfg.roi1Area.bottom = tb->roi1AreaBottom;
      codingCfg.roi1Area.right = tb->roi1AreaRight;
//      if (CheckArea(&codingCfg.roi1Area, cml) && (tb->roi1DeltaQp || (tb->roi1Qp >= 0)))
//        codingCfg.roi1Area.enable = 1;
//      else
//        codingCfg.roi1Area.enable = 0;
    }
    else
    {
      codingCfg.roi1Area.enable = 0;
    }

      codingCfg.roi1Area.enable = 0;

    codingCfg.roi2Area.top = tb->roi2AreaTop;
    codingCfg.roi2Area.left = tb->roi2AreaLeft;
    codingCfg.roi2Area.bottom = tb->roi2AreaBottom;
    codingCfg.roi2Area.right = tb->roi2AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi2Area, cml) && (tb->roi2DeltaQp || (tb->roi2Qp >= 0)))
      codingCfg.roi2Area.enable = 1;
    else
      codingCfg.roi2Area.enable = 0;
#endif

    codingCfg.roi3Area.top = tb->roi3AreaTop;
    codingCfg.roi3Area.left = tb->roi3AreaLeft;
    codingCfg.roi3Area.bottom = tb->roi3AreaBottom;
    codingCfg.roi3Area.right = tb->roi3AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi3Area, cml) && (tb->roi3DeltaQp || (tb->roi3Qp >= 0)))
      codingCfg.roi3Area.enable = 1;
    else
      codingCfg.roi3Area.enable = 0;
#endif

    codingCfg.roi4Area.top = tb->roi4AreaTop;
    codingCfg.roi4Area.left = tb->roi4AreaLeft;
    codingCfg.roi4Area.bottom = tb->roi4AreaBottom;
    codingCfg.roi4Area.right = tb->roi4AreaRight;
#if 0
    if (CheckArea(&codingCfg.roi4Area, cml) && (tb->roi4DeltaQp || (tb->roi4Qp >= 0)))
      codingCfg.roi4Area.enable = 1;
    else
      codingCfg.roi4Area.enable = 0;
#endif

    codingCfg.roi5Area.top = tb->roi5AreaTop;
    codingCfg.roi5Area.left = tb->roi5AreaLeft;
    codingCfg.roi5Area.bottom = tb->roi5AreaBottom;
    codingCfg.roi5Area.right = tb->roi5AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi5Area, cml) && (tb->roi5DeltaQp || (tb->roi5Qp >= 0)))
      codingCfg.roi5Area.enable = 1;
    else
      codingCfg.roi5Area.enable = 0;
#endif

    codingCfg.roi6Area.top = tb->roi6AreaTop;
    codingCfg.roi6Area.left = tb->roi6AreaLeft;
    codingCfg.roi6Area.bottom = tb->roi6AreaBottom;
    codingCfg.roi6Area.right = tb->roi6AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi6Area, cml) && (tb->roi6DeltaQp || (tb->roi6Qp >= 0)))
      codingCfg.roi6Area.enable = 1;
    else
      codingCfg.roi6Area.enable = 0;
#endif

    codingCfg.roi7Area.top = tb->roi7AreaTop;
    codingCfg.roi7Area.left = tb->roi7AreaLeft;
    codingCfg.roi7Area.bottom = tb->roi7AreaBottom;
    codingCfg.roi7Area.right = tb->roi7AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi7Area, cml) && (tb->roi7DeltaQp || (tb->roi7Qp >= 0)))
      codingCfg.roi7Area.enable = 1;
    else
      codingCfg.roi7Area.enable = 0;
#endif

    codingCfg.roi8Area.top = tb->roi8AreaTop;
    codingCfg.roi8Area.left = tb->roi8AreaLeft;
    codingCfg.roi8Area.bottom = tb->roi8AreaBottom;
    codingCfg.roi8Area.right = tb->roi8AreaRight;

#if 0
    if (CheckArea(&codingCfg.roi8Area, cml) && (tb->roi8DeltaQp || (tb->roi8Qp >= 0)))
      codingCfg.roi8Area.enable = 1;
    else
      codingCfg.roi8Area.enable = 0;
#endif

    codingCfg.roi1DeltaQp = tb->roi1DeltaQp;
    codingCfg.roi2DeltaQp = tb->roi2DeltaQp;
    codingCfg.roi3DeltaQp = tb->roi3DeltaQp;
    codingCfg.roi4DeltaQp = tb->roi4DeltaQp;
    codingCfg.roi5DeltaQp = tb->roi5DeltaQp;
    codingCfg.roi6DeltaQp = tb->roi6DeltaQp;
    codingCfg.roi7DeltaQp = tb->roi7DeltaQp;
    codingCfg.roi8DeltaQp = tb->roi8DeltaQp;
    codingCfg.roi1Qp = tb->roi1Qp;
    codingCfg.roi2Qp = tb->roi2Qp;
    codingCfg.roi3Qp = tb->roi3Qp;
    codingCfg.roi4Qp = tb->roi4Qp;
    codingCfg.roi5Qp = tb->roi5Qp;
    codingCfg.roi6Qp = tb->roi6Qp;
    codingCfg.roi7Qp = tb->roi7Qp;
    codingCfg.roi8Qp = tb->roi8Qp;


    if (codingCfg.cirInterval)
      printf("  CIR: %d %d\n",
             codingCfg.cirStart, codingCfg.cirInterval);

    if (codingCfg.intraArea.enable)
      printf("  IntraArea: %dx%d-%dx%d\n",
             codingCfg.intraArea.left, codingCfg.intraArea.top,
             codingCfg.intraArea.right, codingCfg.intraArea.bottom);

    if (codingCfg.ipcm1Area.enable)
      printf("  IPCM1Area: %dx%d-%dx%d\n",
             codingCfg.ipcm1Area.left, codingCfg.ipcm1Area.top,
             codingCfg.ipcm1Area.right, codingCfg.ipcm1Area.bottom);

    if (codingCfg.ipcm2Area.enable)
      printf("  IPCM2Area: %dx%d-%dx%d\n",
             codingCfg.ipcm2Area.left, codingCfg.ipcm2Area.top,
             codingCfg.ipcm2Area.right, codingCfg.ipcm2Area.bottom);

    if (codingCfg.ipcm3Area.enable)
      printf("  IPCM3Area: %dx%d-%dx%d\n",
             codingCfg.ipcm3Area.left, codingCfg.ipcm3Area.top,
             codingCfg.ipcm3Area.right, codingCfg.ipcm3Area.bottom);

    if (codingCfg.ipcm4Area.enable)
      printf("  IPCM4Area: %dx%d-%dx%d\n",
             codingCfg.ipcm4Area.left, codingCfg.ipcm4Area.top,
             codingCfg.ipcm4Area.right, codingCfg.ipcm4Area.bottom);

    if (codingCfg.ipcm5Area.enable)
      printf("  IPCM5Area: %dx%d-%dx%d\n",
             codingCfg.ipcm5Area.left, codingCfg.ipcm5Area.top,
             codingCfg.ipcm5Area.right, codingCfg.ipcm5Area.bottom);

    if (codingCfg.ipcm6Area.enable)
      printf("  IPCM6Area: %dx%d-%dx%d\n",
             codingCfg.ipcm6Area.left, codingCfg.ipcm6Area.top,
             codingCfg.ipcm6Area.right, codingCfg.ipcm6Area.bottom);

    if (codingCfg.ipcm7Area.enable)
      printf("  IPCM7Area: %dx%d-%dx%d\n",
             codingCfg.ipcm7Area.left, codingCfg.ipcm7Area.top,
             codingCfg.ipcm7Area.right, codingCfg.ipcm7Area.bottom);

    if (codingCfg.ipcm8Area.enable)
      printf("  IPCM8Area: %dx%d-%dx%d\n",
             codingCfg.ipcm8Area.left, codingCfg.ipcm8Area.top,
             codingCfg.ipcm8Area.right, codingCfg.ipcm8Area.bottom);

    if (codingCfg.roi1Area.enable)
      printf("  ROI 1: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi1Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi1Qp >= 0 ? codingCfg.roi1Qp : codingCfg.roi1DeltaQp,
             codingCfg.roi1Area.left, codingCfg.roi1Area.top,
             codingCfg.roi1Area.right, codingCfg.roi1Area.bottom);

    if (codingCfg.roi2Area.enable)
      printf("  ROI 2: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi2Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi2Qp >= 0 ? codingCfg.roi2Qp : codingCfg.roi2DeltaQp,
             codingCfg.roi2Area.left, codingCfg.roi2Area.top,
             codingCfg.roi2Area.right, codingCfg.roi2Area.bottom);

    if (codingCfg.roi3Area.enable)
      printf("  ROI 3: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi3Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi3Qp >= 0 ? codingCfg.roi3Qp : codingCfg.roi3DeltaQp,
             codingCfg.roi3Area.left, codingCfg.roi3Area.top,
             codingCfg.roi3Area.right, codingCfg.roi3Area.bottom);

    if (codingCfg.roi4Area.enable)
      printf("  ROI 4: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi4Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi4Qp >= 0 ? codingCfg.roi4Qp : codingCfg.roi4DeltaQp,
             codingCfg.roi4Area.left, codingCfg.roi4Area.top,
             codingCfg.roi4Area.right, codingCfg.roi4Area.bottom);

    if (codingCfg.roi5Area.enable)
      printf("  ROI 5: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi5Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi5Qp >= 0 ? codingCfg.roi5Qp : codingCfg.roi5DeltaQp,
             codingCfg.roi5Area.left, codingCfg.roi5Area.top,
             codingCfg.roi5Area.right, codingCfg.roi5Area.bottom);

    if (codingCfg.roi6Area.enable)
      printf("  ROI 6: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi6Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi6Qp >= 0 ? codingCfg.roi6Qp : codingCfg.roi6DeltaQp,
             codingCfg.roi6Area.left, codingCfg.roi6Area.top,
             codingCfg.roi6Area.right, codingCfg.roi6Area.bottom);

    if (codingCfg.roi7Area.enable)
      printf("  ROI 7: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi7Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi7Qp >= 0 ? codingCfg.roi7Qp : codingCfg.roi7DeltaQp,
             codingCfg.roi7Area.left, codingCfg.roi7Area.top,
             codingCfg.roi7Area.right, codingCfg.roi7Area.bottom);

    if (codingCfg.roi8Area.enable)
      printf("  ROI 8: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi8Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi8Qp >= 0 ? codingCfg.roi8Qp : codingCfg.roi8DeltaQp,
             codingCfg.roi8Area.left, codingCfg.roi8Area.top,
             codingCfg.roi8Area.right, codingCfg.roi8Area.bottom);

    codingCfg.roiMapDeltaQpEnable = tb->roiMapDeltaQpEnable;
    codingCfg.roiMapDeltaQpBlockUnit = tb->roiMapDeltaQpBlockUnit;
    /* enable roiMap if lookaheadDepth for qpDelta mapping */
    if (tb->lookaheadDepth)
    {
      codingCfg.roiMapDeltaQpEnable = 1;
      codingCfg.roiMapDeltaQpBlockUnit = IS_AV1(tb->codecFormat) ? 0 : MAX(1, tb->roiMapDeltaQpBlockUnit);
    }

    codingCfg.RoimapCuCtrl_index_enable = (tb->RoimapCuCtrlIndexBinFile != NULL);
    codingCfg.RoimapCuCtrl_enable       = (tb->RoimapCuCtrlInfoBinFile != NULL);
	  /* add (tb->RoiQpDeltaVer != 4)for only rdoq map (roiMapVersion==4) */
	  codingCfg.roiMapDeltaQpBinEnable    = (tb->roiMapInfoBinFile != NULL) && (tb->RoiQpDeltaVer != 4);
    codingCfg.RoimapCuCtrl_ver          = tb->RoiCuCtrlVer;
    codingCfg.RoiQpDelta_ver            = tb->RoiQpDeltaVer;


    /* SKIP map */
    codingCfg.skipMapEnable = tb->skipMapEnable;

    /* RDOQ map */
    codingCfg.rdoqMapEnable = tb->rdoqMapEnable;

    codingCfg.enableScalingList = tb->enableScalingList;
    codingCfg.chroma_qp_offset= tb->chromaQpOffset;

    /* low latency */
    codingCfg.inputLineBufEn = (tb->inputLineBufMode>0) ? 1 : 0;
    codingCfg.inputLineBufLoopBackEn = (tb->inputLineBufMode==1||tb->inputLineBufMode==2) ? 1 : 0;
    if (tb->inputLineBufDepth != DEFAULT) codingCfg.inputLineBufDepth = tb->inputLineBufDepth;
    codingCfg.amountPerLoopBack = tb->amountPerLoopBack;
    codingCfg.inputLineBufHwModeEn = (tb->inputLineBufMode==2||tb->inputLineBufMode==4) ? 1 : 0;
    codingCfg.inputLineBufCbFunc = VCEncInputLineBufDone;
    codingCfg.inputLineBufCbData = &(tb->inputCtbLineBuf);
    codingCfg.sbi_id_0 = 0;
    codingCfg.sbi_id_1 = 1;
    codingCfg.sbi_id_2 = 2;

#if 0
    /*stream multi-segment*/
    codingCfg.streamMultiSegmentMode = tb->streamMultiSegmentMode;
    codingCfg.streamMultiSegmentAmount = tb->streamMultiSegmentAmount;
    codingCfg.streamMultiSegCbFunc = &EncStreamSegmentReady;
    codingCfg.streamMultiSegCbData = &(tb->streamSegCtl);
#endif

    /* denoise */
    codingCfg.noiseReductionEnable = tb->noiseReductionEnable;//0: disable noise reduction; 1: enable noise reduction
    if(tb->noiseLow == 0)
    {
        codingCfg.noiseLow = 10;
    }
    else
    {
        codingCfg.noiseLow = CLIP3(1, 30, tb->noiseLow);//0: use default value; valid value range: [1, 30]
    }

    if(tb->firstFrameSigma == 0)
    {
        codingCfg.firstFrameSigma = 11;
    }
    else
    {
        codingCfg.firstFrameSigma = CLIP3(1, 30, tb->firstFrameSigma);
    }

    /* smart */
    codingCfg.smartModeEnable = tb->smartModeEnable;
    codingCfg.smartH264LumDcTh = tb->smartH264LumDcTh;
    codingCfg.smartH264CbDcTh = tb->smartH264CbDcTh;
    codingCfg.smartH264CrDcTh = tb->smartH264CrDcTh;
    for(i = 0; i < 3; i++) {
      codingCfg.smartHevcLumDcTh[i] = tb->smartHevcLumDcTh[i];
      codingCfg.smartHevcChrDcTh[i] = tb->smartHevcChrDcTh[i];
      codingCfg.smartHevcLumAcNumTh[i] = tb->smartHevcLumAcNumTh[i];
      codingCfg.smartHevcChrAcNumTh[i] = tb->smartHevcChrAcNumTh[i];
    }
    codingCfg.smartH264Qp = tb->smartH264Qp;
    codingCfg.smartHevcLumQp = tb->smartHevcLumQp;
    codingCfg.smartHevcChrQp = tb->smartHevcChrQp;
    for(i = 0; i < 4; i++)
      codingCfg.smartMeanTh[i] = tb->smartMeanTh[i];
    codingCfg.smartPixNumCntTh = tb->smartPixNumCntTh;

    /* tile */
    codingCfg.tiles_enabled_flag = tb->tiles_enabled_flag && !IS_H264(tb->codecFormat);
    codingCfg.num_tile_columns = tb->num_tile_columns;
    codingCfg.num_tile_rows       = tb->num_tile_rows;
    codingCfg.loop_filter_across_tiles_enabled_flag = tb->loop_filter_across_tiles_enabled_flag;

    /* HDR10 */
    codingCfg.Hdr10Display.hdr10_display_enable = tb->hdr10_display_enable;
    if (tb->hdr10_display_enable)
    {
    	codingCfg.Hdr10Display.hdr10_dx0 = tb->hdr10_dx0;
    	codingCfg.Hdr10Display.hdr10_dy0 = tb->hdr10_dy0;
    	codingCfg.Hdr10Display.hdr10_dx1 = tb->hdr10_dx1;
    	codingCfg.Hdr10Display.hdr10_dy1 = tb->hdr10_dy1;
    	codingCfg.Hdr10Display.hdr10_dx2 = tb->hdr10_dx2;
    	codingCfg.Hdr10Display.hdr10_dy2 = tb->hdr10_dy2;
    	codingCfg.Hdr10Display.hdr10_wx  = tb->hdr10_wx;
    	codingCfg.Hdr10Display.hdr10_wy  = tb->hdr10_wy;
    	codingCfg.Hdr10Display.hdr10_maxluma = tb->hdr10_maxluma;
    	codingCfg.Hdr10Display.hdr10_minluma = tb->hdr10_minluma;
    }

    codingCfg.Hdr10LightLevel.hdr10_lightlevel_enable = tb->hdr10_lightlevel_enable;
    if (tb->hdr10_lightlevel_enable)
    {
    	codingCfg.Hdr10LightLevel.hdr10_maxlight = tb->hdr10_maxlight;
    	codingCfg.Hdr10LightLevel.hdr10_avglight = tb->hdr10_avglight;
    }

    // vui information
    codingCfg.spsVuiParam.vuiVideoSignalTypePresentFlag = tb->vuiVideoSignalTypePresentFlag;
    codingCfg.spsVuiParam.vuiColorDescripPresentFlag    = tb->vuiColorDescripPresentFlag;
    codingCfg.spsVuiParam.vuiColorPrimaries             = tb->vuiColorPrimaries;
    codingCfg.spsVuiParam.vuiTransferCharacteristics    = tb->vuiTransferCharacteristics;
    codingCfg.spsVuiParam.vuiMatrixCoefficients         = tb->vuiMatrixCoefficients;
    codingCfg.vuiVideoFormat                            = tb->vuiVideoFormat;

    codingCfg.sampleAspectRatioHeight          = tb->vuiAspectRatioHeight;
    codingCfg.sampleAspectRatioWidth           = tb->vuiAspectRatioWidth;

    codingCfg.RpsInSliceHeader = tb->RpsInSliceHeader;

    /* Assign ME vertical search range */
    codingCfg.meVertSearchRange = tb->MEVertRange;

    if(tb->psyFactor != DEFAULT)
      codingCfg.psyFactor = tb->psyFactor;
    if(tb->aq_mode != DEFAULT)
      codingCfg.aq_mode   = tb->aq_mode;
    if(tb->aq_strength != DEFAULT)
      codingCfg.aq_strength   = tb->aq_strength;

    if ((ret = VCEncSetCodingCtrl(encoder, &codingCfg)) != VCENC_OK)
    {
      //PrintErrorValue("VCEncSetCodingCtrl() failed.", ret);
      CloseEncoder(encoder, tb);
      return -1;
    }

  }

  /* Encoder setup: rate control */
  if ((ret = VCEncGetRateCtrl(encoder, &tb->rcCfg)) != VCENC_OK)
  {
    //PrintErrorValue("VCEncGetRateCtrl() failed.", ret);
    CloseEncoder(encoder, tb);
    return -1;
  }
  else
  {
    VLOG_DEBUG("Get rate control: qp %2d qpRange I[%2d, %2d] PB[%2d, %2d] %8d bps  "
           "pic %d skip %d  hrd %d  cpbSize %d cpbMaxRate %d bitrateWindow %d "
           "intraQpDelta %2d\n",
           tb->rcCfg.qpHdr, tb->rcCfg.qpMinI, tb->rcCfg.qpMaxI, tb->rcCfg.qpMinPB, tb->rcCfg.qpMaxPB, tb->rcCfg.bitPerSecond,
           tb->rcCfg.pictureRc, tb->rcCfg.pictureSkip, tb->rcCfg.hrd,
           tb->rcCfg.hrdCpbSize, tb->rcCfg.cpbMaxRate, tb->rcCfg.bitrateWindow, tb->rcCfg.intraQpDelta);

    if (tb->qpHdr != DEFAULT)
      tb->rcCfg.qpHdr = tb->qpHdr;
    else
      tb->rcCfg.qpHdr = -1;
    if (tb->qpMin != DEFAULT)
      tb->rcCfg.qpMinI = tb->rcCfg.qpMinPB = tb->qpMin;
    if (tb->qpMax != DEFAULT)
      tb->rcCfg.qpMaxI = tb->rcCfg.qpMaxPB = tb->qpMax;
    if (tb->qpMinI != DEFAULT)
      tb->rcCfg.qpMinI = tb->qpMinI;
    if (tb->qpMaxI != DEFAULT)
      tb->rcCfg.qpMaxI = tb->qpMaxI;
    if (tb->picSkip != DEFAULT)
      tb->rcCfg.pictureSkip = tb->picSkip;
    if (tb->picRc != DEFAULT)
      tb->rcCfg.pictureRc = tb->picRc;
    if (tb->ctbRc != DEFAULT)
    {
      if(tb->ctbRc == 4 || tb->ctbRc == 6)
      {
        tb->rcCfg.ctbRc = tb->ctbRc - 3;
        tb->rcCfg.ctbRcQpDeltaReverse = 1;
      }
      else
      {
        tb->rcCfg.ctbRc = tb->ctbRc;
        tb->rcCfg.ctbRcQpDeltaReverse = 0;
      }
    }

    tb->rcCfg.blockRCSize = 0;
    if (tb->blockRCSize != DEFAULT)
      tb->rcCfg.blockRCSize = tb->blockRCSize;

    tb->rcCfg.rcQpDeltaRange = 10;
    if (tb->rcQpDeltaRange != DEFAULT)
      tb->rcCfg.rcQpDeltaRange = tb->rcQpDeltaRange;

    tb->rcCfg.rcBaseMBComplexity = 15;
    if (tb->rcBaseMBComplexity != DEFAULT)
      tb->rcCfg.rcBaseMBComplexity = tb->rcBaseMBComplexity;

    if (tb->picQpDeltaMax != DEFAULT)
      tb->rcCfg.picQpDeltaMax = tb->picQpDeltaMax;
    if (tb->picQpDeltaMin != DEFAULT)
      tb->rcCfg.picQpDeltaMin = tb->picQpDeltaMin;
    if (tb->bitPerSecond != DEFAULT)
      tb->rcCfg.bitPerSecond = tb->bitPerSecond;
    if (tb->cpbMaxRate != DEFAULT)
      tb->rcCfg.cpbMaxRate = tb->cpbMaxRate;
    if (tb->bitVarRangeI != DEFAULT)
      tb->rcCfg.bitVarRangeI = tb->bitVarRangeI;
    if (tb->bitVarRangeP != DEFAULT)
      tb->rcCfg.bitVarRangeP = tb->bitVarRangeP;
    if (tb->bitVarRangeB != DEFAULT)
      tb->rcCfg.bitVarRangeB = tb->bitVarRangeB;

    if (tb->tolMovingBitRate != DEFAULT)
      tb->rcCfg.tolMovingBitRate = tb->tolMovingBitRate;

    if (tb->tolCtbRcInter != DEFAULT)
      tb->rcCfg.tolCtbRcInter = tb->tolCtbRcInter;

    if (tb->tolCtbRcIntra != DEFAULT)
      tb->rcCfg.tolCtbRcIntra = tb->tolCtbRcIntra;

    if (tb->ctbRcRowQpStep != DEFAULT)
      tb->rcCfg.ctbRcRowQpStep = tb->ctbRcRowQpStep;

    tb->rcCfg.longTermQpDelta = tb->longTermQpDelta;

    if (tb->monitorFrames != DEFAULT)
      tb->rcCfg.monitorFrames = tb->monitorFrames;
    else
    {
      tb->rcCfg.monitorFrames =(tb->outputRateNumer+tb->outputRateDenom-1) / tb->outputRateDenom;
      tb->monitorFrames = (tb->outputRateNumer+tb->outputRateDenom-1) / tb->outputRateDenom;
    }

    if(tb->rcCfg.monitorFrames>MOVING_AVERAGE_FRAMES)
      tb->rcCfg.monitorFrames=MOVING_AVERAGE_FRAMES;

    if (tb->rcCfg.monitorFrames < 10)
    {
      tb->rcCfg.monitorFrames = (tb->outputRateNumer > tb->outputRateDenom)? 10:LEAST_MONITOR_FRAME;
    }

    if (tb->hrdConformance != DEFAULT)
      tb->rcCfg.hrd = tb->hrdConformance;

    if (tb->cpbSize != DEFAULT)
      tb->rcCfg.hrdCpbSize = tb->cpbSize;

    if (tb->intraPicRate != 0)
      tb->rcCfg.bitrateWindow = MIN(tb->intraPicRate, MAX_GOP_LEN);

    if (tb->bitrateWindow != DEFAULT)
      tb->rcCfg.bitrateWindow = tb->bitrateWindow;

    if (tb->intraQpDelta != DEFAULT)
      tb->rcCfg.intraQpDelta = tb->intraQpDelta;

    if (tb->vbr != DEFAULT)
      tb->rcCfg.vbr = tb->vbr;

    if (tb->crf != DEFAULT)
      tb->rcCfg.crf = tb->crf;

    tb->rcCfg.fixedIntraQp = tb->fixedIntraQp;
    tb->rcCfg.smoothPsnrInGOP = tb->smoothPsnrInGOP;
    tb->rcCfg.u32StaticSceneIbitPercent = tb->u32StaticSceneIbitPercent;

    tb->rcCfg.frameRateNum = tb->outputRateNumer;
    tb->rcCfg.frameRateDenom = tb->outputRateDenom;
    tb->rcCfg.IpropMax = tb->IpropMax;
    tb->rcCfg.IpropMin = tb->IpropMin;
    tb->rcCfg.GopSize = tb->intraPicRate;
    
    VLOG_DEBUG("Set rate control: qp %2d qpRange I[%2d, %2d] PB[%2d, %2d] %9d bps  "
           "pic %d skip %d  hrd %d"
           "  cpbSize %d cpbMaxRate %d bitrateWindow %d intraQpDelta %2d "
           "fixedIntraQp %2d\n",
           tb->rcCfg.qpHdr, tb->rcCfg.qpMinI, tb->rcCfg.qpMaxI, tb->rcCfg.qpMinPB, tb->rcCfg.qpMaxPB, tb->rcCfg.bitPerSecond,
           tb->rcCfg.pictureRc, tb->rcCfg.pictureSkip, tb->rcCfg.hrd,
           tb->rcCfg.hrdCpbSize, tb->rcCfg.cpbMaxRate, tb->rcCfg.bitrateWindow, tb->rcCfg.intraQpDelta,
           tb->rcCfg.fixedIntraQp);

    ret = VCEncSetRateCtrl(encoder, &tb->rcCfg);
    if (ret != VCENC_OK) {
      VLOG_ERROR("VCEncSetRateCtrl() failed, ret = %d", ret);
      CloseEncoder(encoder, tb);
      return -1;
    }
  }

  /* Optional scaled image output */
  if (tb->scaledWidth * tb->scaledHeight > 0)
  {
    i32 dsFrmSize = tb->scaledWidth * tb->scaledHeight * 2;
    /* the scaled image size changes frame by frame when testing down-scaling */
    if (tb->testId == 34)
    {
      dsFrmSize = tb->width * tb->height * 2;
    }
    if((tb->bitDepthLuma!=8) || (tb->bitDepthChroma!=8))
      dsFrmSize <<= 1;

    if (tb->scaledOutputFormat == 1)
      dsFrmSize = dsFrmSize *3 /4;

    tb->scaledPictureMem.mem_type = EWL_MEM_TYPE_DPB;
    if (EWLMallocRefFrm(ewl_inst, dsFrmSize, 0, &tb->scaledPictureMem) != EWL_OK)
    {
      tb->scaledPictureMem.virtualAddress = NULL;
      tb->scaledPictureMem.busAddress = 0;
    }
  }

  /* PreP setup */
  if ((ret = VCEncGetPreProcessing(encoder, &preProcCfg)) != VCENC_OK)
  {
    //PrintErrorValue("VCEncGetPreProcessing() failed.", ret);
    CloseEncoder(encoder, tb);
    return -1;
  }

  VLOG_DEBUG("Get PreP: input %4dx%d : offset %4dx%d : format %d : rotation %d"
   "cc %d : scaling %d\n",
   preProcCfg.origWidth, preProcCfg.origHeight, preProcCfg.xOffset,
   preProcCfg.yOffset, preProcCfg.inputType, preProcCfg.rotation,
   preProcCfg.colorConversion.type,
   preProcCfg.scaledOutput);

  preProcCfg.inputType = (VCEncPictureType)tb->inputFormat;
  preProcCfg.rotation = (VCEncPictureRotation)tb->rotation;
  preProcCfg.mirror = (VCEncPictureMirror)tb->mirror;

  preProcCfg.origWidth = tb->lumWidthSrc;
  preProcCfg.origHeight = tb->lumHeightSrc;

  if (tb->horOffsetSrc != DEFAULT)
    preProcCfg.xOffset = tb->horOffsetSrc;
  if (tb->verOffsetSrc != DEFAULT)
    preProcCfg.yOffset = tb->verOffsetSrc;

  /* assume input is a frame and we'll seperate it as two field for interlace encoding */
  if(tb->interlacedFrame)
  {
    preProcCfg.origWidth *= 2;
    preProcCfg.origHeight /= 2;
    preProcCfg.yOffset /= 2;
  }

  /* stab setup */
  preProcCfg.videoStabilization = 0;
  if (tb->videoStab != DEFAULT)
  {
    preProcCfg.videoStabilization = tb->videoStab;
  }

  if (tb->colorConversion != DEFAULT)
    preProcCfg.colorConversion.type =
      (VCEncColorConversionType)tb->colorConversion;
  if (preProcCfg.colorConversion.type == VCENC_RGBTOYUV_USER_DEFINED)
  {
    preProcCfg.colorConversion.coeffA = 20000;
    preProcCfg.colorConversion.coeffB = 44000;
    preProcCfg.colorConversion.coeffC = 5000;
    preProcCfg.colorConversion.coeffE = 35000;
    preProcCfg.colorConversion.coeffF = 38000;
    preProcCfg.colorConversion.coeffG = 35000;
    preProcCfg.colorConversion.coeffH = 38000;
    preProcCfg.colorConversion.LumaOffset = 0;
  }

  if (tb->rotation&&tb->rotation!=3)
  {
    preProcCfg.scaledWidth = tb->scaledHeight;
    preProcCfg.scaledHeight = tb->scaledWidth;
  }
  else
  {
    preProcCfg.scaledWidth = tb->scaledWidth;
    preProcCfg.scaledHeight = tb->scaledHeight;
  }
  preProcCfg.busAddressScaledBuff = tb->scaledPictureMem.busAddress;
  preProcCfg.virtualAddressScaledBuff = tb->scaledPictureMem.virtualAddress;
  preProcCfg.sizeScaledBuff = tb->scaledPictureMem.size;
  preProcCfg.input_alignment = 1<<tb->exp_of_input_alignment;
  preProcCfg.scaledOutputFormat = tb->scaledOutputFormat;

  VLOG_DEBUG("Set PreP: input %4dx%d : offset %4dx%d : format %d : rotation %d"
   "cc %d : scaling %d : scaling format %d\n",
   preProcCfg.origWidth, preProcCfg.origHeight, preProcCfg.xOffset,
   preProcCfg.yOffset, preProcCfg.inputType, preProcCfg.rotation,
   preProcCfg.colorConversion.type,
   preProcCfg.scaledOutput, preProcCfg.scaledOutputFormat);

  if(tb->scaledWidth*tb->scaledHeight > 0)
    preProcCfg.scaledOutput=1;

   /* constant chroma control */
   preProcCfg.constChromaEn = tb->constChromaEn;
   if (tb->constCb != DEFAULT)
     preProcCfg.constCb = tb->constCb;
   if (tb->constCr != DEFAULT)
     preProcCfg.constCr = tb->constCr;

  //ChangeToCustomizedFormat(cml,&preProcCfg);

  /* Set overlay area*/
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    preProcCfg.overlayArea[i].xoffset = tb->olXoffset[i];
    preProcCfg.overlayArea[i].cropXoffset = tb->olCropXoffset[i];
    preProcCfg.overlayArea[i].yoffset = tb->olYoffset[i];
    preProcCfg.overlayArea[i].cropYoffset = tb->olCropYoffset[i];
    preProcCfg.overlayArea[i].width = tb->olWidth[i];
    preProcCfg.overlayArea[i].cropWidth = tb->olCropWidth[i];
    preProcCfg.overlayArea[i].height = tb->olHeight[i];
    preProcCfg.overlayArea[i].cropHeight = tb->olCropHeight[i];
    preProcCfg.overlayArea[i].format = tb->olFormat[i];
    preProcCfg.overlayArea[i].alpha = tb->olAlpha[i];
    preProcCfg.overlayArea[i].enable = (tb->overlayEnables >> i) & 1;
    preProcCfg.overlayArea[i].Ystride = tb->olYStride[i];
    preProcCfg.overlayArea[i].UVstride = tb->olUVStride[i];
    preProcCfg.overlayArea[i].bitmapY = tb->olBitmapY[i];
    preProcCfg.overlayArea[i].bitmapU = tb->olBitmapU[i];
    preProcCfg.overlayArea[i].bitmapV = tb->olBitmapV[i];
    preProcCfg.overlayArea[i].superTile = tb->olSuperTile[i];
    preProcCfg.overlayArea[i].scaleWidth = tb->olScaleWidth[i];
    preProcCfg.overlayArea[i].scaleHeight = tb->olScaleHeight[i];
  }

  /* Set mosaic region parameters */
  for(i = 0; i < MAX_MOSAIC_NUM; i++)
  {
    preProcCfg.mosEnable[i] = (tb->mosaicEnables >> i) & 1;
    preProcCfg.mosXoffset[i] = tb->mosXoffset[i];
    preProcCfg.mosYoffset[i] = tb->mosYoffset[i];
    preProcCfg.mosWidth[i] = tb->mosWidth[i];
    preProcCfg.mosHeight[i] = tb->mosHeight[i];
  }
  for (i = 0;i < 3; i++) {
    preProcCfg.stride[i] = tb->u32PicStride[i];
  }
  if ((ret = VCEncSetPreProcessing(encoder, &preProcCfg)) != VCENC_OK)
  {
    //PrintErrorValue("VCEncSetPreProcessing() failed.", ret);
    CloseEncoder(encoder, tb);
    return (int)ret;
  }
  return 0;
}

static void processFrameNew(AX_AVCHEVC_HANDLE_S *tb, VCEncInst encoder, VCEncOut *pEncOut, SliceCtl_s *ctl,
    u64 *streamSize, u32 *maxSliceSize, ma_s *ma, u64 *total_bits, VCEncRateCtrl *rc, u32 *frameCntOutput)
{
  VCEncIn *pEncIn = &(tb->encIn);

//  if(tb->lookaheadDepth && pEncOut->codingType == VCENC_INTRA_FRAME)
//    (*frameCntOutput) = 0;

#ifdef TEST_DATA
  //show profile data, only for c-model;
  //write_recon_sw(encoder, encIn.poc);
  EncTraceUpdateStatus();
  if((tb->outReconFrame==1) && (tb->writeReconToDDR ||tb->intraPicRate != 1))
    while (EncTraceRecon(encoder, *frameCntOutput/*encIn.poc*/, tb->recon))
      (*frameCntOutput) ++;
#endif

  VCEncGetRateCtrl(encoder, rc);
  /* Write scaled encoder picture to file, packed yuyv 4:2:2 format */
  //WriteScaled((u32 *)pEncOut->scaledPicture, cml);
#ifdef TEST_DATA
  /* write cu encoding information to file <cuInfo.txt> */
  EncTraceCuInformation(encoder, &pEncOut->cuOutData, pEncOut->picture_cnt,
                           pEncIn->poc);

  /* write ctb encoded bits to file <ctbBits.txt> */
  EncTraceCtbBits(encoder, pEncOut->ctbBitsData);
#endif
  u32 ivfHeaderSize = 0;
  if (pEncOut->streamSize != 0)
  {
    //multi-core: output bitstream has (tb->parallelCoreNum-1) delay
    i32 coreIdx = (tb->picture_enc_cnt -1 - (tb->frame_delay-1)) % tb->parallelCoreNum;
    i32 iBuf;
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++) {
      tb->outbufMem[iBuf] = &(tb->outbufMemFactory[coreIdx][iBuf]);
		  VLOG_DEBUG("tb->outbufMem[iBuf]=%p\n", tb->outbufMem[iBuf]);
    }

//    if(IS_AV1(tb->codecFormat)){
//      tb->Av1PreoutbufMem = &(tb->Av1PreoutbufMemFactory[coreIdx]);
//    }

    //if((tb->streamMultiSegmentMode != 0)||(ctl->multislice_encoding==0)||(ENCH2_SLICE_READY_INTERRUPT==0)||(tb->hrdConformance==1))
	//if((tb->streamMultiSegmentMode != 0)||(ENCH2_SLICE_READY_INTERRUPT==0)||(tb->hrdConformance==1))

#if 0
    {
      VCEncStrmBufs bufs;
      getStreamBufs (&bufs, tb, HANTRO_TRUE);

      if (tb->streamSegCtl.streamMultiSegEn)
      {
        u8 *streamBase = tb->streamSegCtl.streamBase + (tb->streamSegCtl.streamRDCounter % tb->streamSegCtl.segmentAmount) * tb->streamSegCtl.segmentSize;
        WriteStrm(tb->streamSegCtl.outStreamFile, (u32 *)streamBase, pEncOut->streamSize - tb->streamSegCtl.streamRDCounter * tb->streamSegCtl.segmentSize, 0);
        tb->streamSegCtl.streamRDCounter = 0;
      }
      else if (tb->byteStream == 0)
      {
        //WriteNalSizesToFile(nalfile, pEncOut->pNaluSizeBuf, pEncOut->numNalus);
        writeNalsBufs(tb->out, &bufs, pEncOut->pNaluSizeBuf, pEncOut->numNalus, 0, pEncOut->sliceHeaderSize, 0);
      }
      else
      {
        if(pEncOut->sliceHeaderSize > 0)
        {
          ASSERT(tb->tiles_enabled_flag);
          writeStrmBufs(tb->out, &bufs, pEncOut->streamSize - pEncOut->sliceHeaderSize, pEncOut->sliceHeaderSize, 0);
          writeStrmBufs(tb->out, &bufs, 0, pEncOut->streamSize - pEncOut->sliceHeaderSize, 0);
        }
        else
        {
          if(IS_VP9(tb->codecFormat) || (IS_AV1(tb->codecFormat) && tb->ivf)){
            u32 offset = 0;
            for(i32 i = 0; i < pEncOut->numNalus; i++){
              writeIvfFrame(tb->out, &bufs, pEncOut->pNaluSizeBuf[i], offset, pEncOut->picture_cnt);
              offset += pEncOut->pNaluSizeBuf[i];
              ivfHeaderSize += 12;
            }
          }
          else
            writeStrmBufs(tb->out, &bufs, 0, pEncOut->streamSize, 0);
        }
      }
    }
#endif

    pEncIn->timeIncrement = tb->outputRateDenom;

    *total_bits += pEncOut->streamSize * 8;
	  *total_bits += ivfHeaderSize * 8;  //IVF frame header size
    *streamSize += pEncOut->streamSize;
    *streamSize += ivfHeaderSize;
    tb->validencodedframenumber++;
    MaAddFrame(ma, pEncOut->streamSize*8);
    *maxSliceSize = MAX(*maxSliceSize, pEncOut->maxSliceStreamSize);

#if 0
    VLOG_DEBUG("=== Encoded %i bits=%d TotalBits=%lu averagebitrate=%lu HWCycles=%d Time(us %d HW +SW), maxSliceBytes=%d.\n",
                          tb->picture_enc_cnt-1 - (tb->frame_delay-1), pEncOut->streamSize*8,
                          (long unsigned int)(*total_bits),
                          (long unsigned int)(*total_bits * tb->outputRateNumer) / ((tb->picture_enc_cnt - (tb->frame_delay-1)) * tb->outputRateDenom),
                          VCEncGetPerformance(encoder), uTimeDiff(tb->timeFrameEnd, tb->timeFrameStart),
                          pEncOut->maxSliceStreamSize);
#endif

    if(tb->picRc&&tb->validencodedframenumber>=ma->length)
    {
      tb->numbersquareoferror++;
      if(tb->maxerrorovertarget<(Ma(ma)- tb->bitPerSecond))
        tb->maxerrorovertarget=(Ma(ma)- tb->bitPerSecond);
      if(tb->maxerrorundertarget<(tb->bitPerSecond-Ma(ma)))
        tb->maxerrorundertarget=(tb->bitPerSecond-Ma(ma));
      tb->sumsquareoferror+=((float)(ABS(Ma(ma)- tb->bitPerSecond))*100/tb->bitPerSecond);
      tb->averagesquareoferror=(tb->sumsquareoferror/tb->numbersquareoferror);
      VLOG_DEBUG("RateControl(movingBitrate=%d MaxOvertarget=%d%% MaxUndertarget=%d%% AveDeviationPerframe=%f%%).\n",Ma(ma),tb->maxerrorovertarget*100/tb->bitPerSecond,tb->maxerrorundertarget*100/tb->bitPerSecond,tb->averagesquareoferror);
    }

    VLOG_DEBUG("Picture %i targetPicSize=%d actualBits=%d deviation=%.3f%%\n",
      tb->picture_enc_cnt-1 - (tb->frame_delay-1), rc->targetPicSize, pEncOut->streamSize*8,
      (pEncOut->streamSize*8*100.0f)/rc->targetPicSize-100);

    /* high risk: AX_AVCHEVC_HANDLE_S to (struct test_bench *)tb */
    EncTraceProfile(encoder, (struct test_bench *)tb, *total_bits - tb->totalBits, tb->bRdLog);
    tb->totalBits = *total_bits;
  }
}

int GetVencChnAttr(AX_S32 VeChn, const AX_VENC_CHN_ATTR_S *pstAttr, AX_AVCHEVC_HANDLE_S *pHandle, AX_VENC_CHN_ATTR_S *pstVencChnAttr)
{
	AX_S32 s32Ret = -1;

	pHandle->s32GetFrameMode = pstAttr->stVencAttr.enLinkMode;
	pHandle->stRcParam.enRcMode = pstAttr->stRcAttr.enRcMode;
	pHandle->rcCfg.rcMode = pstAttr->stRcAttr.enRcMode;
	pHandle->stChnnelAttr.stRcAttr.enRcMode = pstAttr->stRcAttr.enRcMode;
	if (PT_H264 == pstAttr->stVencAttr.enType)
		pHandle->codecFormat = VCENC_VIDEO_CODEC_H264;
	else if (PT_H265 == pstAttr->stVencAttr.enType)
		pHandle->codecFormat = VCENC_VIDEO_CODEC_HEVC;

	switch (pHandle->codecFormat)
	{
	case VCENC_VIDEO_CODEC_HEVC:
	{
		default_parameter_new(pHandle);
		pHandle->profile = pstAttr->stVencAttr.enProfile;
		pHandle->level = pstAttr->stVencAttr.enLevel;
		pHandle->tier = pstAttr->stVencAttr.enTier;

		if (VENC_RC_MODE_H265CBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH265Cbr, &pstAttr->stRcAttr.stH265Cbr, sizeof(AX_VENC_H265_CBR_S));
			pHandle->vbr = 0;
			pHandle->inputRateNumer = pHandle->stH265Cbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH265Cbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH265Cbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH265Cbr.u32BitRate * VENC_BITRATE_RATIO;
			pHandle->enRcMode = VENC_RC_MODE_H265CBR;
			/* quality control */
			pHandle->ctbRc = VCENC_CTBRC_TARRC;
			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;
			pHandle->qpMin = pHandle->stH265Cbr.u32MinQp;
			pHandle->qpMax = pHandle->stH265Cbr.u32MaxQp;
			pHandle->qpMinI = pHandle->stH265Cbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH265Cbr.u32MaxIQp;

            if(pHandle->stH265Cbr.u32IdrDeltaRange && pHandle->stH265Cbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH265Cbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_CBR;
                pHandle->stH265Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
                pstVencChnAttr->stRcAttr.stH265Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
            }

			if (pHandle->stH265Cbr.u32MaxIprop && pHandle->stH265Cbr.u32MaxIprop <= 100) {
				pHandle->IpropMax = pHandle->stH265Cbr.u32MaxIprop;
			} else {
				pHandle->IpropMax = 40;
				pHandle->stH265Cbr.u32MaxIprop = 40;
			}
			if (pHandle->stH265Cbr.u32MinIprop && pHandle->stH265Cbr.u32MinIprop <= pHandle->IpropMax) {
				pHandle->IpropMin = pHandle->stH265Cbr.u32MinIprop;
			} else {
				pHandle->IpropMin = 10;
				pHandle->stH265Cbr.u32MinIprop = 10;
			}

			pHandle->intraQpDelta = pHandle->stH265Cbr.s32IntraQpDelta;

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265Cbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH265Cbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h265 Cbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h265 Cbr Invalid qpmap qp type = %d.\n", VeChn, pHandle->stH265Cbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH265Cbr, &pHandle->stH265Cbr, sizeof(AX_VENC_H265_CBR_S));
		} else if (VENC_RC_MODE_H265VBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH265Vbr, &pstAttr->stRcAttr.stH265Vbr, sizeof(AX_VENC_H265_VBR_S));

			pHandle->vbr = 1;
			pHandle->inputRateNumer = pHandle->stH265Vbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH265Vbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH265Vbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->enRcMode = VENC_RC_MODE_H265VBR;
			/*RC param*/
			pHandle->ctbRc = VCENC_CTBRC_AVG;
			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;
			pHandle->intraQpDelta = pHandle->stH265Vbr.s32IntraQpDelta;
			pHandle->qpMin = pHandle->stH265Vbr.u32MinQp;
			pHandle->qpMax = pHandle->stH265Vbr.u32MaxQp;
			pHandle->qpMinI = pHandle->stH265Vbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH265Vbr.u32MaxIQp;
			pHandle->cpbSize = 2 * (pHandle->stH265Vbr.u32MaxBitRate * VENC_BITRATE_RATIO);
            
            if(pHandle->stH265Vbr.u32IdrDeltaRange && pHandle->stH265Vbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH265Vbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_VBR;
                pHandle->stH265Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
                pstVencChnAttr->stRcAttr.stH265Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
            }

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265Vbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265Vbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH265Vbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH265Vbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h265 Vbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h265 Vbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH265Vbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH265Vbr, &pHandle->stH265Vbr, sizeof(AX_VENC_H265_VBR_S));
		} else if (VENC_RC_MODE_H265AVBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH265AVbr, &pstAttr->stRcAttr.stH265AVbr, sizeof(AX_VENC_H265_AVBR_S));

			pHandle->vbr = 1;
			pHandle->inputRateNumer = pHandle->stH265AVbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH265AVbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH265AVbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH265AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;
			pHandle->enRcMode = VENC_RC_MODE_H265AVBR;
			/*RC param*/
			pHandle->ctbRc = VCENC_CTBRC_AVG;
			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;
			pHandle->intraQpDelta = pHandle->stH265AVbr.s32IntraQpDelta;
			pHandle->qpMin = pHandle->stH265AVbr.u32MinQp;
			pHandle->qpMax = pHandle->stH265AVbr.u32MaxQp;
			pHandle->qpMinI = pHandle->stH265AVbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH265AVbr.u32MaxIQp;
			pHandle->cpbSize = 2 * (pHandle->stH265AVbr.u32MaxBitRate * VENC_BITRATE_RATIO);

            if(pHandle->stH265AVbr.u32IdrDeltaRange && pHandle->stH265AVbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH265AVbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_AVBR;
                pHandle->stH265AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
                pstVencChnAttr->stRcAttr.stH265AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
            }

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265AVbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265AVbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH265AVbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH265AVbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h265 avbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h265 avbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH265AVbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH265AVbr, &pHandle->stH265AVbr, sizeof(AX_VENC_H265_AVBR_S));
        } else if (VENC_RC_MODE_H265CVBR == pstAttr->stRcAttr.enRcMode) {
           memcpy(&pHandle->stH265CVbr, &pstAttr->stRcAttr.stH265CVbr, sizeof(AX_VENC_H265_CVBR_S));

           pHandle->vbr = 0;
           pHandle->inputRateNumer = pHandle->stH265CVbr.u32SrcFrameRate;
           pHandle->inputRateDenom = 1;
           pHandle->outputRateNumer = pHandle->stH265CVbr.fr32DstFrameRate;
           pHandle->outputRateDenom = 1;
           pHandle->intraPicRate = pHandle->stH265CVbr.u32Gop;
           pHandle->bitPerSecond = pHandle->stH265CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;
           pHandle->enRcMode = VENC_RC_MODE_H265CVBR;
           /*RC param*/
           pHandle->ctbRc = VCENC_CTBRC_AVG;
           pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;
           pHandle->intraQpDelta = pHandle->stH265CVbr.s32IntraQpDelta;
           pHandle->qpMin = pHandle->stH265CVbr.u32MinQp;
           pHandle->qpMax = pHandle->stH265CVbr.u32MaxQp;
           pHandle->qpMinI = pHandle->stH265CVbr.u32MinIQp;
           pHandle->qpMaxI = pHandle->stH265CVbr.u32MaxIQp;

            pHandle->u32MaxBitRate = pHandle->stH265CVbr.u32MaxBitRate;
            pHandle->u32ShortTermStatTime = pHandle->stH265CVbr.u32ShortTermStatTime;
            pHandle->u32LongTermStatTime = pHandle->stH265CVbr.u32LongTermStatTime;
            pHandle->u32LongTermMaxBitrate = pHandle->stH265CVbr.u32LongTermMaxBitrate;
            pHandle->u32LongTermMinBitrate = pHandle->stH265CVbr.u32LongTermMinBitrate;
            pHandle->u32ExtraBitPercent = pHandle->stH265CVbr.u32ExtraBitPercent;
            pHandle->u32LongTermStatTimeUnit = pHandle->stH265CVbr.u32LongTermStatTimeUnit;

           pHandle->cpbSize = 2 * (pHandle->stH265CVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
           
           if(pHandle->stH265CVbr.u32IdrDeltaRange && pHandle->stH265CVbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH265CVbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_CVBR;
                pHandle->stH265CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
                pstVencChnAttr->stRcAttr.stH265CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
            }

           if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265CVbr.stQpmapInfo.enQpmapQpType)
           {
               pHandle->roiMapDeltaQpEnable = 1;
               pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265CVbr.stQpmapInfo.u32QpmapBlockUnit;
               pHandle->ctbRc = pHandle->stH265CVbr.stQpmapInfo.enCtbRcMode;
           }
           else if (VENC_QPMAP_DISABLE == pHandle->stH265CVbr.stQpmapInfo.enQpmapQpType)
           {
               VLOG_DEBUG("VencChn %d: h265 Cbr Disable QpMap.\n", VeChn);
           }
           else
           {
               VLOG_ERROR("VencChn %d: h265 Cbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH265CVbr.stQpmapInfo.enQpmapQpType);
           }

           memcpy(&pHandle->stRcParam.stH265CVbr, &pHandle->stH265CVbr, sizeof(AX_VENC_H265_CVBR_S));
		} else if (VENC_RC_MODE_H265FIXQP == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH265FixQp, &pstAttr->stRcAttr.stH265FixQp, sizeof(AX_VENC_H265_FIXQP_S));

			pHandle->inputRateNumer = pHandle->stH265FixQp.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH265FixQp.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH265FixQp.u32Gop;
			pHandle->enRcMode = VENC_RC_MODE_H265FIXQP;
			pHandle->fixedIntraQp = pHandle->stH265FixQp.u32IQp; //fix qp for I slice
			pHandle->qpHdr = pHandle->stH265FixQp.u32PQp;
			if (pHandle->stH265FixQp.u32PQp < pHandle->stH265FixQp.u32BQp)
				pHandle->bFrameQpDelta = pHandle->stH265FixQp.u32BQp - pHandle->stH265FixQp.u32PQp;
			else
				pHandle->bFrameQpDelta = pHandle->stH265FixQp.u32PQp - pHandle->stH265FixQp.u32BQp;

			VLOG_DEBUG("VencChn %d: qpHdr = %u, fixedIntraQp=%u, bFrameQpDelta=%u.\n",
				VeChn, pHandle->qpHdr, pHandle->fixedIntraQp, pHandle->bFrameQpDelta);

			memcpy(&pHandle->stRcParam.stH265FixQp, &pHandle->stH265FixQp, sizeof(AX_VENC_H265_FIXQP_S));
		} else if (VENC_RC_MODE_H265QPMAP == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH265QpMap, &pstAttr->stRcAttr.stH265QpMap, sizeof(AX_VENC_H265_QPMAP_S));

			pHandle->vbr = 1;
			pHandle->picRc = 1;
			pHandle->inputRateNumer = pHandle->stH265QpMap.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH265QpMap.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH265QpMap.u32Gop;
			pHandle->bitPerSecond = pHandle->stH265QpMap.u32TargetBitRate * VENC_BITRATE_RATIO;
			pHandle->enRcMode = VENC_RC_MODE_H265QPMAP;
			pHandle->ctbRc = VCENC_CTBRC_SUBQ;
			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH265QpMap.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->ctbRc = pHandle->stH265QpMap.enCtbRcMode;
			}
			else if (VENC_QPMAP_ENABLE_ABSQP == pHandle->stH265QpMap.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
			}
			else if (VENC_QPMAP_ENABLE_IPCM == pHandle->stH265QpMap.enQpmapQpType)
			{
				pHandle->ipcmMapEnable = 1;
				pHandle->ctbRc = pHandle->stH265QpMap.enCtbRcMode;
			}
			else
			{
				VLOG_ERROR("VencChn %d: h265 Invalid qpmap qp type = %d.\n", VeChn, pHandle->stH265QpMap.enQpmapQpType);
			}
			pHandle->roiMapDeltaQpBlockUnit = pHandle->stH265QpMap.u32QpmapBlockUnit;

			memcpy(&pHandle->stRcParam.stH265QpMap, &pHandle->stH265QpMap, sizeof(AX_VENC_H265_QPMAP_S));
		}
	}
	break;

	case VCENC_VIDEO_CODEC_H264:
	{
		default_parameter_new(pHandle);

		pHandle->profile = pstAttr->stVencAttr.enProfile;
		if (pHandle->profile == VCENC_H264_BASE_PROFILE)
			pHandle->enableCabac = 0;

		pHandle->level = pstAttr->stVencAttr.enLevel;

		if (VENC_RC_MODE_H264CBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH264Cbr, &pstAttr->stRcAttr.stH264Cbr, sizeof(AX_VENC_H264_CBR_S));

			pHandle->vbr = 0;
			pHandle->inputRateNumer = pHandle->stH264Cbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH264Cbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH264Cbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH264Cbr.u32BitRate * VENC_BITRATE_RATIO;

			pHandle->enRcMode = VENC_RC_MODE_H264CBR;

			pHandle->ctbRc = VCENC_CTBRC_AVG;
			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;
			pHandle->qpMin = pHandle->stH264Cbr.u32MinQp;
			pHandle->qpMax = pHandle->stH264Cbr.u32MaxQp;
			pHandle->qpMinI = pHandle->stH264Cbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH264Cbr.u32MaxIQp;
            
            if(pHandle->stH264Cbr.u32IdrDeltaRange && pHandle->stH264Cbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH264Cbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_CBR;
                pHandle->stH264Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
                pstVencChnAttr->stRcAttr.stH264Cbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CBR;
            }

			if (pHandle->stH264Cbr.u32MaxIprop && pHandle->stH264Cbr.u32MaxIprop <= 100) {
				pHandle->IpropMax = pHandle->stH264Cbr.u32MaxIprop;
			} else {
				pHandle->IpropMax = 40;
				pHandle->stH264Cbr.u32MaxIprop = 40;
			}
			if (pHandle->stH264Cbr.u32MinIprop && pHandle->stH264Cbr.u32MinIprop <= pHandle->IpropMax) {
				pHandle->IpropMin = pHandle->stH264Cbr.u32MinIprop;
			} else {
				pHandle->IpropMin = 10;
				pHandle->stH264Cbr.u32MinIprop = 10;
			}
			pHandle->intraQpDelta = pHandle->stH264Cbr.s32IntraQpDelta;

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264Cbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH264Cbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h265 Cbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h265 Cbr Invalid qpmap qp type = %d.\n", VeChn, pHandle->stH264Cbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH264Cbr, &pHandle->stH264Cbr, sizeof(AX_VENC_H264_CBR_S));
		} else if (VENC_RC_MODE_H264VBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH264Vbr, &pstAttr->stRcAttr.stH264Vbr, sizeof(AX_VENC_H264_VBR_S));

			pHandle->vbr = 1;
			pHandle->inputRateNumer = pHandle->stH264Vbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH264Vbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH264Vbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH264Vbr.u32MaxBitRate * VENC_BITRATE_RATIO;

			pHandle->enRcMode = VENC_RC_MODE_H264VBR;
			/* Rc param*/
			pHandle->ctbRc = VCENC_CTBRC_AVG;

			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;

			pHandle->qpMin = pHandle->stH264Vbr.u32MinQp;
			pHandle->qpMax = pHandle->stH264Vbr.u32MaxQp;

			pHandle->qpMinI = pHandle->stH264Vbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH264Vbr.u32MaxIQp;
			pHandle->intraQpDelta = pHandle->stH264Vbr.s32IntraQpDelta;
			pHandle->cpbSize = 2 * (pHandle->stH264Vbr.u32MaxBitRate * VENC_BITRATE_RATIO);
            
            if(pHandle->stH264Vbr.u32IdrDeltaRange && pHandle->stH264Vbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH264Vbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_VBR;
                pHandle->stH264Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
                pstVencChnAttr->stRcAttr.stH264Vbr.u32IdrDeltaRange = IDR_DELTA_RANGE_VBR;
            }

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264Vbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264Vbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH264Vbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH264Vbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h264 Cbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h264 Cbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH264Vbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH264Vbr, &pHandle->stH264Vbr, sizeof(AX_VENC_H264_VBR_S));
		} else if (VENC_RC_MODE_H264AVBR == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH264AVbr, &pstAttr->stRcAttr.stH264AVbr, sizeof(AX_VENC_H264_AVBR_S));

			pHandle->vbr = 1;
			pHandle->inputRateNumer = pHandle->stH264AVbr.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH264AVbr.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH264AVbr.u32Gop;
			pHandle->bitPerSecond = pHandle->stH264AVbr.u32MaxBitRate * VENC_BITRATE_RATIO;

			pHandle->enRcMode = VENC_RC_MODE_H264AVBR;
			/* Rc param*/
			pHandle->ctbRc = VCENC_CTBRC_AVG;

			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;

			pHandle->qpMin = pHandle->stH264AVbr.u32MinQp;
			pHandle->qpMax = pHandle->stH264AVbr.u32MaxQp;

			pHandle->qpMinI = pHandle->stH264AVbr.u32MinIQp;
			pHandle->qpMaxI = pHandle->stH264AVbr.u32MaxIQp;
			pHandle->intraQpDelta = pHandle->stH264AVbr.s32IntraQpDelta;
			pHandle->cpbSize = 2 * (pHandle->stH264AVbr.u32MaxBitRate * VENC_BITRATE_RATIO);
            
            if(pHandle->stH264AVbr.u32IdrDeltaRange && pHandle->stH264AVbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH264AVbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_AVBR;
                pHandle->stH264AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
                pstVencChnAttr->stRcAttr.stH264AVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_AVBR;
            }

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264AVbr.stQpmapInfo.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264AVbr.stQpmapInfo.u32QpmapBlockUnit;
				pHandle->ctbRc = pHandle->stH264AVbr.stQpmapInfo.enCtbRcMode;
			}
			else if (VENC_QPMAP_DISABLE == pHandle->stH264AVbr.stQpmapInfo.enQpmapQpType)
			{
				VLOG_DEBUG("VencChn %d: h264 avbr Disable QpMap.\n", VeChn);
			}
			else
			{
				VLOG_ERROR("VencChn %d: h264 avbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH264Vbr.stQpmapInfo.enQpmapQpType);
			}

			memcpy(&pHandle->stRcParam.stH264AVbr, &pHandle->stH264AVbr, sizeof(AX_VENC_H264_AVBR_S));
        } else if (VENC_RC_MODE_H264CVBR == pstAttr->stRcAttr.enRcMode) {
           memcpy(&pHandle->stH264CVbr, &pstAttr->stRcAttr.stH264CVbr, sizeof(AX_VENC_H264_CVBR_S));

           pHandle->vbr = 0;
           pHandle->inputRateNumer = pHandle->stH264CVbr.u32SrcFrameRate;
           pHandle->inputRateDenom = 1;
           pHandle->outputRateNumer = pHandle->stH264CVbr.fr32DstFrameRate;
           pHandle->outputRateDenom = 1;
           pHandle->intraPicRate = pHandle->stH264CVbr.u32Gop;
           pHandle->bitPerSecond = pHandle->stH264CVbr.u32LongTermMaxBitrate * VENC_BITRATE_RATIO;
           
           if(pHandle->stH264CVbr.u32IdrDeltaRange && pHandle->stH264CVbr.u32IdrDeltaRange <= 10)
            {
                pHandle->idrDeltaRange = pHandle->stH264CVbr.u32IdrDeltaRange;
            }else{
                pHandle->idrDeltaRange = IDR_DELTA_RANGE_CVBR;
                pHandle->stH264CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
                pstVencChnAttr->stRcAttr.stH264CVbr.u32IdrDeltaRange = IDR_DELTA_RANGE_CVBR;
            }

           pHandle->enRcMode = VENC_RC_MODE_H264CVBR;
           /* Rc param*/
           pHandle->ctbRc = VCENC_CTBRC_AVG;

           pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;

           pHandle->qpMin = pHandle->stH264CVbr.u32MinQp;
           pHandle->qpMax = pHandle->stH264CVbr.u32MaxQp;

           pHandle->qpMinI = pHandle->stH264CVbr.u32MinIQp;
           pHandle->qpMaxI = pHandle->stH264CVbr.u32MaxIQp;
            pHandle->intraQpDelta = pHandle->stH264CVbr.s32IntraQpDelta;
            pHandle->u32MaxBitRate = pHandle->stH264CVbr.u32MaxBitRate;
           pHandle->u32ShortTermStatTime = pHandle->stH264CVbr.u32ShortTermStatTime;
           pHandle->u32LongTermStatTime = pHandle->stH264CVbr.u32LongTermStatTime;
           pHandle->u32LongTermMaxBitrate = pHandle->stH264CVbr.u32LongTermMaxBitrate;
           pHandle->u32LongTermMinBitrate = pHandle->stH264CVbr.u32LongTermMinBitrate;
           pHandle->u32ExtraBitPercent = pHandle->stH264CVbr.u32ExtraBitPercent;
           pHandle->u32LongTermStatTimeUnit = pHandle->stH264CVbr.u32LongTermStatTimeUnit;

           pHandle->cpbSize = 2 * (pHandle->stH264CVbr.u32MaxBitRate * VENC_BITRATE_RATIO);

           if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264CVbr.stQpmapInfo.enQpmapQpType)
          {
               pHandle->roiMapDeltaQpEnable = 1;
               pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264CVbr.stQpmapInfo.u32QpmapBlockUnit;
               pHandle->ctbRc = pHandle->stH264CVbr.stQpmapInfo.enCtbRcMode;
           }
           else if (VENC_QPMAP_DISABLE == pHandle->stH264CVbr.stQpmapInfo.enQpmapQpType)
           {
               VLOG_DEBUG("VencChn %d: h264 Cbr Disable QpMap.\n", VeChn);
           }
           else
           {
               VLOG_ERROR("VencChn %d: h264 Cbr Invalid qpmap qp type = %d.\n", VeChn, pstAttr->stRcAttr.stH264CVbr.stQpmapInfo.enQpmapQpType);
           }

           memcpy(&pHandle->stRcParam.stH264CVbr, &pHandle->stH264CVbr, sizeof(AX_VENC_H264_CVBR_S));
		} else if (VENC_RC_MODE_H264FIXQP == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH264FixQp, &pstAttr->stRcAttr.stH264FixQp, sizeof(AX_VENC_H264_FIXQP_S));

			pHandle->inputRateNumer = pHandle->stH264FixQp.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH264FixQp.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH264FixQp.u32Gop;

			pHandle->enRcMode = VENC_RC_MODE_H264FIXQP;

			pHandle->fixedIntraQp = pHandle->stH264FixQp.u32IQp; //fix qp for I slice
			pHandle->qpHdr = pHandle->stH264FixQp.u32PQp;
			if (pHandle->stH264FixQp.u32PQp < pHandle->stH264FixQp.u32BQp)
				pHandle->bFrameQpDelta = pHandle->stH264FixQp.u32BQp - pHandle->stH264FixQp.u32PQp;
			else
				pHandle->bFrameQpDelta = pHandle->stH264FixQp.u32PQp - pHandle->stH264FixQp.u32BQp;

			VLOG_DEBUG("VencChn %d: qpHdr = %u, fixedIntraQp=%u, bFrameQpDelta=%u.\n",
				VeChn, pHandle->qpHdr, pHandle->fixedIntraQp, pHandle->bFrameQpDelta);

            memcpy(&pHandle->stRcParam.stH264FixQp, &pHandle->stH264FixQp, sizeof(AX_VENC_H264_FIXQP_S));
		} else if (VENC_RC_MODE_H264QPMAP == pstAttr->stRcAttr.enRcMode) {
			memcpy(&pHandle->stH264QpMap, &pstAttr->stRcAttr.stH264QpMap, sizeof(AX_VENC_H264_QPMAP_S));

			pHandle->vbr = 1;
			pHandle->picRc = 1;
			pHandle->inputRateNumer = pHandle->stH264QpMap.u32SrcFrameRate;
			pHandle->inputRateDenom = 1;
			pHandle->outputRateNumer = pHandle->stH264QpMap.fr32DstFrameRate;
			pHandle->outputRateDenom = 1;
			pHandle->intraPicRate = pHandle->stH264QpMap.u32Gop;
			pHandle->bitPerSecond = pHandle->stH264QpMap.u32TargetBitRate * VENC_BITRATE_RATIO;
			pHandle->ctbRc = VCENC_CTBRC_SUBQ;

			pHandle->enRcMode = VENC_RC_MODE_H264QPMAP;

			pHandle->qpHdr = pstAttr->stRcAttr.s32FirstFrameStartQp;

			if (VENC_QPMAP_ENABLE_DELTAQP == pHandle->stH264QpMap.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->ctbRc = pHandle->stH264Vbr.stQpmapInfo.enCtbRcMode;;
			}
			else if (VENC_QPMAP_ENABLE_ABSQP == pHandle->stH264QpMap.enQpmapQpType)
			{
				pHandle->roiMapDeltaQpEnable = 1;
				pHandle->ctbRc = VENC_RC_CTBRC_DISABLE;
			}
			else if (VENC_QPMAP_ENABLE_IPCM == pHandle->stH264QpMap.enQpmapQpType)
			{
				pHandle->ipcmMapEnable = 1;
				pHandle->ctbRc = pHandle->stH264QpMap.enCtbRcMode;
			}
 			else
			{
				VLOG_ERROR("VencChn %d: h264 Invalid qpmap qp type = %d.\n", VeChn, pHandle->stH264QpMap.enQpmapQpType);
			}
			pHandle->roiMapDeltaQpBlockUnit = pHandle->stH264QpMap.u32QpmapBlockUnit;

			memcpy(&pHandle->stRcParam.stH264QpMap, &pHandle->stH264QpMap, sizeof(AX_VENC_H264_QPMAP_S));
		}
	}
	break;

	default:
		VLOG_ERROR("VencChn %d: encoder type (%d) not supported!\n", VeChn, pstAttr->stVencAttr.enType);
		return AX_ERR_VENC_CREATE_CHAN_ERR;
	}

	pHandle->encIn.gopConfig.pGopPicCfg = pHandle->gopPicCfg;
	pHandle->encIn.gopConfig.pGopPicSpecialCfg = pHandle->gopPicSpecialCfg;

	/* Gop type setting */
	switch (pstAttr->stGopAttr.enGopMode)
	{
	case VENC_GOPMODE_NORMALP:
	{
		pHandle->gopSize = 1;
		pHandle->gopSize = MIN(pHandle->gopSize, MAX_GOP_SIZE);
		pHandle->enGopMode = VENC_GOPMODE_NORMALP;
		memcpy(&pHandle->stNormalP, &pstAttr->stGopAttr.stNormalP, sizeof(AX_VENC_GOP_NORMALP_S));
		s32Ret = InitGopConfigsNew(pHandle->gopSize, *pHandle, &(pHandle->encIn.gopConfig),
				pHandle->encIn.gopConfig.gopCfgOffset, HANTRO_FALSE, pHandle->hwid) ;

		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: InitGopConfigs failed!\n", VeChn);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		break;
	}

	case VENC_GOPMODE_ONELTR:
	{
    if (pstAttr->stGopAttr.stOneLTR.stPicSpecialConfig.s32Interval < 0 ||
        pstAttr->stGopAttr.stOneLTR.stPicSpecialConfig.s32Interval > pHandle->intraPicRate)
    {
      VLOG_ERROR("VencChn %d: Invalid ltr interval(%d), not in range (0, %d].\n",
          VeChn,
          pstAttr->stGopAttr.stOneLTR.stPicSpecialConfig.s32Interval,
          pHandle->intraPicRate);
      return AX_ERR_VENC_ILLEGAL_PARAM;
    }
		pHandle->gopSize = 1;
		pHandle->gopSize = MIN(pHandle->gopSize, MAX_GOP_SIZE);
		pHandle->enGopMode = VENC_GOPMODE_ONELTR;
		memcpy(&pHandle->stOneLTR, &pstAttr->stGopAttr.stOneLTR, sizeof(AX_VENC_GOP_ONE_LTR_S));
		s32Ret = InitGopConfigsLTR(pHandle->gopSize, *pHandle, &(pHandle->encIn.gopConfig),
				pHandle->encIn.gopConfig.gopCfgOffset);

		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: InitGopConfigsLTR failed!\n", VeChn);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		break;
	}
	case VENC_GOPMODE_SVC_T:
	{
		pHandle->gopSize = pstAttr->stGopAttr.stSvcT.u32GopSize;
		pHandle->svc_t_cfg = (char **)pstAttr->stGopAttr.stSvcT.s8SvcTCfg;
		if (NULL == pstAttr->stGopAttr.stSvcT.s8SvcTCfg) {
			VLOG_ERROR("VencChn %d: SVC-T config is NULL.\n", VeChn);
			return AX_ERR_VENC_NULL_PTR;
		}

		pHandle->gopSize = MIN(pHandle->gopSize, MAX_GOP_SIZE);
		s32Ret = InitGopConfigsSVCT(pHandle->gopSize, pHandle, &(pHandle->encIn.gopConfig),
				pHandle->encIn.gopConfig.gopCfgOffset);

		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: InitGopConfigs SVC-T failed!\n", VeChn);
			return AX_ERR_VENC_ILLEGAL_PARAM;
		}

		break;
	}

	default:
		VLOG_ERROR("VencChn %d: GOP Type (%d) not supported!\n", VeChn, pstAttr->stGopAttr.enGopMode);
		return AX_ERR_VENC_CREATE_CHAN_ERR;
	}

	pHandle->maxPicWidth = pstAttr->stVencAttr.u32MaxPicWidth;
	if (pHandle->maxPicWidth <= 0)
		pHandle->maxPicWidth = pstAttr->stVencAttr.u32PicWidthSrc;

	pHandle->maxPicHeight = pstAttr->stVencAttr.u32MaxPicHeight;
	if (pHandle->maxPicHeight <= 0)
		pHandle->maxPicHeight = pstAttr->stVencAttr.u32PicHeightSrc;

	/*width height of input frame*/
	pHandle->lumWidthSrc = pstAttr->stVencAttr.u32PicWidthSrc;
	pHandle->lumHeightSrc = pstAttr->stVencAttr.u32PicHeightSrc;

	if ( (0 != pstAttr->stVencAttr.u32CropWidth) &&
        (0 != pstAttr->stVencAttr.u32CropHeight) ) {
		/* cropping offset */
		pHandle->horOffsetSrc = pstAttr->stVencAttr.u32CropOffsetX;
		pHandle->verOffsetSrc = pstAttr->stVencAttr.u32CropOffsetY;
		/*widht height of encoded picture*/
		pHandle->width = pstAttr->stVencAttr.u32CropWidth;
		pHandle->height = pstAttr->stVencAttr.u32CropHeight;
		pHandle->dynamicCropEnable = AX_FALSE;
	} else {
		/* cropping offset */
		pHandle->horOffsetSrc = 0;
		pHandle->verOffsetSrc = 0;
		/*widht height of encoded picture*/
		pHandle->width = pstAttr->stVencAttr.u32PicWidthSrc;
		pHandle->height = pstAttr->stVencAttr.u32PicHeightSrc;
		pHandle->dynamicCropEnable = AX_TRUE;
	}

  // if (pstAttr->stVencAttr.stUserDataQueueAttr.u32UserDataBufferCount > 0)
  //   pHandle->stUserDataQueueAttr.u32UserDataBufferCount = pstAttr->stVencAttr.stUserDataQueueAttr.u32UserDataBufferCount;
  // if (pstAttr->stVencAttr.stUserDataQueueAttr.u32UserDataBufferSize > 0)
  //   pHandle->stUserDataQueueAttr.u32UserDataBufferSize = pstAttr->stVencAttr.stUserDataQueueAttr.u32UserDataBufferSize;

	pHandle->sliceSize = pstAttr->stVencAttr.u32MbLinesPerSlice;

	pHandle->streamBufSize = pstAttr->stVencAttr.u32BufSize;
	if (pHandle->streamBufSize <= 0) {
		pHandle->streamBufSize = 2 * (pstAttr->stVencAttr.u32MaxPicWidth) * (pstAttr->stVencAttr.u32MaxPicHeight);
	}

	memcpy(&pHandle->stChnnelAttr, pstAttr, sizeof(AX_VENC_CHN_ATTR_S));

	/* GDR config */
	pHandle->gdrDuration = pstAttr->stVencAttr.u32GdrDuration;
	/* Video range config */
	pHandle->videoRange = pstAttr->stVencAttr.u32VideoRange;

	pHandle->encIn.gopConfig.idr_interval = pHandle->intraPicRate;
	pHandle->encIn.gopConfig.gdrDuration = pHandle->gdrDuration;
	pHandle->encIn.gopConfig.firstPic = pHandle->firstPic;
	pHandle->encIn.gopConfig.lastPic = pHandle->lastPic;
	pHandle->encIn.gopConfig.outputRateNumer = pHandle->outputRateNumer; /* Output frame rate numerator */
	pHandle->encIn.gopConfig.outputRateDenom = pHandle->outputRateDenom; /* Output frame rate denominator */
	pHandle->encIn.gopConfig.inputRateNumer = pHandle->inputRateNumer;   /* Input frame rate numerator */
	pHandle->encIn.gopConfig.inputRateDenom = pHandle->inputRateDenom;   /* Input frame rate denominator */
	pHandle->encIn.gopConfig.gopLowdelay = pHandle->gopLowdelay;
	pHandle->encIn.gopConfig.interlacedFrame = pHandle->interlacedFrame;
	pHandle->encIn.dec400Enable = 0;

	pHandle->streamBufNum = 1;//pHandle->streamBufChain ? 2 : 1;

	pHandle->hwid = EncAsicGetAsicHWid(pHandle->codecFormat, NULL);

	return 0;
}

AX_H264E_NALU_TYPE_E VencH264NaluType(int VeChn, int type)
{
  switch (type)
  {
  case H264E_NALU_SPS:
    return H264E_NALU_SPS;
  case H264E_NALU_PPS:
    return H264E_NALU_PPS;
  case H264E_NALU_SEI:
    return H264E_NALU_SEI;
  case H264E_NALU_IDRSLICE:
    return H264E_NALU_IDRSLICE;
  case H264E_NALU_ISLICE:
    return H264E_NALU_ISLICE;
  case H264E_NALU_PSLICE:
    return H264E_NALU_PSLICE;
  case H264E_NALU_BSLICE:
    return H264E_NALU_BSLICE;
  case H264E_NALU_PREFIX_14:
    return H264E_NALU_PREFIX_14;
  default:
    VLOG_WARNING("VencChn %d: Invalid h264 nalu type(%d)!\n", VeChn, type);
    return H264E_NALU_BUTT;
  }
}

AX_H265E_NALU_TYPE_E VencH265NaluType(int VeChn, int type)
{
  switch (type)
  {
  case H265E_NALU_VPS:
    return H265E_NALU_VPS;
  case H265E_NALU_SPS:
    return H265E_NALU_SPS;
  case H265E_NALU_PPS:
    return H265E_NALU_PPS;
  case H265E_NALU_SEI:
    return H265E_NALU_SEI;
  case H265E_NALU_IDRSLICE:
    return H265E_NALU_IDRSLICE;
  case H265E_NALU_ISLICE:
    return H265E_NALU_ISLICE;
  case H265E_NALU_PSLICE:
    return H265E_NALU_PSLICE;
  case H265E_NALU_BSLICE:
    return H265E_NALU_BSLICE;
  case H265E_NALU_TSA_R:
    return H265E_NALU_TSA_R;
  default:
    VLOG_WARNING("VencChn %d: Invalid h265 nalu type(%d)!\n", VeChn, type);
    return H265E_NALU_BUTT;
  }
}

int VencParseNaluType(AX_S32 VeChn, const AX_AVCHEVC_HANDLE_S *pHandle, const VCEncIn *pEncIn, VCEncOut *pEncOut, AX_ENCODR_METADATA_INFO_S *pUserOut)
{
  int naluType;
  AX_H265E_NALU_TYPE_E enH265Type;
  AX_H264E_NALU_TYPE_E enH264Type;
  unsigned char *pStrmBuf = (unsigned char *)pEncIn->pOutBuf[0];
  pUserOut->outputStreamInfo.stPackage.u32NaluNum = pEncOut->numNalus;

  if (pEncOut->numNalus > VENC_MAX_NALU_NUM) {
    VLOG_WARNING("VencChn %d: Invalid nalu number(%d).\n", VeChn, pEncOut->numNalus);
    return -1;
  }

  for (int j = 0; j < pEncOut->numNalus; j++) {
    pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluLength = pEncOut->pNaluSizeBuf[j];
    if (VCENC_VIDEO_CODEC_HEVC == pHandle->codecFormat) {

        if (0 == j) {
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset = 0;
          naluType = ((pStrmBuf[4]) & 0x7E) >> 1;
        } else {
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset =
              pUserOut->outputStreamInfo.stPackage.stNaluInfo[j-1].u32NaluOffset + pEncOut->pNaluSizeBuf[j-1];

          pStrmBuf += pEncOut->pNaluSizeBuf[j-1];
          naluType = (pStrmBuf[4] & 0x7E) >> 1;
        }

        enH265Type = VencH265NaluType(VeChn, naluType);
        if (enH265Type < H265E_NALU_BUTT)
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].unNaluType.enH265EType = enH265Type;

        VLOG_DEBUG("VencChn %d: pack-%d: offset=%d, type%d, Len=%d.\n",
              VeChn,
              j,
              pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset,
              pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].unNaluType.enH265EType,
              pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluLength);

    } else if (VCENC_VIDEO_CODEC_H264 == pHandle->codecFormat) {

        if (0 == j) {
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset = 0;
          naluType = pStrmBuf[4] & 0x1f;
        } else {
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset =
              pUserOut->outputStreamInfo.stPackage.stNaluInfo[j-1].u32NaluOffset + pEncOut->pNaluSizeBuf[j-1];

          pStrmBuf += pEncOut->pNaluSizeBuf[j-1];
          naluType = pStrmBuf[4] & 0x1f;
        }

        enH264Type = VencH264NaluType(VeChn, naluType);
        if (enH264Type < H264E_NALU_BUTT)
          pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].unNaluType.enH264EType = enH264Type;

          VLOG_DEBUG("VencChn %d: pack-%d: offset=%d, type%d, Len=%d.\n",
                VeChn,
                j,
                pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluOffset,
                pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].unNaluType.enH264EType,
                pUserOut->outputStreamInfo.stPackage.stNaluInfo[j].u32NaluLength);
    }
  }

  return 0;
}

void VencConfigFrameBuffer(AX_S32 VeChn, AX_AVCHEVC_HANDLE_S *pHandle, VCEncIn *pEncIn,
                                AX_ENCODR_METADATA_INFO_S *pFrame, AX_ENCODR_METADATA_INFO_S *pStream)
{
    //config frame buffer
    if (pFrame->inputFrameType == FRAME_NORMAL_TYPE) {
      if (pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[0]) {
        pEncIn->busLuma = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[0];
        pHandle->lum = (u8 *)((u32)pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[0]);
      }

      if (pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[1]) {
        pEncIn->busChromaU = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[1];
        pHandle->cb = (u8 *)((u32)pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[1]);
      } else {
        pEncIn->busChromaU = pEncIn->busLuma + pHandle->lumaSize;
        if(pHandle->lum){
            pHandle->cb = pHandle->lum + pHandle->lumaSize;
        }else{
            pHandle->cb = NULL;
        }
      }

      if (pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[2]) {
        pEncIn->busChromaV = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64PhyAddr[2];
        pHandle->cr = (u8 *)((u32)pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64VirAddr[2]);
      } else {
        pEncIn->busChromaV = pEncIn->busChromaU + pHandle->chromaSize / 2;
        if(pHandle->cb) {
            pHandle->cr = pHandle->cb + pHandle->chromaSize / 2; // for semi-planar, cr should be 0.
        }else{
            pHandle->cr = NULL;
        }
      }

      if (pFrame->inputFrameInfo.stFrameInfo.stVFrame.enCompressMode == AX_COMPRESS_MODE_TILE) {
        pEncIn->fbdcInfo.enableFBDC = true;
        pEncIn->fbdcInfo.width = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u32Width;
        if ((pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetRight > 0) && (pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetBottom > 0) ) {
          pEncIn->fbdcInfo.width = pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetRight -
                                      pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetLeft;
        }

        pEncIn->fbdcInfo.cropX = pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetLeft;
        pEncIn->fbdcInfo.cropY = pFrame->inputFrameInfo.stFrameInfo.stVFrame.s16OffsetTop;
      } else {
        pEncIn->fbdcInfo.enableFBDC = false;
      }

      pStream->outputStreamInfo.stPackage.u64UserData = pFrame->inputFrameInfo.stFrameInfo.stVFrame.u64UserData;
    } else if (pFrame->inputFrameType == FRAME_USER_TYPE) {
      if (pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[0]) {
        pEncIn->busLuma = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[0];
        pHandle->lum = (u8 *)((u32)pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64VirAddr[0]);
      }

      if (pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[1]) {
        pEncIn->busChromaU = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[1];
        pHandle->cb = (u8 *)((u32)pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64VirAddr[1]);
      } else {
        pEncIn->busChromaU = pEncIn->busLuma + pHandle->lumaSize;
        if(pHandle->lum){
            pHandle->cb = pHandle->lum + pHandle->lumaSize;
        }else{
            pHandle->cb = NULL;
        }
      }

      if (pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[2]) {
        pEncIn->busChromaV = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64PhyAddr[2];
        pHandle->cr = (u8 *)((u32)pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64VirAddr[2]);
      } else {
        pEncIn->busChromaV = pEncIn->busChromaU + pHandle->chromaSize / 2;
        if(pHandle->cb) {
            pHandle->cr = pHandle->cb + pHandle->chromaSize / 2; // for semi-planar, cr should be 0.
        }else{
            pHandle->cr = NULL;
        }
      }

      pEncIn->roiMapDeltaQpAddr = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserRcInfo.u64QpMapPhyAddr;
      pEncIn->pRoiMapDelta = (signed char *)(pFrame->inputUserFrameInfo.stUserFrameInfo.stUserRcInfo.pQpMapVirAddr);
      pEncIn->roiMapDeltaSize = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserRcInfo.u32RoiMapDeltaSize;

      pStream->outputStreamInfo.stPackage.u64UserData = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u64UserData;

      if (pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.enCompressMode == AX_COMPRESS_MODE_TILE) {
        pEncIn->fbdcInfo.enableFBDC = true;
        pEncIn->fbdcInfo.width = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.u32Width;
        if ((pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetRight > 0)
              && (pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetBottom > 0) ) {

          pEncIn->fbdcInfo.width = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetRight -
                                      pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetLeft;
        }

        pEncIn->fbdcInfo.cropX = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetLeft;
        pEncIn->fbdcInfo.cropY = pFrame->inputUserFrameInfo.stUserFrameInfo.stUserFrame.stVFrame.s16OffsetTop;
      } else {
        pEncIn->fbdcInfo.enableFBDC = false;
      }

    }

    if (pEncIn->fbdcInfo.enableFBDC == true) {
        VLOG_INFO("fbdcInfo.width:%d .cropX:0x%x .cropY:0x%x", pEncIn->fbdcInfo.width, pEncIn->fbdcInfo.cropX, pEncIn->fbdcInfo.cropY);
    }

    VLOG_DEBUG("VencChn %d, in: phyAddr=%lx, virAddr=%p U_phyAddr=%lx V_PhyAddr=%lx, lumaSize=%lu, chromaSize=%u.\n",
                VeChn, pEncIn->busLuma, pHandle->lum, pEncIn->busChromaU, pEncIn->busChromaV, pHandle->lumaSize, pHandle->chromaSize);
}

AX_S32 VencGlbReset(AX_S32 chnID)
{
  AX_S32 regVal;
  AX_S32 fd = -1;
  AX_U32 glbBaseAddr = (AX_U32)MAP_FAILED;
  AX_U32 mmapSize = 0x100;

  fd = open(GLB_MMAP_PATH, O_RDWR | O_SYNC);
  if (fd < 0) {
    VLOG_ERROR("VencChn %d: open %s error.\n", chnID, GLB_MMAP_PATH);
    return -1;
  }

  glbBaseAddr = (AX_U32)mmap(0, mmapSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, VENC_GLB_BASE);
  if ((AX_U32)MAP_FAILED == glbBaseAddr) {
    VLOG_ERROR("VencChn %d: mmap error.!\n", chnID);
    goto EXIT;
  }

  regVal = *(volatile int *)(glbBaseAddr + 0x20);
  VLOG_DEBUG("VencChn %d: read glb reg value=%lx.\n", chnID, regVal);

  *(volatile int *)(glbBaseAddr + 0x20) = regVal | 0x4;
  VLOG_DEBUG("VencChn %d: read glb reg value=%lx.\n", chnID, *(volatile int *)(glbBaseAddr + 0x20));

  regVal = *(volatile int *)(glbBaseAddr + 0x20);
  VLOG_DEBUG("VencChn %d: read glb reg value=%lx.\n", chnID, regVal);

  *(volatile int *)(glbBaseAddr + 0x20) = regVal & (~(0x4));
  VLOG_DEBUG("VencChn %d: read glb reg value=%lx.\n", chnID, *(volatile int *)(glbBaseAddr + 0x20));

EXIT:

  if (fd >= 0) {
    close(fd);
    fd = -1;
  }

  if (((AX_U32)MAP_FAILED) != glbBaseAddr) {
    munmap((void *)glbBaseAddr, mmapSize);
    /* glbBaseAddr = MAP_FAILED; */
  }

  VLOG_DEBUG("VencChn %d: reset glb register.\n", chnID);

  return 0;
}

int AllocSceneChangeRefbuf(AX_AVCHEVC_HANDLE_S *pHandle) {
    pHandle->refFrameInfo = malloc(PIXEL_WIDTH * PIXEL_HEIGHT * sizeof(AX_U8));
    if (pHandle->refFrameInfo == NULL) {
      VLOG_ERROR("VENC %d: malloc scene change frame error\n", pHandle->VeChn);
      return -1;
    }
    memset(pHandle->refFrameInfo, 0, PIXEL_WIDTH * PIXEL_HEIGHT * sizeof(AX_U8));

    return 0;
}

void FreeSceneChangeRefbuf(AX_AVCHEVC_HANDLE_S *pHandle) {
    if (pHandle->refFrameInfo != NULL) {
      free(pHandle->refFrameInfo);
      pHandle->refFrameInfo = NULL;
    }
}


/* Depends on UpdateVencConfig to update frame vitrual address. */
static int SceneChangeCheck(AX_AVCHEVC_HANDLE_S *pHandle)
{
    AX_S64 changed_pixel = 0;
    AX_U32 height_num = PIXEL_HEIGHT;
    AX_U32 width_num = PIXEL_WIDTH;
    AX_U32 width = 0;
    AX_U32 height = 0;
    AX_U32 change_ratio = 0;
    AX_U32 lumaMapSize = 0;
    AX_U32 cbMapSize = 0;
    AX_U32 crMapSize = 0;
    AX_S32 s32Ret = 0;
    AX_U64 lumaPhyAddr = 0;
    AX_U64 cbPhyAddr = 0;
    AX_U64 crPhyAddr = 0;
    AX_U32 lumaAddrOffset = 0;
    AX_U32 cbAddrOffset = 0;
    AX_U32 crAddrOffset = 0;
    AX_U8* lumaVirtAddr = NULL;
    AX_U8* cbVirtAddr = NULL;
    AX_U8* crVirtAddr = NULL;
    AX_U8* pstFrameLum = NULL;
    AX_U8* pstFrameCb = NULL;
    AX_U8* pstFrameCr = NULL;
    VCEncIn *pEncIn = NULL;

    if(NULL == pHandle)
    {
        return 0;
    }

    pstFrameLum = pHandle->lum;
    pstFrameCb = pHandle->cb;
    pstFrameCr = pHandle->cr;

    width = pHandle->lumWidthSrc;
    height = pHandle->lumHeightSrc;

#if 0

    if(pHandle->lum){
        pstFrameLum = pHandle->lum;
    }else{
        pEncIn = &(pHandle->encIn);
        frameSize = pHandle->lumaSize + pHandle->chromaSize;
        lumaPhyAddr = pEncIn->busLuma ;
        lumaPhyAddr += VENC_ADDR_OFFSET;
        pstFrameLum = AX_SYS_Mmap(lumaPhyAddr,frameSize);
    }

    if(!pstFrameLum){
        return 0;
    }

    if (pHandle->inputFormat == AX_YUV420_PLANAR) {
      height += height / 2;
    } else if (pHandle->inputFormat == AX_YUV420_SEMIPLANAR || pHandle->inputFormat == AX_YUV420_SEMIPLANAR_VU) {
      height += height / 2;
    } else {
      width += width / 2;
    }

    for (int i = 0; i < width_num; i++) {
      for (int j = 0; j < height_num; j++) {
        if (ABS(pstFrameLum[(width - 1) * i / width_num + width * (height - 1) * j / height_num]
          - (pHandle->refFrameInfo[i + width_num * j])) >= 5) {
            changed_pixel++;
  //          printf("changed i %d, j %d, %d, %d, index %ds\n", i, j, ((AX_U8*)pstFrameLum->stVFrame.u64VirAddr[0])[(width - 1) * i / width_num + width * (height - 1) * j / height_num],
  //            (pHandle->refFrameInfo[i + width_num * j]), i + width_num * j);
        } else {
  //          printf("no change i %d, j %d, %d, %d , index %d, %d\n", i, j, ((AX_U8*)pstFrameLum->stVFrame.u64VirAddr[0])[(width - 1) * i / width_num + width * (height - 1) * j / height_num],
  //            (pHandle->refFrameInfo[i + width_num * j]), i + width_num * j);
        }
        pHandle->refFrameInfo[i + width_num * j] = pstFrameLum[(width - 1) * i / width_num + width * (height - 1) * j / height_num];
      }
    }
    change_ratio = changed_pixel * 100 / (width_num * height_num);

    if(frameSize > 0){
        s32Ret = AX_SYS_Munmap(pstFrameLum,frameSize);

        if(s32Ret){
            VLOG_WARNING("AX_SYS_Munmap failed,s32Ret=0x%x\n",s32Ret);
        }
    }

#else
    AX_U32 height_lum_num = PIXEL_HEIGHT / 2;
    AX_U32 height_cb_num = PIXEL_HEIGHT / 4;
    AX_U32 height_cr_num = PIXEL_HEIGHT / 4;
    AX_U32 height_lum = height;
    AX_U32 height_cb = height / 4;
    AX_U32 height_cr = height / 4;
    AX_U32 ref_base = 0;
    AX_U32 threshold = 5;


    pEncIn = &(pHandle->encIn);

    if(!pstFrameLum){

        lumaAddrOffset = (pEncIn->busLuma & 0xfff);
        lumaPhyAddr = pEncIn->busLuma;
        lumaPhyAddr += VENC_ADDR_OFFSET;
        lumaPhyAddr -= lumaAddrOffset;
        lumaMapSize = pHandle->lumaSize + lumaAddrOffset;

        if(g_fd_devmem == -1){
            lumaVirtAddr = AX_SYS_Mmap(lumaPhyAddr,lumaMapSize);
        }else{
            lumaVirtAddr = mmap((void *) 0,lumaMapSize,PROT_READ | PROT_WRITE,MAP_SHARED,g_fd_devmem,lumaPhyAddr);
        }

        if(lumaVirtAddr == NULL || lumaVirtAddr == MAP_FAILED){
            lumaVirtAddr = NULL;
            VLOG_ERROR("mmap Luma virtaddr failed.\n");
            return 0;
        }

        pstFrameLum = lumaVirtAddr + lumaAddrOffset;

        VLOG_INFO("busLuma=0x%lx,lumaAddrOffset=%d,lumaPhyAddr=0x%llx,pstFrameLum=%p,lumaMapSize=%d\n",pEncIn->busLuma,lumaAddrOffset,lumaPhyAddr,pstFrameLum,lumaMapSize);

        if(!pstFrameLum){
            return 0;
        }
    }

    if(!pstFrameCb){

        cbAddrOffset = (pEncIn->busChromaU & 0xfff);
        cbPhyAddr = pEncIn->busChromaU;
        cbPhyAddr += VENC_ADDR_OFFSET;
        cbPhyAddr -= cbAddrOffset;
        cbMapSize = pHandle->chromaSize/2 + cbAddrOffset;

        if(g_fd_devmem == -1){
            cbVirtAddr = AX_SYS_Mmap(cbPhyAddr,cbMapSize);
        }else{
            cbVirtAddr = mmap((void *) 0,cbMapSize,PROT_READ | PROT_WRITE,MAP_SHARED,g_fd_devmem,cbPhyAddr);
        }

        if(cbVirtAddr == NULL || cbVirtAddr == MAP_FAILED){
            cbVirtAddr = NULL;
            VLOG_ERROR("mmap cb virtaddr failed.\n");
            goto END;
        }

        pstFrameCb = cbVirtAddr + cbAddrOffset;

        VLOG_INFO("busChromaU=0x%lx,,cbAddrOffset=%d,cbPhyAddr=0x%llx,pstFrameCb=%p,cbMapSize=%d\n",pEncIn->busChromaU,cbAddrOffset,cbPhyAddr,pstFrameCb,cbMapSize);

        if(!pstFrameCb){
            change_ratio = 0;
            goto END;
        }
    }

    if(!pstFrameCr){

        crAddrOffset = (pEncIn->busChromaV & 0xfff);
        crPhyAddr = pEncIn->busChromaV;
        crPhyAddr += VENC_ADDR_OFFSET;
        crPhyAddr -= crAddrOffset;
        crMapSize = pHandle->chromaSize/2 + crAddrOffset;

        if(g_fd_devmem == -1){
            crVirtAddr = AX_SYS_Mmap(crPhyAddr,crMapSize);
        }else{
            crVirtAddr = mmap((void *) 0,crMapSize,PROT_READ | PROT_WRITE,MAP_SHARED,g_fd_devmem,crPhyAddr);
        }

        if(crVirtAddr == NULL || crVirtAddr == MAP_FAILED){
            crVirtAddr = NULL;
            VLOG_ERROR("mmap cr virtaddr failed.\n");
            goto END;
        }

        pstFrameCr = crVirtAddr + crAddrOffset;

        VLOG_INFO("busChromaV=0x%lx,crAddrOffset=%d,crPhyAddr=0x%llx,pstFrameCr=%p,crMapSize=%d\n",pEncIn->busChromaV,crAddrOffset,crPhyAddr,pstFrameCr,crMapSize);

        if(!pstFrameCr){
            change_ratio = 0;
            goto END;
        }
    }

    if (pHandle->inputFormat == AX_YUV420_PLANAR) {
        if (pstFrameCb == NULL) {
            pstFrameCb = pstFrameLum + height * width;
        }
        if (pstFrameCr == NULL) {
            pstFrameCr = pstFrameCb + height * width / 4;
        }
    } else if (pHandle->inputFormat == AX_YUV420_SEMIPLANAR || pHandle->inputFormat == AX_YUV420_SEMIPLANAR_VU) {
        if (pstFrameCb == NULL) {
            pstFrameCb = pstFrameLum + height * width;
        }
        if (pstFrameCr == NULL) {
            pstFrameCr = pstFrameCb + height * width / 4;
        }
    } else {
        // to do: support other input format
    }

    for (int i = 0; i < height_lum_num; i++) {
        for (int j = 0; j < width_num; j++) {
            if (ABS(pstFrameLum[(height_lum - 1) * i / height_lum_num * width + (width - 1) * j / width_num]
              - (pHandle->refFrameInfo[ref_base + i * width_num +  j])) >= threshold) {
                changed_pixel++;
            } else {
            }
            pHandle->refFrameInfo[ref_base + i * width_num +  j] =
                pstFrameLum[(height_lum - 1) * i / height_lum_num * width + (width - 1) * j / width_num];
        }
    }

    ref_base = height_lum_num * width_num;
    for (int i = 0; i < height_cb_num; i++) {
        for (int j = 0; j < width_num; j++) {
            if (ABS(pstFrameCb[(height_cb - 1) * i / height_cb_num * width + (width - 1) * j / width_num]
              - (pHandle->refFrameInfo[ref_base + i * width_num +  j])) >= threshold) {
                changed_pixel++;
            } else {
            }
            pHandle->refFrameInfo[ref_base + i * width_num +  j] =
                pstFrameCb[(height_cb - 1) * i / height_cb_num * width + (width - 1) * j / width_num];
        }
    }

    ref_base = (height_lum_num + height_cb_num) * width_num;
    for (int i = 0; i < height_cr_num; i++) {
        for (int j = 0; j < width_num; j++) {
            if (ABS(pstFrameCr[(height_cr - 1) * i / height_cr_num * width + (width - 1) * j / width_num]
              - (pHandle->refFrameInfo[ref_base + i * width_num +  j])) >= threshold) {
                changed_pixel++;
            } else {
            }
            pHandle->refFrameInfo[ref_base + i * width_num +  j] =
                pstFrameCr[(height_cr - 1) * i / height_cr_num * width + (width - 1) * j / width_num];
        }
    }

    change_ratio = changed_pixel * 100 / (width_num * height_num);

END:
    if(lumaVirtAddr){

        if(g_fd_devmem == -1){
            s32Ret = AX_SYS_Munmap(lumaVirtAddr,lumaMapSize);
        }else{
            munmap((void *)lumaVirtAddr, lumaMapSize);
        }

        if(s32Ret){
            VLOG_WARNING("AX_SYS_Munmap Luma failed,s32Ret=0x%x\n",s32Ret);
        }else{
            VLOG_INFO("AX_SYS_Munmap lumaVirtAddr=%p,lumaMapSize=0x%x\n",lumaVirtAddr,lumaMapSize);
        }
    }

    if(cbVirtAddr){

        if(g_fd_devmem == -1){
            s32Ret = AX_SYS_Munmap(cbVirtAddr,cbMapSize);
        }else{
            munmap((void *)cbVirtAddr, cbMapSize);
        }

        if(s32Ret){
            VLOG_WARNING("AX_SYS_Munmap Cb failed,s32Ret=0x%x\n",s32Ret);
        }else{
            VLOG_INFO("AX_SYS_Munmap cbVirtAddr=%p,cbMapSize=0x%x\n",cbVirtAddr,cbMapSize);
        }
    }

    if(crVirtAddr){

        if(g_fd_devmem == -1){
            s32Ret = AX_SYS_Munmap(crVirtAddr,crMapSize);
        }else{
            munmap((void *)crVirtAddr, crMapSize);
        }

        if(s32Ret){
            VLOG_WARNING("AX_SYS_Munmap Cr failed,s32Ret=0x%x\n",s32Ret);
        }else{
            VLOG_INFO("AX_SYS_Munmap crVirtAddr=%p,crMapSize=0x%x\n",crVirtAddr,crMapSize);
        }
    }

#endif

    return change_ratio;
}

