
#ifndef _AX_VIDEO_ENC_PIC_CONFIG_H_
#define _AX_VIDEO_ENC_PIC_CONFIG_H_

#include "ax_video_enc_hal.h"

void InitPicConfig(VCEncIn *pEncIn, AX_AVCHEVC_HANDLE_S *tb);

#endif
