/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/

#ifndef _AX_VIDEO_ENC_HAL_H_
#define _AX_VIDEO_ENC_HAL_H_

#include "ax_global_type.h"
#include "ax_comm_codec.h"
#include "ax_comm_venc.h"
#include "ax_comm_venc_rc.h"
#include "ax_venc_interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_I_PROP 40
#define ROI_LIMIT_MINQP 10
AX_S32 AX_AvcHevc_CreateChn(AX_S32 VeChn, const AX_VENC_CHN_ATTR_S *pstAttr, AX_VOID **ppCtx);
AX_S32 AX_AvcHevc_DestroyChn(AX_VOID *pCtx);

AX_S32 AX_AvcHevc_SendFrame(AX_VOID *pCtx, const AX_VIDEO_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec);
AX_S32 AX_AvcHevc_SendFrameEx(AX_VOID *pCtx, const AX_USER_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec);

AX_S32 AX_AvcHevc_GetStream(AX_VOID *pCtx, AX_VENC_STREAM_S *pstStream, AX_S32 s32MilliSec);
AX_S32 AX_AvcHevc_ReleaseStream(AX_VOID *pCtx, const AX_VENC_STREAM_S *pstStream);

AX_S32 AX_AvcHevc_StartRecvFrame(AX_VOID *pCtx, const AX_VENC_RECV_PIC_PARAM_S *pstRecvParam);
AX_S32 AX_AvcHevc_StopRecvFrame(AX_VOID *pCtx);

// AX_S32 AX_AvcHevc_ConfigOSD(AX_VOID *pCtx, AX_VENC_OSD_AREA_ATTR_S *pstAttr);

AX_S32 AX_AvcHevc_SetOsdLayer(AX_VOID *pCtx, const AX_OSD_BMP_ATTR_S *pstOSDAttr);
AX_S32 AX_AvcHevc_RefreshOsdLayer(AX_VOID *pCtx, AX_U32 u32OsdIndex, AX_U8* pBitmap);
AX_S32 AX_AvcHevc_ResetOsd(AX_VOID *pCtx);

AX_S32 AX_AvcHevc_SetRoiAttr(AX_VOID *pCtx, const AX_VENC_ROI_ATTR_S *pstRoiAttr);
AX_S32 AX_AvcHevc_GetRoiAttr(AX_VOID *pCtx, AX_U32 u32Index, AX_VENC_ROI_ATTR_S *pstRoiAttr);

AX_S32 AX_AvcHevc_SetRcParam(AX_VOID *pCtx, const AX_VENC_RC_PARAM_S *pstRcParam);
AX_S32 AX_AvcHevc_GetRcParam(AX_VOID *pCtx, AX_VENC_RC_PARAM_S *pstRcParam);

AX_S32 AX_AvcHevc_SetChnAttr(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr);
AX_S32 AX_AvcHevc_GetChnAttr(AX_VOID *pCtx, AX_VENC_CHN_ATTR_S *pstChnAttr);

AX_S32 AX_AvcHevc_InsertUserData(AX_VOID *pCtx, const AX_U8 *pu8Data, AX_U32 u32Len);

AX_S32 AX_AvcHevc_RequestIDR(AX_VOID *pCtx, AX_BOOL bInstant);

AX_S32 AX_AvcHevc_Process(VENC_CHN VeChn);

//AX_S32 AX_AvcHevc_SetJpegParam(AX_VENC_MOD_INSTANCE_S *pCtx, const AX_VENC_JPEG_PARAM_S *pstJpegParam);
//AX_S32 AX_AvcHevc_GetJpegParam(AX_VENC_MOD_INSTANCE_S *pCtx, AX_VENC_JPEG_PARAM_S *pstJpegParam);

#ifdef __cplusplus
}
#endif

#endif
