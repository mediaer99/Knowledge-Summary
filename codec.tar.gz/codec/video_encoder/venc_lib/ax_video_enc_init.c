#include <math.h>
#include <linux/ioctl.h>
#include "vsi_string.h"

#include "base_type.h"


#include "ax_video_enc.h"
#include "ax_video_enc_init.h"

void default_parameter_new(AX_AVCHEVC_HANDLE_S *cml)
{

  cml->useVcmd  = -1;
  cml->useDec400  = 0;
  cml->useMMU   = 0;
  cml->useL2Cache =0;

  cml->input      = "/mnt/352x288_yuv420p_30frm.yuv";
  cml->output     = "stream.hevc";
  //cml->recon      = "deblock.yuv";

  cml->buffer_cnt = 1;
  cml->parallelCoreNum = 1;
  cml->streamBufNum = 1;

  cml->firstPic    = 0;
  cml->lastPic   = 100;
  cml->inputRateNumer      = 30;
  cml->inputRateDenom      = 1;
  cml->outputRateNumer      = DEFAULT;
  cml->outputRateDenom      = DEFAULT;
  cml->test_data_files    = getenv("TEST_DATA_FILES");
  cml->lumWidthSrc      = DEFAULT;
  cml->lumHeightSrc     = DEFAULT;
  cml->horOffsetSrc = DEFAULT;
  cml->verOffsetSrc = DEFAULT;
  cml->videoStab = DEFAULT;
  cml->rotation = 0;
  cml->inputFormat = 0;
  cml->formatCustomizedType = -1;

  cml->width      = DEFAULT;
  cml->height     = DEFAULT;
  cml->max_cu_size  = 64;
  cml->min_cu_size  = 8;
  cml->max_tr_size  = 16;
  cml->min_tr_size  = 4;
  cml->tr_depth_intra = 2;  //mfu =>0
  cml->tr_depth_inter = (cml->max_cu_size == 64) ? 4 : 3;
  cml->intraPicRate   = 0;  // only first is IDR.
  //cml->codecFormat = VCENC_VIDEO_CODEC_HEVC;
#ifdef CODEC_FORMAT
  cml->codecFormat = CODEC_FORMAT;
#endif
  if(IS_H264(cml->codecFormat)) {
    cml->max_cu_size  = 16;
    cml->min_cu_size  = 8;
    cml->max_tr_size  = 16;
    cml->min_tr_size  = 4;
    cml->tr_depth_intra = 1;
    cml->tr_depth_inter = 2;
    cml->layerInRefIdc = 0;
  }

  cml->bitPerSecond = 1000000;
  cml->cpbMaxRate = 0;
  cml->bitVarRangeI = 10000;
  cml->bitVarRangeP = 10000;
  cml->bitVarRangeB = 10000;
  cml->tolMovingBitRate = 2000;
  cml->monitorFrames = DEFAULT;
  cml->tolCtbRcInter = 0.3;
  cml->tolCtbRcIntra = DEFAULT;
  cml->u32StaticSceneIbitPercent = 80;
  cml->intraQpDelta = DEFAULT;
  cml->idrDeltaRange = 0;
  cml->bFrameQpDelta = -1;

  cml->disableDeblocking = 0;
  cml->tc_Offset = 0;
  cml->beta_Offset = 0;

  cml->qpHdr = DEFAULT;
  cml->qpMin = DEFAULT;
  cml->qpMax = DEFAULT;
  cml->qpMinI = DEFAULT;
  cml->qpMaxI = DEFAULT;
  cml->picRc = DEFAULT;
  cml->ctbRc = DEFAULT; //CTB_RC
  cml->cpbSize = DEFAULT;
  cml->bitrateWindow = DEFAULT;
  cml->fixedIntraQp = 0;
  cml->hrdConformance = 0;
  cml->smoothPsnrInGOP = 0;
  cml->vbr = 0;

  cml->byteStream = 1;

  cml->chromaQpOffset = 0;

  cml->enableSao = 1;

  cml->strong_intra_smoothing_enabled_flag = 0;

  cml->pcm_loop_filter_disabled_flag = 0;

  cml->intraAreaLeft = cml->intraAreaRight = cml->intraAreaTop =
                         cml->intraAreaBottom = -1;  /* Disabled */
  cml->ipcm1AreaLeft = cml->ipcm1AreaRight = cml->ipcm1AreaTop =
                         cml->ipcm1AreaBottom = -1;  /* Disabled */
  cml->ipcm2AreaLeft = cml->ipcm2AreaRight = cml->ipcm2AreaTop =
                         cml->ipcm2AreaBottom = -1;  /* Disabled */

  cml->ipcm3AreaLeft = cml->ipcm3AreaRight = cml->ipcm3AreaTop =
                         cml->ipcm3AreaBottom = -1;  /* Disabled */
  cml->ipcm4AreaLeft = cml->ipcm4AreaRight = cml->ipcm4AreaTop =
                         cml->ipcm4AreaBottom = -1;  /* Disabled */
  cml->ipcm5AreaLeft = cml->ipcm5AreaRight = cml->ipcm5AreaTop =
                         cml->ipcm5AreaBottom = -1;  /* Disabled */
  cml->ipcm6AreaLeft = cml->ipcm6AreaRight = cml->ipcm6AreaTop =
                         cml->ipcm6AreaBottom = -1;  /* Disabled */
  cml->ipcm7AreaLeft = cml->ipcm7AreaRight = cml->ipcm7AreaTop =
                         cml->ipcm7AreaBottom = -1;  /* Disabled */
  cml->ipcm8AreaLeft = cml->ipcm8AreaRight = cml->ipcm8AreaTop =
                         cml->ipcm8AreaBottom = -1;  /* Disabled */
  cml->gdrDuration=0;

  cml->picSkip = 0;

  cml->sliceSize = 0;

  cml->enableCabac = 1;
  cml->cabacInitFlag = 0;
  cml->cirStart = 0;
  cml->cirInterval = 0;
  cml->enableDeblockOverride = 0;
  cml->deblockOverride = 0;

  cml->enableScalingList = 0;

  cml->compressor = 3;
  cml->sei = 0;
  cml->videoRange = 0;
  cml->level = DEFAULT;
  cml->profile = DEFAULT;
  cml->tier = DEFAULT;
  cml->bitDepthLuma = DEFAULT;
  cml->bitDepthChroma= DEFAULT;
  cml->blockRCSize= DEFAULT;
  cml->rcQpDeltaRange = DEFAULT;
  cml->rcBaseMBComplexity = DEFAULT;
  cml->picQpDeltaMin = DEFAULT;
  cml->picQpDeltaMax = DEFAULT;
  cml->ctbRcRowQpStep = DEFAULT;

  cml->gopSize = 1;
  cml->gopCfg = NULL;
  cml->gopLowdelay = 0;
  cml->longTermGap = 0;
  cml->longTermGapOffset = 0;
  cml->longTermQpDelta = 0;
  cml->ltrInterval = DEFAULT;

  cml->flexRefs = NULL;

  cml->outReconFrame=0;

  cml->roiMapDeltaQpBlockUnit=0;
  cml->roiMapDeltaQpEnable=0;
//  cml->roiMapDeltaQpFile = NULL;
//  cml->roiMapDeltaQpBinFile = NULL;
  cml->roiMapInfoBinFile        = NULL;
  cml->RoimapCuCtrlInfoBinFile  = NULL;
  cml->RoimapCuCtrlIndexBinFile = NULL;
  cml->RoiCuCtrlVer  = 0;
  cml->RoiQpDeltaVer = 1;
  cml->ipcmMapEnable = 0;
  cml->ipcmMapFile = NULL;
  cml->roi1Qp = DEFAULT;
  cml->roi2Qp = DEFAULT;
  cml->roi3Qp = DEFAULT;
  cml->roi4Qp = DEFAULT;
  cml->roi5Qp = DEFAULT;
  cml->roi6Qp = DEFAULT;
  cml->roi7Qp = DEFAULT;
  cml->roi8Qp = DEFAULT;

  cml->interlacedFrame = 0;
  cml->noiseReductionEnable = 0;

  /* low latency */
  cml->inputLineBufMode = 0;
  cml->inputLineBufDepth = DEFAULT;
  cml->amountPerLoopBack = 0;

  /*stride*/
  cml->exp_of_input_alignment = 0;//6;
  cml->exp_of_ref_alignment = 0;//6;
  cml->exp_of_ref_ch_alignment = 0;//6;
  cml->exp_of_aqinfo_alignment = 0;//6;

  cml->multimode = 0;
  cml->nstream = 0;
  for(int i = 0; i < MAX_STREAMS; i++)
    cml->streamcfg[i] = NULL;

  cml->enableOutputCuInfo = 0;
  cml->enableOutputCtbBits = 0;
  cml->P010RefEnable = 0;

  cml->rdoLevel = 1;
  cml->dynamicRdoCu16Bias = 3;
  cml->dynamicRdoCu16Factor = 80;
  cml->dynamicRdoCu32Bias = 2;
  cml->dynamicRdoCu32Factor = 32;
  cml->dynamicRdoEnable = 0;
  cml->hashtype = 0;
  cml->verbose = 0;

  /* smart */
  cml->smartModeEnable = 0;
  cml->smartH264LumDcTh = 5;
  cml->smartH264CbDcTh = 1;
  cml->smartH264CrDcTh = 1;
  cml->smartHevcLumDcTh[0] = 2;
  cml->smartHevcLumDcTh[1] = 2;
  cml->smartHevcLumDcTh[2] = 2;
  cml->smartHevcChrDcTh[0] = 2;
  cml->smartHevcChrDcTh[1] = 2;
  cml->smartHevcChrDcTh[2] = 2;
  cml->smartHevcLumAcNumTh[0] = 12;
  cml->smartHevcLumAcNumTh[1] = 51;
  cml->smartHevcLumAcNumTh[2] = 204;
  cml->smartHevcChrAcNumTh[0] = 3;
  cml->smartHevcChrAcNumTh[1] = 12;
  cml->smartHevcChrAcNumTh[2] = 51;
  cml->smartH264Qp = 30;
  cml->smartHevcLumQp = 30;
  cml->smartHevcChrQp = 30;
  cml->smartMeanTh[0] = 5;
  cml->smartMeanTh[1] = 5;
  cml->smartMeanTh[2] = 5;
  cml->smartMeanTh[3] = 5;
  cml->smartPixNumCntTh = 0;

  /* constant chroma control */
  cml->constChromaEn = 0;
  cml->constCb = DEFAULT;
  cml->constCr = DEFAULT;

  for (int i = 0; i < MAX_SCENE_CHANGE; i ++)
    cml->sceneChange[i] = 0;

  cml->tiles_enabled_flag = 0;
  cml->num_tile_columns = 1;
  cml->num_tile_rows  = 1;
  cml->loop_filter_across_tiles_enabled_flag = 1;

  cml->skip_frame_enabled_flag=0;
  cml->skip_frame_poc=0;

  /* HDR10 */
  cml->hdr10_display_enable = 0;
  cml->hdr10_dx0 = 0;
  cml->hdr10_dy0 = 0;
  cml->hdr10_dx1 = 0;
  cml->hdr10_dy1 = 0;
  cml->hdr10_dx2 = 0;
  cml->hdr10_dy2 = 0;
  cml->hdr10_wx  = 0;
  cml->hdr10_wy  = 0;
  cml->hdr10_maxluma = 0;
  cml->hdr10_minluma = 0;

  cml->hdr10_lightlevel_enable = 0;
  cml->hdr10_maxlight          = 0;
  cml->hdr10_avglight          = 0;

  cml->vuiColorDescripPresentFlag    = 0;
  cml->vuiColorPrimaries             = 1; /* BT709 or sRGB */
  cml->vuiTransferCharacteristics    = 1; /* BT709 */
  cml->vuiMatrixCoefficients         = 1; /* BT709 */
  cml->vuiVideoFormat                = 5;
  cml->vuiVideoSignalTypePresentFlag = 1;
  cml->vuiAspectRatioWidth           = 0;
  cml->vuiAspectRatioHeight          = 0;

  cml->picOrderCntType = 0;
  cml->log2MaxPicOrderCntLsb = 16;
  cml->log2MaxFrameNum = 12;

  cml->RpsInSliceHeader = 0;
  cml->ssim = 1;
  cml->psnr = 1;
  cml->vui_timing_info_enable = 1;
  cml->halfDsInput = NULL;
  cml->inLoopDSRatio = 1;

  /* skip mode */
  cml->skipMapEnable = 0;
  cml->skipMapFile = NULL;
  cml->skipMapBlockUnit = 0;

  /* rdoq mode */
  cml->rdoqMapEnable = 0;

  /* Frame-level core parallelism option */
  cml->parallelCoreNum =1;

  /* two stream buffer */
  cml->streamBufChain = 0;

  /*multi-segment of stream buffer*/
  cml->streamMultiSegmentMode = 0;
  cml->streamMultiSegmentAmount = 4;

  /*dump register*/
  cml->dumpRegister = 0;

  cml->rasterscan = 0;
  cml->cuInfoVersion = -1;

#ifdef RECON_REF_1KB_BURST_RW
  cml->exp_of_input_alignment = 10;
  cml->exp_of_ref_alignment = 10;
  cml->exp_of_ref_ch_alignment = 10;
  cml->compressor = 2;
#endif
#ifdef RECON_REF_ALIGN64
  cml->exp_of_ref_alignment = 6;
  cml->exp_of_ref_ch_alignment = 6;
#endif

  cml->enableRdoQuant = DEFAULT;

  /*CRF constant*/
  cml->crf = -1;

  /*external SRAM*/
  cml->extSramLumHeightBwd = IS_H264(cml->codecFormat) ? 12 : (IS_HEVC(cml->codecFormat) ? 16 : 0);
  cml->extSramChrHeightBwd = IS_H264(cml->codecFormat) ? 6  : (IS_HEVC(cml->codecFormat) ? 8 : 0);
  cml->extSramLumHeightFwd = IS_H264(cml->codecFormat) ? 12 : (IS_HEVC(cml->codecFormat) ? 16 : 0);
  cml->extSramChrHeightFwd = IS_H264(cml->codecFormat) ? 6  : (IS_HEVC(cml->codecFormat) ? 8 : 0);

  /* AXI alignment */
  cml->AXIAlignment = 0x66666666;

  /* MMU */
  cml->mmuEnable = 0;

  /* sliceNode */
  cml->sliceNode = 0;

  /*Ivf support*/
  cml->ivf = 1;

  /*DEC400 compress table*/
  cml->dec400CompTableinput      = "dec400CompTableinput.bin";
  cml->osdDec400CompTableInput      = NULL;

  /*PSY factor*/
  cml->psyFactor = DEFAULT;

  /*Overlay*/
  cml->overlayEnables = 0;
  for(int i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    cml->olInput[i] = "olInput.yuv";
    cml->olFormat[i] = 0;
    cml->olAlpha[i] = 0;
    cml->olWidth[i] = 0;
    cml->olCropWidth[i] = 0;
    cml->olScaleWidth[i] = 0;
    cml->olHeight[i] = 0;
    cml->olCropHeight[i] = 0;
    cml->olScaleHeight[i] = 0;
    cml->olXoffset[i] = 0;
    cml->olCropXoffset[i] = 0;
    cml->olYoffset[i] = 0;
    cml->olCropYoffset[i] = 0;
    cml->olYStride[i] = 0;
    cml->olUVStride[i] = 0;
    cml->olBitmapY[i] = 0;
    cml->olBitmapU[i] = 0;
    cml->olBitmapV[i] = 0;
    cml->olSuperTile[i] = 0;
  }

  /* mosaic */
  cml->mosaicEnables = 0;
  for(int i = 0; i <MAX_MOSAIC_NUM; i++)
  {
    cml->mosHeight[i] = 0;
    cml->mosWidth[i] = 0;
    cml->mosXoffset[i] = 0;
    cml->mosYoffset[i] = 0;
  }

  cml->codedChromaIdc = VCENC_CHROMA_IDC_420;
  cml->aq_mode     = DEFAULT;
  cml->aq_strength = DEFAULT;

  cml->preset = DEFAULT;

  cml->writeReconToDDR = 1;

  cml->TxTypeSearchEnable = 0;
  cml->av1InterFiltSwitch = 1;

	cml->sendAUD = 0;

  cml->extSEI = NULL;
  cml->tune   = VCENC_TUNE_PSNR;
  cml->b_vmaf_preprocess = 0;

  cml->resendParamSet = 0;

  cml->sramPowerdownDisable = 0;

  cml->insertIDR = 0;

//  cml->replaceMvFile = NULL;

//  cml->inputFileList = NULL;

  /*AXI max burst length */
  cml->burstMaxLength = ENCH2_DEFAULT_BURST_LENGTH;

  cml->IpropMax = 0;
  cml->IpropMin = 0;

  // rate jam strategy
  cml->dropFrameCnt = 0;
  cml->stRateJamStrategyParam.bDropFrmEn = AX_FALSE;
  cml->stRateJamStrategyParam.enDropFrmMode = DROPFRM_NORMAL;
  cml->stRateJamStrategyParam.u32MaxApplyCount = 3;
  cml->stRateJamStrategyParam.u32DropFrmThrBps = 128 * 1024; //  128K

  // userdata buffer queue
  cml->stUserDataQueueAttr.u32UserDataBufferCount = 4;
  cml->stUserDataQueueAttr.u32UserDataBufferSize = 1024;

  // super frame cfg
  cml->stSuperFrmCfg.bStrategyEn = AX_FALSE;
  cml->stSuperFrmCfg.u32MaxReEncodeTimes = 3;
  cml->stSuperFrmCfg.u32SuperIFrmBitsThr = 500000;
  cml->stSuperFrmCfg.u32SuperPFrmBitsThr = 500000;
  cml->stSuperFrmCfg.u32SuperBFrmBitsThr = 500000;
}
