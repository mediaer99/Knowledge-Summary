/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#ifndef _AX_VIDEO_ENC_INIT_H_
#define _AX_VIDEO_ENC_INIT_H_

#include "base_type.h"
#include "ax_video_enc.h"
#include "ax_venc_log.h"

void default_parameter_new(AX_AVCHEVC_HANDLE_S *cml);

int ENCMallocLinear(int size, unsigned int *busAddr, unsigned int **virAddr);
int ENCFreeLinear(int size, unsigned int busAddr, unsigned int *virAddr);

#endif
