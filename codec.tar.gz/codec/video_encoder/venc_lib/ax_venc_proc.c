#include <fcntl.h>

#include "ax_venc_proc.h"
#include "ax_venc_interface.h"
#include "ax_venc_log.h"
#include "vc8000_driver.h"
#include "ax_video_enc.h"
#include <sys/time.h>
#include <signal.h>
#include <time.h>
#include <sys/ioctl.h>

extern AX_VENC_MOD_INSTANCE_S gModCtx;
extern AX_VENC_CHN_INSTANCE_S *gChnInst[MAX_VENC_NUM];
extern AX_AVCHEVC_HANDLE_S *gAvcHevcHandle[MAX_VENC_NUM];
extern AX_S32 g_fd_venc;

static ENC_PROC_PARAMS_S gVencProcParams = {
	.bExit = AX_FALSE,
	.callback = NULL,
};

static char gProcMsg[VENC_PROC_MSG_LEN];
static timer_t venc_timer_id = 0;

static AX_VOID *VencListenerThread(AX_VOID *args)
{
	AX_S32 s32Ret = -1;
	ENC_PROC_PARAMS_S *pArgs = (ENC_PROC_PARAMS_S *)args;
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set,SIGALRM);
    pthread_sigmask(SIG_SETMASK,&set,NULL);

	if (NULL == pArgs || NULL == pArgs->callback) {
		VLOG_ERROR("VENC proc invalid args.\n");
		return NULL;
	}

	while (!pArgs->bExit) {
		s32Ret = ioctl(g_fd_venc, HANTRO_IOCH_VENC_PROC_TRIGGER);
		if (0 != s32Ret)
		{
			VLOG_ERROR("VENC proc triger fail, retry...\n");
			usleep(5000);
			continue;
		}

		if (NULL != pArgs->callback)
			pArgs->callback(gProcMsg, VENC_PROC_MSG_LEN);

		s32Ret = ioctl(g_fd_venc, HANTRO_IOCH_VENC_PROC_UPDATE, &gProcMsg);
		if (0 != s32Ret) {
			VLOG_ERROR("VENC proc update message fail, retry...\n");
		}
	}

	return NULL;
}

//proc info update
void VencProcUpdate(union sigval v)
{
	AX_VENC_CHN_INSTANCE_S *pChnInst;
	AX_S32 s32Ret;

	for (int i = 0; i < MAX_VENC_NUM; i++) {
		if (PT_JPEG == gModCtx.enChnCodecType[i] || PT_MJPEG == gModCtx.enChnCodecType[i])
			continue;

		s32Ret = pthread_mutex_trylock(&gModCtx.stChnStateMutex[i]);
		if (!s32Ret) {
			pChnInst = gChnInst[i];
			if (NULL == pChnInst || NULL == gAvcHevcHandle[i]) {
				s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
				if (s32Ret)
					VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);

				continue;
			}

			pChnInst->pEncoder->pfnUpdateFpsBr(pChnInst);
			pChnInst->pEncoder->pfnUpdateCvbrShortBps(pChnInst);
            pChnInst->pEncoder->pfnUpdateCvbrLongBps(pChnInst);

			s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			if (s32Ret)
				VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);
		} else {
			VLOG_DEBUG("VENC %d: proc lock err(%d).\n", i, s32Ret);
			continue;
		}
	}
}

AX_S32 VencProcInit(EncProcCatCallback *cb)
{
	AX_S32 s32Ret;
	struct sigevent evp;
	struct itimerspec ts;

	if (NULL == cb) {
		VLOG_ERROR("VENC proc Invalid cb.\n");
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	/* init timer */
	memset(&evp, 0, sizeof (evp));
	evp.sigev_value.sival_ptr = &venc_timer_id;
	evp.sigev_notify = SIGEV_THREAD;
	evp.sigev_notify_function = VencProcUpdate;
	evp.sigev_value.sival_int = 3;

	s32Ret = timer_create(CLOCK_REALTIME, &evp, &venc_timer_id);
	if (s32Ret) {
		VLOG_ERROR("VENC proc timer_create error\n");
		venc_timer_id = 0;
		return AX_ERR_VENC_UNKNOWN;
	}

	ts.it_interval.tv_sec = 3;
	ts.it_interval.tv_nsec = 0;
	ts.it_value.tv_sec = 3;
	ts.it_value.tv_nsec = 0;

	s32Ret = timer_settime(venc_timer_id, TIMER_ABSTIME, &ts, NULL);
	if (s32Ret) {
		VLOG_ERROR("VENC proc timer_settime error\n");
		return AX_ERR_VENC_UNKNOWN;
	}

	gVencProcParams.bExit = AX_FALSE;
	gVencProcParams.callback = cb;

	s32Ret = pthread_create(&gVencProcParams.threadId, NULL, VencListenerThread, &gVencProcParams);
	if (0 != s32Ret) {
		VLOG_ERROR("VENC proc thread create error.!\n");
		goto ERROR;
	}

	VLOG_INFO("VENC proc init success.\n");
	return AX_SUCCESS;

ERROR:

	return AX_ERR_VENC_SYS_NOTREADY;
}

AX_S32 VencProcDeinit()
{
	AX_S32 s32Ret;

	gVencProcParams.bExit = AX_TRUE;

	s32Ret = ioctl(g_fd_venc, HANTRO_IOCH_VENC_PROC_WAKEUP);
	if (s32Ret) {
		VLOG_ERROR("VENC proc wakeup error.\n");
		return AX_ERR_VENC_UNKNOWN;
	}

	pthread_join(gVencProcParams.threadId, NULL);
	gVencProcParams.callback = NULL;

	if (venc_timer_id) {
		s32Ret = timer_delete(venc_timer_id);
		if ( s32Ret) {
			VLOG_ERROR("VENC proc timer_delete error\n");
			return AX_ERR_VENC_UNKNOWN;
		}
	}

	VLOG_INFO("VENC proc deinit success.\n");
	return AX_SUCCESS;
}

static char *GetImageFormat(VENC_CHN VeChn, AX_IMG_FORMAT_E enImgFmt)
{
  switch (enImgFmt)
  {
  case AX_YUV420_PLANAR:
    return "YUV420P";
  case AX_YUV420_SEMIPLANAR:
    return "NV12";
  case AX_YUV420_SEMIPLANAR_VU:
    return "NV21";
  case AX_YUV422_INTERLEAVED_YUYV:
    return "YUYV422";
  case AX_YUV422_INTERLEAVED_UYVY:
    return "UYVY422";
  default:
    VLOG_ERROR("VENC %d: Unknow Image format.\n", VeChn);
    break;
  }
  return "N/A";
}

//add more proc info later
void VencProcCatCallback(char *msg, int msgMaxLen)
{
	AX_S32 s32Ret;
	AX_S32 i = 0;
	AX_S32 j = 0;
	memset(msg, 0, msgMaxLen);

	snprintf(msg + strlen(msg),
		msgMaxLen - strlen(msg),
		"-------- MODULE PARAM ------------------------\n"
		"%-12s%-12s\n", "MaxChnSize", "MaxRoiSize");

	snprintf(msg + strlen(msg),
		msgMaxLen - strlen(msg),
		"%-12u%-12u\n\n",
		MAX_VENC_NUM,
		MAX_ROI_NUM);

	AX_VENC_CHN_INSTANCE_S *pChnInst;
    AX_S32 VeChn = 0;
    AX_AVCHEVC_HANDLE_S *pHandle = NULL;

	for (i = 0; i < MAX_VENC_NUM; i++) {
		if (PT_JPEG == gModCtx.enChnCodecType[i] || PT_MJPEG == gModCtx.enChnCodecType[i])
			continue;

		s32Ret = pthread_mutex_lock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret) {
			VLOG_ERROR("VENC %d: proc lock err(%d).\n", i, s32Ret);
			continue;
		}
		pChnInst = gChnInst[i];
		if (NULL == pChnInst || NULL == gAvcHevcHandle[i]) {
			s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			if (s32Ret)
				VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);

			continue;
		}

        VeChn = pChnInst->ChnId;
        pHandle = pChnInst->pHalCtx;
        if (NULL == pHandle) {
            VLOG_ERROR("VencChn %d: pHalCtx param is null pointer.\n", VeChn);
            s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
			if (s32Ret)
				VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);

            return;
        }

		/* Channel attribute */
		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"-------- VENC CHN ATTR  ------------------------\n"
			"%-8s%-8s%-8s%-8s%-8s%-8s%-10s%-6s%-10s%-13s%-13s%-13s%-16s%-13s\n",
			"ID", "Type", "wSrc", "hSrc", "Strd0", "Strd1", "PixFmt", "Gdr", "IsLink", "MultiSlice", "InFifoDepth", "OutFifoDepth", "StrmBufSize(kb)", "VideoRange");

		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"%-8d%-8s%-8d%-8d%-8d%-8d%-10s%-6d%-10s%-13d%-13d%-13d%-16d%-13d\n",
			i,
			pChnInst->stVencChnAttr.stVencAttr.enType == PT_H264 ? "h264" : "h265",
			pChnInst->stVencChnAttr.stVencAttr.u32PicWidthSrc,
			pChnInst->stVencChnAttr.stVencAttr.u32PicHeightSrc,
			gAvcHevcHandle[i]->u32PicStride[0],
			gAvcHevcHandle[i]->u32PicStride[1],
			GetImageFormat(i, gAvcHevcHandle[i]->inputFormat),
			pChnInst->stVencChnAttr.stVencAttr.u32GdrDuration,
			pChnInst->stVencChnAttr.stVencAttr.enLinkMode == AX_LINK_MODE ? "true" : "false",
			pChnInst->stVencChnAttr.stVencAttr.u32MbLinesPerSlice,
			pChnInst->stVencChnAttr.stVencAttr.u8InFifoDepth,
			pChnInst->stVencChnAttr.stVencAttr.u8OutFifoDepth,
			pChnInst->stVencChnAttr.stVencAttr.u32BufSize/1000,
			pHandle->videoRange);

		/* RC attribute */
		if (PT_H265 == pChnInst->stVencChnAttr.stVencAttr.enType) {
			if (VENC_RC_MODE_H265CBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"CBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH265Cbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH265Cbr.stQpmapInfo.u32QpmapBlockUnit);
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8s%-13s%-13s\n",
					"", "IpropMax", "IpropMin");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8s%-13d%-13d\n",
					"",
					gAvcHevcHandle[i]->stH265Cbr.u32MaxIprop,
					gAvcHevcHandle[i]->stH265Cbr.u32MinIprop);
			} else if (VENC_RC_MODE_H265VBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"VBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH265Vbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH265Vbr.stQpmapInfo.u32QpmapBlockUnit);
			} else if (VENC_RC_MODE_H265AVBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"AVBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH265AVbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH265AVbr.stQpmapInfo.u32QpmapBlockUnit);
			} else if (VENC_RC_MODE_H265CVBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "Br_ST(kbps)", "Br_LT(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "MaxBitRate","STStatTime","LTStatTime","LTMaxBitrate", "QpMapType", "QpMapUnit", "CtbRc");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13llu%-13llu%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"CVBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
                    pChnInst->u64ShortTermBitRate,
                    pChnInst->u64LongTermBitRate,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,

                    pHandle->u32MaxBitRate,
                    pHandle->u32ShortTermStatTime,
                    pHandle->u32LongTermStatTime,
                    pHandle->u32LongTermMaxBitrate,

					pChnInst->stVencChnAttr.stRcAttr.stH265CVbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH265CVbr.stQpmapInfo.u32QpmapBlockUnit,
					pChnInst->stVencChnAttr.stRcAttr.stH265CVbr.stQpmapInfo.enCtbRcMode);
			} else if (VENC_RC_MODE_H265FIXQP == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "IQp", "PQp");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"FixQP",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					pChnInst->stVencChnAttr.stRcAttr.stH265FixQp.u32IQp,
					pChnInst->stVencChnAttr.stRcAttr.stH265FixQp.u32PQp);
			} else if (VENC_RC_MODE_H265QPMAP == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"QpMap",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					pChnInst->stVencChnAttr.stRcAttr.stH265QpMap.u32TargetBitRate,
					pChnInst->stVencChnAttr.stRcAttr.stH265QpMap.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH265QpMap.u32QpmapBlockUnit);
			}
		}

		if (PT_H264 == pChnInst->stVencChnAttr.stVencAttr.enType) {
			if (VENC_RC_MODE_H264CBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"CBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH264Cbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH264Cbr.stQpmapInfo.u32QpmapBlockUnit);
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8s%-13s%-13s\n",
					"", "IpropMax", "IpropMin");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8s%-13d%-13d\n",
					"",
					gAvcHevcHandle[i]->stH264Cbr.u32MaxIprop,
					gAvcHevcHandle[i]->stH264Cbr.u32MinIprop);
			} else if (VENC_RC_MODE_H264VBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"VBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH264Vbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH264Vbr.stQpmapInfo.u32QpmapBlockUnit);
			} else if (VENC_RC_MODE_H264AVBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"AVBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,
					pChnInst->stVencChnAttr.stRcAttr.stH264Vbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH264Vbr.stQpmapInfo.u32QpmapBlockUnit);
			} else if (VENC_RC_MODE_H264CVBR == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  --------- ---------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "Br_ST(kbps)", "Br_LT(kbps)", "MinQp", "MaxQp", "MinIQp", "MaxIQp", "IQpDelta", "IDRRange", "MaxBitRate","STStatTime","LTTime","LTMaxBitrate", "QpMapType", "QpMapUnit", "CtbRc");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
                    "%-8d%-13s%-13d%-13d%-13d%-13d%-13llu%-13llu%-13d%-13d%-13d%-13d%-13d%-13d%-13d%--13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"CVBR",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					gAvcHevcHandle[i]->rcCfg.bitPerSecond/VENC_BITRATE_RATIO,
                    pChnInst->u64ShortTermBitRate,
                    pChnInst->u64LongTermBitRate,
					gAvcHevcHandle[i]->rcCfg.qpMinPB,
					gAvcHevcHandle[i]->rcCfg.qpMaxPB,
					gAvcHevcHandle[i]->rcCfg.qpMinI,
					gAvcHevcHandle[i]->rcCfg.qpMaxI,
					gAvcHevcHandle[i]->rcCfg.intraQpDelta,
					gAvcHevcHandle[i]->rcCfg.idrDeltaRange,

                    pHandle->u32MaxBitRate,
                    pHandle->u32ShortTermStatTime,
                    pHandle->u32LongTermStatTime,
                    pHandle->u32LongTermMaxBitrate,

					pChnInst->stVencChnAttr.stRcAttr.stH264CVbr.stQpmapInfo.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH264CVbr.stQpmapInfo.u32QpmapBlockUnit,
					pChnInst->stVencChnAttr.stRcAttr.stH264CVbr.stQpmapInfo.enCtbRcMode);
			} else if (VENC_RC_MODE_H264FIXQP == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "IQp", "PQp");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"FixQP",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					pChnInst->stVencChnAttr.stRcAttr.stH264FixQp.u32IQp,
					pChnInst->stVencChnAttr.stRcAttr.stH264FixQp.u32PQp);
			} else if (VENC_RC_MODE_H264QPMAP == pChnInst->stVencChnAttr.stRcAttr.enRcMode) {
				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"-------- VENC RC ATTR  ------------------------\n"
					"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
					"ID", "RcMode", "Gop", "SrcFr", "DstFr", "Br(kbps)", "QpMapType", "QpMapUnit");

				snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
					"%-8d%-13s%-13d%-13d%-13d%-13d%-13d%-13d\n",
					i,
					"QpMap",
					gAvcHevcHandle[i]->encIn.gopConfig.idr_interval,
					pHandle->inputRateNumer,
					pHandle->outputRateNumer,
					pChnInst->stVencChnAttr.stRcAttr.stH264QpMap.u32TargetBitRate,
					pChnInst->stVencChnAttr.stRcAttr.stH264QpMap.enQpmapQpType,
					pChnInst->stVencChnAttr.stRcAttr.stH264QpMap.u32QpmapBlockUnit);
			}
		}

		/* GOP attribute */
		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"-------- VENC GOP ATTR  ------------------------\n"
			"%-8s%-13s\n",
			"ID", "GopMode");
		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"%-8d%-13s\n",
			i,
			pChnInst->stVencChnAttr.stGopAttr.enGopMode == VENC_GOPMODE_NORMALP ? "NormalP" :
				(pChnInst->stVencChnAttr.stGopAttr.enGopMode == VENC_GOPMODE_ONELTR) ? "OneLTR" : "SVC-T");

		snprintf(msg + strlen(msg),
			msgMaxLen - strlen(msg),
			"-------- VENC STATUS  ------------------------\n"
			"%-8s%-8s%-13s%-13s%-13s%-13s%-13s%-16s%-13s%-16s%-16s%-13s\n", "ID", "State", "FrmRecvNum", "FrmRlsNum", "FrmEncNum", "StrmGetNum", "StrmRlsNum", "BlkGetFailNum", "OutFps", "RealBr(kbps)", "ReEncodeCount", "DiscardCount");

		snprintf(msg + strlen(msg),
			msgMaxLen - strlen(msg),
			"%-8d%-8d%-13llu%-13llu%-13llu%-13llu%-13llu%-16llu%-13.2f%-16llu%-16llu%-13llu\n",
			i,
			gModCtx.enChnState[i],
			pChnInst->u64TotalRecvFrameNum,
			pChnInst->u64TotalReleaseFrameNum,
			pChnInst->u64TotalEncodeNum,
			pChnInst->u64TotalGetStrmNum,
			pChnInst->u64TotalReleaseStrmNum,
			pChnInst->u64TotalBlkGetFailNum,
			pChnInst->F32RealTimeFrameRate,
			pChnInst->u64RealTimeBitRate,
			pChnInst->u64ReEncodeCount,
			pChnInst->u64DiscardCount);

			/* ROI Info */
		snprintf(msg + strlen(msg), msgMaxLen - strlen(msg),
			"-------- VENC ROI INFO  ------------------------\n"
			"%-8s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n",
			"ID", "Index", "bEnable", "bAbsQp", "RoiQP", "Width", "Height", "StartX", "StartY");
		for(j = 0; j < MAX_ROI_NUM; j++)
		{
			snprintf(msg + strlen(msg),
					msgMaxLen - strlen(msg),
					"%-8d%-13d%-13s%-13s%-13d%-13d%-13d%-13d%-13d\n",
					i,
					j,
					pChnInst->stVencRoiAttr[j].bEnable == AX_TRUE ? "Y" : "N",
					pChnInst->stVencRoiAttr[j].bAbsQp == AX_TRUE ? "Y" : "N",
					pChnInst->stVencRoiAttr[j].s32RoiQp,
					pChnInst->stVencRoiAttr[j].stRoiArea.u32Width,
					pChnInst->stVencRoiAttr[j].stRoiArea.u32Height,
					pChnInst->stVencRoiAttr[j].stRoiArea.u32X,
					pChnInst->stVencRoiAttr[j].stRoiArea.u32Y);
		}

		snprintf(msg + strlen(msg),
			msgMaxLen - strlen(msg),
			"-------- VENC HW STATUS  ------------------------\n"
			"%-8s%-13s%-13s\n", "ID", "OverFlow", "TimeOut");

		snprintf(msg + strlen(msg),
			msgMaxLen - strlen(msg),
			"%-8d%-13llu%-13llu\n\n",
			i,
			pChnInst->u64HwBufferOverflowCount,
			pChnInst->u64HwTimeOutCount);

		s32Ret = pthread_mutex_unlock(&gModCtx.stChnStateMutex[i]);
		if (s32Ret)
			VLOG_ERROR("VENC %d: proc unlock err(%d).\n", i, s32Ret);
	}

	return;
}
