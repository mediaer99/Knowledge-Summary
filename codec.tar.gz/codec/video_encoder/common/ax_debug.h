#ifndef  _AX_DEBUG_H_
#define  _AX_DEBUG_H_

#include <pthread.h>
#include <unistd.h>
#include "ax_base_type.h"
#include "ax_comm_venc.h"

#ifdef __cplusplus
extern "C" {
#endif

int AX_EncAsicPrint(const char *str_flag, const asicData_s *asic, u32 flag);
AX_S32 AX_VCEncConfig_Print(const char *str_flag, const VCEncConfig *config, u32 flag);

#ifdef __cplusplus
}
#endif

#endif /*  */

