
#include <stdlib.h>
#include <semaphore.h>
#include "ax_fifo.h"
#include "ax_base_type.h"
#include "ax_venc_log.h"

/* Container for instance. */
typedef struct Fifo_s {
  pthread_spinlock_t spinLock;
  //sem_t cs_semaphore;    /* Semaphore for critical section. */
  sem_t read_semaphore;  /* Semaphore for readers. */
  sem_t write_semaphore; /* Semaphore for writers. */
  AX_U32 num_of_slots;
  AX_U32 num_of_objects;
  AX_U32 target_depth;
  AX_U32 current_depth;
  AX_U64 tail_index;
  FifoObject* nodes;
  AX_U32 popAbort;
  AX_U32 pushAbort;
} Fifo_t;

/*
 * FifoInit()
 * user specify FIFO capacity by "capacity"
 * this func allocate FIFO context buffer internally and
 * returns instance pointer
 */
FifoRet AX_Fifo_Create(AX_S32 VeChn, AX_U32 capacity, AX_U32 depth,FifoInst* instance)
{
  //calloc() will reset buffer to zeros
  Fifo_t* inst = calloc(1, sizeof(Fifo_t));
  if (inst == NULL){
    return FIFO_ERROR_MEMALLOC;
  }

  inst->num_of_slots = capacity;
  inst->target_depth = depth;
  inst->current_depth = depth;

  /* Allocate memory for the objects. */
  inst->nodes = calloc(capacity, sizeof(FifoObject));
  if (inst->nodes == NULL) {
    free(inst);
    inst = NULL;
    return FIFO_ERROR_MEMALLOC;
  }

  pthread_spin_init(&inst->spinLock, 0);

  /* Then initialize the read and write semaphores. */
  sem_init(&inst->read_semaphore, 0, 0);
  sem_init(&inst->write_semaphore, 0, depth);

  *instance = inst;

  return FIFO_OK;
}

/*
 * IsFifoFull()
 */
FifoRet AX_IsFifoFull(AX_S32 VeChn, const FifoInst inst)
{
  const Fifo_t* instance = (const Fifo_t*)inst;
  FifoRet fifoRet;

  fifoRet = (instance->num_of_objects >= instance->target_depth) ? FIFO_FULL : FIFO_OK;

  return fifoRet;
}

FifoRet AX_IsFifoEmpty(AX_S32 VeChn, const FifoInst inst)
{
  const Fifo_t* instance = (const Fifo_t*)inst;
  FifoRet fifoRet;

  fifoRet = (instance->num_of_objects == 0) ? FIFO_EMPTY : FIFO_OK;

  return fifoRet;
}
/*
 * FifoPush()
 * write_semaphore indicates how many can write
 * cs_semaphore serves as mutex to protect index pointers
 * the intial status is cs_semaphore=1, num_of_objects=0 and num_of_slots=max
 * therefore, there are initially 0 element to read and "max" elments to write
 * this function supports blocking mode (s32MilliSec=-1) and nonblocking mode (s32MilliSec=0)
 */
FifoRet AX_Fifo_Push(AX_S32 VeChn, FifoInst inst, FifoObject object, AX_S32 s32MilliSec)
{
  Fifo_t* instance = (Fifo_t *)inst;
  int value;

  /*non-block mode*/
  if ((0 == s32MilliSec) && (instance->num_of_objects >= instance->target_depth)) {
    return FIFO_FULL;
  }

  /*block mode*/
  pthread_spin_lock(&instance->spinLock);
  value = instance->current_depth - instance->target_depth;
  instance->current_depth = instance->target_depth;
  pthread_spin_unlock(&instance->spinLock);

  VLOG_DEBUG("VencChn %d: current_depth=%d,target_depth=%d .\n", VeChn,instance->current_depth,instance->target_depth);
  if (value > 0) {

    while(value){
        sem_wait(&instance->write_semaphore);
        value--;
    }
  }else if (value < 0) {

    while(value){
        sem_post(&instance->write_semaphore);
        value++;
    }
  }

  sem_wait(&instance->write_semaphore); //wait for any vacant slot
  VLOG_DEBUG("VencChn %d: write sem_wait --- .\n", VeChn);

  pthread_spin_lock(&instance->spinLock);

  VLOG_DEBUG("VencChn %d: spinLock ---.\n", VeChn);

  if(instance->num_of_objects >= instance->target_depth) {
    pthread_spin_unlock(&instance->spinLock);
    return FIFO_FULL;
  }

  instance->nodes[(instance->tail_index + instance->num_of_objects) %
                  instance->num_of_slots] = object;

  VLOG_DEBUG("VencChn %d: object=%p, tail_index=%lld, num_of_objects=%d, num_of_slots=%d.\n",
  	VeChn,
  	&instance->nodes[(instance->tail_index + instance->num_of_objects) % instance->num_of_slots],
    instance->tail_index,
    instance->num_of_objects,
    instance->num_of_slots);

  instance->num_of_objects++;

  pthread_spin_unlock(&instance->spinLock);

  sem_post(&instance->read_semaphore); //signal something can be read

  return FIFO_OK;
}

/*
 * FifoPeek()
 *Peek one object from the fifo, but the object is still remains in the fifo
 */
FifoRet AX_Fifo_Peek(AX_S32 VeChn, FifoInst inst, FifoObject* object, AX_S32 s32MilliSec)
{
  Fifo_t* instance = (Fifo_t *)inst;
  struct timespec start_time = {0};
  struct timespec end_time = {0};
  AX_U64 consume_ms = 0;

  //non-block
  if ((0 == s32MilliSec) && (instance->num_of_objects == 0)) {
    return FIFO_EMPTY;
  }

  //wait for s32MilliSec millsec
  if (s32MilliSec > 0) {

    clock_gettime(CLOCK_MONOTONIC, &start_time);
    while (instance->num_of_objects == 0) {

      /* Note:usleep accuracy is only about 5ms, so usleep(1000) is actually about 5ms latency */
      usleep(1000);

      clock_gettime(CLOCK_MONOTONIC, &end_time);
      consume_ms =
          (1000 * (end_time.tv_sec - start_time.tv_sec)) + ((end_time.tv_nsec - start_time.tv_nsec) / 1000000);
      if (consume_ms >= s32MilliSec) {
        return FIFO_EMPTY;
      }
    }
  }

  VLOG_DEBUG("VencChn %d: read sem_wait +++\n", VeChn);
  sem_wait(&instance->read_semaphore); //wait until there are something to read
  VLOG_DEBUG("VencChn %d: read sem_wait ---\n", VeChn);

  pthread_spin_lock(&instance->spinLock);
  VLOG_DEBUG("VencChn %d: cs spinLock ---\n", VeChn);

  if(instance->num_of_objects == 0){
    pthread_spin_unlock(&instance->spinLock);
    return FIFO_EMPTY;
  }

  *object = instance->nodes[instance->tail_index % instance->num_of_slots];

  VLOG_DEBUG("VencChn %d: object=%p, tail_index=%lld, num_of_objects=%d, num_of_slots=%d.\n",
    VeChn,
    object,
    instance->tail_index,
    instance->num_of_objects,
    instance->num_of_slots);

  pthread_spin_unlock(&instance->spinLock);

  sem_post(&instance->read_semaphore); //increase read_semaphore so that AX_Fifo_Pop can read the data

  return FIFO_OK;
}

/*
 * FifoPop()
 * read_semaphore indicates how many can read
 * cs_semaphore serves as mutex to protect index pointers
 * the intial status is cs_semaphore=1, num_of_objects=0
 * therefore, there are initially 0 element to read and "max" elments to write
 */
FifoRet AX_Fifo_Pop(AX_S32 VeChn, FifoInst inst, FifoObject* object, AX_S32 s32MilliSec)
{
  Fifo_t* instance = (Fifo_t *)inst;
  struct timespec start_time = {0};
  struct timespec end_time = {0};
  AX_U64 consume_ms = 0;

  //non-block
  if ((0 == s32MilliSec) && (instance->num_of_objects == 0)) {
    return FIFO_EMPTY;
  }

  //wait for s32MilliSec millsec
  if (s32MilliSec > 0) {

    clock_gettime(CLOCK_MONOTONIC, &start_time);
    while (instance->num_of_objects == 0) {

      /* Note:usleep accuracy is only about 5ms, so usleep(1000) is actually about 5ms latency */
      usleep(1000);

      clock_gettime(CLOCK_MONOTONIC, &end_time);
      consume_ms =
          (1000 * (end_time.tv_sec - start_time.tv_sec)) + ((end_time.tv_nsec - start_time.tv_nsec) / 1000000);
      if (consume_ms >= s32MilliSec) {
        return FIFO_EMPTY;
      }
    }
  }

  VLOG_DEBUG("VencChn %d: num_of_objects=%d\n", VeChn,instance->num_of_objects);
  VLOG_DEBUG("VencChn %d: read sem_wait +++\n", VeChn);
  sem_wait(&instance->read_semaphore); //wait until there are something to read
  VLOG_DEBUG("VencChn %d: read sem_wait ---\n", VeChn);
  pthread_spin_lock(&instance->spinLock);
  VLOG_DEBUG("VencChn %d: cs spinLock ---\n", VeChn);

  if(instance->num_of_objects == 0){
    pthread_spin_unlock(&instance->spinLock);
    return FIFO_EMPTY;
  }

  *object = instance->nodes[instance->tail_index % instance->num_of_slots];

  VLOG_DEBUG("VencChn %d: object=%p, tail_index=%lld, num_of_objects=%d, num_of_slots=%d.\n",
  	VeChn,
  	object,
    instance->tail_index,
    instance->num_of_objects,
    instance->num_of_slots);

  instance->tail_index++;
  instance->num_of_objects--;

  pthread_spin_unlock(&instance->spinLock);

  sem_post(&instance->write_semaphore); //increment writable value

  return FIFO_OK;
}

/*
 * FifoCount()
 * Check how many elements currently in FIFO
 * mutex is not necessary inside the function because the number may change
 * anyway after mutex released. if user rely on stable count, he will need
 * external mutex to protect count() and the next logic as a whole
 */
AX_U32 AX_Fifo_Count(AX_S32 VeChn, FifoInst inst)
{
  AX_U32 numOfObj = 0;
  Fifo_t* instance = (Fifo_t *)inst;

  numOfObj = instance->num_of_objects;

  return numOfObj;
}

/*
 * FifoHasObject()
 * Check if a specific element exists in FIFO
 */
AX_U32 AX_Fifo_HasObject(AX_S32 VeChn, FifoInst inst, FifoObject *object)
{
  AX_U32 i;
  AX_U32 success = 0;
  Fifo_t* instance = (Fifo_t *)inst;

  pthread_spin_lock(&instance->spinLock);

  //* need mutex to prevent FIFO status change during the job */
  for (i = 0; i < instance->num_of_objects; i++) {
    if (&instance->nodes[(instance->tail_index + i) %
                  instance->num_of_slots] == object) {
      success = 1;
      break;
    }
  }

  pthread_spin_unlock(&instance->spinLock);

  return success;
}

AX_S32 AX_Fifo_Destroy(AX_S32 VeChn, FifoInst inst)
{
  Fifo_t* instance = (Fifo_t *)inst;

  sem_destroy(&instance->read_semaphore);
  sem_destroy(&instance->write_semaphore);

  pthread_spin_destroy(&instance->spinLock);

  free(instance->nodes);
  instance->nodes = NULL;

  free(instance);
  instance = NULL;

  return 0;
}

void AX_Fifo_SetAbort(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType)
{
  Fifo_t* instance = (Fifo_t *)inst;
  if (instance == NULL)
    return;

  pthread_spin_lock(&instance->spinLock);
  if (VENC_FIFO_POP == oprType)
    instance->popAbort = 1;
  else if (VENC_FIFO_PUSH == oprType)
    instance->pushAbort = 1;
  pthread_spin_unlock(&instance->spinLock);

  return;
}

void AX_Fifo_ClearAbort(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType)
{
  Fifo_t* instance = (Fifo_t *)inst;
  if (instance == NULL)
    return;

  pthread_spin_lock(&instance->spinLock);
  if (VENC_FIFO_POP == oprType)
    instance->popAbort = 0;
  else if (VENC_FIFO_PUSH == oprType)
    instance->pushAbort = 0;
  pthread_spin_unlock(&instance->spinLock);

}

void AX_Fifo_WakeUp(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType)
{
  Fifo_t* instance = (Fifo_t *)inst;
  int value = 0;
  if (instance == NULL)
    return;

  if (VENC_FIFO_POP == oprType){
    sem_post(&instance->read_semaphore);
  } else if (VENC_FIFO_PUSH == oprType){
    sem_getvalue(&instance->write_semaphore, &value);
    if(value > 0) {
        return;
    }
    sem_post(&instance->write_semaphore);

  }

  return;
}

void AX_Fifo_SetDepth(AX_S32 VeChn, FifoInst inst, AX_U32 depth)
{
  Fifo_t* instance = (Fifo_t *)inst;
  if (instance == NULL)
    return;

  if((depth > instance->num_of_slots) || (depth <= 0)){
    VLOG_ERROR("VencChn %d: invalid fifo depth=%d,legal range:(1,%d]\n", VeChn,depth,instance->num_of_slots);
    return;
  }

  if(depth == instance->current_depth){
    return;
  }

  pthread_spin_lock(&instance->spinLock);

  instance->target_depth = depth;

  pthread_spin_unlock(&instance->spinLock);

}
