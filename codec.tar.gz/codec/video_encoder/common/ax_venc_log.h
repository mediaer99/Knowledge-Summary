/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#ifndef _VENC_LOG_D_H_
#define _VENC_LOG_D_H_

#include "ax_global_type.h"
#include "ax_venc_interface.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef enum VENC_DUMP_DATA_TYPE
{
    VENC_DUMP_NONE = 0,
    VENC_DUMP_STREAM = 1,
    VENC_DUMP_FRAME = 2,
    VENC_DUMP_ALL = 3 //dump both frame and stream data
} VENC_DUMP_DATA_TYPE_E;

typedef enum VENC_DUMP_CHN_RANGE
{
    VENC_DUMP_NONE_CHN = -2,
    VENC_DUMP_ALL_CHN = -1,
    VENC_DUMP_MIN_CHN = 0,
    /* reserved */
    VENC_DUMP_MAX_CHN = MAX_VENC_NUM
} VENC_DUMP_CHN_RANGE_E;

typedef struct VENC_DUMP_DATA
{
    /* dump stream or frame*/
	VENC_DUMP_DATA_TYPE_E enDumpType;
    /* channel id to dump */
	AX_S32 s32ChnIndex;
} VENC_DUMP_DATA_S;

AX_S32 VencDebugInit(AX_LOG_LEVEL_E eLogLevel,
			AX_LOG_TARGET_E eLogTarget, VENC_DUMP_DATA_TYPE_E enDumpType, AX_S32 s32ChnIndex);

void VLOG(AX_U32 eLv, char *fmt, ...);

AX_U64 VencGetTickCount(void);

AX_S32 VencDumpDataBegin(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
AX_VOID VencDumpDataEnd(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst);
AX_S32 VencDumpParse(AX_S8 *optArg, AX_S8 delim);


#define VLOG_CRITICAL(fmt,...)   \
    do { \
        VLOG(SYS_LOG_CRITICAL, "[AX_VENC][C][%s][%d]: "fmt"\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        printf("[AX_VENC][C][%s][%d] "fmt"\n", __func__, __LINE__, ##__VA_ARGS__); \
    }while(0)

#define VLOG_ERROR(fmt,...)   \
    do { \
        VLOG(SYS_LOG_ERROR, "[AX_VENC][E][%s][%d]: "fmt"", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
    }while(0)

#define VLOG_WARNING(fmt,...) \
    VLOG(SYS_LOG_WARN, "[AX_VENC][W][%s][%d]: "fmt"", __FUNCTION__, __LINE__, ##__VA_ARGS__);

#define VLOG_INFO(fmt,...) \
    VLOG(SYS_LOG_INFO, "[AX_VENC][I][%s][%d]: "fmt"", __FUNCTION__, __LINE__, ##__VA_ARGS__);

#define VLOG_DEBUG(fmt,...) \
    VLOG(SYS_LOG_DEBUG, "[AX_VENC][D][%s][%d]: "fmt"", __FUNCTION__, __LINE__, ##__VA_ARGS__);

#define VLOG_NOTICE(fmt,...) \
    VLOG(SYS_LOG_NOTICE, "[AX_VENC][N][%s][%d]: "fmt"", __FUNCTION__, __LINE__, ##__VA_ARGS__);


#ifdef __cplusplus
}
#endif

#endif
