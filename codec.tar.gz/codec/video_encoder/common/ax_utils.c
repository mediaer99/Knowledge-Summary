#include <math.h>
#include "base_type.h"
#include "ax_sys_log.h"
#include "ax_venc_log.h"
#include "ax_utils.h"

// multi slice check
#define H264_CU_SIZE 16
#define H265_CU_SIZE 64

#define VIDEO_BITRATE_RANGE_CHECK(VeChn, u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE) \
    do {    \
        if ((u32BitRate < VENC_MIN_BITRATE) || (u32BitRate > VENC_MAX_BITRATE)) {   \
            VLOG_ERROR("VencChn %d:  invalid bitRate(%u), should rang in[%u, %u] kbps.\n", \
                VeChn, u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        }   \
    } while (0)

#define VIDEO_GOP_RANGE_CHECK(VeChn, u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL) \
    do {    \
        if ((u32Gop < VENC_MIN_IDR_INTERVAL) || (u32Gop > VENC_MAX_IDR_INTERVAL)) {   \
            VLOG_ERROR("VencChn %d:  invalid gop length(%u), should rang in[%u, %u].\n", \
                VeChn, u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        }   \
    } while (0)

#define VIDEO_QP_RANGE_CHECK(VeChn, u32Qp, VENC_MIN_QP, VENC_MAX_QP) \
    do {    \
        if ((u32Qp < VENC_MIN_QP) || (u32Qp > VENC_MAX_QP)) {   \
            VLOG_ERROR("VencChn %d:  invalid Qp value(%u), should rang in[%u, %u].\n", \
                VeChn, u32Qp, VENC_MIN_QP, VENC_MAX_QP); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        }   \
    } while (0)

#define VIDEO_FRAME_RATE_RANGE_CHECK(VeChn, u32FrameRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE) \
    do {    \
        if ((u32FrameRate < VENC_MIN_FRAME_RATE) || (u32FrameRate > VENC_MAX_FRAME_RATE)) {   \
            VLOG_ERROR("VencChn %d:  invalid frame rate value(%u), should rang in[%u, %u].\n", \
                VeChn, u32FrameRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        }   \
    } while (0)

#define VIDEO_QPMAP_BLOCK_UNIT_RANGE_CHECK(VeChn, u32BlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H264_QPMAP_BLOCK_UNIT) \
    do { \
        if ((u32BlockUnit < VENC_MIN_QPMAP_BLOCK_UNIT) || (u32BlockUnit > VENC_MAX_H264_QPMAP_BLOCK_UNIT)) { \
            VLOG_ERROR("VencChn %d:  invalid qpmap block unit value(%u), should rang in[%u, %u].\n", \
                VeChn, u32BlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H264_QPMAP_BLOCK_UNIT); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        } \
    } while (0)

#define VIDEO_QPMAP_CTBRC_RANGE_CHECK(VeChn, u32CtbRc, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE) \
    do { \
        if ((u32CtbRc < VENC_MIN_CTBRC_TYPE) || (u32CtbRc > VENC_MAX_CTBRC_TYPE)) { \
            VLOG_ERROR("VencChn %d:  invalid qpmap ctbrc type value(%u), should rang in[%u, %u].\n", \
                VeChn, u32CtbRc, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        } \
    } while (0)

#define VIDEO_QPMAP_QPTYPE_RANGE_CHECK(VeChn, u32QpType, VENC_MIN_QPMAP_QPTYPE, VENC_MAX_QPMAP_QPTYPE) \
    do { \
        if ((u32QpType < VENC_MIN_QPMAP_QPTYPE) || (u32QpType > VENC_MAX_QPMAP_QPTYPE)) { \
            VLOG_ERROR("VencChn %d:  invalid qpmap qptype type value(%u), should rang in[%u, %u].\n", \
                VeChn, u32QpType, VENC_MIN_QPMAP_QPTYPE, VENC_MAX_QPMAP_QPTYPE); \
            return AX_ERR_VENC_ILLEGAL_PARAM;   \
        } \
    } while (0)


AX_S32 VencCropAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr);

AX_S32 AvcChnRcAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr);
AX_S32 HevcChnRcAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr);

static AX_S32 AvcHevcChnAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    AX_S32 s32Ret = -1;
    AX_PAYLOAD_TYPE_E enType;

    enType = pstAttr->stVencAttr.enType;

    if ((pstAttr->stGopAttr.enGopMode < VENC_GOPMODE_NORMALP) ||
            (pstAttr->stGopAttr.enGopMode >= VENC_GOPMODE_BUTT) ) {
        VLOG_ERROR("VencChn %d: invalid gop mode(%d).\n", VeChn, pstAttr->stGopAttr.enGopMode);
		return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (PT_H264 == enType)
        s32Ret = AvcChnRcAttrCheck(VeChn, pstAttr);
    else if (PT_H265 == enType)
        s32Ret = HevcChnRcAttrCheck(VeChn, pstAttr);
    else
        s32Ret = AX_ERR_VENC_ILLEGAL_PARAM;

    return s32Ret;
}

/*  */
static AX_S32 JencChnAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    AX_S32 chn_width_max = pstAttr->stVencAttr.u32MaxPicWidth;
    AX_S32 chn_height_max = pstAttr->stVencAttr.u32MaxPicHeight;
    AX_S32 chn_width = pstAttr->stVencAttr.u32PicWidthSrc;
    AX_S32 chn_height = pstAttr->stVencAttr.u32PicHeightSrc;
    AX_U32 dst_frameRate = 0;
    AX_U32 src_frameRate = 0;
    AX_U32 u32MinQp = 0;
    AX_U32 u32MaxQp = 0;
    AX_S32 s32FixedQp = 0;
    AX_VENC_RC_MODE_E enRcMode = pstAttr->stRcAttr.enRcMode;

    if (chn_width_max > MaxJencWidth || chn_width_max < MinJencWidth) {
        VLOG_ERROR("VencChn %d: Set channel width %d over range[32, 32768].\n", VeChn, chn_width_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_height_max > MaxJencHeight || chn_height_max < MinJencHeight) {
        VLOG_ERROR("VencChn %d: Set channel height %d over range[32, 32768].\n", VeChn, chn_height_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_width > MaxJencWidth || chn_width < MinJencWidth) {
        VLOG_ERROR("VencChn %d: Set channel max width %d over range[32, 32768].\n", VeChn, chn_width);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_height > MaxJencHeight || chn_height < MinJencHeight) {
        VLOG_ERROR("VencChn %d: Set channel max height %d over range[32, 32768].\n", VeChn, chn_height);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_width > chn_width_max && chn_width_max != 0) {
        VLOG_ERROR("VencChn %d: u32PicWidthSrc %d > u32MaxPicWidth %d not support.\n",
            VeChn, chn_width, chn_width_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (chn_height > chn_height_max && chn_height_max != 0) {
        VLOG_ERROR("VencChn %d: u32PicHeightSrc %d > u32MaxPicHeight %d not support.\n",
            VeChn, chn_height, chn_height_max);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (pstAttr->stVencAttr.enType == PT_JPEG) {

    } else {
        switch (enRcMode) {
        case VENC_RC_MODE_MJPEGCBR:
            dst_frameRate = pstAttr->stRcAttr.stMjpegCbr.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegCbr.u32SrcFrameRate;
            u32MaxQp = pstAttr->stRcAttr.stMjpegCbr.u32MaxQp;
            u32MinQp = pstAttr->stRcAttr.stMjpegCbr.u32MinQp;
            break;
        case VENC_RC_MODE_MJPEGFIXQP:
            dst_frameRate = pstAttr->stRcAttr.stMjpegFixQp.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegFixQp.u32SrcFrameRate;
            s32FixedQp = pstAttr->stRcAttr.stMjpegFixQp.s32FixedQp;
            break;
        case VENC_RC_MODE_MJPEGVBR:
            dst_frameRate = pstAttr->stRcAttr.stMjpegVbr.fr32DstFrameRate;
            src_frameRate = pstAttr->stRcAttr.stMjpegVbr.u32SrcFrameRate;
            u32MaxQp = pstAttr->stRcAttr.stMjpegVbr.u32MaxQp;
            u32MinQp = pstAttr->stRcAttr.stMjpegVbr.u32MinQp;
            break;
        default:
            break;
        }
        if (dst_frameRate > src_frameRate) {
            VLOG_ERROR("VencChn %d: Target frame rate more than Source frame rate: srcFrmRate=%d, TargetFrmRate=%d.\n",
                  VeChn, src_frameRate, dst_frameRate);
            return AX_ERR_VENC_ILLEGAL_PARAM;
        }
        if(VENC_RC_MODE_MJPEGCBR == enRcMode ||  VENC_RC_MODE_MJPEGVBR == enRcMode) {
            VIDEO_QP_RANGE_CHECK(VeChn, u32MinQp, VENC_MIN_QP, VENC_MAX_QP);
            VIDEO_QP_RANGE_CHECK(VeChn, u32MaxQp, VENC_MIN_QP, VENC_MAX_QP);
            if (u32MinQp > u32MaxQp) {
                VLOG_ERROR("VencChn %d:  u32MinQp=%u > u32MaxQp=%u.\n",
                           VeChn, u32MinQp, u32MaxQp);
                return AX_ERR_VENC_ILLEGAL_PARAM;
            }
        }
        if(VENC_RC_MODE_MJPEGFIXQP == enRcMode) {
            VIDEO_QP_RANGE_CHECK(VeChn, s32FixedQp, VENC_MIN_QP, VENC_MAX_QP);
        }
    }

	return AX_SUCCESS;
}

AX_S32 VencChnAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
	AX_S32 s32Ret = -1;
	AX_PAYLOAD_TYPE_E enType;
    AX_U32 u32MinStrmBuffSize = 0;

	if (VeChn < 0 || VeChn >= MAX_VENC_NUM) {
        VLOG_ERROR("VencChn %d: Invalid channel ID.\n", VeChn);
		return AX_ERR_VENC_INVALID_CHNID;
	}

	if (NULL == pstAttr) {
        VLOG_ERROR("VencChn %d: Invalid param, pstAttr is null.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	enType = pstAttr->stVencAttr.enType;

	if (PT_H264 == enType || PT_H265 == enType) {
		s32Ret = AvcHevcChnAttrCheck(VeChn, pstAttr);
		if (0 != s32Ret) {
			//
			return -1;
		}
	} else if (PT_JPEG == enType || PT_MJPEG == enType) {
		s32Ret = JencChnAttrCheck(VeChn, pstAttr);
		if (0 != s32Ret) {
			return s32Ret;
		}
	} else {
        VLOG_ERROR("VencChn %d: Invalid codec format %d.\n", VeChn, pstAttr->stVencAttr.enType);
		return -1;
	}

    /*  source image must be even */
    if ((pstAttr->stVencAttr.u32PicWidthSrc & (1)) != 0 ||
        (pstAttr->stVencAttr.u32PicHeightSrc & (1)) != 0)   {
        VLOG_ERROR("VencChn %d: PicWidthSrc or PicHeightSrc must be even.\n", VeChn);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    /* crop attr check, if cropWidth or cropHeight is valid,  */
    s32Ret = VencCropAttrCheck(VeChn, pstAttr);
    if (AX_SUCCESS != s32Ret) {
            VLOG_ERROR("VencChn %d: Invalid crop setting.\n", VeChn);
            return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    // multi slice attr check
    if (PT_H264 == enType || PT_H265 == enType)
    {
        AX_U32 u32MaxMbLineNum = 0;
        AX_U32 u32CuSize = PT_H264 == enType ? H264_CU_SIZE : H265_CU_SIZE;
        if (pstAttr->stVencAttr.u32CropHeight != 0 && pstAttr->stVencAttr.u32CropWidth != 0)
        {
            u32MaxMbLineNum = (pstAttr->stVencAttr.u32CropHeight + u32CuSize - 1) / u32CuSize;
        }
        else
        {
            u32MaxMbLineNum = (pstAttr->stVencAttr.u32PicHeightSrc + u32CuSize - 1) / u32CuSize;
        }
        if (pstAttr->stVencAttr.u32MbLinesPerSlice > u32MaxMbLineNum)
        {
            VLOG_ERROR("VencChn %d:  Invalid slice number(%u), should range in [0, %u].\n",
                VeChn,
                pstAttr->stVencAttr.u32MbLinesPerSlice,
                u32MaxMbLineNum);
            return AX_ERR_VENC_ILLEGAL_PARAM;
        }
    }

    if ((pstAttr->stVencAttr.enLinkMode != AX_NONLINK_MODE) && (pstAttr->stVencAttr.enLinkMode != AX_LINK_MODE)) {
        VLOG_ERROR("VencChn %d: Invalid mode %d.\n", VeChn, pstAttr->stVencAttr.enLinkMode);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((0 != pstAttr->stVencAttr.u32VideoRange) && (1 != pstAttr->stVencAttr.u32VideoRange))   {
        VLOG_ERROR("VencChn %d: Invalid Video Range=%d.\n", VeChn, pstAttr->stVencAttr.u32VideoRange);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (PT_JPEG == enType || PT_MJPEG == enType){
        u32MinStrmBuffSize = pstAttr->stVencAttr.u32PicWidthSrc * pstAttr->stVencAttr.u32PicHeightSrc * 3/8;
    }else{
        u32MinStrmBuffSize = pstAttr->stVencAttr.u32PicWidthSrc * pstAttr->stVencAttr.u32PicHeightSrc * 3/4;
    }

    if (pstAttr->stVencAttr.u32BufSize > 0 && pstAttr->stVencAttr.u32BufSize < u32MinStrmBuffSize) {
        VLOG_ERROR("VencChn %d: Invalid stream buffer size=%u, should not less than(%u).\n",
                    VeChn,
                    pstAttr->stVencAttr.u32BufSize,
                    u32MinStrmBuffSize);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (pstAttr->stVencAttr.u8InFifoDepth > VENC_MAX_FIFO_CAPACITY) {
        VLOG_ERROR("VencChn %d: Invalid input fifo depth=%d, shall not exceed max fifo capacity(%d).\n",
                    VeChn,
                    pstAttr->stVencAttr.u8InFifoDepth,
                    VENC_MAX_FIFO_CAPACITY);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if (pstAttr->stVencAttr.u8OutFifoDepth > VENC_MAX_FIFO_CAPACITY) {
        VLOG_ERROR("VencChn %d: Invalid output fifo depth=%d, shall not exceed max fifo capacity(%d).\n",
                    VeChn,
                    pstAttr->stVencAttr.u8OutFifoDepth,
                    VENC_MAX_FIFO_CAPACITY);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }
	if (PT_H264 == enType) {
		if(pstAttr->stVencAttr.enLevel > VENC_H264_LEVEL_6_2 || pstAttr->stVencAttr.enLevel < VENC_H264_LEVEL_1)
		{
			 VLOG_ERROR("VencChn %d: enType:%d  Invalid enLevel: %d\n",
				VeChn, enType, pstAttr->stVencAttr.enLevel);
			 return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		if(pstAttr->stVencAttr.enProfile > VENC_H264_HIGH_10_PROFILE || pstAttr->stVencAttr.enProfile < VENC_H264_BASE_PROFILE)
		{
			 VLOG_ERROR("VencChn %d: enType: %d Invalid enProfile: %d\n",
				VeChn, enType, pstAttr->stVencAttr.enProfile);
	    	 return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	} else if (PT_H265 == enType) {
		if(pstAttr->stVencAttr.enLevel > VENC_HEVC_LEVEL_6_2 || pstAttr->stVencAttr.enLevel < VENC_HEVC_LEVEL_1)
		{
			 VLOG_ERROR("VencChn %d: enType: %d Invalid enLevel: %d\n",
				VeChn, enType, pstAttr->stVencAttr.enLevel);
			 return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		if(pstAttr->stVencAttr.enProfile > VENC_HEVC_MAINREXT || pstAttr->stVencAttr.enProfile < VENC_HEVC_MAIN_PROFILE)
		{
			 VLOG_ERROR("VencChn %d: enType: %d Invalid enProfile: %d\n",
					VeChn, enType, pstAttr->stVencAttr.enProfile);
			 return AX_ERR_VENC_ILLEGAL_PARAM;
		}
		if(pstAttr->stVencAttr.enTier != VENC_HEVC_HIGH_TIER && pstAttr->stVencAttr.enTier != VENC_HEVC_MAIN_TIER)
		{
			VLOG_ERROR("VencChn %d:  enType: %d Invalid enTier: %d\n",
					VeChn, enType, pstAttr->stVencAttr.enTier);
			 return AX_ERR_VENC_ILLEGAL_PARAM;
		}
	}
	return AX_SUCCESS;
}

AX_S32 VencCropAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    /* CropOffset must be even */
    if ((pstAttr->stVencAttr.u32CropOffsetX & (1)) != 0 ||
        (pstAttr->stVencAttr.u32CropOffsetY & (1)) != 0)       {
        VLOG_ERROR("VencChn %d: CropOffsetX or CropOffsetY must be even.\n", VeChn);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ( (pstAttr->stVencAttr.u32CropOffsetX < 0) || (pstAttr->stVencAttr.u32CropOffsetY < 0) ) {
        VLOG_ERROR("VencChn %d: Invalid offsetX=%u or offsetY=%u.\n",
            VeChn,
            pstAttr->stVencAttr.u32CropOffsetX,
            pstAttr->stVencAttr.u32CropOffsetY);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ( (pstAttr->stVencAttr.u32CropWidth < 0) || (pstAttr->stVencAttr.u32CropHeight < 0) ) {
        VLOG_ERROR("VencChn %d: Invalid cropWidth=%u or cropHeight=%u.\n",
            VeChn,
            pstAttr->stVencAttr.u32CropWidth,
            pstAttr->stVencAttr.u32CropHeight);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

	if ( (pstAttr->stVencAttr.u32CropOffsetX + pstAttr->stVencAttr.u32CropWidth) > pstAttr->stVencAttr.u32PicWidthSrc) {
		VLOG_ERROR("VencChn %d: offsetX(%u) + cropWidth(%u) > u32PicWidthSrc(%u).\n",
			VeChn,
			pstAttr->stVencAttr.u32CropOffsetX,
			pstAttr->stVencAttr.u32CropWidth,
			pstAttr->stVencAttr.u32PicWidthSrc);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

	if ( (pstAttr->stVencAttr.u32CropOffsetY + pstAttr->stVencAttr.u32CropHeight) > pstAttr->stVencAttr.u32PicHeightSrc) {
		VLOG_ERROR("VencChn %d: offsetY(%u) + cropHeight(%u) > u32PicHeightSrc(%u).\n",
			VeChn,
			pstAttr->stVencAttr.u32CropOffsetY,
			pstAttr->stVencAttr.u32CropHeight,
			pstAttr->stVencAttr.u32PicHeightSrc);
		return AX_ERR_VENC_ILLEGAL_PARAM;
	}

    return AX_SUCCESS;
}

AX_S32 AvcChnRcAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    AX_VENC_RC_MODE_E enRcMode = pstAttr->stRcAttr.enRcMode;
    AX_U32 u32BitRate = 0;
    AX_U32 u32Gop = 0;
    AX_U32 u32MinQp = 0;
    AX_U32 u32MaxQp = 51;
    AX_U32 u32MinIQp = 0;
    AX_U32 u32MaxIQp = 51;
    //FixedQp
    AX_U32 u32IQp = 0;
    AX_U32 u32PQp = 0;
    AX_U32 u32BQp = 0;
    //frame rate
    AX_U32 u32SrcFrmRate = 0;
    AX_U32 u32DstFrmRate = 0;
    //Qpmap
    AX_U32 u32BlockUnit = 0;
    AX_VENC_RC_CTBRC_MODE_E enCtbRcMode = VENC_RC_CTBRC_DISABLE;
    AX_VENC_QPMAP_QP_TYPE_E enQpmapType = VENC_QPMAP_DISABLE;

    AX_U32      u32ShortTermStatTime;       /* RW; Range:[1, 120]; the long-term rate statistic time, the unit is second (s)*/
    AX_U32      u32LongTermStatTime;        /* RW; Range:[1, 1440]; the long-term rate statistic time, the unit is u32LongTermStatTimeUnit*/
    AX_U32      u32LongTermMaxBitrate;     /* RW; Range:[2, 614400];the long-term target max bitrate, can not be larger than u32MaxBitRate,the unit is kbps */
    AX_U32      u32LongTermMinBitrate;

    switch (enRcMode)
	{
	    case VENC_RC_MODE_H264CBR:
	    {
	        AX_VENC_H264_CBR_S stH264Cbr = pstAttr->stRcAttr.stH264Cbr;

	        u32BitRate = stH264Cbr.u32BitRate;
	        u32Gop = stH264Cbr.u32Gop;

	        u32MinQp = stH264Cbr.u32MinQp;
	        u32MaxQp = stH264Cbr.u32MaxQp;
	        u32MinIQp = stH264Cbr.u32MinIQp;
	        u32MaxIQp = stH264Cbr.u32MaxIQp;

	        u32SrcFrmRate = stH264Cbr.u32SrcFrameRate;
	        u32DstFrmRate = stH264Cbr.fr32DstFrameRate;

	        u32BlockUnit = stH264Cbr.stQpmapInfo.u32QpmapBlockUnit;
	        enCtbRcMode = stH264Cbr.stQpmapInfo.enCtbRcMode;
	        enQpmapType = stH264Cbr.stQpmapInfo.enQpmapQpType;
	    }
	    break;

	    case VENC_RC_MODE_H264VBR:
	    {
	        AX_VENC_H264_VBR_S stH264Vbr = pstAttr->stRcAttr.stH264Vbr;

	        u32BitRate = stH264Vbr.u32MaxBitRate;
	        u32Gop = stH264Vbr.u32Gop;

	        u32MinQp = stH264Vbr.u32MinQp;
	        u32MaxQp = stH264Vbr.u32MaxQp;
	        u32MinIQp = stH264Vbr.u32MinIQp;
	        u32MaxIQp = stH264Vbr.u32MaxIQp;

	        u32SrcFrmRate = stH264Vbr.u32SrcFrameRate;
	        u32DstFrmRate = stH264Vbr.fr32DstFrameRate;

	        u32BlockUnit = stH264Vbr.stQpmapInfo.u32QpmapBlockUnit;
	        enCtbRcMode = stH264Vbr.stQpmapInfo.enCtbRcMode;
	        enQpmapType = stH264Vbr.stQpmapInfo.enQpmapQpType;
	    }
	    break;

        case VENC_RC_MODE_H264AVBR:
	    {
	        AX_VENC_H264_AVBR_S stH264AVbr = pstAttr->stRcAttr.stH264AVbr;

	        u32BitRate = stH264AVbr.u32MaxBitRate;
	        u32Gop = stH264AVbr.u32Gop;

	        u32MinQp = stH264AVbr.u32MinQp;
	        u32MaxQp = stH264AVbr.u32MaxQp;
	        u32MinIQp = stH264AVbr.u32MinIQp;
	        u32MaxIQp = stH264AVbr.u32MaxIQp;

	        u32SrcFrmRate = stH264AVbr.u32SrcFrameRate;
	        u32DstFrmRate = stH264AVbr.fr32DstFrameRate;

	        u32BlockUnit = stH264AVbr.stQpmapInfo.u32QpmapBlockUnit;
	        enCtbRcMode = stH264AVbr.stQpmapInfo.enCtbRcMode;
	        enQpmapType = stH264AVbr.stQpmapInfo.enQpmapQpType;
	    }
	    break;

        case VENC_RC_MODE_H264CVBR:
       {
            AX_VENC_H264_CVBR_S stH264CVbr = pstAttr->stRcAttr.stH264CVbr;

            u32BitRate = stH264CVbr.u32MaxBitRate;
            u32Gop = stH264CVbr.u32Gop;

            u32MinQp = stH264CVbr.u32MinQp;
            u32MaxQp = stH264CVbr.u32MaxQp;
            u32MinIQp = stH264CVbr.u32MinIQp;
            u32MaxIQp = stH264CVbr.u32MaxIQp;

            u32SrcFrmRate = stH264CVbr.u32SrcFrameRate;
            u32DstFrmRate = stH264CVbr.fr32DstFrameRate;


            u32ShortTermStatTime = stH264CVbr.u32ShortTermStatTime;       /* RW; Range:[1, 120]; the long-term rate statistic time, the unit is second (s)*/
            u32LongTermStatTime = stH264CVbr.u32LongTermStatTime;        /* RW; Range:[1, 1440]; the long-term rate statistic time, the unit is u32LongTermStatTimeUnit*/
            u32LongTermMaxBitrate = stH264CVbr.u32LongTermMaxBitrate;     /* RW; Range:[2, 614400];the long-term target max bitrate, can not be larger than u32MaxBitRate,the unit is kbps */
            u32LongTermMinBitrate = stH264CVbr.u32LongTermMinBitrate;
            u32BlockUnit = stH264CVbr.stQpmapInfo.u32QpmapBlockUnit;
            enCtbRcMode = stH264CVbr.stQpmapInfo.enCtbRcMode;
            enQpmapType = stH264CVbr.stQpmapInfo.enQpmapQpType;

       }
       break;

	    case VENC_RC_MODE_H264QPMAP:
	    {
	        AX_VENC_H264_QPMAP_S stH264QpMap = pstAttr->stRcAttr.stH264QpMap;

	        u32BitRate = stH264QpMap.u32TargetBitRate;
	        u32Gop = stH264QpMap.u32Gop;

	        u32SrcFrmRate = stH264QpMap.u32SrcFrameRate;
	        u32DstFrmRate = stH264QpMap.fr32DstFrameRate;

	        u32BlockUnit = stH264QpMap.u32QpmapBlockUnit;
	        enCtbRcMode = stH264QpMap.enCtbRcMode;
	        enQpmapType = stH264QpMap.enQpmapQpType;
	    }
	    break;

	    case VENC_RC_MODE_H264FIXQP:
	    {
	        AX_VENC_H264_FIXQP_S stH264FixQp = pstAttr->stRcAttr.stH264FixQp;

	        u32Gop = stH264FixQp.u32Gop;

	        u32IQp = stH264FixQp.u32IQp;
	        u32PQp = stH264FixQp.u32PQp;
	        u32BQp = stH264FixQp.u32BQp;

	        u32SrcFrmRate = stH264FixQp.u32SrcFrameRate;
	        u32DstFrmRate = stH264FixQp.fr32DstFrameRate;
	    }
	    break;

	    default:
	        VLOG_ERROR("VencChn %d:  invalid rc mode(%d).\n", VeChn, enRcMode);
	        return AX_ERR_VENC_ILLEGAL_PARAM;
	}

    if ((VENC_RC_MODE_H264CBR == enRcMode) || (VENC_RC_MODE_H264VBR == enRcMode) || (VENC_RC_MODE_H264AVBR == enRcMode) || (VENC_RC_MODE_H264CVBR == enRcMode)) {
        VIDEO_QP_RANGE_CHECK(VeChn, u32MinQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MaxQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MinIQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MaxIQp, VENC_MIN_QP, VENC_MAX_QP);

        if (u32MinQp > u32MaxQp) {
            VLOG_ERROR("VencChn %d:  u32MinQp=%u > u32MaxQp=%u.\n",
                    VeChn, u32MinQp, u32MaxQp);
		    return AX_ERR_VENC_ILLEGAL_PARAM;
        }
        if (u32MinIQp > u32MaxIQp) {
            VLOG_ERROR("VencChn %d:  u32MinIQp=%u > u32MaxIQp=%u.\n",
                    VeChn, u32MinIQp, u32MaxIQp);
		    return AX_ERR_VENC_ILLEGAL_PARAM;
        }
    }

    if ((VENC_RC_MODE_H264CBR == enRcMode) || (VENC_RC_MODE_H264VBR == enRcMode || (VENC_RC_MODE_H264CVBR == enRcMode)) \
        || (VENC_RC_MODE_H264QPMAP == enRcMode) || (VENC_RC_MODE_H264AVBR == enRcMode)) {
        if (enQpmapType > VENC_QPMAP_DISABLE && enQpmapType <= VENC_QPMAP_ENABLE_IPCM) {
            VIDEO_QPMAP_BLOCK_UNIT_RANGE_CHECK(VeChn, u32BlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H264_QPMAP_BLOCK_UNIT);
            VIDEO_QPMAP_CTBRC_RANGE_CHECK(VeChn, enCtbRcMode, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE);
        }
    }

    if (VENC_RC_MODE_H264FIXQP != enRcMode)
        VIDEO_BITRATE_RANGE_CHECK(VeChn, u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

    if (VENC_RC_MODE_H264FIXQP == enRcMode) {
        VIDEO_QP_RANGE_CHECK(VeChn, u32IQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32PQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32BQp, VENC_MIN_QP, VENC_MAX_QP);
    }

    VIDEO_GOP_RANGE_CHECK(VeChn, u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
    VIDEO_FRAME_RATE_RANGE_CHECK(VeChn, u32SrcFrmRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE);
    VIDEO_FRAME_RATE_RANGE_CHECK(VeChn, u32DstFrmRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE);

    return AX_SUCCESS;
}

AX_S32 HevcChnRcAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr)
{
    AX_VENC_RC_MODE_E enRcMode = pstAttr->stRcAttr.enRcMode;
    AX_U32 u32BitRate = 0;
    AX_U32 u32Gop = 0;
    AX_U32 u32MinQp = 0;
    AX_U32 u32MaxQp = 51;
    AX_U32 u32MinIQp = 0;
    AX_U32 u32MaxIQp = 51;
    //FixedQp
    AX_U32 u32IQp = 0;
    AX_U32 u32PQp = 0;
    AX_U32 u32BQp = 0;
    //frame rate
    AX_U32 u32SrcFrmRate = 0;
    AX_U32 u32DstFrmRate = 0;
    //Qpmap
    AX_U32 u32BlockUnit = 0;
    AX_VENC_RC_CTBRC_MODE_E enCtbRcMode = VENC_RC_CTBRC_DISABLE;
    AX_VENC_QPMAP_QP_TYPE_E enQpmapType = VENC_QPMAP_DISABLE;


    AX_U32 u32ShortTermStatTime;       /* RW; Range:[1, 120]; the long-term rate statistic time, the unit is second (s)*/
    AX_U32 u32LongTermStatTime;        /* RW; Range:[1, 1440]; the long-term rate statistic time, the unit is u32LongTermStatTimeUnit*/
    AX_U32 u32LongTermMaxBitrate;     /* RW; Range:[2, 614400];the long-term target max bitrate, can not be larger than u32MaxBitRate,the unit is kbps */
    AX_U32 u32LongTermMinBitrate;     /* RW; Range:[0, 614400];the long-term target min bitrate,  can not be larger than u32LongTermMaxBitrate,the unit is kbps */

    AX_U32 u32ExtraBitPercent;
    AX_U32 u32LongTermStatTimeUnit;

    switch (enRcMode)
    {
    case VENC_RC_MODE_H265CBR:
    {
        AX_VENC_H265_CBR_S stH265Cbr = pstAttr->stRcAttr.stH265Cbr;

        u32BitRate = stH265Cbr.u32BitRate;
        u32Gop = stH265Cbr.u32Gop;

        u32MinQp = stH265Cbr.u32MinQp;
        u32MaxQp = stH265Cbr.u32MaxQp;
        u32MinIQp = stH265Cbr.u32MinIQp;
        u32MaxIQp = stH265Cbr.u32MaxIQp;

        u32SrcFrmRate = stH265Cbr.u32SrcFrameRate;
        u32DstFrmRate = stH265Cbr.fr32DstFrameRate;

        u32BlockUnit = stH265Cbr.stQpmapInfo.u32QpmapBlockUnit;
        enCtbRcMode = stH265Cbr.stQpmapInfo.enCtbRcMode;
        enQpmapType = stH265Cbr.stQpmapInfo.enQpmapQpType;
    }
    break;

    case VENC_RC_MODE_H265VBR:
    {
        AX_VENC_H265_VBR_S stH265Vbr = pstAttr->stRcAttr.stH265Vbr;

        u32BitRate = stH265Vbr.u32MaxBitRate;
        u32Gop = stH265Vbr.u32Gop;

        u32MinQp = stH265Vbr.u32MinQp;
        u32MaxQp = stH265Vbr.u32MaxQp;
        u32MinIQp = stH265Vbr.u32MinIQp;
        u32MaxIQp = stH265Vbr.u32MaxIQp;

        u32SrcFrmRate = stH265Vbr.u32SrcFrameRate;
        u32DstFrmRate = stH265Vbr.fr32DstFrameRate;

        u32BlockUnit = stH265Vbr.stQpmapInfo.u32QpmapBlockUnit;
        enCtbRcMode = stH265Vbr.stQpmapInfo.enCtbRcMode;
        enQpmapType = stH265Vbr.stQpmapInfo.enQpmapQpType;
    }
    break;

    case VENC_RC_MODE_H265AVBR:
    {
        AX_VENC_H265_AVBR_S stH265AVbr = pstAttr->stRcAttr.stH265AVbr;

        u32BitRate = stH265AVbr.u32MaxBitRate;
        u32Gop = stH265AVbr.u32Gop;

        u32MinQp = stH265AVbr.u32MinQp;
        u32MaxQp = stH265AVbr.u32MaxQp;
        u32MinIQp = stH265AVbr.u32MinIQp;
        u32MaxIQp = stH265AVbr.u32MaxIQp;

        u32SrcFrmRate = stH265AVbr.u32SrcFrameRate;
        u32DstFrmRate = stH265AVbr.fr32DstFrameRate;

        u32BlockUnit = stH265AVbr.stQpmapInfo.u32QpmapBlockUnit;
        enCtbRcMode = stH265AVbr.stQpmapInfo.enCtbRcMode;
        enQpmapType = stH265AVbr.stQpmapInfo.enQpmapQpType;
    }
    break;

    case VENC_RC_MODE_H265CVBR:
    {
        AX_VENC_H265_CVBR_S stH265CVbr = pstAttr->stRcAttr.stH265CVbr;

        u32BitRate = stH265CVbr.u32MaxBitRate;
        u32Gop = stH265CVbr.u32Gop;

        u32MinQp = stH265CVbr.u32MinQp;
        u32MaxQp = stH265CVbr.u32MaxQp;
        u32MinIQp = stH265CVbr.u32MinIQp;
        u32MaxIQp = stH265CVbr.u32MaxIQp;

        u32SrcFrmRate = stH265CVbr.u32SrcFrameRate;
        u32DstFrmRate = stH265CVbr.fr32DstFrameRate;

        u32ShortTermStatTime = stH265CVbr.u32ShortTermStatTime;       /* RW; Range:[1, 120]; the long-term rate statistic time, the unit is second (s)*/
        u32LongTermStatTime = stH265CVbr.u32LongTermStatTime;        /* RW; Range:[1, 1440]; the long-term rate statistic time, the unit is u32LongTermStatTimeUnit*/
        u32LongTermMaxBitrate = stH265CVbr.u32LongTermMaxBitrate;     /* RW; Range:[2, 614400];the long-term target max bitrate, can not be larger than u32MaxBitRate,the unit is kbps */
        u32LongTermMinBitrate = stH265CVbr.u32LongTermMinBitrate;

        u32BlockUnit = stH265CVbr.stQpmapInfo.u32QpmapBlockUnit;
        enCtbRcMode = stH265CVbr.stQpmapInfo.enCtbRcMode;
        enQpmapType = stH265CVbr.stQpmapInfo.enQpmapQpType;

    }
    break;

    case VENC_RC_MODE_H265QPMAP:
    {
        AX_VENC_H265_QPMAP_S stH265QpMap = pstAttr->stRcAttr.stH265QpMap;

        u32BitRate = stH265QpMap.u32TargetBitRate;
        u32Gop = stH265QpMap.u32Gop;

        u32SrcFrmRate = stH265QpMap.u32SrcFrameRate;
        u32DstFrmRate = stH265QpMap.fr32DstFrameRate;

        u32BlockUnit = stH265QpMap.u32QpmapBlockUnit;
        enCtbRcMode = stH265QpMap.enCtbRcMode;
        enQpmapType = stH265QpMap.enQpmapQpType;
    }
    break;

    case VENC_RC_MODE_H265FIXQP:
    {
        AX_VENC_H265_FIXQP_S stH265FixQp = pstAttr->stRcAttr.stH265FixQp;

        u32Gop = stH265FixQp.u32Gop;

        u32IQp = stH265FixQp.u32IQp;
        u32PQp = stH265FixQp.u32PQp;
        u32BQp = stH265FixQp.u32BQp;

        u32SrcFrmRate = stH265FixQp.u32SrcFrameRate;
        u32DstFrmRate = stH265FixQp.fr32DstFrameRate;
    }
    break;

    default:
        VLOG_ERROR("VencChn %d:  invalid rc mode(%d).\n", VeChn, enRcMode);
        return AX_ERR_VENC_ILLEGAL_PARAM;
    }

    if ((VENC_RC_MODE_H265CBR == enRcMode) || (VENC_RC_MODE_H265VBR == enRcMode) || (VENC_RC_MODE_H265AVBR == enRcMode)) {
        VIDEO_QP_RANGE_CHECK(VeChn, u32MinQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MaxQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MinIQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32MaxIQp, VENC_MIN_QP, VENC_MAX_QP);

        if (u32MinQp > u32MaxQp) {
            VLOG_ERROR("VencChn %d:  u32MinQp=%u > u32MaxQp=%u.\n",
                    VeChn, u32MinQp, u32MaxQp);
		    return AX_ERR_VENC_ILLEGAL_PARAM;
        }
        if (u32MinIQp > u32MaxIQp) {
            VLOG_ERROR("VencChn %d:  u32MinIQp=%u > u32MaxIQp=%u.\n",
                    VeChn, u32MinIQp, u32MaxIQp);
		    return AX_ERR_VENC_ILLEGAL_PARAM;
        }
    }

    if ((VENC_RC_MODE_H265CBR == enRcMode) || (VENC_RC_MODE_H265VBR == enRcMode) \
        || (VENC_RC_MODE_H265QPMAP == enRcMode) || (VENC_RC_MODE_H265AVBR == enRcMode)) {
        if (enQpmapType > VENC_QPMAP_DISABLE && enQpmapType <= VENC_QPMAP_ENABLE_IPCM) {
            VIDEO_QPMAP_BLOCK_UNIT_RANGE_CHECK(VeChn, u32BlockUnit, VENC_MIN_QPMAP_BLOCK_UNIT, VENC_MAX_H265_QPMAP_BLOCK_UNIT);
            VIDEO_QPMAP_CTBRC_RANGE_CHECK(VeChn, enCtbRcMode, VENC_MIN_CTBRC_TYPE, VENC_MAX_CTBRC_TYPE);
        }
    }

    if (VENC_RC_MODE_H265FIXQP != enRcMode)
        VIDEO_BITRATE_RANGE_CHECK(VeChn, u32BitRate, VENC_MIN_BITRATE, VENC_MAX_BITRATE);

    if (VENC_RC_MODE_H265FIXQP == enRcMode) {
        VIDEO_QP_RANGE_CHECK(VeChn, u32IQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32PQp, VENC_MIN_QP, VENC_MAX_QP);
        VIDEO_QP_RANGE_CHECK(VeChn, u32BQp, VENC_MIN_QP, VENC_MAX_QP);
    }

    VIDEO_GOP_RANGE_CHECK(VeChn, u32Gop, VENC_MIN_IDR_INTERVAL, VENC_MAX_IDR_INTERVAL);
    VIDEO_FRAME_RATE_RANGE_CHECK(VeChn, u32SrcFrmRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE);
    VIDEO_FRAME_RATE_RANGE_CHECK(VeChn, u32DstFrmRate, VENC_MIN_FRAME_RATE, VENC_MAX_FRAME_RATE);

    return AX_SUCCESS;
}

AX_BOOL VencIsFrameRateCtrlDrop(AX_U32 srcFramerate, AX_U32 dstFramerate, AX_U64 u64FrameIndex)
{
    if (u64FrameIndex <= 0) {
        return AX_FALSE;
    }

    if(srcFramerate == dstFramerate) {
        return AX_FALSE;
    }

    if (dstFramerate > srcFramerate) {
        return AX_FALSE;
    }

    if(floor((double)(u64FrameIndex * dstFramerate) / (srcFramerate)) >
        floor((double)((u64FrameIndex - 1) * dstFramerate) / (srcFramerate))) {
        return AX_FALSE;
    } else {
        VLOG_DEBUG("VENC: frame index %lld, src framerate %ld, dst framerate%ld, drop it\n",
                u64FrameIndex, srcFramerate, dstFramerate);
        return AX_TRUE;
    }

    return AX_FALSE;
}

AX_BOOL VencIsFrameRateCtrlEnlarge(AX_U32 srcFramerate, AX_U32 dstFramerate, AX_U64 u64FrameIndex)
{
    if (u64FrameIndex <= 0) {
        return AX_FALSE;
    }

    if (dstFramerate <= srcFramerate) {
        return AX_FALSE;
    }

    if (((u64FrameIndex * srcFramerate) / (dstFramerate)) >
        ((u64FrameIndex - 1) * srcFramerate) / (dstFramerate)) {
        return AX_FALSE;
    } else {
        VLOG_DEBUG("VENC: frame index %lld, src framerate %ld, dst framerate%ld, duplicate it\n",
                u64FrameIndex, srcFramerate, dstFramerate);
        return AX_TRUE;
    }

    return AX_FALSE;
}

AX_U32 VencTimeDiff(struct timeval end, struct timeval start)
{
   return (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec);
}

