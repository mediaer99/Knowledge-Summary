/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#include <stdarg.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "ax_sys_log.h"
#include "ax_venc_log.h"

#define VENC_LOG_ID         AX_ID_VENC //15

static AX_LOG_TARGET_E gVencLogTarget = SYS_LOG_TARGET_SYSLOG;
static AX_LOG_LEVEL_E   gVencLogLevel = SYS_LOG_NOTICE;
static AX_CHAR const *mod_tag = "AX_VENC";

VENC_DUMP_DATA_S gVencDumpData = {VENC_DUMP_NONE, VENC_DUMP_NONE_CHN};

void VLOG(AX_U32 eLv, char *fmt, ...)
{
    va_list args;
    if (eLv <= gVencLogLevel) {
        va_start(args, fmt);
        switch (eLv) {
        case SYS_LOG_DEBUG:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_DEBUG, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_INFO:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_INFO, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_NOTICE:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_NOTICE, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_WARN:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_WARNING, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_ERROR:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_ERR, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_CRITICAL:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_CRIT, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_ALERT:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_ALERT, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_EMERGENCY:
            AX_SYS_LogOutput_Ex(gVencLogTarget, (AX_LOG_LEVEL_E)LOG_EMERG, mod_tag, VENC_LOG_ID, fmt, args);
            break;
        default:
            break;
        }
        va_end(args);
    }
}

AX_S32 VencDebugInit(AX_LOG_LEVEL_E eLogLevel,
        AX_LOG_TARGET_E eLogTarget, VENC_DUMP_DATA_TYPE_E enDumpType, VENC_DUMP_CHN_RANGE_E enChnRange)
{
    if (eLogLevel < SYS_LOG_MIN || eLogLevel > SYS_LOG_MAX) {
        VLOG(SYS_LOG_ERROR, "ENC: Invalid log level(%d).", eLogLevel);
        goto ERROR;
    }

    if (eLogTarget < SYS_LOG_TARGET_MIN || eLogTarget > SYS_LOG_TARGET_MAX) {
        VLOG(SYS_LOG_ERROR, "ENC: Invalid log Target level(%d).", eLogTarget);
        goto ERROR;
    }

    if (enDumpType < VENC_DUMP_NONE || enDumpType > VENC_DUMP_ALL) {
        VLOG(SYS_LOG_ERROR, "ENC: Invalid dump type(%d).", enDumpType);
        goto ERROR;
    }

    if (enChnRange < VENC_DUMP_NONE_CHN || enChnRange > VENC_DUMP_MAX_CHN) {
        VLOG(SYS_LOG_ERROR, "ENC: Invalid dump chn range(%d).", enChnRange);
        goto ERROR;
    }

    char *pEnv = getenv("VENC_LOG_level");
    AX_S32 s32Logv = eLogLevel;
    AX_S32 s32Targetv = eLogTarget;

    if (pEnv) {
        AX_S32 s32Lv = atoi(pEnv);
        if (s32Lv > SYS_LOG_MIN && s32Lv < SYS_LOG_MAX) {
            s32Logv = (AX_LOG_LEVEL_E)s32Lv;
        }
    }
    gVencLogLevel = s32Logv;

    pEnv = getenv("VENC_LOG_target");
    if (pEnv) {
        AX_S32 nTarget = atoi(pEnv);
        if (nTarget > SYS_LOG_TARGET_MIN && nTarget < SYS_LOG_TARGET_MAX) {
            s32Targetv = (AX_LOG_TARGET_E)nTarget;
        }
    }
    gVencLogTarget = s32Targetv;

    //dump frame/stream
    char *enable_dump = getenv("VENC_DUMP_DATA");

    if (enable_dump) {
        AX_S32 i = 0;
        i = VencDumpParse((AX_S8 *)enable_dump, ':');
        if (-1 == i) {
            VLOG(SYS_LOG_ERROR, "ENC: Invalid dump type string.\n");
            goto ERROR;
        }
        gVencDumpData.enDumpType = atoi(enable_dump);
        if (gVencDumpData.enDumpType < VENC_DUMP_NONE || gVencDumpData.enDumpType > VENC_DUMP_ALL) {
            VLOG(SYS_LOG_ERROR, "ENC: Invalid dump type(%d).\n", gVencDumpData.enDumpType);
            goto ERROR;
        }

        enable_dump += i + 1;
        gVencDumpData.s32ChnIndex = atoi(enable_dump);
        if (gVencDumpData.s32ChnIndex < VENC_DUMP_NONE_CHN || gVencDumpData.s32ChnIndex > MAX_VENC_NUM) {
            VLOG(SYS_LOG_ERROR, "ENC: Invalid dump channel id(%d).\n", gVencDumpData.s32ChnIndex);
            goto ERROR;
        }

        VLOG(SYS_LOG_ERROR, "ENC: Dump data by env(type:%d-Chn:%d).\n",
                gVencDumpData.enDumpType, gVencDumpData.s32ChnIndex);
    } else {
        gVencDumpData.enDumpType = enDumpType;
        gVencDumpData.s32ChnIndex = enChnRange;
    }
    //dump frame/stream

    VLOG(SYS_LOG_DEBUG, "ENC: LogLevel=%d, LogTarget=%d, DumpType=%d, DumpChnID=%d\n",
            eLogLevel,
            eLogTarget,
            gVencDumpData.enDumpType,
            gVencDumpData.s32ChnIndex);

    return 0;

ERROR:

    gVencLogLevel = SYS_LOG_ERROR;
    gVencLogTarget = SYS_LOG_TARGET_SYSLOG;
    gVencDumpData.enDumpType = VENC_DUMP_NONE;
    gVencDumpData.s32ChnIndex = VENC_DUMP_NONE_CHN;

    return -1;
}

AX_U64 VencGetTickCount(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

AX_S32 VencDumpDataBegin(VENC_CHN VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
	if ((VENC_DUMP_STREAM & gVencDumpData.enDumpType) && (VENC_DUMP_ALL_CHN == gVencDumpData.s32ChnIndex ||
            VeChn == gVencDumpData.s32ChnIndex)) {
		if (PT_H264 == pChnInst->enType)
			sprintf(pChnInst->pDumpStream, "/tmp/dump_chn%d.%s", VeChn, "264");
		else if (PT_H265 == pChnInst->enType)
			sprintf(pChnInst->pDumpStream, "/tmp/dump_chn%d.%s", VeChn, "265");
		else if (PT_MJPEG == pChnInst->enType)
			sprintf(pChnInst->pDumpStream, "/tmp/dump_chn%d.%s", VeChn, "mjpg");

		pChnInst->fDumpStream = fopen(pChnInst->pDumpStream, "wb");
		if (NULL == pChnInst->fDumpStream) {
			VLOG(SYS_LOG_ERROR, "ENC %d: open output stream file error.\n", VeChn);
			goto ERROR;
		}
	}

    if ((VENC_DUMP_FRAME & gVencDumpData.enDumpType) && (VENC_DUMP_ALL_CHN == gVencDumpData.s32ChnIndex ||
            VeChn == gVencDumpData.s32ChnIndex)) {
		sprintf(pChnInst->pDumpFrame, "/tmp/dump_chn%d.yuv", VeChn);

		pChnInst->fDumpFrame = fopen(pChnInst->pDumpFrame, "wb");
		if (NULL == pChnInst->fDumpFrame) {
			VLOG(SYS_LOG_ERROR, "ENC %d: open output frame file error.\n", VeChn);
			goto ERROR;
		}
    }

    return 0;


ERROR:

    if (NULL != pChnInst->fDumpFrame) {
        fclose(pChnInst->fDumpFrame);
        pChnInst->fDumpFrame = NULL;
    }

    if (NULL != pChnInst->fDumpStream) {
        fclose(pChnInst->fDumpStream);
        pChnInst->fDumpStream = NULL;
    }

    gVencDumpData.enDumpType = VENC_DUMP_NONE;
    gVencDumpData.s32ChnIndex = VENC_DUMP_NONE_CHN;

    return -1;
}

AX_VOID VencDumpDataEnd(AX_S32 VeChn, AX_VENC_CHN_INSTANCE_S *pChnInst)
{
    (void)VeChn;

    if (NULL != pChnInst->fDumpFrame) {
        fclose(pChnInst->fDumpFrame);
        pChnInst->fDumpFrame = NULL;
    }

    if (NULL != pChnInst->fDumpStream) {
        fclose(pChnInst->fDumpStream);
        pChnInst->fDumpStream = NULL;
    }
}

AX_S32 VencDumpParse(AX_S8 *optArg, AX_S8 delim)
{
    AX_S32 i;

    for (i = 0; i < (AX_S32)strlen((char *)optArg); i++) {
        if (optArg[i] == delim) {
            optArg[i] = 0;
            return i;
        }
    }

    return -1;
}

