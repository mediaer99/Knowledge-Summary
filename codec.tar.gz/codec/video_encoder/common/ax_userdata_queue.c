
#include <stdlib.h>
#include <semaphore.h>
#include "ax_userdata_queue.h"
#include "ax_base_type.h"
#include "ax_venc_log.h"

AX_S32 InitUserDataBufferQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_VENC_USERDATA_QUEUE_ATTR_S *pUserDataQueueAttr)
{
	if (!pUserDataBuffQueue)
	{
		VLOG_ERROR("VENC %d: Invalid param, pUserDataBuffQueue is null.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	for (int i = 0; i < pUserDataQueueAttr->u32UserDataBufferCount; i++)
	{
		pUserDataBuffQueue->stBufferNode[i].pBufferAddr = malloc(pUserDataQueueAttr->u32UserDataBufferSize * sizeof(AX_U8));
		if (pUserDataBuffQueue->stBufferNode[i].pBufferAddr == NULL) {
			VLOG_ERROR("VENC %d: malloc user data buffer error\n", VeChn);
			goto EXIT;
		}
		memset(pUserDataBuffQueue->stBufferNode[i].pBufferAddr, 0, pUserDataQueueAttr->u32UserDataBufferSize * sizeof(AX_U8));
	}

	pUserDataBuffQueue->front = 0;
	pUserDataBuffQueue->rear = 0;
	pUserDataBuffQueue->bufferCount = pUserDataQueueAttr->u32UserDataBufferCount;
	pUserDataBuffQueue->bufferSize = pUserDataQueueAttr->u32UserDataBufferSize;

	pthread_mutex_init(&pUserDataBuffQueue->userdata_buffer_mutex, NULL);

	return AX_SUCCESS;

EXIT:

	for (int i = 0; i < pUserDataQueueAttr->u32UserDataBufferCount; i++)
	{
		if (pUserDataBuffQueue->stBufferNode[i].pBufferAddr)
		{
			free(pUserDataBuffQueue->stBufferNode[i].pBufferAddr);
			pUserDataBuffQueue->stBufferNode[i].pBufferAddr = NULL;
		}
	}

	return AX_FAILURE;
}

AX_VOID DestroyUserDataBufferQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue)
{
	if (!pUserDataBuffQueue)
	{
		VLOG_ERROR("VENC %d: Invalid param, pUserDataBuffQueue is null.\n", VeChn);
		return;
	}

	for (int i = 0; i < pUserDataBuffQueue->bufferCount; i++)
	{
		if (pUserDataBuffQueue->stBufferNode[i].pBufferAddr != NULL)
		{
			free(pUserDataBuffQueue->stBufferNode[i].pBufferAddr);
			pUserDataBuffQueue->stBufferNode[i].pBufferAddr = NULL;
		}
	}

	pthread_mutex_destroy(&pUserDataBuffQueue->userdata_buffer_mutex);

	free(pUserDataBuffQueue->stBufferNode);
	free(pUserDataBuffQueue);
	pUserDataBuffQueue = NULL;
}

AX_S32 UserDataInsertQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_USERDATA_NODE_S *pUserDataBuffNode)
{
	if (!pUserDataBuffQueue)
	{
		VLOG_ERROR("VENC %d: Invalid param, pUserDataBuffQueue is null.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	pthread_mutex_lock(&pUserDataBuffQueue->userdata_buffer_mutex);

	// check the queue is full
	if ((pUserDataBuffQueue->rear + 1) % pUserDataBuffQueue->bufferCount == pUserDataBuffQueue->front)
	{
		if (!pUserDataBuffQueue->isFull)
		{
			VLOG_DEBUG("VENC %d: userdata buffer queue full.\n", VeChn);
			pUserDataBuffQueue->isFull = AX_TRUE;
		}
		
		pthread_mutex_unlock(&pUserDataBuffQueue->userdata_buffer_mutex);
		return AX_ERR_VENC_QUEUE_FULL;
	}

	pUserDataBuffQueue->isFull = AX_FALSE;
	memcpy(pUserDataBuffQueue->stBufferNode[pUserDataBuffQueue->rear].pBufferAddr,
		pUserDataBuffNode->pBufferAddr,
		pUserDataBuffNode->u32BufferSize);
	pUserDataBuffQueue->stBufferNode[pUserDataBuffQueue->rear].u32BufferSize = pUserDataBuffNode->u32BufferSize;

	pUserDataBuffQueue->rear = (pUserDataBuffQueue->rear + 1) % pUserDataBuffQueue->bufferCount;

	pthread_mutex_unlock(&pUserDataBuffQueue->userdata_buffer_mutex);

	return AX_SUCCESS;
}

AX_S32 UserDataPopQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_USERDATA_NODE_S *pUserDataBuffNode)
{
	if (!pUserDataBuffQueue)
	{
		VLOG_ERROR("VENC %d: Invalid param, pUserDataBuffQueue is null.\n", VeChn);
		return AX_ERR_VENC_NULL_PTR;
	}

	pthread_mutex_lock(&pUserDataBuffQueue->userdata_buffer_mutex);

	// check the queue is empty
	if (pUserDataBuffQueue->front == pUserDataBuffQueue->rear)
	{
		if (!pUserDataBuffQueue->isEmpty)
		{
			VLOG_DEBUG("VENC %d: userdata buffer queue empty.\n", VeChn);
			pUserDataBuffQueue->isEmpty = AX_TRUE;
		}
		pthread_mutex_unlock(&pUserDataBuffQueue->userdata_buffer_mutex);
		return AX_ERR_VENC_QUEUE_EMPTY;
	}

	pUserDataBuffQueue->isEmpty = AX_FALSE;
	*pUserDataBuffNode = pUserDataBuffQueue->stBufferNode[pUserDataBuffQueue->front];
	pUserDataBuffQueue->front = (pUserDataBuffQueue->front + 1) % pUserDataBuffQueue->bufferCount;

	pthread_mutex_unlock(&pUserDataBuffQueue->userdata_buffer_mutex);

	return AX_SUCCESS;
}