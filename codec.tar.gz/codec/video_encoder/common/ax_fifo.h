#ifndef  _AX_FIFO_H_
#define  _AX_FIFO_H_

#include <pthread.h>
#include <unistd.h>
#include "ax_base_type.h"
#include "ax_comm_venc.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VENC_MAX_DEBUG_FIFO_CAPACITY      (256)
#define VENC_MAX_FIFO_CAPACITY            (8)
#define VENC_DEFAULT_OUT_FIFO_DEPTH       (4)


typedef struct axOUTPUT_STREAM_INFO_S
{
	AX_BOOL  bEOF;
  AX_VENC_PACK_S stPackage;
} AX_OUTPUT_STREAM_INFO_S;

typedef struct axInput_FRAME_INFO_S
{
  AX_VIDEO_FRAME_INFO_S stFrameInfo;
}AX_INPUT_FRAME_INFO_S;

typedef struct axInput_USER_FRAME_INFO_S
{
  AX_USER_FRAME_INFO_S stUserFrameInfo;
} AX_INPUT_USER_FRAME_INFO_S;

typedef enum
{
  FRAME_NORMAL_TYPE = 0,
  FRAME_USER_TYPE,
} AX_INPUT_FRAME_TYPE_E;

typedef struct axEncoder_METADATA_INFO_S
{
  AX_INPUT_FRAME_TYPE_E       inputFrameType;
  AX_INPUT_FRAME_INFO_S       inputFrameInfo;
  AX_INPUT_USER_FRAME_INFO_S  inputUserFrameInfo;
  AX_OUTPUT_STREAM_INFO_S     outputStreamInfo;
}AX_ENCODR_METADATA_INFO_S;

/* FIFO_DATATYPE must be defined to hold specific type of objects. If it is not
 * defined, we need to report an error. */
#ifndef FIFO_DATATYPE
//#error "You must define FIFO_DATATYPE to use this module."
#endif /* FIFO_DATATYPE */

typedef AX_ENCODR_METADATA_INFO_S FifoObject;

enum FifoOperateType {
  VENC_FIFO_POP = 0,
  VENC_FIFO_PUSH = 1
};
/* Possible return values. */
typedef enum {
  FIFO_OK,             /* Operation was successful. */
  FIFO_ERROR_MEMALLOC, /* Failed due to memory allocation error. */
  FIFO_EMPTY,
  FIFO_FULL,
  FIFO_NOK,
  FIFO_ABORT = 0x7FFFFFFF
} FifoRet;

enum FifoException {
  FIFO_EXCEPTION_BLOCK=-1,
  FIFO_EXCEPTION_NONBLOCK=0,
  FIFO_EXCEPTION_TIMEWAIT=1
};

typedef void* FifoInst;

/* FifoInit initializes the queue.
 * |capacity| defines how many slots to reserve at maximum.
 * |depth| defines how many objects can be stored in FIFO.
 * |instance| is output parameter holding the instance. */
FifoRet AX_Fifo_Create(AX_S32 VeChn, AX_U32 capacity, AX_U32 depth,FifoInst* instance);

/* IsFifoFull tests if a Fifo is already full.
 *
 * |inst| is the instance (pointer)  */
FifoRet AX_IsFifoFull(AX_S32 VeChn, const FifoInst inst);

/* IsFifoFull tests if a Fifo is already empty.
 *
 * |inst| is the instance (pointer)  */
FifoRet AX_IsFifoEmpty(AX_S32 VeChn, const FifoInst inst);

/* FifoPush pushes an object to the back of the queue. Ownership of the
 * contained object will be moved from the caller to the queue. Returns OK
 * if the object is successfully pushed into fifo.
 *
 * |inst| is the instance push to.
 * |object| holds the pointer to the object to push into queue.
 * |s32MilliSec| blocking mode (s32MilliSec=-1) and nonblocking mode (s32MilliSec=0) */
FifoRet AX_Fifo_Push(AX_S32 VeChn, FifoInst inst, FifoObject object,
                      AX_S32 s32MilliSec);

/* FifoPop returns object from the front of the queue. Ownership of the popped
 * object will be moved from the queue to the caller. Returns OK if the object
 * is successfully popped from the fifo.
 *
 * |inst| is the instance to pop from.
 * |object| holds the pointer to the object popped from the queue.
 * |s32MilliSec| blocking mode (s32MilliSec=-1) and nonblocking mode (s32MilliSec=0) */
FifoRet AX_Fifo_Pop(AX_S32 VeChn, FifoInst inst, FifoObject* object,
                     AX_S32 s32MilliSec);

/* FifoPeek returns object from the front of the queue. The peeked
 * object will still remains in the fifo. Returns OK if the object
 * is successfully peeked from the fifo.
 *
 * |inst| is the instance to peek from.
 * |object| holds the pointer to the object peeked from the queue.
 * |s32MilliSec| blocking mode (s32MilliSec=-1) and nonblocking mode (s32MilliSec=0) */
FifoRet AX_Fifo_Peek(AX_S32 VeChn, FifoInst inst, FifoObject* object,
                     AX_S32 s32MilliSec);

/* Get and Release mutex to protect fifo operation. */
AX_U32 AX_Fifo_GetLock(AX_S32 VeChn, FifoInst inst) ;
AX_U32 AX_Fifo_ReleaseLock(AX_S32 VeChn, FifoInst inst) ;

/* Ask how many objects there are in the fifo. */
AX_U32 AX_Fifo_Count(AX_S32 VeChn, FifoInst inst);

/* Check if object is contained in fifo */
AX_U32 AX_Fifo_HasObject(AX_S32 VeChn, FifoInst inst, FifoObject *object);

/* FifoRelease releases and deallocated queue. User needs to make sure the
 * queue is empty and no threads are waiting in FifoPush or FifoPop.
 * |inst| is the instance to release. */
AX_S32 AX_Fifo_Destroy(AX_S32 VeChn, FifoInst inst);
void AX_Fifo_SetAbort(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType);
void AX_Fifo_ClearAbort(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType);
void AX_Fifo_WakeUp(AX_S32 VeChn, FifoInst inst, enum FifoOperateType oprType);

/* Set the fifo depth
 *
 * |inst| is the instance to the fifo.
 * |depth| depth of fifo,legal range is (0,num_of_slots]*/
void AX_Fifo_SetDepth(AX_S32 VeChn, FifoInst inst, AX_U32 depth);

#ifdef __cplusplus
}
#endif

#endif /* __FIFO_H__ */
