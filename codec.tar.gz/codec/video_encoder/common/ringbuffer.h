#ifndef _RINGBUFFER_H_
#define _RINGBUFFER_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "ax_comm_venc.h"
#include <semaphore.h>

#define MARGIN_PADDING_FOR_SMALL_RESOLUTION (64 * 1024)


typedef struct ringbuffer_s
{
	// buffer related
	AX_U64	phyaddr_buffer_start;
	AX_U8	*viraddr_buffer_start;

	AX_U64	phyaddr_buffer_end;
	AX_U8	*viraddr_buffer_end;

	AX_U32	buffer_total_size;
	AX_U32	stream_buffer_margin;
	AX_U32	stream_buffer_margin_Init;

	// buffer related
	AX_U8	*viraddr_for_write;
	AX_U64	phyaddr_for_write;
	AX_U64	phyaddr_for_write_rewind;

	AX_U8	*viraddr_for_read;
	AX_U64	phyaddr_for_read;

	AX_U64	readable_frame_num;
	pthread_mutex_t	rb_mutex;
} ringbuffer_t;

typedef struct ringbuffer_initparam_s
{
	AX_U32 buffer_size;
	AX_U32 streamBuffMargin;
	AX_PAYLOAD_TYPE_E enCodecType;
} ringbuffer_initparam_t;

ringbuffer_t* ringbuffer_create(AX_S32 VeChn, const ringbuffer_initparam_t* pstParam);

AX_S32 ringbuffer_close(AX_S32 VeChn, ringbuffer_t *pRingBuf);

AX_S32 ringbuffer_write_finalize(AX_S32 VeChn, ringbuffer_t *pRingBuf, AX_U32 packet_size);

AX_S32 ringbuffer_read_finalize(AX_S32 VeChn, ringbuffer_t *pRingBuf, AX_U32 packet_size);

AX_U32 ringbuffer_usable_size(AX_S32 VeChn, ringbuffer_t *pRingBuf);


#ifdef __cplusplus
}
#endif

#endif
