#ifndef  _AX_USERDATA_QUEUE_H_
#define  _AX_USERDATA_QUEUE_H_

#include <pthread.h>
#include <unistd.h>
#include "ax_base_type.h"
#include "ax_comm_venc.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct axUserData_Node_S
{
	AX_U32  u32BufferSize;
	AX_U8   *pBufferAddr;
} AX_USERDATA_NODE_S;

typedef struct axUserDataBufferQueue_S
{
	AX_USERDATA_NODE_S *stBufferNode;
	AX_U32 front;
	AX_U32 rear;
	AX_U32 bufferCount;
	AX_U32 bufferSize;
	AX_BOOL isEmpty;
	AX_BOOL isFull;
	pthread_mutex_t	userdata_buffer_mutex;
} AX_USERDATA_BUFFER_QUEUE_S;

AX_S32 InitUserDataBufferQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_VENC_USERDATA_QUEUE_ATTR_S *pUserDataQueueAttr);

AX_VOID DestroyUserDataBufferQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue);

AX_S32 UserDataInsertQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_USERDATA_NODE_S *pUserDataBuffNode);

AX_S32 UserDataPopQueue(AX_S32 VeChn, AX_USERDATA_BUFFER_QUEUE_S *pUserDataBuffQueue, AX_USERDATA_NODE_S *pUserDataBuffNode);

#ifdef __cplusplus
}
#endif

#endif /* _AX_USERDATA_QUEUE_H_ */
