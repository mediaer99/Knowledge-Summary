#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ringbuffer.h"
#include <sys/time.h>
#include "ax_sys_api.h"
#include <unistd.h>

#include "ax_venc_log.h"
#include "ax_video_enc_init.h"

#define SYSANONYMOUS "anonymous"

ringbuffer_t* ringbuffer_create(AX_S32 VeChn, const ringbuffer_initparam_t* pstParam)
{
	if (NULL == pstParam) {
		VLOG_ERROR("VencChn %d: Invalid pstParam.\n", VeChn);
		return NULL;
	}

	AX_U64 u64PhyAddr = 0;
	void *pVirAddr = NULL;
	AX_S32 s32Ret = -1;
	ringbuffer_t *pRingbbuf = NULL;
	AX_S8 partitionName[50];
	AX_S8  memName[100];
	AX_U32 streamBuffSize = pstParam->buffer_size;

	if (streamBuffSize < pstParam->streamBuffMargin) {
		VLOG_ERROR("VencChn %d: stream buffer(%u) less than buff margin(%u).\n",
					VeChn,
					streamBuffSize,
					pstParam->streamBuffMargin);
		return NULL;
	}

	AX_MOD_INFO_S vencMod;
	if (PT_H264 == pstParam->enCodecType || PT_H265 == pstParam->enCodecType) {
		vencMod.enModId  = AX_ID_VENC;
		vencMod.s32GrpId = 0;
		vencMod.s32ChnId = VeChn;
	} else if (PT_JPEG == pstParam->enCodecType || PT_MJPEG == pstParam->enCodecType) {
		vencMod.enModId  = AX_ID_JENC;
		vencMod.s32GrpId = 0;
		vencMod.s32ChnId = VeChn;
	}

	s32Ret = AX_SYS_MemGetConfig(&vencMod, partitionName);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d:  AX_SYS_MemGetConfig error.\n", VeChn);
		goto EXIT;
	}

	VLOG_DEBUG("VencChn %d: partitionName=%s.\n", VeChn, partitionName);

	if (0 == strcmp((char *)partitionName, SYSANONYMOUS)) {
		sprintf((char *)memName, "venc_fifo_%d", VeChn);
	} else {
		sprintf((char *)memName, "%s:venc_fifo_%d", partitionName, VeChn);
	}

	VLOG_DEBUG("VencChn %d: memName=%s.\n", VeChn, memName);

	s32Ret = AX_SYS_MemAlloc(&u64PhyAddr, &pVirAddr, streamBuffSize, 0, memName);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: AX_SYS_MemAlloc error.\n", VeChn);
		goto EXIT;
	}

	VLOG(SYS_LOG_DEBUG, "VENC %d, ringbuffer vir_addr %p, phy_addr %llx.\n",
		VeChn,
		pVirAddr,
		u64PhyAddr);

	VLOG(SYS_LOG_DEBUG, "virAddr=%p, phyAddr=%lx,  size=%d.\n", pVirAddr, u64PhyAddr,  streamBuffSize);

	pRingbbuf = (ringbuffer_t *)calloc(1, sizeof(ringbuffer_t));
	if (NULL == pRingbbuf) {
		VLOG_ERROR("VencChn %d: alloc fifo error.\n", VeChn);
		goto EXIT;
	}

	pRingbbuf->phyaddr_buffer_start = u64PhyAddr - VENC_ADDR_OFFSET;
	pRingbbuf->phyaddr_buffer_end = pRingbbuf->phyaddr_buffer_start + streamBuffSize;

	pRingbbuf->viraddr_buffer_start = pVirAddr;
	pRingbbuf->viraddr_buffer_end = pRingbbuf->viraddr_buffer_start + streamBuffSize;

	pRingbbuf->viraddr_for_write = pRingbbuf->viraddr_buffer_start;
	pRingbbuf->phyaddr_for_write = pRingbbuf->phyaddr_buffer_start;

	pRingbbuf->viraddr_for_read = pRingbbuf->viraddr_buffer_start;
	pRingbbuf->phyaddr_for_read = pRingbbuf->phyaddr_buffer_start;

	pRingbbuf->buffer_total_size = streamBuffSize;

	pRingbbuf->stream_buffer_margin = pstParam->streamBuffMargin;
	/* only backup the value of streamBuffMargin when create ringbuffer, should not be changed later */
	pRingbbuf->stream_buffer_margin_Init = pstParam->streamBuffMargin;

	pRingbbuf->readable_frame_num = 0;

	pRingbbuf->phyaddr_for_write_rewind = 0;

	pthread_mutex_init(&pRingbbuf->rb_mutex, NULL);

	VLOG_DEBUG("VencChn %d: buffer_phyaddr_start=%llx, buffer_viraddr_start=%p, totalSize=%d, bufferMargin=%d.\n",
			VeChn,
			pRingbbuf->phyaddr_buffer_start,
			pRingbbuf->viraddr_buffer_start,
			pRingbbuf->buffer_total_size,
			pRingbbuf->stream_buffer_margin
			);

	return pRingbbuf;

EXIT:

	if (NULL != pRingbbuf) {
		VLOG_ERROR("VencChn %d: free fifo.\n", VeChn);
		free(pRingbbuf);
		pRingbbuf = NULL;
	}

	if (0 != u64PhyAddr && NULL != pVirAddr) {
		s32Ret = AX_SYS_MemFree(u64PhyAddr, pVirAddr);
		if (0 != s32Ret) {
			VLOG_ERROR("VencChn %d: AX_SYS_MemFree error.\n", VeChn);
		}
	}

	return NULL;
}

AX_S32 ringbuffer_close(AX_S32 VeChn, ringbuffer_t *pRingbbuf)
{
	AX_S32 s32Ret = -1;

	if (NULL == pRingbbuf) {
		VLOG_ERROR("VencChn %d: fifo is null.\n", VeChn);
		return -1;
	}

	pthread_mutex_destroy(&pRingbbuf->rb_mutex);

	s32Ret = AX_SYS_MemFree(pRingbbuf->phyaddr_buffer_start + VENC_ADDR_OFFSET, pRingbbuf->viraddr_buffer_start);
	if (0 != s32Ret) {
		VLOG_ERROR("VencChn %d: AX_SYS_MemFree error.\n", VeChn);
		return -1;
	}

	if (NULL != pRingbbuf) {
		free(pRingbbuf);
		pRingbbuf = NULL;
	}

	return 0;
}

AX_S32 ringbuffer_read_finalize(AX_S32 VeChn, ringbuffer_t *pRingBuf, AX_U32 packet_size)
{
	if (NULL == pRingBuf) {
		VLOG_ERROR("VencChn %d: fifo is null.\n", VeChn);
		return -1;
	}

	pthread_mutex_lock(&pRingBuf->rb_mutex);

	VLOG_DEBUG("VencChn %d: read: viraddr=%p, phyaddr=%llx, VirBufferEnd=%p, packet_size=%u ++ \n",
			VeChn,
			pRingBuf->viraddr_for_read,
			pRingBuf->phyaddr_for_read,
			pRingBuf->viraddr_buffer_end,
			packet_size);

	/* shall check rewind point before updating readPtr,and do rewind if rewind point is hit */
	if (pRingBuf->phyaddr_for_read == pRingBuf->phyaddr_for_write_rewind) {
		VLOG_DEBUG("VencChn %d: read rewind: viraddr=%p, phyaddr=%llx.\n",
				VeChn, pRingBuf->viraddr_for_read, pRingBuf->phyaddr_for_read);

			pRingBuf->viraddr_for_read = pRingBuf->viraddr_buffer_start;
			pRingBuf->phyaddr_for_read = pRingBuf->phyaddr_buffer_start;
			pRingBuf->phyaddr_for_write_rewind = 0;
	}

	if (pRingBuf->readable_frame_num <= 0) {
		VLOG_ERROR("VencChn %d: readable frame num is 0.\n", VeChn);
		pthread_mutex_unlock(&pRingBuf->rb_mutex);
		return -1;
	}

	if (packet_size == 0) {
		VLOG_WARNING("VencChn %d: packet size is 0.\n", VeChn, packet_size);
		pthread_mutex_unlock(&pRingBuf->rb_mutex);
		return -1;
	}

	/* shall never happend */
	if((pRingBuf->phyaddr_for_read + packet_size) > pRingBuf->phyaddr_buffer_end){
		VLOG_ERROR("VencChn %d: ringbuf exceed!shall never happend!phyaddr_for_write=0x%llx,phyaddr_for_read=0x%llx, phyaddr_buffer_end=0x%llx,packet_size=%u.\n",
			VeChn,
			pRingBuf->phyaddr_for_write,
			pRingBuf->phyaddr_for_read,
			pRingBuf->phyaddr_buffer_end,
			packet_size);
		pthread_mutex_unlock(&pRingBuf->rb_mutex);
		return -1;
	}

	/* update the readPtr */
	pRingBuf->viraddr_for_read += packet_size;
	pRingBuf->phyaddr_for_read += packet_size;
	pRingBuf->readable_frame_num--;

	/* check rewind again after updating readPtr,and shall do rewind right now if rewind point is hit */
	if (pRingBuf->phyaddr_for_read == pRingBuf->phyaddr_for_write_rewind) {
		VLOG_DEBUG("VencChn %d: read rewind right now: viraddr=%p, phyaddr=%llx.\n",
				VeChn, pRingBuf->viraddr_for_read, pRingBuf->phyaddr_for_read);

			pRingBuf->viraddr_for_read = pRingBuf->viraddr_buffer_start;
			pRingBuf->phyaddr_for_read = pRingBuf->phyaddr_buffer_start;
			pRingBuf->phyaddr_for_write_rewind = 0;
	}

	VLOG_DEBUG("VencChn %d: read: viraddr=%p, phyaddr=%llx, VirBufferEnd=%p, PhyBufferEnd=0x%llx, rewind=0x%llx, packet_size=%u -- \n",
			VeChn,
			pRingBuf->viraddr_for_read,
			pRingBuf->phyaddr_for_read,
			pRingBuf->viraddr_buffer_end,
			pRingBuf->phyaddr_buffer_end,
			pRingBuf->phyaddr_for_write_rewind,
			packet_size);

	pthread_mutex_unlock(&pRingBuf->rb_mutex);

	return 0;
}

AX_S32 ringbuffer_write_finalize(AX_S32 VeChn, ringbuffer_t *pRingBuf, AX_U32 packet_size)
{
	if (NULL == pRingBuf) {
		VLOG_ERROR("VencChn %d: fifo is null.\n", VeChn);
		return -1;
	}

	if (packet_size == 0) {
		VLOG_WARNING("VencChn %d: packet size is 0.\n", VeChn, packet_size);
		return -1;
	}

	pthread_mutex_lock(&pRingBuf->rb_mutex);

	VLOG_DEBUG("VencChn %d: write: viraddr=%p, phyaddr=%llx, VirBufferEnd=%p, packet_size=%u ++ \n",
			VeChn,
			pRingBuf->viraddr_for_write,
			pRingBuf->phyaddr_for_write,
			pRingBuf->viraddr_buffer_end,
			packet_size);

	pRingBuf->viraddr_for_write += packet_size;
	pRingBuf->phyaddr_for_write += packet_size;

	pRingBuf->readable_frame_num++;

#if 0
	if ((pRingBuf->viraddr_for_write + pRingBuf->stream_buffer_margin) >= (pRingBuf->viraddr_buffer_end)) {
		VLOG_DEBUG("VencChn %d: write rewind: viraddr_for_next_write=%p, next_write+margin=%p, end_addr=%p .\n",
				VeChn,
				pRingBuf->viraddr_for_write,
				pRingBuf->viraddr_for_write + pRingBuf->stream_buffer_margin,
				pRingBuf->viraddr_buffer_end);

			pRingBuf->phyaddr_for_write_rewind = pRingBuf->phyaddr_for_write;

			pRingBuf->viraddr_for_write = pRingBuf->viraddr_buffer_start;
			pRingBuf->phyaddr_for_write = pRingBuf->phyaddr_buffer_start;
	}
#endif
	VLOG_DEBUG("VencChn %d: write: viraddr=%p, phyaddr=%llx, VirBufferEnd=%p, rewind=0x%llx, packet_size=%u -- \n",
			VeChn,
			pRingBuf->viraddr_for_write,
			pRingBuf->phyaddr_for_write,
			pRingBuf->viraddr_buffer_end,
			pRingBuf->phyaddr_for_write_rewind,
			packet_size);

	pthread_mutex_unlock(&pRingBuf->rb_mutex);

	return 0;
}

AX_U32 ringbuffer_usable_size(AX_S32 VeChn, ringbuffer_t *pRingBuf)
{
	if (NULL == pRingBuf) {
		VLOG_ERROR("VencChn %d: fifo is null.\n", VeChn);
		return -1;
	}

	AX_U32 usable_buffer_size = 0;

	pthread_mutex_lock(&pRingBuf->rb_mutex);

	if ((pRingBuf->viraddr_for_write + pRingBuf->stream_buffer_margin) >= (pRingBuf->viraddr_buffer_end)) {

		if(pRingBuf->phyaddr_for_write_rewind != 0){
			VLOG_WARNING("VencChn %d: The readPtr has not rewinded yet,shall return!startPtr=0x%llx, endPtr=0x%llx, writePtr=0x%llx, readPtr=0x%llx, rewindPtr=0x%llx,margin=%d.\n",
					VeChn,
					pRingBuf->phyaddr_buffer_start,
					pRingBuf->phyaddr_buffer_end,
					pRingBuf->phyaddr_for_write,
					pRingBuf->phyaddr_for_read,
					pRingBuf->phyaddr_for_write_rewind,
					pRingBuf->stream_buffer_margin);
			pthread_mutex_unlock(&pRingBuf->rb_mutex);
			return 0;
		}
		VLOG_DEBUG("VencChn %d: usable size: viraddr_for_next_write=%p, next_write+margin=%p, end_addr=%p .\n",
				VeChn,
				pRingBuf->viraddr_for_write,
				pRingBuf->viraddr_for_write + pRingBuf->stream_buffer_margin,
				pRingBuf->viraddr_buffer_end);
		pRingBuf->phyaddr_for_write_rewind = pRingBuf->phyaddr_for_write;
		VLOG_INFO("VencChn %d: phyaddr_for_write_rewind=0x%llx\n", VeChn, pRingBuf->phyaddr_for_write_rewind);

		pRingBuf->viraddr_for_write = pRingBuf->viraddr_buffer_start;
		pRingBuf->phyaddr_for_write = pRingBuf->phyaddr_buffer_start;
	} // To do: optimize ringbuffer

	//how to get the right output buffer size ?
	if (pRingBuf->phyaddr_for_read > pRingBuf->phyaddr_for_write) {
		if (pRingBuf->phyaddr_for_read == pRingBuf->phyaddr_for_write_rewind)
			usable_buffer_size = pRingBuf->phyaddr_buffer_end - pRingBuf->phyaddr_for_write;
		else
			usable_buffer_size = pRingBuf->phyaddr_for_read - pRingBuf->phyaddr_for_write;
		
		VLOG_DEBUG("VencChn %d: read > write, usable_buffer_size=%u.\n",
				VeChn,
				usable_buffer_size);
	} else {
		usable_buffer_size = pRingBuf->phyaddr_buffer_end - pRingBuf->phyaddr_for_write;

		if (pRingBuf->phyaddr_for_read == pRingBuf->phyaddr_for_write)
			if (pRingBuf->readable_frame_num > 0)
				usable_buffer_size = 0;

		VLOG_DEBUG("VencChn %d: write >= read, usable_buffer_size=%u.\n",
				VeChn,
				usable_buffer_size);
	}

	VLOG_DEBUG("VencChn %d: usable_buffer_size = %d.\n", VeChn, usable_buffer_size);

	pthread_mutex_unlock(&pRingBuf->rb_mutex);

	return usable_buffer_size;
}

