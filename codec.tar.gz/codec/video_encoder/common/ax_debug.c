
#include <stdlib.h>
#include <semaphore.h>
#include <stdarg.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>

#include "ax_base_type.h"

#include "encpreprocess.h"
#include "encasiccontroller.h"
#include "enccommon.h"
#include "ewl.h"

#include "ax_sys_log.h"
#include "ax_venc_log.h"

#include <time.h>

#ifdef __linux
#include <sys/syscall.h>
#endif

#define gettid() syscall(__NR_gettid)

#define DEBUG_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_debug.c %s %d "str"\n", \
            gettid(), __func__, __LINE__, ##arg); \
    }while(0)

#define DEBUG_ERR_LOG(str, arg...)        do{ \
        printf(" tid:%ld ax_debug.c %s %d Error! "str"\n", \
            gettid(), __func__, __LINE__, ##arg); \
    }while(0)


#define WRITE_LOG(str, arg...)    \
    do {    \
        fprintf(fAsic, str"\n", ##arg); \
    } while(0)

static FILE *fAsic = NULL;

static int __EncPrint(const char *str_flag, const void *pPara)
{
    const EWLHwConfig_t *pT = (EWLHwConfig_t *)pPara;

    if (str_flag == NULL) {
        fprintf(fAsic, "%s begin!\n", __func__);
    } else {
        fprintf(fAsic, "%s __EncPrint begin!\n", str_flag);
    }
    // DEBUG_LOG(" ");

    WRITE_LOG("pT->h264Enabled:0x%x", pT->h264Enabled);         /**< swreg80[31] HW supports H264.<br>      0: not supported,   1: supported */
    WRITE_LOG("pT->scalingEnabled:0x%x", pT->scalingEnabled);       /**< swreg80[30] HW supports Down-scaling.<br>     0: not supported;   1: supported */
    WRITE_LOG("pT->bFrameEnabled:0x%x", pT->bFrameEnabled);       /**< swreg80[29] HW supports B-frame.<br>   0: not supported;   1: supported */
    WRITE_LOG("pT->rgbEnabled:0x%x", pT->rgbEnabled);          /**< swreg80[28] HW supports RGB input */
    WRITE_LOG("pT->hevcEnabled:0x%x", pT->hevcEnabled);         /**< bit 27 */ /**< HW supports HEVC */
    WRITE_LOG("pT->vp9Enabled:0x%x", pT->vp9Enabled);          /**<bit 26 */ /**< HW supports VP9 */
    WRITE_LOG("pT->deNoiseEnabled:0x%x", pT->deNoiseEnabled);          /**<bit 25 */ /**< HW supports DeNoise */
    WRITE_LOG("pT->main10Enabled:0x%x", pT->main10Enabled);          /**<bit 24 */ /**< HW supports Main10 */
    WRITE_LOG("pT->busType:0x%x", pT->busType);          /**<bit 23:21 */ /**< HW bus type in use  1=AHB. 2=OCP. 3=AXI. 4=PCI. 5=AXIAHB. 6=AXIAPB.*/
    WRITE_LOG("pT->cavlcEnable:0x%x", pT->cavlcEnable);     /**<bit 20 */ /**< HW support H264 CAVLC */
    WRITE_LOG("pT->lineBufEnable:0x%x", pT->lineBufEnable);     /**<bit 19 */ /**< HW support line buffer input mode */
    WRITE_LOG("pT->progRdoEnable:0x%x", pT->progRdoEnable);     /**<bit 18 */ /**< HW support prog rdo for HEVC */
    WRITE_LOG("pT->rfcEnable:0x%x", pT->rfcEnable);             /**<bit 17 */ /**< HW support reference frame compression */
    WRITE_LOG("pT->tu32Enable:0x%x", pT->tu32Enable);          /**<bit 16 */ /**< HW support TU32 transform for HEVC */
    WRITE_LOG("pT->jpegEnabled:0x%x", pT->jpegEnabled);         /**< bit 15   */ /**< HW support jpeg encoder */
    WRITE_LOG("pT->busWidth:0x%x", pT->busWidth);               /**<bit 14:13 */ /**< bus width  */
    WRITE_LOG("pT->maxEncodedWidthHEVC:0x%x", pT->maxEncodedWidthHEVC);     /**<bit 12:0 */ /**< Maximum supported width for video encoding (HEVC mode on V62 and later) */
    WRITE_LOG("pT->ljpegSupport:0x%x", pT->ljpegSupport);            /**<bit 31 */ /**< HW supports Loss JPEG or not */
    WRITE_LOG("pT->roiAbsQpSupport:0x%x", pT->roiAbsQpSupport);     /**<bit 30 */ /**< HW supports ROI Absolute QP or not */
    WRITE_LOG("pT->intraTU32Enable:0x%x", pT->intraTU32Enable);      /**<bit 29 */ /**< HW supports IntraTU32 or not */
    WRITE_LOG("pT->roiMapVersion:0x%x", pT->roiMapVersion);        /**<bit 28:26 */ /**< roi map buffer format version */
    WRITE_LOG("pT->maxEncodedWidthH264:0x%x", pT->maxEncodedWidthH264);     /**<bit 25:13 */ /**< Maximum supported width for video encoding (H264 mode) */
    WRITE_LOG("pT->maxEncodedWidthJPEG:0x%x", pT->maxEncodedWidthJPEG);     /**<bit 12:0 */ /**< Maximum supported width for video encoding (JPEG mode) */
    WRITE_LOG("pT->ssimSupport:0x%x", pT->ssimSupport);            /**<bit 31 */ /**< HW supports SSIM calculation or not */
    WRITE_LOG("pT->P010RefSupport:0x%x", pT->P010RefSupport);            /**<bit 30 */ /**< HW supports P010 tile-raster format for reference frame buffer or not */
    WRITE_LOG("pT->cuInforVersion:0x%x", pT->cuInforVersion);         /**<bit 29:27*/ /**< Version of the output CU information format. */
    WRITE_LOG("pT->meVertSearchRangeHEVC:0x%x", pT->meVertSearchRangeHEVC);      /**<bit 26:21*/ /**<ME vertical search range in 8 pixel unit for HEVC*/
    WRITE_LOG("pT->meVertSearchRangeH264:0x%x", pT->meVertSearchRangeH264);       /**<bit 20:15*/ /**<ME vertical search range in 8 pixel unit for H264*/
    WRITE_LOG("pT->ctbRcVersion:0x%x", pT->ctbRcVersion);              /**<bit 14:12 */ /**< CTB RC Version */
    WRITE_LOG("pT->jpeg422Support:0x%x", pT->jpeg422Support);            /**<bit 11 */ /**< HW supports JPEG422 coding or not */
    WRITE_LOG("pT->gmvSupport:0x%x", pT->gmvSupport);                /**<bit 10*/ /**<Global MV supported by HW. 0=not supported. 1=supported*/
    WRITE_LOG("pT->ROI8Support:0x%x", pT->ROI8Support);               /**<bit 9 */ /**<8 ROIs supported by HW. 0=not supported. 1=supported*/
    WRITE_LOG("pT->meHorSearchRangeBframe:0x%x", pT->meHorSearchRangeBframe);    /**< bit 8:7 */ /**< ME4N horizontal search range in 64 pixel unit for BFrame (0: 64 pixel)*/
    WRITE_LOG("pT->RDOQSupportHEVC:0x%x", pT->RDOQSupportHEVC);           /**< bit 6 */ /**< HW support HEVC RDOQ or not */
    WRITE_LOG("pT->bMultiPassSupport:0x%x", pT->bMultiPassSupport);         /**< bit 5 */ /**< HW support multipass: 0=not supported. 1=supoorted.*/
    WRITE_LOG("pT->inLoopDSRatio:0x%x", pT->inLoopDSRatio);             /**< bit 4*/  /**< HW support in-loop down scale: 0=1:1, 1=1:2.*/
    WRITE_LOG("pT->streamBufferChain:0x%x", pT->streamBufferChain);         /**< bit 3 */ /**< Stream Buffer Chain supported by HW. 0=not supported. 1=supported */
    WRITE_LOG("pT->streamMultiSegment:0x%x", pT->streamMultiSegment);        /**< bit 2 */ /**< Stream multi-segment supported by HW. 0=not supported. 1=supported */
    WRITE_LOG("pT->IframeOnly:0x%x", pT->IframeOnly);      /**< bit 1 */ /**< Only I frame supported by HW. 0=I/P/B supported. 1=I only supported */
    WRITE_LOG("pT->dynamicMaxTuSize:0x%x", pT->dynamicMaxTuSize);             /**< bit 0 */ /**< Dynamic max TU size change per frame supported by HW. 0=not supported. 1=supported */
    WRITE_LOG("pT->videoHeightExt:0x%x", pT->videoHeightExt);        /**< bit 31*/ /**< Maximum allowed video height extended from 8192 to 8640. 0=Not. 1=Yes. */
    WRITE_LOG("pT->cscExtendSupport:0x%x", pT->cscExtendSupport);      /**< bit 30*/ /**< RGB to YUV conversion extension. 0=not supported. 1=supported */
    WRITE_LOG("pT->scaled420Support:0x%x", pT->scaled420Support);      /**< bit 29*/ /**< out-loop scaler output YUV420SP. 0=not supported. 1=supported */
    WRITE_LOG("pT->cuTreeSupport:0x%x", pT->cuTreeSupport);         /**< bit 28*/ /**< Support of CuTree Lookahead */
    WRITE_LOG("pT->maxAXIAlignment:0x%x", pT->maxAXIAlignment);     /**< bit 27:24 */ /**< Maximum DDR alignment supported by HW */
    WRITE_LOG("pT->meVertRangeProgramable:0x%x", pT->meVertRangeProgramable);      /**<bit 22*/ /**<Programable ME vertical search range.  0=not supported. 1=supported*/
    WRITE_LOG("pT->MonoChromeSupport:0x%x", pT->MonoChromeSupport);     /**< bit21 */ /**< monochrome supported by HW. 0=not supported. 1=supported */
    WRITE_LOG("pT->ExtSramSupport:0x%x", pT->ExtSramSupport);     /**< bit20 */ /**< external SRAM supported by HW. 0=not supported. 1=supported */
    WRITE_LOG("pT->vsSupport:0x%x", pT->vsSupport);          /**< bit19 */ /**< HW supports video stabilization. 0=not supported. 1=supported */
    WRITE_LOG("pT->RDOQSupportH264:0x%x", pT->RDOQSupportH264);       /**< bit 18 */ /**< HW support H264 RDOQ or not */
    WRITE_LOG("pT->disableRecWtSupport:0x%x", pT->disableRecWtSupport);      /**< bit 17 */ /**< HW supports disable to write recon to DDR. 0=not supported. 1=supported */
    WRITE_LOG("pT->OSDSupport:0x%x", pT->OSDSupport);            /**< bit 16 */ /**< HW support OSD or not */
    WRITE_LOG("pT->H264NalRefIdc2bit:0x%x", pT->H264NalRefIdc2bit);     /**< bit 15 */ /**< HW support H264 2bitNalRefIdc or not */
    WRITE_LOG("pT->dynamicRdoSupport:0x%x", pT->dynamicRdoSupport);     /**< bit 14 */ /**< HW support HEVC/AV1 Dynamic RDO or not. 0=not supported. 1=supported */
    WRITE_LOG("pT->av1Enabled:0x%x", pT->av1Enabled);     /**< bits13 */ /**< HW support AV1 encoding or not. 0=not supported. 1=supported */
    WRITE_LOG("pT->maxEncodedWidthAV1:0x%x", pT->maxEncodedWidthAV1);     /**< bits 12:00 */ /**< Maximum video width supported by HW for AV1 (in 8x8 blocks) */
    WRITE_LOG("pT->AXIAlignFuse:0x%x", pT->AXIAlignFuse);
    WRITE_LOG("pT->RDOQSupportAV1:0x%x", pT->RDOQSupportAV1);     /**< bit 31 */ /**< HW support AV1 RDOQ or not. 0=not supported. 1=supported */
    WRITE_LOG("pT->av1InterpFilterSwitchable:0x%x", pT->av1InterpFilterSwitchable);     /**< bit 30 */ /**< HW support AV1 interp filter switchable or not. 0=not supported. 1=supported */
    WRITE_LOG("pT->JpegRoiMapSupport:0x%x", pT->JpegRoiMapSupport);     /**< bit 29 */ /**< HW support Jpeg Roi Map or not*/
    WRITE_LOG("pT->backgroundDetSupport:0x%x", pT->backgroundDetSupport);     /**< bit 28 */ /**< HW support background detection Map or not*/
    WRITE_LOG("pT->RDOQSupportVP9:0x%x", pT->RDOQSupportVP9);     /**< bit 27 */ /**< HW support VP9 RDOQ or not. 0=not supported. 1=supported */
    WRITE_LOG("pT->CtbBitsOutSupport:0x%x", pT->CtbBitsOutSupport);     /**< bit 26 */ /**< HW support output encoded bits for each ctb. 0=not supported. 1=supported */
    WRITE_LOG("pT->encVisualTuneSupport:0x%x", pT->encVisualTuneSupport);     /**< bit 25 */ /**< HW support visual tune. 0=not supported. 1=supported */
    WRITE_LOG("pT->encPsyTuneSupport:0x%x", pT->encPsyTuneSupport);     /**< bit 24 */ /**< HW support psy tune. 0=not supported. 1=supported */
    WRITE_LOG("pT->NonRotationSupport:0x%x", pT->NonRotationSupport);     /**< bit 23 */ /**< HW not suport rotation. 0=supported. 1= not supported */
    WRITE_LOG("pT->NVFormatOnlySupport:0x%x", pT->NVFormatOnlySupport);     /**< bit 22 */ /**< HW only support nv input format. 0=support all input format. 1=only support nv input format */
    WRITE_LOG("pT->MosaicSupport:0x%x", pT->MosaicSupport);         /**< bit 21 */ /**< HW mosaic feature support. 0=not supported. 1=supported */
    WRITE_LOG("pT->IPCM8Support:0x%x", pT->IPCM8Support);          /**< bit 20 */ /**<8 IPCMs supported by HW. 0=not supported. 1=supported*/
    WRITE_LOG("pT->psnrSupport:0x%x", pT->psnrSupport);           /**< bit 18 */ /**<H264/H265 PSNR supported by HW. 0=not supported. 1=supported*/
    WRITE_LOG("pT->prpSbiSupport:0x%x", pT->prpSbiSupport);         /**< bit 17 */ /**<prp sbi supported by HW. 0=not supported. 1=supported*/

    if (str_flag == NULL) {
        fprintf(fAsic, "%s end!\n", __func__);
    } else {
        fprintf(fAsic, "%s __EncPrint end!\n", str_flag);
    }

    return 0;
}

static int print_enable = 1;
int AX_EncAsicPrint(const char *str_flag, const asicData_s *asic, u32 flag)
{
    int i = 0;
    if (asic == NULL) {
        DEBUG_ERR_LOG(" asic == NULL");
        return -1;
    }

    if (flag & ASIC_STATUS_HW_TIMEOUT) {
        if (print_enable > 3) {
            if (print_enable < 5) {
                print_enable++;
                DEBUG_ERR_LOG(" print_enable:%d ", print_enable);
            }
            return 0;
        }
        print_enable++;
    } else if (flag & ASIC_STATUS_FRAME_READY) {
        if (print_enable > 3) {
            if (print_enable < 5) {
                print_enable++;
                DEBUG_ERR_LOG(" print_enable:%d ", print_enable);
            }
            return 0;
        }
        print_enable++;
    } else {
        DEBUG_ERR_LOG(" flag:0x%x ", flag);
        print_enable = 0;
        return 0;
    }

    const regValues_s *regs = &asic->regs;
    time_t time_s = time(NULL);
    char sFilePath[100] = {0};

    if (fAsic == NULL) {
        sprintf(sFilePath, "__EncAsicPrint__%ld.txt", time_s);
        fAsic = fopen(sFilePath, "w");
        if (fAsic == NULL) {
          DEBUG_ERR_LOG("fAsic == NULL fopen(sFilePath:%s failed!", sFilePath);
          return -1;
        }
    }

    if (str_flag == NULL) {
        fprintf(fAsic, "%s begin!\n", __func__);
    } else {
        fprintf(fAsic, "%s begin!\n", str_flag);
    }

    WRITE_LOG("regs->irqDisable:0x%x", regs->irqDisable);
    WRITE_LOG("regs->inputReadChunk:0x%x", regs->inputReadChunk);
    WRITE_LOG("regs->asic_axi_readID:0x%x", regs->asic_axi_readID);
    WRITE_LOG("regs->asic_axi_writeID:0x%x", regs->asic_axi_writeID);
    WRITE_LOG("regs->asic_stream_swap:0x%x", regs->asic_stream_swap);
    WRITE_LOG("regs->asic_pic_swap:0x%x", regs->asic_pic_swap);
    WRITE_LOG("regs->asic_roi_map_qp_delta_swap:0x%x", regs->asic_roi_map_qp_delta_swap);
    WRITE_LOG("regs->asic_ctb_rc_mem_out_swap:0x%x", regs->asic_ctb_rc_mem_out_swap);
    WRITE_LOG("regs->asic_burst_length:0x%x", regs->asic_burst_length);
    WRITE_LOG("regs->asic_burst_scmd_disable:0x%x", regs->asic_burst_scmd_disable);
    WRITE_LOG("regs->asic_burst_incr:0x%x", regs->asic_burst_incr);
    WRITE_LOG("regs->asic_data_discard:0x%x", regs->asic_data_discard);
    WRITE_LOG("regs->asic_clock_gating_encoder:0x%x", regs->asic_clock_gating_encoder);
    WRITE_LOG("regs->asic_clock_gating_encoder_h265:0x%x", regs->asic_clock_gating_encoder_h265);
    WRITE_LOG("regs->asic_clock_gating_encoder_h264:0x%x", regs->asic_clock_gating_encoder_h264);
    WRITE_LOG("regs->asic_clock_gating_inter:0x%x", regs->asic_clock_gating_inter);
    WRITE_LOG("regs->asic_clock_gating_inter_h265:0x%x", regs->asic_clock_gating_inter_h265);
    WRITE_LOG("regs->asic_clock_gating_inter_h264:0x%x", regs->asic_clock_gating_inter_h264);
    WRITE_LOG("regs->asic_axi_dual_channel:0x%x", regs->asic_axi_dual_channel);
    WRITE_LOG("regs->asic_cu_info_mem_out_swap:0x%x", regs->asic_cu_info_mem_out_swap);
    WRITE_LOG("regs->enc_mode:0x%x", regs->enc_mode);
    WRITE_LOG("regs->nal_unit_type:0x%x", regs->nal_unit_type);
    WRITE_LOG("regs->nuh_temporal_id:0x%x", regs->nuh_temporal_id);
    WRITE_LOG("regs->prefixnal_svc_ext:0x%x", regs->prefixnal_svc_ext);
    WRITE_LOG("regs->codingType:0x%x", regs->codingType);
    WRITE_LOG("regs->sliceSize:0x%x", regs->sliceSize);
    WRITE_LOG("regs->sliceNum:0x%x", regs->sliceNum);

    for (i = 0; i < MAX_STRM_BUF_NUM; i++) {
        WRITE_LOG("regs->outputStrmBase[%d]:0x%x", i, regs->outputStrmBase[i]);
    }

    WRITE_LOG("regs->Av1PreoutputStrmBase:0x%x", regs->Av1PreoutputStrmBase);

    for (i = 0; i < MAX_STRM_BUF_NUM; i++) {
        WRITE_LOG("regs->outputStrmSize[%d]:0x%x", i, regs->outputStrmSize[i]);
    }

    WRITE_LOG("regs->Av1PreBufferSize:0x%x", regs->Av1PreBufferSize);
    WRITE_LOG("regs->frameCodingType:0x%x", regs->frameCodingType);
    WRITE_LOG("regs->poc:0x%x", regs->poc);
    WRITE_LOG("regs->inputLumBase:0x%x", regs->inputLumBase);
    WRITE_LOG("regs->inputCbBase:0x%x", regs->inputCbBase);
    WRITE_LOG("regs->inputCrBase:0x%x", regs->inputCrBase);
  //current picture
    WRITE_LOG("regs->reconLumBase:0x%x", regs->reconLumBase);
    WRITE_LOG("regs->reconCbBase:0x%x", regs->reconCbBase);
    WRITE_LOG("regs->reconCrBase:0x%x", regs->reconCrBase);
    WRITE_LOG("regs->reconL4nBase:0x%x", regs->reconL4nBase);
    WRITE_LOG("regs->minCbSize:0x%x", regs->minCbSize);
    WRITE_LOG("regs->maxCbSize:0x%x", regs->maxCbSize);     /* ctb size */
    WRITE_LOG("regs->minTrbSize:0x%x", regs->minTrbSize);
    WRITE_LOG("regs->maxTrbSize:0x%x", regs->maxTrbSize);
    WRITE_LOG("regs->picWidth:0x%x", regs->picWidth);
    WRITE_LOG("regs->picHeight:0x%x", regs->picHeight);
    WRITE_LOG("regs->pps_deblocking_filter_override_enabled_flag:0x%x", regs->pps_deblocking_filter_override_enabled_flag);
    WRITE_LOG("regs->slice_deblocking_filter_override_flag:0x%x", regs->slice_deblocking_filter_override_flag);
    WRITE_LOG("regs->qp:0x%x", regs->qp);
    WRITE_LOG("regs->qpMin:0x%x", regs->qpMin);
    WRITE_LOG("regs->qpMax:0x%x", regs->qpMax);
    WRITE_LOG("regs->rcQpDeltaRange:0x%x", regs->rcQpDeltaRange);
    WRITE_LOG("regs->picInitQp:0x%x", regs->picInitQp);
    WRITE_LOG("regs->diffCuQpDeltaDepth:0x%x", regs->diffCuQpDeltaDepth);
    WRITE_LOG("regs->cbQpOffset:0x%x", regs->cbQpOffset);
    WRITE_LOG("regs->crQpOffset:0x%x", regs->crQpOffset);
    WRITE_LOG("regs->saoEnable:0x%x", regs->saoEnable);
    WRITE_LOG("regs->maxTransHierarchyDepthInter:0x%x", regs->maxTransHierarchyDepthInter);
    WRITE_LOG("regs->maxTransHierarchyDepthIntra:0x%x", regs->maxTransHierarchyDepthIntra);
    WRITE_LOG("regs->cuQpDeltaEnabled:0x%x", regs->cuQpDeltaEnabled);
    WRITE_LOG("regs->log2ParellelMergeLevel:0x%x", regs->log2ParellelMergeLevel);
    WRITE_LOG("regs->numShortTermRefPicSets:0x%x", regs->numShortTermRefPicSets);
    WRITE_LOG("regs->rpsId:0x%x", regs->rpsId);
    WRITE_LOG("regs->numNegativePics:0x%x", regs->numNegativePics);
    WRITE_LOG("regs->numPositivePics:0x%x", regs->numPositivePics);
    WRITE_LOG("regs->delta_poc0:0x%x", regs->delta_poc0);
    // i32 l0_delta_poc[2];
    // i32 l0_long_term_flag[2];
    WRITE_LOG("regs->used_by_curr_pic0:0x%x", regs->used_by_curr_pic0);
    // i32 l0_used_by_curr_pic[2];
    WRITE_LOG("regs->delta_poc1:0x%x", regs->delta_poc1);
    // i32 l1_delta_poc[2];
    // i32 l1_long_term_flag[2];
    WRITE_LOG("regs->used_by_curr_pic1:0x%x", regs->used_by_curr_pic1);
    // i32 l1_used_by_curr_pic[2];
    WRITE_LOG("regs->long_term_ref_pics_present_flag:0x%x", regs->long_term_ref_pics_present_flag);
    WRITE_LOG("regs->num_long_term_pics:0x%x", regs->num_long_term_pics);

  //reference picture list
    // ptr_t pRefPic_recon_l0[3][2]; /* separate luma and chroma addresses */
    // ptr_t pRefPic_recon_l0_4n[2];
    // ptr_t pRefPic_recon_l1[3][2]; /* separate luma and chroma addresses */
    // ptr_t pRefPic_recon_l1_4n[2];

  //compress
    // u32 ref_l0_luma_compressed[2];
    // u32 ref_l0_chroma_compressed[2];
    // ptr_t ref_l0_luma_compress_tbl_base[2];
    // ptr_t ref_l0_chroma_compress_tbl_base[2];
    // u32 ref_l1_luma_compressed[2];
    // u32 ref_l1_chroma_compressed[2];
    // ptr_t ref_l1_luma_compress_tbl_base[2];
    // ptr_t ref_l1_chroma_compress_tbl_base[2];
    WRITE_LOG("regs->frameCtx_base:0x%x", regs->frameCtx_base);
    WRITE_LOG("regs->recon_luma_compress:0x%x", regs->recon_luma_compress);
    WRITE_LOG("regs->recon_chroma_compress:0x%x", regs->recon_chroma_compress);
    WRITE_LOG("regs->recon_luma_compress_tbl_base:0x%x", regs->recon_luma_compress_tbl_base);
    WRITE_LOG("regs->recon_chroma_compress_tbl_base:0x%x", regs->recon_chroma_compress_tbl_base);
    WRITE_LOG("regs->active_l0_cnt:0x%x", regs->active_l0_cnt);
    WRITE_LOG("regs->active_l1_cnt:0x%x", regs->active_l1_cnt);
    WRITE_LOG("regs->active_override_flag:0x%x", regs->active_override_flag);
    WRITE_LOG("regs->streamMode:0x%x", regs->streamMode);       /* 0 - byte stream, 1 - NAL units */

  // intra setup
    WRITE_LOG("regs->strong_intra_smoothing_enabled_flag:0x%x", regs->strong_intra_smoothing_enabled_flag);
    WRITE_LOG("regs->constrained_intra_pred_flag:0x%x", regs->constrained_intra_pred_flag);
    WRITE_LOG("regs->scaling_list_enabled_flag:0x%x", regs->scaling_list_enabled_flag);
    WRITE_LOG("regs->cirStart:0x%x", regs->cirStart);
    WRITE_LOG("regs->cirInterval:0x%x", regs->cirInterval);
    WRITE_LOG("regs->intraAreaTop:0x%x", regs->intraAreaTop);
    WRITE_LOG("regs->intraAreaLeft:0x%x", regs->intraAreaLeft);
    WRITE_LOG("regs->intraAreaBottom:0x%x", regs->intraAreaBottom);
    WRITE_LOG("regs->intraAreaRight:0x%x", regs->intraAreaRight);
    WRITE_LOG("regs->roi1Top:0x%x", regs->roi1Top);
    WRITE_LOG("regs->roi1Left:0x%x", regs->roi1Left);
    WRITE_LOG("regs->roi1Bottom:0x%x", regs->roi1Bottom);
    WRITE_LOG("regs->roi1Right:0x%x", regs->roi1Right);
    WRITE_LOG("regs->roi2Top:0x%x", regs->roi2Top);
    WRITE_LOG("regs->roi2Left:0x%x", regs->roi2Left);
    WRITE_LOG("regs->roi2Bottom:0x%x", regs->roi2Bottom);
    WRITE_LOG("regs->roi2Right:0x%x", regs->roi2Right);
    WRITE_LOG("regs->roi3Top:0x%x", regs->roi3Top);
    WRITE_LOG("regs->roi3Left:0x%x", regs->roi3Left);
    WRITE_LOG("regs->roi3Bottom:0x%x", regs->roi3Bottom);
    WRITE_LOG("regs->roi3Right:0x%x", regs->roi3Right);
    WRITE_LOG("regs->roi4Top:0x%x", regs->roi4Top);
    WRITE_LOG("regs->roi4Left:0x%x", regs->roi4Left);
    WRITE_LOG("regs->roi4Bottom:0x%x", regs->roi4Bottom);
    WRITE_LOG("regs->roi4Right:0x%x", regs->roi4Right);
    WRITE_LOG("regs->roi5Top:0x%x", regs->roi5Top);
    WRITE_LOG("regs->roi5Left:0x%x", regs->roi5Left);
    WRITE_LOG("regs->roi5Bottom:0x%x", regs->roi5Bottom);
    WRITE_LOG("regs->roi5Right:0x%x", regs->roi5Right);
    WRITE_LOG("regs->roi6Top:0x%x", regs->roi6Top);
    WRITE_LOG("regs->roi6Left:0x%x", regs->roi6Left);
    WRITE_LOG("regs->roi6Bottom:0x%x", regs->roi6Bottom);
    WRITE_LOG("regs->roi6Right:0x%x", regs->roi6Right);
    WRITE_LOG("regs->roi7Top:0x%x", regs->roi7Top);
    WRITE_LOG("regs->roi7Left:0x%x", regs->roi7Left);
    WRITE_LOG("regs->roi7Bottom:0x%x", regs->roi7Bottom);
    WRITE_LOG("regs->roi7Right:0x%x", regs->roi7Right);
    WRITE_LOG("regs->roi8Top:0x%x", regs->roi8Top);
    WRITE_LOG("regs->roi8Left:0x%x", regs->roi8Left);
    WRITE_LOG("regs->roi8Bottom:0x%x", regs->roi8Bottom);
    WRITE_LOG("regs->roi8Right:0x%x", regs->roi8Right);
    WRITE_LOG("regs->roi1DeltaQp:0x%x", regs->roi1DeltaQp);
    WRITE_LOG("regs->roi2DeltaQp:0x%x", regs->roi2DeltaQp);
    WRITE_LOG("regs->roi3DeltaQp:0x%x", regs->roi3DeltaQp);
    WRITE_LOG("regs->roi4DeltaQp:0x%x", regs->roi4DeltaQp);
    WRITE_LOG("regs->roi5DeltaQp:0x%x", regs->roi5DeltaQp);
    WRITE_LOG("regs->roi6DeltaQp:0x%x", regs->roi6DeltaQp);
    WRITE_LOG("regs->roi7DeltaQp:0x%x", regs->roi7DeltaQp);
    WRITE_LOG("regs->roi8DeltaQp:0x%x", regs->roi8DeltaQp);
    WRITE_LOG("regs->roi1Qp:0x%x", regs->roi1Qp);
    WRITE_LOG("regs->roi2Qp:0x%x", regs->roi2Qp);
    WRITE_LOG("regs->roi3Qp:0x%x", regs->roi3Qp);
    WRITE_LOG("regs->roi4Qp:0x%x", regs->roi4Qp);
    WRITE_LOG("regs->roi5Qp:0x%x", regs->roi5Qp);
    WRITE_LOG("regs->roi6Qp:0x%x", regs->roi6Qp);
    WRITE_LOG("regs->roi7Qp:0x%x", regs->roi7Qp);
    WRITE_LOG("regs->roi8Qp:0x%x", regs->roi8Qp);
    WRITE_LOG("regs->qpFactorSad:0x%x", regs->qpFactorSad);
    WRITE_LOG("regs->qpFactorSse:0x%x", regs->qpFactorSse);
    WRITE_LOG("regs->lambdaDepth:0x%x", regs->lambdaDepth);
    WRITE_LOG("regs->rcRoiEnable:0x%x", regs->rcRoiEnable);
    WRITE_LOG("regs->ipcmMapEnable:0x%x", regs->ipcmMapEnable);
    WRITE_LOG("regs->roiMapDeltaQpAddr:0x%x", regs->roiMapDeltaQpAddr);
    WRITE_LOG("regs->RoimapCuCtrl_index_enable:0x%x", regs->RoimapCuCtrl_index_enable);
    WRITE_LOG("regs->RoimapCuCtrl_enable:0x%x", regs->RoimapCuCtrl_enable);
    WRITE_LOG("regs->RoimapCuCtrl_ver:0x%x", regs->RoimapCuCtrl_ver);
    WRITE_LOG("regs->RoiQpDelta_ver:0x%x", regs->RoiQpDelta_ver);
    WRITE_LOG("regs->RoimapCuCtrlIndexAddr:0x%x", regs->RoimapCuCtrlIndexAddr);
    WRITE_LOG("regs->RoimapCuCtrlAddr:0x%x", regs->RoimapCuCtrlAddr);
    WRITE_LOG("regs->roiUpdate:0x%x", regs->roiUpdate);
    WRITE_LOG("regs->filterDisable:0x%x", regs->filterDisable);
    WRITE_LOG("regs->tc_Offset:0x%x", regs->tc_Offset);
    WRITE_LOG("regs->beta_Offset:0x%x", regs->beta_Offset);
    WRITE_LOG("regs->intraPenaltyPic4x4:0x%x", regs->intraPenaltyPic4x4);
    WRITE_LOG("regs->intraPenaltyPic8x8:0x%x", regs->intraPenaltyPic8x8);
    WRITE_LOG("regs->intraPenaltyPic16x16:0x%x", regs->intraPenaltyPic16x16);
    WRITE_LOG("regs->intraPenaltyPic32x32:0x%x", regs->intraPenaltyPic32x32);
    WRITE_LOG("regs->intraMPMPenaltyPic1:0x%x", regs->intraMPMPenaltyPic1);
    WRITE_LOG("regs->intraMPMPenaltyPic2:0x%x", regs->intraMPMPenaltyPic2);
    WRITE_LOG("regs->intraMPMPenaltyPic3:0x%x", regs->intraMPMPenaltyPic3);
    WRITE_LOG("regs->intraPenaltyRoi14x4:0x%x", regs->intraPenaltyRoi14x4);
    WRITE_LOG("regs->intraPenaltyRoi18x8:0x%x", regs->intraPenaltyRoi18x8);
    WRITE_LOG("regs->intraPenaltyRoi116x16:0x%x", regs->intraPenaltyRoi116x16);
    WRITE_LOG("regs->intraPenaltyRoi132x32:0x%x", regs->intraPenaltyRoi132x32);
    WRITE_LOG("regs->intraMPMPenaltyRoi11:0x%x", regs->intraMPMPenaltyRoi11);
    WRITE_LOG("regs->intraMPMPenaltyRoi12:0x%x", regs->intraMPMPenaltyRoi12);
    WRITE_LOG("regs->intraMPMPenaltyRoi13:0x%x", regs->intraMPMPenaltyRoi13);
    WRITE_LOG("regs->intraPenaltyRoi24x4:0x%x", regs->intraPenaltyRoi24x4);
    WRITE_LOG("regs->intraPenaltyRoi28x8:0x%x", regs->intraPenaltyRoi28x8);
    WRITE_LOG("regs->intraPenaltyRoi216x16:0x%x", regs->intraPenaltyRoi216x16);
    WRITE_LOG("regs->intraPenaltyRoi232x32:0x%x", regs->intraPenaltyRoi232x32);
    WRITE_LOG("regs->intraMPMPenaltyRoi21:0x%x", regs->intraMPMPenaltyRoi21);
    WRITE_LOG("regs->intraMPMPenaltyRoi22:0x%x", regs->intraMPMPenaltyRoi22);
    WRITE_LOG("regs->intraMPMPenaltyRoi23:0x%x", regs->intraMPMPenaltyRoi23);
    WRITE_LOG("regs->sizeTblBase:0x%x", regs->sizeTblBase);
    WRITE_LOG("regs->lamda_SAO_luma:0x%x", regs->lamda_SAO_luma);
    WRITE_LOG("regs->lamda_SAO_chroma:0x%x", regs->lamda_SAO_chroma);
    WRITE_LOG("regs->lamda_motion_sse:0x%x", regs->lamda_motion_sse);
    WRITE_LOG("regs->lamda_motion_sse_roi1:0x%x", regs->lamda_motion_sse_roi1);
    WRITE_LOG("regs->lamda_motion_sse_roi2:0x%x", regs->lamda_motion_sse_roi2);
    WRITE_LOG("regs->skip_chroma_dc_threadhold:0x%x", regs->skip_chroma_dc_threadhold);
    WRITE_LOG("regs->bits_est_tu_split_penalty:0x%x", regs->bits_est_tu_split_penalty);
    WRITE_LOG("regs->bits_est_bias_intra_cu_8:0x%x", regs->bits_est_bias_intra_cu_8);
    WRITE_LOG("regs->bits_est_bias_intra_cu_16:0x%x", regs->bits_est_bias_intra_cu_16);
    WRITE_LOG("regs->bits_est_bias_intra_cu_32:0x%x", regs->bits_est_bias_intra_cu_32);
    WRITE_LOG("regs->bits_est_bias_intra_cu_64:0x%x", regs->bits_est_bias_intra_cu_64);
    WRITE_LOG("regs->inter_skip_bias:0x%x", regs->inter_skip_bias);
    WRITE_LOG("regs->bits_est_1n_cu_penalty:0x%x", regs->bits_est_1n_cu_penalty);
    WRITE_LOG("regs->lambda_motionSAD:0x%x", regs->lambda_motionSAD);
    WRITE_LOG("regs->lambda_motionSAD_ROI1:0x%x", regs->lambda_motionSAD_ROI1);
    WRITE_LOG("regs->lambda_motionSAD_ROI2:0x%x", regs->lambda_motionSAD_ROI2);
    WRITE_LOG("regs->recon_chroma_half_size:0x%x", regs->recon_chroma_half_size);
    WRITE_LOG("regs->inputImageFormat:0x%x", regs->inputImageFormat);
    WRITE_LOG("regs->enableFBDC:0x%x", regs->enableFBDC);
    WRITE_LOG("regs->outputBitWidthLuma:0x%x", regs->outputBitWidthLuma);
    WRITE_LOG("regs->outputBitWidthChroma:0x%x", regs->outputBitWidthChroma);
    WRITE_LOG("regs->inputImageRotation:0x%x", regs->inputImageRotation);
    WRITE_LOG("regs->inputImageMirror:0x%x", regs->inputImageMirror);
    WRITE_LOG("regs->inputChromaBaseOffset:0x%x", regs->inputChromaBaseOffset);
    WRITE_LOG("regs->inputLumaBaseOffset:0x%x", regs->inputLumaBaseOffset);
    WRITE_LOG("regs->dummyReadEnable:0x%x", regs->dummyReadEnable);
    WRITE_LOG("regs->dummyReadAddr:0x%x", regs->dummyReadAddr);
    WRITE_LOG("regs->pixelsOnRow:0x%x", regs->pixelsOnRow);
    WRITE_LOG("regs->xFill:0x%x", regs->xFill);
    WRITE_LOG("regs->yFill:0x%x", regs->yFill);
    WRITE_LOG("regs->colorConversionCoeffA:0x%x", regs->colorConversionCoeffA);
    WRITE_LOG("regs->colorConversionCoeffB:0x%x", regs->colorConversionCoeffB);
    WRITE_LOG("regs->colorConversionCoeffC:0x%x", regs->colorConversionCoeffC);
    WRITE_LOG("regs->colorConversionCoeffE:0x%x", regs->colorConversionCoeffE);
    WRITE_LOG("regs->colorConversionCoeffF:0x%x", regs->colorConversionCoeffF);
    WRITE_LOG("regs->colorConversionCoeffG:0x%x", regs->colorConversionCoeffG);
    WRITE_LOG("regs->colorConversionCoeffH:0x%x", regs->colorConversionCoeffH);
    WRITE_LOG("regs->rMaskMsb:0x%x", regs->rMaskMsb);
    WRITE_LOG("regs->gMaskMsb:0x%x", regs->gMaskMsb);
    WRITE_LOG("regs->bMaskMsb:0x%x", regs->bMaskMsb);
    WRITE_LOG("regs->colorConversionLumaOffset:0x%x", regs->colorConversionLumaOffset);
    WRITE_LOG("regs->scaledOutputFormat:0x%x", regs->scaledOutputFormat);
    WRITE_LOG("regs->scaledLumBase:0x%x", regs->scaledLumBase);
    WRITE_LOG("regs->scaledWidth:0x%x", regs->scaledWidth);
    WRITE_LOG("regs->scaledHeight:0x%x", regs->scaledHeight);
    WRITE_LOG("regs->scaledWidthRatio:0x%x", regs->scaledWidthRatio);
    WRITE_LOG("regs->scaledHeightRatio:0x%x", regs->scaledHeightRatio);
    WRITE_LOG("regs->scaledSkipLeftPixelColumn:0x%x", regs->scaledSkipLeftPixelColumn);
    WRITE_LOG("regs->scaledSkipTopPixelRow:0x%x", regs->scaledSkipTopPixelRow);
    WRITE_LOG("regs->scaledVertivalWeightEn:0x%x", regs->scaledVertivalWeightEn);
    WRITE_LOG("regs->scaledHorizontalCopy:0x%x", regs->scaledHorizontalCopy);
    WRITE_LOG("regs->scaledVerticalCopy:0x%x", regs->scaledVerticalCopy);
    WRITE_LOG("regs->scaledOutSwap:0x%x", regs->scaledOutSwap);
    WRITE_LOG("regs->chromaSwap:0x%x", regs->chromaSwap);
    WRITE_LOG("regs->nalUnitSizeSwap:0x%x", regs->nalUnitSizeSwap);
    WRITE_LOG("regs->codedChromaIdc:0x%x", regs->codedChromaIdc);
    WRITE_LOG("regs->compress_coeff_scan_base:0x%x", regs->compress_coeff_scan_base);
    WRITE_LOG("regs->buswidth:0x%x", regs->buswidth);
    WRITE_LOG("regs->cabac_init_flag:0x%x", regs->cabac_init_flag);
    WRITE_LOG("regs->buffer_full_continue:0x%x", regs->buffer_full_continue);
    WRITE_LOG("regs->sliceReadyInterrupt:0x%x", regs->sliceReadyInterrupt);
    WRITE_LOG("regs->asicHwId:0x%x", regs->asicHwId);
    WRITE_LOG("regs->targetPicSize:0x%x", regs->targetPicSize);
    WRITE_LOG("regs->minPicSize:0x%x", regs->minPicSize);
    WRITE_LOG("regs->maxPicSize:0x%x", regs->maxPicSize);
    WRITE_LOG("regs->averageQP:0x%x", regs->averageQP);
    WRITE_LOG("regs->nonZeroCount:0x%x", regs->nonZeroCount);
    WRITE_LOG("regs->intraCu8Num:0x%x", regs->intraCu8Num);
    WRITE_LOG("regs->skipCu8Num:0x%x", regs->skipCu8Num);
    WRITE_LOG("regs->PBFrame4NRdCost:0x%x", regs->PBFrame4NRdCost);
    WRITE_LOG("regs->SSEDivide256:0x%x", regs->SSEDivide256);
  //for noise reduction
    WRITE_LOG("regs->noiseReductionEnable:0x%x", regs->noiseReductionEnable);
    WRITE_LOG("regs->noiseLow:0x%x", regs->noiseLow);
    //u32 firstFrameSigma;
    WRITE_LOG("regs->nrMbNumInvert:0x%x", regs->nrMbNumInvert);
    WRITE_LOG("regs->nrSliceQPPrev:0x%x", regs->nrSliceQPPrev);
    WRITE_LOG("regs->nrThreshSigmaCur:0x%x", regs->nrThreshSigmaCur);
    WRITE_LOG("regs->nrSigmaCur:0x%x", regs->nrSigmaCur);
    WRITE_LOG("regs->nrThreshSigmaCalced:0x%x", regs->nrThreshSigmaCalced);
    WRITE_LOG("regs->nrFrameSigmaCalced:0x%x", regs->nrFrameSigmaCalced);
  // for HEVC
  #ifndef CTBRC_STRENGTH
    // u32 lambda_sse_me[16];
    // u32 lambda_satd_me[16];
    // u32 lambda_satd_ims[16];
  #else
    // u32 lambda_sse_me[32];
    // u32 lambda_satd_me[32];
    // u32 lambda_satd_ims[32];
  #endif
    // u32 intra_size_factor[4];
    // u32 intra_mode_factor[3];
    WRITE_LOG("regs->ctbRcMemAddrCur:0x%x", regs->ctbRcMemAddrCur);
    WRITE_LOG("regs->ctbRcMemAddrPre:0x%x", regs->ctbRcMemAddrPre);
    WRITE_LOG("regs->ctbRcQpDeltaReverse:0x%x", regs->ctbRcQpDeltaReverse);
    WRITE_LOG("regs->ctbRcThrdMin:0x%x", regs->ctbRcThrdMin);
    WRITE_LOG("regs->ctbRcThrdMax:0x%x", regs->ctbRcThrdMax);
    WRITE_LOG("regs->ctbBitsMin:0x%x", regs->ctbBitsMin);
    WRITE_LOG("regs->ctbBitsMax:0x%x", regs->ctbBitsMax);
    WRITE_LOG("regs->totalLcuBits:0x%x", regs->totalLcuBits);
    WRITE_LOG("regs->bitsRatio:0x%x", regs->bitsRatio);
#ifdef CTBRC_STRENGTH
    WRITE_LOG("regs->qpfrac:0x%x", regs->qpfrac);
    WRITE_LOG("regs->sumOfQP:0x%x", regs->sumOfQP);
    WRITE_LOG("regs->sumOfQPNumber:0x%x", regs->sumOfQPNumber);
    WRITE_LOG("regs->rcBaseMBComplexity:0x%x", regs->rcBaseMBComplexity);
    WRITE_LOG("regs->qpDeltaMBGain:0x%x", regs->qpDeltaMBGain);
    WRITE_LOG("regs->picComplexity:0x%x", regs->picComplexity);
    WRITE_LOG("regs->rcBlockSize:0x%x", regs->rcBlockSize);
    WRITE_LOG("regs->offsetSliceQp:0x%x", regs->offsetSliceQp);
#endif

  //  for vp9
  // u32 mvRefIdx[2];
    WRITE_LOG("regs->ref2Enable:0x%x", regs->ref2Enable);
    WRITE_LOG("regs->ipolFilterMode:0x%x", regs->ipolFilterMode);
    WRITE_LOG("regs->disableQuarterPixelMv:0x%x", regs->disableQuarterPixelMv);      //not add into registers
    WRITE_LOG("regs->splitMvMode:0x%x", regs->splitMvMode);              //not add into registers
    for (i = 0; i < 8; i++) {
    // u32 partitionBase[8];
        WRITE_LOG("regs->partitionBase[%d]:0x%x", i, regs->partitionBase[i]);
    }

    // u32 qpY1QuantDc[4];
    // u32 qpY1QuantAc[4];
    // u32 qpY2QuantDc[4];
    // u32 qpY2QuantAc[4];
    // u32 qpChQuantDc[4];
    // u32 qpChQuantAc[4];
    // u32 qpY1ZbinDc[4];
    // u32 qpY1ZbinAc[4];
    // u32 qpY2ZbinDc[4];
    // u32 qpY2ZbinAc[4];
    // u32 qpChZbinDc[4];
    // u32 qpChZbinAc[4];
    // u32 qpY1RoundDc[4];
    // u32 qpY1RoundAc[4];
    // u32 qpY2RoundDc[4];
    // u32 qpY2RoundAc[4];
    // u32 qpChRoundDc[4];
    // u32 qpChRoundAc[4];
    // u32 qpY1DequantDc[4];
    // u32 qpY1DequantAc[4];
    // u32 qpY2DequantDc[4];
    // u32 qpY2DequantAc[4];
    // u32 qpChDequantDc[4];
    // u32 qpChDequantAc[4];
    // u32 filterLevel[4];
    WRITE_LOG("regs->boolEncValue:0x%x", regs->boolEncValue);
    WRITE_LOG("regs->boolEncValueBits:0x%x", regs->boolEncValueBits);
    WRITE_LOG("regs->boolEncRange:0x%x", regs->boolEncRange);
    WRITE_LOG("regs->dctPartitions:0x%x", regs->dctPartitions);
    WRITE_LOG("regs->filterSharpness:0x%x", regs->filterSharpness);
    WRITE_LOG("regs->segmentEnable:0x%x", regs->segmentEnable);
    WRITE_LOG("regs->segmentMapUpdate:0x%x", regs->segmentMapUpdate);
    // i32 lfRefDelta[4];
    // i32 lfModeDelta[4];
    WRITE_LOG("regs->avgVar:0x%x", regs->avgVar);
    WRITE_LOG("regs->invAvgVar:0x%x", regs->invAvgVar);
    WRITE_LOG("regs->cabacCtxBase:0x%x", regs->cabacCtxBase);
    WRITE_LOG("regs->probCountBase:0x%x", regs->probCountBase);
  // for h.264
    WRITE_LOG("regs->frameNum:0x%x", regs->frameNum);
    WRITE_LOG("regs->idrPicId:0x%x", regs->idrPicId);
    WRITE_LOG("regs->nalRefIdc:0x%x", regs->nalRefIdc);
    WRITE_LOG("regs->nalRefIdc_2bit:0x%x", regs->nalRefIdc_2bit);
    WRITE_LOG("regs->transform8x8Enable:0x%x", regs->transform8x8Enable);
    WRITE_LOG("regs->entropy_coding_mode_flag:0x%x", regs->entropy_coding_mode_flag);
    WRITE_LOG("regs->colctbs_load_base:0x%x", regs->colctbs_load_base);
    WRITE_LOG("regs->colctbs_store_base:0x%x", regs->colctbs_store_base);
    // i32 l0_delta_framenum[2];
    // i32 l0_used_by_next_pic[2];
    // i32 l1_delta_framenum[2];
    // i32 l1_used_by_next_pic[2];
    WRITE_LOG("regs->markCurrentLongTerm:0x%x", regs->markCurrentLongTerm);
    WRITE_LOG("regs->currentLongTermIdx:0x%x", regs->currentLongTermIdx);
    // i32 l0_referenceLongTermIdx[2];
    // i32 l1_referenceLongTermIdx[2];
    WRITE_LOG("regs->max_long_term_frame_idx_plus1:0x%x", regs->max_long_term_frame_idx_plus1);
    WRITE_LOG("regs->log2_max_pic_order_cnt_lsb:0x%x", regs->log2_max_pic_order_cnt_lsb);
    WRITE_LOG("regs->log2_max_frame_num:0x%x", regs->log2_max_frame_num);
    WRITE_LOG("regs->pic_order_cnt_type:0x%x", regs->pic_order_cnt_type);

  //ref pic lists modification
    WRITE_LOG("regs->lists_modification_present_flag:0x%x", regs->lists_modification_present_flag);
    WRITE_LOG("regs->ref_pic_list_modification_flag_l0:0x%x", regs->ref_pic_list_modification_flag_l0);
    // u32 list_entry_l0[2];
    WRITE_LOG("regs->ref_pic_list_modification_flag_l1:0x%x", regs->ref_pic_list_modification_flag_l1);
    // u32 list_entry_l1[2];

  //cu info output
    WRITE_LOG("regs->enableOutputCuInfo:0x%x", regs->enableOutputCuInfo);
    WRITE_LOG("regs->cuInfoTableBase:0x%x", regs->cuInfoTableBase);
    WRITE_LOG("regs->cuInfoDataBase:0x%x", regs->cuInfoDataBase);

  //aq info output
    WRITE_LOG("regs->aqInfoOutputMode:0x%x", regs->aqInfoOutputMode);
    WRITE_LOG("regs->aqInfoOutputBase:0x%x", regs->aqInfoOutputBase);
    WRITE_LOG("regs->aqInfoOutputStride:0x%x", regs->aqInfoOutputStride);
    WRITE_LOG("regs->aqStrength:0x%x", regs->aqStrength);

  /* mv info */
    WRITE_LOG("regs->mvInfoBase:0x%x", regs->mvInfoBase);

  /* ctb bits output*/
    WRITE_LOG("regs->enableOutputCtbBits:0x%x", regs->enableOutputCtbBits);
    WRITE_LOG("regs->ctbBitsDataBase:0x%x", regs->ctbBitsDataBase);
    WRITE_LOG("regs->pps_id:0x%x", regs->pps_id);
    WRITE_LOG("regs->rdoLevel:0x%x", regs->rdoLevel);
  // dynamic rdo setting
    WRITE_LOG("regs->dynamicRdoEnable:0x%x", regs->dynamicRdoEnable);
    WRITE_LOG("regs->dynamicRdoCu16Bias:0x%x", regs->dynamicRdoCu16Bias);
    WRITE_LOG("regs->dynamicRdoCu16Factor:0x%x", regs->dynamicRdoCu16Factor);
    WRITE_LOG("regs->dynamicRdoCu32Bias:0x%x", regs->dynamicRdoCu32Bias);
    WRITE_LOG("regs->dynamicRdoCu32Factor:0x%x", regs->dynamicRdoCu32Factor);
  // for jpeg
    WRITE_LOG("regs->firstFreeBit:0x%x", regs->firstFreeBit);
    WRITE_LOG("regs->strmStartMSB:0x%x", regs->strmStartMSB);
    WRITE_LOG("regs->strmStartLSB:0x%x", regs->strmStartLSB);
    WRITE_LOG("regs->jpegHeaderLength:0x%x", regs->jpegHeaderLength);
    WRITE_LOG("regs->jpegMode:0x%x", regs->jpegMode);
    WRITE_LOG("regs->jpegSliceEnable:0x%x", regs->jpegSliceEnable);
    WRITE_LOG("regs->jpegRestartInterval:0x%x", regs->jpegRestartInterval);
    WRITE_LOG("regs->jpegRestartMarker:0x%x", regs->jpegRestartMarker);
    WRITE_LOG("regs->constrainedIntraPrediction:0x%x", regs->constrainedIntraPrediction);
    WRITE_LOG("regs->roundingCtrl:0x%x", regs->roundingCtrl);
    WRITE_LOG("regs->mbsInRow:0x%x", regs->mbsInRow);
    WRITE_LOG("regs->mbsInCol:0x%x", regs->mbsInCol);
    WRITE_LOG("regs->busRoiMap:0x%x", regs->busRoiMap);
    WRITE_LOG("regs->roiEnable:0x%x", regs->roiEnable);
    // u8 quantTable[8 * 8 * 2];
    // u8 quantTableNonRoi[8 * 8 * 2];
  // for lossless jpeg
    WRITE_LOG("regs->ljpegEn:0x%x", regs->ljpegEn);
    WRITE_LOG("regs->ljpegFmt:0x%x", regs->ljpegFmt);
    WRITE_LOG("regs->ljpegPsv:0x%x", regs->ljpegPsv);
    WRITE_LOG("regs->ljpegPt:0x%x", regs->ljpegPt);

  /* low latency */
    WRITE_LOG("regs->mbWrPtr:0x%x", regs->mbWrPtr);
    WRITE_LOG("regs->mbRdPtr:0x%x", regs->mbRdPtr);
    WRITE_LOG("regs->lineBufferDepth:0x%x", regs->lineBufferDepth);
    WRITE_LOG("regs->lineBufferEn:0x%x", regs->lineBufferEn);
    WRITE_LOG("regs->lineBufferHwHandShake:0x%x", regs->lineBufferHwHandShake);
    WRITE_LOG("regs->lineBufferLoopBackEn:0x%x", regs->lineBufferLoopBackEn);
    WRITE_LOG("regs->lineBufferInterruptEn:0x%x", regs->lineBufferInterruptEn);
    WRITE_LOG("regs->amountPerLoopBack:0x%x", regs->amountPerLoopBack);
    WRITE_LOG("regs->initSegNum:0x%x", regs->initSegNum);
    WRITE_LOG("regs->sbi_id_0:0x%x", regs->sbi_id_0);
    WRITE_LOG("regs->sbi_id_1:0x%x", regs->sbi_id_1);
    WRITE_LOG("regs->sbi_id_2:0x%x", regs->sbi_id_2);
    WRITE_LOG("regs->ipcmFilterDisable:0x%x", regs->ipcmFilterDisable);
    WRITE_LOG("regs->ipcm1AreaTop:0x%x", regs->ipcm1AreaTop);
    WRITE_LOG("regs->ipcm1AreaLeft:0x%x", regs->ipcm1AreaLeft);
    WRITE_LOG("regs->ipcm1AreaBottom:0x%x", regs->ipcm1AreaBottom);
    WRITE_LOG("regs->ipcm1AreaRight:0x%x", regs->ipcm1AreaRight);
    WRITE_LOG("regs->ipcm2AreaTop:0x%x", regs->ipcm2AreaTop);
    WRITE_LOG("regs->ipcm2AreaLeft:0x%x", regs->ipcm2AreaLeft);
    WRITE_LOG("regs->ipcm2AreaBottom:0x%x", regs->ipcm2AreaBottom);
    WRITE_LOG("regs->ipcm2AreaRight:0x%x", regs->ipcm2AreaRight);
    WRITE_LOG("regs->ipcm3AreaTop:0x%x", regs->ipcm3AreaTop);
    WRITE_LOG("regs->ipcm3AreaLeft:0x%x", regs->ipcm3AreaLeft);
    WRITE_LOG("regs->ipcm3AreaBottom:0x%x", regs->ipcm3AreaBottom);
    WRITE_LOG("regs->ipcm3AreaRight:0x%x", regs->ipcm3AreaRight);
    WRITE_LOG("regs->ipcm4AreaTop:0x%x", regs->ipcm4AreaTop);
    WRITE_LOG("regs->ipcm4AreaLeft:0x%x", regs->ipcm4AreaLeft);
    WRITE_LOG("regs->ipcm4AreaBottom:0x%x", regs->ipcm4AreaBottom);
    WRITE_LOG("regs->ipcm4AreaRight:0x%x", regs->ipcm4AreaRight);
    WRITE_LOG("regs->ipcm5AreaTop:0x%x", regs->ipcm5AreaTop);
    WRITE_LOG("regs->ipcm5AreaLeft:0x%x", regs->ipcm5AreaLeft);
    WRITE_LOG("regs->ipcm5AreaBottom:0x%x", regs->ipcm5AreaBottom);
    WRITE_LOG("regs->ipcm5AreaRight:0x%x", regs->ipcm5AreaRight);
    WRITE_LOG("regs->ipcm6AreaTop:0x%x", regs->ipcm6AreaTop);
    WRITE_LOG("regs->ipcm6AreaLeft:0x%x", regs->ipcm6AreaLeft);
    WRITE_LOG("regs->ipcm6AreaBottom:0x%x", regs->ipcm6AreaBottom);
    WRITE_LOG("regs->ipcm6AreaRight:0x%x", regs->ipcm6AreaRight);
    WRITE_LOG("regs->ipcm7AreaTop:0x%x", regs->ipcm7AreaTop);
    WRITE_LOG("regs->ipcm7AreaLeft:0x%x", regs->ipcm7AreaLeft);
    WRITE_LOG("regs->ipcm7AreaBottom:0x%x", regs->ipcm7AreaBottom);
    WRITE_LOG("regs->ipcm7AreaRight:0x%x", regs->ipcm7AreaRight);
    WRITE_LOG("regs->ipcm8AreaTop:0x%x", regs->ipcm8AreaTop);
    WRITE_LOG("regs->ipcm8AreaLeft:0x%x", regs->ipcm8AreaLeft);
    WRITE_LOG("regs->ipcm8AreaBottom:0x%x", regs->ipcm8AreaBottom);
    WRITE_LOG("regs->ipcm8AreaRight:0x%x", regs->ipcm8AreaRight);

  /* frame data hash */
    WRITE_LOG("regs->hashtype:0x%x", regs->hashtype);
    WRITE_LOG("regs->hashval:0x%x", regs->hashval);
    WRITE_LOG("regs->hashoffset:0x%x", regs->hashoffset);

  /* for smart */
    WRITE_LOG("regs->smartModeEnable:0x%x", regs->smartModeEnable);
    WRITE_LOG("regs->smartH264Qp:0x%x", regs->smartH264Qp);
    WRITE_LOG("regs->smartHevcLumQp:0x%x", regs->smartHevcLumQp);
    WRITE_LOG("regs->smartHevcChrQp:0x%x", regs->smartHevcChrQp);
    WRITE_LOG("regs->smartH264LumDcTh:0x%x", regs->smartH264LumDcTh);
    WRITE_LOG("regs->smartH264CbDcTh:0x%x", regs->smartH264CbDcTh);
    WRITE_LOG("regs->smartH264CrDcTh:0x%x", regs->smartH264CrDcTh);
  /* threshold for hevc cu8x8/16x16/32x32 */
    // i32 smartHevcLumDcTh[3];
    // i32 smartHevcChrDcTh[3];
    // i32 smartHevcLumAcNumTh[3];
    // i32 smartHevcChrAcNumTh[3];
  /* back ground */
    // i32 smartMeanTh[4];
  /* foreground/background threashold: maximum foreground pixels in background block */
    WRITE_LOG("regs->smartPixNumCntTh:0x%x", regs->smartPixNumCntTh);

  /* constant chroma control */
    WRITE_LOG("regs->constChromaEn:0x%x", regs->constChromaEn);
    WRITE_LOG("regs->constCb:0x%x", regs->constCb);
    WRITE_LOG("regs->constCr:0x%x", regs->constCr);

  /* Tile */
    WRITE_LOG("regs->tiles_enabled_flag:0x%x", regs->tiles_enabled_flag);
    WRITE_LOG("regs->num_tile_columns:0x%x", regs->num_tile_columns);
    WRITE_LOG("regs->num_tile_rows:0x%x", regs->num_tile_rows);
    WRITE_LOG("regs->loop_filter_across_tiles_enabled_flag:0x%x", regs->loop_filter_across_tiles_enabled_flag);

  /* frame encoded as skipframe*/
    WRITE_LOG("regs->skip_frame_enabled:0x%x", regs->skip_frame_enabled);

  /* enable P010 tile-raster format for reference frame buffer */
    WRITE_LOG("regs->P010RefEnable:0x%x", regs->P010RefEnable);

  /*stride*/
    WRITE_LOG("regs->input_luma_stride:0x%x", regs->input_luma_stride);
    WRITE_LOG("regs->input_chroma_stride:0x%x", regs->input_chroma_stride);
    WRITE_LOG("regs->ref_frame_stride:0x%x", regs->ref_frame_stride);
    WRITE_LOG("regs->ref_frame_stride_ch:0x%x", regs->ref_frame_stride_ch);
    WRITE_LOG("regs->ref_ds_luma_stride:0x%x", regs->ref_ds_luma_stride);
  /* RPS in slice header */
    WRITE_LOG("regs->short_term_ref_pic_set_sps_flag:0x%x", regs->short_term_ref_pic_set_sps_flag);
    WRITE_LOG("regs->rps_neg_pic_num:0x%x", regs->rps_neg_pic_num);
    WRITE_LOG("regs->rps_pos_pic_num:0x%x", regs->rps_pos_pic_num);
    // u32 rps_delta_poc[VCENC_MAX_REF_FRAMES];
    // u32 rps_used_by_cur[VCENC_MAX_REF_FRAMES];
    WRITE_LOG("regs->ssim:0x%x", regs->ssim);
    WRITE_LOG("regs->psnr:0x%x", regs->psnr);
    WRITE_LOG("regs->current_max_tu_size_decrease:0x%x", regs->current_max_tu_size_decrease);

  /* CTB QP adjustment for rate control */
    WRITE_LOG("regs->ctbRcModelParam0:0x%x", regs->ctbRcModelParam0);
    WRITE_LOG("regs->ctbRcModelParam1:0x%x", regs->ctbRcModelParam1);
    WRITE_LOG("regs->ctbRcModelParamMin:0x%x", regs->ctbRcModelParamMin);
    WRITE_LOG("regs->prevPicLumMad:0x%x", regs->prevPicLumMad);
    WRITE_LOG("regs->ctbQpSumForRc:0x%x", regs->ctbQpSumForRc);
    WRITE_LOG("regs->ctbRcQpStep:0x%x", regs->ctbRcQpStep);
    WRITE_LOG("regs->ctbRcRowFactor:0x%x", regs->ctbRcRowFactor);
    WRITE_LOG("regs->ctbRcPrevMadValid:0x%x", regs->ctbRcPrevMadValid);
    WRITE_LOG("regs->ctbRcDelay:0x%x", regs->ctbRcDelay);

  /* Global MV */
    // i16 gmv[2][2];

  /* Assigned ME vertical search range */
    WRITE_LOG("regs->meAssignedVertRange:0x%x", regs->meAssignedVertRange);

  /* SKIP map */
    WRITE_LOG("regs->skipMapEnable:0x%x", regs->skipMapEnable);

  /* rdoq map */
    WRITE_LOG("regs->rdoqMapEnable:0x%x", regs->rdoqMapEnable);

  /* SSE before DEB */
    WRITE_LOG("regs->lumSSEDivide256:0x%x", regs->lumSSEDivide256);
    WRITE_LOG("regs->cbSSEDivide64:0x%x", regs->cbSSEDivide64);
    WRITE_LOG("regs->crSSEDivide64:0x%x", regs->crSSEDivide64);

  /* multi-core sync */
    WRITE_LOG("regs->mc_sync_enable:0x%x", regs->mc_sync_enable);
    WRITE_LOG("regs->mc_sync_l0_addr:0x%x", regs->mc_sync_l0_addr);
    WRITE_LOG("regs->mc_sync_l1_addr:0x%x", regs->mc_sync_l1_addr);
    WRITE_LOG("regs->mc_sync_rec_addr:0x%x", regs->mc_sync_rec_addr);
    WRITE_LOG("regs->mc_ref_ready_threshold:0x%x", regs->mc_ref_ready_threshold);
    WRITE_LOG("regs->mc_ddr_polling_interval:0x%x", regs->mc_ddr_polling_interval);

  /* multi-pass*/
    WRITE_LOG("regs->bSkipCabacEnable:0x%x", regs->bSkipCabacEnable);
    WRITE_LOG("regs->bRDOQEnable:0x%x", regs->bRDOQEnable);
    WRITE_LOG("regs->inLoopDSRatio:0x%x", regs->inLoopDSRatio);
    WRITE_LOG("regs->bMotionScoreEnable:0x%x", regs->bMotionScoreEnable);
    // u32 motionScore[2][2];
    WRITE_LOG("regs->cuInfoVersion:0x%x", regs->cuInfoVersion);

  /*stream multi-segment*/
    WRITE_LOG("regs->streamMultiSegEn:0x%x", regs->streamMultiSegEn);
    WRITE_LOG("regs->streamMultiSegSWSyncEn:0x%x", regs->streamMultiSegSWSyncEn);
    WRITE_LOG("regs->streamMultiSegSize:0x%x", regs->streamMultiSegSize);
    WRITE_LOG("regs->streamMultiSegRD:0x%x", regs->streamMultiSegRD);
    WRITE_LOG("regs->streamMultiSegIRQEn:0x%x", regs->streamMultiSegIRQEn);

  /* external SRAM line buffer */
    WRITE_LOG("regs->sram_base_lum_fwd:0x%x", regs->sram_base_lum_fwd);
    WRITE_LOG("regs->sram_base_lum_bwd:0x%x", regs->sram_base_lum_bwd);
    WRITE_LOG("regs->sram_base_chr_fwd:0x%x", regs->sram_base_chr_fwd);
    WRITE_LOG("regs->sram_base_chr_bwd:0x%x", regs->sram_base_chr_bwd);
    WRITE_LOG("regs->sram_linecnt_lum_fwd:0x%x", regs->sram_linecnt_lum_fwd);
    WRITE_LOG("regs->sram_linecnt_lum_bwd:0x%x", regs->sram_linecnt_lum_bwd);
    WRITE_LOG("regs->sram_linecnt_chr_fwd:0x%x", regs->sram_linecnt_chr_fwd);
    WRITE_LOG("regs->sram_linecnt_chr_bwd:0x%x", regs->sram_linecnt_chr_bwd);
    WRITE_LOG("regs->AXI_ENC_WR_ID_E:0x%x", regs->AXI_ENC_WR_ID_E);
    WRITE_LOG("regs->AXI_ENC_RD_ID_E:0x%x", regs->AXI_ENC_RD_ID_E);

  /*AXI max burst length */
    WRITE_LOG("regs->AXI_burst_max_length:0x%x", regs->AXI_burst_max_length);

  /* AXI alignment */
    WRITE_LOG("regs->AXI_burst_align_wr_common:0x%x", regs->AXI_burst_align_wr_common);
    WRITE_LOG("regs->AXI_burst_align_wr_stream:0x%x", regs->AXI_burst_align_wr_stream);
    WRITE_LOG("regs->AXI_burst_align_wr_chroma_ref:0x%x", regs->AXI_burst_align_wr_chroma_ref);
    WRITE_LOG("regs->AXI_burst_align_wr_luma_ref:0x%x", regs->AXI_burst_align_wr_luma_ref);
    WRITE_LOG("regs->AXI_burst_align_rd_common:0x%x", regs->AXI_burst_align_rd_common);
    WRITE_LOG("regs->AXI_burst_align_rd_prp:0x%x", regs->AXI_burst_align_rd_prp);
    WRITE_LOG("regs->AXI_burst_align_rd_ch_ref_prefetch:0x%x", regs->AXI_burst_align_rd_ch_ref_prefetch);
    WRITE_LOG("regs->AXI_burst_align_rd_lu_ref_prefetch:0x%x", regs->AXI_burst_align_rd_lu_ref_prefetch);

  /* AV1 */
    WRITE_LOG("regs->sw_av1_allow_intrabc:0x%x", regs->sw_av1_allow_intrabc);
    WRITE_LOG("regs->sw_av1_coded_lossless:0x%x", regs->sw_av1_coded_lossless);
    WRITE_LOG("regs->sw_av1_delta_q_res:0x%x", regs->sw_av1_delta_q_res);
    WRITE_LOG("regs->sw_av1_enable_filter_intra:0x%x", regs->sw_av1_enable_filter_intra);
    WRITE_LOG("regs->sw_av1_tx_mode:0x%x", regs->sw_av1_tx_mode);
    WRITE_LOG("regs->sw_av1_reduced_tx_set_used:0x%x", regs->sw_av1_reduced_tx_set_used);
    WRITE_LOG("regs->sw_av1_seg_enable:0x%x", regs->sw_av1_seg_enable);
    WRITE_LOG("regs->sw_av1_allow_high_precision_mv:0x%x", regs->sw_av1_allow_high_precision_mv);
    WRITE_LOG("regs->sw_av1_skip_mode_flag:0x%x", regs->sw_av1_skip_mode_flag);
    WRITE_LOG("regs->sw_av1_reference_mode:0x%x", regs->sw_av1_reference_mode);
    WRITE_LOG("regs->sw_av1_list0_ref_frame:0x%x", regs->sw_av1_list0_ref_frame);
    WRITE_LOG("regs->sw_av1_list1_ref_frame:0x%x", regs->sw_av1_list1_ref_frame);
    WRITE_LOG("regs->sw_av1_enable_interintra_compound:0x%x", regs->sw_av1_enable_interintra_compound);
    WRITE_LOG("regs->sw_av1_enable_dual_filter:0x%x", regs->sw_av1_enable_dual_filter);
    WRITE_LOG("regs->sw_av1_cur_frame_force_integer_mv:0x%x", regs->sw_av1_cur_frame_force_integer_mv);
    WRITE_LOG("regs->sw_av1_switchable_motion_mode:0x%x", regs->sw_av1_switchable_motion_mode);
    WRITE_LOG("regs->sw_av1_interp_filter:0x%x", regs->sw_av1_interp_filter);
    WRITE_LOG("regs->sw_av1_allow_update_cdf:0x%x", regs->sw_av1_allow_update_cdf);
    // u32 sw_av1_db_filter_lvl[2];
    WRITE_LOG("regs->sw_av1_db_filter_lvl_u:0x%x", regs->sw_av1_db_filter_lvl_u);
    WRITE_LOG("regs->sw_av1_db_filter_lvl_v:0x%x", regs->sw_av1_db_filter_lvl_v);
    WRITE_LOG("regs->sw_av1_sharpness_lvl:0x%x", regs->sw_av1_sharpness_lvl);
    WRITE_LOG("regs->sw_cdef_damping:0x%x", regs->sw_cdef_damping);
    WRITE_LOG("regs->sw_cdef_bits:0x%x", regs->sw_cdef_bits);
    // u32 sw_cdef_strengths[CDEF_STRENGTH_NUM];
    // u32 sw_cdef_uv_strengths[CDEF_STRENGTH_NUM];
    WRITE_LOG("regs->sw_av1_enable_order_hint:0x%x", regs->sw_av1_enable_order_hint);
    WRITE_LOG("regs->sw_primary_ref_frame:0x%x", regs->sw_primary_ref_frame);
    WRITE_LOG("regs->av1_bTxTypeSearch:0x%x", regs->av1_bTxTypeSearch);
    // u32 av1_plane_rdmult[2][2];
    // u32 av1_qp2qindex[52];

  /* VP9 */
    WRITE_LOG("regs->sw_last_frame_type:0x%x", regs->sw_last_frame_type);
    WRITE_LOG("regs->sw_vp9_refresh_frame_context:0x%x", regs->sw_vp9_refresh_frame_context);
    WRITE_LOG("regs->sw_vp9_segmentation_enable:0x%x", regs->sw_vp9_segmentation_enable);
    // u32 sw_vp9_segment_qp[MAX_SEGMENTS];
    // u32 sw_vp9_segment_lf[MAX_SEGMENTS];
    // u32 sw_vp9_segment_skip[MAX_SEGMENTS];
    WRITE_LOG("regs->sw_vp9_segment_abs:0x%x", regs->sw_vp9_segment_abs);
    // u32 sw_vp9_segment_tree_prob[MAX_SEGMENTS - 1];

  /* overlay regs */
    // ptr_t overlayYAddr[MAX_OVERLAY_NUM];
    // ptr_t overlayUAddr[MAX_OVERLAY_NUM];
    // ptr_t overlayVAddr[MAX_OVERLAY_NUM];
    // u32 overlayEnable[MAX_OVERLAY_NUM];
    // u32 overlayFormat[MAX_OVERLAY_NUM];
    // u32 overlayAlpha[MAX_OVERLAY_NUM];
    // u32 overlayXoffset[MAX_OVERLAY_NUM];
    // u32 overlayYoffset[MAX_OVERLAY_NUM];
    // u32 overlayWidth[MAX_OVERLAY_NUM];
    // u32 overlayHeight[MAX_OVERLAY_NUM];
    // u32 overlayYStride[MAX_OVERLAY_NUM];
    // u32 overlayUVStride[MAX_OVERLAY_NUM];
    // u32 overlayBitmapY[MAX_OVERLAY_NUM];
    // u32 overlayBitmapU[MAX_OVERLAY_NUM];
    // u32 overlayBitmapV[MAX_OVERLAY_NUM];
    WRITE_LOG("regs->overlayScaleWidth:0x%x", regs->overlayScaleWidth);
    WRITE_LOG("regs->overlayScaleHeight:0x%x", regs->overlayScaleHeight);
    WRITE_LOG("regs->overlaySuperTile:0x%x", regs->overlaySuperTile);
    WRITE_LOG("regs->overlayScaleStepW:0x%x", regs->overlayScaleStepW);
    WRITE_LOG("regs->overlayScaleStepH:0x%x", regs->overlayScaleStepH);

  /* Mosaic regs*/
    // u32 mosaicEnable[MAX_MOSAIC_NUM - MAX_OVERLAY_NUM];
    // u32 mosaicXoffset[MAX_MOSAIC_NUM - MAX_OVERLAY_NUM];
    // u32 mosaicYoffset[MAX_MOSAIC_NUM - MAX_OVERLAY_NUM];
    // u32 mosaicWidth[MAX_MOSAIC_NUM - MAX_OVERLAY_NUM];
    // u32 mosaicHeight[MAX_MOSAIC_NUM - MAX_OVERLAY_NUM];

  /* video stabilization */
    WRITE_LOG("regs->stabNextLumaBase:0x%x", regs->stabNextLumaBase);
    WRITE_LOG("regs->stabMode:0x%x", regs->stabMode);
    WRITE_LOG("regs->stabMotionMin:0x%x", regs->stabMotionMin);
    WRITE_LOG("regs->stabMotionSum:0x%x", regs->stabMotionSum);
    WRITE_LOG("regs->stabGmvX:0x%x", regs->stabGmvX);
    WRITE_LOG("regs->stabGmvY:0x%x", regs->stabGmvY);
    WRITE_LOG("regs->stabMatrix1:0x%x", regs->stabMatrix1);
    WRITE_LOG("regs->stabMatrix2:0x%x", regs->stabMatrix2);
    WRITE_LOG("regs->stabMatrix3:0x%x", regs->stabMatrix3);
    WRITE_LOG("regs->stabMatrix4:0x%x", regs->stabMatrix4);
    WRITE_LOG("regs->stabMatrix5:0x%x", regs->stabMatrix5);
    WRITE_LOG("regs->stabMatrix6:0x%x", regs->stabMatrix6);
    WRITE_LOG("regs->stabMatrix7:0x%x", regs->stabMatrix7);
    WRITE_LOG("regs->stabMatrix8:0x%x", regs->stabMatrix8);
    WRITE_LOG("regs->stabMatrix9:0x%x", regs->stabMatrix9);
    WRITE_LOG("regs->writeReconToDDR:0x%x", regs->writeReconToDDR);
    WRITE_LOG("regs->CyclesDdrPollingCheck:0x%x", regs->CyclesDdrPollingCheck);

  /* subject visual tuning */
    WRITE_LOG("regs->H264Intramode4x4Disable:0x%x", regs->H264Intramode4x4Disable);
    WRITE_LOG("regs->H264Intramode8x8Disable:0x%x", regs->H264Intramode8x8Disable);
    WRITE_LOG("regs->RefFrameUsingInputFrameEnable:0x%x", regs->RefFrameUsingInputFrameEnable);
    WRITE_LOG("regs->MeQpForLambda:0x%x", regs->MeQpForLambda);
    WRITE_LOG("regs->rdoqLambdaAdjustIntra:0x%x", regs->rdoqLambdaAdjustIntra);
    WRITE_LOG("regs->rdoqLambdaAdjustInter:0x%x", regs->rdoqLambdaAdjustInter);
    WRITE_LOG("regs->BiPredInLdbDisable:0x%x", regs->BiPredInLdbDisable);
    WRITE_LOG("regs->InLoopDSBilinearEnable:0x%x", regs->InLoopDSBilinearEnable);
    WRITE_LOG("regs->HevcSimpleRdoAssign:0x%x", regs->HevcSimpleRdoAssign);
    WRITE_LOG("regs->PredModeBySatdEnable:0x%x", regs->PredModeBySatdEnable);
  /* psy factor */
    WRITE_LOG("regs->psyFactor:0x%x", regs->psyFactor);
    // u32 regMirror[ASIC_SWREG_AMOUNT];
    WRITE_LOG("regs->*vcmdBuf:%p", regs->vcmdBuf);
    WRITE_LOG("regs->vcmdBufSize:0x%x", regs->vcmdBufSize);
    WRITE_LOG("regs->totalCmdbufSize:0x%x", regs->totalCmdbufSize);
    WRITE_LOG("regs->cmdbufid:0x%x", regs->cmdbufid);

  /* vcmd */
    WRITE_LOG("regs->bVCMDAvailable:0x%x", regs->bVCMDAvailable);
    WRITE_LOG("regs->bVCMDEnable:0x%x", regs->bVCMDEnable);
    WRITE_LOG("regs->bInitUpdate:0x%x", regs->bInitUpdate);              //clean to 0 in EncAsicFrameStart(), set to 1 in VCEncInit()/JpegEncInit()
    WRITE_LOG("regs->bCodingCtrlUpdate:0x%x", regs->bCodingCtrlUpdate);        //clean to 0 in EncAsicFrameStart(), set to 1 in VCEncSetCodingCtrl()
    WRITE_LOG("regs->bRateCtrlUpdate:0x%x", regs->bRateCtrlUpdate);          //clean to 0 in EncAsicFrameStart(), set to 1 in VCEncSetRateCtrl()
    WRITE_LOG("regs->bPreprocessUpdate:0x%x", regs->bPreprocessUpdate);        //clean to 0 in EncAsicFrameStart(), set to 1 in VCEncSetPreProcessing()
    WRITE_LOG("regs->bStrmStartUpdate:0x%x", regs->bStrmStartUpdate);         //clean to 0 in EncAsicFrameStart(), set to 1 in VCEncStrmStart()

  /* SRAM power down disable */
    WRITE_LOG("regs->sramPowerdownDisable:0x%x", regs->sramPowerdownDisable);

    __EncPrint(NULL, &regs->asicCfg);

    if (str_flag == NULL) {
        fprintf(fAsic, "%s end! \n\n", __func__);
    } else {
        fprintf(fAsic, "%s end! \n\n", str_flag);
    }

    fprintf(fAsic, "\n");
    fflush(fAsic);
    return 0;
}


#define CFG_WRITE_LOG(str, arg...)    \
    do {    \
        fprintf(logFd, str"\n", ##arg); \
    } while(0)

static FILE *logFd = NULL;

AX_S32 AX_VCEncConfig_Print(const char *str_flag, const VCEncConfig *config, u32 flag)
{
    /* int i = 0; */
    if (config == NULL) {
        DEBUG_ERR_LOG(" config == NULL");
        return -1;
    }

    const VCEncConfig *CFG = config;
    time_t time_s = time(NULL);
    char sFilePath[100] = {0};

    if (logFd == NULL) {
        sprintf(sFilePath, "%s_%ld.txt", __func__, time_s);
        logFd = fopen(sFilePath, "w");
        if (logFd == NULL) {
          DEBUG_ERR_LOG("logFd == NULL fopen(sFilePath:%s failed!", sFilePath);
          return -1;
        }
    }

    if (str_flag == NULL) {
        fprintf(logFd, "%s begin!\n", __func__);
    } else {
        fprintf(logFd, "%s begin!\n", str_flag);
    }

    DEBUG_LOG("sFilePath:%s", sFilePath);
    DEBUG_LOG("CFG->AXIAlignment:%d 0x%x", CFG->AXIAlignment, CFG->AXIAlignment);

    CFG_WRITE_LOG("CFG->streamType:0x%x", CFG->streamType);       /**< Byte stream / Plain NAL units */

    CFG_WRITE_LOG("CFG->profile:0x%x", CFG->profile);     /* Main, Main Still or main10 */

    CFG_WRITE_LOG("CFG->level:0x%x", CFG->level);     /**< Level encoded in to the SPS. When set as zero, will select
                                automatically. see \ref ss_autoLevel. */

    CFG_WRITE_LOG("CFG->tier:0x%x", CFG->tier);       /**< Main Tier or High Tier */

    CFG_WRITE_LOG("CFG->width:0x%x", CFG->width);               /* Encoded picture width in pixels, multiple of 2 */
    CFG_WRITE_LOG("CFG->height:0x%x", CFG->height);              /* Encoded picture height in pixels, multiple of 2 */
    CFG_WRITE_LOG("CFG->frameRateNum:0x%x", CFG->frameRateNum);        /* The stream time scale, [1..1048575] */
    CFG_WRITE_LOG("CFG->frameRateDenom:0x%x", CFG->frameRateDenom);      /* Maximum frame rate is frameRateNum/frameRateDenom
                                * in frames/second. The actual frame rate will be
                                * defined by timeIncrement of encoded pictures,
                                * [1..frameRateNum] */

    CFG_WRITE_LOG("CFG->refFrameAmount:0x%x", CFG->refFrameAmount);     /**< Amount of reference frame buffers, [0..8]
                                * 0 = only I frames are encoded.
                                * 1 = gop size is 1 and interlacedFrame =0,
                                * 2 = gop size is 1 and interlacedFrame =1,
                                * 2 = gop size is 2 or 3,
                                * 3 = gop size is 4,5,6, or 7,
                                * 4 = gop size is 8
                                * 8 = gop size is 8 svct hirach 7B+1p 4 layer, only libva support this config*/
    CFG_WRITE_LOG("CFG->strongIntraSmoothing:0x%x", CFG->strongIntraSmoothing);           /* 0 = Normal smoothing,
                                            * 1 = Strong smoothing. */


    CFG_WRITE_LOG("CFG->compressor:0x%x", CFG->compressor);           /**< Enable/Disable Embedded Compression. see \ref ss_rfc
                            * - 0 = Disable Compression
                            * - 1 = Only Enable Luma Compression (not support)
                            * - 2 = Only Enable Chroma Compression (not support)
                            * - 3 = Enable Both Luma and Chroma Compression */
        /**
         * only HEVC supported interlace encoding by insert proper SEI information. \ref ss_interlace */
    CFG_WRITE_LOG("CFG->interlacedFrame:0x%x", CFG->interlacedFrame);       /*0 = progressive frame; 1 = interlace frame  */

    CFG_WRITE_LOG("CFG->bitDepthLuma:0x%x", CFG->bitDepthLuma);         /**< Luma sample bit depth of encoded bit stream, 8 = 8 bits, 10 = 10 bits  */
    CFG_WRITE_LOG("CFG->bitDepthChroma:0x%x", CFG->bitDepthChroma);       /**< Chroma sample bit depth of encoded bit stream,  8 = 8 bits, 10 = 10 bits */

        /** Control CU information dumping, 1: Enable, 0: Disable. \ref ss_outCuInfo */
    CFG_WRITE_LOG("CFG->enableOutputCuInfo:0x%x", CFG->enableOutputCuInfo);

    CFG_WRITE_LOG("CFG->enableOutputCtbBits:0x%x", CFG->enableOutputCtbBits);           /**< 1 to enable CTB bits output. \ref ss_outCtbBits */
    CFG_WRITE_LOG("CFG->enableSsim:0x%x", CFG->enableSsim);                    /* Enable/Disable SSIM calculation */
    CFG_WRITE_LOG("CFG->enablePsnr:0x%x", CFG->enablePsnr);                    /* Enable/Disable PSNR calculation */
    CFG_WRITE_LOG("CFG->maxTLayers:0x%x", CFG->maxTLayers);     /*max number Temporal layers*/

    CFG_WRITE_LOG("CFG->rdoLevel:0x%x", CFG->rdoLevel);     /**< control RDO hw runtime effort level, balence between quality and throughput
                        performance, [0..2]. \ref ss_rdolevel
                            * 0 = RDO run 1x cadidates
                            * 1 = RDO run 2x cadidates
                            * 2 = RDO run 3x cadidates
                            */
    CFG_WRITE_LOG("CFG->codecFormat:0x%x", CFG->codecFormat);         /* Video Codec Format: HEVC/H264/AV1 */
    CFG_WRITE_LOG("CFG->verbose:0x%x", CFG->verbose);           /* log printing mode */
    CFG_WRITE_LOG("CFG->exp_of_input_alignment:0x%x", CFG->exp_of_input_alignment);    /*indicates the encoder's alignment,except input/ref frame*/
    CFG_WRITE_LOG("CFG->exp_of_ref_alignment:0x%x", CFG->exp_of_ref_alignment);    /*just affect luma reference frame config*/
    CFG_WRITE_LOG("CFG->exp_of_ref_ch_alignment:0x%x", CFG->exp_of_ref_ch_alignment);    /*just affect chroma reference frame config*/
    CFG_WRITE_LOG("CFG->exp_of_aqinfo_alignment:0x%x", CFG->exp_of_aqinfo_alignment);    /*just affect aqinfo output config*/
    CFG_WRITE_LOG("CFG->exteralReconAlloc:0x%x", CFG->exteralReconAlloc);     /* 0 = recon frame is allocated by encoder itself
                                1 = recon frame is allocated by APP*/
    CFG_WRITE_LOG("CFG->P010RefEnable:0x%x", CFG->P010RefEnable);      /* enable P010 tile-raster format for reference frame buffer */

    CFG_WRITE_LOG("CFG->ctbRcMode:0x%x", CFG->ctbRcMode);     /**< CTB QP adjustment mode for Rate Control and Subjective Quality.
                                        0 = No CTB QP adjustment.\n"
                                        1 = CTB QP adjustment for Subjective Quality only."
                                        2 = CTB QP adjustment for Rate Control only."
                                        3 = CTB QP adjustment for both Subjective Quality and Rate Control. */

    CFG_WRITE_LOG("CFG->picOrderCntType:0x%x", CFG->picOrderCntType);
    CFG_WRITE_LOG("CFG->log2MaxPicOrderCntLsb:0x%x", CFG->log2MaxPicOrderCntLsb);
    CFG_WRITE_LOG("CFG->log2MaxFrameNum:0x%x", CFG->log2MaxFrameNum);

    CFG_WRITE_LOG("CFG->dumpRegister:0x%x", CFG->dumpRegister);      /**< enable dump register values for debug */
    CFG_WRITE_LOG("CFG->dumpCuInfo:0x%x", CFG->dumpCuInfo);        /**< enable dump the Cu Information after encoding one frame for debug */
    CFG_WRITE_LOG("CFG->dumpCtbBits:0x%x", CFG->dumpCtbBits);       /**< enable dump the CTB encoded bits information after encoding one frame */
    CFG_WRITE_LOG("CFG->rasterscan:0x%x", CFG->rasterscan);        /**< enable raster recon yuv dump on FPGA & HW for debug */

    CFG_WRITE_LOG("CFG->parallelCoreNum:0x%x", CFG->parallelCoreNum);      /*Num of Core used by one encoder instance */

        /* Multipass coding config, currently only for internal test purpose */
    CFG_WRITE_LOG("CFG->pass:0x%x", CFG->pass);
    CFG_WRITE_LOG("CFG->bPass1AdaptiveGop:0x%x", CFG->bPass1AdaptiveGop);
    CFG_WRITE_LOG("CFG->lookaheadDepth:0x%x", CFG->lookaheadDepth);
    CFG_WRITE_LOG("CFG->extDSRatio:0x%x", CFG->extDSRatio);     /* external downsample ratio for first pass. 0=1/1 (no downsample), 1=1/2 downsample */
    CFG_WRITE_LOG("CFG->inLoopDSRatio:0x%x", CFG->inLoopDSRatio);     /* in-loop downsample ratio for first pass. 0=1/1 (no downsample), 1=1/2 downsample */
    CFG_WRITE_LOG("CFG->cuInfoVersion:0x%x", CFG->cuInfoVersion);     /* cuInfo version; -1: decide by VC8000E and HW support; 0,1,2: different cuInfo version */
    CFG_WRITE_LOG("CFG->gopSize:0x%x", CFG->gopSize);        /* sequence level GOP size, set gopSize=0 for adaptive GOP size. */

        /** MMU*/
    CFG_WRITE_LOG("CFG->mmuEnable:0x%x", CFG->mmuEnable);

        /** slice node */
    CFG_WRITE_LOG("CFG->slice_idx:0x%x", CFG->slice_idx);

        /*external SRAM*/
    CFG_WRITE_LOG("CFG->extSramLumHeightBwd:0x%x", CFG->extSramLumHeightBwd);
    CFG_WRITE_LOG("CFG->extSramChrHeightBwd:0x%x", CFG->extSramChrHeightBwd);
    CFG_WRITE_LOG("CFG->extSramLumHeightFwd:0x%x", CFG->extSramLumHeightFwd);
    CFG_WRITE_LOG("CFG->extSramChrHeightFwd:0x%x", CFG->extSramChrHeightFwd);

        /* AXI alignment */
    CFG_WRITE_LOG("CFG->AXIAlignment:0x%x", CFG->AXIAlignment);     // bit[31:28] AXI_burst_align_wr_common
                        // bit[27:24] AXI_burst_align_wr_stream
                        // bit[23:20] AXI_burst_align_wr_chroma_ref
                        // bit[19:16] AXI_burst_align_wr_luma_ref
                        // bit[15:12] AXI_burst_align_rd_common
                        // bit[11: 8] AXI_burst_align_rd_prp
                        // bit[ 7: 4] AXI_burst_align_rd_ch_ref_prefetch
                        // bit[ 3: 0] AXI_burst_align_rd_lu_ref_prefetch

    CFG_WRITE_LOG("CFG->codedChromaIdc:0x%x", CFG->codedChromaIdc);     /**< select the chroma_format_idc coded in SPS.
                                                0:YUV400, 1:YUV420. see \ref ss_chmfmt */
    CFG_WRITE_LOG("CFG->tune:0x%x", CFG->tune);       /**< 0..9 Tune psnr/ssim/visual/sharpness_visual by forcing some encoding
                                    parameters. Default 0. \see ss_tune
                                    0 = tune psnr:   aq_mode=0, psyFactor=0
                                    1 = tune ssim:   aq_mode=2, psyFactor=0
                                    2 = tune visual: aq_mode=2, psyFactor=0.75
                                    3 = tune sharpness visual: aq_mode=2, psyFactor=0.75, inLoopDSRatio=0, enableRdoQuant=0
                                    4~9 = reserved */

    CFG_WRITE_LOG("CFG->writeReconToDDR:0x%x", CFG->writeReconToDDR);     /**< HW write recon to DDR or not if it's pure I-frame encoding*/

    CFG_WRITE_LOG("CFG->TxTypeSearchEnable:0x%x", CFG->TxTypeSearchEnable);     /**< av1 tx type search 1=enable 0=disable, enabled by default*/
    CFG_WRITE_LOG("CFG->av1InterFiltSwitch:0x%x", CFG->av1InterFiltSwitch);     /**< av1 interp filter switchable. 1=enable 0=disable, enabled by default*/

    CFG_WRITE_LOG("CFG->fileListExist:0x%x", CFG->fileListExist);     /**< file list exist flag. 1=exist 0=not exist*/

    CFG_WRITE_LOG("CFG->burstMaxLength:0x%x", CFG->burstMaxLength);     /**< AXI max burst length */

    if (str_flag == NULL) {
        fprintf(logFd, "%s end! \n\n", __func__);
    } else {
        fprintf(logFd, "%s end! \n\n", str_flag);
    }

    fprintf(logFd, "\n");
    fflush(logFd);
    return 0;
}




