#ifndef _AX_UTILS_H_
#define _AX_UTILS_H_


#include "ax_global_type.h"
#include "ax_comm_venc.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MaxJencHeight 32768
#define MaxJencWidth 32768
#define MinJencHeight 32
#define MinJencWidth 32
#define MaxH264Height 4188
#define MaxH264Width 5584
#define MinH264Height 136
#define MinH264Width 136
#define MaxH265Height 4188
#define MaxH265Width 5584
#define MinH265Height 144
#define MinH265Width 144

AX_S32 VencChnAttrCheck(VENC_CHN VeChn, const AX_VENC_CHN_ATTR_S *pstAttr);

AX_BOOL VencIsFrameRateCtrlDrop(AX_U32 srcFramerate, AX_U32 dstFramerate, AX_U64 u64FrameIndex);

AX_BOOL VencIsFrameRateCtrlEnlarge(AX_U32 srcFramerate, AX_U32 dstFramerate, AX_U64 u64FrameIndex);

AX_U32 VencTimeDiff(struct timeval end, struct timeval start);

#ifdef __cplusplus
}
#endif

#endif
