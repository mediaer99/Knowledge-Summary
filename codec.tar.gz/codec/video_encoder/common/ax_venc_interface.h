/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/

#ifndef _AX_VENC_INTERFACE_H_
#define _AX_VENC_INTERFACE_H_

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ax_global_type.h"
#include "ax_comm_codec.h"
#include "ax_comm_venc.h"
#include "ax_comm_venc_rc.h"
#include "ax_fifo.h"
#include "ringbuffer.h"
#include "ax_userdata_queue.h"

#ifdef __cplusplus
extern "C" {
#endif

#define STREAM_BUFFER_SIZE (10 * 1024 * 1024)
#define STREAM_BUFFER_MARGIN (1 * 1024 * 1024)

#define VENC_DEVICE_NAME	"/dev/venc"
#define JENC_DEVICE_NAME	"/dev/ax_jenc"

#define AX_VENC_LOOP_THREAD_NUM  (3)
/*
* The DDR address could be accessed by CODEC HW is different from CPU,
* must do offset
*/
#define VENC_ADDR_OFFSET (0x40000000)

typedef struct axVENC_ENCODER_S
{
	AX_PAYLOAD_TYPE_E enType;

	AX_S32 (*pfnCreateChn)(AX_S32 VeChn, const AX_VENC_CHN_ATTR_S *pstAttr, AX_VOID *pCtx);
	AX_S32 (*pfnDestroyChn)(AX_VOID *pCtx);

	AX_S32 (*pfnSendFrame)(AX_VOID *pCtx, const AX_VIDEO_FRAME_INFO_S *pstFrame , AX_S32 s32MilliSec);
	AX_S32 (*pfnSendFrameEx)(AX_VOID *pCtx, const AX_USER_FRAME_INFO_S *pstFrame, AX_S32 s32MilliSec);

	AX_S32 (*pfnGetStream)(AX_VOID *pCtx, AX_VENC_STREAM_S *pstStream, AX_S32 AX_S32MilliSec);
	AX_S32 (*pfnReleaseStream)(AX_VOID *pCtx, const AX_VENC_STREAM_S *pstStream);

	AX_S32 (*pfnStartRecvFrame)(AX_VOID *pCtx, const AX_VENC_RECV_PIC_PARAM_S *pstRecvParam);
	AX_S32 (*pfnStopRecvFrame)(AX_VOID *pCtx);

#if 0
	AX_S32 (*pfnSetOsdLayer)(AX_VOID *pCtx, const AX_OSD_BMP_ATTR_S *pstOSDAttr);
	AX_S32 (*pfnRefreshOsdLayer)(AX_VOID *pCtx, AX_U32 u32OsdIndex, AX_U8* pBitmap);
	AX_S32 (*pfnResetOsd)(AX_VOID *pCtx);
#endif

	AX_S32 (*pfnSetRoiAttr)(AX_VOID *pCtx, const AX_VENC_ROI_ATTR_S *pstRoiAttr);
	AX_S32 (*pfnGetRoiAttr)(AX_VOID *pCtx, AX_U32 u32Index, AX_VENC_ROI_ATTR_S *pstRoiAttr);

	AX_S32 (*pfnSetRcParam)(AX_VOID *pCtx, const AX_VENC_RC_PARAM_S *pstRcParam);
	AX_S32 (*pfnGetRcParam)(AX_VOID *pCtx, AX_VENC_RC_PARAM_S *pstRcParam);

	AX_S32 (*pfnSetChnAttr)(AX_VOID *pCtx, const AX_VENC_CHN_ATTR_S *pstChnAttr);
	AX_S32 (*pfnGetChnAttr)(AX_VOID *pCtx, AX_VENC_CHN_ATTR_S *pstChnAttr);

	AX_S32 (*pfnSetSpsVuiParam)(AX_VOID *pCtx, const AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam);
	AX_S32 (*pfnGetSpsVuiParam)(AX_VOID *pCtx, AX_VENC_SPS_VUI_PARAM_S *pstSpsVuiParam);

	AX_S32 (*pfnSetRateJamStrategyParam)(AX_VOID *pCtx, const AX_VENC_RATE_JAM_CFG_S *pstRateJamParam);
	AX_S32 (*pfnGetRateJamStrategyParam)(AX_VOID *pCtx, AX_VENC_RATE_JAM_CFG_S *pstRateJamParam);

	AX_S32 (*pfnSetSuperFrameCfg)(AX_VOID *pCtx, const AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg);
	AX_S32 (*pfnGetSuperFrameCfg)(AX_VOID *pCtx, AX_VENC_SUPERFRAME_CFG_S *pstSuperFrameCfg);

	AX_S32 (*pfnInsertUserData)(AX_VOID *pCtx, const AX_U8 *pu8Data, AX_U32 u32Len);

	AX_S32 (*pfnRequestIDR)(AX_VOID *pCtx, AX_BOOL bInstant);
	AX_S32 (*pfnQueryStatus)(AX_VOID *pCtx, AX_VENC_CHN_STATUS_S *pstStatus);

	AX_VOID (*pfnUpdateFpsBr)(AX_VOID *pCtx);
	AX_VOID (*pfnUpdateCvbrShortBps)(AX_VOID *pCtx);
    AX_VOID (*pfnUpdateCvbrLongBps)(AX_VOID *pCtx);

	AX_S32 (*pfnSetJpegParam)(AX_VOID *pCtx, const AX_VENC_JPEG_PARAM_S *pstJpegParam);
	AX_S32 (*pfnGetJpegParam)(AX_VOID *pCtx, AX_VENC_JPEG_PARAM_S *pstJpegParam);

	AX_S32 (*pfnJpegEncodeOnceInit)();
	AX_S32 (*pfnJpegEncodeOnceDeinit)();
	AX_S32 (*pfnJpegEncodeOnce)(AX_JPEG_ENCODE_ONCE_PARAMS *pstParam);
} AX_VENC_ENCODER_S;

typedef enum {
	VENC_MOD_UNINIT = 0,
	VENC_MOD_INITING,
	VENC_MOD_INITED
} AX_VENC_MOD_STATUS_E;

typedef enum {
	VENC_CHN_STATE_CREATED,
	VENC_CHN_STATE_STARTED,
	VENC_CHN_STATE_STOPPED,
	VENC_CHN_STATE_DESTROYING,
	VENC_CHN_STATE_DESTROYED,
	VENC_CHN_STATE_RESETED,
} AX_VENC_CHN_STATUS_E;

typedef enum {
	VENC_STATE_MACHINE_NORMAL = 0,
	VENC_STATE_MACHINE_ENLARGE,
}AX_VENC_STATE_MACHINE_E;

typedef struct ax_VENC_CHN_INSTANCE_S {
	VENC_CHN ChnId;
	AX_PAYLOAD_TYPE_E enType;
	const AX_VENC_ENCODER_S *pEncoder;
	AX_VOID *pHalCtx;
	FifoInst inputQueue;
	FifoInst outputQueue;
	ringbuffer_t *pstRingBuf;
	AX_USERDATA_BUFFER_QUEUE_S *pstUserDataBufferQueue;

	AX_BOOL bSendFrmAbort;
	AX_BOOL bGetStrmAbort;
	AX_BOOL bReleaseStrmEnd;

	AX_ENCODR_METADATA_INFO_S stFrameInfo;
	AX_ENCODR_METADATA_INFO_S stStreamInfo;

	AX_VENC_CHN_ATTR_S stVencChnAttr;

	/* dump stream */
	FILE *fDumpStream;
	char pDumpStream[50];

	/* dump frame */
	FILE *fDumpFrame;
	char pDumpFrame[50];

	/* fd for kfifo */
	AX_S32 devFd;
	AX_S8 devName[50];
    AX_BOOL bRequestIDR;
    AX_BOOL bInstant;


	AX_S32 s32FrameSize;
	AX_S32 s32FrameIndex;
	AX_U64 u64FrameEncodeIndex;
	AX_U32 dst_frameRate;
	AX_U32 src_frameRate;
	AX_F32 F32RealTimeFrameRate;
	AX_U64 u64RealTimeBitRate;
	AX_U64 u64InstantaneousBitRate;
	/*for CVBR start */
    AX_U64 u64ShortTermBitRate;
    struct timeval timeGetShortTermFrmEncodeStart;
	struct timeval timeGetFrmEncodeStartForShortTermBps;
    AX_U64 u64LongTermBitRate;
    struct timeval timeGetLongTermFrmEncodeStart;
	struct timeval timeGetFrmEncodeStartForLongTermBps;
    /*for CVBR end*/
	/* re-encode status */
	AX_U64 u64ReEncodeCount;
	AX_U64 u64DiscardCount;
	/* for debug */
	AX_U64 u64TotalRecvFrameNum;
	AX_U64 u64TotalReleaseFrameNum;
	AX_U64 u64TotalEncodeNum;
	AX_U64 u64TotalGetStrmNum;
	AX_U64 u64TotalReleaseStrmNum;
	AX_U64 u64TotalBlkGetFailNum;
	AX_U64 u64LeftStreamBytes;
	/* for proc */
	AX_U64 u64PerSecondStrmSize;
	AX_U64 u64ShortTermtrmSize;
    AX_U64 u64LongTermtrmSize;
	struct timeval timeGetFrmEncodeStart;
	struct timeval timeGetFrmEncodeStartForInstantBps;
	AX_U64 u64StatisticalEncodeFrm;
	AX_U32 u64EncodeFrmNumForInstantaneousBps;
	AX_U32 u64InstantaneousEncodeStrmSize;
	AX_U64 u64HwBufferOverflowCount;
	AX_U64 u64HwTimeOutCount;
	AX_VENC_ROI_ATTR_S  stVencRoiAttr[MAX_ROI_NUM];

	AX_VENC_STATE_MACHINE_E enStateMachine;
} AX_VENC_CHN_INSTANCE_S;

typedef struct AX_VENC_SELECT_GRP
{
	AX_U32 u32ChanNum;
	AX_U32 u32VencChan[MAX_VENC_NUM];

	AX_BOOL bEncSelectCondInit;
	pthread_mutex_t stEncSelectMutex;
	pthread_condattr_t stEncSelectCondAttr;
	pthread_cond_t stEncSelectCond;
}AX_VENC_SELECT_GRP;

typedef struct ax_JPEG_ENCODE_ONE_FRAME_INSTANCE_S {
	const AX_VENC_ENCODER_S *pEncoder;
} AX_JPEG_ENCODE_ONE_FRAME_INSTANCE_S;

typedef struct ax_VENC_MOD_INSTANCE_S {
	pthread_mutex_t stModMuxtex;
	AX_VENC_MOD_STATUS_E enModState;
	AX_VENC_ENCODER_TYPE_E enType;
	AX_VENC_CHN_STATUS_E enChnState[MAX_VENC_NUM];
	pthread_mutex_t stChnStateMutex[MAX_VENC_NUM];

	AX_BOOL bEncSelectCondInit;
	pthread_condattr_t stEncSelectCondAttr;
	pthread_mutex_t stEncSelectMutex;
	pthread_cond_t stEncSelectCond;

	AX_VENC_SELECT_GRP stVencSelectGrp[MAX_VENC_GRP_NUM];
	VENC_GRP vencGrpId[MAX_VENC_NUM];

	AX_PAYLOAD_TYPE_E enChnCodecType[MAX_VENC_NUM];

	/* reserved for venc */
	pthread_t vencTid[AX_VENC_LOOP_THREAD_NUM];
	pthread_mutex_t stVencMutex[AX_VENC_LOOP_THREAD_NUM];
	pthread_condattr_t stVencCondAttr[AX_VENC_LOOP_THREAD_NUM];
	pthread_cond_t stVencCond[AX_VENC_LOOP_THREAD_NUM];
	AX_BOOL isVencEncodeLoopExit[AX_VENC_LOOP_THREAD_NUM];
	AX_BOOL isVencEnterSleep[AX_VENC_LOOP_THREAD_NUM];
	AX_U32 encodeThreadIndex[AX_VENC_LOOP_THREAD_NUM];
	AX_U32 VencChnLoopIndex[MAX_VENC_NUM];
	AX_BOOL isVencWaitUnlock;

	/* reserved for jenc */
	pthread_t jencTid;
	pthread_mutex_t stJencMutex;
	pthread_condattr_t stJencCondAttr;
	pthread_cond_t stJencCond;
	AX_BOOL isJencEncodeLoopExit;
	AX_BOOL isVencEncodeLoopCreate[AX_VENC_LOOP_THREAD_NUM];
	AX_BOOL isJencEncodeLoopCreate;
	AX_BOOL isJencEnterSleep;
	AX_BOOL isJencWaitUnlock;

} AX_VENC_MOD_INSTANCE_S;


AX_VENC_ENCODER_S gVencEncoder;
AX_VENC_ENCODER_S gJencEncoder;

extern AX_VOID* VencEncodeLoop(AX_VOID *loopIndex);
extern AX_VOID* JencEncodeLoop(AX_VOID *pCtx);

#ifdef __cplusplus
}
#endif

#endif
