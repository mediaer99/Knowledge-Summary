/*--------------------------------------------------------------------------------
--                                                                              --
--       This software is confidential and proprietary and may be used          --
--        only as expressly authorized by a licensing agreement from            --
--                                                                              --
--                            Verisilicon.                                      --
--                                                                              --
--                   (C) COPYRIGHT 2020 VERISILICON                             --
--                            ALL RIGHTS RESERVED                               --
--                                                                              --
--                 The entire notice above must be reproduced                   --
--                  on all copies and should not be removed.                    --
--                                                                              --
--------------------------------------------------------------------------------*/

/* This file is generated. Please don't edit, don't change. */

#define VCENC_BUILD_CLNUM 323274

