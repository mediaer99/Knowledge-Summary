/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2014 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : VC8000 Encoder API
--
------------------------------------------------------------------------------*/

#ifndef VIDEO_STREAM_CTRL_H
#define VIDEO_STREAM_CTRL_H

#include "hevcencapi.h"

/* stream control information */
typedef struct
{
  u32 width;
  u32 height;
} VCEncStrmCtrl;

/**
 * @brief VCEncSetStrmCtrl(), Set stream control.In previous VC8000E software, there's no way to
 *        change sequence level parameters such as width height etc dynamically.
 *        To support related requirement, this new API named VCEncSetStrmCtrl is designed.
 * @param VCEncInst inst: encoder instance.
 * @param VCEncStrmCtrl*params: stream control params.
 * @return VCEncRet: VCENC_OK successful, other unsuccessful.
 */
VCEncRet VCEncSetStrmCtrl(VCEncInst inst, VCEncStrmCtrl*params, u32 changeEncodeType);

VCEncRet VCEncSetResolution(VCEncInst inst, int width, int height);

#endif
