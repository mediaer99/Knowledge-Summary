/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2019 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Abstract : VC8000 CODEC Wrapper Layer
--
------------------------------------------------------------------------------*/
#ifndef __CWL_VC8000_VCMD_COMMON_H__
#define __CWL_VC8000_VCMD_COMMON_H__

#include "base_type.h"
#include "osal.h"
#include "vc8000_driver.h"

void CWLCollectWriteRegData(u32* src, u32* dst,u16 reg_start, u32 reg_length,u32* total_length);
void CWLCollectStallData(u32* dst,u32* total_length,u32 interruput_mask);
void CWLCollectReadRegData(u32* dst,u16 reg_start, u32 reg_length,u32* total_length,ptr_t status_data_base_addr);
void CWLCollectNopData(u32* dst,u32* total_length);
void CWLCollectIntData(u32* dst,u16 int_vecter,u32* total_length);
void CWLCollectJmpData(u32* dst,u32* total_length,u16 cmdbuf_id);
void CWLCollectClrIntData(u32* dst,u32 clear_type,u16 interrupt_reg_addr,u32 bitmask,u32* total_length);

#endif /* __CWL_VC8000_VCMD_COMMON_H__ */
