/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--                   (C) COPYRIGHT 2019 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
--------------------------------------------------------------------------------

--
--  Abstract : Encoder Wrapper Layer, common parts
--
------------------------------------------------------------------------------*/
#include "ewl.h"

#undef PTRACE
#ifdef TRACE_EWL
#   include <stdio.h>
static const char *busTypeName[7] = { "UNKNOWN", "AHB", "OCP", "AXI", "PCI", "AXIAHB", "AXIAPB" };
#   define PTRACE(...) printf("%s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__)
#else
#   define PTRACE(...) /* no trace */
#endif

u32* EWLLoadAsicConfig(u32 *regs, u32 *configs)
{
    if (!regs || !configs) return NULL;

    u32 hw_id = configs[0] = regs[0];
    configs[1] = regs[HWIF_REG_CFG1];
    configs[2] = (hw_id >= 0x80006001) ? regs[HWIF_REG_CFG2] : 0;
    configs[3] = (hw_id >= 0x80006010) ? regs[HWIF_REG_CFG3] : 0;
    configs[4] = (hw_id >= 0x80006010) ? regs[HWIF_REG_CFG4] : 0;
    configs[5] = (hw_id >= 0x80006010) ? regs[HWIF_REG_CFG5] : 0;
    configs[6] = (hw_id >= 0x80006010) ? regs[HWIF_REG_CFGAXI] : 0;

    return configs;
}

void EWLParseAsicConfig(EWLHwConfig_t     *cfg_info, u32 *configs)
{
    if (!configs || !cfg_info) return;
    memset(cfg_info, 0, sizeof(EWLHwConfig_t));

    u32 hw_id = configs[0];
    u32 cfgval = configs[1];
    cfg_info->h264Enabled = (cfgval >> 31) & 1;
    cfg_info->scalingEnabled = (cfgval >> 30) & 1;
    cfg_info->bFrameEnabled = (cfgval >> 29) & 1;
    cfg_info->rgbEnabled = (cfgval >> 28) & 1;
    cfg_info->hevcEnabled = (cfgval >> 27) & 1;
    cfg_info->vp9Enabled = (cfgval >> 26) & 1;
    cfg_info->deNoiseEnabled = (cfgval >> 25) & 1;
    cfg_info->main10Enabled = (cfgval >> 24) & 1;
    cfg_info->busType = (cfgval >> 21) & 7;
    cfg_info->cavlcEnable = (cfgval >> 20) & 1;
    cfg_info->lineBufEnable = (cfgval >> 19) & 1;
    cfg_info->progRdoEnable = (cfgval >> 18) & 1;
    cfg_info->rfcEnable = (cfgval >> 17) & 1;
    cfg_info->tu32Enable = (cfgval >> 16) & 1;
    cfg_info->jpegEnabled = (cfgval >> 15) & 1;
    cfg_info->busWidth = (cfgval >> 13) & 3;
    cfg_info->maxEncodedWidthH264 =
        cfg_info->maxEncodedWidthJPEG =
            cfg_info->maxEncodedWidthHEVC = cfgval & ((1 << 13) - 1);

    if (hw_id >= 0x80006001) {
        cfgval = configs[2];
        cfg_info->ljpegSupport = (cfgval >> 31) & 1;
        cfg_info->roiAbsQpSupport = (cfgval >> 30) & 1;
        cfg_info->intraTU32Enable = (cfgval >> 29) & 1;
        cfg_info->roiMapVersion = (cfgval >> 26) & 7;
        if (hw_id >= 0x80006010) {
            cfg_info->maxEncodedWidthHEVC <<= 3;
            cfg_info->maxEncodedWidthH264 = ((cfgval >> 13) & ((1 << 13) - 1)) << 3;
            cfg_info->maxEncodedWidthJPEG = (cfgval & ((1 << 13) - 1)) << 3;
        }
    }

    if (hw_id >= 0x80006010) {
        cfgval = configs[3];
        cfg_info->ssimSupport = (cfgval >> 31) & 1;
        cfg_info->P010RefSupport = (cfgval >> 30) & 1;
        cfg_info->cuInforVersion = (cfgval >> 27) & 7;
        cfg_info->meVertSearchRangeHEVC = (cfgval >> 21) & 0x3f;
        cfg_info->meVertSearchRangeH264 = (cfgval >> 15) & 0x3f;
        cfg_info->ctbRcVersion = (cfgval >> 12) & 7;
        cfg_info->jpeg422Support = (cfgval >> 11) & 1;
        cfg_info->gmvSupport = (cfgval >> 10) & 1;
        cfg_info->ROI8Support = (cfgval >> 9) & 1;
        cfg_info->meHorSearchRangeBframe = (cfgval >> 7) & 3;
        cfg_info->RDOQSupportHEVC = (cfgval >> 6) & 1;
        cfg_info->bMultiPassSupport = (cfgval >> 5) & 1;
        cfg_info->inLoopDSRatio = (cfgval >> 4) & 1;
        cfg_info->streamBufferChain = (cfgval >> 3) & 1;
        cfg_info->streamMultiSegment = (cfgval >> 2) & 1;
        cfg_info->IframeOnly = (cfgval >> 1) & 1;
        cfg_info->dynamicMaxTuSize = (cfgval & 1);
    }

    if (hw_id >= 0x80006010) {
        cfgval = configs[4];
        cfg_info->videoHeightExt = (cfgval >> 31) & 1;
        cfg_info->cscExtendSupport = (cfgval >> 30) & 1;
        cfg_info->scaled420Support = (cfgval >> 29) & 1;
        cfg_info->cuTreeSupport = (cfgval >> 28) & 1;
        cfg_info->maxAXIAlignment = (cfgval >> 24) & 0xf;
        cfg_info->meVertRangeProgramable = (cfgval >> 22) & 1;
        cfg_info->MonoChromeSupport  = (cfgval >> 21) & 1;
        cfg_info->ExtSramSupport  = (cfgval >> 20) & 1;
        cfg_info->vsSupport = (cfgval >> 19) & 1;
        cfg_info->RDOQSupportH264 = (cfgval >> 18) & 1;
        cfg_info->disableRecWtSupport = (cfgval >> 17) & 1;
        cfg_info->OSDSupport = (cfgval >> 16) & 1;
        cfg_info->H264NalRefIdc2bit = (cfgval >> 15) & 1;
        cfg_info->dynamicRdoSupport = (cfgval >> 14) & 1;
        cfg_info->av1Enabled = (cfgval >> 13) & 1;
        cfg_info->maxEncodedWidthAV1 = cfgval & 0x1fff;

        cfgval = configs[5];
        cfg_info->RDOQSupportAV1 = (cfgval >> 31) & 1;
        cfg_info->av1InterpFilterSwitchable = (cfgval >> 30) & 1;
        cfg_info->JpegRoiMapSupport = (cfgval >> 29) & 1;
        cfg_info->backgroundDetSupport = (cfgval >> 28) & 1;
        cfg_info->RDOQSupportVP9 = (cfgval >> 27) & 1;
        cfg_info->CtbBitsOutSupport = (cfgval >> 26) & 1;
        cfg_info->encVisualTuneSupport = (cfgval >> 25) & 1;
        cfg_info->encPsyTuneSupport = (cfgval >> 24) & 1;
        cfg_info->NonRotationSupport = (cfgval >> 23) & 1;
        cfg_info->NVFormatOnlySupport = (cfgval >> 22) & 1;
        cfg_info->MosaicSupport = (cfgval >> 21) & 1;
        cfg_info->IPCM8Support  = (cfgval >> 20) & 1;
        cfg_info->psnrSupport = (cfgval >> 18) & 1;
        cfg_info->prpSbiSupport = (cfgval >> 17) & 1;

        cfgval = configs[6];
        cfg_info->AXIAlignFuse = cfgval;
    }

    PTRACE("EWLReadAsicConfig:\n"
           "    maxEncodedWidthHEVC   = %d\n"
           "    maxEncodedWidthH264   = %d\n"
           "    maxEncodedWidthJPEG   = %d\n"
           "    hevcEnabled       = %s\n"
           "    h264Enabled       = %s\n"
           "    vp9Enabled        = %s\n"
           "    rgbEnabled        = %s\n"
           "    scalingEnabled    = %s\n"
           "    busType           = %s\n"
           "    busWidth          = %d\n"
           "    bFrameEnabled     = %s\n"
           "    deNoiseEnabled       = %s\n"
           "    main10Enabled       = %s\n"
           "    cavlcEnable       = %s\n"
           "    lineBufEnable       = %s\n"
           "    progRdoEnable       = %s\n"
           "    rfcEnable       = %s\n"
           "    tu32Enable       = %s\n"
           "    jpegEnabled       = %s\n"
           "    ljpegEnabled       = %s\n"
           "    absqpEnabled       = %s\n"
           "    IntraTU32x32Enabled       = %s\n"
           "    roiMapVersion       = %d\n"
           "    ssimEnabled         = %s\n"
           "    P010RefEnabled      = %s\n"
           "    cuInforVersion      = %d\n"
           "    meVerticalSearchRangeHEVC      = +- %d\n"
           "    meVerticalSearchRangeH264        = +- %d\n"
           "    ctbRcVersion        = %d\n"
           "    jpeg422Enabled       = %s\n"
           "    gmvSupport          = %s\n"
           "    ROI8Support         = %s\n"
           "    me4nHorizontalSearchRange      = +- %d\n"
           "    RDOQSupportHEVC     = %s\n"
           "    MultiPassSupport     = %s\n"
           "    inLoopDSRatio        = %s\n"
           "    streamBufferChain    = %s\n"
           "    streamMultiSegment   = %s\n"
           "    IframeOnly        = %s\n"
           "    dynamicMaxTuSize     = %s\n"
           "    videoHeightExt       = %s\n"
           "    colorConversionExt   = %s\n"
           "    scaled420Support    = %s\n"
           "    cuTreeSupport    = %s\n"
           "    maxAXIAlignment    = %d\n"
           "    meVertRangeProgramable    = %s\n"
           "    ExtSramSupport    = %s\n"
           "    RDOQSupportH264   = %s\n"
           "    disableRecWtSupport   = %s\n"
           "    IPCM8Support         = %s\n"
           "    psnrEnabled         = %s\n"
           "    prpSbiSupport         = %s\n",
           cfg_info->maxEncodedWidthHEVC,
           cfg_info->maxEncodedWidthH264,
           cfg_info->maxEncodedWidthJPEG,
           cfg_info->hevcEnabled == 1 ? "YES" : "NO",
           cfg_info->h264Enabled == 1 ? "YES" : "NO",
           cfg_info->vp9Enabled == 1 ? "YES" : "NO",
           cfg_info->rgbEnabled == 1 ? "YES" : "NO",
           cfg_info->scalingEnabled == 1 ? "YES" : "NO",
           cfg_info->busType < 7 ? busTypeName[cfg_info->busType] : "UNKNOWN",
           (cfg_info->busWidth + 1) * 32,
           cfg_info->bFrameEnabled == 1 ? "YES" : "NO",
           cfg_info->deNoiseEnabled == 1 ? "YES" : "NO",
           cfg_info->main10Enabled == 1 ? "YES" : "NO",
           cfg_info->cavlcEnable == 1 ? "YES" : "NO",
           cfg_info->lineBufEnable == 1 ? "YES" : "NO",
           cfg_info->progRdoEnable == 1 ? "YES" : "NO",
           cfg_info->rfcEnable == 1 ? "YES" : "NO",
           cfg_info->tu32Enable == 1 ? "YES" : "NO",
           cfg_info->jpegEnabled == 1 ? "YES" : "NO",
           cfg_info->ljpegSupport == 1 ? "YES" : "NO",
           cfg_info->roiAbsQpSupport == 1 ? "YES" : "NO",
           cfg_info->intraTU32Enable == 1 ? "YES" : "NO",
           cfg_info->roiMapVersion,
           cfg_info->ssimSupport == 1 ? "YES" : "NO",
           cfg_info->P010RefSupport == 1 ? "YES" : "NO",
           cfg_info->cuInforVersion,
           (cfg_info->meVertSearchRangeHEVC == 0) ? 40 : (cfg_info->meVertSearchRangeHEVC << 3),
           (cfg_info->meVertSearchRangeH264 == 0) ? 24 : (cfg_info->meVertSearchRangeH264 << 3),
           cfg_info->ctbRcVersion,
           cfg_info->jpeg422Support == 1 ? "YES" : "NO",
           cfg_info->gmvSupport == 1 ? "YES" : "NO",
           cfg_info->ROI8Support == 1 ? "YES" : "NO",
           ((cfg_info->meHorSearchRangeBframe + 1) << 6),
           cfg_info->RDOQSupportHEVC == 1 ? "YES" : "NO",
           cfg_info->bMultiPassSupport == 1 ? "YES" : "NO",
           cfg_info->inLoopDSRatio == 1 ? "YES" : "NO",
           cfg_info->streamBufferChain == 1 ? "YES" : "NO",
           cfg_info->streamMultiSegment == 1 ? "YES" : "NO",
           cfg_info->IframeOnly == 1 ? "YES" : "NO",
           cfg_info->dynamicMaxTuSize == 1 ? "YES" : "NO",
           cfg_info->videoHeightExt == 1 ? "YES" : "NO",
           cfg_info->cscExtendSupport == 1 ? "YES" : "NO",
           cfg_info->scaled420Support == 1 ? "YES" : "NO",
           cfg_info->cuTreeSupport == 1 ? "YES" : "NO",
           cfg_info->maxAXIAlignment,
           cfg_info->meVertRangeProgramable == 1 ? "YES" : "NO",
           cfg_info->ExtSramSupport == 1 ? "YES" : "NO",
           cfg_info->RDOQSupportH264 == 1 ? "YES" : "NO",
           cfg_info->disableRecWtSupport == 1 ? "YES" : "NO",
           cfg_info->IPCM8Support == 1 ? "YES" : "NO",
           cfg_info->psnrSupport == 1 ? "YES" : "NO",
           cfg_info->prpSbiSupport == 1 ? "YES" : "NO"
          );
}


