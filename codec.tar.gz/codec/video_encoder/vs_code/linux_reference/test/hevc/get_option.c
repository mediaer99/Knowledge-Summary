/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Verisilicon.                                    --
--                                                                            --
--      In the event of publication, the following notice is applicable:      --
--                                                                            --
--                   (C) COPYRIGHT 2014 VERISILICON                           --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
------------------------------------------------------------------------------*/

#include <math.h>
#include "vsi_string.h"
#include "osal.h"

#include "base_type.h"
//#include "version.h"
#include "error.h"

#include "HevcTestBench.h"
#include "test_bench_utils.h"
#include "get_option.h"
//#include "instance.h"

#define MAXARGS 128
#define CMDLENMAX 256


static struct option options[] =
{
  {"help",    'H', 2},
  {"firstPic", 'a', 1},
  {"lastPic",  'b', 1},
  {"width", 'x', 1},
  {"height", 'y', 1},
  {"lumWidthSrc", 'w', 1},
  {"lumHeightSrc", 'h', 1},
  {"horOffsetSrc", 'X', 1},
  {"verOffsetSrc", 'Y', 1},
  {"inputFormat", 'l', 1},        /* Input image format */
  {"colorConversion", 'O', 1},    /* RGB to YCbCr conversion type */
  {"rotation", 'r', 1},           /* Input image rotation */
  {"outputRateNumer", 'f', 1},
  {"outputRateDenom", 'F', 1},
  {"inputLineBufferMode", '0', 1},
  {"inputLineBufferDepth", '0', 1},
  {"inputLineBufferAmountPerLoopback", '0', 1},
  {"inputRateNumer", 'j', 1},
  {"inputRateDenom", 'J', 1},
  {"inputFileList", '0', 1},
   /*stride*/
  {"inputAlignmentExp", '0', 1},
  {"refAlignmentExp", '0', 1},
  {"refChromaAlignmentExp",  '0',  1},
  {"aqInfoAlignmentExp", '0', 1},
  {"formatCustomizedType", '0', 1},
  {"input",   'i', 1},
  {"output",    'o', 1},
#ifdef FBDC_ENABLE
  {"UVheaderSize",   '0', 1},
  {"UVpayloadSize",    '0', 1},
  {"YheaderSize", '0', 1},
  {"YpayloadSize", '0', 1},
  {"CropX", '0', 1},
  {"CropY", '0', 1},
#endif
  {"test_data_files", 'T', 1},
  {"cabacInitFlag", 'p', 1},
  {"qp_size",   'Q', 1},
  {"qpMinI", '0', 1},             /* Minimum frame header qp for I picture */
  {"qpMaxI", '0', 1},             /* Maximum frame header qp for I picture */
  {"qpMin", 'n', 1},              /* Minimum frame header qp for any picture */
  {"qpMax", 'm', 1},              /* Maximum frame header qp for any picture */
  {"qpHdr",     'q', 1},
  {"hrdConformance", 'C', 1},     /* HDR Conformance (ANNEX C) */
  {"cpbSize", 'c', 1},            /* Coded Picture Buffer Size */
  {"vbr", '0', 1},                /* Variable Bit Rate Control by qpMin */
  {"intraQpDelta", 'A', 1},       /* QP adjustment for intra frames */
  {"fixedIntraQp", 'G', 1},       /* Fixed QP for all intra frames */
  {"bFrameQpDelta", 'V', 1},       /* QP adjustment for B frames */
  {"byteStream", 'N', 1},         /* Byte stream format (ANNEX B) */
  {"bitPerSecond", 'B', 1},
  {"picRc",   'U', 1},
  {"ctbRc",   'u', 1},
  {"picSkip", 's', 1},            /* Frame skipping */
  {"profile",       'P', 1},   /* profile   (ANNEX A):support main and main still picture */
  {"level",         'L', 1},   /* Level * 30  (ANNEX A) */
  {"intraPicRate",  'R', 1},   /* IDR interval */
  {"bpsAdjust", '1', 1},          /* Setting bitrate on the fly */
  {"bitrateWindow", 'g', 1},          /* bitrate window of pictures length */
  {"disableDeblocking", 'D', 1},
  {"tc_Offset", 'W', 1},
  {"beta_Offset", 'E', 1},
  {"sliceSize", 'e', 1},
  {"chromaQpOffset", 'I', 1},     /* Chroma qp index offset */
  {"enableSao", 'M', 1},          /* Enable or disable SAO */
  {"videoRange", 'k', 1},
  {"sei", 'S', 1},                /* SEI messages */
  {"codecFormat", '0', 1},          /* select videoFormat: HEVC/H264/AV1 */
  {"enableCabac", 'K', 1},        /* H.264 entropy coding mode, 0 for CAVLC, 1 for CABAC */
  {"userData", 'z', 1},           /* SEI User data file */
  {"videoStab", 'Z', 1},          /* video stabilization */

  /* Only long option can be used for all the following parameters because
   * we have no more letters to use. All shortOpt=0 will be identified by
   * long option. */
  {"cir", '0', 1},
  {"cpbMaxRate", '0', 1},         /* max bitrate for CPB VBR/CBR */
  {"intraArea", '0', 1},
  {"ipcm1Area", '0', 1},
  {"ipcm2Area", '0', 1},
  {"ipcm3Area", '0', 1},
  {"ipcm4Area", '0', 1},
  {"ipcm5Area", '0', 1},
  {"ipcm6Area", '0', 1},
  {"ipcm7Area", '0', 1},
  {"ipcm8Area", '0', 1},
  {"roi1Area", '0', 1},
  {"roi2Area", '0', 1},
  {"roi1DeltaQp", '0', 1},
  {"roi2DeltaQp", '0', 1},
  {"roi1Qp", '0', 1},
  {"roi2Qp", '0', 1},
  {"roi3Area", '0', 1},
  {"roi3DeltaQp", '0', 1},
  {"roi3Qp", '0', 1},
  {"roi4Area", '0', 1},
  {"roi4DeltaQp", '0', 1},
  {"roi4Qp", '0', 1},
  {"roi5Area", '0', 1},
  {"roi5DeltaQp", '0', 1},
  {"roi5Qp", '0', 1},
  {"roi6Area", '0', 1},
  {"roi6DeltaQp", '0', 1},
  {"roi6Qp", '0', 1},
  {"roi7Area", '0', 1},
  {"roi7DeltaQp", '0', 1},
  {"roi7Qp", '0', 1},
  {"roi8Area", '0', 1},
  {"roi8DeltaQp", '0', 1},
  {"roi8Qp", '0', 1},

  {"layerInRefIdc", '0', 1},	  /*H264 2bit nal_ref_idc*/
  
  {"ipcmFilterDisable", '0', 1},

  {"roiMapDeltaQpBlockUnit", '0', 1},
  {"roiMapDeltaQpEnable", '0', 1},
  {"ipcmMapEnable", '0', 1},

  {"outBufSizeMax", '0', 1},

  {"constrainIntra", '0', 1},
  {"smoothingIntra", '0', 1},
  {"scaledWidth", '0', 1},
  {"scaledHeight", '0', 1},
  {"scaledOutputFormat", '0', 1},
  {"enableDeblockOverride", '0', 1},
  {"deblockOverride", '0', 1},
  {"enableScalingList", '0', 1},
  {"compressor", '0', 1},
  {"testId", '0', 1},            /* TestID for generate vector. */
  {"gopSize", '0', 1},
  {"gopConfig", '0', 1},
  {"gopLowdelay", '0', 1},
  {"LTR", '0', 1},
  {"flexRefs", '0', 1},    /* flexible reference list */
  {"interlacedFrame", '0', 1},
  {"fieldOrder", '0', 1},
  {"outReconFrame", '0', 1},
  {"tier", '0', 1},

  {"gdrDuration", '0', 1},
  {"bitVarRangeI", '0', 1},
  {"bitVarRangeP", '0', 1},
  {"bitVarRangeB", '0', 1},
  {"smoothPsnrInGOP", '0', 1},
  {"staticSceneIbitPercent", '0', 1},
  {"tolCtbRcInter", '0', 1},
  {"tolCtbRcIntra", '0', 1},
  {"ctbRowQpStep", '0', 1},

  {"tolMovingBitRate", '0', 1},
  {"monitorFrames", '0', 1},
  {"roiMapDeltaQpFile", '0', 1},
  {"roiMapDeltaQpBinFile", '0', 1},
  {"ipcmMapFile", '0', 1},
  {"roiMapInfoBinFile", '0', 1},
  {"RoimapCuCtrlInfoBinFile", '0', 1},
  {"RoimapCuCtrlIndexBinFile", '0', 1},
  {"RoiCuCtrlVer", '0', 1},
  {"RoiQpDeltaVer", '0', 1 },
  //WIENER_DENOISE
  {"noiseReductionEnable", '0', 1},
  {"noiseLow", '0', 1},
  {"noiseFirstFrameSigma", '0', 1},
  /* multi stream configs */
  {"multimode", '0', 1}, // Multi-stream mode, 0--disable, 1--mult-thread, 2--multi-process
  {"streamcfg", '0', 1}, // extra stream config.
  {"bitDepthLuma",   '0', 1},   /* luma bit depth */
  {"bitDepthChroma",   '0', 1},   /* chroma bit depth */
  {"blockRCSize",   '0', 1},   /*block rc size */
  {"rcQpDeltaRange",   '0', 1},   /* ctb rc qp delta range */
  {"rcBaseMBComplexity",   '0', 1},   /* ctb rc mb complexity base */
  {"picQpDeltaRange", '0', 1},
  {"enableOutputCuInfo", '0', 1},
  {"enableOutputCtbBits", '0', 1},   /* enable output ctb encoded bits */
  {"enableP010Ref", '0', 1},
  {"rdoLevel", '0', 1},
  {"enableDynamicRdo", '0', 1},
  {"dynamicCu16Bias", '0', 1},
  {"dynamicCu16Factor", '0', 1},
  {"dynamicCu32Bias", '0', 1},
  {"dynamicCu32Factor", '0', 1},
  {"enableRdoQuant", '0', 1},
  {"gmvList1File", '0', 1},
  {"gmvFile", '0', 1},
  {"gmvList1", '0', 1},
  {"gmv", '0', 1},

  {"enableSmartMode", '0', 1},  /* enable smart mode */
  {"smartConfig", '0', 1},  /* smart config file */
  {"mirror", '0', 1},  /* mirror */
  {"hashtype", '0', 1},  /* hash frame data, 0--disable, 1--crc32, 2--checksum */
  {"verbose", '0', 1}, /* print log verbose or not */
  /* constant chroma control */
  {"enableConstChroma", '0', 1}, /* enable constant chroma setting or not */
  {"constCb", '0', 1},           /* constant pixel value for CB */
  {"constCr", '0', 1},           /* constant pixel value for CR */

  {"sceneChange", '0', 1},
  {"enableVuiTimingInfo", '0', 1}, /* Write VUI timing info in SPS */
  {"lookaheadDepth", '0', 1},
  {"halfDsInput", '0', 1},  /* external 1/2 DS input yuv */
  {"inLoopDSRatio", '0', 1},  /* in-loop DS ratio */
  {"cuInfoVersion", '0', 1},

  {"ssim", '0', 1},
  {"psnr", '0', 1},
  {"tile", '0', 1},
  {"skipFramePOC", '0', 1},
  {"HDR10_display", '0', 1 },
  {"vuiColordescription", '0', 1},
  {"HDR10_lightlevel",'0', 1},
  {"vuiVideoFormat", '0', 1},    /* videoformat, 0--component, 1--PAL, 2--NTSC, 3--SECAM, 4--MAC, 5--UNDEF */
  {"vuiVideosignalPresent", '0', 1}, /* video signal type Present in vui, 0--NOT present, 1--present */
  {"vuiAspectRatio", '0', 1},
  {"RPSInSliceHeader",'0', 1},
  {"POCConfig", '0', 1},

  /* skip map */
  {"skipMapEnable", '0', 1},
  {"skipMapFile", '0', 1},
  {"skipMapBlockUnit", '0', 1},

  /* rdoq map */
  {"rdoqMapEnable", '0', 1},

  /* multi-core */
  {"parallelCoreNum",  '0', 1},   /* parallel core num */

  /* stream buffer chain */
  {"streamBufChain", '0', 1},

  /* stream multi-segment */
  {"streamMultiSegmentMode", '0', 1},
  {"streamMultiSegmentAmount", '0', 1},

  /*external sram*/
  {"extSramLumHeightBwd", '0', 1},
  {"extSramChrHeightBwd", '0', 1},
  {"extSramLumHeightFwd", '0', 1},
  {"extSramChrHeightFwd", '0', 1},

  /* AXI alignment */
  {"AXIAlignment", '0', 1},

  /* MMU */
  {"mmuEnable", '0', 1},

  /* sliceNode */
  {"sliceNode", '0', 1},
  
  /*register dump*/
  {"dumpRegister", '0', 1},
  /* raster scan output for recon on FPGA & HW */
  {"rasterscan", '0', 1},

  /*CRF constant*/
  {"crf", '0', 1},

  {"ivf", '0', 1},
  {"codedChromaIdc", '0', 1},

  /*ME vertical search range*/
  {"MEVertRange", '0', 1},

  {"dec400TableInput", '0', 1},
  {"osdDec400TableInput", '0', 1},

  {"psyFactor", '0', 1},

  /*Overlay*/
  {"overlayEnables", '0', 1},
  {"olInput1", '0', 1},
  {"olFormat1", '0', 1},
  {"olAlpha1", '0', 1},
  {"olWidth1", '0', 1},
  {"olHeight1", '0', 1},
  {"olXoffset1", '0', 1},
  {"olYoffset1", '0', 1},
  {"olYStride1", '0', 1},
  {"olUVStride1", '0', 1},
  {"olCropWidth1", '0', 1},
  {"olCropHeight1", '0', 1},
  {"olCropXoffset1", '0', 1},
  {"olCropYoffset1", '0', 1},
  {"olBitmapY1", '0', 1},
  {"olBitmapU1", '0', 1},
  {"olBitmapV1", '0', 1},
  {"olSuperTile1", '0', 1},
  {"olScaleWidth1", '0', 1},
  {"olScaleHeight1", '0', 1},

  {"olInput2", '0', 1},
  {"olFormat2", '0', 1},
  {"olAlpha2", '0', 1},
  {"olWidth2", '0', 1},
  {"olHeight2", '0', 1},
  {"olXoffset2", '0', 1},
  {"olYoffset2", '0', 1},
  {"olYStride2", '0', 1},
  {"olUVStride2", '0', 1},
  {"olCropWidth2", '0', 1},
  {"olCropHeight2", '0', 1},
  {"olCropXoffset2", '0', 1},
  {"olCropYoffset2", '0', 1},
  {"olBitmapY2", '0', 1},
  {"olBitmapU2", '0', 1},
  {"olBitmapV2", '0', 1},

  {"olInput3", '0', 1},
  {"olFormat3", '0', 1},
  {"olAlpha3", '0', 1},
  {"olWidth3", '0', 1},
  {"olHeight3", '0', 1},
  {"olXoffset3", '0', 1},
  {"olYoffset3", '0', 1},
  {"olYStride3", '0', 1},
  {"olUVStride3", '0', 1},
  {"olCropWidth3", '0', 1},
  {"olCropHeight3", '0', 1},
  {"olCropXoffset3", '0', 1},
  {"olCropYoffset3", '0', 1},
  {"olBitmapY3", '0', 1},
  {"olBitmapU3", '0', 1},
  {"olBitmapV3", '0', 1},

  {"olInput4", '0', 1},
  {"olFormat4", '0', 1},
  {"olAlpha4", '0', 1},
  {"olWidth4", '0', 1},
  {"olHeight4", '0', 1},
  {"olXoffset4", '0', 1},
  {"olYoffset4", '0', 1},
  {"olYStride4", '0', 1},
  {"olUVStride4", '0', 1},
  {"olCropWidth4", '0', 1},
  {"olCropHeight4", '0', 1},
  {"olCropXoffset4", '0', 1},
  {"olCropYoffset4", '0', 1},
  {"olBitmapY4", '0', 1},
  {"olBitmapU4", '0', 1},
  {"olBitmapV4", '0', 1},

  {"olInput5", '0', 1},
  {"olFormat5", '0', 1},
  {"olAlpha5", '0', 1},
  {"olWidth5", '0', 1},
  {"olHeight5", '0', 1},
  {"olXoffset5", '0', 1},
  {"olYoffset5", '0', 1},
  {"olYStride5", '0', 1},
  {"olUVStride5", '0', 1},
  {"olCropWidth5", '0', 1},
  {"olCropHeight5", '0', 1},
  {"olCropXoffset5", '0', 1},
  {"olCropYoffset5", '0', 1},
  {"olBitmapY5", '0', 1},
  {"olBitmapU5", '0', 1},
  {"olBitmapV5", '0', 1},

  {"olInput6", '0', 1},
  {"olFormat6", '0', 1},
  {"olAlpha6", '0', 1},
  {"olWidth6", '0', 1},
  {"olHeight6", '0', 1},
  {"olXoffset6", '0', 1},
  {"olYoffset6", '0', 1},
  {"olYStride6", '0', 1},
  {"olUVStride6", '0', 1},
  {"olCropWidth6", '0', 1},
  {"olCropHeight6", '0', 1},
  {"olCropXoffset6", '0', 1},
  {"olCropYoffset6", '0', 1},
  {"olBitmapY6", '0', 1},
  {"olBitmapU6", '0', 1},
  {"olBitmapV6", '0', 1},

  {"olInput7", '0', 1},
  {"olFormat7", '0', 1},
  {"olAlpha7", '0', 1},
  {"olWidth7", '0', 1},
  {"olHeight7", '0', 1},
  {"olXoffset7", '0', 1},
  {"olYoffset7", '0', 1},
  {"olYStride7", '0', 1},
  {"olUVStride7", '0', 1},
  {"olCropWidth7", '0', 1},
  {"olCropHeight7", '0', 1},
  {"olCropXoffset7", '0', 1},
  {"olCropYoffset7", '0', 1},
  {"olBitmapY7", '0', 1},
  {"olBitmapU7", '0', 1},
  {"olBitmapV7", '0', 1},

  {"olInput8", '0', 1},
  {"olFormat8", '0', 1},
  {"olAlpha8", '0', 1},
  {"olWidth8", '0', 1},
  {"olHeight8", '0', 1},
  {"olXoffset8", '0', 1},
  {"olYoffset8", '0', 1},
  {"olYStride8", '0', 1},
  {"olUVStride8", '0', 1},
  {"olCropWidth8", '0', 1},
  {"olCropHeight8", '0', 1},
  {"olCropXoffset8", '0', 1},
  {"olCropYoffset8", '0', 1},
  {"olBitmapY8", '0', 1},
  {"olBitmapU8", '0', 1},
  {"olBitmapV8", '0', 1},

  /* Mosaic */
  {"mosaicEnables", '0', 1},
  {"mosArea01", '0', 1},
  {"mosArea02", '0', 1},
  {"mosArea03", '0', 1},
  {"mosArea04", '0', 1},
  {"mosArea05", '0', 1},
  {"mosArea06", '0', 1},
  {"mosArea07", '0', 1},
  {"mosArea08", '0', 1},
  {"mosArea09", '0', 1},
  {"mosArea10", '0', 1},
  {"mosArea11", '0', 1},
  {"mosArea12", '0', 1},

  {"aq_mode", '0', 1},
  {"aq_strength", '0', 1},

  {"tune", '0', 1},
  {"preset", '0', 1},

   /*HW write recon to DDR or not if it's pure I-frame encoding*/
  {"writeReconToDDR", '0', 1},

   /*AV1 tx type search*/
  {"TxTypeSearchEnable", '0', 1},
  {"av1InterFiltSwitch", '0', 1},

  {"sendAUD", '0', 1},

   /*external SEI*/
  {"extSEI", '0', 1},

  {"useVcmd", '3', 1},
  {"useMMU", '3', 1},
  {"useDec400", '3', 1},
  {"useL2Cache", '3', 1},

  /* Resend high level headers(VPS/SPS/PPS) */
  {"resendParamSet", '0', 1},

  {"sramPowerdownDisable", '0', 1},
  
  {"insertIDR", '0', 1},

  /* output rd log in profile.log regardless of tb.cfg */
  {"rdLog", '0', 1},

  {"replaceMvFile", '0', 1},
  
  /*AXI max burst length */
  {"burstMaxLength", '0', 1},

  {NULL,      0,   0}        /* Format of last line */
};


static i32 long_option(i32 argc, char **argv, struct option *option,
                       struct parameter *parameter, char **p);
static i32 short_option(i32 argc, char **argv, struct option *option,
                        struct parameter *parameter, char **p);
static i32 parse(i32 argc, char **argv, struct option *option,
                 struct parameter *parameter, char **p, u32 lenght);
static i32 get_next(i32 argc, char **argv, struct parameter *parameter, char **p);

/*------------------------------------------------------------------------------
  get_option parses command line options. This function should be called
  with argc and argv values that are parameters of main(). The function
  will parse the next parameter from the command line. The function
  returns the next option character and stores the current place to
  structure argument. Structure option contain valid options
  and structure parameter contains parsed option.

  option options[] = {
    {"help",           'H', 0}, // No argument
    {"input",          'i', 1}, // Argument is compulsory
    {"output",         'o', 2}, // Argument is optional
    {NULL,              0,  0}  // Format of last line
  }

  Command line format can be
  --input filename
  --input=filename
  --inputfilename
  -i filename
  -i=filename
  -ifilename

  Input argc  Argument count as passed to main().
    argv  Argument values as passed to main().
    option  Valid options and argument requirements structure.
    parameter Option and argument return structure.

  Return  1 Unknown option.
    0 Option and argument are OK.
    -1  No more options.
    -2  Option match but argument is missing.
------------------------------------------------------------------------------*/
i32 get_option(i32 argc, char **argv, struct option *option,
               struct parameter *parameter)
{
  char *p = NULL;
  i32 ret;

  parameter->argument = "?";
  parameter->short_opt = '?';
  parameter->enable = 0;

  if (get_next(argc, argv, parameter, &p))
  {
    return -1;  /* End of options */
  }

  /* Long option */
  ret = long_option(argc, argv, option, parameter, &p);
  if (ret != 1) return ret;

  /* Short option */
  ret = short_option(argc, argv, option, parameter, &p);
  if (ret != 1)  return ret;

  /* This is unknow option but option anyway so argument must return */
  parameter->argument = p;

  return 1;
}

/*------------------------------------------------------------------------------
  long_option
------------------------------------------------------------------------------*/
i32 long_option(i32 argc, char **argv, struct option *option,
                struct parameter *parameter, char **p)
{
  i32 i = 0;
  u32 lenght, pLength;

  if (strncmp("--", *p, 2) != 0)
  {
    return 1;
  }

  pLength = strlen(*p+2);
  while (option[i].long_opt != NULL)
  {
    lenght = strlen(option[i].long_opt);
    if (strncmp(option[i].long_opt, *p + 2, lenght) == 0)
    {
      goto match;
    }
    i++;
  }
  return 1;

match:
  lenght += 2;    /* Because option start -- */
  if (parse(argc, argv, &option[i], parameter, p, lenght) != 0)
  {
    return -2;
  }

  return 0;
}

/*------------------------------------------------------------------------------
  short_option
------------------------------------------------------------------------------*/
i32 short_option(i32 argc, char **argv, struct option *option,
                 struct parameter *parameter, char **p)
{
  i32 i = 0;
  char short_opt;

  if (strncmp("-", *p, 1) != 0)
  {
    return 1;
  }

  //strncpy(&short_opt, *p + 1, 1);
  short_opt = *(*p + 1);
  while (option[i].long_opt != NULL)
  {
    if (option[i].short_opt  == short_opt)
    {
      goto match;
    }
    i++;
  }
  return 1;

match:
  if (parse(argc, argv, &option[i], parameter, p, 2) != 0)
  {
    return -2;
  }

  return 0;
}

/*------------------------------------------------------------------------------
  parse
------------------------------------------------------------------------------*/
i32 parse(i32 argc, char **argv, struct option *option,
          struct parameter *parameter, char **p, u32 lenght)
{
  char *arg;

  parameter->short_opt = option->short_opt;
  parameter->longOpt = option->long_opt;
  arg = *p + lenght;

  /* Argument and option are together */
  if (strlen(arg) != 0)
  {
    /* There should be no argument */
    if (option->enable == 0)
    {
      return -1;
    }

    /* Remove = */
    if (strncmp("=", arg, 1) == 0)
    {
      arg++;
    }
    parameter->enable = 1;
    parameter->argument = arg;
    return 0;
  }

  /* Argument and option are separately */
  if (get_next(argc, argv, parameter, p))
  {
    /* There is no more parameters */
    if (option->enable == 1)
    {
      return -1;
    }
    return 0;
  }

  /* Parameter is missing if next start with "-" but next time this
   * option is OK so we must fix parameter->cnt */
  if (strncmp("-", *p,  1) == 0)
  {
    parameter->cnt--;
    if (option->enable == 1)
    {
      return -1;
    }
    return 0;
  }

  /* There should be no argument */
  if (option->enable == 0)
  {
    return -1;
  }

  parameter->enable = 1;
  parameter->argument = *p;

  return 0;
}

/*------------------------------------------------------------------------------
  get_next
------------------------------------------------------------------------------*/
i32 get_next(i32 argc, char **argv, struct parameter *parameter, char **p)
{
  /* End of options */
  if ((parameter->cnt >= argc) || (parameter->cnt < 0))
  {
    return -1;
  }
  *p = argv[parameter->cnt];
  parameter->cnt++;

  return 0;
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
int ParseDelim(char *optArg, char delim)
{
  i32 i;

  for (i = 0; i < (i32)strlen(optArg); i++)
    if (optArg[i] == delim)
    {
      optArg[i] = 0;
      return i;
    }

  return -1;
}

int HasDelim(char *optArg, char delim)
{
  i32 i;

  for (i = 0; i < (i32)strlen(optArg); i++)
    if (optArg[i] == delim)
    {
      return 1;
    }

  return 0;
}


/*------------------------------------------------------------------------------
  help
------------------------------------------------------------------------------*/
void help(char *test_app)
{
  char helptext[] = {
    #include "../vcenc_help.dat"
    , '\0'
  };
  
  //fprintf(stdout, "Version: %s\n", git_version);
  fprintf(stdout, "Usage:  %s [options] -i inputfile\n\n", test_app);
  fprintf(stdout,
          "Default parameters are marked inside []. More detailed descriptions of\n"
          "C-Model command line parameters can be found from C-Model Command Line API Manual.\n\n");

  fprintf(stdout,
          "  -H --help                        This help\n\n");


  fprintf(stdout, "%s", helptext);

  exit(OK);
}

/* developing options */
void help_dev()
{
  fprintf(stdout, "===================\n");
  fprintf(stdout, "Developing Options:\n");
  fprintf(stdout,
          "\n Flex\n"
          "    --flexRefs refs.txt        Read flexible reference list from following file.\n"
          "\n");
}

/**
 * \page preset Preset Option Description
 
 The **--preset** option is used to explicitly defines preset encoding parameters. Preset settings
 shows the balance between  performance and compression efficiency. A higher preset value means 
 high quality but lower performance. When the **--preset** option is specified,.the default 
 parameters defined in the table bellow are loaded.
 
   | Preset: H264 | Preset: HEVC |  --lookaheadDepth   | --rdoLevel | --enableRdoQuant |  Performance  |
   | :----------: | :----------: | :---: | :------: | :--: | :-----------: |
   |     N/A      |      4       |  40   |    3     |  1   |   4K12fps     |
   |     N/A      |      3       |  40   |    3     |  0   |   4K18fps     |
   |     N/A      |      2       |  40   |    2     |  0   |   4K30fps     |   
   |      1       |      1       |  40   |    1     |  0   |   4K60fps     |
   |      0       |      0       |   0   |    1     |  0   |   4K75fps     |

 
 When preset are specified, the default parameters defined in above table are loaded. The later 
 options will overwrite the previous values for the option parser is working one by one.
 
 The performance data is an approximate value in general condition, may change according to 
 actual stream condition. Assume the core work frequency is 650MHz. 
 */
void Parameter_Preset(commandLine_s *cml)
{
    if(cml->preset >=4)
    {
      cml->lookaheadDepth = 40;
      cml->rdoLevel = 3;
      cml->enableRdoQuant = 1;
    }
    else if(cml->preset ==3)
    {
      cml->lookaheadDepth = 40;
      cml->rdoLevel = 3;
      cml->enableRdoQuant = 0;
    }
    else if(cml->preset ==2)
    {
      cml->lookaheadDepth = 40;
      cml->rdoLevel = 2;
      cml->enableRdoQuant = 0;
    }
    else if(cml->preset ==1)
    {
      cml->lookaheadDepth = 40;
      cml->rdoLevel = 1;
      cml->enableRdoQuant = 0;
    }
    else if(cml->preset ==0)
    {
      cml->lookaheadDepth = 0;
      cml->rdoLevel = 1;
      cml->enableRdoQuant = 0;
    }
}

i32 Parameter_Check(commandLine_s *cml)
{
  u32 client_type;
  EWLAttach(NULL,0,cml->useVcmd);
  client_type = IS_H264(cml->codecFormat)  ? EWL_CLIENT_TYPE_H264_ENC : EWL_CLIENT_TYPE_HEVC_ENC;
  EWLHwConfig_t asic_cfg = VCEncGetAsicConfig(client_type, NULL);//EncAsicGetAsicConfig(0);
  if(cml->lookaheadDepth > 0 && ((!asic_cfg.bFrameEnabled && cml->gopSize != 1) || asic_cfg.cuInforVersion < 1)) {
    // lookahead needs bFrame support & cuInfo version 1
    printf("Lookahead not supported, disable lookahead!\n");
    cml->lookaheadDepth = 0;
  }

  if(cml->lookaheadDepth > 0 && asic_cfg.cuInforVersion != 2 && asic_cfg.bMultiPassSupport)
  {
    printf("IM only support cuInfo version 2!\n");
    return NOK;
  }

  if(((i32)asic_cfg.cuInforVersion < cml->cuInfoVersion) ||
     (cml->cuInfoVersion == 0 && asic_cfg.cuInforVersion != 0))
  {
    printf("CuInfoVersion %d is not supported\n", cml->cuInfoVersion);
    return NOK;
  }

  if(cml->inLoopDSRatio > 0 && (cml->lookaheadDepth == 0 || asic_cfg.inLoopDSRatio == 0))
    cml->inLoopDSRatio = 0;

  /* We check OSD FUSE here to avoid testbench level osd working(test OSD input existance) */
  if(cml->overlayEnables > 0 && !asic_cfg.OSDSupport)
  {
    printf("OSD not supported\n");
    return NOK;
  }
  
  if(cml->layerInRefIdc == 1 && !asic_cfg.H264NalRefIdc2bit)
  {
    printf("H264NalRefIdc2bit not supported, disable 2bitNalRefIdc!\n");
    cml->layerInRefIdc = 0;
  }

  if(cml->lookaheadDepth)
  {
    cml->gopLowdelay = 0; /* lookahead not work well with lowdelay configurations */
  }

  if((IS_AV1(cml->codecFormat) || IS_VP9(cml->codecFormat)) && cml->sliceSize != 0)
  {
    printf("WARNING: No multi slice support in AV1 or VP9\n");
    cml->sliceSize = 0;
  }

  if((IS_AV1(cml->codecFormat) || IS_VP9(cml->codecFormat)) && !cml->byteStream) {
    printf("WARNING: AV1 and VP9 only supports byte stream mode\n");
    cml->byteStream = 1;
  }

#ifdef VMAF_SUPPORT
  if(cml->tune == 4 && cml->inputFormat != 0)
  {
    printf("Error: tune=vmaf only supports YUV420P format\n");
    return NOK;
  }
#endif

  /* disable DEB & SAO for InputAsRef test */
  if(cml->testId == 45)
  {
    cml->disableDeblocking = 1;
    cml->enableSao = 0;
  }
  return OK;
}

/*------------------------------------------------------------------------------
  parameter
------------------------------------------------------------------------------*/
i32 Parameter_Get(i32 argc, char **argv, commandLine_s *cml) {
  struct parameter prm;
  i32 status = OK;
  i32 ret, i;
  char *p;
  i32 bpsAdjustCount = 0;

  prm.cnt = 1;
  while ((ret = get_option(argc, argv, options, &prm)) != -1)
  {
    if (ret == -2) status = NOK;
    p = prm.argument;
    switch (prm.short_opt)
    {
      case 'H':
        help(argv[0]);
        if (strcmp(p, "dev") == 0) {
          help_dev();
        }
        break;
      case 'i':
        cml->input = p;
        break;
      case 'o':
        cml->output = p;
        break;
      case 'a':
        cml->firstPic = atoi(p);
        break;
      case 'b':
        cml->lastPic = atoi(p);
        break;
      case 'x':
        cml->width = atoi(p);
        break;
      case 'y':
        cml->height = atoi(p);
        break;
      case 'z':
        cml->userData = p;
        break;
      case 'w':
        cml->lumWidthSrc = atoi(p);
        break;
      case 'h':
        cml->lumHeightSrc = atoi(p);
        break;
      case 'X':
        cml->horOffsetSrc = atoi(p);
        break;
      case 'Y':
        cml->verOffsetSrc = atoi(p);
        break;
      case 'l':
        cml->inputFormat = atoi(p);
        break;
      case 'O':
        cml->colorConversion = atoi(p);
        break;
      case 'f':
        cml->outputRateNumer = atoi(p);
        break;
      case 'F':
        cml->outputRateDenom = atoi(p);
        break;
      case 'j':
        cml->inputRateNumer = atoi(p);
        break;
      case 'J':
        cml->inputRateDenom = atoi(p);
        break;
      case 'p':
        cml->cabacInitFlag = atoi(p);
        break;
      case 'K':
        cml->enableCabac = atoi(p);
        break;

      case 'q':
        cml->qpHdr = atoi(p);
        break;
      case 'n':
        cml->qpMin = atoi(p);
        break;
      case 'm':
        cml->qpMax = atoi(p);
        break;

      case 'B':
        cml->bitPerSecond = atoi(p);
        break;
      case 'U':
        cml->picRc = atoi(p);
        break;
      case 'u':
        cml->ctbRc = atoi(p); //CTB_RC
        break;
      case 'C':
        cml->hrdConformance = atoi(p);
        break;
      case 'c':
        cml->cpbSize = atoi(p);
        break;
      case 's':
        cml->picSkip = atoi(p);
        break;
      case 'T':
        cml->test_data_files = p;
        break;
      case 'L':
        cml->level = atoi(p);
        break;
      case 'P':
        cml->profile = atoi(p);
        break;
      case 'r':
        cml->rotation = atoi(p);
        break;
      case 'R':
        cml->intraPicRate = atoi(p);
        break;
      case 'Z':
        cml->videoStab = atoi(p);
        break;
      case 'A':
        cml->intraQpDelta = atoi(p);
        break;
      case 'D':
        cml->disableDeblocking = atoi(p);
        break;
      case 'W':
        cml->tc_Offset = atoi(p);
        break;
      case 'E':
        cml->beta_Offset = atoi(p);
        break;
      case 'e':
        cml->sliceSize = atoi(p);
        break;

      case 'g':
        cml->bitrateWindow = atoi(p);
        break;
      case 'G':
        cml->fixedIntraQp = atoi(p);
        break;
      case 'N':
        cml->byteStream = atoi(p);
        break;
      case 'I':
        cml->chromaQpOffset = atoi(p);
        break;
      case 'M':
        cml->enableSao = atoi(p);
        break;

      case 'k':
        cml->videoRange = atoi(p);
        break;

      case 'S':
        cml->sei = atoi(p);
        break;
      case 'V':
        cml->bFrameQpDelta = atoi(p);
        break;
      case '1':
        if (bpsAdjustCount == MAX_BPS_ADJUST)
          break;
        /* Argument must be "xx:yy", replace ':' with 0 */
        if ((i = ParseDelim(p, ':')) == -1) break;
        /* xx is frame number */
        cml->bpsAdjustFrame[bpsAdjustCount] = atoi(p);
        /* yy is new target bitrate */
        cml->bpsAdjustBitrate[bpsAdjustCount] = atoi(p + i + 1);
        bpsAdjustCount++;
        break;

      case '3':
        if (strcmp(prm.longOpt, "useVcmd") == 0)
           cml->useVcmd =  atoi(p);
        if (strcmp(prm.longOpt, "useMMU") == 0)
           cml->useMMU =  atoi(p);
        if (strcmp(prm.longOpt, "useDec400") == 0)
           cml->useDec400 =  atoi(p);
        if (strcmp(prm.longOpt, "useL2Cache") == 0)
           cml->useL2Cache =  atoi(p);
        break;
        
      case '0':
        /* Check long option */
        if (strcmp(prm.longOpt, "tier") == 0)
          cml->tier = atoi(p);
#ifdef FBDC_ENABLE
        if (strcmp(prm.longOpt, "UVheaderSize") == 0)
          cml->UVheaderSize = atoi(p);

        if (strcmp(prm.longOpt, "UVpayloadSize") == 0)
          cml->UVpayloadSize = atoi(p);

        if (strcmp(prm.longOpt, "YheaderSize") == 0)
          cml->YheaderSize = atoi(p);

        if (strcmp(prm.longOpt, "YpayloadSize") == 0)
          cml->YpayloadSize = atoi(p);

		if (strcmp(prm.longOpt, "CropX") == 0)
          cml->CropX = atoi(p);

        if (strcmp(prm.longOpt, "CropY") == 0)
          cml->CropY = atoi(p);
#endif
        if (strcmp(prm.longOpt, "cpbMaxRate") == 0)
          cml->cpbMaxRate = atoi(p);

        if (strcmp(prm.longOpt, "roi1DeltaQp") == 0)
          cml->roi1DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi2DeltaQp") == 0)
          cml->roi2DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi3DeltaQp") == 0)
          cml->roi3DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi4DeltaQp") == 0)
          cml->roi4DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi5DeltaQp") == 0)
          cml->roi5DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi6DeltaQp") == 0)
          cml->roi6DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi7DeltaQp") == 0)
          cml->roi7DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi8DeltaQp") == 0)
          cml->roi8DeltaQp = atoi(p);

        if (strcmp(prm.longOpt, "roi1Qp") == 0)
          cml->roi1Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi2Qp") == 0)
          cml->roi2Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi3Qp") == 0)
          cml->roi3Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi4Qp") == 0)
          cml->roi4Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi5Qp") == 0)
          cml->roi5Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi6Qp") == 0)
          cml->roi6Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi7Qp") == 0)
          cml->roi7Qp = atoi(p);

        if (strcmp(prm.longOpt, "roi8Qp") == 0)
          cml->roi8Qp = atoi(p);

        if (strcmp(prm.longOpt, "roiMapDeltaQpBlockUnit") == 0)
          cml->roiMapDeltaQpBlockUnit = atoi(p);

        if (strcmp(prm.longOpt, "roiMapDeltaQpEnable") == 0)
          cml->roiMapDeltaQpEnable = atoi(p);

        if (strcmp(prm.longOpt, "ipcmMapEnable") == 0)
          cml->ipcmMapEnable = atoi(p);

        if (strcmp(prm.longOpt, "outBufSizeMax") == 0)
          cml->outBufSizeMax = atoi(p);

        if (strcmp(prm.longOpt, "codecFormat") == 0) {
          if(strcmp(p,"hevc") == 0)
            cml->codecFormat = VCENC_VIDEO_CODEC_HEVC;
          else if(strcmp(p,"h264") == 0)
            cml->codecFormat = VCENC_VIDEO_CODEC_H264;
          else if(strcmp(p,"av1") == 0)
            cml->codecFormat = VCENC_VIDEO_CODEC_AV1;
          else if(strcmp(p,"vp9") == 0)
            cml->codecFormat = VCENC_VIDEO_CODEC_VP9;
          else if(p[0] >= '0' && p[0] <= '9')
            cml->codecFormat = atoi(p);
          else {
            ASSERT(0 && "unknown codecFormat");
          }
          if(IS_H264(cml->codecFormat)) {
            cml->max_cu_size  = 16;
            cml->min_cu_size  = 8;
            cml->max_tr_size  = 16;
            cml->min_tr_size  = 4;
            cml->tr_depth_intra = 1;
            cml->tr_depth_inter = 2;
          }
        }

        if (strcmp(prm.longOpt, "layerInRefIdc") == 0)
          cml->layerInRefIdc = atoi(p);

        if (strcmp(prm.longOpt, "cir") == 0)
        {
          /* Argument must be "xx:yy", replace ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          /* xx is cir start */
          cml->cirStart = atoi(p);
          /* yy is cir interval */
          cml->cirInterval = atoi(p + i + 1);
        }

        if (strcmp(prm.longOpt, "intraArea") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->intraAreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->intraAreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->intraAreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->intraAreaBottom = atoi(p);
          cml->intraAreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "ipcm1Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm1AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm1AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm1AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm1AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm2Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm2AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm2AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm2AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm2AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm3Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm3AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm3AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm3AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm3AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm4Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm4AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm4AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm4AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm4AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm5Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm5AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm5AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm5AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm5AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm6Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm6AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm6AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm6AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm6AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm7Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm7AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm7AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm7AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm7AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "ipcm8Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm8AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm8AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ipcm8AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->ipcm8AreaBottom = atoi(p);
        }

        if (strcmp(prm.longOpt, "roi1Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi1AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi1AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi1AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi1AreaBottom = atoi(p);
          cml->roi1AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi2Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi2AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi2AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi2AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi2AreaBottom = atoi(p);
          cml->roi2AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi3Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi3AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi3AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi3AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi3AreaBottom = atoi(p);
          cml->roi3AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi4Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi4AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi4AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi4AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi4AreaBottom = atoi(p);
          cml->roi4AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi5Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi5AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi5AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi5AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi5AreaBottom = atoi(p);
          cml->roi5AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi6Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi6AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi6AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi6AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi6AreaBottom = atoi(p);
          cml->roi6AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi7Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi7AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi7AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi7AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi7AreaBottom = atoi(p);
          cml->roi7AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "roi8Area") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi8AreaLeft = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi8AreaTop = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->roi8AreaRight = atoi(p);
          /* YY is bottom coordinate */
          p += i + 1;
          cml->roi8AreaBottom = atoi(p);
          cml->roi8AreaEnable = 1;
        }

        if (strcmp(prm.longOpt, "smoothingIntra") == 0)
        {
          cml->strong_intra_smoothing_enabled_flag = atoi(p);
          ASSERT(cml->strong_intra_smoothing_enabled_flag < 2);
        }

        if (strcmp(prm.longOpt, "scaledWidth") == 0)
          cml->scaledWidth = atoi(p);

        if (strcmp(prm.longOpt, "scaledHeight") == 0)
          cml->scaledHeight = atoi(p);

        if (strcmp(prm.longOpt, "scaledOutputFormat") == 0)
          cml->scaledOutputFormat = atoi(p);

        if (strcmp(prm.longOpt, "enableDeblockOverride") == 0)
          cml->enableDeblockOverride = atoi(p);
        if (strcmp(prm.longOpt, "deblockOverride") == 0)
          cml->deblockOverride = atoi(p);

        if (strcmp(prm.longOpt, "enableScalingList") == 0)
          cml->enableScalingList = atoi(p);

        if (strcmp(prm.longOpt, "compressor") == 0)
          cml->compressor = atoi(p);
        if (strcmp(prm.longOpt, "testId") == 0)
          cml->testId = atoi(p);
        if (strcmp(prm.longOpt, "interlacedFrame") == 0)
          cml->interlacedFrame = atoi(p);

        if (strcmp(prm.longOpt, "fieldOrder") == 0)
          cml->fieldOrder = atoi(p);
        if (strcmp(prm.longOpt, "gopSize") == 0)
          cml->gopSize = atoi(p);
        if (strcmp(prm.longOpt, "gopConfig") == 0)
          cml->gopCfg = p;
        if (strcmp(prm.longOpt, "gopLowdelay") == 0)
          cml->gopLowdelay = atoi(p);
        if (strcmp(prm.longOpt, "LTR") == 0) {
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->ltrInterval = atoi(p);
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->longTermGapOffset = atoi(p);
          p += i + 1;
          i = ParseDelim(p, ':');
          cml->longTermGap = atoi(p);
          if (i >= 0) {
            p += i + 1;
            cml->longTermQpDelta = atoi(p);
          }
        }
        if (strcmp(prm.longOpt, "flexRefs")==0)
          cml->flexRefs = p;

        if (strcmp(prm.longOpt, "tile") == 0) {
            if ((i = ParseDelim(p, ':')) == -1) break;
            cml->num_tile_columns = atoi(p);
            p += i + 1;

            if ((i = ParseDelim(p, ':')) == -1) break;
            cml->num_tile_rows = atoi(p);
            p += i + 1;

            i = ParseDelim(p, ':');
            cml->loop_filter_across_tiles_enabled_flag = atoi(p);
            p += i + 1;

            cml->tiles_enabled_flag= ((cml->num_tile_columns * cml->num_tile_rows)>1);
        }

        if (strcmp(prm.longOpt, "skipFramePOC") == 0) {
            cml->skip_frame_poc = atoi(p);
            cml->skip_frame_enabled_flag = (cml->skip_frame_poc !=0);
        }
        if (strcmp(prm.longOpt, "bFrameQpDelta") == 0)
          cml->bFrameQpDelta = atoi(p);

        if (strcmp(prm.longOpt, "outReconFrame") == 0)
          cml->outReconFrame = atoi(p);


        if (strcmp(prm.longOpt, "gdrDuration") == 0)
          cml->gdrDuration = atoi(p);

        if (strcmp(prm.longOpt, "ipcmFilterDisable") == 0)
          cml->pcm_loop_filter_disabled_flag = atoi(p);

        if (strcmp(prm.longOpt, "bitVarRangeI") == 0)
          cml->bitVarRangeI = atoi(p);

        if (strcmp(prm.longOpt, "bitVarRangeP") == 0)
          cml->bitVarRangeP = atoi(p);

        if (strcmp(prm.longOpt, "bitVarRangeB") == 0)
          cml->bitVarRangeB = atoi(p);
        if (strcmp(prm.longOpt, "tolMovingBitRate") == 0)
          cml->tolMovingBitRate = atoi(p);

        if (strcmp(prm.longOpt, "tolCtbRcInter") == 0)
          cml->tolCtbRcInter = atof(p);
        if (strcmp(prm.longOpt, "tolCtbRcIntra") == 0)
          cml->tolCtbRcIntra = atof(p);

        if (strcmp(prm.longOpt, "smoothPsnrInGOP") == 0)
          cml->smoothPsnrInGOP = atoi(p);

        if (strcmp(prm.longOpt, "staticSceneIbitPercent") == 0)
          cml->u32StaticSceneIbitPercent = atoi(p);

        if (strcmp(prm.longOpt, "monitorFrames") == 0)
          cml->monitorFrames = atoi(p);
        if (strcmp(prm.longOpt, "roiMapDeltaQpFile") == 0)
          cml->roiMapDeltaQpFile = p;
        if (strcmp(prm.longOpt, "roiMapDeltaQpBinFile") == 0)
          cml->roiMapDeltaQpBinFile = p;
        if (strcmp(prm.longOpt, "ipcmMapFile") == 0)
          cml->ipcmMapFile = p;
        if (strcmp(prm.longOpt, "roiMapInfoBinFile") == 0)
          cml->roiMapInfoBinFile = p;
        if (strcmp(prm.longOpt, "RoimapCuCtrlInfoBinFile") == 0)
          cml->RoimapCuCtrlInfoBinFile = p;
        if (strcmp(prm.longOpt, "RoimapCuCtrlIndexBinFile") == 0)
          cml->RoimapCuCtrlIndexBinFile = p;
        if (strcmp(prm.longOpt, "RoiCuCtrlVer") == 0)
          cml->RoiCuCtrlVer = atoi(p);
        if (strcmp(prm.longOpt, "RoiQpDeltaVer") == 0)
            cml->RoiQpDeltaVer = atoi(p);

        /* low latency */
        if (strcmp(prm.longOpt, "inputLineBufferMode") == 0)
            cml->inputLineBufMode = atoi(p);
        if (strcmp(prm.longOpt, "inputLineBufferDepth") == 0)
            cml->inputLineBufDepth = atoi(p);
        if (strcmp(prm.longOpt, "inputLineBufferAmountPerLoopback") == 0)
            cml->amountPerLoopBack = atoi(p);

        /* stride */
        if (strcmp(prm.longOpt, "inputAlignmentExp") == 0)
          cml->exp_of_input_alignment = atoi(p);

        if (strcmp(prm.longOpt, "refAlignmentExp") == 0)
          cml->exp_of_ref_alignment = atoi(p);

        if (strcmp(prm.longOpt, "aqInfoAlignmentExp") == 0)
          cml->exp_of_aqinfo_alignment = atoi(p);

        if (strcmp(prm.longOpt,  "refChromaAlignmentExp") == 0)
          cml->exp_of_ref_ch_alignment = atoi(p);

        if (strcmp(prm.longOpt, "formatCustomizedType") == 0)
          cml->formatCustomizedType = atoi(p);

       //wiener denoise
        if (strcmp(prm.longOpt, "noiseReductionEnable") == 0)
          cml->noiseReductionEnable = atoi(p);
        if (strcmp(prm.longOpt, "noiseLow") == 0)
          cml->noiseLow = atoi(p);
        if (strcmp(prm.longOpt, "noiseFirstFrameSigma") == 0)
          cml->firstFrameSigma = atoi(p);

        /* multi-stream */
        if (strcmp(prm.longOpt, "multimode") == 0)
          cml->multimode = atoi(p);
        if (strcmp(prm.longOpt, "streamcfg") == 0)
          cml->streamcfg[cml->nstream++] = p;
        if (strcmp(prm.longOpt, "bitDepthLuma") == 0)
          cml->bitDepthLuma = atoi(p);

        if (strcmp(prm.longOpt, "bitDepthChroma") == 0)
          cml->bitDepthChroma = atoi(p);

        if (strcmp(prm.longOpt, "blockRCSize") == 0)
          cml->blockRCSize = atoi(p);

        if (strcmp(prm.longOpt, "rcQpDeltaRange") == 0)
          cml->rcQpDeltaRange = atoi(p);

        if (strcmp(prm.longOpt, "rcBaseMBComplexity") == 0)
          cml->rcBaseMBComplexity = atoi(p);

        if (strcmp(prm.longOpt, "picQpDeltaRange") == 0) {
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->picQpDeltaMin = atoi(p);
          p += i + 1;
          cml->picQpDeltaMax = atoi(p);
        }

        if (strcmp(prm.longOpt, "ctbRowQpStep") == 0)
          cml->ctbRcRowQpStep = atoi(p);

        if (strcmp(prm.longOpt, "sceneChange") == 0) {
          i32 j = 0, iSc = 0, tmp;
          while(j++ < MAX_SCENE_CHANGE)
          {
            if ((tmp = atoi(p)))
              cml->sceneChange[iSc ++] = tmp;

            if ((i = ParseDelim(p, ':')) == -1) break;
            p += i + 1;
          }
        }

        if (strcmp(prm.longOpt, "enableP010Ref") == 0)
          cml->P010RefEnable = atoi(p);

        /* CU infor dumping */
         if (strcmp(prm.longOpt, "enableOutputCuInfo") == 0)
          cml->enableOutputCuInfo = atoi(p);

        if (strcmp(prm.longOpt, "enableOutputCtbBits") == 0)
          cml->enableOutputCtbBits = atoi(p);

        if (strcmp(prm.longOpt, "rdoLevel") == 0)
          cml->rdoLevel = atoi(p);

        if (strcmp(prm.longOpt, "enableDynamicRdo") == 0)
          cml->dynamicRdoEnable = atoi(p);

        if (strcmp(prm.longOpt, "dynamicCu16Bias") == 0)
          cml->dynamicRdoCu16Bias = atoi(p);

        if (strcmp(prm.longOpt, "dynamicCu16Factor") == 0)
          cml->dynamicRdoCu16Factor = atoi(p);

        if (strcmp(prm.longOpt, "dynamicCu32Bias") == 0)
          cml->dynamicRdoCu32Bias = atoi(p);

        if (strcmp(prm.longOpt, "dynamicCu32Factor") == 0)
          cml->dynamicRdoCu32Factor = atoi(p);

        if (strcmp(prm.longOpt, "enableRdoQuant") == 0)
          cml->enableRdoQuant = atoi(p);

        /* smart mode */
        if (strcmp(prm.longOpt, "enableSmartMode") == 0)
          cml->smartModeEnable = atoi(p);
        if (strcmp(prm.longOpt, "smartConfig") == 0)
          ParsingSmartConfig (p, cml);

        if (strcmp(prm.longOpt, "enableVuiTimingInfo") == 0)
          cml->vui_timing_info_enable = atoi(p);
        if (strcmp(prm.longOpt, "lookaheadDepth") == 0)
          cml->lookaheadDepth = atoi(p);
        if (strcmp(prm.longOpt, "cuInfoVersion") == 0)
          cml->cuInfoVersion = atoi(p);
        if (strcmp(prm.longOpt, "halfDsInput") == 0)
          cml->halfDsInput = p;
        if (strcmp(prm.longOpt, "inLoopDSRatio") == 0)
          cml->inLoopDSRatio = atoi(p);
        /* mirror */
        if (strcmp(prm.longOpt, "mirror") == 0)
        {
          cml->mirror = atoi(p);
          cml->mirror = CLIP3(0, 1, cml->mirror);
        }

        if (strcmp(prm.longOpt, "hashtype") == 0)
          cml->hashtype = atoi(p);

        if (strcmp(prm.longOpt, "gmvFile") == 0)
          cml->gmvFileName[0] = p;

        if (strcmp(prm.longOpt, "gmvList1File") == 0)
          cml->gmvFileName[1] = p;

        if (strcmp(prm.longOpt, "verbose") == 0)
          cml->verbose = atoi(p);

        /* constant chroma control */
        if (strcmp(prm.longOpt, "enableConstChroma") == 0)
          cml->constChromaEn = atoi(p);
        if (strcmp(prm.longOpt, "constCb") == 0)
          cml->constCb = atoi(p);
        if (strcmp(prm.longOpt, "constCr") == 0)
          cml->constCr = atoi(p);

        /* qpMin/qpMax for I picture */
        if (strcmp(prm.longOpt, "qpMinI") == 0)
          cml->qpMinI = atoi(p);
        if (strcmp(prm.longOpt, "qpMaxI") == 0)
          cml->qpMaxI = atoi(p);

        /* vbr, controlled by qpMin */
        if (strcmp(prm.longOpt, "vbr") == 0)
          cml->vbr = atoi(p);

    /* HDR10 */
    if (strcmp(prm.longOpt, "HDR10_display") == 0)
    {
      cml->hdr10_display_enable = ENCHW_YES;
      /* Argument must be "xx:yy:XX:YY".*/
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dx0 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dy0 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dx1 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dy1 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dx2 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_dy2 = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_wx = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_wy = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_maxluma = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_minluma = atoi(p);
    }

    if (strcmp(prm.longOpt, "HDR10_lightlevel") == 0)
    {
      cml->hdr10_lightlevel_enable = ENCHW_YES;

      /* Argument must be "xx:yy:zz".*/
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->hdr10_maxlight = atoi(p);

      p += i + 1;
      cml->hdr10_avglight = atoi(p);
    }

    if (strcmp(prm.longOpt, "vuiColordescription") == 0)
    {
      cml->vuiColorDescripPresentFlag = ENCHW_YES;

      /* Argument must be "xx:yy:zz".*/
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->vuiColorPrimaries = atoi(p);

      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->vuiTransferCharacteristics = atoi(p);

      p += i + 1;
      cml->vuiMatrixCoefficients = atoi(p);
    }

    if (strcmp(prm.longOpt, "vuiVideoFormat") == 0)
      cml->vuiVideoFormat = atoi(p);

    if (strcmp(prm.longOpt, "vuiVideosignalPresent") == 0)
      cml->vuiVideoSignalTypePresentFlag = atoi(p);

    if (strcmp(prm.longOpt, "vuiAspectRatio") == 0)
    {
      /* Argument must be "xx:yy".*/
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->vuiAspectRatioWidth = atoi(p);

      p += i + 1;
      cml->vuiAspectRatioHeight = atoi(p);
    }

    if (strcmp(prm.longOpt, "RPSInSliceHeader") == 0)
    {
      cml->RpsInSliceHeader = atoi(p);
    }

    if (strcmp(prm.longOpt, "POCConfig") == 0)
    {
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->picOrderCntType = atoi(p);
      p += i + 1;
      if ((i = ParseDelim(p, ':')) == -1) break;
      cml->log2MaxPicOrderCntLsb = atoi(p);
      p += i + 1;
      cml->log2MaxFrameNum = atoi(p);
    }

        if (strcmp(prm.longOpt, "ssim") == 0)
          cml->ssim = atoi(p);

        if (strcmp(prm.longOpt, "psnr") == 0)
          cml->psnr = atoi(p);

        if (strcmp(prm.longOpt, "gmv") == 0)
        {
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->gmv[0][0] = atoi(p);
          p += i + 1;
          cml->gmv[0][1] = atoi(p);
        }

        if (strcmp(prm.longOpt, "gmvList1") == 0)
        {
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->gmv[1][0] = atoi(p);
          p += i + 1;
          cml->gmv[1][1] = atoi(p);
        }

        if (strcmp(prm.longOpt, "MEVertRange") == 0)
          cml->MEVertRange = atoi(p);

        /* skip map */
        if (strcmp(prm.longOpt, "skipMapEnable") == 0)
          cml->skipMapEnable = atoi(p);
        if (strcmp(prm.longOpt, "skipMapBlockUnit") == 0)
          cml->skipMapBlockUnit = atoi(p);
        if (strcmp(prm.longOpt, "skipMapFile") == 0)
          cml->skipMapFile = p;

        /* rdoq map */
        if (strcmp(prm.longOpt, "rdoqMapEnable") == 0)
          cml->rdoqMapEnable = atoi(p);

        if (strcmp(prm.longOpt, "parallelCoreNum") == 0)
          cml->parallelCoreNum = atoi(p);

        /* two stream buffer */
        if (strcmp(prm.longOpt, "streamBufChain") == 0)
          cml->streamBufChain = atoi(p);

        if (strcmp(prm.longOpt, "streamMultiSegmentMode") == 0)
          cml->streamMultiSegmentMode = atoi(p);

        if (strcmp(prm.longOpt, "streamMultiSegmentAmount") == 0)
          cml->streamMultiSegmentAmount = atoi(p);

        if (strcmp(prm.longOpt, "dumpRegister") == 0)
          cml->dumpRegister = atoi(p);

        if (strcmp(prm.longOpt, "rasterscan") == 0)
          cml->rasterscan = atoi(p);

        if (strcmp(prm.longOpt, "crf") == 0)
          cml->crf = atoi(p);

        /*external sram*/
        if (strcmp(prm.longOpt, "extSramLumHeightBwd") == 0)
          cml->extSramLumHeightBwd = atoi(p);
        if (strcmp(prm.longOpt, "extSramChrHeightBwd") == 0)
          cml->extSramChrHeightBwd = atoi(p);
        if (strcmp(prm.longOpt, "extSramLumHeightFwd") == 0)
          cml->extSramLumHeightFwd = atoi(p);
        if (strcmp(prm.longOpt, "extSramChrHeightFwd") == 0)
          cml->extSramChrHeightFwd = atoi(p);

        if (strcmp(prm.longOpt, "AXIAlignment") == 0)
          cml->AXIAlignment = strtoul(p, NULL, 16);

        if (strcmp(prm.longOpt, "mmuEnable") == 0)
          cml->mmuEnable = atoi(p);
        
        if (strcmp(prm.longOpt, "sliceNode") == 0)
          cml->sliceNode = atoi(p);

        if (strcmp(prm.longOpt, "ivf") == 0)
          cml->ivf = atoi(p);

        if (strcmp(prm.longOpt, "dec400TableInput") == 0)
          cml->dec400CompTableinput = p;

        if (strcmp(prm.longOpt, "psyFactor") == 0)
          cml->psyFactor = atof(p);

        if (strcmp(prm.longOpt, "overlayEnables") == 0)
          cml->overlayEnables = atoi(p);

        if (strcmp(prm.longOpt, "osdDec400TableInput") == 0)
          cml->osdDec400CompTableInput = p;

        if (strcmp(prm.longOpt, "olInput1") == 0)
          cml->olInput[0] = p;
        if (strcmp(prm.longOpt, "olFormat1") == 0)
          cml->olFormat[0] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha1") == 0)
          cml->olAlpha[0] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth1") == 0)
          cml->olWidth[0] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight1") == 0)
          cml->olHeight[0] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset1") == 0)
          cml->olXoffset[0] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset1") == 0)
          cml->olYoffset[0] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride1") == 0)
          cml->olYStride[0] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride1") == 0)
          cml->olUVStride[0] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth1") == 0)
          cml->olCropWidth[0] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight1") == 0)
          cml->olCropHeight[0] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset1") == 0)
          cml->olCropXoffset[0] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset1") == 0)
          cml->olCropYoffset[0] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY1") == 0)
          cml->olBitmapY[0] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU1") == 0)
          cml->olBitmapU[0] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV1") == 0)
          cml->olBitmapV[0] = atoi(p);
        if (strcmp(prm.longOpt, "olSuperTile1") == 0)
          cml->olSuperTile[0] = atoi(p);
        if (strcmp(prm.longOpt, "olScaleWidth1") == 0)
          cml->olScaleWidth[0] = atoi(p);
        if (strcmp(prm.longOpt, "olScaleHeight1") == 0)
          cml->olScaleHeight[0] = atoi(p);

        if (strcmp(prm.longOpt, "olInput2") == 0)
          cml->olInput[1] = p;
        if (strcmp(prm.longOpt, "olFormat2") == 0)
          cml->olFormat[1] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha2") == 0)
          cml->olAlpha[1] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth2") == 0)
          cml->olWidth[1] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight2") == 0)
          cml->olHeight[1] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset2") == 0)
          cml->olXoffset[1] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset2") == 0)
          cml->olYoffset[1] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride2") == 0)
          cml->olYStride[1] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride2") == 0)
          cml->olUVStride[1] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth2") == 0)
          cml->olCropWidth[1] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight2") == 0)
          cml->olCropHeight[1] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset2") == 0)
          cml->olCropXoffset[1] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset2") == 0)
          cml->olCropYoffset[1] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY2") == 0)
          cml->olBitmapY[1] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU2") == 0)
          cml->olBitmapU[1] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV2") == 0)
          cml->olBitmapV[1] = atoi(p);

        if (strcmp(prm.longOpt, "olInput3") == 0)
          cml->olInput[2] = p;
        if (strcmp(prm.longOpt, "olFormat3") == 0)
          cml->olFormat[2] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha3") == 0)
          cml->olAlpha[2] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth3") == 0)
          cml->olWidth[2] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight3") == 0)
          cml->olHeight[2] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset3") == 0)
          cml->olXoffset[2] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset3") == 0)
          cml->olYoffset[2] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride3") == 0)
          cml->olYStride[2] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride3") == 0)
          cml->olUVStride[2] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth3") == 0)
          cml->olCropWidth[2] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight3") == 0)
          cml->olCropHeight[2] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset3") == 0)
          cml->olCropXoffset[2] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset3") == 0)
          cml->olCropYoffset[2] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY3") == 0)
          cml->olBitmapY[2] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU3") == 0)
          cml->olBitmapU[2] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV3") == 0)
          cml->olBitmapV[2] = atoi(p);


        if (strcmp(prm.longOpt, "olInput4") == 0)
          cml->olInput[3] = p;
        if (strcmp(prm.longOpt, "olFormat4") == 0)
          cml->olFormat[3] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha4") == 0)
          cml->olAlpha[3] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth4") == 0)
          cml->olWidth[3] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight4") == 0)
          cml->olHeight[3] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset4") == 0)
          cml->olXoffset[3] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset4") == 0)
          cml->olYoffset[3] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride4") == 0)
          cml->olYStride[3] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride4") == 0)
          cml->olUVStride[3] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth4") == 0)
          cml->olCropWidth[3] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight4") == 0)
          cml->olCropHeight[3] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset4") == 0)
          cml->olCropXoffset[3] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset4") == 0)
          cml->olCropYoffset[3] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY4") == 0)
          cml->olBitmapY[3] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU4") == 0)
          cml->olBitmapU[3] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV4") == 0)
          cml->olBitmapV[3] = atoi(p);

        if (strcmp(prm.longOpt, "olInput5") == 0)
          cml->olInput[4] = p;
        if (strcmp(prm.longOpt, "olFormat5") == 0)
          cml->olFormat[4] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha5") == 0)
          cml->olAlpha[4] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth5") == 0)
          cml->olWidth[4] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight5") == 0)
          cml->olHeight[4] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset5") == 0)
          cml->olXoffset[4] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset5") == 0)
          cml->olYoffset[4] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride5") == 0)
          cml->olYStride[4] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride5") == 0)
          cml->olUVStride[4] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth5") == 0)
          cml->olCropWidth[4] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight5") == 0)
          cml->olCropHeight[4] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset5") == 0)
          cml->olCropXoffset[4] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset5") == 0)
          cml->olCropYoffset[4] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY5") == 0)
          cml->olBitmapY[4] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU5") == 0)
          cml->olBitmapU[4] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV5") == 0)
          cml->olBitmapV[4] = atoi(p);

        if (strcmp(prm.longOpt, "olInput6") == 0)
          cml->olInput[5] = p;
        if (strcmp(prm.longOpt, "olFormat6") == 0)
          cml->olFormat[5] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha6") == 0)
          cml->olAlpha[5] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth6") == 0)
          cml->olWidth[5] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight6") == 0)
          cml->olHeight[5] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset6") == 0)
          cml->olXoffset[5] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset6") == 0)
          cml->olYoffset[5] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride6") == 0)
          cml->olYStride[5] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride6") == 0)
          cml->olUVStride[5] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth6") == 0)
          cml->olCropWidth[5] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight6") == 0)
          cml->olCropHeight[5] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset6") == 0)
          cml->olCropXoffset[5] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset6") == 0)
          cml->olCropYoffset[5] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY6") == 0)
          cml->olBitmapY[5] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU6") == 0)
          cml->olBitmapU[5] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV6") == 0)
          cml->olBitmapV[5] = atoi(p);

        if (strcmp(prm.longOpt, "olInput7") == 0)
          cml->olInput[6] = p;
        if (strcmp(prm.longOpt, "olFormat7") == 0)
          cml->olFormat[6] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha7") == 0)
          cml->olAlpha[6] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth7") == 0)
          cml->olWidth[6] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight7") == 0)
          cml->olHeight[6] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset7") == 0)
          cml->olXoffset[6] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset7") == 0)
          cml->olYoffset[6] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride7") == 0)
          cml->olYStride[6] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride7") == 0)
          cml->olUVStride[6] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth7") == 0)
          cml->olCropWidth[6] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight7") == 0)
          cml->olCropHeight[6] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset7") == 0)
          cml->olCropXoffset[6] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset7") == 0)
          cml->olCropYoffset[6] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY7") == 0)
          cml->olBitmapY[6] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU7") == 0)
          cml->olBitmapU[6] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV7") == 0)
          cml->olBitmapV[6] = atoi(p);

        if (strcmp(prm.longOpt, "olInput8") == 0)
          cml->olInput[7] = p;
        if (strcmp(prm.longOpt, "olFormat8") == 0)
          cml->olFormat[7] = atoi(p);
        if (strcmp(prm.longOpt, "olAlpha8") == 0)
          cml->olAlpha[7] = atoi(p);
        if (strcmp(prm.longOpt, "olWidth8") == 0)
          cml->olWidth[7] = atoi(p);
        if (strcmp(prm.longOpt, "olHeight8") == 0)
          cml->olHeight[7] = atoi(p);
        if (strcmp(prm.longOpt, "olXoffset8") == 0)
          cml->olXoffset[7] = atoi(p);
        if (strcmp(prm.longOpt, "olYoffset8") == 0)
          cml->olYoffset[7] = atoi(p);
        if (strcmp(prm.longOpt, "olYStride8") == 0)
          cml->olYStride[7] = atoi(p);
        if (strcmp(prm.longOpt, "olUVStride8") == 0)
          cml->olUVStride[7] = atoi(p);
        if (strcmp(prm.longOpt, "olCropWidth8") == 0)
          cml->olCropWidth[7] = atoi(p);
        if (strcmp(prm.longOpt, "olCropHeight8") == 0)
          cml->olCropHeight[7] = atoi(p);
        if (strcmp(prm.longOpt, "olCropXoffset8") == 0)
          cml->olCropXoffset[7] = atoi(p);
        if (strcmp(prm.longOpt, "olCropYoffset8") == 0)
          cml->olCropYoffset[7] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapY8") == 0)
          cml->olBitmapY[7] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapU8") == 0)
          cml->olBitmapU[7] = atoi(p);
        if (strcmp(prm.longOpt, "olBitmapV8") == 0)
          cml->olBitmapV[7] = atoi(p);

        if (strcmp(prm.longOpt, "codedChromaIdc") == 0)
          cml->codedChromaIdc = atoi(p);

        if (strcmp(prm.longOpt, "aq_mode") == 0)
          cml->aq_mode = atoi(p);
        if (strcmp(prm.longOpt, "aq_strength") == 0)
          cml->aq_strength = atof(p);

        if (strcmp(prm.longOpt, "writeReconToDDR") == 0)
          cml->writeReconToDDR = atoi(p);

        if (strcmp(prm.longOpt, "TxTypeSearchEnable") == 0)
          cml->TxTypeSearchEnable = atoi(p);
        if (strcmp(prm.longOpt, "av1InterFiltSwitch") == 0)
          cml->av1InterFiltSwitch = atoi(p);

        if (strcmp(prm.longOpt, "preset") == 0)
        {
          cml->preset = atof(p);
          Parameter_Preset(cml);
        }
        if (strcmp(prm.longOpt, "tune") == 0)
        {
          if(strcmp(p,"psnr") == 0)
            cml->tune = VCENC_TUNE_PSNR;
          else if(strcmp(p,"ssim") == 0)
            cml->tune = VCENC_TUNE_SSIM;
          else if(strcmp(p,"visual") == 0)
            cml->tune = VCENC_TUNE_VISUAL;
          else if(strcmp(p,"sharpness_visual") == 0)
            cml->tune = VCENC_TUNE_SHARP_VISUAL;
#ifdef VMAF_SUPPORT
          else if(strcmp(p,"vmaf") == 0)
            cml->tune = 4;
#endif
          else if(p[0] >= '0' && p[0] <= '9')
            cml->tune = atoi(p);
          else {
            fprintf(stderr, "unknown tuning option\n");
            status = NOK;
          }
        }
        if (strcmp(prm.longOpt, "extSEI") == 0)
          cml->extSEI = p;

        if (strcmp(prm.longOpt, "resendParamSet") == 0)
          cml->resendParamSet = atoi(p);

        if(strcmp(prm.longOpt, "sendAUD") == 0)
          cml->sendAUD = atoi(p);

        if(strcmp(prm.longOpt, "mosaicEnables") == 0)
          cml->mosaicEnables = atoi(p);

        if (strcmp(prm.longOpt, "mosArea01") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[0] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[0] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[0] = atoi(p) - cml->mosXoffset[0];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[0] = atoi(p) - cml->mosYoffset[0];
        }

        if (strcmp(prm.longOpt, "mosArea02") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[1] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[1] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[1] = atoi(p) - cml->mosXoffset[1];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[1] = atoi(p) - cml->mosYoffset[1];
        }

        if (strcmp(prm.longOpt, "mosArea03") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[2] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[2] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[2] = atoi(p) - cml->mosXoffset[2];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[2] = atoi(p) - cml->mosYoffset[2];
        }

        if (strcmp(prm.longOpt, "mosArea04") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[3] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[3] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[3] = atoi(p) - cml->mosXoffset[3];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[3] = atoi(p) - cml->mosYoffset[3];
        }

        if (strcmp(prm.longOpt, "mosArea05") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[4] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[4] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[4] = atoi(p) - cml->mosXoffset[4];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[4] = atoi(p) - cml->mosYoffset[4];
        }

        if (strcmp(prm.longOpt, "mosArea06") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[5] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[5] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[5] = atoi(p) - cml->mosXoffset[5];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[5] = atoi(p) - cml->mosYoffset[5];
        }

        if (strcmp(prm.longOpt, "mosArea07") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[6] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[6] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[6] = atoi(p) - cml->mosXoffset[6];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[6] = atoi(p) - cml->mosYoffset[6];
        }

        if (strcmp(prm.longOpt, "mosArea08") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[7] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[7] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[7] = atoi(p) - cml->mosXoffset[7];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[7] = atoi(p) - cml->mosYoffset[7];
        }

        if (strcmp(prm.longOpt, "mosArea09") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[8] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[8] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[8] = atoi(p) - cml->mosXoffset[8];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[8] = atoi(p) - cml->mosYoffset[8];
        }

        if (strcmp(prm.longOpt, "mosArea10") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[9] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[9] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[9] = atoi(p) - cml->mosXoffset[9];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[9] = atoi(p) - cml->mosYoffset[9];
        }

        if (strcmp(prm.longOpt, "mosArea11") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[10] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[10] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[10] = atoi(p) - cml->mosXoffset[10];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[10] = atoi(p) - cml->mosYoffset[10];
        }

        if (strcmp(prm.longOpt, "mosArea12") == 0)
        {
          /* Argument must be "xx:yy:XX:YY".
           * xx is left coordinate, replace first ':' with 0 */
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosXoffset[11] = atoi(p);
          /* yy is top coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosYoffset[11] = atoi(p);
          /* XX is right coordinate */
          p += i + 1;
          if ((i = ParseDelim(p, ':')) == -1) break;
          cml->mosWidth[11] = atoi(p) - cml->mosXoffset[11];
          /* YY is bottom coordinate */
          p += i + 1;
          cml->mosHeight[11] = atoi(p) - cml->mosYoffset[11];
        }

        /* SRAM Power down disable */
        if(strcmp(prm.longOpt, "sramPowerdownDisable") == 0)
          cml->sramPowerdownDisable = atoi(p);

        if(strcmp(prm.longOpt, "insertIDR") == 0)
          cml->insertIDR = atoi(p);

        if(strcmp(prm.longOpt, "rdLog") == 0)
          cml->bRdLog = atoi(p);

        /* User provided ME1N MVs */
        if (strcmp(prm.longOpt, "replaceMvFile") == 0)
          cml->replaceMvFile = p;

        if (strcmp(prm.longOpt, "inputFileList") == 0)
          cml->inputFileList = p;

        /*AXI max burst length */
        if (strcmp(prm.longOpt, "burstMaxLength") == 0)
          cml->burstMaxLength = atoi(p);

        break;
      default:
        break;
    }
  }

#ifdef __FREERTOS__
#ifndef FREERTOS_SIMULATOR
#include "user_freertos.h"
  extern u8 user_freertos_vcmd_en;
  if(cml->sliceSize > 1) { //VCMD HW not support the multi slice, so here bypass vcmd
    user_freertos_vcmd_en = 0;
  }
  Platform_init();
#endif
#endif

  if(Parameter_Check(cml) != OK)
    status = NOK;

  return status;
}

/*------------------------------------------------------------------------------
  change_input
------------------------------------------------------------------------------*/
i32 change_input(struct test_bench *tb)
{
  struct parameter prm;
  i32 enable = HANTRO_FALSE;
  i32 ret;

  prm.cnt = 1;
  while ((ret = get_option(tb->argc, tb->argv, options, &prm)) != -1)
  {
    if ((ret == 1) && enable)
    {
      tb->input = prm.argument;
      printf("Next input file %s\n", tb->input);
      return OK;
    }
    if (prm.argument == tb->input)
    {
      enable = HANTRO_TRUE;
    }
  }

  return NOK;
}


/*------------------------------------------------------------------------------
  default_parameter
------------------------------------------------------------------------------*/
void default_parameter(commandLine_s *cml)
{
  int i;
  memset(cml, 0, sizeof(commandLine_s));

  cml->useVcmd  = -1;
  cml->useDec400  = 0;
  cml->useMMU   = 0;
  cml->useL2Cache =0;

  cml->input      = "input.yuv";
  cml->output     = "stream.hevc";
  cml->recon      = "deblock.yuv";
  cml->firstPic    = 0;
  cml->lastPic   = 100;
  cml->inputRateNumer      = 30;
  cml->inputRateDenom      = 1;
  cml->outputRateNumer      = DEFAULT;
  cml->outputRateDenom      = DEFAULT;
  cml->test_data_files    = getenv("TEST_DATA_FILES");
  cml->lumWidthSrc      = DEFAULT;
  cml->lumHeightSrc     = DEFAULT;
  cml->horOffsetSrc = DEFAULT;
  cml->verOffsetSrc = DEFAULT;
  cml->videoStab = DEFAULT;
  cml->rotation = 0;
  cml->inputFormat = 0;
  cml->formatCustomizedType = -1;

  cml->width      = DEFAULT;
  cml->height     = DEFAULT;
  cml->max_cu_size  = 64;
  cml->min_cu_size  = 8;
  cml->max_tr_size  = 16;
  cml->min_tr_size  = 4;
  cml->tr_depth_intra = 2;  //mfu =>0
  cml->tr_depth_inter = (cml->max_cu_size == 64) ? 4 : 3;
  cml->intraPicRate   = 0;  // only first is IDR.
  cml->codecFormat = VCENC_VIDEO_CODEC_HEVC;
#ifdef CODEC_FORMAT
  cml->codecFormat = CODEC_FORMAT;
#endif
  if(IS_H264(cml->codecFormat)) {
    cml->max_cu_size  = 16;
    cml->min_cu_size  = 8;
    cml->max_tr_size  = 16;
    cml->min_tr_size  = 4;
    cml->tr_depth_intra = 1;
    cml->tr_depth_inter = 2;
    cml->layerInRefIdc = 0;
  }

  cml->bitPerSecond = 1000000;
  cml->cpbMaxRate = 0;
  cml->bitVarRangeI = 10000;
  cml->bitVarRangeP = 10000;
  cml->bitVarRangeB = 10000;
  cml->tolMovingBitRate = 2000;
  cml->monitorFrames = DEFAULT;
  cml->tolCtbRcInter = DEFAULT;
  cml->tolCtbRcIntra = DEFAULT;
  cml->u32StaticSceneIbitPercent = 80;
  cml->intraQpDelta = DEFAULT;
  cml->bFrameQpDelta = -1;

  cml->disableDeblocking = 0;
  cml->tc_Offset = 0;
  cml->beta_Offset = 0;

  cml->qpHdr = DEFAULT;
  cml->qpMin = DEFAULT;
  cml->qpMax = DEFAULT;
  cml->qpMinI = DEFAULT;
  cml->qpMaxI = DEFAULT;
  cml->picRc = DEFAULT;
  cml->ctbRc = DEFAULT; //CTB_RC
  cml->cpbSize = DEFAULT;
  cml->bitrateWindow = DEFAULT;
  cml->fixedIntraQp = 0;
  cml->hrdConformance = 0;
  cml->smoothPsnrInGOP = 0;
  cml->vbr = 0;

  cml->byteStream = 1;

  cml->chromaQpOffset = 0;

  cml->enableSao = 1;

  cml->strong_intra_smoothing_enabled_flag = 0;

  cml->pcm_loop_filter_disabled_flag = 0;

  cml->intraAreaLeft = cml->intraAreaRight = cml->intraAreaTop =
                         cml->intraAreaBottom = -1;  /* Disabled */
  cml->ipcm1AreaLeft = cml->ipcm1AreaRight = cml->ipcm1AreaTop =
                         cml->ipcm1AreaBottom = -1;  /* Disabled */
  cml->ipcm2AreaLeft = cml->ipcm2AreaRight = cml->ipcm2AreaTop =
                         cml->ipcm2AreaBottom = -1;  /* Disabled */

  cml->ipcm3AreaLeft = cml->ipcm3AreaRight = cml->ipcm3AreaTop =
                         cml->ipcm3AreaBottom = -1;  /* Disabled */
  cml->ipcm4AreaLeft = cml->ipcm4AreaRight = cml->ipcm4AreaTop =
                         cml->ipcm4AreaBottom = -1;  /* Disabled */
  cml->ipcm5AreaLeft = cml->ipcm5AreaRight = cml->ipcm5AreaTop =
                         cml->ipcm5AreaBottom = -1;  /* Disabled */
  cml->ipcm6AreaLeft = cml->ipcm6AreaRight = cml->ipcm6AreaTop =
                         cml->ipcm6AreaBottom = -1;  /* Disabled */
  cml->ipcm7AreaLeft = cml->ipcm7AreaRight = cml->ipcm7AreaTop =
                         cml->ipcm7AreaBottom = -1;  /* Disabled */
  cml->ipcm8AreaLeft = cml->ipcm8AreaRight = cml->ipcm8AreaTop =
                         cml->ipcm8AreaBottom = -1;  /* Disabled */
  cml->gdrDuration=0;

  cml->picSkip = 0;

  cml->sliceSize = 0;

  cml->enableCabac = 1;
  cml->cabacInitFlag = 0;
  cml->cirStart = 0;
  cml->cirInterval = 0;
  cml->enableDeblockOverride = 0;
  cml->deblockOverride = 0;

  cml->enableScalingList = 0;

  cml->compressor = 0;
  cml->sei = 0;
  cml->videoRange = 0;
  cml->level = DEFAULT;
  cml->profile = DEFAULT;
  cml->tier = DEFAULT;
  cml->bitDepthLuma = DEFAULT;
  cml->bitDepthChroma= DEFAULT;
  cml->blockRCSize= DEFAULT;
  cml->rcQpDeltaRange = DEFAULT;
  cml->rcBaseMBComplexity = DEFAULT;
  cml->picQpDeltaMin = DEFAULT;
  cml->picQpDeltaMax = DEFAULT;
  cml->ctbRcRowQpStep = DEFAULT;

  cml->gopSize = 0;
  cml->gopCfg = NULL;
  cml->gopLowdelay = 0;
  cml->longTermGap = 0;
  cml->longTermGapOffset = 0;
  cml->longTermQpDelta = 0;
  cml->ltrInterval = DEFAULT;

  cml->flexRefs = NULL;

  cml->outReconFrame=1;

  cml->roiMapDeltaQpBlockUnit=0;
  cml->roiMapDeltaQpEnable=0;
  cml->roiMapDeltaQpFile = NULL;
  cml->roiMapDeltaQpBinFile = NULL;
  cml->roiMapInfoBinFile        = NULL;
  cml->RoimapCuCtrlInfoBinFile  = NULL;
  cml->RoimapCuCtrlIndexBinFile = NULL;
  cml->RoiCuCtrlVer  = 0;
  cml->RoiQpDeltaVer = 1;
  cml->ipcmMapEnable = 0;
  cml->ipcmMapFile = NULL;
  cml->roi1Qp = DEFAULT;
  cml->roi2Qp = DEFAULT;
  cml->roi3Qp = DEFAULT;
  cml->roi4Qp = DEFAULT;
  cml->roi5Qp = DEFAULT;
  cml->roi6Qp = DEFAULT;
  cml->roi7Qp = DEFAULT;
  cml->roi8Qp = DEFAULT;

  cml->interlacedFrame = 0;
  cml->noiseReductionEnable = 0;

  /* low latency */
  cml->inputLineBufMode = 0;
  cml->inputLineBufDepth = DEFAULT;
  cml->amountPerLoopBack = 0;

  /*stride*/
  cml->exp_of_input_alignment = 6;
  cml->exp_of_ref_alignment = 6;
  cml->exp_of_ref_ch_alignment = 6;
  cml->exp_of_aqinfo_alignment = 6;

  cml->multimode = 0;
  cml->nstream = 0;
  for(i = 0; i < MAX_STREAMS; i++)
    cml->streamcfg[i] = NULL;

  cml->enableOutputCuInfo = 0;
  cml->enableOutputCtbBits = 0;
  cml->P010RefEnable = 0;

  cml->rdoLevel = 3;
  cml->dynamicRdoCu16Bias = 3;
  cml->dynamicRdoCu16Factor = 80;
  cml->dynamicRdoCu32Bias = 2;
  cml->dynamicRdoCu32Factor = 32;
  cml->dynamicRdoEnable = 0;
  cml->hashtype = 0;
  cml->verbose = 0;

  /* smart */
  cml->smartModeEnable = 0;
  cml->smartH264LumDcTh = 5;
  cml->smartH264CbDcTh = 1;
  cml->smartH264CrDcTh = 1;
  cml->smartHevcLumDcTh[0] = 2;
  cml->smartHevcLumDcTh[1] = 2;
  cml->smartHevcLumDcTh[2] = 2;
  cml->smartHevcChrDcTh[0] = 2;
  cml->smartHevcChrDcTh[1] = 2;
  cml->smartHevcChrDcTh[2] = 2;
  cml->smartHevcLumAcNumTh[0] = 12;
  cml->smartHevcLumAcNumTh[1] = 51;
  cml->smartHevcLumAcNumTh[2] = 204;
  cml->smartHevcChrAcNumTh[0] = 3;
  cml->smartHevcChrAcNumTh[1] = 12;
  cml->smartHevcChrAcNumTh[2] = 51;
  cml->smartH264Qp = 30;
  cml->smartHevcLumQp = 30;
  cml->smartHevcChrQp = 30;
  cml->smartMeanTh[0] = 5;
  cml->smartMeanTh[1] = 5;
  cml->smartMeanTh[2] = 5;
  cml->smartMeanTh[3] = 5;
  cml->smartPixNumCntTh = 0;

  /* constant chroma control */
  cml->constChromaEn = 0;
  cml->constCb = DEFAULT;
  cml->constCr = DEFAULT;

  for (i = 0; i < MAX_SCENE_CHANGE; i ++)
    cml->sceneChange[i] = 0;

  cml->tiles_enabled_flag = 0;
  cml->num_tile_columns = 1;
  cml->num_tile_rows  = 1;
  cml->loop_filter_across_tiles_enabled_flag = 1;

  cml->skip_frame_enabled_flag=0;
  cml->skip_frame_poc=0;

  /* HDR10 */
  cml->hdr10_display_enable = 0;
  cml->hdr10_dx0 = 0;
  cml->hdr10_dy0 = 0;
  cml->hdr10_dx1 = 0;
  cml->hdr10_dy1 = 0;
  cml->hdr10_dx2 = 0;
  cml->hdr10_dy2 = 0;
  cml->hdr10_wx  = 0;
  cml->hdr10_wy  = 0;
  cml->hdr10_maxluma = 0;
  cml->hdr10_minluma = 0;

  cml->hdr10_lightlevel_enable = 0;
  cml->hdr10_maxlight          = 0;
  cml->hdr10_avglight          = 0;

  cml->vuiColorDescripPresentFlag    = 0;
  cml->vuiColorPrimaries             = 9;
  cml->vuiTransferCharacteristics    = 0;
  cml->vuiMatrixCoefficients         = 9;
  cml->vuiVideoFormat                = 5;
  cml->vuiVideoSignalTypePresentFlag = 0;
  cml->vuiAspectRatioWidth           = 0;
  cml->vuiAspectRatioHeight          = 0;

  cml->picOrderCntType = 0;
  cml->log2MaxPicOrderCntLsb = 16;
  cml->log2MaxFrameNum = 12;

  cml->RpsInSliceHeader = 0;
  cml->ssim = 1;
  cml->psnr = 1;
  cml->vui_timing_info_enable = 1;
  cml->halfDsInput = NULL;
  cml->inLoopDSRatio = 1;

  /* skip mode */
  cml->skipMapEnable = 0;
  cml->skipMapFile = NULL;
  cml->skipMapBlockUnit = 0;

  /* rdoq mode */
  cml->rdoqMapEnable = 0;

  /* Frame-level core parallelism option */
  cml->parallelCoreNum =1;

  /* two stream buffer */
  cml->streamBufChain = 0;

  /*multi-segment of stream buffer*/
  cml->streamMultiSegmentMode = 0;
  cml->streamMultiSegmentAmount = 4;

  /*dump register*/
  cml->dumpRegister = 0;

  cml->rasterscan = 0;
  cml->cuInfoVersion = -1;

#ifdef RECON_REF_1KB_BURST_RW
  cml->exp_of_input_alignment = 10;
  cml->exp_of_ref_alignment = 10;
  cml->exp_of_ref_ch_alignment = 10;
  cml->compressor = 2;
#endif
#ifdef RECON_REF_ALIGN64
  cml->exp_of_ref_alignment = 6;
  cml->exp_of_ref_ch_alignment = 6;
#endif

  cml->enableRdoQuant = DEFAULT;

  /*CRF constant*/
  cml->crf = -1;

  /*external SRAM*/
  cml->extSramLumHeightBwd = IS_H264(cml->codecFormat) ? 12 : (IS_HEVC(cml->codecFormat) ? 16 : 0);
  cml->extSramChrHeightBwd = IS_H264(cml->codecFormat) ? 6  : (IS_HEVC(cml->codecFormat) ? 8 : 0);
  cml->extSramLumHeightFwd = IS_H264(cml->codecFormat) ? 12 : (IS_HEVC(cml->codecFormat) ? 16 : 0);
  cml->extSramChrHeightFwd = IS_H264(cml->codecFormat) ? 6  : (IS_HEVC(cml->codecFormat) ? 8 : 0);

  /* AXI alignment */
  cml->AXIAlignment = 0;

  /* MMU */
  cml->mmuEnable = 0;

  /* sliceNode */
  cml->sliceNode = 0;

  /*Ivf support*/
  cml->ivf = 1;

  /*DEC400 compress table*/
  cml->dec400CompTableinput      = "dec400CompTableinput.bin";
  cml->osdDec400CompTableInput      = NULL;

  /*PSY factor*/
  cml->psyFactor = DEFAULT;

  /*Overlay*/
  cml->overlayEnables = 0;
  for(i = 0; i < MAX_OVERLAY_NUM; i++)
  {
    cml->olInput[i] = "olInput.yuv";
    cml->olFormat[i] = 0;
    cml->olAlpha[i] = 0;
    cml->olWidth[i] = 0;
    cml->olCropWidth[i] = 0;
    cml->olScaleWidth[i] = 0;
    cml->olHeight[i] = 0;
    cml->olCropHeight[i] = 0;
    cml->olScaleHeight[i] = 0;
    cml->olXoffset[i] = 0;
    cml->olCropXoffset[i] = 0;
    cml->olYoffset[i] = 0;
    cml->olCropYoffset[i] = 0;
    cml->olYStride[i] = 0;
    cml->olUVStride[i] = 0;
    cml->olBitmapY[i] = 0;
    cml->olBitmapU[i] = 0;
    cml->olBitmapV[i] = 0;
    cml->olSuperTile[i] = 0;
  }

  /* mosaic */
  cml->mosaicEnables = 0;
  for(i = 0; i <MAX_MOSAIC_NUM; i++)
  {
    cml->mosHeight[i] = 0;
    cml->mosWidth[i] = 0;
    cml->mosXoffset[i] = 0;
    cml->mosYoffset[i] = 0;
  }
  
  cml->codedChromaIdc = VCENC_CHROMA_IDC_420;
  cml->aq_mode     = DEFAULT;
  cml->aq_strength = DEFAULT;

  cml->preset = DEFAULT;

  cml->writeReconToDDR = 1;

  cml->TxTypeSearchEnable = 0;
  cml->av1InterFiltSwitch = 1;

	cml->sendAUD = 0;

  cml->extSEI = NULL;
  cml->tune   = VCENC_TUNE_PSNR;
  cml->b_vmaf_preprocess = 0;

  cml->resendParamSet = 0;

  cml->sramPowerdownDisable = 0;
  
  cml->insertIDR = 0;

  cml->replaceMvFile = NULL;

  cml->inputFileList = NULL;

  /*AXI max burst length */
  cml->burstMaxLength = ENCH2_DEFAULT_BURST_LENGTH;
}


int parse_stream_cfg(const char *streamcfg, commandLine_s *pcml)
{
  i32 ret, i;
  char *p;
  FILE *fp = fopen(streamcfg, "r");
  default_parameter(pcml);
  if(fp == NULL)
    return NOK;
  if((ret = fseek(fp, 0, SEEK_END)) < 0)
  {
    fclose(fp);
    return NOK;
  }
  i32 fsize = ftell(fp);
  if(fsize < 0)
  {
    fclose(fp);
    return NOK;
  }
  if((ret = fseek(fp, 0, SEEK_SET)) < 0)
  {
    fclose(fp);
    return NOK;
  }
  pcml->argv = (char **)malloc(MAXARGS*sizeof(char *));
  pcml->argv[0] = (char *)malloc(fsize);
  ret = fread(pcml->argv[0], 1, fsize, fp);
  if(ret < 0)
  {
    fclose(fp);
    return ret;
  }
  fclose(fp);

  p = pcml->argv[0];
  for(i = 1; i < MAXARGS; i++) {
    while(*p && *p <= 32)
      ++p;
    if(!*p) break;
    pcml->argv[i] = p;
    while(*p > 32)
      ++p;
    *p = 0; ++p;
  }
  pcml->argc = i;
  if (Parameter_Get(pcml->argc, pcml->argv, pcml))
  {
    Error(2, ERR, "Input parameter error");
    return NOK;
  }
  return OK;
}

