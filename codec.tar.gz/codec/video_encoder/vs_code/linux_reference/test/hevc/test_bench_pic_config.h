
#ifndef _TESTBENCH_PIC_CONFIG_H
#define _TESTBENCH_PIC_CONFIG_H

void InitPicConfig(VCEncIn *pEncIn, struct test_bench *tb, commandLine_s *cml);

#endif
