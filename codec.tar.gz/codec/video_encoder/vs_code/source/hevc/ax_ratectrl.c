
#include "ax_ratectrl.h"
#include "rate_control_picture.h"

#define AX_MAX(a, b) ((a) > (b) ? (a) : (b))
#define AX_MIN(a, b) (((a) < (b)) ? (a) : (b))

#define MIN_P_FRM_CNT 5
#define PERCENT_TARGET 20

int InitRcModel(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config)
{
    int tmp;
    int err = 0;
    int a = 0;
    int b = 0;
    int c = 0;

    --err;
    if(!rc || !config)
    {
        return err; //-1
    }

    --err;
    if(!config->stat_period)
    {
        return err; //-2
    }

    //rate_target is required
    --err;
    if(!config->rate_target)
    {
        return err; //-3
    }

    --err;
    tmp = config->frame_width * config->frame_height * config->bits_per_pixel;
    if(!tmp)
    {
        return err; //-4
    }

    //reset RC model
    memset(rc, 0, sizeof(AX_RC_MODEL_CTX));

    //copy user config to RC context, each stream requires one context
    rc->config = *config;

    if(!rc->config.start_qp)
    {
        rc->config.start_qp = AX_DEFAULT_START_QP;
    }

    if(!rc->config.start_I_ratio)
    {
        rc->config.start_I_ratio = AX_DEFAULT_IRATIO;
    }

    // ensure batch >= 2, so we can update I_ratio mode
    if (rc->config.stat_period <=1)
    {
        rc->config.stat_period = rc->config.stat_period *2;
        rc->config.rate_target = rc->config.rate_target*2;
    }

    if(!rc->config.batch_size)
    {

        if(rc->config.stat_period > 20)
        {
            rc->config.batch_size = AX_DEFAULT_RC_BATCH;
        } else if(rc->config.stat_period <5 && rc->config.stat_period >= 2)
        {
            rc->config.batch_size = 2;
        } else if(rc->config.stat_period <2)
        {
            rc->config.batch_size = 1;
        } else
        {
            rc->config.batch_size = rc->config.stat_period /5;
        }
    }

    rc->config.min_qp[0] = AX_SEARCH_QPRANGE_LO;

    //caution: Isize is in bits but rate_traget is in kbits, ratio is percent, thus total need x10
    rc->Isize_pred = (rc->config.rate_target * rc->config.start_I_ratio) * 10;
    if(rc->config.stat_period>1)
    {
        rc->Psize_pred = (rc->config.rate_target * 1000 - rc->Isize_pred) / (rc->config.stat_period - 1);
    } else{
        rc->Psize_pred = rc->config.rate_target * 1000 - rc->Isize_pred;
    }

    rc->bits_remaining = (rc->config.rate_target * 1000);

    // init pred matrix
    rc->func_coeff[0][0] = AX_DEFAULT_POLY_A;
    rc->func_coeff[0][1] = AX_DEFAULT_POLY_B;
    rc->func_coeff[0][2] = rc->config.rate_target / 36 - (a * 784 + b * 28);
    rc->func_coeff[1][0] = -6200;
    rc->func_coeff[1][1] = 328000;

    setFuncQp(rc, 0);

#ifdef AX_CBR_DEBUG
    printf("%s:%d - Isize_pred=%lld, Psize_pred=%lld, bits_remaining=%lld.\n",
            __func__, __LINE__,
            rc->Isize_pred,
            rc->Psize_pred,
            rc->bits_remaining);
#endif

    return 0;
}

int setFuncQp(AX_RC_MODEL_CTX *rc, bool bIframe)
{
    int i = rc->config.min_qp[0];
    int j = AX_SEARCH_QPRANGE_HI;
    int func_hi = 38;
    int a, b, c, d, m, k;

    a = rc->func_coeff[0][0];
    b = rc->func_coeff[0][1];
    c = rc->func_coeff[0][2];
    m = rc->func_coeff[1][0];
    k = rc->func_coeff[1][1];

    for(; !bIframe && i<=AX_SEARCH_QPRANGE_HI; i++)
    {
        d = (a * i * i + b * i + c)  ;
        if(d > 100 && i <func_hi)
        {
            rc->Pframe_size_pred[i] = d << 10;
        }else if((m * i + k)>10240)
        {
            rc->Pframe_size_pred[i] = m * i + k;
        } else
        {
            rc->Pframe_size_pred[i] = 10240;
        }
    }
    return 0;
}

int GetNextQp(AX_RC_MODEL_CTX *rc, bool bIframe, int model_flag)
{
#ifdef AX_CBR_DEBUG
    printf("%s:%d - bIframe=%d.\n", __func__, __LINE__, bIframe);
    printf("====== frame_encoded_cnt = %d \n", rc->frame_encoded_cnt);
#endif

    int pred;
    int qp;
    int qp_curr;
    //int I_ratio_use;
    int bits_remain;
    int gop_remain, stat_remain;
    int qp_former;
    int qp_drop;
    int num_Iframe_coming = 0;

    //frames in the same batch uses the same qp, disregard I/P type
    //batch idea is to smooth out between-frame jitter, can be bypassed
    //by setting batch size to one

    //proceed to qp calcuation if this is the first frame in a new batch

    if(bIframe)
    {
        qp_former = rc->qp_pred[0];
        //printf("[ax_ratectrl %s] qp_former %d. \n", __func__, qp_former);
        //record predicted qp for future use, currently only occupy first slot
        rc->qp_pred[0] = InterpolateIframeQp(rc);
        //printf("[ax_ratectrl %s] rc->qp_pred[0] %d, rc->frame_encoded_gop %d. \n", __func__, rc->qp_pred[0], rc->frame_encoded_gop);
        if((qp_former != 0) && (rc->qp_pred[0] < (qp_former-3)))
        {
            rc->qp_pred[0] = qp_former - 3; // 3 means 50% size adjust, ensure no breath effect
            rc->qp_pred[0] = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, rc->qp_pred[0]);
        }

        //printf("[ax_ratectrl %s] rc->qp_pred[0] %d, rc->frame_encoded_gop %d. \n", __func__, rc->qp_pred[0], rc->frame_encoded_gop);
        rc->qp_pred[1] = rc->qp_pred[0]; // every gop P frame's QP start at I's QP
        qp_curr = rc->qp_pred[0];
    }
    else
    {
        qp_former = rc->qp_pred[1];
        if (ABSrc(rc->Pframe_change_ratio_last) > AX_DEFAULT_MARGIN)
        {
            rc->batch_encoded = 0;
#ifdef AX_CBR_DEBUG
            printf("Pframe change ratio %d over 30\n", rc->Pframe_change_ratio_last);
#endif
        }

        if(rc->batch_encoded)
        {
#ifdef AX_CBR_DEBUG
	    printf("p frame get last batch qp %d\n", rc->qp_pred[1]);
#endif
            return rc->qp_pred[1];
        }

        bits_remain = rc->bits_remaining;
        gop_remain = rc->config.gop_size - rc->frame_encoded_gop;
        stat_remain = rc->config.stat_period - rc->frame_encoded_stat;
        num_Iframe_coming = stat_remain / rc->config.gop_size;

        //handle special scenario that an I frame is coming soon
        if(stat_remain > gop_remain)
        {
            stat_remain = stat_remain - num_Iframe_coming;
            bits_remain -= rc->Iframe_consumed_last * num_Iframe_coming;
        }

        pred = AX_MAX(256, bits_remain) / AX_MAX(1, stat_remain); //smallest P frame is 32B

        rc->Psize_pred = pred;

        if (ABSrc(rc->Pframe_change_ratio_last) <= AX_DEFAULT_MARGIN) {
            qp_drop = rc->config.rate_target /2000 + rc->config.batch_size /2 + 25/ rc->config.stat_period;
            qp_drop = CLIP3rc(3, 9, qp_drop);
        } else {
            qp_drop = rc->config.rate_target /2000 + 25/ rc->config.stat_period; // predect mode invalid, so qp_drop may not too big
            qp_drop = CLIP3rc(3, 5, qp_drop);
        }

        if(pred<256)
        {
#ifdef AX_CBR_DEBUG
            printf("p frame, pred: %d < 256, bit_reamin %d, start_remain %d \n", pred, bits_remain, stat_remain);
#endif
            if((rc->frame_encoded_stat+1) == rc->config.stat_period) // To do: no remaining size, should set qp max? and not change formar qp?
            {
                qp = qp_former;
                rc->qp_pred[1] = qp_former;
            } else
            rc->qp_pred[1] = qp_former + qp_drop; //AX_SEARCH_QPRANGE_HI;
            rc->qp_pred[1] = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, rc->qp_pred[1]);
            qp = qp_former + qp_drop;
        }
        else
        {
            qp = InterpolateQp(rc, bIframe, pred, model_flag);
#ifdef AX_CBR_DEBUG
            printf("p frame InterpolateQp bits_remain %d, stat_remain %d, gop_remain %d . qp_drop %d, predsize %d\n", bits_remain, stat_remain, gop_remain, qp_drop, pred);
#endif
#if 0
            if (ABSrc(rc->Pframe_change_ratio_last) >= AX_DEFAULT_MARGIN) {
                if (rc->Pframe_change_ratio_last > 0) { // real size too smaller
                    rc->qp_pred[1] = AX_MIN(qp_former - qp_drop, qp);
                } else {
                    rc->qp_pred[1] = AX_MAX(qp_former + qp_drop, qp);
                }
            } else {
                if(qp <(qp_former - qp_drop))
                {
                    rc->qp_pred[1] = qp_former - qp_drop;
                }
                else
                {
                    rc->qp_pred[1] = qp;
                }
            }
#else
            if(qp <(qp_former - qp_drop))
            {
                rc->qp_pred[1] = qp_former - qp_drop;
            }
            else
            {
                rc->qp_pred[1] = qp;
            }
#endif
            rc->qp_pred[1] = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, rc->qp_pred[1]);
        }

        if(qp > rc->config.max_qp[0] )
        {
            rc->qp_pred[1] = rc->config.max_qp[0];
        } else if(qp < rc->config.min_qp[0] )
        {
            rc->qp_pred[1] = rc->config.start_qp;
        }
        rc->qp_pred[1] = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, rc->qp_pred[1]);
        qp_curr = rc->qp_pred[1];

    }

    if(bIframe)
    {
#ifdef AX_CBR_DEBUG
    printf("%s:%d - I frame qp=%d.\n", __func__, __LINE__, rc->qp_pred[0]);
#endif
        return rc->qp_pred[0];
    } else
    {
#ifdef AX_CBR_DEBUG
    printf("%s:%d - P frame qp=%d.\n", __func__, __LINE__, rc->qp_pred[1]);
#endif
        return rc->qp_pred[1];
    }

}

/*
 * UpdateRcModel()
 * this func should be called after qp-size relation is known, the values
 * will be recorded and be used to predict next qp-size pair
 */
int UpdateRcModel(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int model_flag)
{
    int qpI = rc->qp_pred[0]; //get qp value for this frame
    int qpP = rc->qp_pred[1]; //get qp value for this frame
    int qp = 0;
    int i_size, p_size, divisor;

    // newRc debug
    rc->frame_encoded_cnt++;
#ifdef AX_CBR_DEBUG
    printf("Update Rc Model, encoded real size_bits %d\n", size_bits);
#endif

    if(++rc->batch_encoded >= rc->config.batch_size)
    {
        rc->batch_encoded = 0;
    }

    rc->bits_remaining -= size_bits;

    if(rc->bits_remaining < 0)
    {
        rc->bits_remaining = 0;
    }
    // printf("frame_encoded_stat %d, stat_period %d, ", rc->frame_encoded_stat, rc->config.stat_period);
    // start a new stat period when applicable
    if(++rc->frame_encoded_stat >= rc->config.stat_period)
    {
        rc->frame_encoded_stat = 0;
        rc->Iframe_consumed = 0;
        rc->Pframe_consumed = 0;
        rc->bits_remaining = (rc->config.rate_target * 950); // original * 1000, reserve 10% budget at the begining of a new period
    }

    if(bIframe)
    {
        qp = qpI;
        rc->frame_encoded_gop = 1;
        rc->Iframe_consumed += size_bits;
        rc->Isize_prev = size_bits;
        if(rc->Iframe_size_real[qpI] == 0){
            rc->Iframe_size_real[qpI] = size_bits;
        }else
        {
            rc->Iframe_size_real[qpI] = (rc->Iframe_size_real[qpI] + size_bits) >> 1;
        }
        rc->Iframe_consumed_last = size_bits;
    }
    else
    {
        qp = qpP;
        rc->frame_encoded_gop++;
        rc->Pframe_consumed += size_bits;
        if(rc->Pframe_size_real[qpP] == 0)
        {
            rc->Pframe_size_real[qpP] = size_bits;
        } else{
            rc->Pframe_size_real[qpP] =  (rc->Pframe_size_real[qpP] + size_bits ) >> 1;
        }
    }


    int num_Iframe = (rc->config.stat_period << 2)/rc->config.gop_size;
    //update I ratio for given qp, activated by P frame only
    if(!bIframe)
    {
        i_size = (num_Iframe*rc->Iframe_size_real[qpP]) >> 12;  //value must fix 60Mbits, could be zero too
        p_size = ((rc->config.stat_period<<2) - num_Iframe) * rc->Pframe_size_real[qpP] >> 12; //could be zero after shift
        divisor = (i_size + p_size);

        //printf("i_size %d, p_size %d, divisor %d. \n", i_size, p_size, divisor);

        if(i_size && divisor)
        {
            rc->rate_pred[qpP] = divisor; // test for P's QP to choose
            rc->I_ratio[qpP] =  (10000 * i_size) / divisor; // test for P's QP to choose
            //printf("[i_size && divisor] i_size %d, divisor %d, ", i_size, divisor);
        }

    }

    //printf("rc->rate_pred[qpP] %d.\n", rc->rate_pred[qpP]);

    if(!model_flag)
    {
        //printf("======================= %s  model_flag =======================\n", __func__);
        // if frameCnt +/- 30% from pred, update coefficient of predict functions
        int i = rc->config.min_qp[0];
        int func_hi = 38;
        int change_ratio;
        rc->change_cnt[0] = 0;
        rc->change_cnt[1] = 0;
        if (rc->Pframe_size_real[qpP])
            rc->Pframe_change_ratio_last = rc->Pframe_size_pred[qpP] * 100 / rc->Pframe_size_real[qpP] - 100;

        for(; i<= (AX_SEARCH_QPRANGE_HI-1); i++ )
        {
            if(rc->Pframe_size_real[i])
            {
                change_ratio =  rc->Pframe_size_pred[i] * 100 / rc->Pframe_size_real[i] - 100;
                //printf("[%s] i %d, Pframe_size_pred[i] %d, Pframe_size_real[i] %d, change_ratio %d.\n", __func__, i, rc->Pframe_size_pred[i], rc->Pframe_size_real[i], change_ratio);
                if(ABSrc(change_ratio) > AX_DEFAULT_MARGIN)
                {
                    if(i < func_hi)
                    {
                        rc->change_log[0][rc->change_cnt[0]] = i;
                        rc->change_cnt[0] += 1;
                        //printf("[%s] i %d, change_ratio %d.\n", __func__, i, change_ratio);
                    }
                    else
                    {
                        if(rc->Pframe_size_real[i] > 1024)
                        {
                            rc->change_log[1][rc->change_cnt[1]] = i;
                            rc->change_cnt[1] += 1;
                            //printf("[%s] i %d, change_ratio %d.\n", __func__, i, change_ratio);
                        }

                    }
                }
            }

        }
        // count over margin update func
        if(rc->change_cnt[0] > 2)
        {
            updateFuncQP(rc, bIframe);
            //printf("[%s] psize = %dx^2+ %dx +%d.\n", __func__, rc->func_coeff[0][0], rc->func_coeff[0][1], rc->func_coeff[0][2] );
            setFuncQp(rc, bIframe);
        }
        if(rc->change_cnt[1] > 1)
        {
            updateFuncQPhi(rc, bIframe);
            //printf("[%s] psize = %dx +%d.\n", __func__, rc->func_coeff[1][0], rc->func_coeff[1][1] );
            setFuncQp(rc, bIframe);
        }
    }

    return 0;
}

int updateFuncQP(AX_RC_MODEL_CTX *rc, bool bIframe)
{
    int q0, q1, q2, cnt;
    int s0, s1, s2;
    int a, b, c;
    int denominator;

    q0 = rc->change_log[0][0];
    cnt = rc->change_cnt[0]/2;
    q1 = rc->change_log[0][cnt];
    q2 = rc->change_log[0][rc->change_cnt[0]-1];
    s0 = rc->Pframe_size_real[q0]  >> 10;
    s1 = rc->Pframe_size_real[q1]  >> 10;
    s2 = rc->Pframe_size_real[q2]  >> 10;
    //printf("[%s] q0 %d, q1 %d, q2 %d, s0 %d, s1 %d, s2 %d.\n", __func__, q0, q1, q2, s0, s1, s2);

    denominator = (q0 - q1) * (q0 - q2) * (q1 - q2);
    a = (s0 * (q1 - q2) + s1 * (q2 - q0) + s2 * (q0 - q1)) / denominator;
    b = (s0-s2) / (q0 - q2) - (q0+q2) * a;
    c = s1 - a*q1*q1 - b*q1;
    rc->func_coeff[0][0] = a;
    rc->func_coeff[0][1] = b;
    rc->func_coeff[0][2] = c;

    return 0;
}

int updateFuncQPhi(AX_RC_MODEL_CTX *rc, bool bIframe)
{
    int q0, q1, cnt;
    int s0, s1;
    int m, k;
    int denominator;

    q0 = rc->change_log[1][0];
    q1 = rc->change_log[1][rc->change_cnt[1]-1];
    s0 = rc->Pframe_size_real[q0];
    s1 = rc->Pframe_size_real[q1];
    //printf("[%s] q0 %d, q1 %d, s0 %d, s1 %d.\n", __func__, q0, q1, s0, s1);

    m = (s1 -s0)/ (q1 - q0);
    k = s0 - q0 * m;
    rc->func_coeff[1][0] = m;
    rc->func_coeff[1][1] = k;

    return 0;
}

/*
 *------------------------------------------------------------------------------
 * internal functions only
 *------------------------------------------------------------------------------
 */

int FindNearestAnchorQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int *qp0, int *qp1)
{
    int i = rc->config.min_qp[0];
    int j = AX_SEARCH_QPRANGE_HI;
    int t0 = 0, t1 = 0;

    for(; bIframe && i<=AX_SEARCH_QPRANGE_HI; i++, j--)
    {
        //printf("[ax_ratectrl %s] i %d, Iframe_size_real %d.\n", __func__, i, rc->Iframe_size_real[i]);
        if(rc->Iframe_size_real[i])
        {
            if(rc->Iframe_size_real[i] >= size_bits)
            {
                t0 = i;
            }
        }

        if(rc->Iframe_size_real[j])
        {
            if(rc->Iframe_size_real[j] <= size_bits)
            {
                t1 = j;
            }
        }

    }

    //printf("[ax_ratectrl %s] size_bits %d; \n", __func__, size_bits);

    for(; !bIframe && i<=AX_SEARCH_QPRANGE_HI; i++, j--)
    {
        //printf("[ax_ratectrl %s] i %d, Pframe_size_real %d.\n", __func__, i, rc->Pframe_size_real[i]);

        if(rc->Pframe_size_real[i])
        {
            if(rc->Pframe_size_real[i] >= size_bits)
            {
                t0 = i;
            }
        }

        if(rc->Pframe_size_real[j])
        {
            if(rc->Pframe_size_real[j] <= size_bits)
            {
                t1 = j;
            }
        }

    }

    //printf("[ax_ratectrl %s] t0 %d, t1 %d.\n", __func__, t0, t1);

    if(1)
    {
        *qp0 = t0;
        *qp1 = t1;
    }

    return (t0 && t1);
}


int FindPredQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int *qp0, int *qp1)
{
    int i = rc->config.min_qp[0];
    int j = AX_SEARCH_QPRANGE_HI;
    int t0 = 0, t1 = 0;

    //printf("[ax_ratectrl %s] size_bits %d; \n", __func__, size_bits);

    for(; !bIframe && i<=AX_SEARCH_QPRANGE_HI; i++, j--)
    {
        //printf("[ax_ratectrl %s] i %d, Pframe_size_pred %d, Pframe_size_real %d.\n", __func__, i, rc->Pframe_size_pred[i], rc->Pframe_size_real[i]);

        if(rc->Pframe_size_pred[i])
        {
            if(rc->Pframe_size_pred[i] >= size_bits)
            {
                t0 = i;
            }
        }

        if(rc->Pframe_size_pred[j])
        {
            if(rc->Pframe_size_pred[j] <= size_bits)
            {
                t1 = j;
            }
        }
    }

    //printf("[ax_ratectrl %s] t0 %d, t1 %d.\n", __func__, t0, t1);

    if(1)
    {
        *qp0 = t0;
        *qp1 = t1;
    }

    return (t0 && t1);
}



/*
 * InterploateQp
 * given target bitsize, look up in table of history samples and
 * 1) try to find two anchor qp from above and below and do linear interpolation
 * 2) if only greater-sized samples available, predict (qp_greater+delta)
 * 3) if only smaller-sized samples available, predict (qp_smaller-delta)
 */
int InterpolateQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int model_flag)
{
    int v0, v1;
    int qp, qp0, qp1;
    int ret;

    if(model_flag) // 1 for real; 0 for pred
    {
        ret = FindNearestAnchorQp(rc, bIframe, size_bits, &qp0, &qp1);
    }else
    {
        ret = FindPredQp(rc, bIframe, size_bits, &qp0, &qp1);
    }

    if(!qp0 && !qp1)
    {
        return 0;
    }

    if(qp0 && !qp1)
    {
        qp = qp0 + 6; //predict (qp_greater+delta)
    }
    else if(!qp0 && qp1)
    {
        qp = qp1 - 6; //predict (qp_smaller-delta)
    }
    else
    {
        if(model_flag)
        {
            v0 = bIframe ? rc->Iframe_size_real[qp0] : rc->Pframe_size_real[qp0];
            v1 = bIframe ? rc->Iframe_size_real[qp1] : rc->Pframe_size_real[qp1];
        }else
        {
            v0 = bIframe ? rc->Iframe_size_pred[qp0] : rc->Pframe_size_pred[qp0];
            v1 = bIframe ? rc->Iframe_size_pred[qp1] : rc->Pframe_size_pred[qp1];
        }

        //prevent div zero
        if(v0 == v1)
        {
            return MAX(qp0, qp1);
        }

        qp = qp0 + (size_bits-v0)*(qp1-qp0) / (v1-v0);
    }

    if(qp > rc->config.max_qp[0])
        qp = rc->config.max_qp[0];

    if(qp < rc->config.min_qp[0])
        qp = rc->config.min_qp[0];

    return qp;
}

/*
 * InterploateIframeQp
 * I frame qp is especially important to minimize qp related breathing
 * I frame qp should be predicted based on current I ratio
 * if no I ratio statistics available, just follow previous qp
 */
int InterpolateIframeQp(AX_RC_MODEL_CTX *rc)
{
    int i = rc->config.min_qp[0];
    int j = AX_SEARCH_QPRANGE_HI;
    int t0=0, t1=0;
    int r0, r1, qp;

    for(; i<=AX_SEARCH_QPRANGE_HI; i++, j--)
    {
        // printf("[ax_ratectrl %s] i %d, rc->rate_pred[i] %d.\n", __func__, i, rc->rate_pred[i]);

        if(rc->rate_pred[i] && (rc->rate_pred[i] > rc->config.rate_target))
        {
            t0 = i;
        }

        if(rc->rate_pred[j] && (rc->rate_pred[j] < rc->config.rate_target))
        {
            t1 = j;
        }
    }
#ifdef AX_CBR_DEBUG
    printf("[ax_ratectrl %s] I frame t0 %d, t1 %d, rate_target %lld.\n", __func__, t0, t1, rc->config.rate_target);
#endif

    if(!t0 && !t1)
    {
        if(rc->qp_pred[0] && rc->qp_pred[1])
        {
            qp = (7 * rc->qp_pred[0] + rc->qp_pred[1]) / 8;
        } else
        {
            qp = rc->config.start_qp;
        }
        // if(rc->qp_pred[0])
        // {
        //     qp = rc->qp_pred[0];
        // } else
        // {
        //     qp = rc->config.start_qp;
        // }
    } else if(t1 && !t0)
    {
        if(rc->config.stat_period < 7)
        {
            qp = t1 - (10-rc->config.stat_period)/3;
        }
        else
        {
            qp = t1-1;
        }
    } else if(!t1 && t0)
    {
        qp = t0+3;
    } else
    {
        r0 = rc->rate_pred[t0];
        r1 = rc->rate_pred[t1];
        if(r0 == r1)
        {
            qp = (t0+t1) / 2;
        } else
        {
            qp = t0 + ((rc->config.rate_target - r0)*(t1-t0)*4 / (r1-r0) + 2) / 4;
        }

        if (qp == rc->qp_pred[0] && rc->rate_pred[qp])
        {
            if ((rc->rate_pred[qp] < (rc->config.rate_target*0.95)))
            {
                qp = qp - 1;
                qp = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, qp);
            }
            else
            {
                qp = qp + 1;
                qp = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, qp);
            }

        }
    }
    qp = CLIP3rc(AX_SEARCH_QPRANGE_LO, AX_SEARCH_QPRANGE_HI, qp);
    return qp;

}

static int AXRcUpdatePICompressRatio(AX_RC_MODEL_CTX *rc)
{
    int aver_P_qp = 0;
    int P_I_ratio = rc->P_I_ratio;
    if (rc->config.gop_size == 1) // all I frame no need to compute P_I_ratio
        return P_I_ratio;

    if (rc->num_p_frame) {
        aver_P_qp = ((rc->P_qp_total_gop << 2) / rc->num_p_frame >> 2);
    }

    // aver_P_qp = ((rc->P_qp_total_gop << 2) / (rc->config.gop_size - 1) >> 2);

    rc->avg_p_qp = aver_P_qp;

    /* first i aver_P_qp is 0 and I_qp_prev is -1 */
    if(aver_P_qp > 0 && rc->I_qp_prev > 0) {
        if (ABSrc(aver_P_qp - rc->I_qp_prev) >= 1) {
            if ((aver_P_qp - rc->I_qp_prev) >= 1) {
                P_I_ratio -= (P_I_ratio * ((aver_P_qp - rc->I_qp_prev) << 5) / 51) >> 3;
            } else if ((aver_P_qp - rc->I_qp_prev) <= -1) {
                P_I_ratio -= (P_I_ratio * ((aver_P_qp - rc->I_qp_prev) << 5) / 51) >> 3;
            }
        }
    }

    /* Pframe_mb_qp_average will be delayed 1 gop when stat_period > gop */
    if ((rc->Iframe_mb_qp_prev > 0) && (rc->Pframe_mb_qp_average > 0)) {
        if ((rc->Iframe_mb_qp_prev - rc->Pframe_mb_qp_average) > 0) {
            P_I_ratio += P_I_ratio * ((rc->Iframe_mb_qp_prev - rc->Pframe_mb_qp_average) / 6);
        } else {
            P_I_ratio += P_I_ratio * ((rc->Iframe_mb_qp_prev - rc->Pframe_mb_qp_average) / 12);
        }
    }

    P_I_ratio = CLIP3rc(rc->P_I_ratio_min, rc->P_I_ratio_max, P_I_ratio);
    // clear qp of last gop after updating PI compression ratio

#ifdef AX_CBR_DEBUG
    printf("%s:%d - P_I_ratio=%d, aver_P_qp %d, P_qp_total_gop %d\n",
            __func__, __LINE__,
            P_I_ratio,
            aver_P_qp,
            rc->P_qp_total_gop);
    printf("Iframe_mb_qp_prev %lf,  Pframe_mb_qp_average %lf\n",
            rc->Iframe_mb_qp_prev,
            rc->Pframe_mb_qp_average);
#endif
    rc->P_qp_total_gop = 0;
    rc->I_qp_total_gop = 0;

    return P_I_ratio; // I_ratio need * 100
}

static int AXRcUpdateIratio(int stat_period, int P_I_ratio, int I_qp_delta)
{
    int div = 0;
    int p_i_ratio = P_I_ratio - P_I_ratio * I_qp_delta * 3 / 51;
    div = stat_period + p_i_ratio - 1;
    if(div == 0) {
        return 40;
    }
    return (p_i_ratio * 100) / div; // I_ratio need * 100
}

void static AXRcIframeSizePred(AX_RC_MODEL_CTX *rc)
{
    int i_size_ratio = 0;
    long long int max_i_size = 0;
    long long int min_i_size = 0;
    int i_frm_cnt = 0;
    long long int bit_rate = rc->config.rate_target * AX_TARGET_PIC_SIZE_RATIO;
    int i_size_compare = 1;

    rc->P_I_ratio = AXRcUpdatePICompressRatio(rc);
    /* AXRcUpdateIratio will be called 3 times when it is in CLIP3rc */
    i_size_ratio = AXRcUpdateIratio(rc->config.stat_period, rc->P_I_ratio, rc->I_qp_delta);
    rc->I_size_ratio = CLIP3rc(1, 95, i_size_ratio);
    if(rc->config.gop_size == 1) {
        rc->I_size_ratio = 100 / rc->config.stat_period;
    }
    rc->Isize_pred = (rc->cur_target_bits * rc->I_size_ratio) / 100;

    /* if fps = 1 and gop = 2, i size / 2 */
    if ((rc->bps_ratio == 2 && rc->config.stat_period == 2)
        || (rc->bps_ratio == 2 && rc->config.stat_period == 4)) {
        rc->Isize_pred /= rc->bps_ratio;
        i_size_compare = 0;
    }

    if(rc->config.stat_period <= rc->config.gop_size) {
        i_frm_cnt = 1;
    } else {
        i_frm_cnt = rc->config.stat_period / rc->config.gop_size;
    }

    /* P_I_ratio_min >= 1, P_I_ratio_max >= P_I_ratio_min stat_period >= 1 */
    max_i_size = bit_rate * rc->P_I_ratio_max / (rc->P_I_ratio_max * i_frm_cnt + rc->config.stat_period - i_frm_cnt);
    min_i_size = bit_rate * rc->P_I_ratio_min / (rc->P_I_ratio_min * i_frm_cnt + rc->config.stat_period - i_frm_cnt);
    /*printf("[%s] min %lld max %lld pred %lld\n", __func__, min_i_size, max_i_size, rc->Isize_pred); */

    if(i_size_compare)
    {
        rc->Isize_pred = CLIP3rc(min_i_size, max_i_size, rc->Isize_pred);
    }

#ifdef AX_CBR_DEBUG
    printf("%s:%d - Isize_pred=%lld, Isize_ratio %d, P_I_ratio %d\n",
            __func__, __LINE__,
            rc->Isize_pred,
            rc->I_size_ratio,
            rc->P_I_ratio);
#endif
}

void static AXRcPframeSizePred(AX_RC_MODEL_CTX *rc)
{
    long long int pred_size = 0;
    long long int bits_remain = rc->bits_remaining;
    int gop_remain = rc->config.gop_size - rc->frame_encoded_gop;
    int stat_remain = rc->config.stat_period - rc->frame_encoded_stat;
    int num_Iframe_coming = (stat_remain + rc->frame_encoded_gop) / rc->config.gop_size;

    if (rc->Pframe_mb_qp_change_ratio) {
        bits_remain = bits_remain * rc->Pframe_mb_qp_change_ratio;
    }
    //handle special scenario that an I frame is coming soon
    if(stat_remain > gop_remain)
    {
        stat_remain = stat_remain - num_Iframe_coming;
        bits_remain -= rc->Isize_prev * num_Iframe_coming;
    }
    //bits_remain += rc->bits_adjust;

    pred_size = AX_MAX(256, bits_remain) / AX_MAX(1, stat_remain); //smallest P frame is 32B

#ifdef AX_CBR_DEBUG
    printf("%s:%d p frm pre size %lld remain %lld\n", __func__, __LINE__, pred_size, bits_remain);
#endif
    rc->Psize_pred = pred_size;
}

static int AXRcIframeQpPred(AX_RC_MODEL_CTX *rc, int size_bits)
{
    int Iqp = 0;
    int qp_drop = 0;
    rc->prevIDR = 1;
    rc->cnt = 0;
    if (rc->I_qp_prev != -1) {
        // keep I frame the same as last P frame, to avoid breath effect
        if (rc->P_qp_prev != -1  && rc->avg_p_qp) {
            // Iqp = (rc->P_qp_prev + rc->I_qp_prev) >> 1;
            //limit qp_Iframe_min and qp_Pframe_max when camera moving
            //and recover client's configuration qp_Iframe_min and qp_Pframe_max,
            //camera not moving
            if (false == rc->roi_enable)
            {
                if (rc->avg_p_qp > 35 && rc->P_qp_prev > 39)
                {
                    rc->config.min_qp[0] = 36;
                    rc->config.max_qp[1] = 46;
                    rc->limit_block_effect = 1;
                }
                else
                {
                    rc->config.min_qp[0] = rc->config.min_qp_cfg[0];
                    rc->config.max_qp[1] = rc->config.max_qp_cfg[1];
                    rc->limit_block_effect = 0;
                }
            }

            if (rc->P_qp_prev > 42)
            {
                Iqp = rc->I_qp_prev;
            }
            else
            {

                Iqp = ((rc->P_qp_prev + rc->avg_p_qp) >> 1) - 3;
                Iqp = CLIP3rc(rc->config.min_qp[0], rc->config.max_qp[0], Iqp);
            }

            /*qp increased when I/p frame realbits ratio more than 1.5*Ipratio*/
            if (rc->ip_ratio > (1.5*rc->config.P_I_ratio_max))
            {
                Iqp = Iqp + 2;
            }

            /*limit I frame qp less or equal I frame Qp to alleviate breath_effect*/
            if ( Iqp > rc->P_qp_prev)
            {
                Iqp = rc->P_qp_prev;
            }
            else
            {
                if (Iqp < (rc->P_qp_prev - 2))
                {
                    Iqp = rc->P_qp_prev - 2;
                }
            }
        } else {
            Iqp = rc->I_qp_prev;
        }

        if ((0 == rc->limit_block_effect) && (1 == rc->motion_level) )
        {
            rc->config.P_I_ratio_max_cfg = rc->config.P_I_ratio_max;
            rc->config.P_I_ratio_min_cfg = rc->config.P_I_ratio_min;
            rc->config.P_I_ratio_max = 40;
            rc->config.P_I_ratio_min = 28;
        }
        else
        {
            rc->config.P_I_ratio_max = rc->config.P_I_ratio_max_cfg;
            rc->config.P_I_ratio_min = rc->config.P_I_ratio_min_cfg;
        }

        //printf("%s:line_%d motion_level %d\n", __func__, __LINE__, rc->motion_level);
        if ((1 == rc->limit_block_effect))
        {
            Iqp = Iqp + rc->motion_level;
            // printf("%s: line_%d, Iqp %d\n", __func__, __LINE__, Iqp);
            if ( Iqp > rc->P_qp_prev)
                {
                    Iqp = rc->P_qp_prev;
                    // printf("%s: line_%d, Iqp %d\n", __func__, __LINE__, Iqp);
                }
                else
                {
                    if (Iqp < (rc->P_qp_prev - 2))
                    {
                        Iqp = rc->P_qp_prev - 2;
                        // printf("%s: line_%d, Iqp %d\n", __func__, __LINE__, Iqp);
                    }
                }
        }

        if (rc->num_p_frame < (rc->config.gop_size - 1))
        {
            Iqp = rc->I_qp_prev;
        }
    } else {
        Iqp = rc->config.start_qp;
    }

    /* qp recaculate when p frm too few */
    if ((rc->num_p_frame == (rc->config.gop_size - 1)) && (rc->num_p_frame < MIN_P_FRM_CNT)) {
        if (ABSrc(rc->Iframe_change_ratio_last) >= AX_CHANGE_RATIO_MARGIN && rc->P_qp_prev < 36 ) {
            rc->batch_encoded = 0;
            qp_drop = CLIP3rc(1, 5, ABSrc(rc->Iframe_change_ratio_last) / 15);
            if (rc->Iframe_change_ratio_last > 0) {
                Iqp = rc->I_qp_prev - qp_drop;
            } else if (rc->Iframe_change_ratio_last < 0) {
                Iqp = rc->I_qp_prev + qp_drop;
            }
        }
    }

    Iqp = CLIP3rc(rc->config.min_qp[0], rc->config.max_qp[0], Iqp);

    if (rc->P_qp_prev != -1 && rc->P_qp_prev) {
        rc->P_qp_prev = (rc->P_qp_prev + Iqp) >> 1;
    } else {
        rc->P_qp_prev = Iqp;  // P qp keep the same as I qp
    }

#ifdef AX_CBR_DEBUG
            printf("%s:%d - Iqp=%d, change_ratio %d, qp_drop %d, start_qp %d, rc->P_qp_prev %d-%d\n",
                    __func__, __LINE__,
                    Iqp,
                    rc->Pframe_change_ratio_last,
                    qp_drop,
                    rc->config.start_qp,
                    rc->P_qp_prev,
                    rc->avg_p_qp);
#endif
    rc->num_p_frame = 0;

    return Iqp;
}

static int AXRcClipQp(int QpSrc, int QpDst, int DeltaQpLimit)
{
    int resultQp = 0;
    int delta_qp = QpDst - QpSrc;
    if (delta_qp > 0)
    {
        delta_qp = CLIP3rc(1, DeltaQpLimit, delta_qp);
        resultQp = QpSrc + delta_qp;
    }
    else
    {
        delta_qp = ABSrc(delta_qp);
        delta_qp = CLIP3rc(1, DeltaQpLimit, delta_qp);
        resultQp = QpSrc - delta_qp;
    }
    return resultQp;
}

static int AXRcPframeQpPred(AX_RC_MODEL_CTX *rc, int size_bits)
{
    int Pqp = rc->P_qp_prev;
    int qp_drop = 0;
    if (rc->prevIDR)
    {
        // Pqp = rc->P_qp_prev + 3;
        Pqp = ((rc->P_qp_prev + (int)rc->averageQp) >> 1) + 3;
        Pqp = AXRcClipQp(rc->P_qp_prev, Pqp, DELTA_QP_LIMIT);
        rc->prevIDR = 0;
        rc->base_qp = (int)rc->averageQp;
    }
     else if ((ABSrc(rc->Pframe_change_ratio_last) >= AX_CHANGE_RATIO_MARGIN)
        && (rc->Pframe_change_ratio_last < AX_CHANGE_RATIO_MAX)) {
        rc->batch_encoded = 0;
        qp_drop = CLIP3rc(1, 3, ABSrc(rc->Pframe_change_ratio_last) / 15);
        if (rc->Pframe_change_ratio_last > 0) {
            if ((rc->base_qp-5) < Pqp) {
                Pqp = rc->P_qp_prev - qp_drop;
            }
        } else if (rc->Pframe_change_ratio_last < 0) {
            Pqp = rc->P_qp_prev + qp_drop;
        }
    }

    if (rc->ip_ratio > (1.5 * rc->config.P_I_ratio_max) && rc->config.gop_size <= 60)
    {
        if ((rc->base_qp-5) < Pqp)
        {
            Pqp = Pqp - 1;
        }
    }

    if (false == rc->roi_enable)
    {
        if (rc->ip_ratio && ((int)rc->ip_ratio < rc->ip_Ratio_threshold))
        {
            rc->config.max_qp[0] = 44;
            rc->config.max_qp[1] = 44;
        }
        else
        {
            if ((rc->config.max_qp_cfg[0] - rc->config.max_qp[0]) > 2)
            {
                rc->config.max_qp[0] = rc->config.max_qp[0] + 2;
            }
            else
            {
                rc->config.max_qp[0] = rc->config.max_qp_cfg[0];
            }

            if ((rc->config.max_qp_cfg[1] - rc->config.max_qp[1]) > 2)
            {
                rc->config.max_qp[1] = rc->config.max_qp[1] + 2;
            }
            else
            {
                rc->config.max_qp[1] = rc->config.max_qp_cfg[1];
            }
            if(1 == rc->limit_block_effect)
            {
                rc->config.min_qp[0] = 36;
                rc->config.max_qp[1] = 46;
            }
        }
     }
    Pqp = CLIP3rc(rc->config.min_qp[1], rc->config.max_qp[1], Pqp);

    return Pqp;
}

static void AXResetMotionLevel(AX_RC_MODEL_CTX *rc)
{
    rc->motion_count_veryslow = 0;
    rc->motion_count_slow = 0;
    rc->motion_count_mid = 0;
    rc->motion_count_fast = 0;
    rc->motion_level = 0;
    rc->motion_weight = false;
    return ;
}

static void AXRcResetPerPeriod(AX_RC_MODEL_CTX *rc)
{
    long long int total_bits = rc->Iframe_consumed + rc->Pframe_consumed;
    long long int delta_bits = rc->cur_target_bits - total_bits;
    long long int def_target_bits = rc->config.rate_target * AX_TARGET_PIC_SIZE_RATIO;
    long long int comp_bits = 0;
    bool flag_decrease_bits = false;
    bool flag_increase_bits = false;
    bool flag_instant_bits = false;/*keep targetbits same*/
    bool bitrate_non_zero = false;
    bitrate_non_zero = ((rc->u64LongTermBitRate > 0) && (rc->u64ShortTermBitRate > 0));
    flag_instant_bits = bitrate_non_zero ? ( rc->u64LongTermBitRate < rc->config.u32LongTermMaxBitrate \
                        && rc->config.u32LongTermMinBitrate < rc->u64LongTermBitRate \
                        && rc->config.u32MaxBitRate > rc->u64LongTermBitRate ) : false;
    // flag_decrease_bits = ( bitrate_non_zero && (rc->u64LongTermBitRate > rc->config.u32LongTermMaxBitrate
    //                     || (rc->u64ShortTermBitRate > rc->config.u32MaxBitRate))) || (rc->motion_level <= 1);
    flag_decrease_bits = bitrate_non_zero ? ( ((rc->u64LongTermBitRate > rc->config.u32LongTermMaxBitrate) \
                        || (rc->u64ShortTermBitRate > rc->config.u32MaxBitRate)) || (rc->motion_level <= 1)) : false;
    flag_increase_bits = bitrate_non_zero ? ((rc->u64LongTermBitRate <= rc->config.u32LongTermMinBitrate) || (rc->motion_level > 2) ) : false;

    if((rc->frame_encoded_stat >= rc->config.stat_period) && (VENC_VIDEO_CODEC_H264 == rc->config.codec_format))
    {
        rc->total_delta_bits += delta_bits;
        comp_bits = rc->total_delta_bits / 5;/*20% of saved bits*/
        if (VENC_CVBR == rc->rc_mode)
         {
            /*adjust bits */
            if (flag_decrease_bits)
             {
                // rc->bits_remaining = rc->bits_remaining * 0.9;
                comp_bits = 0 - def_target_bits / PERCENT_TARGET;
             }
            else if (flag_increase_bits)
             {
                // rc->bits_remaining = rc->bits_remaining * 1.1;
                if (comp_bits > 0)
                {
                    comp_bits = def_target_bits / PERCENT_TARGET;
                }
            }
        }
        else
        {
            comp_bits = CLIP3rc(-def_target_bits / 10, def_target_bits / 10, comp_bits);
        }
        rc->total_delta_bits -= comp_bits;
        if (VENC_CVBR == rc->rc_mode)
        {
            AXResetMotionLevel(rc);
        }
#ifdef AX_CBR_DEBUG
        printf("[%s] target bits %lld, delta_bits %lld comp_bits %lld total_delta bits %lld---------\n", __func__,
            rc->cur_target_bits, delta_bits, comp_bits, rc->total_delta_bits);
#endif
    }

    rc->frame_encoded_stat = 0;
    rc->Pframe_mb_qp_sum = 0;
    rc->Iframe_consumed = 0;
    rc->Pframe_consumed = 0;
    rc->bits_remaining = def_target_bits + comp_bits;
    rc->cur_target_bits = rc->bits_remaining;
#ifdef AX_CBR_DEBUG
    printf("[%s] reset bps, target %lld real %lld---------\n", __func__, def_target_bits, rc->bits_remaining);
#endif

    return;
}

static void AXRcBitrateChange(AX_RC_MODEL_CTX *rc)
{
    rc->bits_remaining = rc->bits_remaining * rc->bitrate_change_ratio;  // adjust remain bits by bitrate change ratio to make sure bitrate change instantly
    rc->Isize_prev = rc->Isize_prev * rc->bitrate_change_ratio;  // update I previous size for p size will minus it.
    rc->Psize_prev = rc->Psize_prev * rc->bitrate_change_ratio;  // not usefull by now.

    return;
}

int AXRcInitRcModel(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config)
{
    int tmp;
    int err = 0;
    int a, b, c;
    float ratio = 1.0;
    --err;
    if(!rc || !config)
    {
        return err; //-1
    }

    --err;
    if(!config->stat_period)
    {
        return err; //-2
    }

    //rate_target is required
    --err;
    if(!config->rate_target)
    {
        return err; //-3
    }

    //gop is required
    --err;
    if(!config->gop_size)
    {
        return err; //-4
    }

    --err;
    tmp = config->frame_width * config->frame_height * config->bits_per_pixel;
    if(!tmp)
    {
        return err; //-5
    }

    //reset RC model
    memset(rc, 0, sizeof(AX_RC_MODEL_CTX));

    //copy user config to RC context, each stream requires one context
    rc->config = *config;
    rc->config.codec_format = config->codec_format;
    rc->config.rc_mode = config->rc_mode;
    /*To smooth picture quality and avoid blockeffect, select appropriate start Qp.*/
    if(!rc->config.start_qp)
    {
        /* condition:fps abnomal */
        if (rc->config.stat_period < 25)
        {
            rc->config.start_qp = 25;
        }
        else if (rc->config.bpp < 0.06)
        {
            rc->config.start_qp = 40;
            if (VENC_VIDEO_CODEC_HEVC == rc->config.codec_format)
            {
                rc->config.start_qp = 38;
            }
        }
        else if( rc->config.bpp >= 0.06 && rc->config.bpp <= 0.14 )
        {
            rc->config.start_qp = 35;
        }
        else if( rc->config.bpp > 0.14 && rc->config.bpp <= 0.24 )
        {
            rc->config.start_qp = 25;
        }
        else
        {
            rc->config.start_qp = 10;
        }
        rc->I_qp_pred = rc->config.start_qp;
    }

    if (rc->config.I_qp_delta) {
        rc->I_qp_delta = rc->config.I_qp_delta;
    }

    ratio = (float)rc->config.gop_size / rc->config.stat_period;
    ratio = (int)(10.0 * ratio + 0.5) / 10.0;
    if(ratio < 1.0) {
       ratio = 1.0;
    }

    rc->config.stat_period = rc->config.stat_period * ratio;
    rc->config.rate_target = rc->config.rate_target * ratio;
    rc->bps_ratio = ratio;

    if (!rc->config.P_I_ratio_min) {
        rc->P_I_ratio_min = 1;
    } else {
        rc->P_I_ratio_min = rc->config.P_I_ratio_min;
    }

    if (!rc->config.P_I_ratio_max) {
        rc->P_I_ratio_max = AX_DEFAULT_MAX_IRATIO;
    } else {
        rc->P_I_ratio_max = rc->config.P_I_ratio_max;
    }

    if(!rc->config.start_P_I_ratio)
    {
        rc->config.start_P_I_ratio = AX_DEFAULT_P_IRATIO;
        rc->P_I_ratio = CLIP3rc(rc->P_I_ratio_min, rc->P_I_ratio_max, rc->config.start_P_I_ratio);
    }

    rc->config.start_I_ratio = AXRcUpdateIratio(rc->config.stat_period ,rc->config.start_P_I_ratio, rc->I_qp_delta);
    rc->I_size_ratio = rc->config.start_I_ratio;

    // ensure batch >= 2, so we can update I_ratio mode
    if (rc->config.stat_period <= 1)
    {
        rc->config.stat_period = rc->config.stat_period * 2;
        rc->config.rate_target = rc->config.rate_target * 2;
    }
    rc->config.frame_rate = config->frame_rate;

    if(!rc->config.batch_size)
    {
        if(rc->config.stat_period > 20)
        {
            rc->config.batch_size = AX_DEFAULT_RC_BATCH;
        } else if(rc->config.stat_period <5 && rc->config.stat_period >= 2)
        {
            rc->config.batch_size = 2;
        } else if(rc->config.stat_period <2)
        {
            rc->config.batch_size = 1;
        } else
        {
            rc->config.batch_size = rc->config.stat_period /5;
        }
    }

#if 0
        rc->config.min_qp[0] = AX_SEARCH_QPRANGE_LO; // To do: set by user
        rc->config.max_qp[0] = AX_SEARCH_QPRANGE_HI;
        rc->config.min_qp[1] = AX_SEARCH_QPRANGE_LO; // To do: set by user
        rc->config.max_qp[1] = AX_SEARCH_QPRANGE_HI;
#else
    if ((rc->config.min_qp[0] < 0) || (rc->config.min_qp[0] > rc->config.max_qp[0]) || (rc->config.max_qp[0] > 51)) {
        //printf("WARN: I qp max %d or min %d over range\n", rc->config.max_qp[0], rc->config.min_qp[0]);
        rc->config.min_qp[0] = AX_SEARCH_QPRANGE_LO; // To do: set by user
        rc->config.max_qp[0] = AX_SEARCH_QPRANGE_HI;
    }
    if ((rc->config.min_qp[1] < 0) || (rc->config.min_qp[1] > rc->config.max_qp[1]) || (rc->config.max_qp[1] > 51)) {
        //printf("WARN: PB qp max %d or min %d over range\n", rc->config.max_qp[1], rc->config.min_qp[1]);
        rc->config.min_qp[1] = AX_SEARCH_QPRANGE_LO; // To do: set by user
        rc->config.max_qp[1] = AX_SEARCH_QPRANGE_HI;
    }
#endif
    rc->config.min_qp_cfg[0] = rc->config.min_qp[0];
    rc->config.min_qp_cfg[1] = rc->config.min_qp[1];
    rc->config.max_qp_cfg[0] = rc->config.max_qp[0];
    rc->config.max_qp_cfg[1] = rc->config.max_qp[1];
    rc->config.P_I_ratio_max_cfg = rc->config.P_I_ratio_max;
    rc->config.P_I_ratio_min_cfg = rc->config.P_I_ratio_min;
    //caution: Isize is in bits but rate_traget is in kbits, ratio is percent, thus total need x10
    rc->Isize_pred = (rc->config.rate_target * rc->config.start_I_ratio) * 10;
    if(rc->config.stat_period>1)
    {
        rc->Psize_pred = (rc->config.rate_target * 1000 - rc->Isize_pred) / (rc->config.stat_period - 1);  // To do
    } else{
        rc->Psize_pred = rc->config.rate_target * 1000 - rc->Isize_pred;
    }

    rc->bits_remaining = (rc->config.rate_target * 1000);
    rc->I_qp_prev = -1;
    rc->P_qp_prev = -1;
    rc->Pframe_mb_qp_average = 0;
    rc->Pframe_mb_qp_sum = 0;
    rc->ip_Ratio_threshold = (int)(rc->config.P_I_ratio_max*0.4);

    rc->i_frm_extra_bits = 0;
    rc->total_delta_bits = 0;
    rc->cur_target_bits = rc->bits_remaining;

#ifdef AX_CBR_DEBUG
    printf("%s:%d - startqp %d, gop %d, period %d, minqpI=%d, minqpP=%d, maxqpI=%d, maxqpP=%d, targetBitrate %lld, Ipropmin %d, IpropMax %d.\n",
            __func__, __LINE__,
            rc->config.start_qp,
            rc->config.gop_size,
            rc->config.stat_period,
            rc->config.min_qp[0],
            rc->config.min_qp[1],
            rc->config.max_qp[0],
            rc->config.max_qp[1],
            rc->config.rate_target,
            rc->P_I_ratio_min,
            rc->P_I_ratio_max);
#endif

    return 0;

}


int AXRcUpdateConfig(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config)
{
    float ratio = 1.0;

    if(!rc || !config)
    {
        return -1;
    }

    if (!config->P_I_ratio_min) {
        rc->P_I_ratio_min = AX_DEFAULT_MIN_IRATIO;
    } else {
        rc->P_I_ratio_min = config->P_I_ratio_min;
    }

    if (!config->P_I_ratio_max) {
        rc->P_I_ratio_max = AX_DEFAULT_MAX_IRATIO;
    } else {
        rc->P_I_ratio_max = config->P_I_ratio_max;
    }
    rc->ip_Ratio_threshold = (int)(rc->config.P_I_ratio_max*0.4);

    if (config->I_qp_delta) {
        rc->I_qp_delta = config->I_qp_delta;
    }

    if (config->frame_rate_change) {
        // special handle, recalculate period and bitrate
        ratio = (float)rc->config.gop_size / rc->config.stat_period;
        ratio = (int)(10.0 * ratio + 0.5) / 10.0;
        if(ratio < 1.0) {
           ratio = 1.0;
        }
        rc->config.stat_period = rc->config.stat_period * ratio;
        rc->config.rate_target = rc->config.rate_target * ratio;
        rc->bps_ratio = ratio;
        /* AXRcResetPerPeriod(rc); */
        config->frame_rate_change = false;
#ifdef AX_CBR_DEBUG
        printf("%s:%d - update framerate=%d.\n",
                __func__, __LINE__,
                config->stat_period);
#endif
    }

    if (config->bitrate_change) {
        rc->bitrate_change_ratio = (float)(config->rate_target * rc->config.stat_period)
                                    / (rc->config.rate_target * config->stat_period);
        // special handle, recalculate period and bitrate
        ratio = (float)rc->config.gop_size / rc->config.stat_period;
        //the result is rounded to one decimal place
        ratio = (int)(10.0 * ratio + 0.5) / 10.0;
        if(ratio < 1.0) {
            ratio = 1.0;
        }
        rc->config.stat_period = rc->config.stat_period * ratio;
        rc->config.rate_target = rc->config.rate_target * ratio;
        rc->bps_ratio = ratio;
        AXRcBitrateChange(rc);
        config->bitrate_change = false;
#ifdef AX_CBR_DEBUG
        printf("%s:%d - update bitrate=%d.\n",
                __func__, __LINE__,
                config->stat_period);
#endif
    }

    return 0;
}

static void AXGetMotionLevel(AX_RC_MODEL_CTX *rc)
{

    if (rc->motion_count_fast > 3)
    {
        rc->motion_level = 4;
    }
    else if (rc->motion_count_mid > 3)
    {
        rc->motion_level = 3;
    }
    else if (rc->motion_count_slow > 3)
    {
        rc->motion_level = 2;
    }
    else if (rc->motion_count_veryslow >= 3)
    {
        rc->motion_level = 1;
    }
    // printf("AXGetMotionLevel: motion_level %d\n",rc->motion_level);
    return ;
}

void AXRcGetNextRcInfo(AX_RC_MODEL_CTX *rc, bool bIframe, int *target_size, int *frame_qp)
{
    int pic_size = 0;
    int qp = 0;
    int frame_size = 0;
    if (bIframe) {
        AXRcIframeSizePred(rc);
        frame_size = rc->Isize_pred;

        if (VENC_CVBR == rc->rc_mode)
        {
           AXGetMotionLevel(rc);
        }
        qp = AXRcIframeQpPred(rc, frame_size);

        qp = qp + rc->I_qp_delta;
        
        qp = CLIP3rc(rc->config.min_qp[0], rc->config.max_qp[0], qp);
        rc->I_qp_pred = qp;
    } else {
        AXRcPframeSizePred(rc);
        if (VENC_CVBR == rc->rc_mode)
        {
            AXGetMotionLevel(rc);
        }
        frame_size = rc->Psize_pred;

        qp = AXRcPframeQpPred(rc, frame_size);
        rc->P_qp_pred = qp;
    }

    *target_size = frame_size;
    *frame_qp = qp;

#ifdef AX_CBR_DEBUG
    if (bIframe) {
        printf("%s:%d - Isize_pred=%d, qp=%d.\n",
                __func__, __LINE__,
                frame_size,
                qp);
    } else {
        printf("%s:%d - Psize_pred=%d, qp=%d.\n",
                __func__, __LINE__,
                frame_size,
                qp);
    }
#endif

}

/* Update I_ratio, SizeI[n], SizeP[n], batch_cnt, encode_cnt, etc. */
int AXRcUpdateRcModel(AX_RC_MODEL_CTX *rc, bool bIframe, long long int size_bits, float mb_qp)
{
    int qpI = rc->I_qp_pred; //get qp value for this frame
    int qpP = rc->P_qp_pred; //get qp value for this frame
    int qp = 0;
    long long int i_size, p_size, divisor;
    int target_size_stat = 0;
    int num_Iframe_coming = (rc->config.stat_period - 1) / rc->config.gop_size;
    long long int lliTemp = 0;

    rc->frame_encoded_cnt++;

    if (rc->Pframe_mb_qp_change_ratio) {
        rc->bits_remaining = ((rc->bits_remaining * rc->Pframe_mb_qp_change_ratio) - size_bits) / rc->Pframe_mb_qp_change_ratio;
    } else {
        rc->bits_remaining -= size_bits;
    }

    if (VENC_CVBR == rc->rc_mode)
    {
        // printf("CVBR %s:line_%d, motion_level %d\n", __func__, __LINE__, rc->motion_level);
        if (4 == rc->motion_level && false == rc->motion_weight)
        {
            rc->bits_remaining = rc->bits_remaining * 1.4;
            rc->motion_weight = true;
            // printf("motion 1.4 \n");
        }
        else if (3 == rc->motion_level && false == rc->motion_weight)
        {
            rc->bits_remaining = rc->bits_remaining * 1.3;
            rc->motion_weight = true;
            // printf("motion 1.3 \n");
        }
        else if (2 == rc->motion_level && false == rc->motion_weight)
        {
            rc->bits_remaining = rc->bits_remaining * 1.2;
            rc->motion_weight = true;
            // printf("motion 1.2 \n");
        }
        else if (1 == rc->motion_level && false == rc->motion_weight)
        {
            rc->bits_remaining = rc->bits_remaining * 1.1;
            rc->motion_weight = true;
            // printf("motion 1.2 \n");
        }
    }

    if(rc->bits_remaining < 0)
    {
        rc->bits_remaining = 0;
    }

    if(bIframe)
    {
        if (rc->i_frm_extra_bits) /* when insert i frm, not update i frm info */
        {
            if (rc->i_frm_extra_bits > size_bits)
            {
                rc->bits_remaining -= (rc->i_frm_extra_bits - size_bits);
            }
            else if (rc->i_frm_extra_bits < size_bits)
            {
                rc->bits_remaining += (size_bits - rc->i_frm_extra_bits);
            }
            rc->i_frm_extra_bits = 0;
            rc->frame_encoded_gop++;
        }
        else
        {
            qp = qpI;
            rc->frame_encoded_gop = 1;
            rc->Iframe_consumed += size_bits;
            rc->Isize_prev = size_bits;
            rc->I_qp_total_gop += qpP;
            rc->I_qp_prev = qp;
            lliTemp = (long long int)rc->Isize_pred * 100;
            lliTemp = lliTemp/size_bits;
            rc->Iframe_change_ratio_last = lliTemp - 100;
            // rc->Iframe_change_ratio_last = rc->Isize_pred * 100 / size_bits - 100;
            rc->Iframe_mb_qp_prev = mb_qp;
        }
    }
    else
    {
        qp = qpP;
        rc->frame_encoded_gop++;
        rc->Pframe_consumed += size_bits;
        rc->Psize_prev = size_bits;
        rc->ip_ratio = (float)rc->Isize_prev/(float)size_bits;
        rc->P_qp_total_gop += qpP;
        rc->num_p_frame = rc->num_p_frame + 1;
        rc->P_qp_prev = qp;
        lliTemp = (long long int)rc->Psize_pred * 100;
        lliTemp = lliTemp/size_bits;
        rc->Pframe_change_ratio_last = lliTemp - 100;
        // rc->Pframe_change_ratio_last = rc->Psize_pred * 100 / size_bits - 100;
        rc->Pframe_mb_qp_prev = mb_qp;
        rc->Pframe_mb_qp_sum += mb_qp;
        if (rc->Pframe_mb_qp_average) {
            rc->Pframe_mb_qp_change_ratio = (float)(100 + CLIP3rc(0, 15, 5 * (mb_qp - rc->Pframe_mb_qp_average) * mb_qp / 30)) / 100;
        }
        else if ((rc->base_qp+5) < rc->averageQp)
        {
            rc->Pframe_mb_qp_change_ratio = 1.3;
        }
    //     else if (rc->ip_ratio > (1.5*rc->config.P_I_ratio_max) && (rc->config.gop_size<=50))
    //     {
    //         rc->Pframe_mb_qp_change_ratio = 1.05;
    //     }
    }

    if (rc->frame_encoded_stat == 0) {
        rc->adjust_target_size_stat = (rc->bits_remaining - num_Iframe_coming * rc->Isize_prev) / (rc->config.stat_period * 2);
    }
    rc->bits_adjust = ((rc->adjust_target_size_stat * (rc->config.stat_period / 2 - rc->frame_encoded_stat) / rc->config.stat_period));

    if(++rc->batch_encoded >= rc->config.batch_size)
    {
        rc->batch_encoded = 0;
    }

    rc->frame_encoded_stat++;
    if(rc->frame_encoded_stat >= rc->config.stat_period)
    {
        if (rc->frame_encoded_stat > 1) {
            rc->Pframe_mb_qp_average = rc->Pframe_mb_qp_sum / (rc->frame_encoded_stat - 1);
        }
        AXRcResetPerPeriod(rc);
    }

    if (rc->frame_encoded_gop >= rc->config.gop_size) {
        rc->frame_encoded_gop = 0;
    }

    //update I ratio for given qp, activated by P frame only
#ifdef AX_CBR_DEBUG
    printf("%s:%d - frame cnt=%d, qp %d, real_bits %lld, pred_bits %lld, remaining bits %lld, bits_adjust %lld, ip_ratio %f\n",
            __func__, __LINE__,
            rc->frame_encoded_cnt,
            rc->P_qp_pred,
            size_bits,
            rc->Psize_pred,
            rc->bits_remaining,
            rc->bits_adjust,
            rc->ip_ratio);
    printf("%s:%d - Pframe_mb_ratio %lf, qp %lf, Pframe_average %lf, Pframe_mb_qp_sum %lf\n",
            __func__, __LINE__,
            rc->Pframe_mb_qp_change_ratio,
            mb_qp,
            rc->Pframe_mb_qp_average,
            rc->Pframe_mb_qp_sum);
#endif

    return 0;
}

void AXRcUpdateSceneCutParam(AX_RC_MODEL_CTX *rc, int scene_change_ratio)
{
    if (scene_change_ratio >= 60)
    {
        rc->motion_count_fast = rc->motion_count_fast + 1;
    }
    else if (scene_change_ratio >= 40)
    {
        rc->motion_count_mid = rc->motion_count_mid + 1;
    }
    else if (scene_change_ratio >= 20)
    {
        rc->motion_count_slow = rc->motion_count_slow + 1;
    }
    else if (scene_change_ratio >=11)
    {
        rc->motion_count_veryslow = rc->motion_count_veryslow + 1;
    }

    if (scene_change_ratio >= 75) {
        int Iqpmin = AX_MAX(rc->config.min_qp[0], rc->config.start_qp);
        int Pqpmin = AX_MAX(rc->config.min_qp[1], rc->config.start_qp);

        rc->I_qp_prev = CLIP3rc(Iqpmin, rc->config.max_qp[0], rc->I_qp_prev);
        rc->P_qp_prev = CLIP3rc(Pqpmin, rc->config.max_qp[1], rc->P_qp_prev);
#ifdef AX_CBR_DEBUG
        printf("%s:%d - change ratio %d, adjust to I_qp_prev %d, P_qp_prev %d\n",
                __func__, __LINE__,
                scene_change_ratio,
                rc->I_qp_prev,
                rc->P_qp_prev);
#endif
    }
}


/* calculate the average by sliding the window */
double sliding_window_avg(win_buff *win_buff, int win_data)
{
    int count = 0;
    int sum = 0;
    if(win_buff->size == 0) {
        return 0.0;
    }
    win_buff->date_buff[ win_buff->pos++ ] = win_data;  //get_data为实时获取的数据
    if (win_buff->pos == win_buff->size) {
        win_buff->pos = 0;           //当数据大于数组长度，替换数据组的一个数据  相当于环形队列更新，先进先出！
    }

    for (count = 0; count < win_buff->size; count++) {
        sum += win_buff->date_buff[count];
    }
    return (double)sum / win_buff->size;
}

int AXRcUpdateSceneCutParamvbr(int rc_input,int qpMax, int scene_change_ratio, AX_RC_MODEL_CTX *rc)
{
    int rc_output = 0;

    rc->scene_change_avg = sliding_window_avg(&rc->scene_change_buf, scene_change_ratio);
    if (scene_change_ratio >= 90) {
     rc_output = CLIP3rc(qpMax * 2 / 3, qpMax, rc_input + 3);
    } else if (scene_change_ratio <= 5) {
       /*When scene_change_ratio is less than 7, qp is set to 0.9 times of maxqp, reducing the bit rate
         rc->scene_change_avg is less than 1.0, the default is static scene*/
        if(rc->scene_change_avg < 1.0) {
            rc_output = CLIP3rc(qpMax * 9 / 10, qpMax, rc_input + 4);
        } else {
            rc_output = rc_input;
        }
    } else {
        rc_output = rc_input;
    }

    return rc_output;
}

int AXRcUpdateSceneCutParamAvbr(int rc_input, int qpMax, int qpMin, int scene_change_ratio, AX_RC_MODEL_CTX *rc)
{
    int rc_output = 0;
    if (qpMax == qpMin) {
        return qpMax;
    }

    rc->scene_change_avg = sliding_window_avg(&rc->scene_change_buf, scene_change_ratio);
    if (scene_change_ratio >= 80) {
        rc_output = CLIP3rc(qpMax * 2 / 3, qpMax, rc_input + (3 << QP_FRACTIONAL_BITS));
    } else if (scene_change_ratio >= 60) {
        rc_output = CLIP3rc(qpMax * 2 / 3, qpMax, rc_input + (2 << QP_FRACTIONAL_BITS));
    } else if (scene_change_ratio >= 7) {
        rc_output = CLIP3rc(qpMin, qpMax, (rc_input + (2 << QP_FRACTIONAL_BITS) * (rc_input - qpMin) / (qpMax - qpMin)));
    } else {
        /*When scene_change_ratio is less than 7, qp is set to 0.9 times of maxqp, reducing the bit rate
         rc->scene_change_avg is less than 1.0, the default is static scene*/
        if(rc->scene_change_avg < 1.0) {
            rc_output = CLIP3rc(qpMax * 9 / 10, qpMax, rc_input + (2 << QP_FRACTIONAL_BITS));
        } else {
            rc_output = rc_input;
        }
    }

    return rc_output;
}

/* when call AX_VENC_RequestIDR, there are two cases:
 * 1、i frm insert in gop, the frm cnt in gop increse continous; bps will increase
 * 2、drop current gop, start new gop by this i frm, bps recount in new gop;
 */
void AXRcInsertIFrame(AX_RC_MODEL_CTX *rc, int insert_flag)
{
    int ret = 0;
    if (1 == insert_flag) {  /* insert i frm */
#ifdef AX_CBR_DEBUG
        printf("[%s] remain %lld preI %lld\n", __func__, rc->bits_remaining, rc->Isize_prev);
#endif
        rc->bits_remaining += rc->Isize_prev;
        rc->i_frm_extra_bits = rc->Isize_prev;
    } else if (2 == insert_flag) { /* start new gop */
        /* only restart bps count, all bps param no change */
        AXRcResetPerPeriod(rc);
    }
}

