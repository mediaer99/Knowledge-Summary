#ifndef AX_RATECTRL_H
#define AX_RATECTRL_H

#define AX_DEFAULT_RC_BATCH (4)
#define AX_MIN_POSSBILE_QP (0)
#define AX_MAX_POSSBILE_QP (51)
#define AX_DEFAULT_START_QP (25)
#define AX_DEFAULT_IRATIO (15)       //100~12%, 200~20%
#define AX_DEFAULT_INTERPOLATOR (50) //interpolation between previous qp & desired qp

#define AX_SEARCH_QPRANGE_LO  (1)
#define AX_SEARCH_QPRANGE_HI  (46)

#define AX_MAX_QP (52)

#define AX_DEFAULT_POLY_A (7)
#define AX_DEFAULT_POLY_B (-300)
#define AX_DEFAULT_MARGIN (30) // means 30%

#define MAX(a, b) ((a) > (b) ?  (a) : (b))
#define ABSrc(a) ((a) > 0 ?  (a) : (-a))
#define CLIP3rc(x, y, z) (((z) < (x)) ? (x) : (((z) > (y)) ? (y) : (z))) // make x < z < y

#define AX_DEFAULT_P_IRATIO (15)       //6~30
#define AX_DEFAULT_MIN_IRATIO (10)
#define AX_DEFAULT_MAX_IRATIO (40)

#define AX_TARGET_PIC_SIZE_RATIO (1000)
#define AX_CHANGE_RATIO_MARGIN (5) // means 30%
#define AX_CHANGE_RATIO_MAX (5000) /*  when the cameras are covered, change ratio may > 10000 */
#define DELTA_QP_LIMIT 3 // deltaQP limit in neighbourhood two frames

#include "base_type.h"
#include <string.h>

//#define AX_CBR_DEBUG
//#define AX_VBR_DEBUG
typedef enum
  {
    VENC_VIDEO_CODEC_HEVC=0,
    VENC_VIDEO_CODEC_H264=1,
    VENC_VIDEO_CODEC_AV1=2,
    VENC_VIDEO_CODEC_VP9=3
  }VEncVideoCodecFormat;

typedef struct axRcModelConfig
{
    //user config section
    bool enabled; //model output qp=0 if not enabled
    VEncVideoCodecFormat codec_format;
    int rc_mode;
    int gop_size; //typical 24~50
    int batch_size;  //frame batch granuality, 0 means default(8),
    int min_qp_cfg[2]; // Temporarily store customer configuration min_qp Iframe and Pframe
    int max_qp_cfg[2]; // Temporarily store customer configuration max_qp Iframe and Pframe
    int min_qp[2]; //used to clip model output for I&P frame
    int max_qp[2]; //used to clip model output for I&P frame
    int start_qp; //initial qp (I frame) to start from,
    int stat_period; //typical one second worth of frame count (25/30)
    int fps_target_x100; //2499 for 24.99fps, required for model operation
    long long rate_target; //kbps, final bitrate should not exceed 5% of this value
    int frame_rate;
    int start_I_ratio; //usually 10%~30%, 1234 means 12.34% of total rate_target
    int I_ratio_max; //clip highest I bits portion
    int I_ratio_min; //clip lowest I bits portion

    int frame_width; //used to calc default I/P stream size
    int frame_height; //used to calc default I/P stream size
    int bits_per_pixel; //12 for YUV420, used to calc default I/P stream size

    int start_P_I_ratio; //usually 6~30, means P I compression ratio, default 10
    int P_I_ratio_max_cfg;
    int P_I_ratio_min_cfg;
    int P_I_ratio_max;
    int P_I_ratio_min;
    int I_qp_delta;
    bool frame_rate_change;
    bool bitrate_change;
    float bpp;

    /*for CVBR*/
    unsigned int       u32MaxBitRate;              /* RW; the max bitrate, the unit is kbps */

    unsigned int       u32ShortTermStatTime;       /* RW; Range:[1, 120]; the long-term rate statistic time, the unit is second (s)*/
    unsigned int       u32LongTermStatTime;        /* RW; Range:[1, 1440]; the long-term rate statistic time, the unit is u32LongTermStatTimeUnit*/
    unsigned int       u32LongTermMaxBitrate;     /* RW; Range:[2, 614400];the long-term target max bitrate, can not be larger than u32MaxBitRate,the unit is kbps */
    unsigned int       u32LongTermMinBitrate;     /* RW; Range:[0, 614400];the long-term target min bitrate,  can not be larger than u32LongTermMaxBitrate,the unit is kbps */

    unsigned int       u32ExtraBitPercent;
    unsigned int       u32LongTermStatTimeUnit;
}AX_RC_MODEL_CONFIG;

typedef struct win_buff{
	int  pos;              /* current position */
	int  size;             /* average for size */
	int  date_buff[32];    /* date*/
}win_buff;

typedef struct axRcModelCtx
{
    AX_RC_MODEL_CONFIG config;
    int rc_mode;
    bool roi_enable;
    int limit_block_effect;
    int cnt;
    //model prediction section
    // int qp_pred_prev[2];
    int qp_pred[2]; //model output for I&P frame, store for future use, return previous if within same batch
    int I_ratio[AX_MAX_QP]; //I bits percent relative to total budget for a state period
    int rate_pred[AX_MAX_QP]; //predicated total rate if I/P frames take the same qp

    //model status section
    u32 frame_encoded_cnt; // free run counter
    int frame_encoded_gop;  //restart fom 0 when a new gop begins (bIframe=true)
    int frame_encoded_stat; //restart from 0 when reach stat_period
    int batch_encoded; //restart from 0 if reach next batch of P frames
    long long int bits_remaining; //bit available for allocation, calc from Iframe_consumed and Pframe_consumed
    long long int bits_adjust;
    long long int Isize_pred;
    long long int Psize_pred;
    long long int Isize_prev;
    long long int Psize_prev;
    float ip_ratio;
    // func cal size
    int Iframe_size_pred[AX_MAX_QP]; //update when +/- 30% from real
    int Pframe_size_pred[AX_MAX_QP];
    int change_cnt[2];
    int change_log[2][AX_MAX_QP];
    int func_coeff[2][3];
    //facts collection section
    int Iframe_size_real[AX_MAX_QP]; //update when bIframe=true, slowly evolves with scene and environment
    int Pframe_size_real[AX_MAX_QP]; //update when bIframe=false, need low pass filter to smooth out jitter
    long long int Iframe_consumed; //bits already consumed by past I frames in a stat period
    int Iframe_consumed_last;
    long long int Pframe_consumed; //bits already consumed by past P frames in a stat period
    int Pframe_change_ratio_last;
    int Iframe_change_ratio_last;
    int prevIDR;

    int I_qp_delta;
    int P_I_ratio;
    int I_size_ratio;
    int I_qp_pred;
    int P_qp_pred;
    int I_qp_total_gop;
    int P_qp_total_gop;
    int num_p_frame;
    int I_qp_prev;
    int P_qp_prev;
    int base_qp;
    int P_I_ratio_max;
    int P_I_ratio_min;
    int avg_p_qp;
    float averageQp;
    float bitrate_change_ratio;
    float bps_ratio;

    // mb qp info
    float Iframe_mb_qp_prev;
    float Pframe_mb_qp_prev;
    float Pframe_mb_qp_sum;
    float Pframe_mb_qp_average;
    float Pframe_mb_qp_change_ratio;
    int adjust_target_size_stat;
    int ip_Ratio_threshold;
    long long int i_frm_extra_bits; /* for insert i frm */
    long long int total_delta_bits;
    long long int cur_target_bits;

    /*for CVBR*/
    unsigned long long int u64LongTermBitRate;
    unsigned long long int u64ShortTermBitRate;

    int scene_change_ratio;
    int scene_change_sum;
    float scene_change_avg;
    int scene_change_count;
    int motion_level;
    bool motion_weight;
    int motion_count_veryslow;
    int motion_count_slow;
    int motion_count_mid;
    int motion_count_fast;
    win_buff scene_change_buf;
} AX_RC_MODEL_CTX;

int InitRcModel(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config);
int GetNextQp(AX_RC_MODEL_CTX *rc_CTX, bool bIframe, int model_flag);
int UpdateRcModel(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int model_flag);

int AXRcInitRcModel(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config);
int AXRcUpdateConfig(AX_RC_MODEL_CTX *rc, AX_RC_MODEL_CONFIG *config);
void AXRcGetNextRcInfo(AX_RC_MODEL_CTX *rc, bool bIframe, int *target_size, int *frame_qp);
int AXRcUpdateRcModel(AX_RC_MODEL_CTX *rc, bool bIframe, long long int size_bits, float mb_qp);
void AXRcUpdateSceneCutParam(AX_RC_MODEL_CTX *rc, int scene_change_ratio);
void AXRcInsertIFrame(AX_RC_MODEL_CTX *rc, int insert_flag);
int AXRcUpdateSceneCutParamvbr(int rc_input,int qpMax, int scene_change_ratio, AX_RC_MODEL_CTX *rc);
int AXRcUpdateSceneCutParamAvbr(int rc_input, int qpMax, int qpMin, int scene_change_ratio, AX_RC_MODEL_CTX *rc);
/*
 * internal functions only
 */

int FindNearestAnchorQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int *qp0, int *qp1);
int InterpolateQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int model_flag);
int InterpolateIframeQp(AX_RC_MODEL_CTX *rc);
int FindPredQp(AX_RC_MODEL_CTX *rc, bool bIframe, int size_bits, int *qp0, int *qp1);
int setFuncQp(AX_RC_MODEL_CTX *rc, bool bIframe);
int updateFuncQP(AX_RC_MODEL_CTX *rc, bool bIframe);
int updateFuncQPhi(AX_RC_MODEL_CTX *rc, bool bIframe);
double sliding_window_avg(win_buff *buf, int get_data);

#endif
