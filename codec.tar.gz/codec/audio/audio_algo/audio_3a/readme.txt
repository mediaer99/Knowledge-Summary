1. audio_3a基于开源代码进行二次开发，已经在多款产品上实现量产。
2. audio_3a算法库包含Noise Suppression，Acoustic Echo Cancellation for mobile，Acoustic Echo Cancellation，Automatic Gain Control模块。
3. 开发包包含demo和drv两个目录。drv目录包含audio_3a算法全部源代码，之前已经在arm平台编译通过，在其他平台上需要微调Makefile。
    demo是audio_3a的应用参考。
4. 为了方便使用，整个audio_3a算法库被抽象成了3个接口函数。demo展示了audio_3a的使用方法和调用流程。
    需要注意的是，在不同硬件平台上，需要调用aec_process对音频输入的每一帧数据进行处理后，再送入编码模块或者音频输出模块。