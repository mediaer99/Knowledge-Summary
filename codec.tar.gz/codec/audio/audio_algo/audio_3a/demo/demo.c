
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>

#include "demo.h"
#include "audio_process.h"

//*****************************************************************************
//*****************************************************************************
//** Local Defines
//*****************************************************************************
//*****************************************************************************


//*****************************************************************************
//*****************************************************************************
//** Enumerated types
//*****************************************************************************
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
//** Local structures
//*****************************************************************************
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
//** Global Data
//*****************************************************************************
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
//** Local Data
//*****************************************************************************
//*****************************************************************************


//*****************************************************************************
//*****************************************************************************
//** Local Functions Declaration
//*****************************************************************************
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
//** Local Functions Define
//*****************************************************************************
//*****************************************************************************

AX_VOID *aec_init(int sample_rate, int frame_samples)
{
    AP_UPTALKVQE_ATTR_S audio_process_attr;

    audio_process_attr.s32SampleRate = sample_rate;
    audio_process_attr.u32FrameSamples = frame_samples;

    audio_process_attr.stAecCfg.enAecMode = AEC_MODE_FLOAT;
    audio_process_attr.stAecCfg.stAecFloatCfg.enSuppressionLevel = 0;
    audio_process_attr.stAecCfg.stAecFixedCfg.eRoutingMode = 3;

    audio_process_attr.stNsCfg.bNsEnable = AX_TRUE;
    audio_process_attr.stNsCfg.nsParam= 3;
    
    audio_process_attr.stAgcCfg.bAgcEnable = AX_TRUE;
    audio_process_attr.stAgcCfg.agcParam= 15;

    return AX_AP_UpTalkVqe_Create(&audio_process_attr);
}

int aec_process(AX_VOID *inst, AX_VOID *ai_data, AX_VOID *ao_data, AX_VOID *aec_data)
{
    return AX_AP_UpTalkVqe_Process(inst, ai_data, ao_data, aec_data);
}

int aec_deinit(AX_VOID *inst)
{
    return AX_AP_UpTalkVqe_Destory(inst);
}

int main(int argc, char *argv[])
{
	AX_VOID *aiAddr;
	AX_VOID *aecAddr;
	AX_VOID *aiAddr;
    AX_VOID *aec;

	aec = aec_init(8000, 160);

	while(1)
	{
		// TODO: use data in real environment 
		aec_process(aec, aiAddr, aecAddr, aiAddr);
	}

    return 0;
}

