/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include "vad_wrapper.h"

#include <assert.h>

#include "ap/vad/webrtc_vad.h"

typedef struct {
    void* vadHandle;
} VadCtx;

static int MapSetting(Likelihood likelihood) 
{
  Likelihood likelihood_temp;
  switch (likelihood) {
    case kVeryLowLikelihood:
      likelihood_temp = 3;
      break;
    case kLowLikelihood:
      likelihood_temp = 2;
      break;
    case kModerateLikelihood:
      likelihood_temp = 1;
      break;
    case kHighLikelihood:
      likelihood_temp = 0;
      break;
    default:
      likelihood_temp = 1;
  }
  
  return likelihood_temp;
}

int webrtc_vad_process(void* pCtx, void *ai_data, int sample_rate, size_t frame_size, unsigned short *vad_flags) 
{
    int vad_ret;
    if(!pCtx)
        return -1;
    VadCtx *pVadCtx = pCtx;

    vad_ret = WebRtcVad_Process(pVadCtx->vadHandle, sample_rate, ai_data, frame_size);
    if (vad_ret == 0) {
    *vad_flags = 0;
    } else if (vad_ret == 1) {
    *vad_flags = 1;
    } else {
    return -1;
    }

    return 0;
}

void* webrtc_vad_create(Likelihood likelihood)
{
    int ret;
    VadCtx *pVadCtx = malloc(sizeof(VadCtx));
    if(!pVadCtx)
        return NULL;
    pVadCtx->vadHandle = WebRtcVad_Create();
    if(pVadCtx->vadHandle == NULL){
            fprintf(stderr,"AP: create vad handle failed!\n");
            goto out_free_pVadCtx;
    }
	ret = WebRtcVad_Init(pVadCtx->vadHandle);
	if(ret < 0){
		fprintf(stderr,"Initialize  vad  failed!\n");
		goto out_free_vad_handle;
	}
    
    WebRtcVad_set_mode(pVadCtx->vadHandle, MapSetting(likelihood));

    return pVadCtx;

out_free_vad_handle:    
    WebRtcVad_Free(pVadCtx->vadHandle);
out_free_pVadCtx:
    free(pVadCtx);
    return NULL;
}

int webrtc_vad_destory(void* pCtx)
{
    if(!pCtx)
        return -1;
    VadCtx *pVadCtx = pCtx;
	if(pVadCtx->vadHandle!= NULL) {
	    WebRtcVad_Free(pVadCtx->vadHandle);
	    pVadCtx->vadHandle = NULL;
	}

    free(pVadCtx);
    return 0;
}

