/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/


#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include <ap/hpf/high_pass_filter.h>
#include "ap/aec/aec_core.h"
#include "ap/aec/include/echo_cancellation.h"
#include "ap/agc/legacy/gain_control.h"
#include "ap/user_wrappers/aec_wrapper.h"

#include <ap/user_wrappers/aecm_wrapper.h>
#include <ap/user_wrappers/ns_wrapper.h>
#include <ap/user_wrappers/agc_wrapper.h>

#include "ax_audio_process.h"

/* Expose nessary symbol */
#ifndef AX_AP_PUBLIC
    #define AX_AP_PUBLIC __attribute__ ((visibility ("default")))
#endif

typedef struct {
    size_t frameSamples;
    size_t processCnt;
    int16_t msInSndCardBuf;
    AX_BOOL aecFixedEnable;
    AX_BOOL aecFloatEnable;
    AX_BOOL bNsEnable;
    AX_BOOL bAgcEnable;
    AX_BOOL bVadEnable;
    void* pHpf;
    void* pAec;
    void* pAecm;
    void* pNs;
    void* pAgc;
    void* pVad;
} UpTalkVqeCtx;

static int CheckUpTalkVqeParams(UpTalkVqeCtx *pVqeCtx, const AP_UPTALKVQE_ATTR_S *pstVqeAttr)
{
    if(pstVqeAttr->s32SampleRate == 8000 && pstVqeAttr->u32FrameSamples == 80) {
        pVqeCtx->processCnt = 1;
        //pVqeCtx->msInSndCardBuf = 10;
    } else if(pstVqeAttr->s32SampleRate == 8000 && pstVqeAttr->u32FrameSamples == 160) {
        pVqeCtx->processCnt = 2;
        //pVqeCtx->msInSndCardBuf = 20;
    } else if(pstVqeAttr->s32SampleRate == 16000 && pstVqeAttr->u32FrameSamples == 160) {
        pVqeCtx->processCnt = 1;
        //pVqeCtx->msInSndCardBuf = 10;
    } else {
        fprintf(stderr,"Invalid sample rate or frame size!\n");
        return -1;
    }
    pVqeCtx->msInSndCardBuf = pstVqeAttr->msInSndCardBuf;

    if ((pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FLOAT) &&
        (pstVqeAttr->stAecCfg.stAecFloatCfg.enSuppressionLevel > 2)) {
        fprintf(stderr,"Invalid aec float parameter!\n");
        return -1;
    }

    if ((pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FIXED) &&
        (pstVqeAttr->stAecCfg.stAecFixedCfg.eRoutingMode > 4)) {
        fprintf(stderr,"Invalid aec fixed parameter!\n");
        return -1;
    }

    if ((pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) &&
        (pstVqeAttr->stNsCfg.enAggressivenessLevel > 3)) {
        fprintf(stderr,"Invalid ns parameter!\n");
        return -1;
    }

    if (pstVqeAttr->stAgcCfg.bAgcEnable == AX_TRUE) {
        if ((pstVqeAttr->stAgcCfg.enAgcMode == AGC_MODE_ADAPTIVE_ANALOG) ||
            (pstVqeAttr->stAgcCfg.enAgcMode == AGC_MODE_ADAPTIVE_DIGITAL)) {
            fprintf(stderr,"Agc mode not support!\n");
            return -1;
        }
        if ((pstVqeAttr->stAgcCfg.s16TargetLevel < -31) ||
            (pstVqeAttr->stAgcCfg.s16TargetLevel > 0)) {
            fprintf(stderr,"Invalid agc parameter!\n");
            return -1;
        }
        if (pstVqeAttr->stAgcCfg.s16Gain > 90) {
            fprintf(stderr,"Invalid agc parameter!\n");
            return -1;
        }
    }

    return 0;

}

static int16_t MapSettingSuppressionLevel(SUPPRESSION_LEVEL_E level) {
  switch (level) {
    case SUPPRESSION_LEVEL_LOW:
      return kAecNlpConservative;
    case SUPPRESSION_LEVEL_MODERATE:
      return kAecNlpModerate;
    case SUPPRESSION_LEVEL_HIGH:
      return kAecNlpAggressive;
  }
  return -1;
}

static int MapSettingRoutingMode(ROUTING_MODE_E mode)
{
    int route_mode = 0;

    switch (mode) {
      case ROUTING_MODE_QUITE_EARPIECE_OR_HEADSET:
        route_mode = 0;
        break;
      case ROUTING_MODE_EARPIECE:
        route_mode = 1;
        break;
      case ROUTING_MODE_LOUD_EARPIECE:
        route_mode = 2;
        break;
      case ROUTING_MODE_SPEAKERPHONE:
        route_mode = 3;
        break;
      case ROUTING_MODE_LOUD_SPEAKERPHONE:
        route_mode = 4;
        break;
      default:
        route_mode = 3;
    }

    return route_mode;
}

static int MapSettingAggressivenessLevel(AGGRESSIVENESS_LEVEL_E level)
{
  int level_temp = 0;
  
  switch (level) {
    case AGGRESSIVENESS_LEVEL_LOW:
      level_temp = 0;
      break;
    case AGGRESSIVENESS_LEVEL_MODERATE:
      level_temp = 1;
      break;
    case AGGRESSIVENESS_LEVEL_HIGH:
      level_temp = 2;
      break;
    case AGGRESSIVENESS_LEVEL_VERYHIGH:
      level_temp = 3;
      break;
    default:
      level_temp = 2;
  }

  return level_temp;
}

static int MapSettingAgcMode(AGC_MODE_E mode)
{

	switch (mode) {
	  case AGC_MODE_ADAPTIVE_ANALOG:
		return kAgcModeAdaptiveAnalog;
	  case AGC_MODE_ADAPTIVE_DIGITAL:
		return kAgcModeAdaptiveDigital;
	  case AGC_MODE_FIXED_DIGITAL:
		return kAgcModeFixedDigital;
	}

    return kAgcModeFixedDigital;
}

AX_AP_PUBLIC
AX_VOID *AX_AP_UpTalkVqe_Create(const AP_UPTALKVQE_ATTR_S *pstVqeAttr)
{
    int ret;

    UpTalkVqeCtx *pVqeCtx = malloc(sizeof(UpTalkVqeCtx));
    if (!pVqeCtx)
        return NULL;

    memset(pVqeCtx, 0, sizeof(*pVqeCtx));

    ret = CheckUpTalkVqeParams(pVqeCtx, pstVqeAttr);
    if(ret != 0) {
		goto out_free_pVqeCtx;
	}

    pVqeCtx->pHpf = webrtc_hpf_create(pstVqeAttr->s32SampleRate);
	if(!pVqeCtx->pHpf) {
		goto out_free_pVqeCtx;
	}

    if(pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FLOAT) {
        int16_t nlpMode = MapSettingSuppressionLevel(pstVqeAttr->stAecCfg.stAecFloatCfg.enSuppressionLevel);
        pVqeCtx->pAec = webrtc_aec_create(pstVqeAttr->s32SampleRate, nlpMode, 1);
        if(!pVqeCtx->pAec) {
		    goto out_hpf_destory;
    	}
        pVqeCtx->aecFloatEnable = AX_TRUE;
    } else if(pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FIXED) {
        int16_t echoMode = MapSettingRoutingMode(pstVqeAttr->stAecCfg.stAecFixedCfg.eRoutingMode);
        pVqeCtx->pAecm = webrtc_aecm_create(pstVqeAttr->s32SampleRate, 1, echoMode);
        if(!pVqeCtx->pAecm) {
		    goto out_hpf_destory;
    	}
        pVqeCtx->aecFixedEnable = AX_TRUE;
    }

    if(pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) {
        int mode = MapSettingAggressivenessLevel(pstVqeAttr->stNsCfg.enAggressivenessLevel);
        pVqeCtx->pNs = webrtc_ns_create(pstVqeAttr->s32SampleRate, mode);
        if(!pVqeCtx->pNs) {
		    goto out_aec_aecm_destory;
    	}
        pVqeCtx->bNsEnable = AX_TRUE;
    }

    if(pstVqeAttr->stVadCfg.bVadEnable == AX_TRUE){
        pVqeCtx->pVad = webrtc_vad_create(pstVqeAttr->stVadCfg.u32VadLevel);
        if(!pVqeCtx->pVad){
            goto out_vad_destory;
        }
        pVqeCtx->bVadEnable = AX_TRUE;
    }

    if(pstVqeAttr->stAgcCfg.bAgcEnable == AX_TRUE) {
        int16_t agcMode = MapSettingAgcMode(pstVqeAttr->stAgcCfg.enAgcMode);
        pVqeCtx->pAgc = webrtc_agc_create(pstVqeAttr->s32SampleRate, agcMode, pstVqeAttr->stAgcCfg.s16TargetLevel,
            pstVqeAttr->stAgcCfg.s16Gain);
        if(!pVqeCtx->pAgc) {
		    goto out_ns_destory;
    	}
        pVqeCtx->bAgcEnable = AX_TRUE;
    }

	pVqeCtx->frameSamples = pstVqeAttr->u32FrameSamples;

    return pVqeCtx;

out_ns_destory:
    if(pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) {
	    webrtc_ns_destory(pVqeCtx->pNs);
    }
out_vad_destory:
    if(pstVqeAttr->stVadCfg.bVadEnable == AX_TRUE){
        webrtc_vad_destory(pVqeCtx->pVad);
    }
out_aec_aecm_destory:
    if(pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FLOAT) {
	    webrtc_aec_destory(pVqeCtx->pAec);
    } else if(pstVqeAttr->stAecCfg.enAecMode == AEC_MODE_FIXED) {
	    webrtc_aecm_destory(pVqeCtx->pAecm);
    }
out_hpf_destory:
    webrtc_hpf_destory(pVqeCtx->pHpf);
out_free_pVqeCtx:
    free(pVqeCtx);
    return NULL;
}

AX_AP_PUBLIC
AX_S32 AX_AP_UpTalkVqe_Process(AX_VOID *inst, AX_VOID *in_data, AX_VOID *ref_data, AX_VOID *out_data)
{
    int stream_is_saturated;
	int i;
    int echoFlags = 0;
    unsigned short vadFlags;

    if (!inst)
        return -1;

    UpTalkVqeCtx *pVqeCtx = (UpTalkVqeCtx *)inst;

    memcpy(out_data, in_data, pVqeCtx->frameSamples*2);
    void *ppl_data = out_data;

    webrtc_hpf_process(pVqeCtx->pHpf, ppl_data, pVqeCtx->frameSamples);

#if 0
    for(i=0; i < pVqeCtx->processCnt; i++) {
        if(pVqeCtx->bAgcEnable) {
            webrtc_agc_analyze(ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt);
        }
    }
#endif
    if(pVqeCtx->aecFloatEnable && ref_data) {
        webrtc_aec_process(pVqeCtx->pAec, ppl_data, ref_data, ppl_data, pVqeCtx->frameSamples, &echoFlags, pVqeCtx->msInSndCardBuf);
    }

    if(pVqeCtx->aecFixedEnable && ref_data) {
        webrtc_aecm_process(pVqeCtx->pAecm, ppl_data, ref_data, ppl_data, pVqeCtx->frameSamples, pVqeCtx->msInSndCardBuf);
    }

    if(pVqeCtx->bNsEnable) {
        for(i=0; i < pVqeCtx->processCnt; i++) {
            webrtc_ns_process(pVqeCtx->pNs, ppl_data + i*160, ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt);
        }
    }

    if(pVqeCtx->bVadEnable){
        webrtc_vad_process(pVqeCtx->pVad, ppl_data, (pVqeCtx->frameSamples/pVqeCtx->processCnt*100), pVqeCtx->frameSamples, &vadFlags);
        if(vadFlags == 0) {
            memset(ppl_data, 0, (pVqeCtx->frameSamples * 2));
        }
    }

    if(pVqeCtx->bAgcEnable) {
        for(i=0; i < pVqeCtx->processCnt; i++) {
            webrtc_agc_process(pVqeCtx->pAgc, ppl_data + i*160, ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt, &stream_is_saturated, echoFlags);
        }
    }

    return 0;
}

AX_AP_PUBLIC
AX_S32 AX_AP_UpTalkVqe_Destory(AX_VOID *inst)
{
    if (!inst)
        return -1;

    UpTalkVqeCtx *pVqeCtx = (UpTalkVqeCtx *)inst;

    if(pVqeCtx->aecFloatEnable) {
	    webrtc_aec_destory(pVqeCtx->pAec);
	    pVqeCtx->aecFloatEnable = AX_FALSE;
    }
    if(pVqeCtx->aecFixedEnable) {
	    webrtc_aecm_destory(pVqeCtx->pAecm);
	    pVqeCtx->aecFixedEnable = AX_FALSE;
    }

    if(pVqeCtx->bNsEnable) {
	    webrtc_ns_destory(pVqeCtx->pNs);
	    pVqeCtx->bNsEnable = AX_FALSE;
    }

    if(pVqeCtx->bVadEnable) {
        webrtc_vad_destory(pVqeCtx->pVad);
        pVqeCtx->bVadEnable = AX_FALSE;
    }

    if(pVqeCtx->bAgcEnable) {
        webrtc_agc_destory(pVqeCtx->pAgc);
        pVqeCtx->bAgcEnable = AX_FALSE;
    }

    webrtc_hpf_destory(pVqeCtx->pHpf);

    free(pVqeCtx);
    return 0;
}

typedef struct {
    size_t frameSamples;
    size_t processCnt;
    AX_BOOL bNsEnable;
    AX_BOOL bAgcEnable;
    void* pHpf;
    void* pNs;
    void* pAgc;
} DnVqeCtx;

static int CheckDnVqeParams(DnVqeCtx *pVqeCtx, const AP_DNVQE_ATTR_S *pstVqeAttr)
{
    if(pstVqeAttr->s32SampleRate == 8000 && pstVqeAttr->u32FrameSamples == 80) {
		pVqeCtx->processCnt = 1;
	} else if(pstVqeAttr->s32SampleRate == 8000 && pstVqeAttr->u32FrameSamples == 160) {
		pVqeCtx->processCnt = 2;
	} else if(pstVqeAttr->s32SampleRate == 16000 && pstVqeAttr->u32FrameSamples == 160) {
		pVqeCtx->processCnt = 1;
	} else {
        fprintf(stderr,"Invalid sample rate or frame size!\n");
        return -1;
    }

    if ((pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) &&
        (pstVqeAttr->stNsCfg.enAggressivenessLevel > 3)) {
        fprintf(stderr,"Invalid ns parameter!\n");
        return -1;
    }

    if (pstVqeAttr->stAgcCfg.bAgcEnable == AX_TRUE) {
        if ((pstVqeAttr->stAgcCfg.enAgcMode == AGC_MODE_ADAPTIVE_ANALOG) ||
            (pstVqeAttr->stAgcCfg.enAgcMode == AGC_MODE_ADAPTIVE_DIGITAL)) {
            fprintf(stderr,"Agc mode not support!\n");
            return -1;
        }
        if ((pstVqeAttr->stAgcCfg.s16TargetLevel < -31) ||
            (pstVqeAttr->stAgcCfg.s16TargetLevel > 0)) {
            fprintf(stderr,"Invalid agc parameter!\n");
            return -1;
        }
        if (pstVqeAttr->stAgcCfg.s16Gain > 90) {
            fprintf(stderr,"Invalid agc parameter!\n");
            return -1;
        }
    }

    return 0;

}

AX_AP_PUBLIC
AX_VOID *AX_AP_DnVqe_Create(const AP_DNVQE_ATTR_S *pstVqeAttr)
{
    int ret;

    DnVqeCtx *pVqeCtx = malloc(sizeof(DnVqeCtx));
    if (!pVqeCtx)
        return NULL;

    memset(pVqeCtx, 0, sizeof(*pVqeCtx));

    ret = CheckDnVqeParams(pVqeCtx, pstVqeAttr);
    if(ret != 0) {
		goto out_free_pVqeCtx;
	}

    pVqeCtx->pHpf = webrtc_hpf_create(pstVqeAttr->s32SampleRate);
	if(!pVqeCtx->pHpf) {
		goto out_free_pVqeCtx;
	}

    if(pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) {
        int mode = MapSettingAggressivenessLevel(pstVqeAttr->stNsCfg.enAggressivenessLevel);
        pVqeCtx->pNs = webrtc_ns_create(pstVqeAttr->s32SampleRate, mode);
        if(!pVqeCtx->pNs) {
		    goto out_hpf_destory;
        }
        pVqeCtx->bNsEnable = AX_TRUE;
    }

    if(pstVqeAttr->stAgcCfg.bAgcEnable == AX_TRUE) {
        int16_t agcMode = MapSettingAgcMode(pstVqeAttr->stAgcCfg.enAgcMode);
        pVqeCtx->pAgc = webrtc_agc_create(pstVqeAttr->s32SampleRate, agcMode, pstVqeAttr->stAgcCfg.s16TargetLevel,
            pstVqeAttr->stAgcCfg.s16Gain);
        if(!pVqeCtx->pAgc) {
		    goto out_ns_destory;
        }
        pVqeCtx->bAgcEnable = AX_TRUE;
    }

	pVqeCtx->frameSamples = pstVqeAttr->u32FrameSamples;

    return pVqeCtx;

out_ns_destory:
    if(pstVqeAttr->stNsCfg.bNsEnable == AX_TRUE) {
	    webrtc_ns_destory(pVqeCtx->pNs);
    }
out_hpf_destory:
    webrtc_hpf_destory(pVqeCtx->pHpf);
out_free_pVqeCtx:
    free(pVqeCtx);
    return NULL;
}

AX_AP_PUBLIC
AX_S32 AX_AP_DnVqe_Process(AX_VOID *inst, AX_VOID *in_data, AX_VOID *out_data)
{
    int stream_is_saturated;
	int i;
    int echoFlags = 0;

    if (!inst)
        return -1;

    DnVqeCtx *pVqeCtx = (DnVqeCtx *)inst;

    memcpy(out_data, in_data, pVqeCtx->frameSamples*2);
    void *ppl_data = out_data;

    webrtc_hpf_process(pVqeCtx->pHpf, ppl_data, pVqeCtx->frameSamples);

#if 0
    for(i=0; i < pVqeCtx->processCnt; i++) {
        if(pVqeCtx->bAgcEnable) {
            webrtc_agc_analyze(ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt);
        }
    }
#endif
    if(pVqeCtx->bNsEnable) {
        for(i=0; i < pVqeCtx->processCnt; i++) {
            webrtc_ns_process(pVqeCtx->pNs, ppl_data + i*160, ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt);
        }
    }

    if(pVqeCtx->bAgcEnable) {
        for(i=0; i < pVqeCtx->processCnt; i++) {
           webrtc_agc_process(pVqeCtx->pAgc, ppl_data + i*160, ppl_data + i*160, pVqeCtx->frameSamples / pVqeCtx->processCnt, &stream_is_saturated, echoFlags);
        }
    }

    return 0;
}

AX_AP_PUBLIC
AX_S32 AX_AP_DnVqe_Destory(AX_VOID *inst)
{
    if (!inst)
        return -1;

    DnVqeCtx *pVqeCtx = (DnVqeCtx *)inst;

    if(pVqeCtx->bNsEnable) {
	    webrtc_ns_destory(pVqeCtx->pNs);
	    pVqeCtx->bNsEnable = AX_FALSE;
    }
    if(pVqeCtx->bAgcEnable) {
        webrtc_agc_destory(pVqeCtx->pAgc);
        pVqeCtx->bAgcEnable = AX_FALSE;
    }

    webrtc_hpf_destory(pVqeCtx->pHpf);

    free(pVqeCtx);
    return 0;
}

AX_AP_PUBLIC
AX_VOID AX_AUDIO_InterleavedToNoninterleaved16(AX_S16 *interleaved, AX_U32 frameCount, AX_S16 *left, AX_S16 *right)
{
    for (AX_U32 i = 0; i < frameCount; i++) {
        AX_S16 *src = &interleaved[i*2];
        left[i] = src[0];
        right[i] = src[1];
    }
}

AX_AP_PUBLIC
AX_VOID AX_AUDIO_MonoToStereo16(AX_S16 *mono, AX_U32 frameCount, AX_S16 *stereo)
{
    for (AX_U32 i = 0; i < frameCount; i++) {
        AX_S16* src = &mono[i];
        AX_S16* dst = &stereo[i*2];
        dst[0] = src[0];
        dst[1] = src[0];
    }
}

