/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "ap/aec/aec_core.h"
#include "ap/aec/include/echo_cancellation.h"
#include "ap/user_wrappers/aec_wrapper.h"

typedef struct {
    void* aecHandle;
    void **pInData;
    void **pOutData;
} AecCtx;

void* webrtc_aec_create(int sample_rate, int16_t nlpMode, int delay_agnostic)
{
    AecConfig config;
    int ret;

    AecCtx *pAecCtx = malloc(sizeof(AecCtx));
    if (!pAecCtx)
		return NULL;

    pAecCtx->aecHandle = WebRtcAec_Create();
    if (pAecCtx->aecHandle == NULL){
        fprintf(stderr,"AP: create  aec[Float] handle failed!\n");
		goto out_free_pAecCtx;
    }

	//ret = WebRtcAec_Init(pAecCtx->aecHandle, sample_rate, 48000);
    ret = WebRtcAec_Init(pAecCtx->aecHandle, sample_rate, sample_rate);
	if (ret < 0){
		fprintf(stderr,"Initialize  aec[Float]  failed!\n");
		goto out_free_aec_handle;
	}

    config.metricsMode = kAecFalse;
    config.nlpMode = nlpMode;
    config.skewMode = kAecFalse;
    config.delay_logging = kAecFalse;

    WebRtcAec_enable_extended_filter(WebRtcAec_aec_core(pAecCtx->aecHandle), 0);
    WebRtcAec_enable_delay_agnostic(WebRtcAec_aec_core(pAecCtx->aecHandle), delay_agnostic);

    ret = WebRtcAec_set_config(pAecCtx->aecHandle, config);
    if (ret) {
		fprintf(stderr,"WebRtcAec_set_config error\n");
		goto out_free_aec_handle;
	}

    pAecCtx->pInData = (void**)malloc(sizeof(void*));
	if(pAecCtx->pInData == NULL) {
		fprintf(stderr,"malloc memory failed!");
		goto out_free_aec_handle;
	}
    pAecCtx->pOutData = (void**)malloc(sizeof(void*));
    if(pAecCtx->pOutData == NULL) {
		fprintf(stderr,"malloc memory failed!");
		goto out_free_pInData;
	}

    return pAecCtx;

out_free_pInData:
    free(pAecCtx->pInData);
out_free_aec_handle:
    WebRtcAec_Free(pAecCtx->aecHandle);
out_free_pAecCtx:
    free(pAecCtx);
    return NULL;
}

int webrtc_aec_process(void* pCtx, void *in_data, void *ref_data, void *out_data, size_t frame_samples, int *echoFlags, int16_t msInSndCardBuf)
{
    short *st_inFrame = (short *)in_data;
    short *st_refFrame = (short *)ref_data;
    short *st_outFrame = (short *)out_data;
    //int16_t msInSndCardBuf;
    float inbuf[160];
    float refbuf[160];
    float outbuf[160];
    int i = 0;
    int ret;

    if (!pCtx)
        return -1;

    AecCtx *pAecCtx = pCtx;

    //msInSndCardBuf = (frame_samples == 160) ? 10 : 20;

    for(i=0; i<frame_samples; i++) {
        inbuf[i] = (float)st_inFrame[i];
        refbuf[i] = (float)st_refFrame[i];
    }
    *pAecCtx->pInData = (void*)inbuf;
    *pAecCtx->pOutData = (void*)outbuf;

    ret = WebRtcAec_BufferFarend(pAecCtx->aecHandle, (const float*)refbuf, frame_samples);
    if (ret != 0) {
        fprintf(stderr,"AP: fill in farend data failed.\n");
    }

    ret = WebRtcAec_Process(pAecCtx->aecHandle, (const float* const*)pAecCtx->pInData, 1, (float* const*)pAecCtx->pOutData, frame_samples, msInSndCardBuf, 0);
    if (ret != 0) {
        fprintf(stderr,"AP: aec[Float] Process failed.\n");
    }

    ret = WebRtcAec_get_echo_status(pAecCtx->aecHandle, echoFlags);
    if (ret != 0) {
        fprintf(stderr,"AP: aec[Float] get echo flags failed.\n");
    }

    for(i=0;i<frame_samples;i++) {
    	st_outFrame[i] = (short)outbuf[i];
    }

    return 0;

}

int webrtc_aec_destory(void* pCtx)
{
    if (!pCtx)
        return -1;

    AecCtx *pAecCtx = pCtx;

	if(pAecCtx->aecHandle!= NULL) {
	    WebRtcAec_Free(pAecCtx->aecHandle);
	    pAecCtx->aecHandle = NULL;
	}

    if(pAecCtx->pInData!= NULL) {
	    free(pAecCtx->pInData);
        pAecCtx->pInData = NULL;
	}
    if(pAecCtx->pOutData!= NULL) {
	    free(pAecCtx->pOutData);
        pAecCtx->pOutData = NULL;
	}
    free(pAecCtx);
    return 0;
}

