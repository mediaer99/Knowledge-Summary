/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <ap/user_wrappers/agc_wrapper.h>
#include <assert.h>
#include "ap/agc/legacy/gain_control.h"

typedef struct {
    int capture_levels;
    int analog_capture_level;
    int16_t agc_mode;

    void *agcHandle;
    void **pInData;
    void **pOutData;
} AgcCtx;

void* webrtc_agc_create(int sample_rate, int16_t agcMode, int16_t targetLevel, int16_t gain)
{
    WebRtcAgcConfig config;
    int ret;

    AgcCtx *pAgcCtx = malloc(sizeof(AgcCtx));
    if (!pAgcCtx)
		return NULL;

    memset(pAgcCtx, 0, sizeof(*pAgcCtx));
    pAgcCtx->analog_capture_level = 0;

	pAgcCtx->agcHandle = WebRtcAgc_Create();
	if (pAgcCtx->agcHandle == NULL) {
		fprintf(stderr,"create webrtc agc failed!\n");
		goto out_free_pAgcCtx;
	}

	ret = WebRtcAgc_Init(pAgcCtx->agcHandle, 0, 255, agcMode, sample_rate);
	if (ret < 0) {
		fprintf(stderr,"Initialize webrtc gac failed!\n");
		goto out_free_gac_handle;
	}

	config.targetLevelDbfs = -targetLevel;
    config.compressionGaindB = gain;
    config.limiterEnable = kAgcTrue;

    ret = WebRtcAgc_set_config(pAgcCtx->agcHandle, config);
    if (ret < 0) {
		fprintf(stderr,"Configure webrtc agc failed!\n");
		goto out_free_gac_handle;
	}

	pAgcCtx->pInData = (void**)malloc(sizeof(void*));
    if (pAgcCtx->pInData == NULL) {
        fprintf(stderr,"malloc memory failed!\n");
        goto out_free_gac_handle;
    }
    pAgcCtx->pOutData = (void**)malloc(sizeof(void*));
    if (pAgcCtx->pOutData == NULL) {
        fprintf(stderr,"malloc memory failed!\n");
        goto out_free_pInData;
    }

    pAgcCtx->agc_mode = agcMode;

    return pAgcCtx;

out_free_pInData:
	free(pAgcCtx->pInData);
out_free_gac_handle:
    WebRtcAgc_Free(pAgcCtx->agcHandle);
out_free_pAgcCtx:
    free(pAgcCtx);
    return NULL;
}

int webrtc_agc_analyze(void* pCtx, void *ai_data, size_t frame_samples)
{
    int ret;

    if (!pCtx)
        return -1;

    AgcCtx *pAgcCtx = pCtx;

    *pAgcCtx->pInData = ai_data;
    if (pAgcCtx->agc_mode == kAgcModeAdaptiveAnalog) {
        pAgcCtx->capture_levels = pAgcCtx->analog_capture_level;
        ret = WebRtcAgc_AddMic(
            pAgcCtx->agcHandle,
            (int16_t* const*)pAgcCtx->pInData,
            1,
            frame_samples);

        if (ret != 0) {
            return ret;
        }
    } else if (pAgcCtx->agc_mode == kAgcModeAdaptiveDigital) {
        int32_t capture_level_out = 0;

        ret = WebRtcAgc_VirtualMic(
            pAgcCtx->agcHandle,
            (int16_t* const*)pAgcCtx->pInData,
            1,
            frame_samples,
            pAgcCtx->analog_capture_level,
            &capture_level_out);

        pAgcCtx->capture_levels = capture_level_out;

        if (ret != 0) {
            return ret;
        }
    }

    return 0;
}

int webrtc_agc_process(void* pCtx, void *ai_data, void *ao_data, size_t frame_samples, int *stream_is_saturated, int echoFlags)
{
    int ret;
    int capture_level_out = 0;

    if (!pCtx)
        return -1;

    AgcCtx *pAgcCtx = pCtx;

    *pAgcCtx->pInData = ai_data;
    *pAgcCtx->pOutData = ao_data;

    ret = WebRtcAgc_Process(
        pAgcCtx->agcHandle,
        (const int16_t* const*)pAgcCtx->pInData,
        1,
        frame_samples,
        (int16_t* const*)pAgcCtx->pOutData,
        pAgcCtx->capture_levels,
        &capture_level_out,
        echoFlags,
        (uint8_t *)stream_is_saturated);

    if (ret != 0) {
        fprintf(stderr,"webrtc_agc_process() failed!\n");
    }

    pAgcCtx->capture_levels = capture_level_out;

    if (pAgcCtx->agc_mode == kAgcModeAdaptiveAnalog) {
        // Take the analog level to be the average across the handles.
        pAgcCtx->analog_capture_level = pAgcCtx->capture_levels;
    }

    return ret;
}

int webrtc_agc_destory(void* pCtx)
{
    if (!pCtx)
        return -1;

    AgcCtx *pAgcCtx = pCtx;

	if(pAgcCtx->agcHandle!= NULL) {
	    WebRtcAgc_Free(pAgcCtx->agcHandle);
	    pAgcCtx->agcHandle = NULL;
	}

	if(pAgcCtx->pInData!= NULL) {
	    free(pAgcCtx->pInData);
        pAgcCtx->pInData = NULL;
	}
    if(pAgcCtx->pOutData!= NULL) {
	    free(pAgcCtx->pOutData);
        pAgcCtx->pOutData = NULL;
	}

    if (pAgcCtx) {
        free(pAgcCtx);
    }

    return 0;
}

