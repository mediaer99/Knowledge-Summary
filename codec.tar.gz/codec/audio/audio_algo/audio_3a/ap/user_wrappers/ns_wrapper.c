/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <ap/user_wrappers/ns_wrapper.h>


#if defined(WEBRTC_NS_FLOAT)
#include "ap/ns/noise_suppression.h"
#elif defined(WEBRTC_NS_FIXED)
#include "ap/ns/noise_suppression_x.h"
#endif

#if defined(WEBRTC_NS_FLOAT)
#define Ns_Init WebRtcNs_Init
#define Ns_Process WebRtcNs_Process
#define Ns_Create WebRtcNs_Create
#define Ns_Free WebRtcNs_Free
#define Ns_Analyze WebRtcNs_Analyze
#define Ns_set_policy WebRtcNs_set_policy
#elif defined(WEBRTC_NS_FIXED)
#define Ns_Init WebRtcNsx_Init
#define Ns_Process WebRtcNsx_Process
#define Ns_Create WebRtcNsx_Create
#define Ns_Free WebRtcNsx_Free
#define Ns_set_policy WebRtcNsx_set_policy
#endif

typedef struct {
    void* nsxHandle;
    void **pInData;
    void **pOutData;
} NsCtx;

void* webrtc_ns_create(int sample_rate, int mode)
{
    int ret = 0;

    NsCtx *pNsCtx = malloc(sizeof(NsCtx));
    if (!pNsCtx)
		return NULL;

    pNsCtx->nsxHandle = (void*)Ns_Create();
	if(pNsCtx->nsxHandle == NULL){
		fprintf(stderr,"CreateHandle failed!");
	    goto out_free_pNsCtx;
	}
	ret = Ns_Init(pNsCtx->nsxHandle, sample_rate);
	if(ret!= 0) {
	    fprintf(stderr,"InitializeHandle failed!");
	    goto out_free_ns_handle;
	}
	ret = Ns_set_policy(pNsCtx->nsxHandle, mode);
    if(ret!= 0) {
	    fprintf(stderr,"ConfigureHandle failed!");
	    goto out_free_ns_handle;
	}

    pNsCtx->pInData = (void**)malloc(sizeof(void*));
	if(pNsCtx->pInData == NULL) {
		fprintf(stderr,"malloc memory failed!");
		goto out_free_ns_handle;
	}
    pNsCtx->pOutData = (void**)malloc(sizeof(void*));
    if(pNsCtx->pOutData == NULL) {
		fprintf(stderr,"malloc memory failed!");
		goto out_free_pInData;
	}

    return pNsCtx;
out_free_pInData:
	free(pNsCtx->pInData);
out_free_ns_handle:
    Ns_Free(pNsCtx->nsxHandle);
out_free_pNsCtx:
    free(pNsCtx);
    return NULL;
}

int webrtc_ns_process(void* pCtx, void *inFrame, void *outFrame, size_t frame_samples)
{
    if (!pCtx)
        return -1;

    NsCtx *pNsCtx = pCtx;

#if defined(WEBRTC_NS_FLOAT)
    short *st_inFrame = (short *)inFrame;
    short *st_outFrame = (short *)outFrame;
    float inbuf[160];
    float outbuf[160];
    int i = 0;

    for(i=0; i<frame_samples; i++) {
        inbuf[i] = (float)st_inFrame[i];
    }
    Ns_Analyze(pNsCtx->nsxHandle, inbuf);

    *pNsCtx->pInData = (void*)inbuf;
    *pNsCtx->pOutData = (void*)outbuf;

    Ns_Process(pNsCtx->nsxHandle, (const float* const*)pNsCtx->pInData,1, (float* const*)pNsCtx->pOutData);

    for(i=0; i<frame_samples; i++) {
    	st_outFrame[i] = (short)outbuf[i];
    }

#else
	*pNsCtx->pInData = inFrame;
	*pNsCtx->pOutData = outFrame;

	Ns_Process(pNsCtx->nsxHandle, (const short* const*)pNsCtx->pInData,1, (short* const*)pNsCtx->pOutData);
#endif

    return 0;
}

int webrtc_ns_destory(void* pCtx)
{
    if (!pCtx)
        return -1;

    NsCtx *pNsCtx = pCtx;

	if(pNsCtx->nsxHandle!= NULL) {
	    Ns_Free(pNsCtx->nsxHandle);
	    pNsCtx->nsxHandle =  NULL;
	}
    if(pNsCtx->pInData!= NULL) {
	    free(pNsCtx->pInData);
        pNsCtx->pInData = NULL;
	}
    if(pNsCtx->pOutData!= NULL) {
	    free(pNsCtx->pOutData);
        pNsCtx->pOutData = NULL;
	}

    if (pNsCtx) {
        free(pNsCtx);
    }

    return 0;
}

