/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */
#include <stdio.h>

#ifndef WEBRTC_NOISE_SUPPRESSION_WRAPPER_H_
#define WEBRTC_NOISE_SUPPRESSION_WRAPPER_H_


void* webrtc_ns_create(int sample_rate, int mode);
int webrtc_ns_process(void* pCtx, void *inFrame, void *outFrame, size_t frame_samples);
int webrtc_ns_destory(void* pCtx);

#endif  // WEBRTC_NOISE_SUPPRESSION_WRAPPER_H_
