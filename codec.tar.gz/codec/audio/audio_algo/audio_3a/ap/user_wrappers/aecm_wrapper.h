#ifndef _GK_AECM_H__
#define _GK_AECM_H__

#include <stdio.h>
#include <stdlib.h>


#ifdef __cplusplus
extern "C" {
#endif

void* webrtc_aecm_create(int sample_rate, int cngMode, int16_t echoMode);
int webrtc_aecm_process(void* pCtx, void *in_data, void *ref_data, void *out_data, size_t frame_samples, int16_t msInSndCardBuf);
int webrtc_aecm_destory(void* pCtx);

#ifdef __cplusplus
}
#endif

#endif /* _GK_AECM_H__ */
