#ifndef _VAD_WRAPPER_H_
#define _VAD_WRAPPER_H_

#include <stdio.h>

// Specifies the likelihood that a frame will be declared to contain voice.
// A higher value makes it more likely that speech will not be clipped, at
// the expense of more noise being detected as voice.
typedef enum {
  kVeryLowLikelihood,
  kLowLikelihood,
  kModerateLikelihood,
  kHighLikelihood
}Likelihood;

#ifdef __cplusplus
extern "C" {
#endif

void* webrtc_vad_create(Likelihood likelihood);
int webrtc_vad_process(void* pCtx, void *ai_data, int sample_rate, size_t frame_size, unsigned short *vad_flags);
int webrtc_vad_destory(void* pCtx);

#ifdef __cplusplus
}
#endif

#endif  // _VAD_WRAPPER_H_
