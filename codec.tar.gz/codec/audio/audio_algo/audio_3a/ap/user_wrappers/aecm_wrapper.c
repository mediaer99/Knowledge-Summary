/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include <stdio.h>
#include <string.h>
#include <ap/aecm/echo_control_mobile.h>
#include <ap/user_wrappers/aecm_wrapper.h>

typedef struct {
    void* aecmHandle;
} AecmCtx;

void* webrtc_aecm_create(int sample_rate, int cngMode, int16_t echoMode)
{
    AecmConfig config;
    int ret;

    AecmCtx *pAecmCtx = malloc(sizeof(AecmCtx));
    if (!pAecmCtx)
		return NULL;

	pAecmCtx->aecmHandle = WebRtcAecm_Create();
	if (pAecmCtx->aecmHandle == NULL) {
		fprintf(stderr,"create webrtc aecm failed!\n");
		goto out_free_pAecmCtx;
	}

	ret = WebRtcAecm_Init(pAecmCtx->aecmHandle,sample_rate);
	if (ret) {
		fprintf(stderr,"Initialize webrtc aecm failed!\n");
		goto out_free_aecm_handle;
	}

    config.cngMode = cngMode;
    config.echoMode = echoMode;

    ret = WebRtcAecm_set_config(pAecmCtx->aecmHandle, config);
    if (ret) {
		fprintf(stderr,"Configure webrtc aecm failed!\n");
		goto out_free_aecm_handle;
	}

    return pAecmCtx;

out_free_aecm_handle:
    WebRtcAecm_Free(pAecmCtx->aecmHandle);
out_free_pAecmCtx:
    free(pAecmCtx);
    return NULL;
}

int webrtc_aecm_process(void* pCtx, void *in_data, void *ref_data, void *out_data, size_t frame_samples, int16_t msInSndCardBuf)
{
    //int16_t msInSndCardBuf;

    if (!pCtx)
        return -1;

    AecmCtx *pAecmCtx = pCtx;

    //msInSndCardBuf = (frame_samples == 160) ? 10 : 20;

    if (WebRtcAecm_BufferFarend(pAecmCtx->aecmHandle,  (const int16_t*)ref_data, frame_samples)!=0) {
	    fprintf(stderr,"WebRtcAecm_BufferFarend() failed.\n");
	}

	if (WebRtcAecm_Process(pAecmCtx->aecmHandle,  (const int16_t*)in_data, NULL, out_data, frame_samples, msInSndCardBuf)!=0) {
	    fprintf(stderr,"WebRtcAecm_Process() failed.\n");
	}

    return 0;
}

int webrtc_aecm_destory(void* pCtx)
{
    if (!pCtx)
        return -1;

    AecmCtx *pAecmCtx = pCtx;

	if (pAecmCtx->aecmHandle != NULL) {
	    WebRtcAecm_Free(pAecmCtx->aecmHandle);
	    pAecmCtx->aecmHandle = NULL;
	}

    free(pAecmCtx);
    return 0;
}

