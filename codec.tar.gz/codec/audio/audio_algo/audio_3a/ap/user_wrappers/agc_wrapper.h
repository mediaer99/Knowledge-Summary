#ifndef _GK_AGC_H__
#define _GK_AGC_H__

#include <stdio.h>

void* webrtc_agc_create(int sample_rate, int16_t agcMode, int16_t targetLevel, int16_t gain);
int webrtc_agc_analyze(void* pCtx, void *ai_data, size_t frame_samples);
int webrtc_agc_process(void* pCtx, void *ai_data, void *ao_data, size_t frame_samples, int *stream_is_saturated, int echoFlags);
int webrtc_agc_destory(void* pCtx);

#endif  // _GK_AGC_H__
