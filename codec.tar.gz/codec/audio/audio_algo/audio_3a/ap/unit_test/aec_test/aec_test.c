#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>

#include "ap/aec/aec_core.h"
#include "ap/aec/include/echo_cancellation.h"
#include "user_wrappers/aec_wrapper.h"
#include "user_wrappers/wave_parser.h"

#define SAMPLE_NUM      160

static unsigned int gRate = 16000;
static char *gInFileName = NULL;
static char *gRefFileName = NULL;
static char *gOutFileName = NULL;
static int gIsWave = 1;
static int16_t gNlpMode = kAecNlpModerate;
static int gDelayAgnostic = 1;
static int16_t gMsInSndCardBuf = 10;

int Process()
{
    short in[SAMPLE_NUM];
    short ref[SAMPLE_NUM];
    short out[SAMPLE_NUM];
    int echoFlags;

    FILE *inFile;
    FILE *refFile;
    FILE *outFile;
    inFile = fopen(gInFileName, "rb");
    if (!inFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gInFileName);
        return 1;
    }
    refFile = fopen(gRefFileName, "rb");
    if (!refFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gRefFileName);
        goto close_inFile;
    }
    outFile = fopen(gOutFileName, "wb");
    if (!outFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gOutFileName);
        goto close_refFile;
    }

    if (gIsWave) {
        uint16_t in_num_channels;
        uint32_t in_sample_rate;
        uint16_t in_bits_per_sample;
        if (ParseWaveHeader(gInFileName, inFile, &in_num_channels, &in_sample_rate, &in_bits_per_sample)) {
            fprintf(stderr, "ParseWaveHeader '%s' error\n", gInFileName);
            goto close_outFile;
        }
        if (in_num_channels != 1 || in_bits_per_sample != 16) {
            fprintf(stderr, "'%s' format not support\n", gInFileName);
            goto close_outFile;
        }

        uint16_t ref_num_channels;
        uint32_t ref_sample_rate;
        uint16_t ref_bits_per_sample;
        if (ParseWaveHeader(gRefFileName, refFile, &ref_num_channels, &ref_sample_rate, &ref_bits_per_sample)) {
            fprintf(stderr, "ParseWaveHeader '%s' error\n", gRefFileName);
            goto close_outFile;
        }
        if (ref_num_channels != 1 || ref_bits_per_sample != 16) {
            fprintf(stderr, "'%s' format not support\n", gRefFileName);
            goto close_outFile;
        }

        LeaveWaveHeader(outFile);

        if (in_sample_rate != ref_sample_rate) {
            printf("in_sample_rate not match ref_sample_rate\n");
            goto close_outFile;
        }
        gRate = in_sample_rate;
    }

    void* pAec = webrtc_aec_create(gRate, gNlpMode, gDelayAgnostic);
    if (!pAec) {
        goto close_outFile;
    }

    unsigned int frames = 0;
    while (!feof(inFile)) {
        fread(in, sizeof(short), SAMPLE_NUM, inFile);
        fread(ref, sizeof(short), SAMPLE_NUM, refFile);
        webrtc_aec_process(pAec, in, ref, out, SAMPLE_NUM, &echoFlags, gMsInSndCardBuf);
        fwrite(out, sizeof(short), SAMPLE_NUM, outFile);
        frames += SAMPLE_NUM;
    }
   
    webrtc_aec_destory(pAec);

    if (gIsWave) {
        WriteWaveHeader(outFile, 1, gRate, 16, frames);
    }

close_outFile:
    fclose(outFile);
close_refFile:
    fclose(refFile);
close_inFile:
    fclose(inFile);
    return 0;
}

static void PrintHelp()
{
    printf("usage: aec_test <args>\n");
    printf("args:\n");
    printf("  -r:               rate.                       (support 8000-48000), default: 16000\n");
    printf("  -i:               inFile.                     (support string), default: NULL\n");
    printf("  -e:               refFile.                    (support string), default: NULL\n");
    printf("  -o:               outFile.                    (support string), default: NULL\n");
    printf("  -v:               is wave file.               (support 0,1), default: 1\n");
    printf("  --nlp:            gNlpMode.                   (support 0,1,2), default: 1\n");
    printf("  --delay:          enable delay agnostic.      (support 0,1), default: 1\n");
    printf("  --ms:             gMsInSndCardBuf.            (support int), default: 10\n");
}

enum LONG_OPTION {
    LONG_OPTION_NLP_MODE = 10000,
    LONG_OPTION_DELAY_AGNOSTIC,
    LONG_OPTION_MS,
    LONG_OPTION_BUTT
};

int main(int argc, char *argv[])
{
    int c;
    int isExit = 0;

    while (1) {
        int option_index = 0;
        static struct option long_options[] = {
            {"nlp",                 required_argument,  0, LONG_OPTION_NLP_MODE},
            {"delay",               required_argument,  0, LONG_OPTION_DELAY_AGNOSTIC },
            {"ms",                  required_argument,  0, LONG_OPTION_MS },
            {0,                     0,                  0, 0 }
        };

        c = getopt_long(argc, argv, "r:i:e:o:v:h",
                 long_options, &option_index);
        if (c == -1)
            break;
        
        switch (c) {
        case 'r':
            gRate = atoi(optarg);
            break;
        case 'i':
            gInFileName = optarg;
            break;
        case 'e':
            gRefFileName = optarg;
            break;
        case 'o':
            gOutFileName = optarg;
            break;
        case 'v':
            gIsWave = atoi(optarg);
            break;
        case 'h':
            isExit = 1;
            break;
        case LONG_OPTION_NLP_MODE:
            gNlpMode = atoi(optarg);
            printf("gNlpMode: %d\n", gNlpMode);
            break;
        case LONG_OPTION_DELAY_AGNOSTIC:
            gDelayAgnostic = atoi(optarg);
            printf("gDelayAgnostic: %d\n", gDelayAgnostic);
            break;
        case LONG_OPTION_MS:
            gMsInSndCardBuf = atoi(optarg);
            printf("gMsInSndCardBuf: %d\n", gMsInSndCardBuf);
            break;
        default:
            isExit = 1;
            break;
        }
    }

    if (isExit) {
        PrintHelp();
        exit(0);
    }

    if (!gInFileName || !gRefFileName || !gOutFileName) {
        PrintHelp();
        exit(0);
    }

    Process();

    return 0;
}
