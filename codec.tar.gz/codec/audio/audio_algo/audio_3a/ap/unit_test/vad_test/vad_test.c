#include <stdio.h>
#include "user_wrappers/vad_wrapper.h"


FILE *aoFile;
FILE *aiFile;

int main(int argc, char **argv)
{
   short ai[80];
   short st[80] = {0,};
   unsigned short vadFlags;
   
   aiFile = fopen(argv[1], "rb");
   aoFile = fopen(argv[2], "wb");

   webrtc_vad_init(0);

   while (!feof(aiFile))
   {
      fread(ai, sizeof(short), 80, aiFile);
      webrtc_vad_process(ai, 8000, 160, &vadFlags);
      if(vadFlags) {
        fwrite(ai, sizeof(short), 80, aoFile);
      }else {
        fwrite(st, sizeof(short), 80, aoFile);
      }
   }
   
   webrtc_vad_deinit();
   fclose(aiFile);
   fclose(aoFile);

   return 0;
}
