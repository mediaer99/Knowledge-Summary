#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <assert.h>

#include "user_wrappers/ns_wrapper.h"
#include "user_wrappers/wave_parser.h"

static unsigned int gRate = 16000;
static char *gInFileName = NULL;
static char *gRefFileName = NULL;
static char *gOutFileName = NULL;
static int gIsWave = 1;
static int gMode = 3;

int Process()
{
    FILE *inFile;
    FILE *outFile;
    inFile = fopen(gInFileName, "rb");
    if (!inFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gInFileName);
        return 1;
    }
    outFile = fopen(gOutFileName, "wb");
    if (!outFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gOutFileName);
        goto close_inFile;
    }

    if (gIsWave) {
        uint16_t in_num_channels;
        uint32_t in_sample_rate;
        uint16_t in_bits_per_sample;
        if (ParseWaveHeader(gInFileName, inFile, &in_num_channels, &in_sample_rate, &in_bits_per_sample)) {
            fprintf(stderr, "ParseWaveHeader '%s' error\n", gInFileName);
            goto close_outFile;
        }
        if (in_num_channels != 1 || in_bits_per_sample != 16) {
            fprintf(stderr, "'%s' format not support\n", gInFileName);
            goto close_outFile;
        }

        LeaveWaveHeader(outFile);

        gRate = in_sample_rate;
    }

    void* pNs = webrtc_ns_create(gRate, gMode);
    if (!pNs) {
        goto close_outFile;
    }

    int process_count = gRate/100;
    short* in = malloc(sizeof(short) * process_count);
    short* out = malloc(sizeof(short) * process_count);
    assert(in && out);

    unsigned int frames = 0;
    while (!feof(inFile)) {
        fread(in, sizeof(short), process_count, inFile);
        webrtc_ns_process(pNs, in, out, process_count);
        fwrite(out, sizeof(short), process_count, outFile);
        frames += process_count;
    }

    webrtc_ns_destory(pNs);

    if (gIsWave) {
        WriteWaveHeader(outFile, 1, gRate, 16, frames);
    }

    free(in);
    free(out);

close_outFile:
    fclose(outFile);
close_inFile:
    fclose(inFile);
    return 0;
}

static void PrintHelp()
{
    printf("usage: aecm_test <args>\n");
    printf("args:\n");
    printf("  -r:               rate.                       (support 8000-48000), default: 16000\n");
    printf("  -i:               inFile.                     (support string), default: NULL\n");
    printf("  -e:               refFile.                    (support string), default: NULL\n");
    printf("  -o:               outFile.                    (support string), default: NULL\n");
    printf("  -v:               is wave file.               (support 0,1), default: 1\n");
    printf("  --mode:           mode.                       (support 0,1,2,3), default: 3\n");
}

enum LONG_OPTION {
    LONG_OPTION_MODE = 10000,
    LONG_OPTION_BUTT
};

int main(int argc, char *argv[])
{
    int c;
    int isExit = 0;

    while (1) {
        int option_index = 0;
        static struct option long_options[] = {
            {"mode",                required_argument,  0, LONG_OPTION_MODE},
            {0,                     0,                  0, 0 }
        };

        c = getopt_long(argc, argv, "r:i:e:o:v:h",
                 long_options, &option_index);
        if (c == -1)
            break;

        switch (c) {
        case 'r':
            gRate = atoi(optarg);
            break;
        case 'i':
            gInFileName = optarg;
            break;
        case 'e':
            gRefFileName = optarg;
            break;
        case 'o':
            gOutFileName = optarg;
            break;
        case 'v':
            gIsWave = atoi(optarg);
            break;
        case 'h':
            isExit = 1;
            break;
        case LONG_OPTION_MODE:
            gMode = atoi(optarg);
            printf("gMode: %d\n", gMode);
            break;
        default:
            isExit = 1;
            break;
        }
    }

    if (isExit) {
        PrintHelp();
        exit(0);
    }

    if (!gInFileName || !gOutFileName) {
        PrintHelp();
        exit(0);
    }

    Process();

    return 0;
}

