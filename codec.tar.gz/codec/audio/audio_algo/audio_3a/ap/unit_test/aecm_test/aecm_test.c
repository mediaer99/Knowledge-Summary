#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>

#include "user_wrappers/aecm_wrapper.h"
#include "user_wrappers/wave_parser.h"

#define SAMPLE_NUM      160

static unsigned int gRate = 16000;
static char *gInFileName = NULL;
static char *gRefFileName = NULL;
static char *gOutFileName = NULL;
static int gIsWave = 1;
static int gCngMode = 1;
static int16_t gEchoMode = 3;
static int16_t gMsInSndCardBuf = 10;

int Process()
{
    short in[SAMPLE_NUM];
    short ref[SAMPLE_NUM];
    short out[SAMPLE_NUM];

    FILE *inFile;
    FILE *refFile;
    FILE *outFile;
    inFile = fopen(gInFileName, "rb");
    if (!inFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gInFileName);
        return 1;
    }
    refFile = fopen(gRefFileName, "rb");
    if (!refFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gRefFileName);
        goto close_inFile;
    }
    outFile = fopen(gOutFileName, "wb");
    if (!outFile) {
        fprintf(stderr, "Unable to open file '%s'\n", gOutFileName);
        goto close_refFile;
    }

    if (gIsWave) {
        uint16_t in_num_channels;
        uint32_t in_sample_rate;
        uint16_t in_bits_per_sample;
        if (ParseWaveHeader(gInFileName, inFile, &in_num_channels, &in_sample_rate, &in_bits_per_sample)) {
            fprintf(stderr, "ParseWaveHeader '%s' error\n", gInFileName);
            goto close_outFile;
        }
        if (in_num_channels != 1 || in_bits_per_sample != 16) {
            fprintf(stderr, "'%s' format not support\n", gInFileName);
            goto close_outFile;
        }

        uint16_t ref_num_channels;
        uint32_t ref_sample_rate;
        uint16_t ref_bits_per_sample;
        if (ParseWaveHeader(gRefFileName, refFile, &ref_num_channels, &ref_sample_rate, &ref_bits_per_sample)) {
            fprintf(stderr, "ParseWaveHeader '%s' error\n", gRefFileName);
            goto close_outFile;
        }
        if (ref_num_channels != 1 || ref_bits_per_sample != 16) {
            fprintf(stderr, "'%s' format not support\n", gRefFileName);
            goto close_outFile;
        }

        LeaveWaveHeader(outFile);

        if (in_sample_rate != ref_sample_rate) {
            printf("in_sample_rate not match ref_sample_rate\n");
            goto close_outFile;
        }
        gRate = in_sample_rate;
    }

    void* pAecm = webrtc_aecm_create(gRate, gCngMode, gEchoMode);
    if (!pAecm) {
        goto close_outFile;
    }

    unsigned int frames = 0;
    while (!feof(inFile)) {
        fread(in, sizeof(short), SAMPLE_NUM, inFile);
        fread(ref, sizeof(short), SAMPLE_NUM, refFile);
        webrtc_aecm_process(pAecm, in, ref, out, SAMPLE_NUM, gMsInSndCardBuf);
        fwrite(out, sizeof(short), SAMPLE_NUM, outFile);
        frames += SAMPLE_NUM;
    }
   
    webrtc_aecm_destory(pAecm);

    if (gIsWave) {
        WriteWaveHeader(outFile, 1, gRate, 16, frames);
    }

close_outFile:
    fclose(outFile);
close_refFile:
    fclose(refFile);
close_inFile:
    fclose(inFile);
    return 0;
}

static void PrintHelp()
{
    printf("usage: aecm_test <args>\n");
    printf("args:\n");
    printf("  -r:               rate.                       (support 8000-48000), default: 16000\n");
    printf("  -i:               inFile.                     (support string), default: NULL\n");
    printf("  -e:               refFile.                    (support string), default: NULL\n");
    printf("  -o:               outFile.                    (support string), default: NULL\n");
    printf("  -v:               is wave file.               (support 0,1), default: 1\n");
    printf("  --cng-mode:       cng mode.                   (support 0,1), default: 1\n");
    printf("  --echo-mode:      echo mode.                  (support 0,1,2,3,4), default: 3\n");
    printf("  --ms:             gMsInSndCardBuf.            (support int), default: 10\n");
}

enum LONG_OPTION {
    LONG_OPTION_CNG_MODE = 10000,
    LONG_OPTION_ECHO_MODE,
    LONG_OPTION_MS,
    LONG_OPTION_BUTT
};

int main(int argc, char *argv[])
{
    int c;
    int isExit = 0;

    while (1) {
        int option_index = 0;
        static struct option long_options[] = {
            {"cng-mode",            required_argument,  0, LONG_OPTION_CNG_MODE},
            {"echo-mode",           required_argument,  0, LONG_OPTION_ECHO_MODE },
            {"ms",                  required_argument,  0, LONG_OPTION_MS },
            {0,                     0,                  0, 0 }
        };

        c = getopt_long(argc, argv, "r:i:e:o:v:h",
                 long_options, &option_index);
        if (c == -1)
            break;
        
        switch (c) {
        case 'r':
            gRate = atoi(optarg);
            break;
        case 'i':
            gInFileName = optarg;
            break;
        case 'e':
            gRefFileName = optarg;
            break;
        case 'o':
            gOutFileName = optarg;
            break;
        case 'v':
            gIsWave = atoi(optarg);
            break;
        case 'h':
            isExit = 1;
            break;
        case LONG_OPTION_CNG_MODE:
            gCngMode = atoi(optarg);
            printf("gCngMode: %d\n", gCngMode);
            break;
        case LONG_OPTION_ECHO_MODE:
            gEchoMode = atoi(optarg);
            printf("gEchoMode: %d\n", gEchoMode);
            break;
        case LONG_OPTION_MS:
            gMsInSndCardBuf = atoi(optarg);
            printf("gMsInSndCardBuf: %d\n", gMsInSndCardBuf);
            break;
        default:
            isExit = 1;
            break;
        }
    }

    if (isExit) {
        PrintHelp();
        exit(0);
    }

    if (!gInFileName || !gRefFileName || !gOutFileName) {
        PrintHelp();
        exit(0);
    }

    Process();

    return 0;
}

