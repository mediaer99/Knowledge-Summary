/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef HIGH_PASS_FILTER_WEBRTC_H_
#define HIGH_PASS_FILTER_WEBRTC_H_

#include <stddef.h>

#include "ap/include/typedefs.h"

#ifdef __cplusplus
extern "C" {
#endif

void* webrtc_hpf_create(int sample_rate);
int webrtc_hpf_process(void* pCtx, void *inFrame, size_t frame_samples);
int webrtc_hpf_destory(void* pCtx);

#ifdef __cplusplus
}
#endif
#endif  // HIGH_PASS_FILTER_WEBRTC_H_
