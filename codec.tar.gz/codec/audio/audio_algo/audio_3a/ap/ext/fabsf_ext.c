#include "math_ext.h"
#include "private_ext.h"

float fabsf_ext(float x)
{
	unsigned int ix;
	GET_FLOAT_WORD(ix,x);
	SET_FLOAT_WORD(x,ix&0x7fffffff);
        return x;
}
