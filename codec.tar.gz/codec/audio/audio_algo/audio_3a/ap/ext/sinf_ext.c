#include "math_ext.h"
#include "private_ext.h"

float sinf_ext(float x)
{
	float y[2],z=0.0;
	int n, ix;

	GET_FLOAT_WORD(ix,x);

    /* |x| ~< pi/4 */
	ix &= 0x7fffffff;
	if(ix <= 0x3f490fd8) return kernel_sinf_ext(x,z,0);

    /* sin(Inf or NaN) is NaN */
	else if (ix>=0x7f800000) {
	  //if (ix == 0x7f800000)
	   // __set_errno (EDOM);
	  return x-x;
	}

    /* argument reduction needed */
	else {
	    n = ieee754_rem_pio2f_ext(x,y);
	    switch(n&3) {
		case 0: return  kernel_sinf_ext(y[0],y[1],1);
		case 1: return  kernel_cosf_ext(y[0],y[1]);
		case 2: return -kernel_sinf_ext(y[0],y[1],1);
		default:
			return -kernel_cosf_ext(y[0],y[1]);
	    }
	}
}
