#ifndef _MATH_EXT_H_
#define _MATH_EXT_H_
float logf_ext(float x);
float sqrtf_ext(float x);
int kernel_rem_pio2f_ext(float *x, float *y, int e0, int nx, int prec, const int *ipio2);
float cosf_ext(float x);
float floorf_ext(float x);
float sinf_ext(float x);
int ieee754_rem_pio2f_ext(float x, float *y);
float fabsf_ext(float x);
float powf_ext(float x, float y);
float scalbnf_ext (float x, int n);
float copysignf_ext(float x, float y);
float kernel_cosf_ext(float x, float y);
float kernel_sinf_ext(float x, float y, int iy);
#endif /* _MATH_EXT_H_ */


