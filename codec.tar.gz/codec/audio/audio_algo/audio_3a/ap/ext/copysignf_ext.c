#include "math_ext.h"
#include "private_ext.h"

float copysignf_ext(float x, float y)
{
	unsigned int ix,iy;
	GET_FLOAT_WORD(ix,x);
	GET_FLOAT_WORD(iy,y);
	SET_FLOAT_WORD(x,(ix&0x7fffffff)|(iy&0x80000000));
        return x;
}
