/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "circle_queue.h"

CircleQueue *CreateCirQ(AX_U32 dataMaxLen)
{
    CircleQueue *q = (CircleQueue *)malloc(sizeof(CircleQueue));
    if (!q) {
        printf("Create queue no mem\n");
        return NULL;
    }
    q->data = malloc(sizeof(AX_VOID *) * dataMaxLen);
    if (!q->data) {
        printf("Create data no mem\n");
        free(q);
        return NULL;
    }
    q->dataMaxLen = dataMaxLen;
    q->front = -1;
    q->rear = -1;
    q->size = 0;
    return q;
}

void DestoryCirQ(CircleQueue *q)
{
    free(q->data);
    free(q);
}

int IsFullCirQ(CircleQueue *q)
{
    return (q->size == q->dataMaxLen);
}

int IsEmptyCirQ(CircleQueue *q)
{
    return (q->size == 0);
}

void *FrontCirQ(CircleQueue *q)
{
    if (IsEmptyCirQ(q)) {
        printf("empty queue\n");
        return NULL;
    }
    int front = q->front + 1;
    front %= q->dataMaxLen;
    return q->data[front];
}

void *BackCirQ(CircleQueue *q)
{
    if (IsEmptyCirQ(q)) {
        printf("empty queue\n");
        return NULL;
    }
    return q->data[q->rear];
}

void PushCirQ(CircleQueue *q, void *item)
{
    if (IsFullCirQ(q)) {
        printf("queue full\n");
        return;
    }
    q->rear++;
    q->rear %= q->dataMaxLen;
    q->size++;
    q->data[q->rear] = item;
}

void *PopCirQ(CircleQueue *q)
{
    if (IsEmptyCirQ(q)) {
        printf("empty queue\n");
        return NULL;
    }
    q->front++;
    q->front %= q->dataMaxLen; //0 1 2 3 4 5
    q->size--;
    return q->data[q->front];
}

void PrintCirQ(CircleQueue *q, PrintDataFunc func)
{
    if (IsEmptyCirQ(q)) {
        printf("empty queue\n");
        return;
    }
    printf("---------------------------------\n");
    printf("Print queue data:\n");
    int index = q->front;
    int i;
    for (i = 0; i < q->size; i++) {
        index++;
        index %= q->dataMaxLen;
        printf("%p ", q->data[index]);
        func(q->data[index]);
    }
    printf("\n---------------------------------\n");
}