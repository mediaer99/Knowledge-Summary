/**************************************************************************************************
 *
 * Copyright (c) 2019-2023 Axera Semiconductor (Shanghai) Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor (Shanghai) Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor (Shanghai) Co., Ltd.
 *
 **************************************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "opus.h"
#include "opus_types.h"
#include "opus_multistream.h"
#include "sc_opus.h"
#include "ax_aenc_log.h"
#include "ax_adec_log.h"


typedef struct {
    OpusEncoder *enc;
    int frame_size;
    int channels;
    opus_int32 sampling_rate;
    int max_payload_bytes;
    short *in;
    unsigned char *data;
    int toggle;
} ScOpusEncoder;

static AX_S32 ScOpusOpenEncoder(AX_VOID *pEncoderAttr, AX_VOID **ppEncoder)
{
    AX_AENC_OPUS_ENCODER_ATTR_T *pOpusEncoderAttr = pEncoderAttr;

    if (!pOpusEncoderAttr) {
        return AX_ERR_AENC_NULL_PTR;
    }

    int application = pOpusEncoderAttr->enApplication;
    if ((application <= AX_OPUS_APPLICATION_UNKNOWN) ||
        (application >= AX_OPUS_APPLICATION_BUTT)) {
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    opus_int32 sampling_rate = pOpusEncoderAttr->u32SamplingRate;
    if (sampling_rate != 8000 && sampling_rate != 12000
        && sampling_rate != 16000 && sampling_rate != 24000
        && sampling_rate != 48000) {
        AencLog(SYS_LOG_ERROR, "Supported sampling rates are 8000, 12000, "
                "16000, 24000 and 48000.\n");
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    int channels = pOpusEncoderAttr->s32Channels;
    if (channels < 1 || channels > 2) {
        AencLog(SYS_LOG_ERROR, "Opus_supports only 1 or 2 channels.\n");
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    opus_int32 bitrate_bps = pOpusEncoderAttr->s32BitrateBps;

    AX_F32 framesizeInMs = pOpusEncoderAttr->f32FramesizeInMs;
    if (framesizeInMs != 2.5 && framesizeInMs != 5
        && framesizeInMs != 10 && framesizeInMs != 20
        && framesizeInMs != 40 && framesizeInMs != 60
        && framesizeInMs != 80 && framesizeInMs != 100
        && framesizeInMs != 120) {
        AencLog(SYS_LOG_ERROR, "Unsupported frame size: %.1f ms. "
                "Supported are 2.5, 5, 10, 20, 40, 60, 80, 100, 120.\n",
                framesizeInMs);
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    int frame_size = (int)(sampling_rate * framesizeInMs / 1000.f);

    int bandwidth = OPUS_AUTO;

    ScOpusEncoder *pSoe = malloc(sizeof(ScOpusEncoder));
    if (!pSoe)
        return AX_ERR_AENC_NOMEM;

    memset(pSoe, 0, sizeof(ScOpusEncoder));
    pSoe->frame_size = frame_size;
    pSoe->channels = channels;
    pSoe->toggle = 0;
    pSoe->sampling_rate = sampling_rate;

    int err;
    int use_vbr = 1;
    int cvbr = 0;
    int complexity = 10;
    int use_inbandfec = 0;
    int forcechannels = OPUS_AUTO;
    int use_dtx = 0;
    int packet_loss_perc = 0;
    opus_int32 skip = 0;
    int variable_duration = OPUS_FRAMESIZE_ARG;
    const char *bandwidth_string = "auto bandwidth";
    int max_frame_size = 48000 * 2;
    pSoe->max_payload_bytes = SC_OPUS_MAX_PACKET;
    pSoe->enc = opus_encoder_create(sampling_rate, channels, application, &err);
    if (err != OPUS_OK) {
        AencLog(SYS_LOG_ERROR, "Cannot create encoder: %s\n", opus_strerror(err));
        goto err_free_pSoe;
    }
    opus_encoder_ctl(pSoe->enc, OPUS_SET_BITRATE(bitrate_bps));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_BANDWIDTH(bandwidth));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_VBR(use_vbr));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_VBR_CONSTRAINT(cvbr));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_COMPLEXITY(complexity));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_INBAND_FEC(use_inbandfec));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_FORCE_CHANNELS(forcechannels));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_DTX(use_dtx));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_PACKET_LOSS_PERC(packet_loss_perc));

    opus_encoder_ctl(pSoe->enc, OPUS_GET_LOOKAHEAD(&skip));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_LSB_DEPTH(16));
    opus_encoder_ctl(pSoe->enc, OPUS_SET_EXPERT_FRAME_DURATION(variable_duration));

    AencLog(SYS_LOG_INFO, "Encoding %ld Hz input at %.3f kb/s "
            "in %s with %d-sample frames.\n",
            (long)sampling_rate, bitrate_bps * 0.001,
            bandwidth_string, frame_size);

    pSoe->in = (short *)malloc(max_frame_size * channels * sizeof(short));
    if (!pSoe->in) {
        AencLog(SYS_LOG_ERROR, "Cannot alloc memory\n");
        goto err_encoder_destroy;
    }
    if (use_inbandfec) {
        pSoe->data = (unsigned char *)calloc(pSoe->max_payload_bytes, sizeof(unsigned char));
        if (!pSoe->data) {
            AencLog(SYS_LOG_ERROR, "Cannot alloc memory\n");
            goto err_free_in;
        }
    }

    *ppEncoder = pSoe;
    return AX_SUCCESS;

err_free_in:
    free(pSoe->in);
err_encoder_destroy:
    opus_encoder_destroy(pSoe->enc);
err_free_pSoe:
    free(pSoe);
    return AX_ERR_AENC_SYS_NOTREADY;
}

static AX_S32 ScOpusEncodeFrm(AX_VOID *pEncoder, const AX_AUDIO_FRAME_S *pstData,
                              AX_U8 *pu8Outbuf, AX_U32 *pu32OutLen)
{
    if (!pEncoder || !pstData || !pu8Outbuf || !pu32OutLen)
        return AX_ERR_AENC_NULL_PTR;

    ScOpusEncoder *pSoe = pEncoder;

    int i;
    int channels = pSoe->channels;
    unsigned char *fbytes = pstData->u64VirAddr;
    int curr_read = pstData->u32Len / (sizeof(short) * channels);
    for (i = 0; i < curr_read * channels; i++) {
        opus_int32 s;
        s = fbytes[2 * i + 1] << 8 | fbytes[2 * i];
        s = ((s & 0xFFFF) ^ 0x8000) - 0x8000;
        pSoe->in[i] = s;
    }

    if (curr_read != pSoe->frame_size) {
        AencLog(SYS_LOG_ERROR, "curr_read %d not equal to frame_size %d\n", curr_read, pSoe->frame_size);
    }
    if (*pu32OutLen < pSoe->max_payload_bytes) {
        AencLog(SYS_LOG_ERROR, "encode buffer %d is less than %d\n", *pu32OutLen, pSoe->max_payload_bytes);
    }

    int len = opus_encode(pSoe->enc, pSoe->in, pSoe->frame_size, pu8Outbuf, pSoe->max_payload_bytes);
    int nb_encoded = opus_packet_get_samples_per_frame(pu8Outbuf,
                     pSoe->sampling_rate) * opus_packet_get_nb_frames(pu8Outbuf, len);
    int remaining = pSoe->frame_size - nb_encoded;
    AencLog(SYS_LOG_DEBUG, "opus_encode len: %d, remaining: %d\n", len, remaining);
    if (len < 0) {
        AencLog(SYS_LOG_ERROR, "opus_encode() returned %d\n", len);
    }

    *pu32OutLen = len;
    return AX_SUCCESS;
}

static AX_S32 ScOpusCloseEncoder(AX_VOID *pEncoder)
{
    if (!pEncoder)
        return AX_ERR_AENC_NULL_PTR;

    ScOpusEncoder *pSoe = pEncoder;
    free(pSoe->in);
    opus_encoder_destroy(pSoe->enc);
    free(pSoe);
    return AX_SUCCESS;
}

AX_AENC_ENCODER_S gScOpusEncoder = {
    .enType = PT_OPUS,
    .u32MaxFrmLen = 100,
    .aszName = "OPUS",
    .pfnOpenEncoder = &ScOpusOpenEncoder,
    .pfnEncodeFrm = &ScOpusEncodeFrm,
    .pfnCloseEncoder = &ScOpusCloseEncoder,
};

typedef struct {
    OpusDecoder *dec;
    int channels;
    short *out;
} ScOpusDecoder;

AX_S32 ScOpusOpenDecoder(AX_VOID *pDecoderAttr, AX_VOID **ppDecoder)
{
    AX_ADEC_OPUS_DECODER_ATTR_T *pOpusDecoderAttr = pDecoderAttr;

    if (!pOpusDecoderAttr) {
        return AX_ERR_ADEC_NULL_PTR;
    }

    opus_int32 sampling_rate = pOpusDecoderAttr->u32SamplingRate;
    if (sampling_rate != 8000 && sampling_rate != 12000
        && sampling_rate != 16000 && sampling_rate != 24000
        && sampling_rate != 48000) {
        AdecLog(SYS_LOG_ERROR, "Supported sampling rates are 8000, 12000, "
                "16000, 24000 and 48000.\n");
        return AX_ERR_ADEC_NOT_SUPPORT;
    }

    int channels = pOpusDecoderAttr->s32Channels;
    if (channels < 1 || channels > 2) {
        AdecLog(SYS_LOG_ERROR, "Opus_supports only 1 or 2 channels.\n");
        return AX_ERR_ADEC_NOT_SUPPORT;
    }

    ScOpusDecoder *pSod = malloc(sizeof(ScOpusDecoder));
    if (!pSod)
        return AX_ERR_ADEC_NOMEM;

    memset(pSod, 0, sizeof(ScOpusDecoder));
    pSod->channels = channels;

    int err;
    pSod->dec = opus_decoder_create(sampling_rate, channels, &err);
    if (err != OPUS_OK) {
        AdecLog(SYS_LOG_ERROR, "Cannot create decoder: %s\n", opus_strerror(err));
        goto err_free_pSod;
    }

    int max_frame_size = 48000 * 2;
    pSod->out = (short *)malloc(max_frame_size * channels * sizeof(short));
    if (!pSod->out) {
        AdecLog(SYS_LOG_ERROR, "malloc error\n");
        goto err_decoder_destroy;
    }

    *ppDecoder = pSod;
    return AX_SUCCESS;

err_decoder_destroy:
    opus_decoder_destroy(pSod->dec);
err_free_pSod:
    free(pSod);
    return AX_ERR_AENC_SYS_NOTREADY;
}

AX_S32 ScOpusDecodeFrm(AX_VOID *pDecoder, AX_U8 **pu8Inbuf, AX_S32 *ps32LeftByte,
                       AX_U16 *pu16Outbuf, AX_U32 *pu32OutLen, AX_U32 *pu32Chns)
{
    ScOpusDecoder *pSod = (ScOpusDecoder *)pDecoder;

    unsigned char *fbytes = (unsigned char *)pu16Outbuf;
    opus_int32 output_samples = *pu32OutLen / (2 * sizeof(short));
    output_samples = opus_decode(pSod->dec, *pu8Inbuf, *ps32LeftByte, pSod->out, output_samples, 0);
    if (output_samples > 0) {
        int i;
        for (i = 0; i < output_samples * pSod->channels; i++) {
            short s;
            s = pSod->out[i];
            fbytes[2 * i] = s & 0xFF;
            fbytes[2 * i + 1] = (s >> 8) & 0xFF;
        }
    } else {
        AdecLog(SYS_LOG_ERROR, "error decoding frame: %s\n",
                opus_strerror(output_samples));
        return AX_ERR_ADEC_DECODER_ERR;
    }

    *pu32OutLen = sizeof(short) * pSod->channels * output_samples;
    *pu32Chns = pSod->channels;
    return AX_SUCCESS;
}

AX_S32 ScOpusGetFrmInfo(AX_VOID *pDecoder, AX_VOID *pInfo)
{
    AX_AUDIO_FRAME_S *data = (AX_AUDIO_FRAME_S *)pInfo;
    data->enBitwidth = AX_AUDIO_BIT_WIDTH_16;
    return AX_SUCCESS;
}

AX_S32 ScOpusCloseDecoder(AX_VOID *pDecoder)
{
    ScOpusDecoder *pSod = (ScOpusDecoder *)pDecoder;
    opus_decoder_destroy(pSod->dec);
    free(pSod->out);
    free(pSod);
    return AX_SUCCESS;
}

AX_S32 ScOpusResetDecoder(AX_VOID *pDecoder)
{
    return AX_SUCCESS;
}

AX_ADEC_DECODER_S gScOpusDecoder = {
    .enType = PT_OPUS,
    .aszName = "OPUS decoder",
    .pfnOpenDecoder = &ScOpusOpenDecoder,
    .pfnDecodeFrm = &ScOpusDecodeFrm,
    .pfnGetFrmInfo = &ScOpusGetFrmInfo,
    .pfnCloseDecoder = &ScOpusCloseDecoder,
    .pfnResetDecoder = &ScOpusResetDecoder,
};
