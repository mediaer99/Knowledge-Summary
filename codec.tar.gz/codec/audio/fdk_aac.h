/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#ifndef _AX_FDK_AAC_HAL_H_
#define _AX_FDK_AAC_HAL_H_

#include "ax_base_type.h"
#include "ax_global_type.h"
#include "ax_aenc_api.h"
#include "ax_adec_api.h"

#ifdef __cplusplus
extern "C" {
#endif

extern AX_AENC_ENCODER_S gFdkAacEncoder;
extern AX_ADEC_DECODER_S gFdkAacDecoder;

#ifdef __cplusplus
}
#endif

#endif
