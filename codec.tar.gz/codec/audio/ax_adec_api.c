/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include "ax_adec_api.h"
#include "g711.h"
#include "fdk_aac.h"
#include "lpcm.h"
#include "sc_opus.h"
#include "circle_queue.h"
#include "ax_adec_log.h"
#include "ax_audio_proc.h"

#define AX_ADEC_MAX_DECODER_NUM         20
#define AX_ADEC_FRAME_SIZE_G711         (1024 * 8)
#define AX_ADEC_FRAME_SIZE_AAC          (1024 * 32)

static AX_AUDIO_FRAME_S* CreateAudioFrame(AX_U64 u64TimeStamp, AX_U32 u32Seq, AX_BOOL bEof, AX_U32 u32Len)
{
    AX_AUDIO_FRAME_S* data = malloc(sizeof(AX_AUDIO_FRAME_S));
    if (!data) {
        return NULL;
    }

    data->u64VirAddr = malloc(sizeof(AX_U8) * u32Len);
    if (!data->u64VirAddr) {
        free(data);
        return NULL;
    }
    data->u64TimeStamp = u64TimeStamp;
    data->u32Seq = u32Seq;
    data->u32Len = u32Len;
    data->bEof = bEof;
    return data;
}

static void DestoryAudioFrame(AX_AUDIO_FRAME_S* data)
{
    free(data->u64VirAddr);
    free(data);
}

typedef struct {
    AX_PAYLOAD_TYPE_E enType;
    const AX_ADEC_DECODER_S *pAdecDecoder;
    AX_U32 u32BufSize;
    AX_VOID *pDecoder;
    CircleQueue *pQueue;
    pthread_mutex_t queueMutex;
    pthread_cond_t queueCond;

    AX_U64 u64SndStrm;
    AX_U64 u64DecOk;
    AX_U64 u64BufFull;
    AX_U64 u64GetFrm;
    AX_U64 u64RlsFrm;
} AxAdecChn;

static const AX_ADEC_DECODER_S *gAdecDecoders[AX_ADEC_MAX_DECODER_NUM] =
    {&gG711ADecoder, &gG711UDecoder, &gFdkAacDecoder, &gLpcmDecoder, &gScOpusDecoder, };
static AxAdecChn *gChns[AX_ADEC_MAX_CHN_NUM];
static int gAdecInitFlag = 0;
static int gAdecProcFd = -1;
static char *gAdecDevicePath = "/dev/adec";
static pthread_t gAdecProcThreadTid = 0;
static volatile int gAdecProcThreadRun = 0;

static void AdecProcFormatMsg(char *msg, size_t msgMaxLen)
{
    AX_U32 i;

    snprintf(msg,
             msgMaxLen,
             "-------- ADEC CHN ATTR ------------------------\n"
             "%-16s%-16s%-16s\n", "ChnId", "PlType", "BufSize");
    for (i = 0; i < AX_ADEC_MAX_CHN_NUM; i++) {
        if (gChns[i]) {
            snprintf(msg + strlen(msg),
                     msgMaxLen - strlen(msg),
                     "%-16u%-16s%-16u\n",
                     i,
                     gChns[i]->pAdecDecoder->aszName,
                     gChns[i]->u32BufSize);
        }
    }

    snprintf(msg + strlen(msg),
             msgMaxLen - strlen(msg),
             "-------- ADEC CHN STATUS ------------------------\n"
             "%-16s%-16s%-16s%-16s%-16s%-16s\n", "ChnId", "SndStrm", "DecOk", "BufFull", "GetFrm", "RlsFrm");
    for (i = 0; i < AX_ADEC_MAX_CHN_NUM; i++) {
        if (gChns[i]) {
            snprintf(msg + strlen(msg),
                     msgMaxLen - strlen(msg),
                     "%-16u%-16llu%-16llu%-16llu%-16llu%-16llu\n",
                     i,
                     gChns[i]->u64SndStrm,
                     gChns[i]->u64DecOk,
                     gChns[i]->u64BufFull,
                     gChns[i]->u64GetFrm,
                     gChns[i]->u64RlsFrm);
        }
    }
}

static void *AdecProcThread(void *args)
{
    char msg[PROC_USR_MSG_LEN];
    while (gAdecProcThreadRun) {
        if (ioctl(gAdecProcFd, AUDIOPROC_WAIT, NULL)) {
            AdecLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_WAIT failed\n");
            continue;
        }

        if (!gAdecProcThreadRun)
            break;

        AdecProcFormatMsg(msg, PROC_USR_MSG_LEN);
        if (ioctl(gAdecProcFd, AUDIOPROC_DONE, msg)) {
            AdecLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_DONE failed\n");
        }
    }

    return NULL;
}

static void PrintData(void *data)
{
    AX_AUDIO_FRAME_S* frame = data;
    printf("[%p, %u] ", frame->u64VirAddr, frame->u32Len);
}

AX_S32 AX_ADEC_Init()
{
    if (!gAdecInitFlag) {
        AdecLogInit(SYS_LOG_WARN, SYS_LOG_TARGET_SYSLOG);

        gAdecProcFd = open(gAdecDevicePath, O_RDWR);
        if (gAdecProcFd == -1) {
            AdecLog(SYS_LOG_ERROR, "failed to open %s, errno: %d\n", gAdecDevicePath, errno);
            return AX_ERR_ADEC_SYS_NOTREADY;
        }

        gAdecProcThreadRun = 1;
        if (pthread_create(&gAdecProcThreadTid, NULL, AdecProcThread, (void *)NULL) != 0) {
            close(gAdecProcFd);
            AdecLog(SYS_LOG_ERROR, "Create AdecProcThread failed\n");
            return AX_ERR_ADEC_SYS_NOTREADY;
        }

        gAdecInitFlag = 1;
    }

    return AX_SUCCESS;
}

AX_S32 AX_ADEC_DeInit()
{
    if (gAdecInitFlag) {
        for (int i = 0; i < AX_ADEC_MAX_CHN_NUM; i++) {
            if (gChns[i]) {
                AdecLog(SYS_LOG_ERROR, "channel %d exist, destory it first\n", i);
                return AX_ERR_ADEC_NOT_PERM;
            }
        }

        gAdecProcThreadRun = 0;
        if (ioctl(gAdecProcFd, AUDIOPROC_EXIT, NULL)) {
            AdecLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_EXIT failed\n");
        }
        pthread_join(gAdecProcThreadTid, NULL);
        close(gAdecProcFd);
        gAdecInitFlag = 0;
    }
    return AX_SUCCESS;
}

AX_S32 AX_ADEC_CreateChn(ADEC_CHN adChn, const AX_ADEC_CHN_ATTR_S *pstAttr)
{
    AX_S32 ret = AX_SUCCESS;

    if (!gAdecInitFlag)
        return AX_ERR_ADEC_SYS_NOTREADY;

    if (adChn < 0 || adChn >= AX_ADEC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!pstAttr)
        return AX_ERR_ADEC_NULL_PTR;

    if (gChns[adChn])
        return AX_ERR_ADEC_EXIST;

    gChns[adChn] = malloc(sizeof(AxAdecChn));
    if (!gChns[adChn])
        return AX_ERR_ADEC_NOMEM;

    gChns[adChn]->enType = pstAttr->enType;
    int i = 0;
    for (i = 0; i < AX_ADEC_MAX_DECODER_NUM; i++) {
        if (gAdecDecoders[i] && gAdecDecoders[i]->enType == pstAttr->enType)
            break;
    }
    if (i == AX_ADEC_MAX_DECODER_NUM) {
        free(gChns[adChn]);
        gChns[adChn] = NULL;
        return AX_ERR_ADEC_NOT_SUPPORT;
    }

    gChns[adChn]->pAdecDecoder = gAdecDecoders[i];
    gChns[adChn]->u32BufSize = pstAttr->u32BufSize;

    // open decoder
    if ((ret = gChns[adChn]->pAdecDecoder->pfnOpenDecoder(pstAttr->pValue, &gChns[adChn]->pDecoder)) != AX_SUCCESS) {
        free(gChns[adChn]);
        gChns[adChn] = NULL;
        return ret;
    }

    gChns[adChn]->pQueue = CreateCirQ(gChns[adChn]->u32BufSize);
    if (!gChns[adChn]->pQueue) {
        gChns[adChn]->pAdecDecoder->pfnCloseDecoder(gChns[adChn]->pDecoder);
        free(gChns[adChn]);
        gChns[adChn] = NULL;
        return AX_ERR_ADEC_NOBUF;
    }

    pthread_mutex_init(&gChns[adChn]->queueMutex, NULL);
    pthread_cond_init(&gChns[adChn]->queueCond, NULL);

    gChns[adChn]->u64SndStrm = 0;
    gChns[adChn]->u64DecOk = 0;
    gChns[adChn]->u64BufFull = 0;
    gChns[adChn]->u64GetFrm = 0;
    gChns[adChn]->u64RlsFrm = 0;

    AdecLog(SYS_LOG_INFO, "AX_ADEC_CreateChn succeed, adChn: %d\n", adChn);
    return AX_SUCCESS;
}


AX_S32 AX_ADEC_DestroyChn(ADEC_CHN adChn)
{
    AX_S32 ret = AX_SUCCESS;

    if (!gAdecInitFlag)
        return AX_ERR_ADEC_SYS_NOTREADY;

    if (adChn < 0 || adChn >= AX_ADEC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!gChns[adChn]) {
        return AX_SUCCESS;
    }

    // close decoder
    if ((ret = gChns[adChn]->pAdecDecoder->pfnCloseDecoder(gChns[adChn]->pDecoder)) != AX_SUCCESS) {
        AdecLog(SYS_LOG_WARN, "Close decoder error: %d\n", ret);
    }

    pthread_mutex_destroy(&gChns[adChn]->queueMutex);
    pthread_cond_destroy(&gChns[adChn]->queueCond);

    DestoryCirQ(gChns[adChn]->pQueue);

    free(gChns[adChn]);
    gChns[adChn] = NULL;

    AdecLog(SYS_LOG_INFO, "AX_ADEC_DestroyChn succeed, adChn: %d\n", adChn);
    return AX_SUCCESS;
}

AX_S32 AX_ADEC_SendStream(ADEC_CHN adChn, const AX_AUDIO_STREAM_S *pstStream, AX_BOOL bBlock)
{
    AX_S32 ret = AX_SUCCESS;

    if (adChn < 0 || adChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!pstStream)
        return AX_ERR_AENC_NULL_PTR;

    if (!gChns[adChn]) {
        return AX_ERR_AENC_UNEXIST;
    }

    gChns[adChn]->u64SndStrm++;
    pthread_mutex_lock(&gChns[adChn]->queueMutex);
    if (bBlock == AX_TRUE) {
        while (IsFullCirQ(gChns[adChn]->pQueue)) {
            pthread_cond_wait(&gChns[adChn]->queueCond, &gChns[adChn]->queueMutex);
            //printf("%s: aeChn: %d, IsEmptyCirQ: %d\n", __func__, aeChn, IsEmptyCirQ(gChns[aeChn]->pQueue));
        }
    } else {
        if (IsFullCirQ(gChns[adChn]->pQueue)) {
            gChns[adChn]->u64BufFull++;
            pthread_mutex_unlock(&gChns[adChn]->queueMutex);
            return AX_ERR_AENC_BUF_FULL;
        }
    }

    AX_U32 frameLen;
    switch (gChns[adChn]->enType) {
    case PT_AAC:
        frameLen = AX_ADEC_FRAME_SIZE_AAC;
        break;
    case PT_OPUS:
        frameLen = 48000 * 2 * 2 * sizeof(short);
        break;
    default:
        frameLen = AX_ADEC_FRAME_SIZE_G711;
        break;
    }
    AX_AUDIO_FRAME_S *data = CreateAudioFrame(pstStream->u64TimeStamp, pstStream->u32Seq, pstStream->bEof, frameLen);
    if (!data) {
        pthread_mutex_unlock(&gChns[adChn]->queueMutex);
        return AX_ERR_AENC_NOMEM;
    }
    if (pstStream->bEof == AX_FALSE) {
        AX_U8 *pu8Inbuf = pstStream->pStream;
        AX_S32 ps32LeftByte = pstStream->u32Len;
        AX_U32 pu32Chns;
        ret = gChns[adChn]->pAdecDecoder->pfnDecodeFrm(gChns[adChn]->pDecoder, &pu8Inbuf, &ps32LeftByte,
                   (AX_U16 *)data->u64VirAddr, &data->u32Len, &pu32Chns);
        if ((ret != AX_SUCCESS) || (data->u32Len == 0)) {
            DestoryAudioFrame(data);
            pthread_mutex_unlock(&gChns[adChn]->queueMutex);
            return ret;
        }

        data->enSoundmode = (pu32Chns == 2 ? AX_AUDIO_SOUND_MODE_STEREO : AX_AUDIO_SOUND_MODE_MONO);
        ret = gChns[adChn]->pAdecDecoder->pfnGetFrmInfo(gChns[adChn]->pDecoder, data);
        if (ret != AX_SUCCESS) {
            DestoryAudioFrame(data);
            pthread_mutex_unlock(&gChns[adChn]->queueMutex);
            return ret;
        }
    }

    gChns[adChn]->u64DecOk++;
    PushCirQ(gChns[adChn]->pQueue, data);
    //printf("%s, data: %p, data->u64VirAddr: %p, data->u32Seq: %u, data->u32Len: %u\n", __func__, data, data->u64VirAddr, data->u32Seq, data->u32Len);
    //PrintCirQ(gChns[adChn]->pQueue, &PrintData);
    pthread_cond_signal(&gChns[adChn]->queueCond);
    pthread_mutex_unlock(&gChns[adChn]->queueMutex);

    return AX_SUCCESS;
}

AX_S32 AX_ADEC_ClearChnBuf(ADEC_CHN adChn)
{
    if (adChn < 0 || adChn >= AX_ADEC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!gChns[adChn])
        return AX_ERR_ADEC_UNEXIST;

    pthread_mutex_lock(&gChns[adChn]->queueMutex);
    while (!IsEmptyCirQ(gChns[adChn]->pQueue)) {
        AX_AUDIO_FRAME_S *data = PopCirQ(gChns[adChn]->pQueue);
        DestoryAudioFrame(data);
    }
    pthread_cond_signal(&gChns[adChn]->queueCond);
    pthread_mutex_unlock(&gChns[adChn]->queueMutex);

    return AX_SUCCESS;
}

AX_S32 AX_ADEC_GetFrame(ADEC_CHN adChn, AX_AUDIO_FRAME_S *pstFrmInfo, AX_BOOL bBlock)
{
    if (adChn < 0 || adChn >= AX_ADEC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!pstFrmInfo)
        return AX_ERR_ADEC_NULL_PTR;

    if (!gChns[adChn]) {
        return AX_ERR_ADEC_UNEXIST;
    }

    pthread_mutex_lock(&gChns[adChn]->queueMutex);
    if (bBlock == AX_TRUE) {
        while (IsEmptyCirQ(gChns[adChn]->pQueue)) {
            pthread_cond_wait(&gChns[adChn]->queueCond, &gChns[adChn]->queueMutex);
            //printf("%s: aeChn: %d, IsEmptyCirQ: %d\n", __func__, aeChn, IsEmptyCirQ(gChns[aeChn]->pQueue));
        }
    } else {
        if (IsEmptyCirQ(gChns[adChn]->pQueue)) {
            pthread_mutex_unlock(&gChns[adChn]->queueMutex);
            return AX_ERR_ADEC_BUF_EMPTY;
        }
    }

    AX_AUDIO_FRAME_S *data = FrontCirQ(gChns[adChn]->pQueue);
    //printf("AX_ADEC_GetFrame, data: %p\n", data);

    if (data->bEof == AX_TRUE) {
        AX_AUDIO_FRAME_S *endData = PopCirQ(gChns[adChn]->pQueue);
        DestoryAudioFrame(endData);
        pthread_mutex_unlock(&gChns[adChn]->queueMutex);
        return AX_ERR_ADEC_END_OF_STREAM;
    }
    memcpy(pstFrmInfo, data, sizeof(*pstFrmInfo));
    pthread_mutex_unlock(&gChns[adChn]->queueMutex);

    gChns[adChn]->u64GetFrm++;
    return AX_SUCCESS;
}

AX_S32 AX_ADEC_ReleaseFrame(ADEC_CHN adChn, const AX_AUDIO_FRAME_S *pstFrmInfo)
{
    if (adChn < 0 || adChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!pstFrmInfo)
        return AX_ERR_ADEC_NULL_PTR;

    if (!gChns[adChn])
        return AX_ERR_ADEC_UNEXIST;

    pthread_mutex_lock(&gChns[adChn]->queueMutex);
    AX_AUDIO_FRAME_S *frontdata = FrontCirQ(gChns[adChn]->pQueue);
    if ((frontdata->u64VirAddr != pstFrmInfo->u64VirAddr) || (frontdata->u32Len != pstFrmInfo->u32Len)) {
        AdecLog(SYS_LOG_DEBUG, "%s, frontdata->u64VirAddr[%p] pstFrmInfo->u64VirAddr[%p] not match"
            " OR frontdata->u32Len[%u] pstFrmInfo->u32Len[%u] not match\n",
            __func__,
            frontdata->u64VirAddr,
            pstFrmInfo->u64VirAddr,
            frontdata->u32Len,
            pstFrmInfo->u32Len);
        pthread_mutex_unlock(&gChns[adChn]->queueMutex);
        return AX_ERR_ADEC_NOT_PERM;
    }
    AX_AUDIO_FRAME_S *data = PopCirQ(gChns[adChn]->pQueue);
    //printf("%s, data: %p\n", __func__, data);
    DestoryAudioFrame(data);
    pthread_cond_signal(&gChns[adChn]->queueCond);
    pthread_mutex_unlock(&gChns[adChn]->queueMutex);
    gChns[adChn]->u64RlsFrm++;

    return AX_SUCCESS;
}

AX_S32 AX_ADEC_SendEndOfStream(ADEC_CHN adChn, AX_BOOL bInstant)
{
    if (adChn < 0 || adChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_ADEC_INVALID_CHNID;

    if (!gChns[adChn])
        return AX_ERR_ADEC_UNEXIST;

    if (bInstant == AX_TRUE) {
        AX_S32 ret = AX_ADEC_ClearChnBuf(adChn);
        if (ret != AX_SUCCESS) {
            AdecLog(SYS_LOG_DEBUG, "AX_ADEC_ClearChnBuf error: %x\n", ret);
        }
    }

    AX_AUDIO_STREAM_S stStream;
    memset(&stStream, 0, sizeof(stStream));
    if(gChns[adChn]->enType == PT_AAC){
        AX_U8 data[13]={0xff, 0xf9, 0x6c, 0x40, 0x01, 0xbf, 0xfc, 0x00, 0xc8, 0x83, 0xfc, 0x08, 0xe0};
        stStream.pStream = (AX_U8 *)data;
        stStream.u64PhyAddr = 0;
        stStream.u32Len = 13;
        stStream.u32Seq = 0;
        stStream.bEof = AX_FALSE;

        AX_ADEC_SendStream(adChn, &stStream, AX_TRUE);
        AX_ADEC_SendStream(adChn, &stStream, AX_TRUE);
    }
    stStream.bEof = AX_TRUE;
    return AX_ADEC_SendStream(adChn, &stStream, AX_TRUE);
}

AX_S32 AX_ADEC_RegisterDecoder(AX_S32 *ps32Handle, const AX_ADEC_DECODER_S *pstDecoder)
{
    if (!ps32Handle || !pstDecoder)
        return AX_ERR_ADEC_NULL_PTR;

    // check if already registered
    int i = 0;
    for (i = 0; i < AX_ADEC_MAX_DECODER_NUM; i++) {
        if (gAdecDecoders[i] && gAdecDecoders[i]->enType == pstDecoder->enType)
            return AX_ERR_ADEC_NOT_PERM;
    }

    // find an empty place
    for (i = 0; i < AX_ADEC_MAX_DECODER_NUM; i++) {
        if (!gAdecDecoders[i])
            break;
    }

    if (i == AX_ADEC_MAX_DECODER_NUM) {
        // array full
        return AX_ERR_ADEC_NOT_PERM;
    }

    *ps32Handle = i;
    gAdecDecoders[i] = pstDecoder;

    return AX_SUCCESS;
}

AX_S32 AX_ADEC_UnRegisterDecoder(AX_S32 s32Handle)
{
    if (s32Handle < 0 || s32Handle >= AX_ADEC_MAX_DECODER_NUM)
        return AX_ERR_ADEC_NOT_PERM;

    if (!gAdecDecoders[s32Handle])
        return AX_ERR_ADEC_NOT_PERM;

    // check whether this encoder is using
    int i = 0;
    for (i = 0; i < AX_ADEC_MAX_CHN_NUM; i++) {
        if (gChns[i] && (gChns[i]->pDecoder == gAdecDecoders[s32Handle]))
            return AX_ERR_ADEC_NOT_PERM;
    }

    gAdecDecoders[s32Handle] = NULL;
    return AX_SUCCESS;
}
