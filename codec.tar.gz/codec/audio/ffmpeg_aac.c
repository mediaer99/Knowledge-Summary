/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <stdio.h>

#include "libavformat/avformat.h"
#include "libavformat/avio.h"

#include "libavcodec/avcodec.h"

#include "libavutil/audio_fifo.h"
#include "libavutil/avassert.h"
#include "libavutil/avstring.h"
#include "libavutil/frame.h"
#include "libavutil/opt.h"

#include "libswresample/swresample.h"

#include "ffmpeg_aac.h"

/* The output bit rate in bit/s */
#define OUTPUT_BIT_RATE 96000
/* The number of output channels */
#define OUTPUT_CHANNELS 2

typedef struct {
    AVCodecContext *pCodecCtx;
    AVFrame *pFrame;
    SwrContext *swrCtx;
    uint8_t **convert_data;
    uint8_t *frameBuf;
    AVPacket pkt;
    int i_frame;
    // adts header config
    char aac_adts_header[7];
    int chanCfg;
} FfmpegAacEncoder;

static int init_aac_header(FfmpegAacEncoder *pFae)
{
    int profile = 2;   //AAC LC
    int freqIdx = 4;   //44100HZ
    switch (pFae->pCodecCtx->sample_rate) {
    case 96000:
        freqIdx = 0x0;
        break;
    case 88200:
        freqIdx = 0x1;
        break;
    case 64000:
        freqIdx = 0x2;
        break;
    case 48000:
        freqIdx = 0x3;
        break;
    case 44100:
        freqIdx = 0x4;
        break;
    case 32000:
        freqIdx = 0x5;
        break;
    case 24000:
        freqIdx = 0x6;
        break;
    case 22050:
        freqIdx = 0x7;
        break;
    case 16000:
        freqIdx = 0x8;
        break;
    case 12000:
        freqIdx = 0x9;
        break;
    case 11025:
        freqIdx = 0xa;
        break;
    case 8000:
        freqIdx = 0xb;
        break;
    case 7350:
        freqIdx = 0xc;
        break;
    default:
        printf("init_aac_header: unsupport sample_rate: %d\n", pFae->pCodecCtx->sample_rate);
        return -1;
    }

    pFae->chanCfg = pFae->pCodecCtx->channels;

    pFae->aac_adts_header[0] = (char)0xFF;      // 11111111     = syncword
    pFae->aac_adts_header[1] = (char)0xF1;      // 1111 1 00 1  = syncword MPEG-2 Layer CRC
    pFae->aac_adts_header[2] = (char)(((profile - 1) << 6) + (freqIdx << 2) + (pFae->chanCfg >> 2));
    pFae->aac_adts_header[6] = (char)0xFC;

    return 0;
}

static int write_aac_header(FfmpegAacEncoder *pFae, AVPacket *pkt)
{
    pFae->aac_adts_header[3] = (char)(((pFae->chanCfg & 3) << 6) + ((7 + pkt->size) >> 11));
    pFae->aac_adts_header[4] = (char)(((7 + pkt->size) & 0x7FF) >> 3);
    pFae->aac_adts_header[5] = (char)((((7 + pkt->size) & 7) << 5) + 0x1F);

    return 0;
}

static AX_S32 FfmpegAacOpenEncoder(AX_VOID *pEncoderAttr, AX_VOID **ppEncoder)
{
    AVCodecContext *pCodecCtx = NULL;
    AVCodec *pCodec = NULL;
    AVFrame *pFrame = NULL;
    int error;
    AX_AENC_AAC_ENCODER_ATTR_S *pAacEncoderAttr = pEncoderAttr;

    if (!pAacEncoderAttr) {
        return AX_ERR_AENC_NULL_PTR;
    }

    FfmpegAacEncoder *pFae = malloc(sizeof(FfmpegAacEncoder));
    if (!pFae)
        return AX_ERR_AENC_NOMEM;

    /* Find the encoder to be used by its name. */
    if (!(pCodec = avcodec_find_encoder(AV_CODEC_ID_AAC))) {
        fprintf(stderr, "Could not find an AAC encoder.\n");
        free(pFae);
        return AVERROR_EXIT;
    }

    pCodecCtx = avcodec_alloc_context3(pCodec);
    if (!pCodecCtx) {
        fprintf(stderr, "Could not allocate an encoding context\n");
        free(pFae);
        error = AVERROR(ENOMEM);
        return error;
    }

    /* Set the basic encoder parameters.
     * The input file's sample rate is used to avoid a sample rate conversion. */
    pCodecCtx->codec_type = AVMEDIA_TYPE_AUDIO;
    pCodecCtx->sample_fmt = AV_SAMPLE_FMT_FLTP;
    pCodecCtx->sample_rate = pAacEncoderAttr->u32SampleRate;
    pCodecCtx->channel_layout = AV_CH_LAYOUT_STEREO;
    pCodecCtx->channels = av_get_channel_layout_nb_channels(pCodecCtx->channel_layout);
    pCodecCtx->bit_rate = pAacEncoderAttr->u32BitRate;

    /* Allow the use of the experimental AAC encoder. */
    //pCodecCtx->strict_std_compliance = FF_COMPLIANCE_EXPERIMENTAL;

    /* Open the encoder for the audio stream to use it later. */
    if ((error = avcodec_open2(pCodecCtx, pCodec, NULL)) < 0) {
        fprintf(stderr, "Could not open output codec (error '%s')\n",
                av_err2str(error));
        avcodec_free_context(&pCodecCtx);
        free(pFae);
        return error;
    }

    // alloc frame to store raw audio data
    pFrame = av_frame_alloc();
    if (!pFrame) {
        printf("can't alloc frame\n");
        avcodec_free_context(&pCodecCtx);
        free(pFae);
        return AX_ERR_AENC_NOMEM;
    }

    pFrame->nb_samples = pCodecCtx->frame_size;
    pFrame->format = pCodecCtx->sample_fmt;
    pFrame->channels = 2;

    // PCM resample
    pFae->swrCtx = swr_alloc();
    swr_alloc_set_opts(pFae->swrCtx, av_get_default_channel_layout(pCodecCtx->channels), pCodecCtx->sample_fmt,
                       pCodecCtx->sample_rate, av_get_default_channel_layout(pFrame->channels), AV_SAMPLE_FMT_S16,
                       pAacEncoderAttr->u32SampleRate, 0, NULL);
    swr_init(pFae->swrCtx);

    // alloc space
    pFae->convert_data = (uint8_t **) calloc(pCodecCtx->channels, sizeof(*(pFae->convert_data)));
    av_samples_alloc(pFae->convert_data, NULL, pCodecCtx->channels, pCodecCtx->frame_size, pCodecCtx->sample_fmt, 0);

    int size = av_samples_get_buffer_size(NULL, pCodecCtx->channels, pCodecCtx->frame_size, pCodecCtx->sample_fmt, 1);
    //printf("av_samples_get_buffer_size: %d\n", size);
    pFae->frameBuf = (uint8_t *) av_malloc(size);
    avcodec_fill_audio_frame(pFrame, pCodecCtx->channels, pCodecCtx->sample_fmt, (const uint8_t *) pFae->frameBuf, size, 1);

    // init packet
    av_init_packet(&pFae->pkt);
    pFae->pkt.data = NULL;
    pFae->pkt.size = 0;
    pFae->i_frame = 0;

    pFae->pCodecCtx = pCodecCtx;
    pFae->pFrame = pFrame;
    *ppEncoder = pFae;

    init_aac_header(pFae);

    return AX_SUCCESS;
}

static AX_S32 FfmpegAacEncodeFrm(AX_VOID *pEncoder, const AX_AUDIO_FRAME_S *pstData,
                                 AX_U8 *pu8Outbuf, AX_U32 *pu32OutLen)
{
    if (!pEncoder || !pstData || !pu8Outbuf || !pu32OutLen)
        return AX_ERR_AENC_NULL_PTR;

    FfmpegAacEncoder *pFae = pEncoder;
#if 0
    int ret = avcodec_fill_audio_frame(pFae->pFrame, pFae->pCodecCtx->channels, pFae->pCodecCtx->sample_fmt,
                                       (const uint8_t *) pstData->u64VirAddr, pstData->u32Len, 1);
    if (ret < 0)
        printf("avcodec_fill_audio_frame error: ret:%d\n", ret);
#endif
    //memcpy(pFae->frameBuf, pstData->u64VirAddr, pstData->u32Len);
    //swr_convert(pFae->swrCtx, pFae->convert_data, pFae->pCodecCtx->frame_size, (const uint8_t**) pFae->pFrame->data, pFae->pFrame->nb_samples);
    swr_convert(pFae->swrCtx, pFae->convert_data, pFae->pCodecCtx->frame_size, (const uint8_t **) &pstData->u64VirAddr,
                pFae->pFrame->nb_samples);
    int length = pFae->pCodecCtx->frame_size * av_get_bytes_per_sample(pFae->pCodecCtx->sample_fmt);
    memcpy(pFae->pFrame->data[0], pFae->convert_data[0], length);
    memcpy(pFae->pFrame->data[1], pFae->convert_data[1], length);

    pFae->pFrame->pts = (pFae->i_frame++) * 100;

    if (avcodec_send_frame(pFae->pCodecCtx, pFae->pFrame) < 0) {
        printf("can't send frame for encoding\n");
        return AVERROR_EXIT;
    }

    int error = avcodec_receive_packet(pFae->pCodecCtx, &pFae->pkt);
    if (error == AVERROR(EAGAIN)) {
        *pu32OutLen = 0;
        /* If the last frame has been encoded, stop encoding. */
    } else if (error == AVERROR_EOF) {
        *pu32OutLen = 0;
    } else if (error < 0) {
        fprintf(stderr, "Could not encode frame (error '%s')\n",
                av_err2str(error));
        return AVERROR_EXIT;
    } else {
        //printf("encode data: %p, size: %d\n", pFae->pkt.data, pFae->pkt.size);
        write_aac_header(pFae, &pFae->pkt);
        memcpy(pu8Outbuf, pFae->aac_adts_header, sizeof(pFae->aac_adts_header));
        memcpy(pu8Outbuf + sizeof(pFae->aac_adts_header), pFae->pkt.data, pFae->pkt.size);
        *pu32OutLen = sizeof(pFae->aac_adts_header) + pFae->pkt.size;
    }

    av_packet_unref(&pFae->pkt);
    return AX_SUCCESS;
}

static AX_S32 FfmpegAacCloseEncoder(AX_VOID *pEncoder)
{
    if (!pEncoder)
        return AX_ERR_AENC_NULL_PTR;

    FfmpegAacEncoder *pFae = pEncoder;
    swr_free(&pFae->swrCtx);
    avcodec_free_context(&pFae->pCodecCtx);
    av_free(pFae->pFrame);
    av_free(pFae->frameBuf);
    free(pFae);
    return AX_SUCCESS;
}

AX_AENC_ENCODER_S gFfmpegAacEncoder = {
    .enType = PT_AAC,
    .u32MaxFrmLen = 100,
    .aszName = "AAC",
    .pfnOpenEncoder = &FfmpegAacOpenEncoder,
    .pfnEncodeFrm = &FfmpegAacEncodeFrm,
    .pfnCloseEncoder = &FfmpegAacCloseEncoder,
};
