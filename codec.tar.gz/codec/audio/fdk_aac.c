/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "aacenc_lib.h"
#include "aacdecoder_lib.h"
#include "fdk_aac.h"
#include "ax_aenc_log.h"
#include "ax_adec_log.h"

#define IS_LD_ELD(aot) ((aot == 23) || (aot == 39))

typedef struct {
    HANDLE_AACENCODER handle;
    AACENC_InfoStruct info;
    int input_size;
    int16_t *convert_buf;
} FdkAacEncoder;

static AX_S32 FdkAacOpenEncoder(AX_VOID *pEncoderAttr, AX_VOID **ppEncoder)
{
    AX_AENC_AAC_ENCODER_ATTR_S *pAacEncoderAttr = pEncoderAttr;

    if (!pAacEncoderAttr) {
        return AX_ERR_AENC_NULL_PTR;
    }

    if ((pAacEncoderAttr->enAacType <= AAC_TYPE_NULL_OBJECT) ||
        (pAacEncoderAttr->enAacType >= AAC_TYPE_BUTT)) {
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    int aot = pAacEncoderAttr->enAacType;

    if ((pAacEncoderAttr->enTransType <= AAC_TRANS_TYPE_UNKNOWN) ||
        (pAacEncoderAttr->enTransType >= AAC_TRANS_TYPE_BUTT)) {
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    TRANSPORT_TYPE transmux = pAacEncoderAttr->enTransType;

    if ((pAacEncoderAttr->enChnMode <= AAC_CHANNEL_MODE_UNKNOWN) ||
        (pAacEncoderAttr->enChnMode >= AAC_CHANNEL_MODE_BUTT)) {
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    CHANNEL_MODE mode = pAacEncoderAttr->enChnMode;

    FdkAacEncoder *pFae = malloc(sizeof(FdkAacEncoder));
    if (!pFae)
        return AX_ERR_AENC_NOMEM;

    if (aacEncOpen(&pFae->handle, 0, 2) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to open encoder\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_AOT, aot) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the AOT\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_SAMPLERATE, pAacEncoderAttr->u32SampleRate) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the AOT\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_CHANNELMODE, mode) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the channel mode\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_CHANNELORDER, 1) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the wav channel order\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_BITRATE, pAacEncoderAttr->u32BitRate) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the bitrate\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_TRANSMUX, transmux) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the transmux\n");
        free(pFae);
        return 1;
    }
    if (aacEncoder_SetParam(pFae->handle, AACENC_AFTERBURNER, 1) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to set the afterburner mode\n");
        free(pFae);
        return 1;
    }
    if (IS_LD_ELD(aot)) {
        // set encode count
        if (aacEncoder_SetParam(pFae->handle, AACENC_GRANULE_LENGTH, pAacEncoderAttr->u32GranuleLength) != AACENC_OK) {
            fprintf(stderr, "Unable to set the AACENC_GRANULE_LENGTH\n");
            return -1;
        }
    }
    if (aacEncEncode(pFae->handle, NULL, NULL, NULL, NULL) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to initialize the encoder\n");
        free(pFae);
        return 1;
    }
    if (aacEncInfo(pFae->handle, &pFae->info) != AACENC_OK) {
        AencLog(SYS_LOG_ERROR, "Unable to get the encoder info\n");
        free(pFae);
        return 1;
    }

    memcpy(pAacEncoderAttr->u8ConfBuf, pFae->info.confBuf, sizeof(pAacEncoderAttr->u8ConfBuf));
    pFae->input_size = 2 * 2 * pFae->info.frameLength;
    pFae->convert_buf = (int16_t *) malloc(pFae->input_size);
    *ppEncoder = pFae;

    return AX_SUCCESS;
}

static AX_S32 FdkAacEncodeFrm(AX_VOID *pEncoder, const AX_AUDIO_FRAME_S *pstData,
                              AX_U8 *pu8Outbuf, AX_U32 *pu32OutLen)
{
    if (!pEncoder || !pstData || !pu8Outbuf || !pu32OutLen)
        return AX_ERR_AENC_NULL_PTR;

    FdkAacEncoder *pFae = pEncoder;

    AACENC_BufDesc in_buf = { 0 }, out_buf = { 0 };
    AACENC_InArgs in_args = { 0 };
    AACENC_OutArgs out_args = { 0 };
    int in_identifier = IN_AUDIO_DATA;
    int in_size, in_elem_size;
    int out_identifier = OUT_BITSTREAM_DATA;
    int out_size, out_elem_size;
    int read, i;
    void *in_ptr, *out_ptr;
    AACENC_ERROR err;

    uint8_t *input_buf = pstData->u64VirAddr;
    read = pstData->u32Len;
    for (i = 0; i < read / 2; i++) {
        const uint8_t *in = &input_buf[2 * i];
        pFae->convert_buf[i] = in[0] | (in[1] << 8);
    }
    in_ptr = pFae->convert_buf;
    in_size = read;
    in_elem_size = 2;

    in_args.numInSamples = read <= 0 ? -1 : read / 2;
    in_buf.numBufs = 1;
    in_buf.bufs = &in_ptr;
    in_buf.bufferIdentifiers = &in_identifier;
    in_buf.bufSizes = &in_size;
    in_buf.bufElSizes = &in_elem_size;

    out_ptr = pu8Outbuf;
    out_size = *pu32OutLen;
    out_elem_size = 1;
    out_buf.numBufs = 1;
    out_buf.bufs = &out_ptr;
    out_buf.bufferIdentifiers = &out_identifier;
    out_buf.bufSizes = &out_size;
    out_buf.bufElSizes = &out_elem_size;

    if ((err = aacEncEncode(pFae->handle, &in_buf, &out_buf, &in_args, &out_args)) != AACENC_OK) {
        if (err == AACENC_ENCODE_EOF) {
            fprintf(stderr, "%s, end of file is signaled\n", __func__);
        } else {
            fprintf(stderr, "Encoding failed\n");
            return 1;
        }
    }

    *pu32OutLen = out_args.numOutBytes;
    return AX_SUCCESS;
}

static AX_S32 FdkAacCloseEncoder(AX_VOID *pEncoder)
{
    if (!pEncoder)
        return AX_ERR_AENC_NULL_PTR;

    FdkAacEncoder *pFae = pEncoder;
    free(pFae->convert_buf);
    aacEncClose(&pFae->handle);
    free(pFae);
    return AX_SUCCESS;
}

AX_AENC_ENCODER_S gFdkAacEncoder = {
    .enType = PT_AAC,
    .u32MaxFrmLen = 100,
    .aszName = "AAC",
    .pfnOpenEncoder = &FdkAacOpenEncoder,
    .pfnEncodeFrm = &FdkAacEncodeFrm,
    .pfnCloseEncoder = &FdkAacCloseEncoder,
};

typedef struct {
    int output_size;
	INT_PCM *decode_buf;
    HANDLE_AACDECODER handle;
    CStreamInfo *info;
    int frame_size;
} FdkAacDecoder;

AX_S32 FdkAacOpenDecoder(AX_VOID *pDecoderAttr, AX_VOID **ppDecoder)
{
    AX_ADEC_AAC_DECODER_ATTR_S *pAacDecoderAttr = pDecoderAttr;

    if (!pAacDecoderAttr) {
        return AX_ERR_AENC_NULL_PTR;
    }

    if ((pAacDecoderAttr->enTransType <= AAC_TRANS_TYPE_UNKNOWN) ||
        (pAacDecoderAttr->enTransType >= AAC_TRANS_TYPE_BUTT)) {
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    TRANSPORT_TYPE transportFmt = pAacDecoderAttr->enTransType;

    FdkAacDecoder *pFad = malloc(sizeof(FdkAacDecoder));
    if (!pFad)
        return AX_ERR_ADEC_NOMEM;

    pFad->handle = aacDecoder_Open(transportFmt, 1);
    if (!pFad->handle) {
        AdecLog(SYS_LOG_ERROR, "aacDecoder_Open error\n");
        free(pFad);
        return AX_ERR_ADEC_DECODER_ERR;
    }

    if (transportFmt == TT_MP4_RAW) {
        AAC_DECODER_ERROR err = aacDecoder_ConfigRaw(pFad->handle, pAacDecoderAttr->u8Conf, &pAacDecoderAttr->u32ConfLen);
        if (err > 0) {
            AdecLog(SYS_LOG_ERROR, "aacDecoder_ConfigRaw error: %x\n", err);
            free(pFad);
            return AX_ERR_ADEC_DECODER_ERR;
        }
    }

    pFad->output_size = 8*sizeof(INT_PCM)*2048;
    AdecLog(SYS_LOG_DEBUG, "%s, output_size: %d\n", __func__, pFad->output_size);
	pFad->decode_buf = (INT_PCM*) malloc(pFad->output_size);
    if (!pFad->decode_buf) {
        AdecLog(SYS_LOG_ERROR, "malloc error\n");
        free(pFad);
        aacDecoder_Close(pFad->handle);
        return AX_ERR_ADEC_NOMEM;
    }
    pFad->info = NULL;
    pFad->frame_size = 0;
    *ppDecoder = pFad;

    return AX_SUCCESS;
}

AX_S32 FdkAacDecodeFrm(AX_VOID *pDecoder, AX_U8 **pu8Inbuf,AX_S32 *ps32LeftByte,
                        AX_U16 *pu16Outbuf,AX_U32 *pu32OutLen,AX_U32 *pu32Chns)
{
    FdkAacDecoder *pFad = (FdkAacDecoder *)pDecoder;
    AAC_DECODER_ERROR err;
    uint8_t *ptr = *pu8Inbuf;
    UINT valid, packet_size;

    if (*pu32OutLen < pFad->output_size) {
        return AX_ERR_ADEC_BUF_LACK;
    }

    valid = packet_size = *ps32LeftByte;
    err = aacDecoder_Fill(pFad->handle, &ptr, &packet_size, &valid);
	if (err != AAC_DEC_OK) {
		AdecLog(SYS_LOG_ERROR, "Fill failed: %x\n", err);
		return AX_ERR_ADEC_DECODER_ERR;
	}
    *pu32OutLen = 0;
    err = aacDecoder_DecodeFrame(pFad->handle, pFad->decode_buf, pFad->output_size / sizeof(INT_PCM), 0);
	if (err == AAC_DEC_NOT_ENOUGH_BITS) {
		return AX_SUCCESS;
	}
	if (err != AAC_DEC_OK) {
		AdecLog(SYS_LOG_ERROR, "Decode failed: %x\n", err);
		return AX_ERR_ADEC_DECODER_ERR;
	}

    if (!pFad->info) {
        pFad->info = aacDecoder_GetStreamInfo(pFad->handle);
        if (!pFad->info || pFad->info->sampleRate <= 0) {
			AdecLog(SYS_LOG_ERROR, "No stream info\n");
			return AX_ERR_ADEC_DECODER_ERR;
		}
        pFad->frame_size = pFad->info->frameSize * pFad->info->numChannels;
        AdecLog(SYS_LOG_DEBUG, "%s, frame_size: %d\n", __func__, pFad->frame_size);
    }

    uint8_t *output_buf = (uint8_t *)pu16Outbuf;
    for (int i = 0; i < pFad->frame_size; i++) {
		uint8_t* out = &output_buf[sizeof(INT_PCM)*i];
		unsigned j;
		for (j = 0; j < sizeof(INT_PCM); j++)
			out[j] = (uint8_t)(pFad->decode_buf[i] >> (8*j));
	}
    *pu32OutLen = sizeof(INT_PCM)*pFad->frame_size;
    *pu32Chns = pFad->info->numChannels;

    return AX_SUCCESS;
}

AX_S32 FdkAacGetFrmInfo(AX_VOID *pDecoder, AX_VOID *pInfo)
{
    AX_AUDIO_FRAME_S *data = (AX_AUDIO_FRAME_S *)pInfo;
    data->enBitwidth = AX_AUDIO_BIT_WIDTH_16;
    return AX_SUCCESS;
}

AX_S32 FdkAacCloseDecoder(AX_VOID *pDecoder)
{
    FdkAacDecoder *pFad = (FdkAacDecoder *)pDecoder;
    free(pFad->decode_buf);
    aacDecoder_Close(pFad->handle);
    if (pFad) {
        free(pFad);
    }
    return AX_SUCCESS;
}

AX_S32 FdkAacResetDecoder(AX_VOID *pDecoder)
{
   return AX_SUCCESS;
}

AX_ADEC_DECODER_S gFdkAacDecoder = {
    .enType = PT_AAC,
    .aszName = "AAC decoder",
    .pfnOpenDecoder = &FdkAacOpenDecoder,
    .pfnDecodeFrm = &FdkAacDecodeFrm,
    .pfnGetFrmInfo = &FdkAacGetFrmInfo,
    .pfnCloseDecoder = &FdkAacCloseDecoder,
    .pfnResetDecoder = &FdkAacResetDecoder,
};
