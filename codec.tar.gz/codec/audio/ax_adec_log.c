/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#include <stdarg.h>
#include <time.h>
#include <stdlib.h>
#include "ax_sys_log.h"


#define ADEC_LOG_TAG        "ADEC"
#define ADEC_LOG_ID         AX_ID_ADEC

static AX_LOG_TARGET_E gAdecLogTarget = SYS_LOG_TARGET_SYSLOG;
static AX_LOG_LEVEL_E gAdecLogLevel = SYS_LOG_NOTICE;

AX_S32 AdecLogInit(AX_LOG_LEVEL_E eLv, AX_LOG_LEVEL_E eTarget)
{
    AX_CHAR *pEnv = getenv("ADEC_LOG_LEVEL");
    if (pEnv) {
        AX_S32 nLv = atoi(pEnv);
        if (nLv > SYS_LOG_MIN && nLv < SYS_LOG_MAX) {
            eLv = (AX_LOG_LEVEL_E)nLv;
        }
    }
    gAdecLogLevel = eLv;

    pEnv = getenv("ADEC_LOG_TARGET");
    if (pEnv) {
        AX_S32 nTarget = atoi(pEnv);
        if (nTarget > SYS_LOG_TARGET_MIN && nTarget < SYS_LOG_TARGET_MAX) {
            eTarget = (AX_LOG_TARGET_E)nTarget;
        }
    }
    gAdecLogTarget = eTarget;

    return 0;
}

void AdecLog(AX_U32 eLv, const AX_CHAR *fmt, ...)
{
    va_list args;
    if (eLv <= gAdecLogLevel) {
        va_start(args, fmt);
        switch (eLv) {
        case SYS_LOG_DEBUG:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_DEBUG, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_INFO:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_INFO, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_NOTICE:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_NOTICE, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_WARN:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_WARNING, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_ERROR:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_ERR, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_CRITICAL:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_CRIT, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_ALERT:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_ALERT, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        case SYS_LOG_EMERGENCY:
            AX_SYS_LogOutput_Ex(gAdecLogTarget, (AX_LOG_LEVEL_E)LOG_EMERG, ADEC_LOG_TAG, ADEC_LOG_ID, (AX_CHAR *)fmt, args);
            break;
        default:
            break;
        }
        va_end(args);
    }
}