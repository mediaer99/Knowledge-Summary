/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <stdio.h>
#include <string.h>
#include "lpcm.h"



static AX_S32 LpcmOpenEncoder(AX_VOID *pEncoderAttr, AX_VOID **ppEncoder)
{
    return AX_SUCCESS;
}

static AX_S32 LpcmEncodeFrm(AX_VOID *pEncoder, const AX_AUDIO_FRAME_S *pstData,
                             AX_U8 *pu8Outbuf, AX_U32 *pu32OutLen)
{
    memcpy(pu8Outbuf, pstData->u64VirAddr, pstData->u32Len);
    *pu32OutLen = pstData->u32Len;
    return AX_SUCCESS;
}

static AX_S32 LpcmCloseEncoder(AX_VOID *pEncoder)
{
    return AX_SUCCESS;
}

AX_AENC_ENCODER_S gLpcmEncoder = {
    .enType = PT_LPCM,
    .u32MaxFrmLen = 100,
    .aszName = "LPCM encoder",
    .pfnOpenEncoder = &LpcmOpenEncoder,
    .pfnEncodeFrm = &LpcmEncodeFrm,
    .pfnCloseEncoder = &LpcmCloseEncoder,
};

static AX_S32 LpcmOpenDecoder(AX_VOID *pDecoderAttr, AX_VOID **ppDecoder)
{
    return AX_SUCCESS;
}

static AX_S32 LpcmDecodeFrm(AX_VOID *pDecoder, AX_U8 **pu8Inbuf,AX_S32 *ps32LeftByte,
                        AX_U16 *pu16Outbuf,AX_U32 *pu32OutLen,AX_U32 *pu32Chns)
{
    if (*pu32OutLen < *ps32LeftByte) {
        return AX_ERR_ADEC_BUF_LACK;
    }

    memcpy(pu16Outbuf, *pu8Inbuf, *ps32LeftByte);
    *pu32OutLen = *ps32LeftByte;
    *ps32LeftByte = 0;
    return AX_SUCCESS;
}

static AX_S32 LpcmGetFrmInfo(AX_VOID *pDecoder, AX_VOID *pInfo)
{
    return AX_SUCCESS;
}

static AX_S32 LpcmCloseDecoder(AX_VOID *pDecoder)
{
    return AX_SUCCESS;
}

static AX_S32 LpcmResetDecoder(AX_VOID *pDecoder)
{
    return AX_SUCCESS;
}

AX_ADEC_DECODER_S gLpcmDecoder = {
    .enType = PT_LPCM,
    .aszName = "LPCM decoder",
    .pfnOpenDecoder = &LpcmOpenDecoder,
    .pfnDecodeFrm = &LpcmDecodeFrm,
    .pfnGetFrmInfo = &LpcmGetFrmInfo,
    .pfnCloseDecoder = &LpcmCloseDecoder,
    .pfnResetDecoder = &LpcmResetDecoder,
};