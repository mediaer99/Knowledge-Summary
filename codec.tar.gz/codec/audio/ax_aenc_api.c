/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include "ax_aenc_api.h"
#include "g711.h"
#include "fdk_aac.h"
#include "lpcm.h"
#include "sc_opus.h"
#include "circle_queue.h"
#include "ax_aenc_log.h"
#include "ax_audio_proc.h"

#define AX_AENC_MAX_ENCODER_NUM         20

static AX_AUDIO_STREAM_S* CreateAudioStream(AX_U32 u32Len, AX_U64 u64TimeStamp, AX_U32 u32Seq)
{
    AX_AUDIO_STREAM_S* data = malloc(sizeof(AX_AUDIO_STREAM_S));
    if (!data) {
        return NULL;
    }

    data->pStream = malloc(sizeof(AX_U8) * u32Len);
    if (!data->pStream) {
        free(data);
        return NULL;
    }
    data->u32Len = u32Len;
    data->u64TimeStamp = u64TimeStamp;
    data->u32Seq = u32Seq;
    return data;
}

static void DestoryAudioStream(AX_AUDIO_STREAM_S* data)
{
    free(data->pStream);
    free(data);
}

typedef struct {
    AX_PAYLOAD_TYPE_E enType;
    const AX_AENC_ENCODER_S *pAencEncoder;
    AX_U32 u32PtNumPerFrm;
    AX_U32 u32BufSize;
    AX_VOID *pEncoder;
    CircleQueue *pQueue;
    pthread_mutex_t queueMutex;
    pthread_condattr_t queueCondattr;
    pthread_cond_t queueCond;

    AX_U64 u64SndFrm;
    AX_U64 u64EncOk;
    AX_U64 u64BufFull;
    AX_U64 u64GetStrm;
    AX_U64 u64RlsStrm;
} AxAencChn;

static const AX_AENC_ENCODER_S *gAencEncoders[AX_AENC_MAX_ENCODER_NUM] =
    {&gG711AEncoder, &gG711UEncoder, &gFdkAacEncoder, &gLpcmEncoder, &gScOpusEncoder, };
static AxAencChn *gChns[AX_AENC_MAX_CHN_NUM];
static int gAencInitFlag = 0;
static int gAencProcFd = -1;
static char *gAencDevicePath = "/dev/aenc";
static pthread_t gAencProcThreadTid = 0;
static volatile int gAencProcThreadRun = 0;

static void AencProcFormatMsg(char *msg, size_t msgMaxLen)
{
    AX_U32 i;

    snprintf(msg,
             msgMaxLen,
             "-------- AENC CHN ATTR ------------------------\n"
             "%-16s%-16s%-16s%-16s\n", "ChnId", "PlType", "PtNumPerFrm", "BufSize");
    for (i = 0; i < AX_AENC_MAX_CHN_NUM; i++) {
        if (gChns[i]) {
            snprintf(msg + strlen(msg),
                     msgMaxLen - strlen(msg),
                     "%-16u%-16s%-16u%-16u\n",
                     i,
                     gChns[i]->pAencEncoder->aszName,
                     gChns[i]->u32PtNumPerFrm,
                     gChns[i]->u32BufSize);
        }
    }

    snprintf(msg + strlen(msg),
             msgMaxLen - strlen(msg),
             "-------- AENC CHN STATUS ------------------------\n"
             "%-16s%-16s%-16s%-16s%-16s%-16s\n", "ChnId", "SndFrm", "EncOk", "BufFull", "GetStrm", "RlsStrm");
    for (i = 0; i < AX_AENC_MAX_CHN_NUM; i++) {
        if (gChns[i]) {
            snprintf(msg + strlen(msg),
                     msgMaxLen - strlen(msg),
                     "%-16u%-16llu%-16llu%-16llu%-16llu%-16llu\n",
                     i,
                     gChns[i]->u64SndFrm,
                     gChns[i]->u64EncOk,
                     gChns[i]->u64BufFull,
                     gChns[i]->u64GetStrm,
                     gChns[i]->u64RlsStrm);
        }
    }
}

static void *AencProcThread(void *args)
{
    char msg[PROC_USR_MSG_LEN];
    while (gAencProcThreadRun) {
        if (ioctl(gAencProcFd, AUDIOPROC_WAIT, NULL)) {
            AencLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_WAIT failed\n");
            continue;
        }

        if (!gAencProcThreadRun)
            break;

        AencProcFormatMsg(msg, PROC_USR_MSG_LEN);
        if (ioctl(gAencProcFd, AUDIOPROC_DONE, msg)) {
            AencLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_DONE failed\n");
        }
    }

    return NULL;
}

AX_S32 AX_AENC_Init()
{
    if (!gAencInitFlag) {
        AencLogInit(SYS_LOG_WARN, SYS_LOG_TARGET_SYSLOG);

        gAencProcFd = open(gAencDevicePath, O_RDWR);
        if (gAencProcFd == -1) {
            AencLog(SYS_LOG_ERROR, "failed to open %s, errno: %d\n", gAencDevicePath, errno);
            return AX_ERR_AENC_SYS_NOTREADY;
        }

        gAencProcThreadRun = 1;
        if (pthread_create(&gAencProcThreadTid, NULL, AencProcThread, (void *)NULL) != 0) {
            close(gAencProcFd);
            AencLog(SYS_LOG_ERROR, "Create AencProcThread failed\n");
            return AX_ERR_AENC_SYS_NOTREADY;
        }
        gAencInitFlag = 1;
    }

    return AX_SUCCESS;
}

AX_S32 AX_AENC_DeInit()
{
    if (gAencInitFlag) {
        for (int i = 0; i < AX_AENC_MAX_CHN_NUM; i++) {
            if (gChns[i]) {
                AencLog(SYS_LOG_ERROR, "channel %d exist, destory it first\n", i);
                return AX_ERR_AENC_NOT_PERM;
            }
        }

        gAencProcThreadRun = 0;
        if (ioctl(gAencProcFd, AUDIOPROC_EXIT, NULL)) {
            AencLog(SYS_LOG_ERROR, "ioctl AUDIOPROC_EXIT failed\n");
        }
        pthread_join(gAencProcThreadTid, NULL);
        close(gAencProcFd);
        gAencInitFlag = 0;
    }
    return AX_SUCCESS;
}

AX_S32 AX_AENC_CreateChn(AENC_CHN aeChn, const AX_AENC_CHN_ATTR_S *pstAttr)
{
    AX_S32 ret = AX_SUCCESS;

    if (!gAencInitFlag)
        return AX_ERR_AENC_SYS_NOTREADY;

    if (aeChn < 0 || aeChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!pstAttr)
        return AX_ERR_AENC_NULL_PTR;

    if (gChns[aeChn])
        return AX_ERR_AENC_EXIST;

    gChns[aeChn] = malloc(sizeof(AxAencChn));
    if (!gChns[aeChn])
        return AX_ERR_AENC_NOMEM;

    gChns[aeChn]->enType = pstAttr->enType;
    int i = 0;
    for (i = 0; i < AX_AENC_MAX_ENCODER_NUM; i++) {
        if (gAencEncoders[i] && gAencEncoders[i]->enType == pstAttr->enType)
            break;
    }
    if (i == AX_AENC_MAX_ENCODER_NUM) {
        free(gChns[aeChn]);
        gChns[aeChn] = NULL;
        return AX_ERR_AENC_NOT_SUPPORT;
    }

    gChns[aeChn]->pAencEncoder = gAencEncoders[i];
    gChns[aeChn]->u32PtNumPerFrm = pstAttr->u32PtNumPerFrm;
    gChns[aeChn]->u32BufSize = pstAttr->u32BufSize;

    // open encoder
    if ((ret = gChns[aeChn]->pAencEncoder->pfnOpenEncoder(pstAttr->pValue, &gChns[aeChn]->pEncoder)) != AX_SUCCESS) {
        free(gChns[aeChn]);
        gChns[aeChn] = NULL;
        return ret;
    }

    gChns[aeChn]->pQueue = CreateCirQ(gChns[aeChn]->u32BufSize);
    if (!gChns[aeChn]->pQueue) {
        gChns[aeChn]->pAencEncoder->pfnCloseEncoder(gChns[aeChn]->pEncoder);
        free(gChns[aeChn]);
        gChns[aeChn] = NULL;
        return AX_ERR_AENC_NOBUF;
    }

    pthread_mutex_init(&gChns[aeChn]->queueMutex, NULL);
    pthread_condattr_init(&gChns[aeChn]->queueCondattr);
    pthread_condattr_setclock(&gChns[aeChn]->queueCondattr, CLOCK_MONOTONIC);
    pthread_cond_init(&gChns[aeChn]->queueCond, &gChns[aeChn]->queueCondattr);

    gChns[aeChn]->u64SndFrm = 0;
    gChns[aeChn]->u64EncOk = 0;
    gChns[aeChn]->u64BufFull = 0;
    gChns[aeChn]->u64GetStrm = 0;
    gChns[aeChn]->u64RlsStrm = 0;

    AencLog(SYS_LOG_INFO, "AX_AENC_CreateChn succeed, aeChn: %d\n", aeChn);
    return AX_SUCCESS;
}

AX_S32 AX_AENC_DestroyChn(AENC_CHN aeChn)
{
    AX_S32 ret = AX_SUCCESS;

    if (!gAencInitFlag)
        return AX_ERR_AENC_SYS_NOTREADY;

    if (aeChn < 0 || aeChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!gChns[aeChn])
        return AX_ERR_AENC_UNEXIST;

    // close encoder
    if ((ret = gChns[aeChn]->pAencEncoder->pfnCloseEncoder(gChns[aeChn]->pEncoder)) != AX_SUCCESS)
        return ret;

    pthread_mutex_destroy(&gChns[aeChn]->queueMutex);
    pthread_condattr_destroy(&gChns[aeChn]->queueCondattr);
    pthread_cond_destroy(&gChns[aeChn]->queueCond);

    DestoryCirQ(gChns[aeChn]->pQueue);

    free(gChns[aeChn]);
    gChns[aeChn] = NULL;

    AencLog(SYS_LOG_INFO, "AX_AENC_DestroyChn succeed, aeChn: %d\n", aeChn);
    return AX_SUCCESS;
}

AX_S32 AX_AENC_SendFrame(AENC_CHN aeChn, const AX_AUDIO_FRAME_S *pstFrm)
{
    AX_S32 ret = AX_SUCCESS;

    if (aeChn < 0 || aeChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!gChns[aeChn])
        return AX_ERR_AENC_UNEXIST;

    if (!pstFrm)
        return AX_ERR_AENC_NULL_PTR;

    gChns[aeChn]->u64SndFrm++;
    pthread_mutex_lock(&gChns[aeChn]->queueMutex);
    if (IsFullCirQ(gChns[aeChn]->pQueue)) {
        gChns[aeChn]->u64BufFull++;
        pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
        return AX_ERR_AENC_BUF_FULL;
    }

    AX_U32 streamLen;
    switch (gChns[aeChn]->enType) {
    case PT_OPUS:
        streamLen = SC_OPUS_MAX_PACKET;
        break;
    default:
        streamLen = gChns[aeChn]->u32PtNumPerFrm * 4;
        break;
    }
    AX_AUDIO_STREAM_S *data = CreateAudioStream(streamLen, pstFrm->u64TimeStamp, pstFrm->u32Seq);
    if (!data) {
        pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
        return AX_ERR_AENC_NOMEM;
    }
    if ((ret = gChns[aeChn]->pAencEncoder->pfnEncodeFrm(gChns[aeChn]->pEncoder, pstFrm, data->pStream,
               &data->u32Len)) != AX_SUCCESS) {
        DestoryAudioStream(data);
        pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
        return ret;
    }

    gChns[aeChn]->u64EncOk++;
    PushCirQ(gChns[aeChn]->pQueue, data);
    //printf("%s, data: %p, data->pStream: %p\n", __func__, data, data->pStream);
    pthread_cond_signal(&gChns[aeChn]->queueCond);
    pthread_mutex_unlock(&gChns[aeChn]->queueMutex);

    return AX_SUCCESS;
}

AX_S32 AX_AENC_GetStream(AENC_CHN aeChn, AX_AUDIO_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
    if (aeChn < 0 || aeChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!gChns[aeChn])
        return AX_ERR_AENC_UNEXIST;

    if (!pstStream)
        return AX_ERR_AENC_NULL_PTR;

    pthread_mutex_lock(&gChns[aeChn]->queueMutex);
    if (s32MilliSec == -1) {
        while (IsEmptyCirQ(gChns[aeChn]->pQueue)) {
            pthread_cond_wait(&gChns[aeChn]->queueCond, &gChns[aeChn]->queueMutex);
            //printf("%s: aeChn: %d, IsEmptyCirQ: %d\n", __func__, aeChn, IsEmptyCirQ(gChns[aeChn]->pQueue));
        }
    } else if (s32MilliSec == 0) {
        if (IsEmptyCirQ(gChns[aeChn]->pQueue)) {
            pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
            return AX_ERR_AENC_BUF_EMPTY;
        }
    } else {
        if (IsEmptyCirQ(gChns[aeChn]->pQueue)) {
            int ret = 0;
            int timeout = 0;
            struct timespec tv;

            AX_U32 sec_exp = s32MilliSec / 1000;
            AX_U32 msec_exp = s32MilliSec % 1000;
            clock_gettime(CLOCK_MONOTONIC, &tv);
            tv.tv_sec += sec_exp;
            tv.tv_nsec += msec_exp * 1000 * 1000;
            ret = pthread_cond_timedwait(&gChns[aeChn]->queueCond, &gChns[aeChn]->queueMutex, &tv);
            timeout = ((ret == 0) && (!IsEmptyCirQ(gChns[aeChn]->pQueue))) ? 0 : 1;
            if (timeout) {
                pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
                return AX_ERR_AENC_BUF_EMPTY;
            }
        }
    }
    AX_AUDIO_STREAM_S *data = FrontCirQ(gChns[aeChn]->pQueue);
    //printf("%s, data: %p, data->pStream: %p\n", __func__, data, data->pStream);
    memcpy(pstStream, data, sizeof(*pstStream));
    pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
    gChns[aeChn]->u64GetStrm++;

    return AX_SUCCESS;
}

AX_S32 AX_AENC_ReleaseStream(AENC_CHN aeChn, const AX_AUDIO_STREAM_S *pstStream)
{
    if (aeChn < 0 || aeChn >= AX_AENC_MAX_CHN_NUM)
        return AX_ERR_AENC_INVALID_CHNID;

    if (!gChns[aeChn])
        return AX_ERR_AENC_UNEXIST;

    if (!pstStream)
        return AX_ERR_AENC_NULL_PTR;

    pthread_mutex_lock(&gChns[aeChn]->queueMutex);
    AX_AUDIO_STREAM_S *frontdata = FrontCirQ(gChns[aeChn]->pQueue);
    if ((frontdata->pStream != pstStream->pStream) || (frontdata->u32Len != pstStream->u32Len)) {
        pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
        return AX_ERR_AENC_NOT_PERM;
    }
    AX_AUDIO_STREAM_S *data = PopCirQ(gChns[aeChn]->pQueue);
    //printf("%s, data: %p, data->pStream: %p\n", __func__, data, data->pStream);
    DestoryAudioStream(data);
    pthread_cond_signal(&gChns[aeChn]->queueCond);
    pthread_mutex_unlock(&gChns[aeChn]->queueMutex);
    gChns[aeChn]->u64RlsStrm++;

    return AX_SUCCESS;
}

AX_S32 AX_AENC_RegisterEncoder(AX_S32 *ps32Handle, const AX_AENC_ENCODER_S *pstEncoder)
{
    if (!ps32Handle || !pstEncoder)
        return AX_ERR_AENC_NULL_PTR;

    // check if already registered
    int i = 0;
    for (i = 0; i < AX_AENC_MAX_ENCODER_NUM; i++) {
        if (gAencEncoders[i] && gAencEncoders[i]->enType == pstEncoder->enType)
            return AX_ERR_AENC_NOT_PERM;
    }

    // find an empty place
    for (i = 0; i < AX_AENC_MAX_ENCODER_NUM; i++) {
        if (!gAencEncoders[i])
            break;
    }

    if (i == AX_AENC_MAX_ENCODER_NUM) {
        // array full
        return AX_ERR_AENC_NOT_PERM;
    }

    *ps32Handle = i;
    gAencEncoders[i] = pstEncoder;

    return AX_SUCCESS;
}

AX_S32 AX_AENC_UnRegisterEncoder(AX_S32 s32Handle)
{
    if (s32Handle < 0 || s32Handle >= AX_AENC_MAX_ENCODER_NUM)
        return AX_ERR_AENC_NOT_PERM;

    if (!gAencEncoders[s32Handle])
        return AX_ERR_AENC_NOT_PERM;

    // check whether this encoder is using
    int i = 0;
    for (i = 0; i < AX_AENC_MAX_CHN_NUM; i++) {
        if (gChns[i] && (gChns[i]->pAencEncoder == gAencEncoders[s32Handle]))
            return AX_ERR_AENC_NOT_PERM;
    }

    gAencEncoders[s32Handle] = NULL;
    return AX_SUCCESS;
}
