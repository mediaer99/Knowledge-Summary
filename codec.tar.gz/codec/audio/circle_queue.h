/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#ifndef _AX_CIRCLE_QUEUE_H_
#define _AX_CIRCLE_QUEUE_H_

#include "ax_base_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    void **data;
    AX_U32 dataMaxLen;
    int front;
    int rear;
    int size;
} CircleQueue;

typedef void (*PrintDataFunc)(void* data);
CircleQueue *CreateCirQ(AX_U32 dataMaxLen);
void DestoryCirQ(CircleQueue *q);
int IsFullCirQ(CircleQueue *q);
int IsEmptyCirQ(CircleQueue *q);
void *FrontCirQ(CircleQueue *q);
void *BackCirQ(CircleQueue *q);
void PushCirQ(CircleQueue *q, void *item);
void *PopCirQ(CircleQueue *q);
void PrintCirQ(CircleQueue *q, PrintDataFunc func);

#ifdef __cplusplus
}
#endif

#endif
