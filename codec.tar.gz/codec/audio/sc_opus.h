/**************************************************************************************************
 *
 * Copyright (c) 2019-2023 Axera Semiconductor (Shanghai) Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor (Shanghai) Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor (Shanghai) Co., Ltd.
 *
 **************************************************************************************************/

#ifndef _AX_SC_OPUS_HAL_H_
#define _AX_SC_OPUS_HAL_H_

#include "ax_base_type.h"
#include "ax_global_type.h"
#include "ax_aenc_api.h"
#include "ax_adec_api.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SC_OPUS_MAX_PACKET      1500

extern AX_AENC_ENCODER_S gScOpusEncoder;
extern AX_ADEC_DECODER_S gScOpusDecoder;

#ifdef __cplusplus
}
#endif

#endif
