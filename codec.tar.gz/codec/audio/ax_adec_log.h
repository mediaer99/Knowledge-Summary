/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#ifndef _AX_ADEC_LOG_H_
#define _AX_ADEC_LOG_H_

#include "ax_global_type.h"

#ifdef __cplusplus
extern "C"
{
#endif

AX_S32 AdecLogInit(AX_LOG_LEVEL_E eLv, AX_LOG_LEVEL_E eTarget);
void AdecLog(AX_U32 eLv, const AX_CHAR *fmt, ...);


#ifdef __cplusplus
}
#endif

#endif
