/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <semaphore.h>
#include <fcntl.h>
#include <errno.h>

#include "ax_vdec_api.h"
#include "ax_vdec_interface.h"
#include "vdec_log.h"
#include "bsp_osal.h"
#include "dwl.h"
#include "ax_vdec_fifo.h"
#include "ax_vdec_proc.h"
#include "ax_sys_api.h"
#include "ax_sys_api_internal.h"
#include "ax_frame.h"
#include "hx170dec.h"


#ifndef AX_VDEC_PUBLIC
    #define AX_VDEC_PUBLIC __attribute__ ((visibility ("default")))
#endif

static AxVdecContext gAxVdecContext = {
    .enModStatus = VDEC_MOD_STATUS_UNINIT,
    .enChnStatus = { VDEC_CHN_STATUS_INIT, },
    .chns = { NULL, },
    .fd = -1,
};

#define CHECK_VDEC_ATTR(w, h, f)  if ((w) > H264_MAX_WIDTH || (h) > H264_MAX_HEIGHT || (f) > H264_MAX_HEIGHT) { \
            return AX_ERR_VDEC_ILLEGAL_PARAM; \
}

#define CHECK_JDEC_ATTR(w, h, f)  if ((w) > JPEG_MAX_WIDTH || (h) > JPEG_MAX_HEIGHT || (f) > JPEG_MAX_HEIGHT) { \
            return AX_ERR_VDEC_ILLEGAL_PARAM; \
}

void VdecProcCatCallback(char *msg, size_t msgMaxLen);
static AX_S32 Vdec_SuspendResume_Callback(const AX_NOTIFY_EVENT_E event, AX_VOID *pdata);
static AX_S32 Jdec_SuspendResume_Callback(const AX_NOTIFY_EVENT_E event, AX_VOID *pdata);

AX_S32 gVdec_Debug_Fd = -1;
AX_U32 Grp_Num = 0;
AX_BOOL gVdecSuspendState = AX_FALSE;
AX_BOOL gJdecSuspendState = AX_FALSE;
AX_BOOL gJdecWaitUnlock = AX_FALSE;
AX_BOOL gVdecWaitUnlock = AX_FALSE;

AX_VDEC_PUBLIC AX_S32 AX_VDEC_Init()
{
    AX_S32 ret = AX_SUCCESS;
    DWLInitParam_t dwlInit;
    AX_S32 fd = -1;
    dwlInit.clientType = DWL_CLIENT_TYPE_H264_DEC;

    if (gAxVdecContext.enModStatus == VDEC_MOD_STATUS_UNINIT) {
        // init log
        VdecLogInit(SYS_LOG_WARN, SYS_LOG_TARGET_SYSLOG);
        VdecThreadLevelInit();

        fd = open(VDEC_DEVICE_NAME, O_RDWR);
        if (fd == -1) {
            printf("Open device ERROR: errno: %d\n", errno);
            return AX_ERR_VDEC_SYS_NOTREADY;
        }

        dwlInit.fd = fd;
        gAxVdecContext.fd = fd;

        gAxVdecContext.dwlInst = DWLInit(&dwlInit);
        if (gAxVdecContext.dwlInst == NULL) {
            VdecLog(SYS_LOG_ERROR, "DWLInit# ERROR: DWL Init failed\n");
            return AX_ERR_VDEC_UNKNOWN;
        }
        ret = VdecProcRegisterCatCallback(VdecProcCatCallback);
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "VdecProcNlRegisterCatCallback error: %x\n", ret);
            return AX_ERR_VDEC_RUN_ERROR;
        }

        ret = AX_SYS_RegisterEventCb(AX_ID_VDEC, Vdec_SuspendResume_Callback, NULL);
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "AX_SYS_RegisterEventCb Vdec error: %x\n", ret);
            return AX_ERR_VDEC_RUN_ERROR;
        }

        ret = AX_SYS_RegisterEventCb(AX_ID_JDEC, Jdec_SuspendResume_Callback, NULL);
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "AX_SYS_RegisterEventCb Jdec error: %x\n", ret);
            return AX_ERR_VDEC_RUN_ERROR;
        }

        ret = CreateJdecWorkingThread();
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "CreateJdecWorkingThread error: %x\n", ret);
            return AX_ERR_VDEC_RUN_ERROR;
        }
        ret = CreateVdecWorkingThread();
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "CreateJdecWorkingThread error: %x\n", ret);
            return AX_ERR_VDEC_RUN_ERROR;
        }

        gAxVdecContext.enModStatus = VDEC_MOD_STATUS_INIT;

        for (int i = 0; i < AX_VDEC_MAX_GRP_SIZE; i++) {
            pthread_mutex_init(&gAxVdecContext.ChannelMutex[i], NULL);
            pthread_mutex_init(&gAxVdecContext.SendMutex[i], NULL);
            pthread_mutex_init(&gAxVdecContext.GetMutex[i], NULL);
            pthread_mutex_init(&gAxVdecContext.ReleaseMutex[i], NULL);
        }
        pthread_mutex_init(&gAxVdecContext.JpegDecMutex,NULL);
    }

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_DeInit()
{
    AX_S32 ret = AX_SUCCESS;
    if (gAxVdecContext.enModStatus == VDEC_MOD_STATUS_INIT) {
        for (int i = 0; i < AX_VDEC_MAX_GRP_SIZE; i++) {
            if (gAxVdecContext.chns[i]) {
                VdecLog(SYS_LOG_ERROR, "channel %d exist, destory it first\n", i);
                return AX_ERR_VDEC_NOT_PERM;
            }
        }

        ret = DestroyJdecWorkingThread();
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "DestroyJdecWorkingThread error: %x\n", ret);
            return AX_ERR_VDEC_UNKNOWN;
        }
        ret = DestroyVdecWorkingThread();
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "DestroyJdecWorkingThread error: %x\n", ret);
            return AX_ERR_VDEC_UNKNOWN;
        }

        ret = VdecProcUnRegisterCatCallback();
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "VdecProcNlUnRegisterCatCallback error: %x\n", ret);
            return AX_ERR_VDEC_UNKNOWN;
        }

        ret = AX_SYS_UnregisterEventCb(AX_ID_VDEC);
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "AX_SYS_UnregisterEventCb vdec error: %x\n", ret);
            return AX_ERR_VDEC_UNKNOWN;
        }

        ret = AX_SYS_UnregisterEventCb(AX_ID_JDEC);
        if (ret != AX_SUCCESS) {
            VdecLog(SYS_LOG_ERROR, "AX_SYS_UnregisterEventCb jdec error: %x\n", ret);
            return AX_ERR_VDEC_UNKNOWN;
        }

        if (gAxVdecContext.dwlInst != NULL) {
            DWLRelease(gAxVdecContext.dwlInst);
            gAxVdecContext.dwlInst = NULL;
        }

        if(gAxVdecContext.fd != -1) {
            close(gAxVdecContext.fd);
            gAxVdecContext.fd = -1;
        }

        for (int i = 0; i < AX_VDEC_MAX_GRP_SIZE; i++) {
            pthread_mutex_destroy(&gAxVdecContext.ChannelMutex[i]);
            pthread_mutex_destroy(&gAxVdecContext.GetMutex[i]);
            pthread_mutex_destroy(&gAxVdecContext.SendMutex[i]);
            pthread_mutex_destroy(&gAxVdecContext.ReleaseMutex[i]);
        }
        pthread_mutex_destroy(&gAxVdecContext.JpegDecMutex);

        gAxVdecContext.enModStatus = VDEC_MOD_STATUS_UNINIT;
    }

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_CreateGrp(AX_VDEC_GRP VdGrp, const AX_VDEC_GRP_ATTR_S *pstAttr)
{
    AX_S32 ret = AX_SUCCESS;
    FifoRet fifoRet = FIFO_OK;
    vdec_ringbuffer_t *pstTmpRingBuf;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstAttr)
        return AX_ERR_VDEC_NULL_PTR;

    if(pstAttr->enType == PT_H264) {
        CHECK_VDEC_ATTR(pstAttr->u32PicWidth, pstAttr->u32PicHeight, pstAttr->u32FrameHeight);
    } else if ((pstAttr->enType == PT_JPEG) || (pstAttr->enType == PT_MJPEG)) {
        CHECK_JDEC_ATTR(pstAttr->u32PicWidth, pstAttr->u32PicHeight, pstAttr->u32FrameHeight);
    }

    if (gAxVdecContext.enModStatus != VDEC_MOD_STATUS_INIT)
        return AX_ERR_VDEC_SYS_NOTREADY;

    if (gAxVdecContext.chns[VdGrp]) {
        return AX_ERR_VDEC_EXIST;
    }

    AxVdecChn *dec_chn = (AxVdecChn *)BspOsalMalloc(sizeof(AxVdecChn));
    if (!dec_chn) {
        return AX_ERR_VDEC_NOMEM;
    }

    dec_chn->enType = pstAttr->enType;
    if (pstAttr->enType == PT_H264) {
        dec_chn->pVdecDecoder = &gVdecDecoder;
    } else if ((pstAttr->enType == PT_JPEG) || (pstAttr->enType == PT_MJPEG)) {
        dec_chn->pVdecDecoder = &gJdecDecoder;
    } else {
        BspOsalFree(dec_chn);
        return AX_ERR_VDEC_NOT_SUPPORT;
    }

    //fifo create
    fifoRet = AX_Vdec_Fifo_Init(VDEC_MAX_FIFO_CAPACITY, &dec_chn->InputInfo.InStreamQueue);
    if (fifoRet != FIFO_OK) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: fifo create error.\n", VdGrp);
        BspOsalFree(dec_chn);
        return AX_ERR_VDEC_NOT_INIT;
    }

    pstTmpRingBuf = Vdec_RingBuffer_Create(VdGrp, pstAttr->u32StreamBufSize);
    if (NULL == pstTmpRingBuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: create ring buffer error.\n", VdGrp);
        AX_Vdec_Fifo_DeInit(dec_chn->InputInfo.InStreamQueue);
        BspOsalFree(dec_chn);
        return AX_ERR_VDEC_NOT_INIT;;
    }

    dec_chn->InputInfo.pstInRingBuf = pstTmpRingBuf;
    dec_chn->InputInfo.VdecFd = gAxVdecContext.fd;

    // open decoder
    ret = dec_chn->pVdecDecoder->pfnCreateGrp(VdGrp, pstAttr,
            &dec_chn->pDecoder, gAxVdecContext.dwlInst, &dec_chn->InputInfo);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "pfnCreateChn error: %x\n", ret);
        Vdec_RingBuffer_Close(VdGrp, dec_chn->InputInfo.pstInRingBuf);
        AX_Vdec_Fifo_DeInit(dec_chn->InputInfo.InStreamQueue);
        BspOsalFree(dec_chn);
        return ret;
    }

    pthread_mutex_init(&dec_chn->InputInfo.InputDoneMutex, NULL);

    gAxVdecContext.chns[VdGrp] = dec_chn;
    gAxVdecContext.chns[VdGrp]->send_num = 0;
    gAxVdecContext.chns[VdGrp]->get_num = 0;
    gAxVdecContext.chns[VdGrp]->release_num = 0;

    memcpy(&gAxVdecContext.pstAttr[VdGrp], pstAttr, sizeof(AX_VDEC_GRP_ATTR_S));

    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_CREATED;
    Grp_Num ++;

    ret = ioctl(gAxVdecContext.fd, HX170DEC_IOCG_DEBUG_FIFO_CREATE, &VdGrp);
    if (0 != ret) {
        VdecLog(SYS_LOG_ERROR, "Vdec Grp %d: create debug kfifo err.\n", VdGrp);
    }

    VdecLog(SYS_LOG_INFO, "AX_VDEC_CreateChn succeed, VdChn: %d\n", VdGrp);
    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_DestroyGrp(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (gAxVdecContext.enModStatus != VDEC_MOD_STATUS_INIT)
        return AX_ERR_VDEC_NOT_PERM;

    if (!gAxVdecContext.chns[VdGrp]) {
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_DestroyChn error: channel is start!\n");
        return AX_ERR_VDEC_NOT_PERM;
    }

    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_DESTROYING;

    /*if getframe API blocking,set end frame for blocking status exit*/
    if (gAxVdecContext.chns[VdGrp]->enType == PT_H264) {
        gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSetEndFrame(gAxVdecContext.chns[VdGrp]->pDecoder);
    }

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);
    pthread_mutex_lock(&gAxVdecContext.SendMutex[VdGrp]);
    pthread_mutex_lock(&gAxVdecContext.GetMutex[VdGrp]);
    pthread_mutex_lock(&gAxVdecContext.ReleaseMutex[VdGrp]);
    /* close decoder,this callback return success*/
    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnDestroyGrp(VdGrp, gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "pfnDestroyChn error: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);
        return ret;
    }

    if (gAxVdecContext.chns[VdGrp]->InputInfo.InStreamQueue != NULL) {
        AX_Vdec_Fifo_DeInit(gAxVdecContext.chns[VdGrp]->InputInfo.InStreamQueue);
        gAxVdecContext.chns[VdGrp]->InputInfo.InStreamQueue = NULL;
    }

    if (gAxVdecContext.chns[VdGrp]->InputInfo.pstInRingBuf != NULL) {
        Vdec_RingBuffer_Close(VdGrp, gAxVdecContext.chns[VdGrp]->InputInfo.pstInRingBuf);
        gAxVdecContext.chns[VdGrp]->InputInfo.pstInRingBuf = NULL;
    }

    ret = ioctl(gAxVdecContext.fd, HX170DEC_IOCG_DEBUG_FIFO_FREE, &VdGrp);
    if (0 != ret) {
        VdecLog(SYS_LOG_ERROR, "Vdec Grp %d: free debug kfifo err.\n", VdGrp);
    }

    pthread_mutex_destroy(&gAxVdecContext.chns[VdGrp]->InputInfo.InputDoneMutex);

    BspOsalFree(gAxVdecContext.chns[VdGrp]);
    gAxVdecContext.chns[VdGrp] = NULL;
    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_DESTROYED;
    Grp_Num --;

    pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);
    pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
    pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);

    VdecLog(SYS_LOG_INFO, "AX_VDEC_DestroyChn succeed, VdChn: %d\n", VdGrp);
    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetGrpAttr(AX_VDEC_GRP VdGrp, AX_VDEC_GRP_ATTR_S *pstAttr)
{
    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstAttr)
        return AX_ERR_VDEC_NULL_PTR;

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        return AX_ERR_VDEC_UNEXIST;
    }

    memcpy(&pstAttr, &gAxVdecContext.pstAttr[VdGrp], sizeof(AX_VDEC_GRP_ATTR_S));

    VdecLog(SYS_LOG_INFO, "AX_VDEC_GetChnAttr VdChn: %d\n", VdGrp);

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetGrpAttr(AX_VDEC_GRP VdGrp, const AX_VDEC_GRP_ATTR_S *pstAttr)
{
    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstAttr)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_SetChnAttr error: channel is start!\n");
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    memcpy(&gAxVdecContext.pstAttr[VdGrp], &pstAttr, sizeof(AX_VDEC_GRP_ATTR_S));
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    VdecLog(SYS_LOG_INFO, "AX_VDEC_SetChnAttr VdChn: %d\n", VdGrp);

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_StartRecvStream(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_SUCCESS;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnStartRecvStream(gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_StartRecvStream error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }

    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_STARTED;
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_StopRecvStream(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnStopRecvStream(gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_StopRecvStream error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }

    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_STOPPED;
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_QueryStatus(AX_VDEC_GRP VdGrp, AX_VDEC_GRP_STATUS_S *pstStatus)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstStatus)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnQueryStatus(gAxVdecContext.chns[VdGrp]->pDecoder, pstStatus);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_QueryStatus error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }

    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_ResetGrp(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnResetGrp(gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_ResetChn error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }

    gAxVdecContext.enChnStatus[VdGrp] = VDEC_CHN_STATUS_RESETED;
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetGrpParam(AX_VDEC_GRP VdGrp, const AX_VDEC_GRP_PARAM_S *pstParam)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstParam)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSetGrpParam(gAxVdecContext.chns[VdGrp]->pDecoder, pstParam);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_SetChnParam error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetGrpParam(AX_VDEC_GRP VdGrp, AX_VDEC_GRP_PARAM_S *pstParam)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstParam)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnGetGrpParam(gAxVdecContext.chns[VdGrp]->pDecoder, pstParam);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_GetChnParam error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetProtocolParam(AX_VDEC_GRP VdGrp, const AX_VDEC_PRTCL_PARAM_S *pstParam)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstParam)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSetProtocolParam(gAxVdecContext.chns[VdGrp]->pDecoder, pstParam);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_SetProtocolParam error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetProtocolParam(AX_VDEC_GRP VdGrp, AX_VDEC_PRTCL_PARAM_S *pstParam)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstParam)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnGetProtocolParam(gAxVdecContext.chns[VdGrp]->pDecoder, pstParam);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_GetProtocolParam error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

/* s32MilliSec: -1 is block,0 is no block,other positive number is timeout */
AX_VDEC_PUBLIC AX_S32 AX_VDEC_SendStream(AX_VDEC_GRP VdGrp, const AX_VDEC_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
    AX_S32 ret = AX_SUCCESS;
    int time_use = 0;
    struct timeval start_time, end_time;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstStream)
        return AX_ERR_VDEC_NULL_PTR;

    if (s32MilliSec < -1) {
        VdecLog(SYS_LOG_ERROR, "VdecGrp %d: SendStream Invalid s32MilliSec value(%d).\n", VdGrp, s32MilliSec);
        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    gettimeofday(&start_time, NULL);

    pthread_mutex_lock(&gAxVdecContext.SendMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] != VDEC_CHN_STATUS_STARTED) {
        VdecLog(SYS_LOG_ERROR, "%s error: channel is not start!\n",  __func__);
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.chns[VdGrp]->InputInfo.InStreamQueue == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s error: channel %d stream buffer is null!\n",  __func__, VdGrp);
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_NULL_PTR;
    }

    if (gAxVdecContext.chns[VdGrp]->InputInfo.pstInRingBuf == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s error: channel %d ring buffer is null!\n",  __func__, VdGrp);
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_NULL_PTR;
    }

    if (pstStream->u32Len > gAxVdecContext.chns[VdGrp]->InputInfo.pstInRingBuf->buffer_total_size) {
        VdecLog(SYS_LOG_ERROR, "%s error: send data len is bigger than buffer!\n",  __func__);
        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    if (s32MilliSec == -1) {
        ret = Vdec_BlockingDecode(gAxVdecContext.chns[VdGrp], pstStream);
    } else if (s32MilliSec == 0) {
        if (gAxVdecContext.chns[VdGrp]->enType == PT_JPEG){
            VdecLog(SYS_LOG_ERROR, "%s JDEC not support NonBlockingDecode \n",  __func__);
            pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
            return AX_ERR_VDEC_NOT_SUPPORT;
        } else {
            ret = Vdec_NonBlockingDecode(gAxVdecContext.chns[VdGrp], pstStream);
            if (ret != AX_SUCCESS) {
                VdecLog(SYS_LOG_ERROR, "%s Vdec_NonBlockingDecode err: 0x%x!\n",  __func__, ret);
                pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
                return ret;
            }
        }
    } else {
        if (gAxVdecContext.chns[VdGrp]->enType == PT_JPEG){
            VdecLog(SYS_LOG_ERROR, "%s JDEC not support timeout \n",  __func__);
            pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
            return AX_ERR_VDEC_NOT_SUPPORT;
        } else {
            while (1) {
                ret = Vdec_NonBlockingDecode(gAxVdecContext.chns[VdGrp], pstStream);
                if (ret == AX_ERR_VDEC_BUF_FULL) {
                    // sleep 1 ms to hand over cpu
                    usleep(1000);
                    gettimeofday(&end_time, NULL);
                    time_use = (end_time.tv_sec - start_time.tv_sec) * 1000 + (end_time.tv_usec - start_time.tv_usec) / 1000;
                    if (time_use >= s32MilliSec) {
                        VdecLog(SYS_LOG_WARN, "%s warn: send data timeout!\n",  __func__);
                        pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);
                        return AX_ERR_VDEC_TIMED_OUT;
                    }
                } else {
                    break;
                }
            }
        }  
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSendStream(gAxVdecContext.chns[VdGrp]->pDecoder, pstStream,
            s32MilliSec);

    gAxVdecContext.chns[VdGrp]->send_num ++;

    pthread_mutex_unlock(&gAxVdecContext.SendMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetFrame(AX_VDEC_GRP VdGrp, AX_VIDEO_FRAME_INFO_S *pstFrameInfo, AX_S32 s32MilliSec)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstFrameInfo)
        return AX_ERR_VDEC_NULL_PTR;

    if (s32MilliSec < -1) {
        VdecLog(SYS_LOG_ERROR, "VdecGrp %d: GetFrame Invalid s32MilliSec value(%d).\n", VdGrp, s32MilliSec);
        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    pthread_mutex_lock(&gAxVdecContext.GetMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnGetFrame(gAxVdecContext.chns[VdGrp]->pDecoder, pstFrameInfo,
            s32MilliSec);

    gAxVdecContext.chns[VdGrp]->get_num ++;

    pthread_mutex_unlock(&gAxVdecContext.GetMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_ReleaseFrame(AX_VDEC_GRP VdGrp, const AX_VIDEO_FRAME_INFO_S *pstFrameInfo)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstFrameInfo)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ReleaseMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnReleaseFrame(gAxVdecContext.chns[VdGrp]->pDecoder, pstFrameInfo);

    gAxVdecContext.chns[VdGrp]->release_num ++;

    pthread_mutex_unlock(&gAxVdecContext.ReleaseMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetUserData(AX_VDEC_GRP VdGrp, AX_VDEC_USERDATA_S *pstUserData, AX_S32 s32MilliSec)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstUserData)
        return AX_ERR_VDEC_NULL_PTR;

    if (s32MilliSec < -1) {
        VdecLog(SYS_LOG_ERROR, "VdecGrp %d: GetUserData Invalid s32MilliSec value(%d).\n", VdGrp, s32MilliSec);
        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnGetUserData(gAxVdecContext.chns[VdGrp]->pDecoder, pstUserData,
            s32MilliSec);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_GetUserData error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_ReleaseUserData(AX_VDEC_GRP VdGrp, const AX_VDEC_USERDATA_S *pstUserData)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstUserData)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnReleaseUserData(gAxVdecContext.chns[VdGrp]->pDecoder, pstUserData);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_ReleaseUserData error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetUserPic(AX_VDEC_GRP VdGrp, const AX_VIDEO_FRAME_INFO_S *pstUsrPic)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstUsrPic)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSetUserPic(gAxVdecContext.chns[VdGrp]->pDecoder, pstUsrPic);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_SetUserPic error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_EnableUserPic(AX_VDEC_GRP VdGrp, AX_BOOL bInstant)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_STARTED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnEnableUserPic(gAxVdecContext.chns[VdGrp]->pDecoder, bInstant);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_EnableUserPic error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_DisableUserPic(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnDisableUserPic(gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_DisableUserPic error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_JpegDecodeOneFrame(AX_JPEG_DECODE_ONCE_PARAMS *pstParam)
{
    const AX_VDEC_DECODER_S *pVdecDecoder = &gJdecDecoder;
    AX_S32 ret = AX_SUCCESS;
    if (!pstParam)
        return AX_ERR_VDEC_NULL_PTR;

    if (pstParam->u64StreamPhyAddr == 0
        || pstParam->pu8StreamVirAddr == NULL
        || pstParam->u32StreamLen == 0
        || pstParam->u64PhyAddr[0] == 0
        || pstParam->u64VirAddr[0] == 0
        || pstParam->u32Len[0] == 0
        || pstParam->u64PhyAddr[1] == 0
        || pstParam->u64VirAddr[1] == 0
        || pstParam->u32Len[1] == 0) {

        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    if (gAxVdecContext.enModStatus != VDEC_MOD_STATUS_INIT)
        return AX_ERR_VDEC_SYS_NOTREADY;

    pthread_mutex_lock(&gAxVdecContext.JpegDecMutex);
    ret = pVdecDecoder->pfnDecodeFrame(gAxVdecContext.dwlInst,pstParam);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_JpegDecOneFrame error code: %x\n", ret);
    }
    pthread_mutex_unlock(&gAxVdecContext.JpegDecMutex);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetDisplayMode(AX_VDEC_GRP VdGrp, AX_VDEC_DISPLAY_MODE_E enDisplayMode)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnSetDisplayMode(gAxVdecContext.chns[VdGrp]->pDecoder, enDisplayMode);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_SetDisplayMode error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetDisplayMode(AX_VDEC_GRP VdGrp, AX_VDEC_DISPLAY_MODE_E *penDisplayMode)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!penDisplayMode)
        return AX_ERR_VDEC_NULL_PTR;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnGetDisplayMode(gAxVdecContext.chns[VdGrp]->pDecoder,
            penDisplayMode);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_GetDisplayMode error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_AttachPool(AX_VDEC_GRP VdGrp, AX_POOL Pool)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (Pool == AX_INVALID_POOLID)
        return AX_ERR_VDEC_ILLEGAL_PARAM;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnAttachPool(gAxVdecContext.chns[VdGrp]->pDecoder, Pool);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_AttachVbPool error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_DetachPool(AX_VDEC_GRP VdGrp)
{
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    pthread_mutex_lock(&gAxVdecContext.ChannelMutex[VdGrp]);

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_INIT) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYING) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_NOT_PERM;
    }

    if (gAxVdecContext.enChnStatus[VdGrp] == VDEC_CHN_STATUS_DESTROYED) {
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return AX_ERR_VDEC_UNEXIST;
    }

    ret = gAxVdecContext.chns[VdGrp]->pVdecDecoder->pfnDetachPool(gAxVdecContext.chns[VdGrp]->pDecoder);
    if (ret != AX_SUCCESS) {
        VdecLog(SYS_LOG_ERROR, "AX_VDEC_DetachVbPool error code: %x\n", ret);
        pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);
        return ret;
    }
    pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[VdGrp]);

    return ret;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_Debug_Init()
{
    AX_S32 fd = -1;

    fd = open(VDEC_DEVICE_NAME, O_RDWR);
    if (fd == -1) {
        VdecLog(SYS_LOG_ERROR, "Open device ERROR: errno: %d\n", errno);
        return AX_ERR_VDEC_SYS_NOTREADY;
    }
    gVdec_Debug_Fd = fd;

    VdecLog(SYS_LOG_INFO, "AX_VDEC_Debug_Init successfully\n");

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_Debug_DeInit()
{
    if(gVdec_Debug_Fd != -1) {
        close(gVdec_Debug_Fd);
        gVdec_Debug_Fd = -1;
    }

    VdecLog(SYS_LOG_INFO, "AX_VDEC_Debug_DeInit successfully\n");

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_SetDebugFifoDepth(AX_VDEC_GRP VdGrp, AX_U32 u32FifoDepth)
{
    VDEC_DEBUG_INFO_S stVdecDebugInfo = {0};
    AX_S32 ret = AX_SUCCESS;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    stVdecDebugInfo.VdGrp = VdGrp;
    stVdecDebugInfo.fifoDepth = u32FifoDepth;

    ret = ioctl(gVdec_Debug_Fd, HX170DEC_IOCG_DEBUG_FIFO_DEPTH_SET, &stVdecDebugInfo);
    if (0 != ret) {
        VdecLog(SYS_LOG_ERROR, "Vdec Grp %d: debug fifo is empty.\n", VdGrp);
        return AX_ERR_VDEC_NOT_SUPPORT;
    }

    VdecLog(SYS_LOG_INFO, "AX_VDEC_SetDebugFIFODepth successfully GRP:%d\n", VdGrp);

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_GetDebugFifoFrame(AX_VDEC_GRP VdGrp, AX_VIDEO_FRAME_INFO_S *pstFrameInfo)
{
    AX_S32 ret = AX_SUCCESS;
    VDEC_DEBUG_INFO_S stVdecDebugInfo = {0};
    AX_FRAME_DESCRIPTOR_S *pstFrameDesc = NULL;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstFrameInfo)
        return AX_ERR_VDEC_NULL_PTR;

    stVdecDebugInfo.VdGrp = VdGrp;
    ret = ioctl(gVdec_Debug_Fd, HX170DEC_IOCG_DEBUG_FIFO_POP, &stVdecDebugInfo);
    if (0 != ret) {
        VdecLog(SYS_LOG_ERROR, "Vdec Grp %d: debug fifo is empty.\n", VdGrp);
        return AX_ERR_VDEC_BUF_EMPTY;
    }

    pstFrameDesc = (AX_FRAME_DESCRIPTOR_S *)AX_POOL_GetMetaVirAddr(stVdecDebugInfo.blockID);
    if (!pstFrameDesc) {
        VdecLog(SYS_LOG_ERROR, "Vdec Grp %d, failed to get frame info from metadata\n", VdGrp);
        return AX_ERR_VDEC_NULL_PTR;
    }

    memcpy(pstFrameInfo,&pstFrameDesc->stFrameInfo,sizeof(AX_VIDEO_FRAME_INFO_S));
    VdecLog(SYS_LOG_INFO, "AX_VDEC_GetDebugFrame successfully GRP:%d\n", VdGrp);

    return AX_SUCCESS;
}

AX_VDEC_PUBLIC AX_S32 AX_VDEC_ReleaseDebugFifoFrame(AX_VDEC_GRP VdGrp, const AX_VIDEO_FRAME_INFO_S *pstFrameInfo)
{
    AX_S32 s32Ret = AX_SUCCESS;
    AX_S32 modId = AX_ID_VDEC;
    AX_BLK u32BlkId = 0;

    if (VdGrp < 0 || VdGrp >= AX_VDEC_MAX_GRP_SIZE)
        return AX_ERR_VDEC_INVALID_CHNID;

    if (!pstFrameInfo)
        return AX_ERR_VDEC_NULL_PTR;

    u32BlkId = pstFrameInfo->stVFrame.u32BlkId[0];
    s32Ret = AX_POOL_DecreaseRefCnt_Inter(u32BlkId, modId);
    if (0 != s32Ret) {
        VdecLog(SYS_LOG_ERROR, "VDEC GRP: %d AX_POOL_DecreaseRefCnt_Inter err(0x%x).\n", VdGrp, s32Ret);
        return AX_ERR_VDEC_UNKNOWN;
    }

    VdecLog(SYS_LOG_INFO, "AX_VDEC_ReleaseDebugFrame successfully GRP:%d\n", VdGrp);

    return AX_SUCCESS;
}

static AX_S32 Vdec_SuspendResume_Callback(const AX_NOTIFY_EVENT_E event, AX_VOID *pdata)
{
    switch (event) {
    case AX_NOTIFY_EVENT_SLEEP:
        AX_SYS_WakeLock(AX_ID_VDEC);
        gVdecWaitUnlock = AX_TRUE;
        gVdecSuspendState = AX_TRUE;
        VdecSendSig();
        break;
    case AX_NOTIFY_EVENT_WAKEUP:
        gVdecSuspendState = AX_FALSE;
        VdecSendSig();
        break;
    default:
        VdecLog(SYS_LOG_ERROR, "suspend_resume event error\n");
        break;
    }

    return AX_SUCCESS;
}

static AX_S32 Jdec_SuspendResume_Callback(const AX_NOTIFY_EVENT_E event, AX_VOID *pdata)
{
    switch (event) {
    case AX_NOTIFY_EVENT_SLEEP:
        AX_SYS_WakeLock(AX_ID_JDEC);
        gJdecWaitUnlock = AX_TRUE;
        gJdecSuspendState = AX_TRUE;
        JdecSendSig();
        break;
    case AX_NOTIFY_EVENT_WAKEUP:
        gJdecSuspendState = AX_FALSE;
        JdecSendSig();
        break;
    default:
        VdecLog(SYS_LOG_ERROR, "suspend_resume event error\n");
        break;
    }

    return AX_SUCCESS;
}
void VdecProcCatCallback(char *msg, size_t msgMaxLen)
{
    int i;
    int len = 0;
    AX_S32 ret = AX_SUCCESS;

    len += snprintf(msg,
                msgMaxLen,
                "-------- MODULE PARAM ------------------------\n"
                "%-16s%-16s%-16s%-16s%-16s%-16s%-16s%-16s%-16s\n",
                "MaxGroupNum",
                "H264MaxPicWid",
                "H264MaxPicHei",
                "H264MinPicWid",
                "H264MinPicHei",
                "JPEGMaxPicWid",
                "JPEGMaxPicHei",
                "JPEGMinPicWid",
                "JPEGMinPicHei"
                );

    len += snprintf(msg + len,
                msgMaxLen - len,
                "%-16u%-16u%-16u%-16u%-16u%-16u%-16u%-16u%-16u\n",
                AX_VDEC_MAX_GRP_SIZE,
                H264_MAX_WIDTH,
                H264_MAX_HEIGHT,
                H264_MIN_WIDTH,
                H264_MIN_HEIGHT,
                JPEG_MAX_WIDTH,
                JPEG_MAX_HEIGHT,
                JPEG_MIN_WIDTH,
                JPEG_MIN_HEIGHT
                );

    len += snprintf(msg + len,
                msgMaxLen - len,
                "%-10s%-8s%-8s%-16s%-12s%-16s%-16s%-16s%-16s%-16s%-16s\n",
                "GroupID", "Fps", "DecType", "StreamBufSize", "GrpStatus", "FrameBufCnt",
                "SendFrameNum","GetFrameNum", "ReleaseFrameNum", "FreeOutBufNum",
                "BlkGetFailNum");

    for (i = 0; i < AX_VDEC_MAX_GRP_SIZE; i++) {
        ret = pthread_mutex_lock(&gAxVdecContext.ChannelMutex[i]);
        if (ret) {
            VdecLog(SYS_LOG_ERROR, "VDEC proc first pthread_mutex_lock error  Grp = %d, code: %x\n", i, ret);
            continue;
        }

        if (gAxVdecContext.chns[i]) {
            AX_F32 FrameRate = 0;
            struct proc_info ProcInfo = {0};
            FrameRate = gAxVdecContext.chns[i]->pVdecDecoder->pfnGetFrameRate(gAxVdecContext.chns[i]->pDecoder);
            gAxVdecContext.chns[i]->pVdecDecoder->pfnGetProcInfo(gAxVdecContext.chns[i]->pDecoder, &ProcInfo);
            len += snprintf(msg + len,
                        msgMaxLen - len,
                        "%-10u%-8.2f%-8u%-16u%-12u%-16u%-16llu%-16llu%-16llu%-16u%-16u\n",
                        i,
                        FrameRate,
                        gAxVdecContext.chns[i]->enType,
                        gAxVdecContext.pstAttr[i].u32StreamBufSize,
                        gAxVdecContext.enChnStatus[i],
                        gAxVdecContext.pstAttr[i].u32FrameBufCnt,
                        gAxVdecContext.chns[i]->send_num,
                        gAxVdecContext.chns[i]->get_num,
                        gAxVdecContext.chns[i]->release_num,
                        ProcInfo.free_buf_num,
                        ProcInfo.block_fail_num);
        }

        ret = pthread_mutex_unlock(&gAxVdecContext.ChannelMutex[i]);
        if (ret) {
            VdecLog(SYS_LOG_ERROR, "VDEC proc first pthread_mutex_unlock error  Grp = %d, code: %x\n", i, ret);
        }
    }
}

