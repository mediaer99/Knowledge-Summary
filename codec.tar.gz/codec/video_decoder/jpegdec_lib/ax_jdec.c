/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/


#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "trace.h"
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/ioctl.h>

#include "jpegdecapi.h"
#include "dwl.h"
#include "jpegdeccontainer.h"
#include "deccfg.h"
#include "tb_cfg.h"
#include "regdrv.h"
#include "tb_sw_performance.h"

#include "ax_vdec_api.h"
#include "ax_vdec_interface.h"
#include "vdec_log.h"
#include "bsp_osal.h"
#include "hx170dec.h"
#include "ax_sys_api_internal.h"

typedef struct {
    JpegDecInst jpeg;
    DWLLinearMem_t streamMem;
    DWLLinearMem_t frameMem;
    DWLLinearMem_t uvMem;
    AX_VDEC_GRP VdGrp;
    AX_BOOL bRunning;
    AX_BOOL bStreamReady;
    u32 streamInfoCheck;
    u32 nbrOfImagesTotal;
    u32 nbrOfImages;
    u32 nbrOfThumbImagesTotal;
    u32 nbrOfThumbImages;
    AX_U8 *byteStrmStart;
    u32 streamInFile;
    AX_BOOL bEofReady;
    AX_U32 u32StreamLength;
    pthread_mutex_t consumerMutex;
    pthread_cond_t consumerCond;
    AX_BOOL bEndOfStream;
    JpegDecImageInfo imageInfo;
    JpegDecOutput jpegOut;
    int yuvAvaliable;
    AX_S32 lastDecodeStatus;
    AxVdecInput *InputInfo;       /* input stream FIFO */

    AX_PAYLOAD_TYPE_E enType;              /* RW; video type to be decoded   */
    AX_VDEC_MODE_E enMode;              /* RW; send by stream or by frame */
    AX_U32 u32PicWidth;         /* RW; max pic width */
    AX_U32 u32PicHeight;        /* RW; max pic height */
    AX_U32 u32StreamBufSize;    /* RW; stream buffer size(Byte) */
    AX_U32 u32FrameBufSize;     /* RW; frame buffer size(Byte) */
    AX_U32 u32FrameBufCnt;
    AX_POOL sPoolId;
    AX_U32 output_pic_num;
    AX_U32 old_output_pic_num;
    AX_U32 block_fail_num;
    struct timespec timer_record;
    AX_LINK_MODE_E enLinkMode;
} AxJdecCtx;

static AxJdecCtx *gJdecCtxs[AX_VDEC_MAX_GRP_SIZE] = { NULL };
static pthread_mutex_t gJdecDestoryMutex[AX_VDEC_MAX_GRP_SIZE] = { PTHREAD_MUTEX_INITIALIZER };

static pthread_mutex_t gJdecWorkingMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t gJdecWorkingCond = PTHREAD_COND_INITIALIZER;
static AX_BOOL gJdecWorkingThreadRun = AX_FALSE;
static pthread_t gJdecWorkingThreadTid = 0;

extern AX_BOOL gJdecSuspendState;
extern AX_BOOL gJdecWaitUnlock;
static JpegDecInst gJdecJpeg;

void PrintJpegRet(JpegDecRet *pJpegRet)
{

    assert(pJpegRet);

    switch (*pJpegRet) {
    case JPEGDEC_FRAME_READY:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_FRAME_READY\n");
        break;
    case JPEGDEC_OK:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_OK\n");
        break;
    case JPEGDEC_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_ERROR\n");
        break;
    case JPEGDEC_DWL_HW_TIMEOUT:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_HW_TIMEOUT\n");
        break;
    case JPEGDEC_UNSUPPORTED:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_UNSUPPORTED\n");
        break;
    case JPEGDEC_PARAM_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_PARAM_ERROR\n");
        break;
    case JPEGDEC_MEMFAIL:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_MEMFAIL\n");
        break;
    case JPEGDEC_INITFAIL:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_INITFAIL\n");
        break;
    case JPEGDEC_HW_BUS_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_HW_BUS_ERROR\n");
        break;
    case JPEGDEC_SYSTEM_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_SYSTEM_ERROR\n");
        break;
    case JPEGDEC_DWL_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_DWL_ERROR\n");
        break;
    case JPEGDEC_INVALID_STREAM_LENGTH:
        VdecLog(SYS_LOG_ERROR,
                "TB: jpeg API returned : JPEGDEC_INVALID_STREAM_LENGTH\n");
        break;
    case JPEGDEC_STRM_ERROR:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned : JPEGDEC_STRM_ERROR\n");
        break;
    case JPEGDEC_INVALID_INPUT_BUFFER_SIZE:
        VdecLog(SYS_LOG_ERROR,
                "TB: jpeg API returned : JPEGDEC_INVALID_INPUT_BUFFER_SIZE\n");
        break;
    case JPEGDEC_INCREASE_INPUT_BUFFER:
        VdecLog(SYS_LOG_ERROR,
                "TB: jpeg API returned : JPEGDEC_INCREASE_INPUT_BUFFER\n");
        break;
    case JPEGDEC_SLICE_MODE_UNSUPPORTED:
        VdecLog(SYS_LOG_ERROR,
                "TB: jpeg API returned : JPEGDEC_SLICE_MODE_UNSUPPORTED\n");
        break;
    default:
        VdecLog(SYS_LOG_ERROR, "TB: jpeg API returned unknown status\n");
        break;
    }
}

/*-----------------------------------------------------------------------------

    Function name:  FindImageEnd

    Purpose:
        Finds 0xFFD9 from the stream and pOffset includes number of bytes to
        this marker. In case of an error returns != 0
        (i.e., the marker not found).

-----------------------------------------------------------------------------*/
u32 FindImageEnd(AxJdecCtx *pJdecCtx, u8 *pStream, u32 streamLength, u32 *pOffset)
{
    u32 i, j;
    u32 jpegThumbInStream = 0;
    u32 tmp, tmp1, tmpTotal = 0;
    u32 lastMarker = 0;

    for (i = 0; i < streamLength; ++i) {
        if (0xFF == pStream[i]) {
            /* if 0xFFE1 to 0xFFFD ==> skip  */
            if ((((i + 1) < streamLength) && 0xE1 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE2 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE3 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE4 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE5 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE6 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE7 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE8 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xE9 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xEA == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xEB == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xEC == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xED == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xEE == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xEF == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF0 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF1 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF2 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF3 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF4 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF5 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF6 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF7 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF8 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xF9 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xFA == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xFB == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xFC == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xFD == pStream[i + 1])) {
                /* increase counter */
                i += 2;

                /* check length vs. data */
                if ((i + 1) > (streamLength))
                    return (-1);

                /* get length */
                tmp = pStream[i];
                tmp1 = pStream[i + 1];
                tmpTotal = (tmp << 8) | tmp1;

                /* check length vs. data */
                if ((tmpTotal + i) > (streamLength))
                    return (-1);
                /* update */
                i += tmpTotal - 1;
                continue;
            }

            /* if 0xFFC2 to 0xFFCB ==> skip  */
            if ((((i + 1) < streamLength) && 0xC1 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC2 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC3 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC5 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC6 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC7 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC8 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xC9 == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xCA == pStream[i + 1]) ||
                (((i + 1) < streamLength) && 0xCB == pStream[i + 1])) {
                /* increase counter */
                i += 2;

                /* check length vs. data */
                if ((i + 1) > (streamLength))
                    return (-1);

                /* increase counter */
                i += 2;

                /* check length vs. data */
                if ((i + 1) > (streamLength))
                    return (-1);

                /* get length */
                tmp = pStream[i];
                tmp1 = pStream[i + 1];
                tmpTotal = (tmp << 8) | tmp1;

                /* check length vs. data */
                if ((tmpTotal + i) > (streamLength))
                    return (-1);
                /* update */
                i += tmpTotal - 1;

                /* look for EOI */
                for (j = i; j < streamLength; ++j) {
                    if (0xFF == pStream[j]) {
                        /* EOI */
                        if (((j + 1) < streamLength) && 0xD9 == pStream[j + 1]) {
                            /* check length vs. data */
                            if ((j + 2) >= (streamLength)) {
                                pJdecCtx->nbrOfImagesTotal = pJdecCtx->nbrOfImages;
                                pJdecCtx->nbrOfThumbImagesTotal = pJdecCtx->nbrOfThumbImages;
                                return (0);
                            }
                            /* update */
                            i = j;
                            /* stil data left ==> continue */
                            continue;
                        }
                    }
                }
            }

            /* check if thumbnails in stream */
            if (((i + 1) < streamLength) && 0xE0 == pStream[i + 1]) {
                if (((i + 9) < streamLength) &&
                    0x4A == pStream[i + 4] &&
                    0x46 == pStream[i + 5] &&
                    0x58 == pStream[i + 6] &&
                    0x58 == pStream[i + 7] &&
                    0x00 == pStream[i + 8] &&
                    0x10 == pStream[i + 9]) {
                    jpegThumbInStream = 1;
                }
                lastMarker = 1;
            }

            /* EOI */
            if (((i + 1) < streamLength) && 0xD9 == pStream[i + 1]) {
                *pOffset = i;
                /* update amount of thumbnail or full resolution image */
                if (jpegThumbInStream) {
                    pJdecCtx->nbrOfThumbImages++;
                    jpegThumbInStream = 0;
                } else
                    pJdecCtx->nbrOfImages++;

                lastMarker = 2;
            }
        }
    }

    /* update total amount of pictures */
    pJdecCtx->nbrOfImagesTotal = pJdecCtx->nbrOfImages;
    pJdecCtx->nbrOfThumbImagesTotal = pJdecCtx->nbrOfThumbImages;

    /* continue until amount of frames counted */
    if (lastMarker == 2)
        return 0;
    else
        return -1;
}

/*-----------------------------------------------------------------------------

    Function name:  FindImageTnEOI

    Purpose:
        Finds 0xFFD9 and next 0xFFE0 (containing THUMB) from the stream and
        pOffset includes number of bytes to this marker. In case of an error
        returns != 0 (i.e., the marker not found).

-----------------------------------------------------------------------------*/
u32 FindImageTnEOI(u8 *pStream, u32 streamLength, u32 *pOffset, u32 mode, u32 thumbExist)
{
    u32 i, j, k;
    u32 h = 0;
    u32 tmp, tmp1, tmpTotal = 0;

    /* reset */

    for (i = 0; i < streamLength; ++i) {
        if (0xFF == pStream[i]) {
            if (((i + 1) < streamLength) && 0xD9 == pStream[i + 1]) {
                if (thumbExist) {
                    for (j = (i + 2); j < streamLength; ++j) {
                        if (0xFF == pStream[j]) {
                            /* seek for next thumbnail in stream */
                            if (((j + 1) < streamLength) && 0xE0 == pStream[j + 1]) {
                                if (((j + 9) < streamLength) &&
                                    0x4A == pStream[j + 4] &&
                                    0x46 == pStream[j + 5] &&
                                    0x58 == pStream[j + 6] &&
                                    0x58 == pStream[j + 7] &&
                                    0x00 == pStream[j + 8] &&
                                    0x10 == pStream[j + 9]) {
                                    *pOffset = h;
                                    return 0;
                                }
                            } else if (((j + 1) < streamLength) && 0xD9 == pStream[j + 1]) {
                                k = j + 2;
                                /* return if FULL */
                                if (!mode) {
                                    *pOffset = k;
                                    return 0;
                                }
                            } else if (((j + 1) < streamLength) && 0xD8 == pStream[j + 1]) {
                                if (j) {
                                    h = j;
                                }
                            }
                        }
                    }

                    /* if no THUMB, but found next SOI ==> return */
                    if (h) {
                        *pOffset = h;
                        return 0;
                    } else
                        return -1;
                } else {
                    *pOffset = i + 2;
                    return 0;
                }
            }
            /* if 0xFFE1 to 0xFFFD ==> skip  */
            else if ((((i + 1) < streamLength) && 0xE1 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE2 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE3 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE4 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE5 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE6 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE7 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE8 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xE9 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xEA == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xEB == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xEC == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xED == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xEE == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xEF == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF0 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF1 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF2 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF3 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF4 == pStream[i + 1])||
                     (((i + 1) < streamLength) && 0xF5 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF6 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF7 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF8 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xF9 == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xFA == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xFB == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xFC == pStream[i + 1]) ||
                     (((i + 1) < streamLength) && 0xFD == pStream[i + 1])) {
                /* increase counter */
                i += 2;
                /* check length vs. data */
                if ((i + 1) > (streamLength))
                    return (-1);

                /* get length */
                tmp = pStream[i];
                tmp1 = pStream[i + 1];
                tmpTotal = (tmp << 8) | tmp1;

                /* check length vs. data */
                if ((tmpTotal + i) > (streamLength))
                    return (-1);
                /* update */
                i += tmpTotal - 1;
                continue;
            }
        }
    }
    return -1;
}

AX_S32 JdecCreateGrp(AX_VDEC_GRP VdGrp, const AX_VDEC_GRP_ATTR_S *pstAttr, AX_VOID **ppDecoder, const void *dwlInst,
                     AxVdecInput *InputInfo)
{
    JpegDecApiVersion decVer;
    JpegDecBuild decBuild;

    decVer = JpegDecGetAPIVersion();
    decBuild = JpegDecGetBuild();
    VdecLog(SYS_LOG_DEBUG,
            "\nX170 JPEG Decoder API v%d.%d - SW build: %d - HW build: %x\n",
            decVer.major, decVer.minor, decBuild.swBuild, decBuild.hwBuild);

    AxJdecCtx *pJdecCtx = BspOsalMalloc(sizeof(AxJdecCtx));
    if (!pJdecCtx) {
        VdecLog(SYS_LOG_ERROR, "malloc error\n");
        return AX_ERR_VDEC_NOMEM;
    }
    memset(pJdecCtx, 0, sizeof(AxJdecCtx));
    pJdecCtx->enType = pstAttr->enType;
    pJdecCtx->enMode = pstAttr->enMode;
    pJdecCtx->u32PicWidth = pstAttr->u32PicWidth;
    pJdecCtx->u32PicHeight = pstAttr->u32PicHeight;
    pJdecCtx->u32StreamBufSize = pstAttr->u32StreamBufSize;
    pJdecCtx->u32FrameBufSize = pstAttr->u32FrameBufSize;
    pJdecCtx->u32FrameBufCnt = pstAttr->u32FrameBufCnt;
    pJdecCtx->InputInfo = InputInfo;
    pJdecCtx->enLinkMode = pstAttr->enLinkMode;
    pJdecCtx->sPoolId = AX_INVALID_POOLID;

    // init instance
    JpegDecRet jpegRet;
    jpegRet = JpegDecInit(&pJdecCtx->jpeg, dwlInst);
    if (jpegRet != JPEGDEC_OK) {
        PrintJpegRet(&jpegRet);
        BspOsalFree(pJdecCtx);
        return AX_ERR_VDEC_RUN_ERROR;
    }

    // alloc input buffer
    /*if(DWLMallocLinear
       (((JpegDecContainer *) pJdecCtx->jpeg)->dwl, pJdecCtx->u32StreamBufSize, &pJdecCtx->streamMem) != DWL_OK) {
        VdecLog(SYS_LOG_ERROR, "alloc streamMem error\n");
        JpegDecRelease(pJdecCtx->jpeg);
        BspOsalFree(pJdecCtx);
        return AX_ERR_VDEC_NOMEM;
    }
    VdecLog(SYS_LOG_DEBUG, "alloc streamMem: virt: 0x%16x bus: 0x%16x\n",
            (g1_addr_t)pJdecCtx->streamMem.virtualAddress, pJdecCtx->streamMem.busAddress);
    DWLmemset(pJdecCtx->streamMem.virtualAddress, 0, pJdecCtx->u32StreamBufSize);*/
#if 0
    // alloc output buffer
    if (DWLMallocLinear
        (((JpegDecContainer *) pJdecCtx->jpeg)->dwl, pJdecCtx->u32FrameBufSize,
         &pJdecCtx->frameMem) != DWL_OK) {
        VdecLog(SYS_LOG_ERROR, "alloc frameMem error\n");
        if (pJdecCtx->streamMem.virtualAddress != NULL)
            DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->streamMem);
        JpegDecRelease(pJdecCtx->jpeg);
        BspOsalFree(pJdecCtx);
        return AX_ERR_VDEC_NOMEM;
    }
    VdecLog(SYS_LOG_DEBUG, "alloc frameMem: virt: 0x%16x bus: 0x%16x\n",
            (g1_addr_t)pJdecCtx->frameMem.virtualAddress, pJdecCtx->frameMem.busAddress);
    DWLmemset(pJdecCtx->frameMem.virtualAddress, 0, pJdecCtx->u32FrameBufSize);

    // alloc uvMem
    if (DWLMallocLinear
        (((JpegDecContainer *) pJdecCtx->jpeg)->dwl, pJdecCtx->u32FrameBufSize,
         &pJdecCtx->uvMem) != DWL_OK) {
        VdecLog(SYS_LOG_ERROR, "alloc uvMem error\n");
        if (pJdecCtx->streamMem.virtualAddress != NULL)
            DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->streamMem);
        if (pJdecCtx->frameMem.virtualAddress != NULL)
            DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->frameMem);
        JpegDecRelease(pJdecCtx->jpeg);
        BspOsalFree(pJdecCtx);
        return AX_ERR_VDEC_NOMEM;
    }
    VdecLog(SYS_LOG_DEBUG, "alloc uvMem: virt: 0x%16x bus: 0x%16x\n",
            (g1_addr_t)pJdecCtx->uvMem.virtualAddress, pJdecCtx->uvMem.busAddress);
    DWLmemset(pJdecCtx->uvMem.virtualAddress, 0, pJdecCtx->u32FrameBufSize);
#endif
    pJdecCtx->VdGrp = VdGrp;
    pJdecCtx->bRunning = AX_FALSE;
    pJdecCtx->bStreamReady = AX_FALSE;
    pJdecCtx->streamInfoCheck = 0;
    pJdecCtx->nbrOfImagesTotal = 0;
    pJdecCtx->nbrOfImages = 0;
    pJdecCtx->nbrOfThumbImagesTotal = 0;
    pJdecCtx->nbrOfThumbImages = 0;
    pJdecCtx->byteStrmStart = NULL;
    pJdecCtx->streamInFile = 0;
    pJdecCtx->bEofReady = AX_FALSE;
    pJdecCtx->u32StreamLength = 0;
    pthread_mutex_init(&pJdecCtx->consumerMutex, NULL);
    pthread_cond_init(&pJdecCtx->consumerCond, NULL);
    pJdecCtx->bEndOfStream = AX_FALSE;
    pJdecCtx->yuvAvaliable = 0;

    pthread_mutex_lock(&gJdecWorkingMutex);
    gJdecCtxs[pJdecCtx->VdGrp] = pJdecCtx;
    pthread_mutex_unlock(&gJdecWorkingMutex);
    *ppDecoder = pJdecCtx;
    return AX_SUCCESS;
}

AX_S32 JdecDestroyGrp(AX_VDEC_GRP VdGrp, AX_VOID *pDecoder)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    // release instance
    JpegDecRelease(pJdecCtx->jpeg);

    // release input buffer
    /*if(pJdecCtx->streamMem.virtualAddress != NULL)
        DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->streamMem);*/
#if 0
    // release output buffer
    if (pJdecCtx->frameMem.virtualAddress != NULL)
        DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->frameMem);

    // release uvMem
    if (pJdecCtx->uvMem.virtualAddress != NULL)
        DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->uvMem);
#endif
    pthread_mutex_destroy(&pJdecCtx->consumerMutex);
    pthread_cond_destroy(&pJdecCtx->consumerCond);

    assert(pJdecCtx->VdGrp == VdGrp);
    pthread_mutex_lock(&gJdecWorkingMutex);
    pthread_mutex_lock(&gJdecDestoryMutex[VdGrp]);
    gJdecCtxs[pJdecCtx->VdGrp] = NULL;
    pthread_mutex_unlock(&gJdecDestoryMutex[VdGrp]);
    pthread_mutex_unlock(&gJdecWorkingMutex);
    BspOsalFree(pJdecCtx);
    return AX_SUCCESS;
}

AX_S32 JdecGetGrpAttr(AX_VOID *pDecoder, AX_VDEC_GRP_ATTR_S *pstAttr)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecSetGrpAttr(AX_VOID *pDecoder, const AX_VDEC_GRP_ATTR_S *pstAttr)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecStartRecvStream(AX_VOID *pDecoder)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    /*here for frame rate parameter clear*/
    pJdecCtx->output_pic_num = 0;
    pJdecCtx->old_output_pic_num = 0;
    pJdecCtx->timer_record.tv_sec = 0;
    pJdecCtx->timer_record.tv_nsec = 0;

    pthread_mutex_lock(&gJdecWorkingMutex);
    pJdecCtx->bRunning = AX_TRUE;
    pthread_cond_broadcast(&gJdecWorkingCond);
    pthread_mutex_unlock(&gJdecWorkingMutex);
    return AX_SUCCESS;
}

AX_S32 JdecStopRecvStream(AX_VOID *pDecoder)
{
    AxJdecCtx *pJdecCtx = pDecoder;
    pthread_mutex_lock(&gJdecWorkingMutex);
    pJdecCtx->bRunning = AX_FALSE;
    pthread_mutex_unlock(&gJdecWorkingMutex);
    return AX_SUCCESS;
}

AX_S32 JdecQueryStatus(AX_VOID *pDecoder, AX_VDEC_GRP_STATUS_S *pstStatus)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecResetGrp(AX_VOID *pDecoder)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecSetGrpParam(AX_VOID *pDecoder, const AX_VDEC_GRP_PARAM_S *pstParam)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecGetGrpParam(AX_VOID *pDecoder, AX_VDEC_GRP_PARAM_S *pstParam)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecSetProtocolParam(AX_VOID *pDecoder, const AX_VDEC_PRTCL_PARAM_S *pstParam)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecGetProtocolParam(AX_VOID *pDecoder, AX_VDEC_PRTCL_PARAM_S *pstParam)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecSetFrameInfo(AxJdecCtx *pJdecCtx, VDEC_FRAME_PARAM_S *stVdecFrameInfo)
{
    AX_VIDEO_FRAME_INFO_S *pstFrameInfo = &stVdecFrameInfo->stFrameInfo;

    pstFrameInfo->stVFrame.u64PhyAddr[0] = pJdecCtx->jpegOut.outputPictureY.busAddress + VDEC_ADDR_OFFSET;
    pstFrameInfo->stVFrame.u64PhyAddr[1] = pJdecCtx->jpegOut.outputPictureCbCr.busAddress + VDEC_ADDR_OFFSET;
    pstFrameInfo->stVFrame.u64PhyAddr[2] = 0;
    pstFrameInfo->stVFrame.u64VirAddr[0] = 0;
    pstFrameInfo->stVFrame.u64VirAddr[1] = 0;
    pstFrameInfo->stVFrame.u64VirAddr[2] = 0;
    pstFrameInfo->stVFrame.u32Width = pJdecCtx->imageInfo.displayWidth;
    pstFrameInfo->stVFrame.u32Height = pJdecCtx->imageInfo.displayHeight;
    pstFrameInfo->stVFrame.u32PicStride[0] = pJdecCtx->imageInfo.outputWidth;
    pstFrameInfo->stVFrame.u32PicStride[1]  = pJdecCtx->imageInfo.outputWidth;
    pstFrameInfo->stVFrame.u32PicStride[2]  = 0;
    pstFrameInfo->stVFrame.u32BlkId[0] = pJdecCtx->frameMem.BlkId;
    pstFrameInfo->stVFrame.u32BlkId[1] = 0;
    pstFrameInfo->stVFrame.u32BlkId[2] = 0;
    pstFrameInfo->stVFrame.s16OffsetTop = 0;
    pstFrameInfo->stVFrame.s16OffsetBottom = 0;
    pstFrameInfo->stVFrame.s16OffsetLeft = 0;
    pstFrameInfo->stVFrame.s16OffsetRight = 0;

    pstFrameInfo->stVFrame.enImgFormat = AX_YUV420_SEMIPLANAR;
    pstFrameInfo->bEof = AX_FALSE;
    stVdecFrameInfo->VdGrp = pJdecCtx->VdGrp;

    return AX_SUCCESS;
}

AX_S32 JdecPutLinkInfo(AxJdecCtx *pJdecCtx)
{
    AX_S32 ret = 0;
    VDEC_FRAME_PARAM_S stVdecFrameInfo = {0};

    JdecSetFrameInfo(pJdecCtx, &stVdecFrameInfo);
    ret = ioctl(pJdecCtx->InputInfo->VdecFd, HX170DEC_IOCG_LINK_PUT, &stVdecFrameInfo);
    if (0 != ret) {
        VdecLog(SYS_LOG_ERROR, "Jdec %d: destroy output frame error.\n", pJdecCtx->VdGrp);
        return AX_ERR_VDEC_RUN_ERROR;
    }

    return AX_SUCCESS;
}

static AX_S32 JdecSendFrameInfoToDebugFifo(AxJdecCtx *pJdecCtx)
{
    AX_S32 s32Ret = -1;
    VDEC_FRAME_PARAM_S stVdecFrameInfo = {0};

    JdecSetFrameInfo(pJdecCtx, &stVdecFrameInfo);
    s32Ret = ioctl(pJdecCtx->InputInfo->VdecFd, HX170DEC_IOCG_DEBUG_FIFO_PUSH, &stVdecFrameInfo);
    if (s32Ret != 0) {
        VdecLog(SYS_LOG_ERROR, "Vdec %d: Vdec_SendDebugInfo error.\n", pJdecCtx->VdGrp);
        return AX_ERR_VDEC_RUN_ERROR;
    }

    return AX_SUCCESS;
}

AX_S32 JdecDecode(AxJdecCtx *pJdecCtx)
{
    JpegDecRet jpegRet;
    AX_S32 ret = 0;
    AX_S32 retry_count = 10;

    if (!pJdecCtx->streamInfoCheck) {
        VdecLog(SYS_LOG_DEBUG, "CHECK THE CONTENT OF STREAM BEFORE ACTIONS\n");
        pJdecCtx->byteStrmStart = (AX_U8 *)pJdecCtx->streamMem.virtualAddress;
        pJdecCtx->streamInFile = pJdecCtx->u32StreamLength;
        if (pJdecCtx->enMode == VIDEO_MODE_FRAME) {
            pJdecCtx->nbrOfImagesTotal = 1;
            pJdecCtx->nbrOfImages = 1;
            pJdecCtx->nbrOfThumbImagesTotal = 0;
            pJdecCtx->nbrOfThumbImages = 0;
        } else {
            u32 imageInfoLength;
            jpegRet = FindImageEnd(pJdecCtx, pJdecCtx->byteStrmStart, pJdecCtx->u32StreamLength, &imageInfoLength);
            if (jpegRet != 0) {
                VdecLog(SYS_LOG_DEBUG, "EOI missing from end of file!\n");
            }
        }

        VdecLog(SYS_LOG_DEBUG, "CHECK THE CONTENT OF STREAM BEFORE ACTIONS successful\n");
        VdecLog(SYS_LOG_DEBUG, "pJdecCtx->nbrOfImages: %u\n", pJdecCtx->nbrOfImages);
        pJdecCtx->streamInfoCheck = 1;
    }

    JpegDecInput jpegIn;
    jpegIn.streamBuffer.pVirtualAddress = (u32 *)pJdecCtx->byteStrmStart;
    jpegIn.streamBuffer.busAddress = pJdecCtx->streamMem.busAddress + (g1_addr_t)pJdecCtx->byteStrmStart -
                                     (g1_addr_t)pJdecCtx->streamMem.virtualAddress;
    jpegIn.streamLength = pJdecCtx->streamInFile;
    jpegIn.bufferSize = 0;
    jpegIn.decImageType = JPEGDEC_IMAGE;
    jpegIn.sliceMbSet = 0;

    jpegRet = JpegDecGetImageInfo(pJdecCtx->jpeg, &jpegIn, &pJdecCtx->imageInfo);
    if (jpegRet != JPEGDEC_OK) {
        pJdecCtx->nbrOfImages = 0;
        PrintJpegRet(&jpegRet);
        return AX_ERR_VDEC_STRM_ERROR;
    }

    VdecLog(SYS_LOG_DEBUG, "JdecDecode displayWidth: %d, displayHeight: %d\n"
        "outputWidth: %d, outputHeight: %d\n"
        "displayWidthThumb: %d, displayHeightThumb: %d\n"
        "outputWidthThumb: %d, outputHeightThumb: %d\n"
        "outputFormat: %d,codingMode: %d\n",
        pJdecCtx->imageInfo.displayWidth, pJdecCtx->imageInfo.displayHeight,
        pJdecCtx->imageInfo.outputWidth, pJdecCtx->imageInfo.outputHeight,
        pJdecCtx->imageInfo.displayWidthThumb, pJdecCtx->imageInfo.displayHeightThumb,
        pJdecCtx->imageInfo.outputWidthThumb, pJdecCtx->imageInfo.outputHeightThumb,
        pJdecCtx->imageInfo.outputFormat, pJdecCtx->imageInfo.codingMode);

    // alloc output buffer,used pool memory
    pJdecCtx->frameMem.mem_type = DWL_MEM_TYPE_POOL;
    pJdecCtx->frameMem.PoolId = pJdecCtx->sPoolId;
    pJdecCtx->u32FrameBufSize = (pJdecCtx->imageInfo.outputWidth *
        pJdecCtx->imageInfo.outputHeight) * 3 / 2;

    retry:
    ret = DWLMallocLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl,
         pJdecCtx->u32FrameBufSize, &pJdecCtx->frameMem, AX_ID_JDEC);
    if (ret != DWL_OK) {
        pJdecCtx->block_fail_num++;
        retry_count--;
        VdecLog(SYS_LOG_ERROR, "alloc frameMem error\n");
        if (!retry_count) {
            pJdecCtx->nbrOfImages = 0;
            return AX_ERR_VDEC_NOMEM;
        }
        usleep(1000);
        goto retry;
    }

    VdecLog(SYS_LOG_DEBUG, "alloc frameMem: virt: 0x%16x bus: 0x%16x\n",
        (g1_addr_t)pJdecCtx->frameMem.virtualAddress, pJdecCtx->frameMem.busAddress);
    //end pool memory alloc

    jpegIn.pictureBufferY.pVirtualAddress = pJdecCtx->frameMem.virtualAddress;
    jpegIn.pictureBufferY.busAddress = pJdecCtx->frameMem.busAddress;

    pJdecCtx->uvMem.virtualAddress = pJdecCtx->frameMem.virtualAddress +
        pJdecCtx->imageInfo.outputHeight * pJdecCtx->imageInfo.outputWidth;
    pJdecCtx->uvMem.busAddress = pJdecCtx->frameMem.busAddress +
        pJdecCtx->imageInfo.outputHeight * pJdecCtx->imageInfo.outputWidth;
    jpegIn.pictureBufferCbCr.pVirtualAddress = pJdecCtx->uvMem.virtualAddress;
    jpegIn.pictureBufferCbCr.busAddress = pJdecCtx->uvMem.busAddress;

    jpegRet = JpegDecDecode(pJdecCtx->jpeg, &jpegIn, &pJdecCtx->jpegOut);
    if (jpegRet == JPEGDEC_FRAME_READY) {
        VdecLog(SYS_LOG_DEBUG, "JPEGDEC_FRAME_READY\n");
        VdecLog(SYS_LOG_DEBUG, "Luma output bus: 0x%16x\n",
                (u8 *) pJdecCtx->jpegOut.outputPictureY.busAddress);
        VdecLog(SYS_LOG_DEBUG, "Chroma output bus: 0x%16x\n",
                (u8 *) pJdecCtx->jpegOut.outputPictureCbCr.busAddress);
        ret = JdecSendFrameInfoToDebugFifo(pJdecCtx);
        if (ret) {
            VdecLog(SYS_LOG_ERROR, "JdecSendFrameInfoToDebugFifo error\n");
        }

        if (pJdecCtx->enLinkMode == AX_LINK_MODE) {
            ret = JdecPutLinkInfo(pJdecCtx);
            if (ret != AX_SUCCESS) {
                VdecLog(SYS_LOG_ERROR, "JdecPutLinkInfo error\n");
            }
            ret = AX_POOL_ReleaseBlock_Inter(pJdecCtx->frameMem.BlkId, AX_ID_JDEC);
            if (0 != ret) {
                VdecLog(SYS_LOG_ERROR, "JDEC AX_POOL_ReleaseBlock_Inter err(0x%x).\n", ret);
            }
        }

    } else if (jpegRet == JPEGDEC_STRM_ERROR) {
        pJdecCtx->nbrOfImages = 0;
        VdecLog(SYS_LOG_DEBUG, "JPEGDEC_STRM_ERROR\n");
        // release instance
        JpegDecRelease(pJdecCtx->jpeg);
        // init instance
        jpegRet = JpegDecInit(&pJdecCtx->jpeg, ((JpegDecContainer *) pJdecCtx->jpeg)->dwl);
        if (jpegRet != JPEGDEC_OK) {
            VdecLog(SYS_LOG_ERROR, "trying to reset channel, but got error\n");
            PrintJpegRet(&jpegRet);
            return AX_ERR_VDEC_RUN_ERROR;
        }

        VdecLog(SYS_LOG_DEBUG, "reset channel succeed\n");
        return AX_ERR_VDEC_STRM_ERROR;
    } else {
        pJdecCtx->nbrOfImages = 0;

        ret = AX_POOL_ReleaseBlock_Inter(pJdecCtx->frameMem.BlkId, AX_ID_JDEC);
        if (0 != ret) {
            VdecLog(SYS_LOG_ERROR, "JDEC AX_POOL_ReleaseBlock_Inter err(0x%x).\n", ret);
        }

        PrintJpegRet(&jpegRet);
        return AX_ERR_VDEC_RUN_ERROR;
    }

    pJdecCtx->nbrOfImages--;
    if (pJdecCtx->nbrOfImages > 0) {
        u32 imageInfoLength = 0;
        jpegRet = FindImageTnEOI(pJdecCtx->byteStrmStart, pJdecCtx->streamInFile, &imageInfoLength, 0, 0);
        if (jpegRet != 0) {
            VdecLog(SYS_LOG_DEBUG, "NO MORE IMAGES!\n");
            pJdecCtx->nbrOfImages = 0;

            ret = AX_POOL_ReleaseBlock_Inter(pJdecCtx->frameMem.BlkId, AX_ID_JDEC);
            if (0 != ret) {
                VdecLog(SYS_LOG_ERROR, "JDEC AX_POOL_ReleaseBlock_Inter err(0x%x).\n", ret);
            }

            return AX_ERR_VDEC_STRM_ERROR;
        }
        pJdecCtx->streamInFile -= imageInfoLength;
        pJdecCtx->byteStrmStart += imageInfoLength;
        VdecLog(SYS_LOG_DEBUG, "find next image size: %u\n", imageInfoLength);
    }
    return AX_SUCCESS;
}

/* s32MilliSec: -1 is block,0 is no block,other positive number is timeout */
AX_S32 JdecSendStream(AX_VOID *pDecoder, const AX_VDEC_STREAM_S *pstStream, AX_S32 s32MilliSec)
{
    AxJdecCtx *pJdecCtx = pDecoder;
    if (pJdecCtx->bRunning == AX_FALSE)
        return AX_ERR_VDEC_SYS_NOTREADY;

    if (pstStream->bEndOfStream == AX_TRUE) {
        pthread_mutex_lock(&gJdecWorkingMutex);
        pJdecCtx->bEofReady = AX_TRUE;
        pthread_cond_broadcast(&gJdecWorkingCond);
        pthread_mutex_unlock(&gJdecWorkingMutex);
    } else {
        if (!pstStream->pu8Addr)
            return AX_ERR_VDEC_NULL_PTR;
        if (pstStream->u32Len > pJdecCtx->u32StreamBufSize)
            return AX_ERR_VDEC_NOT_PERM;

        pthread_mutex_lock(&gJdecWorkingMutex);
        pJdecCtx->bStreamReady = AX_TRUE;
        pJdecCtx->streamInfoCheck = 0;
        pJdecCtx->nbrOfImagesTotal = 0;
        pJdecCtx->nbrOfImages = 0;
        pJdecCtx->nbrOfThumbImagesTotal = 0;
        pJdecCtx->nbrOfThumbImages = 0;
        pthread_cond_broadcast(&gJdecWorkingCond);
        while (pJdecCtx->bStreamReady == AX_TRUE) {
            VdecLog(SYS_LOG_DEBUG, "%s, wait...\n", __func__);
            pthread_cond_wait(&gJdecWorkingCond, &gJdecWorkingMutex);
        }
        pthread_mutex_unlock(&gJdecWorkingMutex);
    }

    return AX_SUCCESS;
}

AX_S32 JdecGetFrame(AX_VOID *pDecoder, AX_VIDEO_FRAME_INFO_S *pstFrameInfo, AX_S32 s32MilliSec)
{
    AxJdecCtx *pJdecCtx = pDecoder;
    if (pJdecCtx->bRunning == AX_FALSE)
        return AX_ERR_VDEC_SYS_NOTREADY;

    int timeout = 0;
    int frameBufEmpty = 0;
    pthread_mutex_lock(&gJdecWorkingMutex);
    if (s32MilliSec == -1) {
        while ((pJdecCtx->yuvAvaliable == 0) && (pJdecCtx->bEndOfStream == AX_FALSE)) {
            pthread_cond_wait(&gJdecWorkingCond, &gJdecWorkingMutex);
            VdecLog(SYS_LOG_DEBUG, "%s, yuvAvaliable: %d, bEndStream: %d\n", __func__, pJdecCtx->yuvAvaliable,
                    pJdecCtx->bEndOfStream);
        }
    } else if (s32MilliSec == 0) {
        frameBufEmpty = ((pJdecCtx->yuvAvaliable == 0) && (pJdecCtx->bEndOfStream == AX_FALSE)) ? 1 : 0;
    } else {
        if ((pJdecCtx->yuvAvaliable == 0) && (pJdecCtx->bEndOfStream == AX_FALSE)) {
            int ret = 0;
            struct timespec outtime;

            u32 sec_exp = s32MilliSec / 1000;
            u32 msec_exp = s32MilliSec % 1000;

            clock_gettime(CLOCK_MONOTONIC, &outtime);
            outtime.tv_sec += sec_exp;
            outtime.tv_nsec += msec_exp * 1000 * 1000;
            if (outtime.tv_nsec >= (1000*1000*1000)) {
                outtime.tv_nsec -= (1000*1000*1000);
                outtime.tv_sec += 1;
            }

            ret = pthread_cond_timedwait(&gJdecWorkingCond, &gJdecWorkingMutex, &outtime);
            timeout = ((ret != 0) && (pJdecCtx->yuvAvaliable == 0) && (pJdecCtx->bEndOfStream == AX_FALSE)) ? 1 : 0;
        }
    }
    pthread_mutex_unlock(&gJdecWorkingMutex);

    if (frameBufEmpty || timeout) {
        VdecLog(SYS_LOG_DEBUG, "%s, frameBufEmpty: %d, timeout: %d\n", __func__, frameBufEmpty, timeout);
        return AX_ERR_VDEC_BUF_EMPTY;
    }

    pstFrameInfo->enModId = AX_ID_VDEC;
    if (pJdecCtx->yuvAvaliable == 1) {
        pstFrameInfo->stVFrame.u64PhyAddr[0] = pJdecCtx->jpegOut.outputPictureY.busAddress + VDEC_ADDR_OFFSET;
        pstFrameInfo->stVFrame.u64PhyAddr[1] = pJdecCtx->jpegOut.outputPictureCbCr.busAddress + VDEC_ADDR_OFFSET;
        pstFrameInfo->stVFrame.u64PhyAddr[2] = 0;
        pstFrameInfo->stVFrame.u64VirAddr[0] = 0;//(AX_U64)pJdecCtx->jpegOut.outputPictureY.pVirtualAddress;
        pstFrameInfo->stVFrame.u64VirAddr[1] = 0;//(AX_U64)pJdecCtx->jpegOut.outputPictureCbCr.pVirtualAddress;
        pstFrameInfo->stVFrame.u64VirAddr[2] = 0;//(AX_U64)pJdecCtx->jpegOut.outputPictureCr.pVirtualAddress;
        pstFrameInfo->stVFrame.u32Width = pJdecCtx->imageInfo.displayWidth;
        pstFrameInfo->stVFrame.u32Height = pJdecCtx->imageInfo.displayHeight;
        pstFrameInfo->stVFrame.u32PicStride[0] = pJdecCtx->imageInfo.outputWidth;
        pstFrameInfo->stVFrame.u32PicStride[1]  = pJdecCtx->imageInfo.outputWidth;
        pstFrameInfo->stVFrame.u32PicStride[2]  = 0;
        pstFrameInfo->stVFrame.u32BlkId[0] = pJdecCtx->frameMem.BlkId;
        pstFrameInfo->stVFrame.u32BlkId[1] = 0;
        pstFrameInfo->stVFrame.u32BlkId[2] = 0;

        if (JPEGDEC_YCbCr420_SEMIPLANAR == pJdecCtx->imageInfo.outputFormat) {
            pstFrameInfo->stVFrame.enImgFormat = AX_YUV420_SEMIPLANAR;
        } else if (JPEGDEC_YCbCr444_SEMIPLANAR == pJdecCtx->imageInfo.outputFormat) {
            pstFrameInfo->stVFrame.enImgFormat = AX_YUV444_SEMIPLANAR;
        } else {
            VdecLog(SYS_LOG_ERROR, "YUV OutputFormat unknown format is %d\n", pJdecCtx->imageInfo.outputFormat);
            pstFrameInfo->stVFrame.enImgFormat = AX_FORMAT_INVALID;
        }

        pstFrameInfo->bEof = AX_FALSE;
        VdecLog(SYS_LOG_DEBUG,
                "%s\n"
                "outputPictureY.busAddress: %p\n"
                "outputPictureCbCr.busAddress: %p\n"
                "outputPictureCr.busAddress: %p\n"
                "outputPictureY.pVirtualAddress: %p\n"
                "outputPictureCbCr.pVirtualAddress: %p\n"
                "outputPictureCr.pVirtualAddress: %p\n"
                "displayWidth: %u\n"
                "displayHeight: %u\n"
                "outputWidth: %u\n"
                "outputHeight: %u\n"
                "outputFormat: %u\n",
                __func__,
                pJdecCtx->jpegOut.outputPictureY.busAddress,
                pJdecCtx->jpegOut.outputPictureCbCr.busAddress,
                pJdecCtx->jpegOut.outputPictureCr.busAddress,
                pJdecCtx->jpegOut.outputPictureY.pVirtualAddress,
                pJdecCtx->jpegOut.outputPictureCbCr.pVirtualAddress,
                pJdecCtx->jpegOut.outputPictureCr.pVirtualAddress,
                pJdecCtx->imageInfo.displayWidth,
                pJdecCtx->imageInfo.displayHeight,
                pJdecCtx->imageInfo.outputWidth,
                pJdecCtx->imageInfo.outputHeight,
                pJdecCtx->imageInfo.outputFormat);
        if (pJdecCtx->lastDecodeStatus != AX_SUCCESS) {
            VdecLog(SYS_LOG_DEBUG, "%s, channel %d decode error: %x\n", __func__, pJdecCtx->VdGrp, pJdecCtx->lastDecodeStatus);
            pthread_mutex_lock(&gJdecWorkingMutex);
            pJdecCtx->yuvAvaliable = 0;
            VdecLog(SYS_LOG_DEBUG, "%s, set yuvAvaliable = 0\n", __func__);
            pthread_cond_broadcast(&gJdecWorkingCond);
            pthread_mutex_unlock(&gJdecWorkingMutex);
            return pJdecCtx->lastDecodeStatus;
        }
    } else if (pJdecCtx->bEndOfStream == AX_TRUE) {
        VdecLog(SYS_LOG_INFO, "%s, end of stream\n", __func__);
        pstFrameInfo->bEof = AX_TRUE;
    } else {
        VdecLog(SYS_LOG_ERROR, "%s, error occurred\n", __func__);
        return AX_ERR_VDEC_RUN_ERROR;
    }
    return AX_SUCCESS;
}

AX_S32 JdecReleaseFrame(AX_VOID *pDecoder, const AX_VIDEO_FRAME_INFO_S *pstFrameInfo)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    if (pJdecCtx->bRunning == AX_FALSE)
        return AX_ERR_VDEC_SYS_NOTREADY;

    // release pool output buffer
    if (pJdecCtx->frameMem.virtualAddress != NULL) {
        DWLFreeLinear(((JpegDecContainer *) pJdecCtx->jpeg)->dwl, &pJdecCtx->frameMem, AX_ID_JDEC);
    }

    pthread_mutex_lock(&gJdecWorkingMutex);
    pJdecCtx->yuvAvaliable = 0;
    VdecLog(SYS_LOG_DEBUG, "%s, set yuvAvaliable = 0\n", __func__);
    pthread_cond_broadcast(&gJdecWorkingCond);
    pthread_mutex_unlock(&gJdecWorkingMutex);
    return AX_SUCCESS;
}

AX_S32 JdecGetUserData(AX_VOID *pDecoder, AX_VDEC_USERDATA_S *pstUserData, AX_S32 s32MilliSec)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecReleaseUserData(AX_VOID *pDecoder, const AX_VDEC_USERDATA_S *pstUserData)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecSetUserPic(AX_VOID *pDecoder, const AX_VIDEO_FRAME_INFO_S *pstUsrPic)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecEnableUserPic(AX_VOID *pDecoder, AX_BOOL bInstant)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecDisableUserPic(AX_VOID *pDecoder)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecDecodeFrame(const void *dwlInst,AX_JPEG_DECODE_ONCE_PARAMS *pstParam)
{
    JpegDecRet jpegRet = JPEGDEC_OK;
    JpegDecInst jpeg = NULL;
    JpegDecInput jpegIn;
    JpegDecOutput jpegOut;
    JpegDecImageInfo imageInfo;
    u32 outputWidth = 0;
    u32 outputHeight = 0;

    if(NULL == gJdecJpeg) {
        jpegRet = JpegDecInit(&gJdecJpeg, dwlInst);
        if(jpegRet != JPEGDEC_OK) {
            PrintJpegRet(&jpegRet);
            return AX_ERR_VDEC_RUN_ERROR;
        }
    }

    jpeg = gJdecJpeg;
    memset(&jpegIn,0,sizeof(JpegDecInput));
    memset(&jpegOut,0,sizeof(JpegDecOutput));
    memset(&imageInfo,0,sizeof(JpegDecImageInfo));

    jpegIn.streamBuffer.pVirtualAddress = (u32 *)pstParam->pu8StreamVirAddr;
    jpegIn.streamBuffer.busAddress = pstParam->u64StreamPhyAddr - 0x40000000;
    jpegIn.streamLength = pstParam->u32StreamLen;
    jpegIn.bufferSize = 0;
    jpegIn.decImageType = JPEGDEC_IMAGE;
    jpegIn.sliceMbSet = 0;

    jpegRet = JpegDecGetImageInfo(jpeg, &jpegIn, &imageInfo);
    if (jpegRet != JPEGDEC_OK) {
        PrintJpegRet(&jpegRet);
        return AX_ERR_VDEC_STRM_ERROR;
    }

    outputWidth = imageInfo.outputWidth;
    outputHeight = imageInfo.outputHeight;

    if(pstParam->u32Len[0] < outputWidth*outputHeight
        || pstParam->u32Len[1] < outputWidth*outputHeight/2) {
        VdecLog(SYS_LOG_ERROR, "outbuflen is too small.len0 need %d x %d,len1 need %d\n",outputWidth,outputHeight,(outputWidth*outputHeight/2));
        return AX_ERR_VDEC_ILLEGAL_PARAM;
    }

    jpegIn.pictureBufferY.pVirtualAddress = (u32 *)(AX_U32)(pstParam->u64VirAddr[0]);
    jpegIn.pictureBufferY.busAddress = pstParam->u64PhyAddr[0] - 0x40000000;
    jpegIn.pictureBufferCbCr.pVirtualAddress = (u32 *)(AX_U32)(pstParam->u64VirAddr[1]);
    jpegIn.pictureBufferCbCr.busAddress = pstParam->u64PhyAddr[1] - 0x40000000;

    jpegRet = JpegDecDecode(jpeg, &jpegIn, &jpegOut);
    if (jpegRet == JPEGDEC_FRAME_READY) {
        VdecLog(SYS_LOG_DEBUG, "JPEGDEC_FRAME_READY\n");
        VdecLog(SYS_LOG_DEBUG, "Luma output bus: 0x%16x\n",
                (u8 *) jpegOut.outputPictureY.busAddress);
        VdecLog(SYS_LOG_DEBUG, "Chroma output bus: 0x%16x\n",
                (u8 *) jpegOut.outputPictureCbCr.busAddress);

    } else if (jpegRet == JPEGDEC_STRM_ERROR) {
        VdecLog(SYS_LOG_DEBUG, "JPEGDEC_STRM_ERROR\n");
        // release instance
        JpegDecRelease(gJdecJpeg);
        gJdecJpeg = NULL;
        VdecLog(SYS_LOG_DEBUG, "reset channel succeed\n");
        return AX_ERR_VDEC_STRM_ERROR;
    } else {
        PrintJpegRet(&jpegRet);
        return AX_ERR_VDEC_RUN_ERROR;
    }

    pstParam->u32PicWidth = imageInfo.displayWidth;
    pstParam->u32PicHeight = imageInfo.displayHeight;
    pstParam->u32PicStride[0] = outputWidth;
    pstParam->u32PicStride[1]  = outputWidth;

    if (JPEGDEC_YCbCr420_SEMIPLANAR == imageInfo.outputFormat) {
        pstParam->enImgFormat = AX_YUV420_SEMIPLANAR;
    } else if (JPEGDEC_YCbCr444_SEMIPLANAR == imageInfo.outputFormat) {
        pstParam->enImgFormat = AX_YUV444_SEMIPLANAR;
    } else {
        VdecLog(SYS_LOG_ERROR, "YUV OutputFormat unknown format is %d\n", imageInfo.outputFormat);
        pstParam->enImgFormat = AX_FORMAT_INVALID;
    }

    return AX_SUCCESS;
}

AX_S32 JdecSetDisplayMode(AX_VOID *pDecoder, AX_VDEC_DISPLAY_MODE_E enDisplayMode)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecGetDisplayMode(AX_VOID *pDecoder, AX_VDEC_DISPLAY_MODE_E *penDisplayMode)
{
    return AX_ERR_VDEC_NOT_SUPPORT;
}

AX_S32 JdecAttachPool(AX_VOID *pDecoder, AX_POOL Pool)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    pJdecCtx->sPoolId = Pool;

    return AX_SUCCESS;

}

AX_S32 JdecDetachPool(AX_VOID *pDecoder)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    pJdecCtx->sPoolId = AX_INVALID_POOLID;

    return AX_SUCCESS;

}

AX_F32 JdecGetFrameRate(AX_VOID *pDecoder)
{
    AxJdecCtx *pJdecCtx = pDecoder;
    AX_F32 frame_rate;
    struct timespec current_tv;

    clock_gettime(CLOCK_MONOTONIC, &current_tv);

    frame_rate = (AX_F32)(pJdecCtx->output_pic_num - pJdecCtx->old_output_pic_num) * 1000.f /
        ((AX_F32)(current_tv.tv_sec - pJdecCtx->timer_record.tv_sec) * 1000.f +
        (AX_F32)(current_tv.tv_nsec - pJdecCtx->timer_record.tv_nsec) / 1000000.f);

    pJdecCtx->timer_record = current_tv;
    pJdecCtx->old_output_pic_num = pJdecCtx->output_pic_num;

    return frame_rate;
}

AX_S32 JdecProcInfo(AX_VOID *pDecoder, struct proc_info *ProcInfo)
{
    AxJdecCtx *pJdecCtx = pDecoder;

    ProcInfo->block_fail_num = pJdecCtx->block_fail_num;
    ProcInfo->free_buf_num = 0;

    return AX_SUCCESS;
}

AX_S32 JdecSendSig()
{
    pthread_mutex_lock(&gJdecWorkingMutex);
    pthread_cond_broadcast(&gJdecWorkingCond);
    pthread_mutex_unlock(&gJdecWorkingMutex);

    return AX_SUCCESS;
}

AX_VDEC_DECODER_S gJdecDecoder = {
    .enType = PT_JPEG,
    .pfnCreateGrp = &JdecCreateGrp,
    .pfnDestroyGrp = &JdecDestroyGrp,
    .pfnGetGrpAttr = &JdecGetGrpAttr,
    .pfnSetGrpAttr = &JdecSetGrpAttr,
    .pfnStartRecvStream = &JdecStartRecvStream,
    .pfnStopRecvStream = &JdecStopRecvStream,
    .pfnQueryStatus = &JdecQueryStatus,
    .pfnResetGrp = &JdecResetGrp,
    .pfnSetGrpParam = &JdecSetGrpParam,
    .pfnGetGrpParam = &JdecGetGrpParam,
    .pfnSetProtocolParam = &JdecSetProtocolParam,
    .pfnGetProtocolParam = &JdecGetProtocolParam,
    .pfnSendStream = &JdecSendStream,
    .pfnGetFrame = &JdecGetFrame,
    .pfnReleaseFrame = &JdecReleaseFrame,
    .pfnGetUserData = &JdecGetUserData,
    .pfnReleaseUserData = &JdecReleaseUserData,
    .pfnSetUserPic = &JdecSetUserPic,
    .pfnEnableUserPic = &JdecEnableUserPic,
    .pfnDisableUserPic = &JdecDisableUserPic,
    .pfnDecodeFrame = &JdecDecodeFrame,
    .pfnSetDisplayMode = &JdecSetDisplayMode,
    .pfnGetDisplayMode = &JdecGetDisplayMode,
    .pfnAttachPool = &JdecAttachPool,
    .pfnDetachPool = &JdecDetachPool,
    .pfnGetFrameRate = &JdecGetFrameRate,
    .pfnGetProcInfo = &JdecProcInfo,
};

AX_BOOL JdecChannelIsReady(int *readyChn)
{
    AX_BOOL channelIsReady = AX_FALSE;
    for (int i = 0; i < AX_VDEC_MAX_GRP_SIZE; i++) {
        if (gJdecCtxs[i] &&
            (gJdecCtxs[i]->bRunning == AX_TRUE) &&
            ((gJdecCtxs[i]->bStreamReady == AX_TRUE) || (gJdecCtxs[i]->bEofReady == AX_TRUE)) &&
            (gJdecCtxs[i]->yuvAvaliable == 0)) {
            channelIsReady = AX_TRUE;
            *readyChn = i;
            break;
        }
    }
    return channelIsReady;
}

static void *JdecWorkingThread(void *arg)
{
    FifoRet fifoRet = FIFO_OK;
    AX_VDEC_STREAM_INFO_S *tmpInput = NULL;

    while (gJdecWorkingThreadRun) {
        int readyChn;
        pthread_mutex_lock(&gJdecWorkingMutex);
        while (gJdecSuspendState || ((gJdecWorkingThreadRun == AX_TRUE) && !JdecChannelIsReady(&readyChn))) {
            VdecLog(SYS_LOG_DEBUG, "%s, wait...\n", __func__);
            if (gJdecSuspendState && gJdecWaitUnlock) {
                AX_SYS_WakeUnlock(AX_ID_JDEC);
                gJdecWaitUnlock = AX_FALSE;
            }
            pthread_cond_wait(&gJdecWorkingCond, &gJdecWorkingMutex);
            VdecLog(SYS_LOG_DEBUG, "%s, wait end\n", __func__);
        }
        pthread_mutex_unlock(&gJdecWorkingMutex);

        if (gJdecWorkingThreadRun == AX_FALSE) {
            VdecLog(SYS_LOG_DEBUG, "%s, got end signal\n", __func__);
            break;
        }

        pthread_mutex_lock(&gJdecDestoryMutex[readyChn]);

        AxJdecCtx *pJdecCtx = gJdecCtxs[readyChn];
        if (pJdecCtx == NULL) {
            VdecLog(SYS_LOG_WARN, "%s, chn %d jdec contex is null\n", __func__, readyChn);
            pthread_mutex_unlock(&gJdecDestoryMutex[readyChn]);
            continue;
        }

        if (pJdecCtx->InputInfo->InStreamQueue != NULL) {
            fifoRet = AX_Vdec_FifoPop(pJdecCtx->InputInfo->InStreamQueue, (void **)&tmpInput, 0);
        } else {
            VdecLog(SYS_LOG_WARN, "%s, chn %d Input Stream Queue is null\n", __func__, readyChn);
            pthread_mutex_unlock(&gJdecDestoryMutex[readyChn]);
            continue;
        }

        if (fifoRet != FIFO_OK) {
            pthread_mutex_unlock(&gJdecDestoryMutex[readyChn]);
            break;
        }

        pJdecCtx->streamMem.virtualAddress = (u32 *)tmpInput->pu8Addr;
        pJdecCtx->streamMem.busAddress = tmpInput->pu64PhyAddr;
        pJdecCtx->u32StreamLength = tmpInput->u32Len;

        VdecLog(SYS_LOG_DEBUG, "%s, readyChn %d is ready, bStreamReady: %d, bEofReady: %d\n",
                __func__, readyChn, pJdecCtx->bStreamReady, pJdecCtx->bEofReady);
        pthread_mutex_unlock(&gJdecDestoryMutex[readyChn]);

        // To do: make clear JdecWorkingMutex
        if (pJdecCtx->bStreamReady == AX_TRUE) {
            pJdecCtx->lastDecodeStatus = JdecDecode(pJdecCtx);

            pthread_mutex_lock(&gJdecWorkingMutex);
            if (pJdecCtx->nbrOfImages <= 0) {
                pJdecCtx->bStreamReady = AX_FALSE;
            }
            pJdecCtx->yuvAvaliable = 1;
            pJdecCtx->output_pic_num ++;
            pthread_cond_broadcast(&gJdecWorkingCond);
            pthread_mutex_unlock(&gJdecWorkingMutex);
        } else if (pJdecCtx->bEofReady == AX_TRUE) {
            pthread_mutex_lock(&gJdecWorkingMutex);
            pJdecCtx->bEndOfStream = AX_TRUE;
            pJdecCtx->bEofReady = AX_FALSE;
            pthread_cond_broadcast(&gJdecWorkingCond);
            pthread_mutex_unlock(&gJdecWorkingMutex);
        } else {
            VdecLog(SYS_LOG_ERROR, "%s, error occurred\n", __func__);
        }
    }

    return NULL;
}

AX_S32 CreateJdecWorkingThread()
{
    pthread_attr_t attr;
    struct sched_param param;

    gJdecWorkingThreadRun = AX_TRUE;

    pthread_attr_init(&attr);
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
    pthread_attr_setschedpolicy(&attr, SCHED_RR);
    param.sched_priority = VdecGetThreadLevel(); // legal range 1~99
    pthread_attr_setschedparam(&attr,&param);
    pthread_create(&gJdecWorkingThreadTid, &attr, JdecWorkingThread, (void *)NULL);
    return AX_SUCCESS;
}

AX_S32 DestroyJdecWorkingThread()
{
    pthread_mutex_lock(&gJdecWorkingMutex);
    gJdecWorkingThreadRun = AX_FALSE;
    pthread_cond_broadcast(&gJdecWorkingCond);
    pthread_mutex_unlock(&gJdecWorkingMutex);

    pthread_join(gJdecWorkingThreadTid, NULL);
    return AX_SUCCESS;
}
