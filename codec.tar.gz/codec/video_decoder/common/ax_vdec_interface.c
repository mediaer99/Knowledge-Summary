#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "ax_sys_api.h"
#include <unistd.h>

#include "vdec_log.h"
#include "ax_vdec_fifo.h"
#include "ax_vdec_interface.h"
#include "bsp_osal.h"


#define VDEC_ADDR_OFFSET 0x40000000

#define SYSANONYMOUS "anonymous"

vdec_ringbuffer_t *Vdec_RingBuffer_Create(AX_VDEC_GRP VdGrp, AX_U32 buffer_size)
{
    AX_U64 u64PhyAddr = 0;
    void *pVirAddr = NULL;
    AX_S32 s32Ret = -1;
    vdec_ringbuffer_t *pRingbbuf = NULL;
    AX_U32 streamBuffSize = buffer_size;

    s32Ret = AX_SYS_MemAlloc(&u64PhyAddr, &pVirAddr, streamBuffSize, 0, (AX_S8 *)"vdec_dwl");
    if (0 != s32Ret) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: AX_SYS_MemAlloc error.\n", VdGrp);
        goto EXIT;
    }

    VdecLog(SYS_LOG_DEBUG, "VDEC %d, ringbuffer vir_addr %p, phy_addr %llx.\n",
            VdGrp,
            pVirAddr,
            u64PhyAddr);

    pRingbbuf = (vdec_ringbuffer_t *)calloc(1, sizeof(vdec_ringbuffer_t));
    if (NULL == pRingbbuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: alloc fifo error.\n", VdGrp);
        goto EXIT;
    }

    pRingbbuf->phyaddr_buffer_start = u64PhyAddr - VDEC_ADDR_OFFSET;
    pRingbbuf->phyaddr_buffer_end = pRingbbuf->phyaddr_buffer_start + streamBuffSize;

    pRingbbuf->viraddr_buffer_start = pVirAddr;
    pRingbbuf->viraddr_buffer_end = pRingbbuf->viraddr_buffer_start + streamBuffSize;

    pRingbbuf->read_offset = 0x0;
    pRingbbuf->write_offset = 0x0;
    pRingbbuf->clip_offset = 0x0;

    pRingbbuf->buffer_total_size = streamBuffSize;

    memset(pRingbbuf->viraddr_buffer_start, 0, pRingbbuf->buffer_total_size);

    VdecLog(SYS_LOG_DEBUG, "VDEC %d: buffer_phyaddr_start=%llx, buffer_viraddr_start=%p, totalSize=%d.\n",
            VdGrp,
            pRingbbuf->phyaddr_buffer_start,
            pRingbbuf->viraddr_buffer_start,
            pRingbbuf->buffer_total_size
           );

    return pRingbbuf;

EXIT:

    if (NULL != pRingbbuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: free fifo.\n", VdGrp);
        free(pRingbbuf);
        pRingbbuf = NULL;
    }

    if (0 != u64PhyAddr && NULL != pVirAddr) {
        s32Ret = AX_SYS_MemFree(u64PhyAddr, pVirAddr);
        if (0 != s32Ret) {
            VdecLog(SYS_LOG_ERROR, "VDEC %d: AX_SYS_MemFree error.\n", VdGrp);
        }
    }

    return NULL;
}

AX_S32 Vdec_RingBuffer_Close(AX_VDEC_GRP VdGrp, vdec_ringbuffer_t *pRingbbuf)
{
    AX_S32 s32Ret = -1;

    if (NULL == pRingbbuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: fifo is null.\n", VdGrp);
        return -1;
    }

    s32Ret = AX_SYS_MemFree(pRingbbuf->phyaddr_buffer_start + VDEC_ADDR_OFFSET, pRingbbuf->viraddr_buffer_start);
    if (0 != s32Ret) {
        VdecLog(SYS_LOG_ERROR, "VDEC %d: AX_SYS_MemFree error.\n", VdGrp);
        return -1;
    }

    if (NULL != pRingbbuf) {
        free(pRingbbuf);
        pRingbbuf = NULL;
    }

    return 0;
}

AX_S32 Vdec_RingBuffer_Read(vdec_ringbuffer_t *pRingBuf, AX_U32 packet_size)
{
    if (NULL == pRingBuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC : fifo is null.\n");
        return -1;
    }

    if ((pRingBuf->clip_offset > 0) &&
        (pRingBuf->read_offset >= pRingBuf->clip_offset)) {
        pRingBuf->read_offset =  0;
        pRingBuf->clip_offset = 0;
    }

    pRingBuf->read_offset += DATA_ALIGN(packet_size, 16);
    sem_post(&pRingBuf->dec_done); //signal something can be read

    VdecLog(SYS_LOG_DEBUG, "Vdec_RingBuffer_Read : clip=%d, read=%d, write=%d, packet_size=%u ++ \n",
            pRingBuf->clip_offset,
            pRingBuf->read_offset,
            pRingBuf->write_offset,
            packet_size);

    return 0;
}

AX_BOOL Vdec_RingBuffer_IsUsable(vdec_ringbuffer_t *pRingBuf, AX_U32 data_len, AX_U32 *scenario)
{
    AX_U32 read_ptr, write_ptr;

    if (NULL == pRingBuf) {
        VdecLog(SYS_LOG_ERROR, "VDEC: fifo is null.\n");
        return -1;
    }

    read_ptr = pRingBuf->read_offset;
    write_ptr = pRingBuf->write_offset;

    if (write_ptr >= read_ptr) {
        if ((pRingBuf->buffer_total_size - write_ptr) >= data_len) {
            //right vacant area is big enough to fit incoming frame
            *scenario = 1;
        } else if (read_ptr >= data_len) {
            //right vacant is not big enough, but left vancant area is big enough
            *scenario = 2;
        } else {
            VdecLog(SYS_LOG_ERROR, "VDEC: fifo is full.\n");
            return AX_FALSE;
        }
    } else {
        //write_ptr rewind back thus write_ptr < read_ptr
        if ((read_ptr - write_ptr) >= data_len) {
            *scenario = 3;
        } else {
            VdecLog(SYS_LOG_ERROR, "VDEC: fifo is full.\n");
            return AX_FALSE;
        }
    }

    return AX_TRUE;
}

AX_S32 Vdec_RingBuffer_Reset(vdec_ringbuffer_t *pRingBuf)
{
    pRingBuf->read_offset = 0x0;
    pRingBuf->write_offset = 0x0;
    pRingBuf->clip_offset = 0x0;

    memset(pRingBuf->viraddr_buffer_start, 0, pRingBuf->buffer_total_size);

    return 0;
}

/*
 * NonBlockingDecode()
 * AX_VDEC_SendStream support blocking and nonblocking mode
 * this function implements the nonblocking mode
 * Watch Out: not thread safe
 */
AX_S32 Vdec_NonBlockingDecode(AxVdecChn *VdChn, const AX_VDEC_STREAM_S *pstStream)
{
    AX_U32 scenario = 0;
    AX_U32 data_len = 0;
    AX_U32 data_len_aligned;
    AX_U32 read_ptr, write_ptr;
    AX_VDEC_STREAM_INFO_S *tmp_input;
    FifoRet fifoRet = FIFO_OK;
    AX_U8 *pAddr = pstStream->pu8Addr;

    if (VdChn->InputInfo.pstInRingBuf == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s, ring buffer is null\n", __func__);
        return AX_ERR_VDEC_NULL_PTR;
    }
    if (VdChn->InputInfo.InStreamQueue == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s, fifo is null\n", __func__);
        return AX_ERR_VDEC_NULL_PTR;
    }

    fifoRet = AX_Vdec_IsFifoFull(VdChn->InputInfo.InStreamQueue);
    if (fifoRet) {
        return AX_ERR_VDEC_BUF_FULL;
    }

    data_len = pstStream->u32Len;
    data_len_aligned = DATA_ALIGN(data_len, 16);

    // this thread is responsible for modifying write_ptr
    // decoder thread shall modify read_ptr and clip
    pthread_mutex_lock(&VdChn->InputInfo.InputDoneMutex);

    read_ptr = VdChn->InputInfo.pstInRingBuf->read_offset;
    write_ptr = VdChn->InputInfo.pstInRingBuf->write_offset;

    // this is standard ring buffer management with clip addon
    // the clip design is to support frame based video processing
    if (write_ptr >= read_ptr) {
        if ((VdChn->InputInfo.pstInRingBuf->buffer_total_size - write_ptr) >= data_len) {
            //right vacant area is big enough to fit incoming frame
            scenario = 1;
            VdChn->InputInfo.pstInRingBuf->write_offset += data_len_aligned;
        } else if (read_ptr >= data_len) {
            //right vacant is not big enough, but left vancant area is big enough
            scenario = 2;

            //rewind happens, set clip=write_ptr, clip will reset by read thread
            VdChn->InputInfo.pstInRingBuf->clip_offset = VdChn->InputInfo.pstInRingBuf->write_offset;
            VdChn->InputInfo.pstInRingBuf->write_offset = data_len_aligned;
        }
    } else {
        //write_ptr rewind back thus write_ptr < read_ptr
        if ((read_ptr - write_ptr) >= data_len) {
            scenario = 3;
            VdChn->InputInfo.pstInRingBuf->write_offset += data_len_aligned;
        }
    }
    pthread_mutex_unlock(&VdChn->InputInfo.InputDoneMutex);

    tmp_input = (AX_VDEC_STREAM_INFO_S *)BspOsalMalloc(sizeof(AX_VDEC_STREAM_INFO_S));
    memset(tmp_input, 0x0, sizeof(AX_VDEC_STREAM_INFO_S));
    switch (scenario) {
    case 1:
    case 3:
        tmp_input->pu8Addr = (VdChn->InputInfo.pstInRingBuf->viraddr_buffer_start + write_ptr);
        tmp_input->pu64PhyAddr = VdChn->InputInfo.pstInRingBuf->phyaddr_buffer_start + write_ptr;
        tmp_input->u32Len = pstStream->u32Len;
        tmp_input->bEndOfFrame = pstStream->bEndOfFrame;
        tmp_input->bEndOfStream = pstStream->bEndOfStream;
        tmp_input->bDisplay = pstStream->bDisplay;
        tmp_input->u64PTS = pstStream->u64PTS;
        break;
    case 2:
        tmp_input->pu8Addr = VdChn->InputInfo.pstInRingBuf->viraddr_buffer_start;
        tmp_input->pu64PhyAddr = VdChn->InputInfo.pstInRingBuf->phyaddr_buffer_start;
        tmp_input->u32Len = pstStream->u32Len;
        tmp_input->bEndOfFrame = pstStream->bEndOfFrame;
        tmp_input->bEndOfStream = pstStream->bEndOfStream;
        tmp_input->bDisplay = pstStream->bDisplay;
        tmp_input->u64PTS = pstStream->u64PTS;
        break;
    default:
        BspOsalFree(tmp_input);
        return AX_ERR_VDEC_BUF_FULL;
    }
    if (pstStream->pu8Addr && data_len) {
        memcpy(tmp_input->pu8Addr, pAddr, data_len);
    }

    AX_Vdec_FifoPush(VdChn->InputInfo.InStreamQueue, tmp_input, FIFO_EXCEPTION_DISABLE);

    return AX_SUCCESS;
}

AX_S32 Vdec_BlockingDecode(AxVdecChn *VdChn, const AX_VDEC_STREAM_S *pstStream)
{
    AX_U32 data_len = 0;
    AX_VDEC_STREAM_INFO_S *tmp_input;
    FifoRet fifoRet = FIFO_OK;
    AX_U8 *pAddr = pstStream->pu8Addr;

    data_len = pstStream->u32Len;

    if (VdChn->InputInfo.pstInRingBuf == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s, ring buffer is null\n", __func__);
        return AX_ERR_VDEC_NULL_PTR;
    }
    if (VdChn->InputInfo.InStreamQueue == NULL) {
        VdecLog(SYS_LOG_ERROR, "%s, fifo is null\n", __func__);
        return AX_ERR_VDEC_NULL_PTR;
    }

    tmp_input = (AX_VDEC_STREAM_INFO_S *)BspOsalMalloc(sizeof(AX_VDEC_STREAM_INFO_S));
    memset(tmp_input, 0x0, sizeof(AX_VDEC_STREAM_INFO_S));
    tmp_input->pu8Addr = VdChn->InputInfo.pstInRingBuf->viraddr_buffer_start;
    tmp_input->pu64PhyAddr = VdChn->InputInfo.pstInRingBuf->phyaddr_buffer_start;

    tmp_input->u32Len = pstStream->u32Len;
    tmp_input->bEndOfFrame = pstStream->bEndOfFrame;
    tmp_input->bEndOfStream = pstStream->bEndOfStream;
    tmp_input->bDisplay = pstStream->bDisplay;
    tmp_input->u64PTS = pstStream->u64PTS;

    if (pstStream->pu8Addr && data_len) {
        memset(tmp_input->pu8Addr, 0, data_len);
        memcpy(tmp_input->pu8Addr, pAddr, data_len);
    }

    fifoRet = AX_Vdec_FifoPush(VdChn->InputInfo.InStreamQueue, tmp_input, FIFO_EXCEPTION_DISABLE);

    if (fifoRet == FIFO_FULL) {
        VdecLog(SYS_LOG_ERROR, "%s, error occurred FIFO_FULL\n", __func__);
    }

    return AX_SUCCESS;
}

