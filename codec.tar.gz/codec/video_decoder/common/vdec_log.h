/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#ifndef _VDEC_LOG_D_H_
#define _VDEC_LOG_D_H_

#include "ax_global_type.h"

#ifdef __cplusplus
extern "C"
{
#endif

void VdecLog(AX_U32 eLv, char *fmt, ...);
AX_S32 VdecLogInit(AX_LOG_LEVEL_E eLv, AX_LOG_LEVEL_E eTarget);
AX_S32 VdecThreadLevelInit(void);
AX_S32 VdecGetThreadLevel(void);
AX_U64 VdecGetTickCount(void);

#ifdef __cplusplus
}
#endif

#endif
