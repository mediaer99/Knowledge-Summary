
#include <stdlib.h>
#include <semaphore.h>
#include "ax_vdec_fifo.h"
#include "ax_base_type.h"
#include "vdec_log.h"

/* Container for instance. */
typedef struct Fifo_s {
    pthread_spinlock_t spinLock;
    //sem_t cs_semaphore;    /* Semaphore for critical section. */
    sem_t read_semaphore;  /* Semaphore for readers. */
    sem_t write_semaphore; /* Semaphore for writers. */
    AX_U32 num_of_slots;
    AX_U32 num_of_objects;
    AX_U64 tail_index;
    FifoObject *nodes;
    AX_U32 abort;
} Fifo_t;

/*
 * FifoInit()
 * user specify FIFO capacity by "num_of_slots"
 * this func allocate FIFO context buffer internally and
 * returns instance pointer
 */
FifoRet AX_Vdec_Fifo_Init(AX_U32 num_of_slots, FifoInst *instance)
{
    //calloc() will reset buffer to zeros
    Fifo_t *inst = calloc(1, sizeof(Fifo_t));
    if (inst == NULL) {
        return FIFO_ERROR_MEMALLOC;
    }

    inst->num_of_slots = num_of_slots;

    /* Allocate memory for the objects. */
    inst->nodes = calloc(num_of_slots, sizeof(FifoObject));
    if (inst->nodes == NULL) {
        free(inst);
        inst = NULL;
        return FIFO_ERROR_MEMALLOC;
    }

    pthread_spin_init(&inst->spinLock, 0);

    /* Then initialize the read and write semaphores. */
    sem_init(&inst->read_semaphore, 0, 0);
    sem_init(&inst->write_semaphore, 0, num_of_slots);

    *instance = inst;

    return FIFO_OK;
}

/*
 * IsFifoFull()
 */
FifoRet AX_Vdec_IsFifoFull(FifoInst inst)
{
    Fifo_t *instance = (Fifo_t *)inst;

    return (instance->num_of_objects == instance->num_of_slots) ? FIFO_FULL : FIFO_OK;
}

FifoRet AX_Vdec_IsFifoEmpty(FifoInst inst)
{
    Fifo_t *instance = (Fifo_t *)inst;
    int value;

    sem_getvalue(&instance->write_semaphore, &value);

    if (((AX_U32)value == instance->num_of_slots) &&
        (instance->num_of_objects == 0)) {
        return FIFO_EMPTY;
    }

    return FIFO_OK;
}
/*
 * FifoPush()
 * write_semaphore indicates how many can write
 * cs_semaphore serves as mutex to protect index pointers
 * the intial status is cs_semaphore=1, num_of_objects=0 and num_of_slots=max
 * therefore, there are initially 0 element to read and "max" elments to write
 * this function supports blocking mode (e=0) and nonblocking mode (e=1)
 */
FifoRet AX_Vdec_FifoPush(FifoInst inst, FifoObject object, enum FifoException e)
{
    Fifo_t *instance = (Fifo_t *)inst;
    int value;

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPush: sem_getvalue +++ .\n");

    sem_getvalue(&instance->read_semaphore, &value);

    //non-block
    if ((e == FIFO_EXCEPTION_ENABLE) && ((AX_U32)value == instance->num_of_slots) &&
        (instance->num_of_objects == instance->num_of_slots)) {
        return FIFO_FULL;
    }

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPush: sem_getvalue --- .\n");
    sem_wait(&instance->write_semaphore); //wait for any vacant slot
    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPush: write sem_wait --- .\n");

    pthread_spin_lock(&instance->spinLock);

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPush: spinLock ---.\n");

    instance->nodes[(instance->tail_index + instance->num_of_objects) %
                                                                      instance->num_of_slots] = object;

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPush: object=%p, tail_index=%lld, num_of_objects=%d, num_of_slots=%d.\n",
            &instance->nodes[(instance->tail_index + instance->num_of_objects) % instance->num_of_slots],
            instance->tail_index,
            instance->num_of_objects,
            instance->num_of_slots);

    instance->num_of_objects++;

    pthread_spin_unlock(&instance->spinLock);

    sem_post(&instance->read_semaphore); //signal something can be read

    return FIFO_OK;
}

/*
 * FifoPop()
 * read_semaphore indicates how many can read
 * cs_semaphore serves as mutex to protect index pointers
 * the intial status is cs_semaphore=1, num_of_objects=0 and num_of_slots=max
 * therefore, there are initially 0 element to read and "max" elments to write
 */
FifoRet AX_Vdec_FifoPop(FifoInst inst, FifoObject *object, enum FifoException e)
{
    Fifo_t *instance = (Fifo_t *)inst;
    int value;

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: write sem_getvalue +++.\n");
    sem_getvalue(&instance->write_semaphore, &value);
    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: write sem_getvalue ---.\n");

    if ((e == FIFO_EXCEPTION_ENABLE) && ((AX_U32)value == instance->num_of_slots) &&
        (instance->num_of_objects == 0)) {
        return FIFO_EMPTY;
    }

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: read sem_wait +++\n");
    sem_wait(&instance->read_semaphore); //wait until there are something to read
    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: read sem_wait ---\n");
    pthread_spin_lock(&instance->spinLock);
    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: cs spinLock ---\n");

    if (instance->abort) {
        pthread_spin_unlock(&instance->spinLock);
        return FIFO_ABORT;
    }

    *object = instance->nodes[instance->tail_index % instance->num_of_slots];

    VdecLog(SYS_LOG_DEBUG, "VDEC AX_FifoPop: object=%p, tail_index=%lld, num_of_objects=%d, num_of_slots=%d.\n",
            object,
            instance->tail_index,
            instance->num_of_objects,
            instance->num_of_slots);

    instance->tail_index++;
    instance->num_of_objects--;

    pthread_spin_unlock(&instance->spinLock);

    sem_post(&instance->write_semaphore); //increment writable value

    return FIFO_OK;
}

/*
 * FifoCount()
 * Check how many elements currently in FIFO
 * mutex is not necessary inside the function because the number may change
 * anyway after mutex released. if user rely on stable count, he will need
 * external mutex to protect count() and the next logic as a whole
 */
AX_U32 AX_Vdec_Fifo_Count(FifoInst inst)
{
    AX_U32 count;
    Fifo_t *instance = (Fifo_t *)inst;

    pthread_spin_lock(&instance->spinLock);
    count = instance->num_of_objects;
    pthread_spin_unlock(&instance->spinLock);

    return count;
}

/*
 * FifoHasObject()
 * Check if a specific element exists in FIFO
 */
AX_U32 AX_Vdec_Fifo_HasObject(FifoInst inst, FifoObject *object)
{
    AX_U32 i;
    AX_U32 success = 0;
    Fifo_t *instance = (Fifo_t *)inst;

    pthread_spin_lock(&instance->spinLock);

    //* need mutex to prevent FIFO status change during the job */
    for (i = 0; i < instance->num_of_objects; i++) {
        if (&instance->nodes[(instance->tail_index + i) %
                                                        instance->num_of_slots] == object) {
            success = 1;
            break;
        }
    }

    pthread_spin_unlock(&instance->spinLock);

    return success;
}

AX_S32 AX_Vdec_Fifo_DeInit(FifoInst inst)
{
    Fifo_t *instance = (Fifo_t *)inst;

    sem_destroy(&instance->read_semaphore);
    sem_destroy(&instance->write_semaphore);

    pthread_spin_destroy(&instance->spinLock);

    free(instance->nodes);
    instance->nodes = NULL;

    free(instance);
    instance = NULL;

    return 0;
}

void AX_Vdec_Fifo_SetAbort(FifoInst inst)
{
    Fifo_t *instance = (Fifo_t *)inst;
    if (instance == NULL)
        return;

    instance->abort = 1;
    sem_post(&instance->read_semaphore);

}

void AX_Vdec_Fifo_ClearAbort(FifoInst inst)
{
    Fifo_t *instance = (Fifo_t *)inst;
    if (instance == NULL)
        return;

    instance->abort = 0;

}
