/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/
#include <stdarg.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <sys/time.h>
#include "ax_global_type.h"
#include "ax_base_type.h"
#include "ax_sys_log.h"


#define VDEC_LOG_TAG        "VDEC"
#define VDEC_LOG_ID         AX_ID_VDEC //16


static AX_LOG_TARGET_E gVdecLogTarget = SYS_LOG_TARGET_SYSLOG;
static AX_LOG_LEVEL_E   gVdecLogLevel = SYS_LOG_NOTICE;
static AX_S32 gVdecThreadLevel = 80;


void VdecLog(AX_U32 eLv, char *fmt, ...)
{
    va_list args;
    if (eLv <= gVdecLogLevel) {
        va_start(args, fmt);
        switch (eLv) {
        case SYS_LOG_DEBUG:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_DEBUG, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_INFO:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_INFO, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_NOTICE:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_NOTICE, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_WARN:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_WARNING, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_ERROR:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_ERR, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_CRITICAL:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_CRIT, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_ALERT:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_ALERT, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        case SYS_LOG_EMERGENCY:
            AX_SYS_LogOutput_Ex(gVdecLogTarget, (AX_LOG_LEVEL_E)LOG_EMERG, VDEC_LOG_TAG, VDEC_LOG_ID, fmt, args);
            break;
        default:
            break;
        }
        va_end(args);
    }
}

AX_S32 VdecLogInit(AX_LOG_LEVEL_E eLv, AX_LOG_LEVEL_E eTarget)
{
    char *pEnv = getenv("VDEC_LOG_level");
    if (pEnv) {
        AX_S32 nLv = atoi(pEnv);
        if (nLv > SYS_LOG_MIN && nLv < SYS_LOG_MAX) {
            eLv = (AX_LOG_LEVEL_E)nLv;
        }
    }
    gVdecLogLevel = eLv;

    pEnv = getenv("VDEC_LOG_target");
    if (pEnv) {
        AX_S32 nTarget = atoi(pEnv);
        if (nTarget > SYS_LOG_TARGET_MIN && nTarget < SYS_LOG_TARGET_MAX) {
            eTarget = (AX_LOG_TARGET_E)nTarget;
        }
    }
    gVdecLogTarget = eTarget;

    return 0;
}

AX_S32 VdecThreadLevelInit(void)
{
    AX_CHAR *pEnv = getenv("VDEC_THREAD_LEVEL");

    if (pEnv) {
        AX_S32 nLv = atoi(pEnv);
        if ((nLv < 1) || (nLv > 99)) {
            return -1;
        }
        gVdecThreadLevel = nLv;
    }
    return 0;
}

AX_S32 VdecGetThreadLevel(void)
{
    return gVdecThreadLevel;
}
AX_U64 VdecGetTickCount(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

