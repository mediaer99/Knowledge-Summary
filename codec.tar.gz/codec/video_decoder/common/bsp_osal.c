/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/


#include "bsp_osal.h"
#include <stdlib.h>

void *BspOsalMalloc(size_t size)
{
    return malloc(size);
}

void BspOsalFree(void *ptr)
{
    return free(ptr);
}