/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/



#ifndef _AX_VDEC_INTERFACE_H_
#define _AX_VDEC_INTERFACE_H_

#include <semaphore.h>

#include "ax_base_type.h"
#include "ax_global_type.h"
#include "ax_vdec_api.h"
#include "ax_vdec_fifo.h"

#ifdef __cplusplus
extern "C" {
#endif


#define DATA_ALIGN(value, n) (((value) + (n) - 1) & ~((n) - 1))
#define VDEC_ADDR_OFFSET  0x40000000
#define VDEC_DEVICE_NAME  "/dev/ax_decoder"

typedef enum {
    VDEC_MOD_STATUS_UNINIT = 0,
    VDEC_MOD_STATUS_INIT
} VDEC_MOD_STATUS_E;

typedef enum {
    VDEC_CHN_STATUS_INIT = 0,
    VDEC_CHN_STATUS_CREATED,
    VDEC_CHN_STATUS_STARTED,
    VDEC_CHN_STATUS_STOPPED,
    VDEC_CHN_STATUS_DESTROYING,
    VDEC_CHN_STATUS_DESTROYED,
    VDEC_CHN_STATUS_RESETED
} VDEC_CHN_STATUS_E;

typedef struct {
    // buffer related
    AX_U64  phyaddr_buffer_start;
    AX_U8   *viraddr_buffer_start;

    AX_U64  phyaddr_buffer_end;
    AX_U8   *viraddr_buffer_end;

    AX_U32  buffer_total_size;

    // buffer related
    AX_U32 read_offset;
    AX_U32 write_offset;
    AX_U32 clip_offset;
    sem_t dec_done;
} vdec_ringbuffer_t;


typedef struct {
    FifoInst InStreamQueue;    /* input stream FIFO */
    vdec_ringbuffer_t *pstInRingBuf;
    pthread_mutex_t InputDoneMutex;
    AX_S32 VdecFd;
} AxVdecInput;

struct proc_info {
    AX_U32 free_buf_num;
    AX_U32 block_fail_num;
};

typedef struct axAX_VDEC_DECODER_S {
    AX_PAYLOAD_TYPE_E enType;
    AX_S32(*pfnCreateGrp)(AX_VDEC_GRP VdGrp, const AX_VDEC_GRP_ATTR_S *pstAttr, AX_VOID **ppDecoder, const void *dwlInst,
                          AxVdecInput *InputInfo);
    AX_S32(*pfnDestroyGrp)(AX_VDEC_GRP VdGrp, AX_VOID *pDecoder);

    AX_S32(*pfnGetGrpAttr)(AX_VOID *pDecoder, AX_VDEC_GRP_ATTR_S *pstAttr);
    AX_S32(*pfnSetGrpAttr)(AX_VOID *pDecoder, const AX_VDEC_GRP_ATTR_S *pstAttr);

    AX_S32(*pfnStartRecvStream)(AX_VOID *pDecoder);
    AX_S32(*pfnStopRecvStream)(AX_VOID *pDecoder);

    AX_S32(*pfnQueryStatus)(AX_VOID *pDecoder, AX_VDEC_GRP_STATUS_S *pstStatus);

    AX_S32(*pfnResetGrp)(AX_VOID *pDecoder);

    AX_S32(*pfnSetGrpParam)(AX_VOID *pDecoder, const AX_VDEC_GRP_PARAM_S *pstParam);
    AX_S32(*pfnGetGrpParam)(AX_VOID *pDecoder, AX_VDEC_GRP_PARAM_S *pstParam);

    AX_S32(*pfnSetProtocolParam)(AX_VOID *pDecoder, const AX_VDEC_PRTCL_PARAM_S *pstParam);
    AX_S32(*pfnGetProtocolParam)(AX_VOID *pDecoder, AX_VDEC_PRTCL_PARAM_S *pstParam);

    /* s32MilliSec: -1 is block,0 is no block,other positive number is timeout */
    AX_S32(*pfnSendStream)(AX_VOID *pDecoder, const AX_VDEC_STREAM_S *pstStream, AX_S32 s32MilliSec);

    AX_S32(*pfnGetFrame)(AX_VOID *pDecoder, AX_VIDEO_FRAME_INFO_S *pstFrameInfo, AX_S32 s32MilliSec);
    AX_S32(*pfnReleaseFrame)(AX_VOID *pDecoder, const AX_VIDEO_FRAME_INFO_S *pstFrameInfo);

    AX_S32(*pfnGetUserData)(AX_VOID *pDecoder, AX_VDEC_USERDATA_S *pstUserData, AX_S32 s32MilliSec);
    AX_S32(*pfnReleaseUserData)(AX_VOID *pDecoder, const AX_VDEC_USERDATA_S *pstUserData);

    AX_S32(*pfnSetUserPic)(AX_VOID *pDecoder, const AX_VIDEO_FRAME_INFO_S *pstUsrPic);
    AX_S32(*pfnEnableUserPic)(AX_VOID *pDecoder, AX_BOOL bInstant);
    AX_S32(*pfnDisableUserPic)(AX_VOID *pDecoder);
    AX_S32(*pfnDecodeFrame)(const void *dwlInst,AX_JPEG_DECODE_ONCE_PARAMS *pstParam);

    AX_S32(*pfnSetDisplayMode)(AX_VOID *pDecoder, AX_VDEC_DISPLAY_MODE_E enDisplayMode);
    AX_S32(*pfnGetDisplayMode)(AX_VOID *pDecoder, AX_VDEC_DISPLAY_MODE_E *penDisplayMode);

    AX_S32(*pfnAttachPool)(AX_VOID *pDecoder, AX_POOL Pool);
    AX_S32(*pfnDetachPool)(AX_VOID *pDecoder);

    AX_S32(*pfnSetEndFrame)(AX_VOID *pDecoder);
    AX_F32(*pfnGetFrameRate)(AX_VOID *pDecoder);
    AX_S32(*pfnGetProcInfo)(AX_VOID *pDecoder, struct proc_info *ProcInfo);
} AX_VDEC_DECODER_S;

typedef struct {
    AX_PAYLOAD_TYPE_E enType;
    const AX_VDEC_DECODER_S *pVdecDecoder;
    AX_VDEC_STREAM_S pstInputStream;
    AxVdecInput InputInfo;
    AX_U64 get_num;
    AX_U64 send_num;
    AX_U64 release_num;
    AX_U32 free_outbuf_num;

    /*
     * pDecoder is the context of pVdecDecoder
     *
     * when call AX_VDEC_CreateChn, it's alloced by pfnCreateChn
     * when call AX_VDEC_DestroyChn, it's freed by pfnDestroyChn
     */
    AX_VOID *pDecoder;
} AxVdecChn;

typedef struct {
    VDEC_MOD_STATUS_E enModStatus;
    VDEC_CHN_STATUS_E enChnStatus[AX_VDEC_MAX_GRP_SIZE];
    AX_VDEC_GRP_ATTR_S pstAttr[AX_VDEC_MAX_GRP_SIZE];
    const void *dwlInst;
    AxVdecChn *chns[AX_VDEC_MAX_GRP_SIZE];
    pthread_mutex_t ChannelMutex[AX_VDEC_MAX_GRP_SIZE];
    pthread_mutex_t SendMutex[AX_VDEC_MAX_GRP_SIZE];
    pthread_mutex_t GetMutex[AX_VDEC_MAX_GRP_SIZE];
    pthread_mutex_t ReleaseMutex[AX_VDEC_MAX_GRP_SIZE];
    pthread_mutex_t JpegDecMutex;
    AX_S32 fd;
} AxVdecContext;


extern AX_VDEC_DECODER_S gVdecDecoder;
extern AX_VDEC_DECODER_S gJdecDecoder;

AX_S32 CreateJdecWorkingThread();
AX_S32 DestroyJdecWorkingThread();
AX_S32 CreateVdecWorkingThread();
AX_S32 DestroyVdecWorkingThread();
AX_S32 VdecSendSig();
AX_S32 JdecSendSig();


vdec_ringbuffer_t *Vdec_RingBuffer_Create(AX_VDEC_GRP VdGrp, AX_U32 buffer_size);
AX_S32 Vdec_RingBuffer_Close(AX_VDEC_GRP VdGrp, vdec_ringbuffer_t *pRingbbuf);
AX_S32 Vdec_RingBuffer_Read(vdec_ringbuffer_t *pRingBuf, AX_U32 packet_size);
AX_S32 Vdec_NonBlockingDecode(AxVdecChn *VdChn, const AX_VDEC_STREAM_S *pstStream);
AX_S32 Vdec_BlockingDecode(AxVdecChn *VdChn, const AX_VDEC_STREAM_S *pstStream);
AX_S32 Vdec_RingBuffer_Reset(vdec_ringbuffer_t *pRingBuf);

#ifdef __cplusplus
}
#endif

#endif
