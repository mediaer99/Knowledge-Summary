#ifndef  _AX_FIFO_H_
#define  _AX_FIFO_H_

#include <pthread.h>
#include <unistd.h>
#include "ax_base_type.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef struct axVdec_STREAM_INFO_S {
    AX_U32  u32Len;
    AX_U64  u64PTS;
    AX_BOOL bEndOfFrame;
    AX_BOOL bEndOfStream;
    AX_BOOL bDisplay;
    AX_BOOL bForInsertUserPic;  /* When bEndOfStream is TRUE, indicates whether the image is from the user to insert the behavior */
    AX_U8  *pu8Addr;
    AX_U64  pu64PhyAddr;
} AX_VDEC_STREAM_INFO_S;

/* FIFO_DATATYPE must be defined to hold specific type of objects. If it is not
 * defined, we need to report an error. */
#ifndef FIFO_DATATYPE
#error "You must define FIFO_DATATYPE to use this module."
#endif /* FIFO_DATATYPE */

typedef FIFO_DATATYPE FifoObject;


#define VDEC_MAX_FIFO_CAPACITY 10


/* Possible return values. */
typedef enum {
    FIFO_OK,             /* Operation was successful. */
    FIFO_ERROR_MEMALLOC, /* Failed due to memory allocation error. */
    FIFO_EMPTY,
    FIFO_FULL,
    FIFO_NOK,
    FIFO_ABORT = 0x7FFFFFFF
} FifoRet;

enum FifoException {
    FIFO_EXCEPTION_DISABLE,
    FIFO_EXCEPTION_ENABLE
};

typedef void *FifoInst;

/* FifoInit initializes the queue.
 * |num_of_slots| defines how many slots to reserve at maximum.
 * |instance| is output parameter holding the instance. */
FifoRet AX_Vdec_Fifo_Init(AX_U32 num_of_slots, FifoInst *instance);

/* IsFifoFull tests if a Fifo is already full.
 *
 * |inst| is the instance (pointer)  */
FifoRet AX_Vdec_IsFifoFull(const FifoInst inst);

/* IsFifoFull tests if a Fifo is already empty.
 *
 * |inst| is the instance (pointer)  */
FifoRet AX_Vdec_IsFifoEmpty(const FifoInst inst);

/* FifoPush pushes an object to the back of the queue. Ownership of the
 * contained object will be moved from the caller to the queue. Returns OK
 * if the object is successfully pushed into fifo.
 *
 * |inst| is the instance push to.
 * |object| holds the pointer to the object to push into queue.
 * |exception_enable| enable FIFO_FULL return value */
FifoRet AX_Vdec_FifoPush(FifoInst inst, FifoObject object,
                         enum FifoException e);

/* FifoPop returns object from the front of the queue. Ownership of the popped
 * object will be moved from the queue to the caller. Returns OK if the object
 * is successfully popped from the fifo.
 *
 * |inst| is the instance to pop from.
 * |object| holds the pointer to the object popped from the queue.
 * |exception_enable| enable FIFO_EMPTY return value */
FifoRet AX_Vdec_FifoPop(FifoInst inst, FifoObject *object,
                        enum FifoException e);

/* Ask how many objects there are in the fifo. */
AX_U32 AX_Vdec_Fifo_Count(FifoInst inst);

/* Check if object is contained in fifo */
AX_U32 AX_Vdec_Fifo_HasObject(FifoInst inst, FifoObject *object);

/* FifoRelease releases and deallocated queue. User needs to make sure the
 * queue is empty and no threads are waiting in FifoPush or FifoPop.
 * |inst| is the instance to release. */
AX_S32 AX_Vdec_Fifo_DeInit(FifoInst inst);
void AX_Vdec_Fifo_SetAbort(FifoInst inst);
void AX_Vdec_Fifo_ClearAbort(FifoInst inst);

#ifdef __cplusplus
}
#endif

#endif /* __FIFO_H__ */
