/**********************************************************************************
 *
 * Copyright (c) 2019-2020 Beijing AXera Technology Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Beijing AXera Technology Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Beijing AXera Technology Co., Ltd.
 *
 **********************************************************************************/


#ifndef _AX_VDEC_PROC_H_
#define _AX_VDEC_PROC_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "basetype.h"


#define PROC_MSG_LEN            4096
typedef void ProcCatCallback(char *msg, size_t msgMaxLen);

struct ProcListenerThreadParams {
  int fd;
  int b_stopped;
  ProcCatCallback *callback;
};

i32 VdecProcRegisterCatCallback(ProcCatCallback *cb);
i32 VdecProcUnRegisterCatCallback(void);


#ifdef __cplusplus
}
#endif

#endif //_AX_VDEC_PROC_NL_H_
